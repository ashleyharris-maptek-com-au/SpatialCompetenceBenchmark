color([1, 0, 1]) hull()
{
  translate([0.1, 0.0, 4.975]) cube([0.4, 0.4, 0.1], center = true);
  translate([1.9000000000000001, 0.0, 4.5249999999999995]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([2.1, 0.0, 4.475]) cube([0.4, 0.4, 0.1], center = true);
  translate([3.9000000000000004, 0.0, 4.025]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.1, 0.0, 3.975]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.9, 0.0, 3.525]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([6.1000000000000005, 0.0, 3.475]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.9, 0.0, 3.0250000000000004]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.05, 0.0, 2.95]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.95, 0.0, 2.05]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([9.0, 0.0, 1.9500000000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([9.0, 0.0, 1.05]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([9.0, 0.0, 0.9500000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([9.0, 0.0, 0.05]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([9.049999999999999, 0.0, 0.0]) cube([0.4, 0.4, 0.1], center = true);
  translate([9.95, 0.0, 0.0]) cube([0.4, 0.4, 0.1], center = true);
}
