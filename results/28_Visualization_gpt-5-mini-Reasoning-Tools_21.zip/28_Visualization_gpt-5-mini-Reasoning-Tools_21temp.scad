
translate([0, 0, 0]) cube([1, 1, 5.063914252819218]);

translate([1, 0, 0]) cube([1, 1, 4.417582102430126]);

translate([2, 0, 0]) cube([1, 1, 4.335833039781842]);

translate([3, 0, 0]) cube([1, 1, 4.261814263715259]);

translate([4, 0, 0]) cube([1, 1, 4.261814262717931]);

translate([5, 0, 0]) cube([1, 1, 4.253041292915157]);

translate([6, 0, 0]) cube([1, 1, 4.290332828876327]);

translate([7, 0, 0]) cube([1, 1, 4.356780468976013]);

translate([8, 0, 0]) cube([1, 1, 4.370787159360663]);

translate([9, 0, 0]) cube([1, 1, 4.373658894836169]);

translate([10, 0, 0]) cube([1, 1, 4.4009395922203085]);

translate([11, 0, 0]) cube([1, 1, 4.051198102580922]);

translate([12, 0, 0]) cube([1, 1, 3.9247525884943606]);

translate([13, 0, 0]) cube([1, 1, 5.323611111111111]);

translate([14, 0, 0]) cube([1, 1, 3.842846209912538]);

translate([15, 0, 0]) cube([1, 1, 5.4]);

translate([16, 0, 0]) cube([1, 1, 4.172324218667842]);

translate([17, 0, 0]) cube([1, 1, 4.105226450819739]);

translate([18, 0, 0]) cube([1, 1, 4.0051756968143115]);

translate([19, 0, 0]) cube([1, 1, 3.9751641603220027]);

translate([20, 0, 0]) cube([1, 1, 3.9542361887955773]);

translate([21, 0, 0]) cube([1, 1, 3.2816211089322658]);

translate([22, 0, 0]) cube([1, 1, 4.6]);

translate([23, 0, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.278930849148365]);

translate([2, 1, 0]) cube([1, 1, 4.743421453909107]);

translate([3, 1, 0]) cube([1, 1, 4.431731687364579]);

translate([4, 1, 0]) cube([1, 1, 4.261814348067988]);

translate([5, 1, 0]) cube([1, 1, 4.267135998292793]);

translate([6, 1, 0]) cube([1, 1, 4.253050109468228]);

translate([7, 1, 0]) cube([1, 1, 4.357294175768474]);

translate([8, 1, 0]) cube([1, 1, 3.9808276229199313]);

translate([9, 1, 0]) cube([1, 1, 4.439354758813513]);

translate([10, 1, 0]) cube([1, 1, 4.449096351504166]);

translate([11, 1, 0]) cube([1, 1, 4.282840041861809]);

translate([12, 1, 0]) cube([1, 1, 3.924754102869966]);

translate([13, 1, 0]) cube([1, 1, 4.881157073682649]);

translate([14, 1, 0]) cube([1, 1, 3.266338598738861]);

translate([15, 1, 0]) cube([1, 1, 4.39518151891538]);

translate([16, 1, 0]) cube([1, 1, 4.1957159616068065]);

translate([17, 1, 0]) cube([1, 1, 4.105794846478754]);

translate([18, 1, 0]) cube([1, 1, 4.008152380402226]);

translate([19, 1, 0]) cube([1, 1, 3.9849329729666203]);

translate([20, 1, 0]) cube([1, 1, 3.9511470866888385]);

translate([21, 1, 0]) cube([1, 1, 3.9254133991082827]);

translate([22, 1, 0]) cube([1, 1, 4.066964285714286]);

translate([23, 1, 0]) cube([1, 1, 4.116071428571428]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.2365232745436785]);

translate([4, 2, 0]) cube([1, 1, 4.838911015463874]);

translate([5, 2, 0]) cube([1, 1, 4.832044425096655]);

translate([6, 2, 0]) cube([1, 1, 4.625481673513831]);

translate([7, 2, 0]) cube([1, 1, 4.358381234444094]);

translate([8, 2, 0]) cube([1, 1, 4.400548762878293]);

translate([9, 2, 0]) cube([1, 1, 4.476072404952554]);

translate([10, 2, 0]) cube([1, 1, 4.561818691892076]);

translate([11, 2, 0]) cube([1, 1, 4.6426859438497665]);

translate([12, 2, 0]) cube([1, 1, 3.925347742712394]);

translate([13, 2, 0]) cube([1, 1, 3.9739137585143904]);

translate([14, 2, 0]) cube([1, 1, 4.255404467181312]);

translate([15, 2, 0]) cube([1, 1, 4.208647062811825]);

translate([16, 2, 0]) cube([1, 1, 4.163306233855509]);

translate([17, 2, 0]) cube([1, 1, 4.075301927624784]);

translate([18, 2, 0]) cube([1, 1, 4.015635150221925]);

translate([19, 2, 0]) cube([1, 1, 3.6589938565733]);

translate([20, 2, 0]) cube([1, 1, 3.950507365881565]);

translate([21, 2, 0]) cube([1, 1, 3.9236170347514676]);

translate([22, 2, 0]) cube([1, 1, 3.920930283955556]);

translate([23, 2, 0]) cube([1, 1, 3.920930353424581]);

translate([0, 3, 0]) cube([1, 1, 7.201875]);

translate([1, 3, 0]) cube([1, 1, 6.5541251092101875]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

translate([4, 3, 0]) cube([1, 1, 5.4597757450497975]);

translate([5, 3, 0]) cube([1, 1, 5.436866440082656]);

translate([6, 3, 0]) cube([1, 1, 5.039534741869547]);

translate([7, 3, 0]) cube([1, 1, 4.591178845709247]);

translate([8, 3, 0]) cube([1, 1, 4.48872900840174]);

translate([9, 3, 0]) cube([1, 1, 4.644474086086732]);

translate([10, 3, 0]) cube([1, 1, 4.616782619444636]);

translate([11, 3, 0]) cube([1, 1, 4.6751550558439385]);

translate([12, 3, 0]) cube([1, 1, 4.740933803796443]);

translate([13, 3, 0]) cube([1, 1, 4.318307499020759]);

translate([14, 3, 0]) cube([1, 1, 4.237227487385772]);

translate([15, 3, 0]) cube([1, 1, 4.213317839495521]);

translate([16, 3, 0]) cube([1, 1, 3.9252506079418503]);

translate([17, 3, 0]) cube([1, 1, 4.048476082821691]);

translate([18, 3, 0]) cube([1, 1, 4.0122310990233165]);

translate([19, 3, 0]) cube([1, 1, 3.992007820424372]);

translate([20, 3, 0]) cube([1, 1, 3.9499579814758996]);

translate([21, 3, 0]) cube([1, 1, 3.9217111174359003]);

translate([22, 3, 0]) cube([1, 1, 3.920930449143807]);

translate([23, 3, 0]) cube([1, 1, 3.9209307380629834]);

translate([0, 4, 0]) cube([1, 1, 7.509375]);

translate([1, 4, 0]) cube([1, 1, 6.927722029541928]);

translate([2, 4, 0]) cube([1, 1, 6.647671873240636]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.40960811186823]);

translate([7, 4, 0]) cube([1, 1, 5.00373854361195]);

translate([8, 4, 0]) cube([1, 1, 4.986352321456558]);

translate([9, 4, 0]) cube([1, 1, 5.229172240432244]);

color([0,1,0])
translate([10, 4, 0]) cube([1, 1, 6]);

translate([11, 4, 0]) cube([1, 1, 5.00947398520858]);

translate([12, 4, 0]) cube([1, 1, 4.801058971088814]);

translate([13, 4, 0]) cube([1, 1, 3.0745441706555012]);

translate([14, 4, 0]) cube([1, 1, 4.224438589757577]);

translate([15, 4, 0]) cube([1, 1, 4.224805643855181]);

translate([16, 4, 0]) cube([1, 1, 4.205565911453252]);

translate([17, 4, 0]) cube([1, 1, 4.1228772615631195]);

translate([18, 4, 0]) cube([1, 1, 4.049470117967452]);

translate([19, 4, 0]) cube([1, 1, 4.005748514862093]);

translate([20, 4, 0]) cube([1, 1, 3.9473249317470187]);

translate([21, 4, 0]) cube([1, 1, 3.9222382375967078]);

translate([22, 4, 0]) cube([1, 1, 3.92109062893696]);

translate([23, 4, 0]) cube([1, 1, 3.9213234494664193]);

translate([0, 5, 0]) cube([1, 1, 7.9]);

translate([1, 5, 0]) cube([1, 1, 7.458180185339443]);

translate([2, 5, 0]) cube([1, 1, 7.1414579328282715]);

translate([3, 5, 0]) cube([1, 1, 6.777665885160196]);

translate([4, 5, 0]) cube([1, 1, 6.5444806220632055]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

translate([7, 5, 0]) cube([1, 1, 5.4855201103811275]);

translate([8, 5, 0]) cube([1, 1, 5.487661119884476]);

color([0,1,0])
translate([9, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 5, 0]) cube([1, 1, 6]);

translate([12, 5, 0]) cube([1, 1, 4.827293211151429]);

translate([13, 5, 0]) cube([1, 1, 4.786829541008619]);

translate([14, 5, 0]) cube([1, 1, 4.2578771108770646]);

translate([15, 5, 0]) cube([1, 1, 4.312812432283312]);

translate([16, 5, 0]) cube([1, 1, 4.2217207684336735]);

translate([17, 5, 0]) cube([1, 1, 4.157433384915661]);

translate([18, 5, 0]) cube([1, 1, 4.065092587367528]);

translate([19, 5, 0]) cube([1, 1, 4.040206203760432]);

translate([20, 5, 0]) cube([1, 1, 4.2]);

translate([21, 5, 0]) cube([1, 1, 4.2]);

translate([22, 5, 0]) cube([1, 1, 4.1]);

translate([23, 5, 0]) cube([1, 1, 3.9224641646460516]);

translate([0, 6, 0]) cube([1, 1, 6.972292534360683]);

translate([1, 6, 0]) cube([1, 1, 7.469498386089131]);

translate([2, 6, 0]) cube([1, 1, 7.170800257319481]);

translate([3, 6, 0]) cube([1, 1, 6.994971806494947]);

translate([4, 6, 0]) cube([1, 1, 6.785502024630127]);

translate([5, 6, 0]) cube([1, 1, 6.664263395449447]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 6, 0]) cube([1, 1, 6]);

translate([12, 6, 0]) cube([1, 1, 4.832153838527448]);

translate([13, 6, 0]) cube([1, 1, 4.812426436350749]);

translate([14, 6, 0]) cube([1, 1, 4.448942480147947]);

translate([15, 6, 0]) cube([1, 1, 4.338324432267833]);

translate([16, 6, 0]) cube([1, 1, 4.021427308007894]);

translate([17, 6, 0]) cube([1, 1, 4.4316997482913765]);

translate([18, 6, 0]) cube([1, 1, 4.6]);

translate([19, 6, 0]) cube([1, 1, 4.6]);

translate([20, 6, 0]) cube([1, 1, 4.7]);

translate([21, 6, 0]) cube([1, 1, 4.6]);

translate([22, 6, 0]) cube([1, 1, 4.5]);

translate([23, 6, 0]) cube([1, 1, 4.4]);

translate([0, 7, 0]) cube([1, 1, 7.9]);

translate([1, 7, 0]) cube([1, 1, 7.369613962932113]);

translate([2, 7, 0]) cube([1, 1, 5.713444584748169]);

translate([3, 7, 0]) cube([1, 1, 5.98915194114821]);

translate([4, 7, 0]) cube([1, 1, 6.915686917589839]);

translate([5, 7, 0]) cube([1, 1, 6.848745878681277]);

translate([6, 7, 0]) cube([1, 1, 6.692570341717102]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

translate([12, 7, 0]) cube([1, 1, 5.0129465344679565]);

translate([13, 7, 0]) cube([1, 1, 4.907252083246426]);

translate([14, 7, 0]) cube([1, 1, 4.613070779811322]);

translate([15, 7, 0]) cube([1, 1, 4.745659567540545]);

translate([16, 7, 0]) cube([1, 1, 4.691832086977896]);

translate([17, 7, 0]) cube([1, 1, 5.1]);

translate([18, 7, 0]) cube([1, 1, 5.3]);

translate([19, 7, 0]) cube([1, 1, 5.2]);

translate([20, 7, 0]) cube([1, 1, 5.1]);

translate([21, 7, 0]) cube([1, 1, 4.9]);

translate([22, 7, 0]) cube([1, 1, 4.9]);

translate([23, 7, 0]) cube([1, 1, 5.1]);

translate([0, 8, 0]) cube([1, 1, 8.1]);

translate([1, 8, 0]) cube([1, 1, 7.510714285714286]);

translate([2, 8, 0]) cube([1, 1, 7.066411635871387]);

translate([3, 8, 0]) cube([1, 1, 6.842569059586198]);

translate([4, 8, 0]) cube([1, 1, 6.821803619258827]);

translate([5, 8, 0]) cube([1, 1, 6.202196297671816]);

translate([6, 8, 0]) cube([1, 1, 6.8301501243144465]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

translate([12, 8, 0]) cube([1, 1, 5.00798893274674]);

translate([13, 8, 0]) cube([1, 1, 5.003369117662642]);

translate([14, 8, 0]) cube([1, 1, 4.672101453625737]);

translate([15, 8, 0]) cube([1, 1, 4.8894639840298675]);

translate([16, 8, 0]) cube([1, 1, 4.933341600608792]);

color([0,1,0])
translate([17, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 8.2]);

translate([1, 9, 0]) cube([1, 1, 7.6]);

translate([2, 9, 0]) cube([1, 1, 7.288629303315976]);

translate([3, 9, 0]) cube([1, 1, 6.851464589244881]);

translate([4, 9, 0]) cube([1, 1, 6.863215475914538]);

translate([5, 9, 0]) cube([1, 1, 7.067192357092268]);

translate([6, 9, 0]) cube([1, 1, 6.5907590547277275]);

translate([7, 9, 0]) cube([1, 1, 6.762195879831057]);

translate([8, 9, 0]) cube([1, 1, 6.675341768484436]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

translate([13, 9, 0]) cube([1, 1, 5.015726479012013]);

translate([14, 9, 0]) cube([1, 1, 5.176172199375037]);

translate([15, 9, 0]) cube([1, 1, 5.004417515178941]);

translate([16, 9, 0]) cube([1, 1, 5.104246517620685]);

color([0,1,0])
translate([17, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 8.1]);

translate([1, 10, 0]) cube([1, 1, 7.7]);

translate([2, 10, 0]) cube([1, 1, 7.522887665868817]);

translate([3, 10, 0]) cube([1, 1, 7.625022045855379]);

translate([4, 10, 0]) cube([1, 1, 6.859426035756344]);

translate([5, 10, 0]) cube([1, 1, 6.869044737084417]);

translate([6, 10, 0]) cube([1, 1, 6.822589426492217]);

translate([7, 10, 0]) cube([1, 1, 6.60925066512631]);

translate([8, 10, 0]) cube([1, 1, 6.555633594579467]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

translate([14, 10, 0]) cube([1, 1, 5.434486888079559]);

translate([15, 10, 0]) cube([1, 1, 5.315972220597894]);

translate([16, 10, 0]) cube([1, 1, 5.401013859175584]);

color([0,1,0])
translate([17, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

translate([20, 10, 0]) cube([1, 1, 6.6]);

translate([21, 10, 0]) cube([1, 1, 6.8]);

translate([22, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 8.1]);

translate([1, 11, 0]) cube([1, 1, 7.8]);

translate([2, 11, 0]) cube([1, 1, 7.604170340975896]);

translate([3, 11, 0]) cube([1, 1, 7.441226318202178]);

translate([4, 11, 0]) cube([1, 1, 7.275312158157115]);

translate([5, 11, 0]) cube([1, 1, 6.714597710181616]);

translate([6, 11, 0]) cube([1, 1, 6.714542947954815]);

translate([7, 11, 0]) cube([1, 1, 6.615088748402324]);

color([0,1,0])
translate([8, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

translate([20, 11, 0]) cube([1, 1, 6.7]);

translate([21, 11, 0]) cube([1, 1, 7.0]);

translate([22, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 7.7]);

translate([1, 12, 0]) cube([1, 1, 7.40083406819518]);

translate([2, 12, 0]) cube([1, 1, 7.2092461454746495]);

translate([3, 12, 0]) cube([1, 1, 7.025990992561968]);

translate([4, 12, 0]) cube([1, 1, 6.669184437878188]);

translate([5, 12, 0]) cube([1, 1, 6.664930858322898]);

translate([6, 12, 0]) cube([1, 1, 6.694895555956996]);

translate([7, 12, 0]) cube([1, 1, 6.870302278055861]);

translate([8, 12, 0]) cube([1, 1, 6.776022268026273]);

translate([9, 12, 0]) cube([1, 1, 6.614995904469482]);

translate([10, 12, 0]) cube([1, 1, 6.5595017771623985]);

translate([11, 12, 0]) cube([1, 1, 6.614651195530981]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 12, 0]) cube([1, 1, 6]);

translate([21, 12, 0]) cube([1, 1, 6.7]);

translate([22, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 7.000208517048795]);

translate([1, 13, 0]) cube([1, 1, 6.803808040447501]);

translate([2, 13, 0]) cube([1, 1, 6.806225555032082]);

translate([3, 13, 0]) cube([1, 1, 6.622129426189375]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

translate([8, 13, 0]) cube([1, 1, 6.5536635387192]);

translate([9, 13, 0]) cube([1, 1, 6.640066027441557]);

translate([10, 13, 0]) cube([1, 1, 6.711541005136126]);

translate([11, 13, 0]) cube([1, 1, 6.707131834060288]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

translate([14, 13, 0]) cube([1, 1, 5.435499607641278]);

translate([15, 13, 0]) cube([1, 1, 5.33165911358583]);

translate([16, 13, 0]) cube([1, 1, 5.403702366130321]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 6.701338852498766]);

translate([1, 14, 0]) cube([1, 1, 6.503949578304838]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

translate([9, 14, 0]) cube([1, 1, 6.526317642066897]);

translate([10, 14, 0]) cube([1, 1, 7.0]);

translate([11, 14, 0]) cube([1, 1, 7.0]);

translate([12, 14, 0]) cube([1, 1, 6.501188638855168]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

translate([15, 14, 0]) cube([1, 1, 5.328630071522901]);

translate([16, 14, 0]) cube([1, 1, 5.198675282270045]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 7.0]);

translate([1, 15, 0]) cube([1, 1, 6.6002677704997526]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

translate([10, 15, 0]) cube([1, 1, 6.9]);

translate([11, 15, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

translate([16, 15, 0]) cube([1, 1, 5.32674233881597]);

translate([17, 15, 0]) cube([1, 1, 5.404121337156596]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

translate([23, 15, 0]) cube([1, 1, 5.4]);

translate([0, 16, 0]) cube([1, 1, 7.2]);

translate([1, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 16, 0]) cube([1, 1, 6]);

translate([10, 16, 0]) cube([1, 1, 6.8]);

translate([11, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

translate([17, 16, 0]) cube([1, 1, 5.406023470283742]);

translate([18, 16, 0]) cube([1, 1, 5.31225687008673]);

translate([19, 16, 0]) cube([1, 1, 5.40021009294838]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

translate([23, 16, 0]) cube([1, 1, 5.100015977412403]);

translate([0, 17, 0]) cube([1, 1, 7.0]);

translate([1, 17, 0]) cube([1, 1, 4.6677966347355255]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

translate([9, 17, 0]) cube([1, 1, 6.6]);

translate([10, 17, 0]) cube([1, 1, 6.9]);

translate([11, 17, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 17, 0]) cube([1, 1, 6]);

translate([22, 17, 0]) cube([1, 1, 5.300031961768935]);

translate([23, 17, 0]) cube([1, 1, 4.900080771541364]);

translate([0, 18, 0]) cube([1, 1, 6.62625]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

translate([8, 18, 0]) cube([1, 1, 6.6]);

translate([9, 18, 0]) cube([1, 1, 7.0]);

translate([10, 18, 0]) cube([1, 1, 7.1]);

translate([11, 18, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([20, 18, 0]) cube([1, 1, 5.400273458670406]);

translate([21, 18, 0]) cube([1, 1, 5.300159819779317]);

translate([22, 18, 0]) cube([1, 1, 4.900113610023593]);

translate([23, 18, 0]) cube([1, 1, 4.700156531194311]);

color([0,1,0])
translate([0, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 19, 0]) cube([1, 1, 6]);

translate([8, 19, 0]) cube([1, 1, 6.8]);

translate([9, 19, 0]) cube([1, 1, 7.2]);

translate([10, 19, 0]) cube([1, 1, 7.1]);

translate([11, 19, 0]) cube([1, 1, 6.5092592592592595]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

translate([19, 19, 0]) cube([1, 1, 5.400463758263463]);

translate([20, 19, 0]) cube([1, 1, 5.400284358495545]);

translate([21, 19, 0]) cube([1, 1, 5.300175939339008]);

translate([22, 19, 0]) cube([1, 1, 5.000086723380187]);

translate([23, 19, 0]) cube([1, 1, 4.600360884181522]);

color([0,1,0])
translate([0, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 20, 0]) cube([1, 1, 6]);

translate([2, 20, 0]) cube([1, 1, 4.4118171940138655]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

translate([4, 20, 0]) cube([1, 1, 4.370468949121754]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 20, 0]) cube([1, 1, 6]);

translate([7, 20, 0]) cube([1, 1, 6.6]);

translate([8, 20, 0]) cube([1, 1, 6.8]);

translate([9, 20, 0]) cube([1, 1, 6.8]);

translate([10, 20, 0]) cube([1, 1, 6.5018518518518515]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 20, 0]) cube([1, 1, 6]);

translate([23, 20, 0]) cube([1, 1, 5.100001005574905]);

color([0,1,0])
translate([0, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

translate([4, 21, 0]) cube([1, 1, 4.615092400011856]);

color([0,1,0])
translate([5, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

translate([11, 21, 0]) cube([1, 1, 5.0321245673633435]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

translate([20, 21, 0]) cube([1, 1, 5.400106848121165]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 22, 0]) cube([1, 1, 6]);

translate([6, 22, 0]) cube([1, 1, 5.451524810497561]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 22, 0]) cube([1, 1, 6]);

translate([11, 22, 0]) cube([1, 1, 5.033672206632046]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

translate([17, 22, 0]) cube([1, 1, 5.409322833521904]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

translate([19, 22, 0]) cube([1, 1, 5.400098316585448]);

translate([20, 22, 0]) cube([1, 1, 5.300189864276989]);

translate([21, 22, 0]) cube([1, 1, 5.400038276204492]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 23, 0]) cube([1, 1, 6]);

translate([5, 23, 0]) cube([1, 1, 5.468422799943006]);

translate([6, 23, 0]) cube([1, 1, 5.458235914503684]);

translate([7, 23, 0]) cube([1, 1, 5.437237955608573]);

translate([8, 23, 0]) cube([1, 1, 5.379554530221328]);

translate([9, 23, 0]) cube([1, 1, 5.379563450719657]);

translate([10, 23, 0]) cube([1, 1, 5.445871285605926]);

color([0,1,0])
translate([11, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 23, 0]) cube([1, 1, 6]);

translate([16, 23, 0]) cube([1, 1, 5.415459328395999]);

translate([17, 23, 0]) cube([1, 1, 5.222387447692024]);

translate([18, 23, 0]) cube([1, 1, 5.22243414110151]);

translate([19, 23, 0]) cube([1, 1, 5.30018920632444]);

translate([20, 23, 0]) cube([1, 1, 5.300192778545609]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);
