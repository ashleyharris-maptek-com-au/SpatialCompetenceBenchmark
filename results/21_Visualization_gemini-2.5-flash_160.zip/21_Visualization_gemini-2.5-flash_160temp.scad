
hull() {
    translate([7.5, 0.07500000000000001, 8.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.5, 1.425, 8.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.5, 1.5746000000000002, 8.684999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.5, 2.9174, 8.415000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.5, 3.0666, 8.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.5, 4.409400000000001, 8.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.5, 4.5586, 8.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.5, 5.9014, 7.8149999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.49545, 6.04955, 7.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.41355, 7.37345, 7.515000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.3911, 7.5185, 7.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.0689, 8.8055, 7.215000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.02055, 8.9441, 7.1850000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.47245, 10.1519, 6.915000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.4014500000000005, 10.2776, 6.885000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.671550000000001, 11.332400000000002, 6.614999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.5837, 11.438400000000001, 6.584999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.7322999999999995, 12.2916, 6.3149999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.63405, 12.3727, 6.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.7169499999999998, 12.9793, 6.015000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.61505, 13.0317, 5.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6979499999999996, 13.368300000000001, 5.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.59905, 13.389600000000002, 5.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7359499999999999, 13.4364, 5.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.6461999999999999, 13.4254, 5.385000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.8938, 13.180600000000002, 5.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.81955, 13.138150000000001, 5.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.23545000000000002, 12.61885, 4.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.19785000000000003, 12.5803, 4.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.10515000000000002, 12.405700000000001, 4.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 12.386700000000001, 4.484999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 12.2193, 4.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 12.200700000000001, 4.1850000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 12.0333, 3.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 12.0147, 3.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 11.847299999999999, 3.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 11.8287, 3.5850000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 11.661299999999999, 3.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 11.642699999999998, 3.2849999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 11.4753, 3.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 11.4567, 2.9850000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 11.289299999999999, 2.7150000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 11.2707, 2.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 11.1033, 2.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 11.0847, 2.3850000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 10.9173, 2.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 10.8987, 2.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 10.7313, 1.8150000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 10.712699999999998, 1.7850000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 10.545300000000001, 1.5150000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 10.5267, 1.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 10.3593, 1.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 10.3407, 1.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 10.173300000000001, 0.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 10.1547, 0.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 9.9873, 0.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 9.9687, 0.5850000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 9.8013, 0.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 9.782699999999998, 0.28500000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 9.615300000000001, 0.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1, 9.606, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1, 9.606, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.10900000000000001, 9.6135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.2710000000000001, 9.7485, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.28900000000000003, 9.7635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.451, 9.8985, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.46900000000000003, 9.913499999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.6310000000000001, 10.0485, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.649, 10.0635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.8109999999999999, 10.1985, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.829, 10.2135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.991, 10.3485, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.009, 10.3635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.171, 10.498500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.189, 10.5135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.3510000000000002, 10.6485, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.3690000000000002, 10.6635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.5310000000000001, 10.798499999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5490000000000002, 10.8135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.711, 10.948500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.729, 10.9635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.891, 11.0985, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.909, 11.1135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.071, 11.2485, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.089, 11.2635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.251, 11.398500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.2689999999999997, 11.4135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.431, 11.548499999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.4490000000000003, 11.5635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.611, 11.6985, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.629, 11.7135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.791, 11.848500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.809, 11.8635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.971, 11.9985, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.989, 12.0135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.1510000000000002, 12.1485, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.1690000000000005, 12.1635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.331, 12.2985, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3489999999999998, 12.313500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.511, 12.4485, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.5290000000000004, 12.4635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6910000000000003, 12.5985, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.709, 12.6135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.871, 12.748500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.8890000000000002, 12.7635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.051, 12.898500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.069, 12.9135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.231, 13.048499999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.2490000000000006, 13.0635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.4110000000000005, 13.198500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.429, 13.2135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.590999999999999, 13.348500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.609, 13.3635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.771000000000001, 13.4985, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.789000000000001, 13.5135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.9510000000000005, 13.6485, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.969, 13.663499999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.130999999999999, 13.7985, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.148999999999999, 13.8135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.311, 13.9485, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.329000000000001, 13.9635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.4910000000000005, 14.0985, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.509, 14.1135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.671, 14.248500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.689, 14.2635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.851, 14.3985, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.869, 14.4135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.031, 14.548499999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.0489999999999995, 14.5635, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.211, 14.698500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.229, 14.7135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.391000000000001, 14.8485, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.409000000000001, 14.8632, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.571000000000001, 14.9928, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.580000000000001, 15.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.580000000000001, 15.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.589, 14.9925, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.7509999999999994, 14.8575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.769, 14.842500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.931000000000001, 14.7075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.949000000000001, 14.6925, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.111000000000001, 14.557500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.1290000000000004, 14.5425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.291, 14.4075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.309, 14.392500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.471, 14.2575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.489000000000001, 14.242500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.651, 14.1075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.6690000000000005, 14.0925, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.831, 13.9575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.849, 13.942499999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.011, 13.807500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.029, 13.792500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.190999999999999, 13.6575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.209, 13.6425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.371, 13.5075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.389000000000001, 13.4925, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.551, 13.357500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.569, 13.342500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.731, 13.2075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.749, 13.192499999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.911000000000001, 13.057500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.929, 13.0425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.091, 12.907500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.109, 12.892500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.271, 12.7575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.289, 12.7425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.451, 12.6075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.469000000000001, 12.5925, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.631, 12.4575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.649000000000001, 12.4425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.811000000000002, 12.307500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.829, 12.2925, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.991, 12.1575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.009, 12.1425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.171000000000001, 12.0075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.189, 11.992500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.350999999999999, 11.8575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.369, 11.8425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.530999999999999, 11.7075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.549, 11.692499999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.711000000000002, 11.557500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.729000000000001, 11.542500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.891, 11.4075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.909, 11.3925, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.071, 11.2575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.088999999999999, 11.2425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.251000000000001, 11.1075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.269, 11.0925, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.431, 10.9575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.449, 10.9425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.611, 10.807500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.629, 10.7925, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.791, 10.6575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.809000000000001, 10.6425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.971, 10.5075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.989, 10.492500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.151000000000002, 10.3575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.169, 10.3425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.331, 10.2075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.349, 10.192499999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.511000000000001, 10.057500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.529, 10.042500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.690999999999999, 9.9075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.709, 9.8925, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.871, 9.7575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.889000000000001, 9.7425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.051000000000002, 9.6075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.069, 9.592500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.231, 9.4575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.249, 9.442499999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.411, 9.307500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.428999999999998, 9.2925, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.591000000000001, 9.1575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.609, 9.142500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.770999999999999, 9.0075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.789, 8.9925, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.951000000000002, 8.8575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.969000000000001, 8.8425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.131, 8.7075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.149000000000001, 8.692499999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.311, 8.557500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.329, 8.5425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.491000000000001, 8.4075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.509, 8.3925, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.671, 8.2575, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.689, 8.2425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.851, 8.1075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.867, 8.09325, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.993, 7.97175, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 7.9559999999999995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 7.7940000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 7.776, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 7.614000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 7.596000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 7.434, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 7.416, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 7.2540000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 7.236000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 7.074, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 7.056, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 6.894, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 6.876, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 6.714, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 6.696000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 6.534000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 6.516000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 6.354, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 6.335999999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 6.1739999999999995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 6.156, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 5.994000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 5.976000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 5.814, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 5.796, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 5.634, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 5.616, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 5.454, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 5.436, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 5.274, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 5.256, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 5.094, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 5.0760000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 4.914000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 4.896, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 4.733999999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 4.715999999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 4.554, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 4.5360000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 4.3740000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 4.356, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 4.194, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 4.176, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 4.013999999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 3.996, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 3.8340000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 3.8160000000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 3.654, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 3.636, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 3.474, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 3.456, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 3.294, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 3.2760000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 3.1140000000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 3.096, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 2.9339999999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 2.916, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 2.7540000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 2.736, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 2.574, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 2.556, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 2.394, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 2.376, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 2.214, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 2.196, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 2.034, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 2.016, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 1.854, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 1.836, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 1.6740000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 1.6560000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 1.494, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 1.476, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 1.3139999999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 1.2959999999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 1.134, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 1.1159999999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 0.954, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 0.9359999999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 0.774, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 0.756, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 0.594, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 0.576, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 0.41400000000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 0.396, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 0.234, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 0.21600000000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 0.054000000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}

