
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.4]);

translate([2, 0, 0]) cube([1, 1, 4.2]);

translate([3, 0, 0]) cube([1, 1, 4.1]);

translate([4, 0, 0]) cube([1, 1, 4.0]);

translate([5, 0, 0]) cube([1, 1, 3.9203672523069053]);

translate([6, 0, 0]) cube([1, 1, 3.920411336006902]);

translate([7, 0, 0]) cube([1, 1, 4.0]);

translate([8, 0, 0]) cube([1, 1, 4.2]);

translate([9, 0, 0]) cube([1, 1, 4.4]);

translate([10, 0, 0]) cube([1, 1, 4.5]);

translate([11, 0, 0]) cube([1, 1, 4.3]);

translate([12, 0, 0]) cube([1, 1, 4.21]);

translate([13, 0, 0]) cube([1, 1, 4.249999999999999]);

translate([14, 0, 0]) cube([1, 1, 4.469999999999999]);

translate([15, 0, 0]) cube([1, 1, 4.839999999999999]);

translate([16, 0, 0]) cube([1, 1, 4.236269078291785]);

translate([17, 0, 0]) cube([1, 1, 4.256564692460305]);

translate([18, 0, 0]) cube([1, 1, 4.281555842140413]);

translate([19, 0, 0]) cube([1, 1, 4.282755505952371]);

translate([20, 0, 0]) cube([1, 1, 4.549263576388882]);

translate([21, 0, 0]) cube([1, 1, 4.112580857142855]);

translate([22, 0, 0]) cube([1, 1, 3.908579147165719]);

translate([23, 0, 0]) cube([1, 1, 3.9045405730565124]);

translate([24, 0, 0]) cube([1, 1, 3.9045405740679504]);

translate([25, 0, 0]) cube([1, 1, 3.4168107568624504]);

translate([26, 0, 0]) cube([1, 1, 4.3599999999999985]);

translate([27, 0, 0]) cube([1, 1, 4.319999999999999]);

translate([28, 0, 0]) cube([1, 1, 4.4]);

translate([29, 0, 0]) cube([1, 1, 4.6]);

translate([30, 0, 0]) cube([1, 1, 4.7]);

translate([31, 0, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.1]);

translate([2, 1, 0]) cube([1, 1, 4.7]);

translate([3, 1, 0]) cube([1, 1, 4.5]);

translate([4, 1, 0]) cube([1, 1, 4.2]);

translate([5, 1, 0]) cube([1, 1, 4.0]);

translate([6, 1, 0]) cube([1, 1, 3.920411336006902]);

translate([7, 1, 0]) cube([1, 1, 4.0]);

translate([8, 1, 0]) cube([1, 1, 4.1]);

translate([9, 1, 0]) cube([1, 1, 4.2]);

translate([10, 1, 0]) cube([1, 1, 4.2]);

translate([11, 1, 0]) cube([1, 1, 4.173810090481868]);

translate([12, 1, 0]) cube([1, 1, 4.173913169062358]);

translate([13, 1, 0]) cube([1, 1, 4.2199999999999935]);

translate([14, 1, 0]) cube([1, 1, 4.269999999999994]);

translate([15, 1, 0]) cube([1, 1, 4.499999999999996]);

translate([16, 1, 0]) cube([1, 1, 4.2362690785726995]);

translate([17, 1, 0]) cube([1, 1, 4.244757323208698]);

translate([18, 1, 0]) cube([1, 1, 4.919999999999997]);

translate([19, 1, 0]) cube([1, 1, 4.14257514374797]);

translate([20, 1, 0]) cube([1, 1, 4.112580856746199]);

translate([21, 1, 0]) cube([1, 1, 4.819999999999998]);

translate([22, 1, 0]) cube([1, 1, 4.639999999999997]);

translate([23, 1, 0]) cube([1, 1, 4.539999999999997]);

translate([24, 1, 0]) cube([1, 1, 4.329999999999997]);

translate([25, 1, 0]) cube([1, 1, 4.129999999999997]);

translate([26, 1, 0]) cube([1, 1, 3.8999999999999977]);

translate([27, 1, 0]) cube([1, 1, 3.759999999999999]);

translate([28, 1, 0]) cube([1, 1, 3.9099999999999997]);

translate([29, 1, 0]) cube([1, 1, 4.0]);

translate([30, 1, 0]) cube([1, 1, 4.2]);

translate([31, 1, 0]) cube([1, 1, 4.3]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

translate([2, 2, 0]) cube([1, 1, 5.4]);

translate([3, 2, 0]) cube([1, 1, 5.1]);

translate([4, 2, 0]) cube([1, 1, 4.8]);

translate([5, 2, 0]) cube([1, 1, 4.5]);

translate([6, 2, 0]) cube([1, 1, 4.4]);

translate([7, 2, 0]) cube([1, 1, 4.4]);

translate([8, 2, 0]) cube([1, 1, 4.3]);

translate([9, 2, 0]) cube([1, 1, 4.2]);

translate([10, 2, 0]) cube([1, 1, 4.171614710487161]);

translate([11, 2, 0]) cube([1, 1, 4.175534260333425]);

translate([12, 2, 0]) cube([1, 1, 4.173529235791347]);

translate([13, 2, 0]) cube([1, 1, 4.2199999999999935]);

translate([14, 2, 0]) cube([1, 1, 4.2699999999999925]);

translate([15, 2, 0]) cube([1, 1, 4.379999999999992]);

translate([16, 2, 0]) cube([1, 1, 4.147211172303731]);

translate([17, 2, 0]) cube([1, 1, 4.1472111727864425]);

translate([18, 2, 0]) cube([1, 1, 4.142575143448707]);

translate([19, 2, 0]) cube([1, 1, 4.689999999999996]);

translate([20, 2, 0]) cube([1, 1, 4.599999999999996]);

translate([21, 2, 0]) cube([1, 1, 4.489999999999996]);

translate([22, 2, 0]) cube([1, 1, 4.349999999999997]);

translate([23, 2, 0]) cube([1, 1, 4.179999999999996]);

translate([24, 2, 0]) cube([1, 1, 4.169999999999996]);

translate([25, 2, 0]) cube([1, 1, 4.009999999999998]);

translate([26, 2, 0]) cube([1, 1, 3.7099999999999977]);

translate([27, 2, 0]) cube([1, 1, 3.579690845687334]);

translate([28, 2, 0]) cube([1, 1, 3.5793060191680897]);

translate([29, 2, 0]) cube([1, 1, 3.8]);

translate([30, 2, 0]) cube([1, 1, 3.9]);

translate([31, 2, 0]) cube([1, 1, 3.8]);

translate([0, 3, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

translate([4, 3, 0]) cube([1, 1, 5.4]);

translate([5, 3, 0]) cube([1, 1, 5.1]);

translate([6, 3, 0]) cube([1, 1, 5.0]);

translate([7, 3, 0]) cube([1, 1, 4.9]);

translate([8, 3, 0]) cube([1, 1, 4.7]);

translate([9, 3, 0]) cube([1, 1, 4.4]);

translate([10, 3, 0]) cube([1, 1, 4.175095690913721]);

translate([11, 3, 0]) cube([1, 1, 4.17605384378104]);

translate([12, 3, 0]) cube([1, 1, 4.21]);

translate([13, 3, 0]) cube([1, 1, 4.319999999999999]);

translate([14, 3, 0]) cube([1, 1, 4.419999999999997]);

translate([15, 3, 0]) cube([1, 1, 4.519999999999993]);

translate([16, 3, 0]) cube([1, 1, 4.599999999999993]);

translate([17, 3, 0]) cube([1, 1, 4.201407707473686]);

translate([18, 3, 0]) cube([1, 1, 4.158525701636099]);

translate([19, 3, 0]) cube([1, 1, 4.609999999999993]);

translate([20, 3, 0]) cube([1, 1, 4.449999999999995]);

translate([21, 3, 0]) cube([1, 1, 4.329999999999995]);

translate([22, 3, 0]) cube([1, 1, 3.9899999999999958]);

translate([23, 3, 0]) cube([1, 1, 3.8199999999999954]);

translate([24, 3, 0]) cube([1, 1, 3.7699999999999965]);

translate([25, 3, 0]) cube([1, 1, 3.699999999999998]);

translate([26, 3, 0]) cube([1, 1, 3.5794245601070576]);

translate([27, 3, 0]) cube([1, 1, 3.5798703547575457]);

translate([28, 3, 0]) cube([1, 1, 3.5797470177973447]);

translate([29, 3, 0]) cube([1, 1, 3.6]);

translate([30, 3, 0]) cube([1, 1, 3.7]);

translate([31, 3, 0]) cube([1, 1, 3.6]);

translate([0, 4, 0]) cube([1, 1, 7.2]);

translate([1, 4, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.4]);

translate([7, 4, 0]) cube([1, 1, 5.3]);

translate([8, 4, 0]) cube([1, 1, 5.0]);

translate([9, 4, 0]) cube([1, 1, 4.6]);

translate([10, 4, 0]) cube([1, 1, 4.4]);

translate([11, 4, 0]) cube([1, 1, 4.4]);

translate([12, 4, 0]) cube([1, 1, 4.6]);

translate([13, 4, 0]) cube([1, 1, 4.8]);

translate([14, 4, 0]) cube([1, 1, 4.8]);

translate([15, 4, 0]) cube([1, 1, 4.739999999999999]);

translate([16, 4, 0]) cube([1, 1, 4.769999999999999]);

translate([17, 4, 0]) cube([1, 1, 4.20752962417329]);

translate([18, 4, 0]) cube([1, 1, 4.163270858935405]);

translate([19, 4, 0]) cube([1, 1, 4.439999999999992]);

translate([20, 4, 0]) cube([1, 1, 4.339999999999993]);

translate([21, 4, 0]) cube([1, 1, 4.109999999999996]);

translate([22, 4, 0]) cube([1, 1, 3.789999999999996]);

translate([23, 4, 0]) cube([1, 1, 3.659989665112037]);

translate([24, 4, 0]) cube([1, 1, 3.6299937022777864]);

translate([25, 4, 0]) cube([1, 1, 3.5793724652848784]);

translate([26, 4, 0]) cube([1, 1, 3.580080572717649]);

translate([27, 4, 0]) cube([1, 1, 3.5801965972817023]);

translate([28, 4, 0]) cube([1, 1, 3.5804562051823545]);

translate([29, 4, 0]) cube([1, 1, 3.580086885014498]);

translate([30, 4, 0]) cube([1, 1, 3.6]);

translate([31, 4, 0]) cube([1, 1, 3.5004294139500622]);

translate([0, 5, 0]) cube([1, 1, 7.4]);

translate([1, 5, 0]) cube([1, 1, 6.9]);

translate([2, 5, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

translate([8, 5, 0]) cube([1, 1, 5.3]);

translate([9, 5, 0]) cube([1, 1, 4.9]);

translate([10, 5, 0]) cube([1, 1, 4.7]);

translate([11, 5, 0]) cube([1, 1, 4.9]);

translate([12, 5, 0]) cube([1, 1, 5.1]);

translate([13, 5, 0]) cube([1, 1, 5.3]);

translate([14, 5, 0]) cube([1, 1, 5.3]);

translate([15, 5, 0]) cube([1, 1, 5.1]);

translate([16, 5, 0]) cube([1, 1, 5.1]);

translate([17, 5, 0]) cube([1, 1, 4.170491719576713]);

translate([18, 5, 0]) cube([1, 1, 4.1586474670944495]);

translate([19, 5, 0]) cube([1, 1, 4.319999999999993]);

translate([20, 5, 0]) cube([1, 1, 4.149999999999992]);

translate([21, 5, 0]) cube([1, 1, 3.9299999999999953]);

translate([22, 5, 0]) cube([1, 1, 3.739999999999995]);

translate([23, 5, 0]) cube([1, 1, 3.6798824562495747]);

translate([24, 5, 0]) cube([1, 1, 3.659882457041164]);

translate([25, 5, 0]) cube([1, 1, 3.6103860679529394]);

translate([26, 5, 0]) cube([1, 1, 3.580155056803959]);

translate([27, 5, 0]) cube([1, 1, 3.579877706763837]);

translate([28, 5, 0]) cube([1, 1, 3.5801819619750024]);

translate([29, 5, 0]) cube([1, 1, 3.5798425393216307]);

translate([30, 5, 0]) cube([1, 1, 3.6]);

translate([31, 5, 0]) cube([1, 1, 3.6]);

translate([0, 6, 0]) cube([1, 1, 7.7]);

translate([1, 6, 0]) cube([1, 1, 7.2]);

translate([2, 6, 0]) cube([1, 1, 7.0]);

translate([3, 6, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([4, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.2]);

translate([10, 6, 0]) cube([1, 1, 5.1]);

translate([11, 6, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([16, 6, 0]) cube([1, 1, 5.3]);

translate([17, 6, 0]) cube([1, 1, 4.142628875661372]);

translate([18, 6, 0]) cube([1, 1, 3.7679682877517444]);

translate([19, 6, 0]) cube([1, 1, 3.4495251456253397]);

translate([20, 6, 0]) cube([1, 1, 4.009999999999994]);

translate([21, 6, 0]) cube([1, 1, 3.900322412777215]);

translate([22, 6, 0]) cube([1, 1, 3.7916321213167477]);

translate([23, 6, 0]) cube([1, 1, 3.669885991688834]);

translate([24, 6, 0]) cube([1, 1, 3.6299999999999994]);

translate([25, 6, 0]) cube([1, 1, 3.7]);

translate([26, 6, 0]) cube([1, 1, 3.8]);

translate([27, 6, 0]) cube([1, 1, 3.9]);

translate([28, 6, 0]) cube([1, 1, 3.8]);

translate([29, 6, 0]) cube([1, 1, 3.8]);

translate([30, 6, 0]) cube([1, 1, 3.8]);

translate([31, 6, 0]) cube([1, 1, 3.7]);

translate([0, 7, 0]) cube([1, 1, 8.0]);

translate([1, 7, 0]) cube([1, 1, 7.5]);

translate([2, 7, 0]) cube([1, 1, 7.3]);

translate([3, 7, 0]) cube([1, 1, 7.0]);

translate([4, 7, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([5, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([16, 7, 0]) cube([1, 1, 5.4]);

translate([17, 7, 0]) cube([1, 1, 4.91]);

translate([18, 7, 0]) cube([1, 1, 4.649999999999999]);

translate([19, 7, 0]) cube([1, 1, 4.299999999999998]);

translate([20, 7, 0]) cube([1, 1, 3.979999999999996]);

translate([21, 7, 0]) cube([1, 1, 3.899999999999996]);

translate([22, 7, 0]) cube([1, 1, 3.8699999999999983]);

translate([23, 7, 0]) cube([1, 1, 4.0]);

translate([24, 7, 0]) cube([1, 1, 4.0]);

translate([25, 7, 0]) cube([1, 1, 4.1]);

translate([26, 7, 0]) cube([1, 1, 4.3]);

translate([27, 7, 0]) cube([1, 1, 4.4]);

translate([28, 7, 0]) cube([1, 1, 4.3]);

translate([29, 7, 0]) cube([1, 1, 4.2]);

translate([30, 7, 0]) cube([1, 1, 4.1]);

translate([31, 7, 0]) cube([1, 1, 4.0]);

translate([0, 8, 0]) cube([1, 1, 7.9]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 7.3]);

translate([3, 8, 0]) cube([1, 1, 7.0]);

translate([4, 8, 0]) cube([1, 1, 6.8]);

translate([5, 8, 0]) cube([1, 1, 6.6]);

translate([6, 8, 0]) cube([1, 1, 6.529999999999999]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([16, 8, 0]) cube([1, 1, 5.4]);

translate([17, 8, 0]) cube([1, 1, 5.01]);

translate([18, 8, 0]) cube([1, 1, 4.72]);

translate([19, 8, 0]) cube([1, 1, 4.4399999999999995]);

translate([20, 8, 0]) cube([1, 1, 4.159999999999998]);

translate([21, 8, 0]) cube([1, 1, 4.02]);

translate([22, 8, 0]) cube([1, 1, 4.2]);

translate([23, 8, 0]) cube([1, 1, 4.5]);

translate([24, 8, 0]) cube([1, 1, 4.6]);

translate([25, 8, 0]) cube([1, 1, 4.6]);

translate([26, 8, 0]) cube([1, 1, 4.6]);

translate([27, 8, 0]) cube([1, 1, 4.7]);

translate([28, 8, 0]) cube([1, 1, 4.6]);

translate([29, 8, 0]) cube([1, 1, 4.5]);

translate([30, 8, 0]) cube([1, 1, 4.5]);

translate([31, 8, 0]) cube([1, 1, 4.4]);

translate([0, 9, 0]) cube([1, 1, 7.9]);

translate([1, 9, 0]) cube([1, 1, 7.4]);

translate([2, 9, 0]) cube([1, 1, 7.1]);

translate([3, 9, 0]) cube([1, 1, 6.9]);

translate([4, 9, 0]) cube([1, 1, 6.619999999999999]);

translate([5, 9, 0]) cube([1, 1, 6.549999999999999]);

translate([6, 9, 0]) cube([1, 1, 6.619999999999999]);

translate([7, 9, 0]) cube([1, 1, 6.71]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 5.1]);

translate([18, 9, 0]) cube([1, 1, 4.9]);

translate([19, 9, 0]) cube([1, 1, 4.71]);

translate([20, 9, 0]) cube([1, 1, 4.5]);

translate([21, 9, 0]) cube([1, 1, 4.4]);

translate([22, 9, 0]) cube([1, 1, 4.7]);

translate([23, 9, 0]) cube([1, 1, 5.0]);

translate([24, 9, 0]) cube([1, 1, 5.1]);

translate([25, 9, 0]) cube([1, 1, 5.1]);

translate([26, 9, 0]) cube([1, 1, 5.0]);

translate([27, 9, 0]) cube([1, 1, 4.9]);

translate([28, 9, 0]) cube([1, 1, 4.8]);

translate([29, 9, 0]) cube([1, 1, 4.8]);

translate([30, 9, 0]) cube([1, 1, 4.9]);

translate([31, 9, 0]) cube([1, 1, 4.9]);

translate([0, 10, 0]) cube([1, 1, 8.0]);

translate([1, 10, 0]) cube([1, 1, 7.5]);

translate([2, 10, 0]) cube([1, 1, 7.1]);

translate([3, 10, 0]) cube([1, 1, 6.71]);

translate([4, 10, 0]) cube([1, 1, 6.639999999999999]);

translate([5, 10, 0]) cube([1, 1, 6.629999999999999]);

translate([6, 10, 0]) cube([1, 1, 6.819999999999999]);

translate([7, 10, 0]) cube([1, 1, 6.92]);

translate([8, 10, 0]) cube([1, 1, 6.7299999999999995]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 5.1]);

translate([18, 10, 0]) cube([1, 1, 4.9]);

translate([19, 10, 0]) cube([1, 1, 4.8]);

translate([20, 10, 0]) cube([1, 1, 4.7]);

translate([21, 10, 0]) cube([1, 1, 4.7]);

translate([22, 10, 0]) cube([1, 1, 5.1]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 10, 0]) cube([1, 1, 6]);

translate([26, 10, 0]) cube([1, 1, 5.4]);

translate([27, 10, 0]) cube([1, 1, 5.2]);

translate([28, 10, 0]) cube([1, 1, 5.1]);

translate([29, 10, 0]) cube([1, 1, 5.1]);

translate([30, 10, 0]) cube([1, 1, 5.3]);

translate([31, 10, 0]) cube([1, 1, 5.4]);

translate([0, 11, 0]) cube([1, 1, 8.2]);

translate([1, 11, 0]) cube([1, 1, 7.7]);

translate([2, 11, 0]) cube([1, 1, 7.2]);

translate([3, 11, 0]) cube([1, 1, 6.91]);

translate([4, 11, 0]) cube([1, 1, 6.93]);

translate([5, 11, 0]) cube([1, 1, 7.039999999999999]);

translate([6, 11, 0]) cube([1, 1, 7.239999999999999]);

translate([7, 11, 0]) cube([1, 1, 7.149999999999999]);

translate([8, 11, 0]) cube([1, 1, 6.739999999999999]);

translate([9, 11, 0]) cube([1, 1, 6.549999999999999]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

translate([17, 11, 0]) cube([1, 1, 5.1]);

translate([18, 11, 0]) cube([1, 1, 5.0]);

translate([19, 11, 0]) cube([1, 1, 4.9]);

translate([20, 11, 0]) cube([1, 1, 4.8]);

translate([21, 11, 0]) cube([1, 1, 4.8]);

translate([22, 11, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 8.2]);

translate([1, 12, 0]) cube([1, 1, 7.7]);

translate([2, 12, 0]) cube([1, 1, 7.3]);

translate([3, 12, 0]) cube([1, 1, 7.2]);

translate([4, 12, 0]) cube([1, 1, 7.319999999999999]);

translate([5, 12, 0]) cube([1, 1, 7.42]);

translate([6, 12, 0]) cube([1, 1, 6.876957266077724]);

translate([7, 12, 0]) cube([1, 1, 7.259999999999999]);

translate([8, 12, 0]) cube([1, 1, 6.979999999999999]);

translate([9, 12, 0]) cube([1, 1, 6.659999999999998]);

translate([10, 12, 0]) cube([1, 1, 6.629999999999999]);

translate([11, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

translate([17, 12, 0]) cube([1, 1, 5.3]);

translate([18, 12, 0]) cube([1, 1, 5.1]);

translate([19, 12, 0]) cube([1, 1, 5.0]);

translate([20, 12, 0]) cube([1, 1, 4.9]);

translate([21, 12, 0]) cube([1, 1, 5.0]);

translate([22, 12, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 8.1]);

translate([1, 13, 0]) cube([1, 1, 7.7]);

translate([2, 13, 0]) cube([1, 1, 7.5]);

translate([3, 13, 0]) cube([1, 1, 7.5]);

translate([4, 13, 0]) cube([1, 1, 7.609999999999999]);

translate([5, 13, 0]) cube([1, 1, 7.609999999999999]);

translate([6, 13, 0]) cube([1, 1, 6.896721097129294]);

translate([7, 13, 0]) cube([1, 1, 6.820136593485276]);

translate([8, 13, 0]) cube([1, 1, 7.079999999999998]);

translate([9, 13, 0]) cube([1, 1, 6.849999999999999]);

translate([10, 13, 0]) cube([1, 1, 6.819999999999999]);

translate([11, 13, 0]) cube([1, 1, 6.8]);

translate([12, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

translate([18, 13, 0]) cube([1, 1, 5.4]);

translate([19, 13, 0]) cube([1, 1, 5.3]);

translate([20, 13, 0]) cube([1, 1, 5.2]);

translate([21, 13, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 13, 0]) cube([1, 1, 6]);

translate([27, 13, 0]) cube([1, 1, 6.6]);

translate([28, 13, 0]) cube([1, 1, 6.7]);

translate([29, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([30, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 8.2]);

translate([1, 14, 0]) cube([1, 1, 7.8]);

translate([2, 14, 0]) cube([1, 1, 7.7]);

translate([3, 14, 0]) cube([1, 1, 7.6]);

translate([4, 14, 0]) cube([1, 1, 7.609999999999999]);

translate([5, 14, 0]) cube([1, 1, 7.52]);

translate([6, 14, 0]) cube([1, 1, 7.43]);

translate([7, 14, 0]) cube([1, 1, 6.676057809569024]);

translate([8, 14, 0]) cube([1, 1, 7.079999999999998]);

translate([9, 14, 0]) cube([1, 1, 7.039999999999999]);

translate([10, 14, 0]) cube([1, 1, 7.0]);

translate([11, 14, 0]) cube([1, 1, 6.8]);

translate([12, 14, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 14, 0]) cube([1, 1, 6]);

translate([27, 14, 0]) cube([1, 1, 6.9]);

translate([28, 14, 0]) cube([1, 1, 7.0]);

translate([29, 14, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([30, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 8.1]);

translate([1, 15, 0]) cube([1, 1, 7.8]);

translate([2, 15, 0]) cube([1, 1, 7.7]);

translate([3, 15, 0]) cube([1, 1, 7.5]);

translate([4, 15, 0]) cube([1, 1, 7.31]);

translate([5, 15, 0]) cube([1, 1, 7.109999999999999]);

translate([6, 15, 0]) cube([1, 1, 6.949999999999999]);

translate([7, 15, 0]) cube([1, 1, 6.8599999999999985]);

translate([8, 15, 0]) cube([1, 1, 6.9399999999999995]);

translate([9, 15, 0]) cube([1, 1, 6.93]);

translate([10, 15, 0]) cube([1, 1, 6.9]);

translate([11, 15, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

translate([15, 15, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 15, 0]) cube([1, 1, 6]);

translate([27, 15, 0]) cube([1, 1, 6.8]);

translate([28, 15, 0]) cube([1, 1, 6.9]);

translate([29, 15, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([30, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 15, 0]) cube([1, 1, 6]);

translate([0, 16, 0]) cube([1, 1, 7.7]);

translate([1, 16, 0]) cube([1, 1, 7.4]);

translate([2, 16, 0]) cube([1, 1, 7.3]);

translate([3, 16, 0]) cube([1, 1, 7.2]);

translate([4, 16, 0]) cube([1, 1, 7.0]);

translate([5, 16, 0]) cube([1, 1, 6.72]);

translate([6, 16, 0]) cube([1, 1, 6.539999999999999]);

translate([7, 16, 0]) cube([1, 1, 6.559999999999999]);

translate([8, 16, 0]) cube([1, 1, 6.639999999999999]);

translate([9, 16, 0]) cube([1, 1, 6.71]);

translate([10, 16, 0]) cube([1, 1, 6.8]);

translate([11, 16, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

translate([15, 16, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 16, 0]) cube([1, 1, 6]);

translate([28, 16, 0]) cube([1, 1, 6.7]);

translate([29, 16, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([30, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 16, 0]) cube([1, 1, 6]);

translate([0, 17, 0]) cube([1, 1, 7.1]);

translate([1, 17, 0]) cube([1, 1, 6.9]);

translate([2, 17, 0]) cube([1, 1, 6.9]);

translate([3, 17, 0]) cube([1, 1, 6.9]);

translate([4, 17, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 17, 0]) cube([1, 1, 6]);

translate([11, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

translate([13, 17, 0]) cube([1, 1, 6.6]);

translate([14, 17, 0]) cube([1, 1, 6.6]);

translate([15, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

translate([19, 17, 0]) cube([1, 1, 5.4]);

translate([20, 17, 0]) cube([1, 1, 5.4]);

translate([21, 17, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([22, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 17, 0]) cube([1, 1, 6]);

translate([0, 18, 0]) cube([1, 1, 6.8]);

translate([1, 18, 0]) cube([1, 1, 6.6]);

translate([2, 18, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

translate([12, 18, 0]) cube([1, 1, 6.6]);

translate([13, 18, 0]) cube([1, 1, 6.8]);

translate([14, 18, 0]) cube([1, 1, 6.9]);

translate([15, 18, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

translate([19, 18, 0]) cube([1, 1, 5.4]);

translate([20, 18, 0]) cube([1, 1, 5.200123908589214]);

translate([21, 18, 0]) cube([1, 1, 5.200126456692449]);

translate([22, 18, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([23, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 6.8]);

translate([1, 19, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

translate([7, 19, 0]) cube([1, 1, 5.4]);

translate([8, 19, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([9, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

translate([13, 19, 0]) cube([1, 1, 6.9]);

translate([14, 19, 0]) cube([1, 1, 7.1]);

translate([15, 19, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([16, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);

translate([20, 19, 0]) cube([1, 1, 5.4]);

translate([21, 19, 0]) cube([1, 1, 5.2001361671690916]);

translate([22, 19, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([23, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 19, 0]) cube([1, 1, 6]);

translate([0, 20, 0]) cube([1, 1, 7.0]);

translate([1, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([2, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

translate([6, 20, 0]) cube([1, 1, 5.4]);

translate([7, 20, 0]) cube([1, 1, 5.320000000076855]);

translate([8, 20, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([9, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

translate([13, 20, 0]) cube([1, 1, 6.8]);

translate([14, 20, 0]) cube([1, 1, 7.0]);

translate([15, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

translate([21, 20, 0]) cube([1, 1, 5.3]);

translate([22, 20, 0]) cube([1, 1, 5.3]);

translate([23, 20, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([24, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 20, 0]) cube([1, 1, 6]);

translate([31, 20, 0]) cube([1, 1, 5.3]);

translate([0, 21, 0]) cube([1, 1, 7.1]);

translate([1, 21, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

translate([4, 21, 0]) cube([1, 1, 5.4]);

translate([5, 21, 0]) cube([1, 1, 5.3]);

translate([6, 21, 0]) cube([1, 1, 5.319999999999999]);

translate([7, 21, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([8, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

translate([13, 21, 0]) cube([1, 1, 6.7]);

translate([14, 21, 0]) cube([1, 1, 6.9]);

translate([15, 21, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

translate([22, 21, 0]) cube([1, 1, 5.300000002997545]);

translate([23, 21, 0]) cube([1, 1, 5.300000018204154]);

translate([24, 21, 0]) cube([1, 1, 5.300000068861609]);

translate([25, 21, 0]) cube([1, 1, 5.300000223020955]);

color([0,1,0])
translate([26, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 21, 0]) cube([1, 1, 6]);

translate([30, 21, 0]) cube([1, 1, 5.4]);

translate([31, 21, 0]) cube([1, 1, 5.1]);

translate([0, 22, 0]) cube([1, 1, 7.1]);

translate([1, 22, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

translate([4, 22, 0]) cube([1, 1, 5.2582216855631705]);

translate([5, 22, 0]) cube([1, 1, 5.262306665970698]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

translate([13, 22, 0]) cube([1, 1, 6.7]);

translate([14, 22, 0]) cube([1, 1, 6.8]);

translate([15, 22, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

translate([24, 22, 0]) cube([1, 1, 5.4]);

translate([25, 22, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([26, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 22, 0]) cube([1, 1, 6]);

translate([30, 22, 0]) cube([1, 1, 5.2]);

translate([31, 22, 0]) cube([1, 1, 4.9]);

translate([0, 23, 0]) cube([1, 1, 6.9]);

translate([1, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 23, 0]) cube([1, 1, 6]);

translate([4, 23, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([5, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 23, 0]) cube([1, 1, 6]);

translate([12, 23, 0]) cube([1, 1, 6.7]);

translate([13, 23, 0]) cube([1, 1, 6.9]);

translate([14, 23, 0]) cube([1, 1, 7.0]);

translate([15, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([16, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 23, 0]) cube([1, 1, 6]);

translate([29, 23, 0]) cube([1, 1, 5.3]);

translate([30, 23, 0]) cube([1, 1, 5.0]);

translate([31, 23, 0]) cube([1, 1, 4.8]);

translate([0, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 24, 0]) cube([1, 1, 6]);

translate([11, 24, 0]) cube([1, 1, 6.7]);

translate([12, 24, 0]) cube([1, 1, 7.0]);

translate([13, 24, 0]) cube([1, 1, 7.1]);

translate([14, 24, 0]) cube([1, 1, 7.1]);

translate([15, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 24, 0]) cube([1, 1, 6]);

translate([27, 24, 0]) cube([1, 1, 5.4]);

translate([28, 24, 0]) cube([1, 1, 5.3]);

translate([29, 24, 0]) cube([1, 1, 5.0]);

translate([30, 24, 0]) cube([1, 1, 4.8]);

translate([31, 24, 0]) cube([1, 1, 4.6]);

color([0,1,0])
translate([0, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 25, 0]) cube([1, 1, 6]);

translate([11, 25, 0]) cube([1, 1, 6.9]);

translate([12, 25, 0]) cube([1, 1, 7.2]);

translate([13, 25, 0]) cube([1, 1, 7.2]);

translate([14, 25, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([15, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 25, 0]) cube([1, 1, 6]);

translate([25, 25, 0]) cube([1, 1, 5.4]);

translate([26, 25, 0]) cube([1, 1, 5.4]);

translate([27, 25, 0]) cube([1, 1, 5.4]);

translate([28, 25, 0]) cube([1, 1, 5.2]);

translate([29, 25, 0]) cube([1, 1, 5.0]);

translate([30, 25, 0]) cube([1, 1, 4.7]);

translate([31, 25, 0]) cube([1, 1, 4.5]);

color([0,1,0])
translate([0, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 26, 0]) cube([1, 1, 6]);

translate([10, 26, 0]) cube([1, 1, 6.7]);

translate([11, 26, 0]) cube([1, 1, 6.9]);

translate([12, 26, 0]) cube([1, 1, 7.0]);

translate([13, 26, 0]) cube([1, 1, 6.9]);

translate([14, 26, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([15, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 26, 0]) cube([1, 1, 6]);

translate([25, 26, 0]) cube([1, 1, 5.4]);

translate([26, 26, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([27, 26, 0]) cube([1, 1, 6]);

translate([28, 26, 0]) cube([1, 1, 5.4]);

translate([29, 26, 0]) cube([1, 1, 5.3]);

translate([30, 26, 0]) cube([1, 1, 5.0]);

translate([31, 26, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 27, 0]) cube([1, 1, 6]);

translate([9, 27, 0]) cube([1, 1, 6.6]);

translate([10, 27, 0]) cube([1, 1, 6.7]);

translate([11, 27, 0]) cube([1, 1, 6.7]);

translate([12, 27, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([13, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 27, 0]) cube([1, 1, 6]);

translate([31, 27, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([0, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 28, 0]) cube([1, 1, 6]);

translate([27, 28, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 29, 0]) cube([1, 1, 6]);

translate([26, 29, 0]) cube([1, 1, 5.4]);

translate([27, 29, 0]) cube([1, 1, 5.3]);

translate([28, 29, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([29, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 30, 0]) cube([1, 1, 6]);

translate([1, 30, 0]) cube([1, 1, 5.4]);

translate([2, 30, 0]) cube([1, 1, 5.4]);

translate([3, 30, 0]) cube([1, 1, 5.4]);

translate([4, 30, 0]) cube([1, 1, 5.3]);

translate([5, 30, 0]) cube([1, 1, 5.2]);

translate([6, 30, 0]) cube([1, 1, 5.1]);

translate([7, 30, 0]) cube([1, 1, 5.3]);

translate([8, 30, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([9, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 30, 0]) cube([1, 1, 6]);

translate([11, 30, 0]) cube([1, 1, 5.3]);

translate([12, 30, 0]) cube([1, 1, 5.2]);

translate([13, 30, 0]) cube([1, 1, 5.3]);

translate([14, 30, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([15, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 30, 0]) cube([1, 1, 6]);

translate([22, 30, 0]) cube([1, 1, 5.3]);

translate([23, 30, 0]) cube([1, 1, 5.3]);

translate([24, 30, 0]) cube([1, 1, 5.4]);

translate([25, 30, 0]) cube([1, 1, 5.4]);

translate([26, 30, 0]) cube([1, 1, 5.3]);

translate([27, 30, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([28, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 30, 0]) cube([1, 1, 6]);

translate([0, 31, 0]) cube([1, 1, 5.3]);

translate([1, 31, 0]) cube([1, 1, 5.2]);

translate([2, 31, 0]) cube([1, 1, 5.2]);

translate([3, 31, 0]) cube([1, 1, 5.3]);

translate([4, 31, 0]) cube([1, 1, 5.2]);

translate([5, 31, 0]) cube([1, 1, 5.0]);

translate([6, 31, 0]) cube([1, 1, 4.9000000542624855]);

translate([7, 31, 0]) cube([1, 1, 5.0]);

translate([8, 31, 0]) cube([1, 1, 5.1]);

translate([9, 31, 0]) cube([1, 1, 5.1]);

translate([10, 31, 0]) cube([1, 1, 5.0]);

translate([11, 31, 0]) cube([1, 1, 4.8]);

translate([12, 31, 0]) cube([1, 1, 4.7]);

translate([13, 31, 0]) cube([1, 1, 4.8]);

translate([14, 31, 0]) cube([1, 1, 5.1]);

translate([15, 31, 0]) cube([1, 1, 5.3]);

translate([16, 31, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([17, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 31, 0]) cube([1, 1, 6]);

translate([22, 31, 0]) cube([1, 1, 5.2]);

translate([23, 31, 0]) cube([1, 1, 5.1]);

translate([24, 31, 0]) cube([1, 1, 5.2]);

translate([25, 31, 0]) cube([1, 1, 5.2]);

translate([26, 31, 0]) cube([1, 1, 5.3]);

translate([27, 31, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 31, 0]) cube([1, 1, 6]);
