color("Yellow") translate([0, 0, 0]) // {'digit': 8, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1.2]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2.4]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 3.5999999999999996]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 4.8]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 6.0]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 7.2]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 7, 'orientation': 'rotate90Y'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 13.4]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 14.6]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 3, 'orientation': 'rotate90Y'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 20.799999999999997]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 21.999999999999996]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 23.199999999999996]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 24.399999999999995]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 25.599999999999994]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 7, 'orientation': 'rotate90Y'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 31.799999999999994]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 3, 'orientation': 'rotate90Y'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 37.99999999999999]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 39.199999999999996]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 40.4]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 41.6]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 42.800000000000004]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 7, 'orientation': 'rotate90Y'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 49.00000000000001]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 50.20000000000001]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 3, 'orientation': 'rotate90Y'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 56.40000000000001]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 57.600000000000016]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 58.80000000000002]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 60.00000000000002]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 61.200000000000024]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 7, 'orientation': 'rotate90Y'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 67.40000000000003]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 68.60000000000004]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 69.80000000000004]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 71.00000000000004]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 72.20000000000005]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 3, 'orientation': 'rotate90Y'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 78.40000000000005]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 7, 'orientation': 'rotate90Y'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 84.60000000000005]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 85.80000000000005]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 87.00000000000006]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 88.20000000000006]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 89.40000000000006]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 3, 'orientation': 'rotate90Y'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 95.60000000000007]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 96.80000000000007]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 7, 'orientation': 'rotate90Y'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 103.00000000000007]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 104.20000000000007]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 105.40000000000008]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 106.60000000000008]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 107.80000000000008]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 109.00000000000009]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 7, 'orientation': 'rotate90Y'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 115.20000000000009]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 116.40000000000009]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 3, 'orientation': 'rotate90Y'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 122.6000000000001]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 123.8000000000001]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 125.0000000000001]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 126.2000000000001]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 7, 'orientation': 'rotate90Y'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 132.4000000000001]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 133.60000000000008]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 134.80000000000007]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 136.00000000000006]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 137.20000000000005]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 3, 'orientation': 'rotate90Y'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 143.40000000000003]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 144.60000000000002]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 7, 'orientation': 'rotate90Y'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 150.8]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 152.0]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 153.2]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 154.39999999999998]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 155.59999999999997]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 3, 'orientation': 'rotate90Y'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 161.79999999999995]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 7, 'orientation': 'rotate90Y'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 167.99999999999994]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 169.19999999999993]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 170.39999999999992]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 171.5999999999999]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 172.7999999999999]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}
