color([1, 0, 1]) hull()
{
  translate([5.0, 5.0, 4.95]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.0, 5.0, 4.05]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.0, 5.0, 3.95]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.0, 5.0, 3.0500000000000003]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.0, 5.0, 2.95]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.0, 5.0, 2.05]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.0, 5.0, 1.9500000000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.0, 5.0, 1.05]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.0, 5.0, 0.9500000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.0, 5.0, 0.05]) cube([0.4, 0.4, 0.1], center = true);
}
