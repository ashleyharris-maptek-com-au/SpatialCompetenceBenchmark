color("Yellow") translate([0, 0, 0]) // {'digit': 17, 'orientation': 'flat'}
union()
{
}

color("White") translate([0, 0, 1.2]) // {'digit': 331, 'orientation': 'flat'}
union()
{
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2.4]) // {'digit': 17331, 'orientation': 'flat'}
union()
{
}
