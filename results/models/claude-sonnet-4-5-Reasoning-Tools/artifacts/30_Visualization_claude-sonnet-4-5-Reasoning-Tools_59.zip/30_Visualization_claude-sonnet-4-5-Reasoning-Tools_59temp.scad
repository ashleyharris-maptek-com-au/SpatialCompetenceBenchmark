color("Yellow") translate([0, 0, 0]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1.2]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2.4]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 3.5999999999999996]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 4.8]) // {'digit': 5, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 6.0]) // {'digit': 9, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 7.2]) // {'digit': 2, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 8.4]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 9.6]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 10.799999999999999]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 11.999999999999998]) // {'digit': 9, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 13.199999999999998]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 14.399999999999997]) // {'digit': 5, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 15.599999999999996]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 16.799999999999997]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 17.999999999999996]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 19.199999999999996]) // {'digit': 9, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 20.399999999999995]) // {'digit': 2, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 21.599999999999994]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 22.799999999999994]) // {'digit': 5, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 23.999999999999993]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 25.199999999999992]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 26.39999999999999]) // {'digit': 9, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 27.59999999999999]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 28.79999999999999]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 29.99999999999999]) // {'digit': 5, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 31.19999999999999]) // {'digit': 2, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 32.39999999999999]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 33.599999999999994]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 34.8]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 36.0]) // {'digit': 9, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 37.2]) // {'digit': 5, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 38.400000000000006]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 39.60000000000001]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 40.80000000000001]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 42.000000000000014]) // {'digit': 2, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 43.20000000000002]) // {'digit': 9, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 44.40000000000002]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 45.60000000000002]) // {'digit': 5, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 46.800000000000026]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 48.00000000000003]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 49.20000000000003]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 50.400000000000034]) // {'digit': 9, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 51.60000000000004]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 52.80000000000004]) // {'digit': 5, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 54.00000000000004]) // {'digit': 2, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 55.200000000000045]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 56.40000000000005]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 57.60000000000005]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 58.800000000000054]) // {'digit': 9, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 60.00000000000006]) // {'digit': 5, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 61.20000000000006]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 62.40000000000006]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 63.600000000000065]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 64.80000000000007]) // {'digit': 2, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 66.00000000000007]) // {'digit': 9, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 67.20000000000007]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 68.40000000000008]) // {'digit': 5, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 69.60000000000008]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}
