color("Yellow") translate([0, 0, 0]) rotate([0, 0, 180]) // {'digit': 9, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1.2]) rotate([0, 0, 180]) // {'digit': 9, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2.4]) rotate([0, 0, 180])
  // {'digit': 7, 'orientation': 'rotate180Z'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}
