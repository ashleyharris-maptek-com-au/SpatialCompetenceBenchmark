color("Yellow") translate([0, 0, 0]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1.2]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 3, 'orientation': 'rotate90Y'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 7.4]) // {'digit': 1, 'orientation': 'rotate90Y'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 8.6]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 9.799999999999999]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 10.999999999999998]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 12.199999999999998]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 13.399999999999997]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 14.599999999999996]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 15.799999999999995]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 16.999999999999996]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 18.199999999999996]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 19.399999999999995]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 20.599999999999994]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 21.799999999999994]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 22.999999999999993]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 24.199999999999992]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 25.39999999999999]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 26.59999999999999]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 27.79999999999999]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 28.99999999999999]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 30.19999999999999]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 31.399999999999988]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 32.59999999999999]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 33.79999999999999]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 34.99999999999999]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 36.199999999999996]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 37.4]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 38.6]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 39.800000000000004]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 41.00000000000001]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 42.20000000000001]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 43.40000000000001]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 44.600000000000016]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 45.80000000000002]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 47.00000000000002]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 48.200000000000024]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 49.40000000000003]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 50.60000000000003]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 51.80000000000003]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 53.000000000000036]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 54.20000000000004]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 55.40000000000004]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 56.600000000000044]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 57.80000000000005]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 59.00000000000005]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 60.20000000000005]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 61.400000000000055]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 62.60000000000006]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 63.80000000000006]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 65.00000000000006]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 66.20000000000006]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 67.40000000000006]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 68.60000000000007]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 69.80000000000007]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 71.00000000000007]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 72.20000000000007]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 73.40000000000008]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 74.60000000000008]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 75.80000000000008]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 77.00000000000009]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 78.20000000000009]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 79.40000000000009]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 80.6000000000001]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 81.8000000000001]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 83.0000000000001]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 84.2000000000001]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 85.4000000000001]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 86.60000000000011]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 87.80000000000011]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 89.00000000000011]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 90.20000000000012]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 91.40000000000012]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 92.60000000000012]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 93.80000000000013]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 95.00000000000013]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 96.20000000000013]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 97.40000000000013]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 98.60000000000014]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 99.80000000000014]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 101.00000000000014]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 102.20000000000014]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 103.40000000000015]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 104.60000000000015]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 105.80000000000015]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 107.00000000000016]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 108.20000000000016]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 109.40000000000016]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 110.60000000000016]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 111.80000000000017]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 113.00000000000017]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 114.20000000000017]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 115.40000000000018]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 116.60000000000018]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 117.80000000000018]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 119.00000000000018]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 120.20000000000019]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 121.40000000000019]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 122.6000000000002]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 123.8000000000002]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 125.0000000000002]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 126.2000000000002]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 127.4000000000002]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 128.6000000000002]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 129.80000000000018]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 131.00000000000017]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 132.20000000000016]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 133.40000000000015]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 134.60000000000014]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 135.80000000000013]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 137.0000000000001]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 138.2000000000001]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 139.4000000000001]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 140.60000000000008]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 141.80000000000007]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 143.00000000000006]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 144.20000000000005]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 145.40000000000003]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 146.60000000000002]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 147.8]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 149.0]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 150.2]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 151.39999999999998]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 152.59999999999997]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 153.79999999999995]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 154.99999999999994]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 156.19999999999993]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 157.39999999999992]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 158.5999999999999]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 159.7999999999999]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 160.9999999999999]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 162.19999999999987]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 163.39999999999986]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 164.59999999999985]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 165.79999999999984]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 166.99999999999983]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 168.19999999999982]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 169.3999999999998]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 170.5999999999998]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 171.79999999999978]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 172.99999999999977]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 174.19999999999976]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 175.39999999999975]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 176.59999999999974]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 177.79999999999973]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 178.99999999999972]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 180.1999999999997]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 181.3999999999997]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 182.59999999999968]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 183.79999999999967]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 184.99999999999966]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 186.19999999999965]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 187.39999999999964]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 188.59999999999962]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 189.7999999999996]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 190.9999999999996]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 192.1999999999996]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 193.39999999999958]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 194.59999999999957]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 195.79999999999956]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 196.99999999999955]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 198.19999999999953]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 199.39999999999952]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 200.5999999999995]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 201.7999999999995]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 202.9999999999995]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 204.19999999999948]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 205.39999999999947]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 206.59999999999945]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 207.79999999999944]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 208.99999999999943]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 210.19999999999942]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 211.3999999999994]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 212.5999999999994]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 213.7999999999994]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 214.99999999999937]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 216.19999999999936]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 217.39999999999935]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 218.59999999999934]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 219.79999999999933]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 220.99999999999932]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 222.1999999999993]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 223.3999999999993]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 224.59999999999928]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 225.79999999999927]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 226.99999999999926]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 228.19999999999925]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 229.39999999999924]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 230.59999999999923]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 231.79999999999922]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 232.9999999999992]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 234.1999999999992]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 235.39999999999918]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 236.59999999999917]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 237.79999999999916]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 238.99999999999915]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 240.19999999999914]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 241.39999999999912]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 242.5999999999991]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 243.7999999999991]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 244.9999999999991]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 246.19999999999908]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 247.39999999999907]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 248.59999999999906]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 249.79999999999905]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 250.99999999999903]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 252.19999999999902]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 253.399999999999]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 254.599999999999]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 255.799999999999]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 256.999999999999]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 258.19999999999897]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 259.39999999999895]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 260.59999999999894]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 261.79999999999893]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 262.9999999999989]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 264.1999999999989]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 265.3999999999989]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 266.5999999999989]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 267.7999999999989]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 268.99999999999886]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 270.19999999999885]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 271.39999999999884]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 272.59999999999883]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 273.7999999999988]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 274.9999999999988]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 276.1999999999988]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 277.3999999999988]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 278.5999999999988]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 279.79999999999876]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 280.99999999999875]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 282.19999999999874]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 283.3999999999987]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 284.5999999999987]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 285.7999999999987]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 286.9999999999987]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 288.1999999999987]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 289.39999999999867]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 290.59999999999866]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 291.79999999999865]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 292.99999999999864]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 294.1999999999986]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 295.3999999999986]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 296.5999999999986]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 297.7999999999986]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 298.9999999999986]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 300.19999999999857]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 301.39999999999856]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 302.59999999999854]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 303.79999999999853]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 304.9999999999985]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 306.1999999999985]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 307.3999999999985]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 308.5999999999985]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 309.7999999999985]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 310.99999999999847]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 312.19999999999845]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 313.39999999999844]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 314.59999999999843]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 315.7999999999984]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 316.9999999999984]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 318.1999999999984]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 319.3999999999984]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 320.5999999999984]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 321.79999999999836]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 322.99999999999835]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 324.19999999999834]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 325.39999999999833]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 326.5999999999983]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 327.7999999999983]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 328.9999999999983]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 330.1999999999983]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 331.3999999999983]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 332.59999999999826]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 333.79999999999825]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 334.99999999999824]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 336.1999999999982]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 337.3999999999982]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 338.5999999999982]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 339.7999999999982]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 340.9999999999982]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 342.19999999999817]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 343.39999999999816]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 344.59999999999815]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 345.79999999999814]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 346.9999999999981]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 348.1999999999981]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 349.3999999999981]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 350.5999999999981]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 351.7999999999981]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 352.99999999999807]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 354.19999999999806]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 355.39999999999804]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 356.59999999999803]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 357.799999999998]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 358.999999999998]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 360.199999999998]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 361.399999999998]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 362.599999999998]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 363.79999999999797]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 364.99999999999795]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 366.19999999999794]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 367.39999999999793]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 368.5999999999979]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 369.7999999999979]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 370.9999999999979]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 372.1999999999979]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 373.3999999999979]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 374.59999999999786]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 375.79999999999785]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 376.99999999999784]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 378.19999999999783]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 379.3999999999978]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 380.5999999999978]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 381.7999999999978]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 382.9999999999978]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 384.1999999999978]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 385.39999999999776]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 386.59999999999775]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 387.79999999999774]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 388.9999999999977]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 390.1999999999977]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 391.3999999999977]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 392.5999999999977]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 393.7999999999977]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 394.99999999999767]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 396.19999999999766]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 397.39999999999765]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 398.59999999999764]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 399.7999999999976]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 400.9999999999976]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 402.1999999999976]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 403.3999999999976]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 404.5999999999976]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 405.79999999999757]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 406.99999999999756]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 408.19999999999754]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 409.39999999999753]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 410.5999999999975]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 411.7999999999975]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 412.9999999999975]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 414.1999999999975]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 415.3999999999975]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 416.59999999999746]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 417.79999999999745]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 418.99999999999744]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 420.19999999999743]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 421.3999999999974]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 422.5999999999974]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 423.7999999999974]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 424.9999999999974]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 426.1999999999974]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 427.39999999999736]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 428.59999999999735]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 429.79999999999734]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 430.9999999999973]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 432.1999999999973]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 433.3999999999973]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 434.5999999999973]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 435.7999999999973]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 436.99999999999727]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 438.19999999999726]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 439.39999999999725]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 440.59999999999724]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 441.7999999999972]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 442.9999999999972]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 444.1999999999972]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 445.3999999999972]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 446.5999999999972]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 447.79999999999717]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 448.99999999999716]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 450.19999999999715]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 451.39999999999714]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 452.5999999999971]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 453.7999999999971]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 454.9999999999971]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 456.1999999999971]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 457.3999999999971]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 458.59999999999707]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 459.79999999999706]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 460.99999999999704]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 462.19999999999703]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 463.399999999997]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 464.599999999997]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 465.799999999997]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 466.999999999997]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 468.199999999997]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 469.39999999999696]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 470.59999999999695]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 471.79999999999694]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 472.99999999999693]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 474.1999999999969]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 475.3999999999969]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 476.5999999999969]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 477.7999999999969]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 478.9999999999969]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 480.19999999999686]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 481.39999999999685]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 482.59999999999684]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 483.7999999999968]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 484.9999999999968]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 486.1999999999968]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 487.3999999999968]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 488.5999999999968]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 489.79999999999677]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 490.99999999999676]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 492.19999999999675]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 493.39999999999674]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 494.5999999999967]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 495.7999999999967]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 496.9999999999967]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 498.1999999999967]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 499.3999999999967]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 500.59999999999667]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 501.79999999999666]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 502.99999999999665]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 504.19999999999663]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 505.3999999999966]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 506.5999999999966]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 507.7999999999966]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 508.9999999999966]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 510.1999999999966]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 511.39999999999657]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 512.5999999999966]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 513.7999999999967]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 514.9999999999967]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 516.1999999999967]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 517.3999999999968]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 518.5999999999968]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 519.7999999999969]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 520.9999999999969]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 522.199999999997]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 523.399999999997]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 524.5999999999971]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 525.7999999999971]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 526.9999999999972]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 528.1999999999972]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 529.3999999999972]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 530.5999999999973]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 531.7999999999973]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 532.9999999999974]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 534.1999999999974]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 535.3999999999975]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 536.5999999999975]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 537.7999999999976]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 538.9999999999976]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 540.1999999999977]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 541.3999999999977]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 542.5999999999977]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 543.7999999999978]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 544.9999999999978]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 546.1999999999979]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 547.3999999999979]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 548.599999999998]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 549.799999999998]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 550.9999999999981]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 552.1999999999981]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 553.3999999999982]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 554.5999999999982]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 555.7999999999982]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 556.9999999999983]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 558.1999999999983]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 559.3999999999984]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 560.5999999999984]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 561.7999999999985]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 562.9999999999985]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 564.1999999999986]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 565.3999999999986]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 566.5999999999987]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 567.7999999999987]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 568.9999999999987]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 570.1999999999988]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 571.3999999999988]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 572.5999999999989]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 573.7999999999989]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 574.999999999999]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 576.199999999999]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 577.3999999999991]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 578.5999999999991]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 579.7999999999992]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 580.9999999999992]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 582.1999999999992]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 583.3999999999993]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 584.5999999999993]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 585.7999999999994]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 586.9999999999994]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 588.1999999999995]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 589.3999999999995]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 590.5999999999996]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 591.7999999999996]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 592.9999999999997]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 594.1999999999997]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 595.3999999999997]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 596.5999999999998]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 597.7999999999998]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 598.9999999999999]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 600.1999999999999]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 601.4]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 602.6]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 603.8000000000001]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 605.0000000000001]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 606.2000000000002]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 607.4000000000002]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 608.6000000000003]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 609.8000000000003]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 611.0000000000003]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 612.2000000000004]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 613.4000000000004]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 614.6000000000005]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 615.8000000000005]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 617.0000000000006]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 618.2000000000006]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 619.4000000000007]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 620.6000000000007]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 621.8000000000008]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 623.0000000000008]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 624.2000000000008]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 625.4000000000009]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 626.6000000000009]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 627.800000000001]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 629.000000000001]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 630.2000000000011]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 631.4000000000011]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 632.6000000000012]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 633.8000000000012]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 635.0000000000013]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 636.2000000000013]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 637.4000000000013]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 638.6000000000014]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 639.8000000000014]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 641.0000000000015]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 642.2000000000015]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 643.4000000000016]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 644.6000000000016]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 645.8000000000017]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 647.0000000000017]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 648.2000000000018]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 649.4000000000018]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 650.6000000000018]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 651.8000000000019]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 653.0000000000019]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 654.200000000002]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 655.400000000002]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 656.6000000000021]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 657.8000000000021]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 659.0000000000022]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 660.2000000000022]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 661.4000000000023]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 662.6000000000023]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 663.8000000000023]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 665.0000000000024]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 666.2000000000024]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 667.4000000000025]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 668.6000000000025]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 669.8000000000026]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 671.0000000000026]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 672.2000000000027]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 673.4000000000027]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 674.6000000000028]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 675.8000000000028]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 677.0000000000028]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 678.2000000000029]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 679.4000000000029]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 680.600000000003]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 681.800000000003]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 683.0000000000031]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 684.2000000000031]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 685.4000000000032]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 686.6000000000032]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 687.8000000000033]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 689.0000000000033]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 690.2000000000033]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 691.4000000000034]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 692.6000000000034]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 693.8000000000035]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 695.0000000000035]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 696.2000000000036]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 697.4000000000036]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 698.6000000000037]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 699.8000000000037]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 701.0000000000038]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 702.2000000000038]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 703.4000000000038]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 704.6000000000039]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 705.8000000000039]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 707.000000000004]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 708.200000000004]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 709.4000000000041]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 710.6000000000041]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 711.8000000000042]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 713.0000000000042]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 714.2000000000043]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 715.4000000000043]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 716.6000000000043]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 717.8000000000044]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 719.0000000000044]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 720.2000000000045]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 721.4000000000045]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 722.6000000000046]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 723.8000000000046]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 725.0000000000047]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 726.2000000000047]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 727.4000000000048]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 728.6000000000048]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 729.8000000000048]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 731.0000000000049]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 732.2000000000049]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 733.400000000005]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 734.600000000005]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 735.8000000000051]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 737.0000000000051]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 738.2000000000052]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 739.4000000000052]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 740.6000000000053]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 741.8000000000053]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 743.0000000000053]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 744.2000000000054]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 745.4000000000054]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 746.6000000000055]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 747.8000000000055]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 749.0000000000056]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 750.2000000000056]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 751.4000000000057]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 752.6000000000057]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 753.8000000000058]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 755.0000000000058]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 756.2000000000058]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 757.4000000000059]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 758.6000000000059]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 759.800000000006]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 761.000000000006]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 762.2000000000061]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 763.4000000000061]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 764.6000000000062]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 765.8000000000062]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 767.0000000000063]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 768.2000000000063]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 769.4000000000063]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 770.6000000000064]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 771.8000000000064]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 773.0000000000065]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 774.2000000000065]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 775.4000000000066]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 776.6000000000066]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 777.8000000000067]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 779.0000000000067]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 780.2000000000068]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 781.4000000000068]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 782.6000000000068]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 783.8000000000069]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 785.0000000000069]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 786.200000000007]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 787.400000000007]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 788.6000000000071]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 789.8000000000071]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 791.0000000000072]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 792.2000000000072]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 793.4000000000073]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 794.6000000000073]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 795.8000000000073]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 797.0000000000074]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 798.2000000000074]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 799.4000000000075]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 800.6000000000075]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 801.8000000000076]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 803.0000000000076]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 804.2000000000077]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 805.4000000000077]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 806.6000000000078]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 807.8000000000078]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 809.0000000000078]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 810.2000000000079]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 811.4000000000079]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 812.600000000008]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 813.800000000008]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 815.0000000000081]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 816.2000000000081]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 817.4000000000082]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 818.6000000000082]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 819.8000000000083]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 821.0000000000083]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 822.2000000000083]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 823.4000000000084]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 824.6000000000084]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 825.8000000000085]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 827.0000000000085]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 828.2000000000086]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 829.4000000000086]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 830.6000000000087]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 831.8000000000087]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 833.0000000000088]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 834.2000000000088]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 835.4000000000088]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 836.6000000000089]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 837.8000000000089]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 839.000000000009]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 840.200000000009]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 841.4000000000091]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 842.6000000000091]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 843.8000000000092]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 845.0000000000092]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 846.2000000000093]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 847.4000000000093]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 848.6000000000093]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 849.8000000000094]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 851.0000000000094]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 852.2000000000095]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 853.4000000000095]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 854.6000000000096]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 855.8000000000096]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 857.0000000000097]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 858.2000000000097]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 859.4000000000098]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 860.6000000000098]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 861.8000000000098]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 863.0000000000099]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 864.2000000000099]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 865.40000000001]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 866.60000000001]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 867.8000000000101]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 869.0000000000101]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 870.2000000000102]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 871.4000000000102]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 872.6000000000103]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 873.8000000000103]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 875.0000000000103]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 876.2000000000104]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 877.4000000000104]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 878.6000000000105]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 879.8000000000105]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 881.0000000000106]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 882.2000000000106]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 883.4000000000107]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 884.6000000000107]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 885.8000000000108]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 887.0000000000108]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 888.2000000000108]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 889.4000000000109]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 890.6000000000109]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 891.800000000011]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 893.000000000011]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 894.2000000000111]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 895.4000000000111]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 896.6000000000112]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 897.8000000000112]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 899.0000000000113]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 900.2000000000113]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 901.4000000000113]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 902.6000000000114]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 903.8000000000114]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 905.0000000000115]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 906.2000000000115]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 907.4000000000116]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 908.6000000000116]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 909.8000000000117]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 911.0000000000117]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 912.2000000000118]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 913.4000000000118]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 914.6000000000118]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 915.8000000000119]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 917.0000000000119]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 918.200000000012]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 919.400000000012]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 920.6000000000121]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 921.8000000000121]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 923.0000000000122]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 924.2000000000122]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 925.4000000000123]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 926.6000000000123]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 927.8000000000123]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 929.0000000000124]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 930.2000000000124]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 931.4000000000125]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 932.6000000000125]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 933.8000000000126]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 935.0000000000126]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 936.2000000000127]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 937.4000000000127]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 938.6000000000128]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 939.8000000000128]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 941.0000000000128]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 942.2000000000129]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 943.4000000000129]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 944.600000000013]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 945.800000000013]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 947.0000000000131]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 948.2000000000131]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 949.4000000000132]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 950.6000000000132]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 951.8000000000133]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 953.0000000000133]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 954.2000000000133]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 955.4000000000134]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 956.6000000000134]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 957.8000000000135]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 959.0000000000135]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 960.2000000000136]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 961.4000000000136]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 962.6000000000137]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 963.8000000000137]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 965.0000000000138]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 966.2000000000138]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 967.4000000000138]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 968.6000000000139]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 969.8000000000139]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 971.000000000014]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 972.200000000014]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 973.4000000000141]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 974.6000000000141]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 975.8000000000142]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 977.0000000000142]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 978.2000000000143]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 979.4000000000143]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 980.6000000000143]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 981.8000000000144]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 983.0000000000144]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 984.2000000000145]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 985.4000000000145]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 986.6000000000146]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 987.8000000000146]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 989.0000000000147]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 990.2000000000147]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 991.4000000000148]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 992.6000000000148]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 993.8000000000148]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 995.0000000000149]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 996.2000000000149]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 997.400000000015]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 998.600000000015]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 999.8000000000151]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1001.0000000000151]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1002.2000000000152]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1003.4000000000152]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1004.6000000000153]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1005.8000000000153]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1007.0000000000153]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1008.2000000000154]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1009.4000000000154]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1010.6000000000155]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1011.8000000000155]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1013.0000000000156]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1014.2000000000156]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1015.4000000000157]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1016.6000000000157]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1017.8000000000158]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1019.0000000000158]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1020.2000000000158]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1021.4000000000159]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1022.6000000000159]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1023.800000000016]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1025.000000000016]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1026.200000000016]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1027.400000000016]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1028.600000000016]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1029.800000000016]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1031.0000000000161]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1032.2000000000162]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1033.4000000000162]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1034.6000000000163]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1035.8000000000163]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1037.0000000000164]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1038.2000000000164]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1039.4000000000165]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1040.6000000000165]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1041.8000000000166]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1043.0000000000166]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1044.2000000000166]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1045.4000000000167]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1046.6000000000167]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1047.8000000000168]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1049.0000000000168]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1050.2000000000169]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1051.400000000017]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1052.600000000017]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1053.800000000017]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1055.000000000017]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1056.200000000017]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1057.4000000000171]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1058.6000000000172]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1059.8000000000172]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1061.0000000000173]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1062.2000000000173]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1063.4000000000174]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1064.6000000000174]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1065.8000000000175]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1067.0000000000175]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1068.2000000000176]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1069.4000000000176]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1070.6000000000176]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1071.8000000000177]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1073.0000000000177]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1074.2000000000178]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1075.4000000000178]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1076.6000000000179]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1077.800000000018]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1079.000000000018]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1080.200000000018]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1081.400000000018]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1082.600000000018]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1083.8000000000181]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1085.0000000000182]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1086.2000000000182]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1087.4000000000183]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1088.6000000000183]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1089.8000000000184]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1091.0000000000184]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1092.2000000000185]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1093.4000000000185]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1094.6000000000186]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1095.8000000000186]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1097.0000000000186]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1098.2000000000187]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1099.4000000000187]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1100.6000000000188]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1101.8000000000188]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1103.0000000000189]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1104.200000000019]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1105.400000000019]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1106.600000000019]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1107.800000000019]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1109.000000000019]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1110.2000000000191]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1111.4000000000192]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1112.6000000000192]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1113.8000000000193]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1115.0000000000193]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1116.2000000000194]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1117.4000000000194]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1118.6000000000195]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1119.8000000000195]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1121.0000000000196]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1122.2000000000196]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1123.4000000000196]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1124.6000000000197]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1125.8000000000197]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1127.0000000000198]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1128.2000000000198]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1129.4000000000199]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1130.60000000002]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1131.80000000002]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1133.00000000002]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1134.20000000002]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1135.40000000002]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1136.6000000000201]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1137.8000000000202]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1139.0000000000202]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1140.2000000000203]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1141.4000000000203]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1142.6000000000204]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1143.8000000000204]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1145.0000000000205]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1146.2000000000205]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1147.4000000000206]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1148.6000000000206]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1149.8000000000206]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1151.0000000000207]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1152.2000000000207]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1153.4000000000208]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1154.6000000000208]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1155.8000000000209]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1157.000000000021]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1158.200000000021]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1159.400000000021]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1160.600000000021]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1161.800000000021]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1163.0000000000211]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1164.2000000000212]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1165.4000000000212]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1166.6000000000213]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1167.8000000000213]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1169.0000000000214]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1170.2000000000214]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1171.4000000000215]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1172.6000000000215]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1173.8000000000216]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1175.0000000000216]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1176.2000000000216]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1177.4000000000217]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1178.6000000000217]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1179.8000000000218]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1181.0000000000218]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1182.2000000000219]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1183.400000000022]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1184.600000000022]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1185.800000000022]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1187.000000000022]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1188.200000000022]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1189.4000000000221]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1190.6000000000222]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1191.8000000000222]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1193.0000000000223]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1194.2000000000223]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1195.4000000000224]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1196.6000000000224]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1197.8000000000225]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1199.0000000000225]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1200.2000000000226]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1201.4000000000226]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1202.6000000000226]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1203.8000000000227]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1205.0000000000227]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1206.2000000000228]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1207.4000000000228]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1208.6000000000229]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1209.800000000023]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1211.000000000023]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1212.200000000023]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1213.400000000023]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1214.600000000023]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1215.8000000000231]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1217.0000000000232]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1218.2000000000232]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1219.4000000000233]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1220.6000000000233]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1221.8000000000234]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1223.0000000000234]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1224.2000000000235]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1225.4000000000235]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1226.6000000000236]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1227.8000000000236]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1229.0000000000236]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1230.2000000000237]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1231.4000000000237]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1232.6000000000238]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1233.8000000000238]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1235.0000000000239]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1236.200000000024]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1237.400000000024]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1238.600000000024]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1239.800000000024]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1241.000000000024]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1242.2000000000241]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1243.4000000000242]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1244.6000000000242]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1245.8000000000243]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1247.0000000000243]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1248.2000000000244]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1249.4000000000244]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1250.6000000000245]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1251.8000000000245]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1253.0000000000246]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1254.2000000000246]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1255.4000000000246]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1256.6000000000247]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1257.8000000000247]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1259.0000000000248]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1260.2000000000248]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1261.4000000000249]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1262.600000000025]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1263.800000000025]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1265.000000000025]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1266.200000000025]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1267.400000000025]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1268.6000000000251]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1269.8000000000252]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1271.0000000000252]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1272.2000000000253]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1273.4000000000253]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1274.6000000000254]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1275.8000000000254]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1277.0000000000255]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1278.2000000000255]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1279.4000000000256]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1280.6000000000256]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1281.8000000000256]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1283.0000000000257]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1284.2000000000257]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1285.4000000000258]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1286.6000000000258]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1287.8000000000259]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1289.000000000026]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1290.200000000026]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1291.400000000026]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1292.600000000026]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1293.800000000026]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1295.0000000000261]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1296.2000000000262]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1297.4000000000262]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1298.6000000000263]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1299.8000000000263]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1301.0000000000264]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1302.2000000000264]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1303.4000000000265]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1304.6000000000265]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1305.8000000000266]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1307.0000000000266]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1308.2000000000266]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1309.4000000000267]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1310.6000000000267]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1311.8000000000268]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1313.0000000000268]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1314.2000000000269]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1315.400000000027]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1316.600000000027]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1317.800000000027]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1319.000000000027]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1320.200000000027]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1321.4000000000271]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1322.6000000000272]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1323.8000000000272]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1325.0000000000273]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1326.2000000000273]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1327.4000000000274]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1328.6000000000274]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1329.8000000000275]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1331.0000000000275]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1332.2000000000276]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1333.4000000000276]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1334.6000000000276]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1335.8000000000277]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1337.0000000000277]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1338.2000000000278]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1339.4000000000278]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1340.6000000000279]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1341.800000000028]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1343.000000000028]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1344.200000000028]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1345.400000000028]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1346.600000000028]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1347.8000000000281]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1349.0000000000282]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1350.2000000000282]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1351.4000000000283]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1352.6000000000283]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1353.8000000000284]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1355.0000000000284]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1356.2000000000285]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1357.4000000000285]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1358.6000000000286]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1359.8000000000286]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1361.0000000000286]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1362.2000000000287]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1363.4000000000287]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1364.6000000000288]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1365.8000000000288]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1367.0000000000289]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1368.200000000029]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1369.400000000029]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1370.600000000029]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1371.800000000029]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1373.000000000029]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1374.2000000000291]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1375.4000000000292]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1376.6000000000292]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1377.8000000000293]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1379.0000000000293]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1380.2000000000294]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1381.4000000000294]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1382.6000000000295]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1383.8000000000295]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1385.0000000000296]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1386.2000000000296]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1387.4000000000296]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1388.6000000000297]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1389.8000000000297]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1391.0000000000298]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1392.2000000000298]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1393.4000000000299]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1394.60000000003]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1395.80000000003]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1397.00000000003]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1398.20000000003]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1399.40000000003]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1400.6000000000301]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1401.8000000000302]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1403.0000000000302]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1404.2000000000303]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1405.4000000000303]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1406.6000000000304]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1407.8000000000304]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1409.0000000000305]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1410.2000000000305]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1411.4000000000306]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1412.6000000000306]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1413.8000000000306]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1415.0000000000307]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1416.2000000000307]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1417.4000000000308]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1418.6000000000308]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1419.8000000000309]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1421.000000000031]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1422.200000000031]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1423.400000000031]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1424.600000000031]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1425.800000000031]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1427.0000000000312]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1428.2000000000312]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1429.4000000000312]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1430.6000000000313]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1431.8000000000313]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1433.0000000000314]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1434.2000000000314]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1435.4000000000315]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1436.6000000000315]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1437.8000000000316]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1439.0000000000316]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1440.2000000000317]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1441.4000000000317]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1442.6000000000317]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1443.8000000000318]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1445.0000000000318]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1446.2000000000319]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1447.400000000032]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1448.600000000032]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1449.800000000032]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1451.000000000032]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1452.200000000032]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1453.4000000000322]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1454.6000000000322]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1455.8000000000322]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1457.0000000000323]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1458.2000000000323]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1459.4000000000324]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1460.6000000000324]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1461.8000000000325]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1463.0000000000325]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1464.2000000000326]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1465.4000000000326]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1466.6000000000327]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1467.8000000000327]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1469.0000000000327]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1470.2000000000328]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1471.4000000000328]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1472.6000000000329]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1473.800000000033]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1475.000000000033]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1476.200000000033]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1477.400000000033]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1478.600000000033]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1479.8000000000332]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1481.0000000000332]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1482.2000000000332]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1483.4000000000333]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1484.6000000000333]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1485.8000000000334]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1487.0000000000334]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1488.2000000000335]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1489.4000000000335]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1490.6000000000336]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1491.8000000000336]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1493.0000000000337]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1494.2000000000337]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1495.4000000000337]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1496.6000000000338]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1497.8000000000338]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1499.0000000000339]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1500.200000000034]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1501.400000000034]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1502.600000000034]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1503.800000000034]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1505.000000000034]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1506.2000000000342]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1507.4000000000342]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1508.6000000000342]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1509.8000000000343]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1511.0000000000343]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1512.2000000000344]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1513.4000000000344]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1514.6000000000345]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1515.8000000000345]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1517.0000000000346]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1518.2000000000346]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1519.4000000000347]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1520.6000000000347]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1521.8000000000347]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1523.0000000000348]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1524.2000000000348]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1525.4000000000349]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1526.600000000035]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1527.800000000035]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1529.000000000035]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1530.200000000035]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1531.400000000035]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1532.6000000000352]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1533.8000000000352]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1535.0000000000352]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1536.2000000000353]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1537.4000000000353]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1538.6000000000354]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1539.8000000000354]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1541.0000000000355]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1542.2000000000355]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1543.4000000000356]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1544.6000000000356]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1545.8000000000357]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1547.0000000000357]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1548.2000000000357]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1549.4000000000358]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1550.6000000000358]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1551.8000000000359]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1553.000000000036]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1554.200000000036]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1555.400000000036]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1556.600000000036]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1557.800000000036]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1559.0000000000362]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1560.2000000000362]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1561.4000000000362]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1562.6000000000363]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1563.8000000000363]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1565.0000000000364]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1566.2000000000364]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1567.4000000000365]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1568.6000000000365]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1569.8000000000366]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1571.0000000000366]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1572.2000000000367]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1573.4000000000367]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1574.6000000000367]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1575.8000000000368]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1577.0000000000368]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1578.2000000000369]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1579.400000000037]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1580.600000000037]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1581.800000000037]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1583.000000000037]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1584.200000000037]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1585.4000000000372]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1586.6000000000372]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1587.8000000000372]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1589.0000000000373]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1590.2000000000373]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1591.4000000000374]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1592.6000000000374]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1593.8000000000375]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1595.0000000000375]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1596.2000000000376]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1597.4000000000376]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1598.6000000000377]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1599.8000000000377]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1601.0000000000377]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1602.2000000000378]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1603.4000000000378]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1604.6000000000379]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1605.800000000038]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1607.000000000038]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1608.200000000038]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1609.400000000038]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1610.600000000038]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1611.8000000000382]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1613.0000000000382]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1614.2000000000382]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1615.4000000000383]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1616.6000000000383]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1617.8000000000384]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1619.0000000000384]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1620.2000000000385]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1621.4000000000385]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1622.6000000000386]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1623.8000000000386]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1625.0000000000387]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1626.2000000000387]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1627.4000000000387]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1628.6000000000388]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1629.8000000000388]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1631.0000000000389]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1632.200000000039]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1633.400000000039]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1634.600000000039]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1635.800000000039]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1637.000000000039]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1638.2000000000392]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1639.4000000000392]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1640.6000000000392]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1641.8000000000393]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1643.0000000000393]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1644.2000000000394]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1645.4000000000394]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1646.6000000000395]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1647.8000000000395]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1649.0000000000396]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1650.2000000000396]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1651.4000000000397]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1652.6000000000397]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1653.8000000000397]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1655.0000000000398]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1656.2000000000398]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1657.4000000000399]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1658.60000000004]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1659.80000000004]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1661.00000000004]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1662.20000000004]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1663.40000000004]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1664.6000000000402]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1665.8000000000402]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1667.0000000000402]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1668.2000000000403]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1669.4000000000403]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1670.6000000000404]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1671.8000000000404]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1673.0000000000405]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1674.2000000000405]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1675.4000000000406]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1676.6000000000406]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1677.8000000000407]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1679.0000000000407]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1680.2000000000407]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1681.4000000000408]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1682.6000000000408]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1683.8000000000409]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1685.000000000041]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1686.200000000041]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1687.400000000041]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1688.600000000041]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1689.800000000041]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1691.0000000000412]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1692.2000000000412]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1693.4000000000412]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1694.6000000000413]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1695.8000000000413]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1697.0000000000414]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1698.2000000000414]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1699.4000000000415]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1700.6000000000415]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1701.8000000000416]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1703.0000000000416]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1704.2000000000417]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1705.4000000000417]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1706.6000000000417]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1707.8000000000418]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1709.0000000000418]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1710.2000000000419]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1711.400000000042]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1712.600000000042]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1713.800000000042]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1715.000000000042]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1716.200000000042]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1717.4000000000422]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1718.6000000000422]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1719.8000000000422]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1721.0000000000423]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1722.2000000000423]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1723.4000000000424]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1724.6000000000424]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1725.8000000000425]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1727.0000000000425]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1728.2000000000426]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1729.4000000000426]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1730.6000000000427]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1731.8000000000427]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1733.0000000000427]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1734.2000000000428]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1735.4000000000428]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1736.6000000000429]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1737.800000000043]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1739.000000000043]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1740.200000000043]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1741.400000000043]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1742.600000000043]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1743.8000000000432]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1745.0000000000432]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1746.2000000000432]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1747.4000000000433]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1748.6000000000433]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1749.8000000000434]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1751.0000000000434]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1752.2000000000435]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1753.4000000000435]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1754.6000000000436]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1755.8000000000436]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1757.0000000000437]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1758.2000000000437]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1759.4000000000437]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1760.6000000000438]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1761.8000000000438]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1763.0000000000439]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1764.200000000044]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1765.400000000044]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1766.600000000044]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1767.800000000044]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1769.000000000044]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1770.2000000000442]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1771.4000000000442]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1772.6000000000442]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1773.8000000000443]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1775.0000000000443]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1776.2000000000444]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1777.4000000000444]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1778.6000000000445]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1779.8000000000445]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1781.0000000000446]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1782.2000000000446]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1783.4000000000447]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1784.6000000000447]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1785.8000000000447]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1787.0000000000448]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1788.2000000000448]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1789.4000000000449]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1790.600000000045]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1791.800000000045]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1793.000000000045]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1794.200000000045]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1795.400000000045]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1796.6000000000452]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1797.8000000000452]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1799.0000000000452]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1800.2000000000453]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1801.4000000000453]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1802.6000000000454]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1803.8000000000454]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1805.0000000000455]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1806.2000000000455]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1807.4000000000456]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1808.6000000000456]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1809.8000000000457]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1811.0000000000457]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1812.2000000000457]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1813.4000000000458]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1814.6000000000458]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1815.8000000000459]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1817.000000000046]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1818.200000000046]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1819.400000000046]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1820.600000000046]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1821.800000000046]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1823.0000000000462]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1824.2000000000462]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1825.4000000000462]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1826.6000000000463]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1827.8000000000463]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1829.0000000000464]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1830.2000000000464]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1831.4000000000465]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1832.6000000000465]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1833.8000000000466]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1835.0000000000466]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1836.2000000000467]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1837.4000000000467]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1838.6000000000467]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1839.8000000000468]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1841.0000000000468]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1842.2000000000469]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1843.400000000047]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1844.600000000047]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1845.800000000047]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1847.000000000047]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1848.200000000047]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1849.4000000000472]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1850.6000000000472]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1851.8000000000472]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1853.0000000000473]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1854.2000000000473]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1855.4000000000474]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1856.6000000000474]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1857.8000000000475]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1859.0000000000475]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1860.2000000000476]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1861.4000000000476]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1862.6000000000477]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1863.8000000000477]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1865.0000000000477]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1866.2000000000478]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1867.4000000000478]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1868.6000000000479]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1869.800000000048]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1871.000000000048]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1872.200000000048]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1873.400000000048]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1874.600000000048]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1875.8000000000482]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1877.0000000000482]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1878.2000000000482]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1879.4000000000483]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1880.6000000000483]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1881.8000000000484]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1883.0000000000484]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1884.2000000000485]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1885.4000000000485]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1886.6000000000486]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1887.8000000000486]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1889.0000000000487]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1890.2000000000487]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1891.4000000000487]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1892.6000000000488]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1893.8000000000488]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1895.0000000000489]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1896.200000000049]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1897.400000000049]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1898.600000000049]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1899.800000000049]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1901.000000000049]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1902.2000000000492]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1903.4000000000492]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1904.6000000000492]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1905.8000000000493]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1907.0000000000493]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1908.2000000000494]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1909.4000000000494]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1910.6000000000495]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1911.8000000000495]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1913.0000000000496]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1914.2000000000496]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1915.4000000000497]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1916.6000000000497]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1917.8000000000497]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1919.0000000000498]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1920.2000000000498]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1921.4000000000499]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1922.60000000005]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1923.80000000005]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1925.00000000005]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1926.20000000005]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1927.40000000005]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1928.6000000000502]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1929.8000000000502]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1931.0000000000502]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1932.2000000000503]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1933.4000000000503]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1934.6000000000504]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1935.8000000000504]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1937.0000000000505]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1938.2000000000505]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1939.4000000000506]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1940.6000000000506]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1941.8000000000507]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1943.0000000000507]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1944.2000000000507]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1945.4000000000508]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1946.6000000000508]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1947.8000000000509]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1949.000000000051]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1950.200000000051]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1951.400000000051]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1952.600000000051]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1953.800000000051]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1955.0000000000512]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1956.2000000000512]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1957.4000000000513]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1958.6000000000513]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1959.8000000000513]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1961.0000000000514]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1962.2000000000514]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1963.4000000000515]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1964.6000000000515]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1965.8000000000516]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1967.0000000000516]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1968.2000000000517]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1969.4000000000517]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1970.6000000000518]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1971.8000000000518]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1973.0000000000518]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1974.200000000052]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1975.400000000052]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1976.600000000052]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1977.800000000052]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1979.000000000052]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1980.2000000000521]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1981.4000000000522]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1982.6000000000522]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1983.8000000000523]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1985.0000000000523]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 1986.2000000000523]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 1987.4000000000524]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 1988.6000000000524]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 1989.8000000000525]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 1991.0000000000525]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 1992.2000000000526]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1993.4000000000526]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 1994.6000000000527]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 1995.8000000000527]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 1997.0000000000528]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 1998.2000000000528]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1999.4000000000528]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2000.600000000053]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2001.800000000053]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2003.000000000053]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2004.200000000053]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2005.400000000053]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2006.6000000000531]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2007.8000000000532]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2009.0000000000532]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2010.2000000000533]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2011.4000000000533]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2012.6000000000533]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2013.8000000000534]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2015.0000000000534]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2016.2000000000535]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2017.4000000000535]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2018.6000000000536]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2019.8000000000536]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2021.0000000000537]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2022.2000000000537]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2023.4000000000538]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2024.6000000000538]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2025.8000000000538]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2027.000000000054]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2028.200000000054]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2029.400000000054]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2030.600000000054]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2031.800000000054]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2033.0000000000541]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2034.2000000000542]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2035.4000000000542]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2036.6000000000543]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2037.8000000000543]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2039.0000000000543]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2040.2000000000544]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2041.4000000000544]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2042.6000000000545]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2043.8000000000545]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2045.0000000000546]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2046.2000000000546]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2047.4000000000547]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2048.6000000000545]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2049.8000000000543]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2051.000000000054]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2052.200000000054]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2053.4000000000538]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2054.6000000000536]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2055.8000000000534]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2057.000000000053]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2058.200000000053]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2059.400000000053]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2060.6000000000527]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2061.8000000000525]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2063.0000000000523]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2064.200000000052]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2065.400000000052]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2066.6000000000518]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2067.8000000000516]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2069.0000000000514]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2070.200000000051]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2071.400000000051]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2072.600000000051]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2073.8000000000507]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2075.0000000000505]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2076.2000000000503]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2077.40000000005]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2078.60000000005]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2079.8000000000497]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2081.0000000000496]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2082.2000000000494]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2083.400000000049]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2084.600000000049]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2085.800000000049]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2087.0000000000487]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2088.2000000000485]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2089.4000000000483]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2090.600000000048]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2091.800000000048]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2093.0000000000477]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2094.2000000000476]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2095.4000000000474]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2096.600000000047]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2097.800000000047]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2099.000000000047]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2100.2000000000467]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2101.4000000000465]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2102.6000000000463]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2103.800000000046]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2105.000000000046]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2106.2000000000457]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2107.4000000000456]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2108.6000000000454]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2109.800000000045]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2111.000000000045]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2112.200000000045]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2113.4000000000447]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2114.6000000000445]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2115.8000000000443]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2117.000000000044]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2118.200000000044]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2119.4000000000437]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2120.6000000000436]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2121.8000000000434]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2123.000000000043]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2124.200000000043]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2125.400000000043]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2126.6000000000427]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2127.8000000000425]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2129.0000000000423]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2130.200000000042]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2131.400000000042]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2132.6000000000417]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2133.8000000000416]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2135.0000000000414]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2136.200000000041]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2137.400000000041]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2138.600000000041]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2139.8000000000407]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2141.0000000000405]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2142.2000000000403]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2143.40000000004]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2144.60000000004]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2145.8000000000397]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2147.0000000000396]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2148.2000000000394]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2149.400000000039]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2150.600000000039]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2151.800000000039]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2153.0000000000387]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2154.2000000000385]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2155.4000000000383]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2156.600000000038]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2157.800000000038]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2159.0000000000377]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2160.2000000000376]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2161.4000000000374]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2162.600000000037]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2163.800000000037]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2165.000000000037]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2166.2000000000367]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2167.4000000000365]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2168.6000000000363]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2169.800000000036]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2171.000000000036]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2172.2000000000357]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2173.4000000000356]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2174.6000000000354]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2175.800000000035]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2177.000000000035]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2178.200000000035]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2179.4000000000347]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2180.6000000000345]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2181.8000000000343]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2183.000000000034]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2184.200000000034]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2185.4000000000337]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2186.6000000000336]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2187.8000000000334]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2189.000000000033]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2190.200000000033]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2191.400000000033]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2192.6000000000327]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2193.8000000000325]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2195.0000000000323]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2196.200000000032]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2197.400000000032]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2198.6000000000317]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2199.8000000000316]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2201.0000000000314]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2202.200000000031]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2203.400000000031]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2204.600000000031]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2205.8000000000306]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2207.0000000000305]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2208.2000000000303]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2209.40000000003]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2210.60000000003]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2211.8000000000297]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2213.0000000000296]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2214.2000000000294]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2215.400000000029]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2216.600000000029]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2217.800000000029]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2219.0000000000286]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2220.2000000000285]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2221.4000000000283]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2222.600000000028]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2223.800000000028]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2225.0000000000277]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2226.2000000000276]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2227.4000000000274]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2228.600000000027]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2229.800000000027]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2231.000000000027]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2232.2000000000266]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2233.4000000000265]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2234.6000000000263]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2235.800000000026]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2237.000000000026]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2238.2000000000257]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2239.4000000000256]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2240.6000000000254]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2241.800000000025]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2243.000000000025]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2244.200000000025]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2245.4000000000246]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2246.6000000000245]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2247.8000000000243]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2249.000000000024]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2250.200000000024]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2251.4000000000237]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2252.6000000000236]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2253.8000000000234]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2255.000000000023]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2256.200000000023]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2257.400000000023]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2258.6000000000226]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2259.8000000000225]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2261.0000000000223]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2262.200000000022]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2263.400000000022]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2264.6000000000217]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2265.8000000000216]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2267.0000000000214]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2268.200000000021]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2269.400000000021]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2270.600000000021]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2271.8000000000206]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2273.0000000000205]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2274.2000000000203]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2275.40000000002]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2276.60000000002]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2277.8000000000197]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2279.0000000000196]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2280.2000000000194]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2281.400000000019]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2282.600000000019]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2283.800000000019]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2285.0000000000186]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2286.2000000000185]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2287.4000000000183]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2288.600000000018]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2289.800000000018]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2291.0000000000177]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2292.2000000000176]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2293.4000000000174]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2294.600000000017]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2295.800000000017]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2297.000000000017]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2298.2000000000166]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2299.4000000000165]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2300.6000000000163]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2301.800000000016]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2303.000000000016]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2304.2000000000157]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2305.4000000000156]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2306.6000000000154]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2307.800000000015]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2309.000000000015]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2310.200000000015]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2311.4000000000146]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2312.6000000000145]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2313.8000000000143]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2315.000000000014]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2316.200000000014]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2317.4000000000137]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2318.6000000000136]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2319.8000000000134]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2321.000000000013]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2322.200000000013]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2323.400000000013]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2324.6000000000126]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2325.8000000000125]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2327.0000000000123]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2328.200000000012]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2329.400000000012]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2330.6000000000117]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2331.8000000000116]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2333.0000000000114]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2334.200000000011]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2335.400000000011]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2336.600000000011]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2337.8000000000106]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2339.0000000000105]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2340.2000000000103]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2341.40000000001]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2342.60000000001]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2343.8000000000097]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2345.0000000000095]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2346.2000000000094]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2347.400000000009]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2348.600000000009]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2349.800000000009]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2351.0000000000086]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2352.2000000000085]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2353.4000000000083]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2354.600000000008]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2355.800000000008]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2357.0000000000077]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2358.2000000000075]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2359.4000000000074]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2360.600000000007]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2361.800000000007]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2363.000000000007]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2364.2000000000066]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2365.4000000000065]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2366.6000000000063]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2367.800000000006]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2369.000000000006]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2370.2000000000057]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2371.4000000000055]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2372.6000000000054]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2373.800000000005]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2375.000000000005]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2376.200000000005]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2377.4000000000046]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2378.6000000000045]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2379.8000000000043]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2381.000000000004]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2382.200000000004]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2383.4000000000037]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2384.6000000000035]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2385.8000000000034]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2387.000000000003]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2388.200000000003]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2389.400000000003]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2390.6000000000026]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2391.8000000000025]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2393.0000000000023]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2394.200000000002]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2395.400000000002]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2396.6000000000017]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2397.8000000000015]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2399.0000000000014]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2400.200000000001]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2401.400000000001]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2402.600000000001]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2403.8000000000006]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2405.0000000000005]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2406.2000000000003]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2407.4]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2408.6]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2409.7999999999997]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2410.9999999999995]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2412.1999999999994]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2413.399999999999]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2414.599999999999]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2415.799999999999]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2416.9999999999986]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2418.1999999999985]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2419.3999999999983]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2420.599999999998]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2421.799999999998]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2422.9999999999977]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2424.1999999999975]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2425.3999999999974]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2426.599999999997]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2427.799999999997]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2428.999999999997]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2430.1999999999966]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2431.3999999999965]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2432.5999999999963]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2433.799999999996]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2434.999999999996]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2436.1999999999957]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2437.3999999999955]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2438.5999999999954]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2439.799999999995]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2440.999999999995]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2442.199999999995]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2443.3999999999946]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2444.5999999999945]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2445.7999999999943]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2446.999999999994]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2448.199999999994]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2449.3999999999937]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2450.5999999999935]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2451.7999999999934]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2452.999999999993]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2454.199999999993]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2455.399999999993]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2456.5999999999926]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2457.7999999999925]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2458.9999999999923]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2460.199999999992]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2461.399999999992]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2462.5999999999917]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2463.7999999999915]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2464.9999999999914]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2466.199999999991]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2467.399999999991]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2468.599999999991]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2469.7999999999906]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2470.9999999999905]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2472.1999999999903]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2473.39999999999]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2474.59999999999]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2475.7999999999897]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2476.9999999999895]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2478.1999999999894]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2479.399999999989]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2480.599999999989]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2481.799999999989]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2482.9999999999886]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2484.1999999999884]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2485.3999999999883]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2486.599999999988]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2487.799999999988]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2488.9999999999877]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2490.1999999999875]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2491.3999999999874]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2492.599999999987]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2493.799999999987]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2494.999999999987]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2496.1999999999866]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2497.3999999999864]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2498.5999999999863]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2499.799999999986]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2500.999999999986]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2502.1999999999857]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2503.3999999999855]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2504.5999999999854]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2505.799999999985]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2506.999999999985]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2508.199999999985]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2509.3999999999846]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2510.5999999999844]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2511.7999999999843]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2512.999999999984]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2514.199999999984]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2515.3999999999837]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2516.5999999999835]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2517.7999999999834]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2518.999999999983]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2520.199999999983]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2521.399999999983]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2522.5999999999826]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2523.7999999999824]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2524.9999999999823]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2526.199999999982]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2527.399999999982]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2528.5999999999817]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2529.7999999999815]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2530.9999999999814]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2532.199999999981]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2533.399999999981]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2534.599999999981]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2535.7999999999806]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2536.9999999999804]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2538.1999999999803]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2539.39999999998]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2540.59999999998]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2541.7999999999797]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2542.9999999999795]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2544.1999999999794]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2545.399999999979]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2546.599999999979]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2547.799999999979]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2548.9999999999786]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2550.1999999999784]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2551.3999999999783]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2552.599999999978]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2553.799999999978]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2554.9999999999777]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2556.1999999999775]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2557.3999999999774]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2558.599999999977]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2559.799999999977]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2560.999999999977]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2562.1999999999766]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2563.3999999999764]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2564.5999999999763]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2565.799999999976]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2566.999999999976]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2568.1999999999757]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2569.3999999999755]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2570.5999999999754]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2571.799999999975]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2572.999999999975]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2574.199999999975]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2575.3999999999746]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2576.5999999999744]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2577.7999999999743]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2578.999999999974]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2580.199999999974]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2581.3999999999737]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2582.5999999999735]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2583.7999999999734]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2584.999999999973]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2586.199999999973]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2587.399999999973]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2588.5999999999726]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2589.7999999999724]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2590.9999999999723]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2592.199999999972]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2593.399999999972]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2594.5999999999717]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2595.7999999999715]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2596.9999999999714]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2598.199999999971]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2599.399999999971]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2600.599999999971]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2601.7999999999706]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2602.9999999999704]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2604.1999999999703]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2605.39999999997]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2606.59999999997]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2607.7999999999697]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2608.9999999999695]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2610.1999999999694]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2611.399999999969]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2612.599999999969]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2613.799999999969]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2614.9999999999686]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2616.1999999999684]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2617.3999999999683]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2618.599999999968]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2619.799999999968]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2620.9999999999677]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2622.1999999999675]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2623.3999999999673]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2624.599999999967]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2625.799999999967]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2626.999999999967]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2628.1999999999666]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2629.3999999999664]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2630.5999999999663]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2631.799999999966]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2632.999999999966]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2634.1999999999657]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2635.3999999999655]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2636.5999999999653]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2637.799999999965]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2638.999999999965]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2640.199999999965]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2641.3999999999646]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2642.5999999999644]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2643.7999999999643]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2644.999999999964]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2646.199999999964]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2647.3999999999637]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2648.5999999999635]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2649.7999999999633]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2650.999999999963]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2652.199999999963]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2653.399999999963]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2654.5999999999626]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2655.7999999999624]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2656.9999999999623]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2658.199999999962]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2659.399999999962]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2660.5999999999617]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2661.7999999999615]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2662.9999999999613]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2664.199999999961]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2665.399999999961]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2666.599999999961]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2667.7999999999606]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2668.9999999999604]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2670.1999999999603]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2671.39999999996]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2672.59999999996]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2673.7999999999597]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2674.9999999999595]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2676.1999999999593]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2677.399999999959]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2678.599999999959]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2679.799999999959]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2680.9999999999586]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2682.1999999999584]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2683.3999999999583]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2684.599999999958]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2685.799999999958]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2686.9999999999577]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2688.1999999999575]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2689.3999999999573]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2690.599999999957]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2691.799999999957]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2692.999999999957]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2694.1999999999566]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2695.3999999999564]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2696.5999999999563]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2697.799999999956]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2698.999999999956]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2700.1999999999557]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2701.3999999999555]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2702.5999999999553]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2703.799999999955]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2704.999999999955]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2706.199999999955]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2707.3999999999546]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2708.5999999999544]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2709.7999999999543]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2710.999999999954]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2712.199999999954]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2713.3999999999537]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2714.5999999999535]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2715.7999999999533]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2716.999999999953]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2718.199999999953]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2719.399999999953]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2720.5999999999526]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2721.7999999999524]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2722.9999999999523]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2724.199999999952]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2725.399999999952]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2726.5999999999517]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2727.7999999999515]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2728.9999999999513]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2730.199999999951]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2731.399999999951]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2732.599999999951]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2733.7999999999506]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2734.9999999999504]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2736.1999999999503]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2737.39999999995]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2738.59999999995]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2739.7999999999497]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2740.9999999999495]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2742.1999999999493]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2743.399999999949]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2744.599999999949]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2745.799999999949]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2746.9999999999486]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2748.1999999999484]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2749.3999999999482]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2750.599999999948]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2751.799999999948]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2752.9999999999477]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2754.1999999999475]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2755.3999999999473]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2756.599999999947]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2757.799999999947]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2758.999999999947]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2760.1999999999466]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2761.3999999999464]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2762.5999999999462]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2763.799999999946]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2764.999999999946]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2766.1999999999457]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2767.3999999999455]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2768.5999999999453]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2769.799999999945]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2770.999999999945]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2772.199999999945]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2773.3999999999446]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2774.5999999999444]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2775.7999999999442]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2776.999999999944]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2778.199999999944]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2779.3999999999437]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2780.5999999999435]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2781.7999999999433]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2782.999999999943]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2784.199999999943]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2785.399999999943]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2786.5999999999426]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2787.7999999999424]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2788.9999999999422]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2790.199999999942]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2791.399999999942]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2792.5999999999417]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2793.7999999999415]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2794.9999999999413]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2796.199999999941]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2797.399999999941]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2798.599999999941]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2799.7999999999406]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2800.9999999999404]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2802.1999999999402]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2803.39999999994]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2804.59999999994]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2805.7999999999397]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2806.9999999999395]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2808.1999999999393]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2809.399999999939]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2810.599999999939]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2811.799999999939]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2812.9999999999386]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2814.1999999999384]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2815.3999999999382]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2816.599999999938]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2817.799999999938]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2818.9999999999377]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2820.1999999999375]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2821.3999999999373]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2822.599999999937]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2823.799999999937]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2824.999999999937]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2826.1999999999366]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2827.3999999999364]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2828.5999999999362]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2829.799999999936]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2830.999999999936]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2832.1999999999357]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2833.3999999999355]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2834.5999999999353]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2835.799999999935]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2836.999999999935]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2838.199999999935]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2839.3999999999346]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2840.5999999999344]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2841.7999999999342]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2842.999999999934]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2844.199999999934]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2845.3999999999337]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2846.5999999999335]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2847.7999999999333]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2848.999999999933]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2850.199999999933]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2851.399999999933]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2852.5999999999326]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2853.7999999999324]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2854.9999999999322]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2856.199999999932]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2857.399999999932]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2858.5999999999317]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2859.7999999999315]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2860.9999999999313]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2862.199999999931]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2863.399999999931]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2864.599999999931]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2865.7999999999306]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2866.9999999999304]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2868.1999999999302]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2869.39999999993]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2870.59999999993]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2871.7999999999297]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2872.9999999999295]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2874.1999999999293]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2875.399999999929]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2876.599999999929]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2877.799999999929]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2878.9999999999286]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2880.1999999999284]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2881.3999999999282]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2882.599999999928]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2883.799999999928]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2884.9999999999277]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2886.1999999999275]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2887.3999999999273]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2888.599999999927]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2889.799999999927]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2890.999999999927]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2892.1999999999266]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2893.3999999999264]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2894.5999999999262]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2895.799999999926]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2896.999999999926]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2898.1999999999257]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2899.3999999999255]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2900.5999999999253]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2901.799999999925]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2902.999999999925]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2904.199999999925]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2905.3999999999246]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2906.5999999999244]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2907.7999999999242]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2908.999999999924]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2910.199999999924]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2911.3999999999237]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2912.5999999999235]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2913.7999999999233]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2914.999999999923]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2916.199999999923]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2917.399999999923]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2918.5999999999226]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2919.7999999999224]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2920.9999999999222]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2922.199999999922]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2923.399999999922]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2924.5999999999217]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2925.7999999999215]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2926.9999999999213]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2928.199999999921]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2929.399999999921]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2930.599999999921]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2931.7999999999206]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2932.9999999999204]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2934.1999999999202]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2935.39999999992]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2936.59999999992]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2937.7999999999197]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2938.9999999999195]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2940.1999999999193]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2941.399999999919]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2942.599999999919]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2943.799999999919]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2944.9999999999186]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2946.1999999999184]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2947.3999999999182]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2948.599999999918]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2949.799999999918]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2950.9999999999177]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2952.1999999999175]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2953.3999999999173]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2954.599999999917]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2955.799999999917]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2956.999999999917]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2958.1999999999166]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2959.3999999999164]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2960.5999999999162]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2961.799999999916]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2962.999999999916]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2964.1999999999157]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2965.3999999999155]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2966.5999999999153]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2967.799999999915]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2968.999999999915]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2970.199999999915]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2971.3999999999146]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2972.5999999999144]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2973.7999999999142]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2974.999999999914]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2976.199999999914]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2977.3999999999137]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2978.5999999999135]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2979.7999999999133]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2980.999999999913]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2982.199999999913]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2983.399999999913]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2984.5999999999126]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 2985.7999999999124]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2986.9999999999122]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2988.199999999912]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 2989.399999999912]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 2990.5999999999117]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 2991.7999999999115]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 2992.9999999999113]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 2994.199999999911]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 2995.399999999911]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 2996.599999999911]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 2997.7999999999106]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 2998.9999999999104]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 3000.1999999999102]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 3001.39999999991]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 3002.59999999991]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 3003.7999999999097]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 3004.9999999999095]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 3006.1999999999093]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 3007.399999999909]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 3008.599999999909]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 3009.799999999909]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 3010.9999999999086]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 3012.1999999999084]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 3013.3999999999082]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 3014.599999999908]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 3015.799999999908]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 3016.9999999999077]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 3018.1999999999075]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 3019.3999999999073]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 3020.599999999907]) rotate([0, 0, 180]) // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 3021.799999999907]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 3022.999999999907]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 3024.1999999999066]) rotate([0, 0, 180])
  // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 3025.3999999999064]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 3026.5999999999062]) rotate([0, 0, 180]) // {'digit': 1, 'orientation': 'rotate180Z'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 3027.799999999906]) rotate([0, 0, 180])
  // {'digit': 3, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}
