
hull() {
    translate([1.05, 1.0, 4.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9500000000000002, 1.0, 4.8100000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.05, 1.0, 4.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.95, 1.0, 4.609999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0500000000000003, 1.0, 4.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.95, 1.0, 4.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.05, 1.0, 4.390000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.95, 1.0, 4.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.05, 1.0, 4.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.95, 1.0, 4.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.050000000000001, 1.0, 3.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.95, 1.0, 3.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.05, 1.0, 3.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.95, 1.0, 3.6100000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.05, 1.0, 3.5900000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.95, 1.0, 3.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.01, 1.05, 3.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.19, 1.9500000000000002, 3.2100000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.209999999999999, 2.05, 3.1900000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.39, 2.95, 3.0100000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.41, 3.0500000000000003, 2.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.59, 3.95, 2.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.610000000000001, 4.05, 2.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.790000000000001, 4.95, 2.6100000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.790000000000001, 5.05, 2.5900000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.610000000000001, 5.95, 2.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.59, 6.050000000000001, 2.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.41, 6.95, 2.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.39, 7.05, 2.1900000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.209999999999999, 7.95, 2.0100000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.19, 8.05, 1.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.01, 8.95, 1.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.95, 9.0, 1.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.05, 9.0, 1.6100000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.95, 9.0, 1.5900000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.05, 9.0, 1.4100000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.95, 9.0, 1.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.050000000000001, 9.0, 1.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.95, 9.0, 1.1900000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.05, 9.0, 1.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.95, 9.0, 0.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.05, 9.0, 0.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.95, 9.0, 0.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.0500000000000003, 9.0, 0.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.95, 9.0, 0.5900000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.05, 9.0, 0.41000000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.9500000000000002, 9.0, 0.39000000000000007]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.05, 9.0, 0.21000000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 8.95, 0.19000000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 8.05, 0.010000000000000002]) cube([0.4, 0.4, 0.1], center=true);
}

