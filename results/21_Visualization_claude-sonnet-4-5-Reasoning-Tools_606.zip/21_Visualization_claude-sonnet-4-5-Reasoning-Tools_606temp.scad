
hull() {
    translate([50.0375, 50.0, 94.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.712500000000006, 50.0, 94.85749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.78750000000001, 50.0, 94.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.462500000000006, 50.0, 94.70750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.5375, 50.001000000000005, 94.69250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.2125, 50.019000000000005, 94.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.2875, 50.022000000000006, 94.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.962500000000006, 50.05800000000001, 94.40750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.037000000000006, 50.063500000000005, 94.39250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.703, 50.12650000000001, 94.25750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.7765, 50.1345, 94.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.4335, 50.2155, 94.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.506, 50.2265, 94.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.153999999999996, 50.343500000000006, 93.95750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.225, 50.3575, 93.94250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.855000000000004, 50.49250000000001, 93.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.9245, 50.509, 93.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.5455, 50.67100000000001, 93.65750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.613499999999995, 50.6905, 93.64250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.216499999999996, 50.8795, 93.50750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.282, 50.902, 93.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.858, 51.118, 93.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.921, 51.143, 93.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.479, 51.37700000000001, 93.20750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.54, 51.404500000000006, 93.19250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.08, 51.6655, 93.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.1385, 51.696, 93.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.651500000000006, 51.98400000000001, 92.90750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.70700000000001, 52.017, 92.89250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.193, 52.323, 92.75750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.246, 52.35850000000001, 92.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.714000000000006, 52.691500000000005, 92.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.764, 52.730000000000004, 92.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.196, 53.09, 92.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.2425, 53.1305, 92.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.6475, 53.499500000000005, 92.30749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.691, 53.54200000000001, 92.29249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.06900000000001, 53.938, 92.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.10900000000001, 53.983000000000004, 92.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.451, 54.397000000000006, 92.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.487, 54.444, 91.99249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.793000000000006, 54.876, 91.85749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.825500000000005, 54.925, 91.84249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.1045, 55.375, 91.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.133, 55.426, 91.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.367000000000004, 55.894000000000005, 91.55749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.3915, 55.9465, 91.54249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.5985, 56.423500000000004, 91.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.619, 56.477500000000006, 91.39250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.781000000000006, 56.972500000000004, 91.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.7975, 57.0275, 91.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.9325, 57.5225, 91.10749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.945, 57.578500000000005, 91.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.03500000000001, 58.091499999999996, 90.95750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.043, 58.1485, 90.94250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.097, 58.6615, 90.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.101, 58.719, 90.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.119, 59.24100000000001, 90.65750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.11850000000001, 59.29900000000001, 90.64250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.09150000000001, 59.821000000000005, 90.50750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.0865, 59.879000000000005, 90.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.0235, 60.401, 90.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.0145, 60.4595, 90.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.915499999999994, 60.990500000000004, 90.20750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.902499999999996, 61.04900000000001, 90.19250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.7675, 61.571000000000005, 90.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.75, 61.629000000000005, 90.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.57, 62.151, 89.90750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.548, 62.209, 89.89250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.332, 62.731, 89.75750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.306, 62.789, 89.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.053999999999995, 63.31100000000001, 89.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.024, 63.36850000000001, 89.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.736000000000004, 63.8815, 89.45750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.702, 63.938, 89.44250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.378, 64.44200000000001, 89.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.34, 64.4975, 89.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.980000000000004, 64.9925, 89.15750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.938, 65.047, 89.14250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.542, 65.533, 89.00750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.496, 65.5865, 88.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.064, 66.0635, 88.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.0145, 66.116, 88.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.5555, 66.584, 88.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.502500000000005, 66.63499999999999, 88.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0075, 67.08500000000001, 88.55749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.951, 67.1345, 88.54249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.429, 67.57549999999999, 88.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.3695, 67.62349999999999, 88.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.8205, 68.0465, 88.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.7575, 68.093, 88.24249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.1725, 68.507, 88.10749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.1065, 68.5515, 88.09249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.5035, 68.93849999999999, 87.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.435, 68.981, 87.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.80500000000001, 69.359, 87.80749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.73350000000001, 69.3995, 87.79249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.0765, 69.7505, 87.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.0025, 69.7885, 87.64250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.3275, 70.1215, 87.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.25150000000001, 70.1575, 87.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.55850000000001, 70.4725, 87.35749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.480000000000004, 70.50649999999999, 87.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.76, 70.80349999999999, 87.20750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.6795, 70.835, 87.19250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.9505, 71.105, 87.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.8685, 71.13350000000001, 87.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.1215, 71.37650000000001, 86.90750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.038, 71.4025, 86.89250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.282, 71.6275, 86.75750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.1975, 71.651, 86.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.4325, 71.849, 86.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.3465, 71.8695, 86.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.563500000000005, 72.0405, 86.45750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.4765, 72.05799999999999, 86.44250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.6935, 72.20199999999998, 86.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.605999999999995, 72.2165, 86.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.814, 72.33350000000002, 86.15750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.726, 72.34500000000001, 86.14250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.934, 72.435, 86.00750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.8455, 72.4435, 85.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.0445, 72.5065, 85.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.9555, 72.512, 85.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.154500000000006, 72.548, 85.70750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0655, 72.5505, 85.69250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.2645, 72.5595, 85.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.1755, 72.55850000000001, 85.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.3745, 72.5315, 85.40750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.2855, 72.5275, 85.39250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.4845, 72.4825, 85.25750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.396, 72.4755, 85.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.604000000000006, 72.3945, 85.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.5165, 72.384, 85.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.7335, 72.276, 84.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.6465, 72.26249999999999, 84.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.8635, 72.1275, 84.80749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.777, 72.111, 84.79249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.003, 71.949, 84.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.9175, 71.92949999999999, 84.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.152499999999996, 71.7405, 84.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.068, 71.7175, 84.49249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.312000000000005, 71.4925, 84.35749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.229000000000006, 71.46650000000001, 84.34249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.49100000000001, 71.2235, 84.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.40950000000001, 71.195, 84.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.6805, 70.925, 84.05749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.600500000000004, 70.89349999999999, 84.04249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.889500000000005, 70.59649999999999, 83.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.8115, 70.5625, 83.89250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.1185, 70.2475, 83.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.042500000000004, 70.21050000000001, 83.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.3675, 69.8595, 83.60749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.2935, 69.8195, 83.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.636500000000005, 69.4505, 83.45750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.5645, 69.4085, 83.44250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.9255, 69.0215, 83.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.856, 68.977, 83.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.244000000000003, 68.563, 83.15750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.177500000000002, 68.516, 83.14250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.592499999999998, 68.084, 83.00750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.528499999999998, 68.03500000000001, 82.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.9615, 67.58500000000001, 82.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.900000000000002, 67.5335, 82.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.36, 67.0565, 82.70750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.301499999999997, 67.003, 82.69250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.7885, 66.517, 82.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.733, 66.46199999999999, 82.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.247, 65.95800000000001, 82.40750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.194499999999998, 65.90100000000001, 82.39250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.735500000000002, 65.37899999999999, 82.25750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.686, 65.32, 82.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.254, 64.78, 82.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.208000000000002, 64.7195, 82.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.812, 64.1705, 81.95750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.7695, 64.10849999999999, 81.94250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.4005, 63.5415, 81.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.3615, 63.478, 81.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.0285, 62.902, 81.65750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.993500000000004, 62.8375, 81.64250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.6965, 62.2525, 81.50750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.665000000000003, 62.187, 81.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.395, 61.593, 81.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.366999999999997, 61.526500000000006, 81.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.133000000000003, 60.923500000000004, 81.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.1095, 60.856, 81.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.9205, 60.244, 81.05749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.901, 60.176, 81.04249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.739, 59.56400000000001, 80.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.7235, 59.49550000000001, 80.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.6065, 58.874500000000005, 80.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.5955, 58.8055, 80.74249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.5145, 58.1845, 80.60749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.5075, 58.115, 80.59249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.462500000000002, 57.48500000000001, 80.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.460000000000004, 57.41550000000001, 80.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.460000000000004, 56.7945, 80.30749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.462000000000003, 56.724999999999994, 80.29249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.498, 56.095, 80.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.504, 56.0255, 80.14250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.576, 55.4045, 80.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.5865, 55.335499999999996, 79.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.703500000000002, 54.7145, 79.85749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.718500000000002, 54.646, 79.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.8715, 54.034000000000006, 79.70750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.8905, 53.966, 79.69250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.0795, 53.354, 79.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.1025, 53.286500000000004, 79.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.3275, 52.683499999999995, 79.40750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.355, 52.617, 79.39250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.625, 52.023, 79.25750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.657, 51.9575, 79.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.963, 51.3725, 79.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.999000000000002, 51.30800000000001, 79.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.341, 50.732, 78.95750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.381, 50.6685, 78.94250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.759, 50.1015, 78.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.803, 50.039500000000004, 78.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.217, 49.490500000000004, 78.65750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.264999999999997, 49.43000000000001, 78.64250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.714999999999996, 48.89, 78.50750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.766999999999996, 48.831, 78.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.253, 48.309000000000005, 78.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.309, 48.25200000000001, 78.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.831, 47.748000000000005, 78.20750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.8905, 47.693, 78.19250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.4395, 47.207, 78.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.502, 47.154, 78.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.078, 46.686, 77.90750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.144, 46.635, 77.89250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.756, 46.184999999999995, 77.75750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.825, 46.1365, 77.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.455, 45.7135, 77.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.526999999999997, 45.667500000000004, 77.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.193, 45.2625, 77.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.2675, 45.219, 77.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.942499999999995, 44.841, 77.30749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.0195, 44.8005, 77.29249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.730500000000006, 44.4495, 77.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.81, 44.412, 77.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.53, 44.088, 77.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.611, 44.05350000000001, 76.99249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.349000000000004, 43.7565, 76.85749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.432, 43.725, 76.84249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.188, 43.455, 76.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.2725, 43.427, 76.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.0375, 43.193000000000005, 76.55749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.1235, 43.1685, 76.54249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.9065, 42.9615, 76.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.994, 42.9405, 76.39250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.786, 42.7695, 76.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.874, 42.752, 76.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.666000000000004, 42.608000000000004, 76.10749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.75450000000001, 42.594, 76.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.5555, 42.486, 75.95750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.644999999999996, 42.476, 75.94250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.455, 42.403999999999996, 75.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.545, 42.397499999999994, 75.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.355, 42.3525, 75.65750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.44499999999999, 42.3495, 75.64250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.254999999999995, 42.3405, 75.50750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.345, 42.3415, 75.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.155, 42.3685, 75.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.245000000000005, 42.37349999999999, 75.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.05500000000001, 42.436499999999995, 75.20750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.145, 42.445, 75.19250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.955, 42.535000000000004, 75.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.0445, 42.547000000000004, 75.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.8455, 42.673, 74.90750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.934, 42.689, 74.89250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.726, 42.851, 74.75750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.814, 42.8705, 74.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.605999999999995, 43.0595, 74.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.6935, 43.082499999999996, 74.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.4765, 43.3075, 74.45750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.56250000000001, 43.334, 74.44250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.3275, 43.586, 74.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.412, 43.616, 74.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.168, 43.904, 74.15750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.2515, 43.93750000000001, 74.14250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.9985, 44.252500000000005, 74.00750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.08, 44.289, 73.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.800000000000004, 44.631, 73.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.87950000000001, 44.671, 73.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.590500000000006, 45.049, 73.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.6685, 45.0925, 73.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.3615, 45.4975, 73.55749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.437, 45.544000000000004, 73.54249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.10300000000001, 45.976, 73.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.176, 46.0255, 73.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.824, 46.484500000000004, 73.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.8945, 46.537, 73.24249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.515499999999996, 47.022999999999996, 73.10749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.583, 47.077999999999996, 73.09249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.17700000000001, 47.582, 72.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.242000000000004, 47.639500000000005, 72.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.818000000000005, 48.170500000000004, 72.80749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.88000000000001, 48.231, 72.79249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.42, 48.789, 72.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.478500000000004, 48.852000000000004, 72.64250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.9915, 49.428000000000004, 72.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.047000000000004, 49.493, 72.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.53300000000001, 50.086999999999996, 72.35749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.58500000000001, 50.153999999999996, 72.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.035000000000004, 50.766, 72.20750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0835, 50.835, 72.19250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.5065, 51.465, 72.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.551500000000004, 51.536, 72.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.938500000000005, 52.184, 71.90750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.9795, 52.257, 71.89250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.3305, 52.923, 71.75750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.368, 52.9975, 71.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.692, 53.6725, 71.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.725500000000004, 53.748, 71.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.00450000000001, 54.432, 71.45750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.033500000000004, 54.509, 71.44250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.2765, 55.211, 71.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.301500000000004, 55.289500000000004, 71.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.5085, 56.0005, 71.15750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.5295, 56.08, 71.14250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.7005, 56.800000000000004, 71.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.7175, 56.88000000000001, 70.99249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.8525, 57.60000000000001, 70.85749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.864999999999995, 57.68050000000001, 70.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.955, 58.40950000000001, 70.70750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.963, 58.490500000000004, 70.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.017, 59.2195, 70.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.020500000000006, 59.300999999999995, 70.54249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.029500000000006, 60.039, 70.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.02850000000001, 60.121, 70.39250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.00150000000001, 60.859, 70.25750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.996500000000005, 60.9405, 70.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.9335, 61.6695, 70.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.924, 61.751000000000005, 70.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.816, 62.489000000000004, 69.95750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.801500000000004, 62.5705, 69.94250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.648500000000006, 63.29950000000001, 69.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.63, 63.38000000000001, 69.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.449999999999996, 64.1, 69.65750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.427499999999995, 64.17999999999999, 69.64250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.2025, 64.89999999999999, 69.50750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.175, 64.9795, 69.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.905, 65.6905, 69.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.8735, 65.769, 69.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.5765, 66.471, 69.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.541000000000004, 66.5485, 69.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.199, 67.2415, 69.05749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.159, 67.318, 69.04249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.781, 68.00200000000001, 68.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.736999999999995, 68.077, 68.89250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.32299999999999, 68.743, 68.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.275499999999994, 68.8165, 68.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.8345, 69.4735, 68.60749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.783, 69.5455, 68.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.297000000000004, 70.1845, 68.45750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.2415, 70.255, 68.44250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.728500000000004, 70.885, 68.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.669500000000006, 70.9535, 68.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.12050000000001, 71.55650000000001, 68.15750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.05800000000001, 71.62250000000002, 68.14250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.482000000000006, 72.2075, 68.00750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.416500000000006, 72.27149999999999, 67.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.813500000000005, 72.83850000000001, 67.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.7445, 72.90050000000001, 67.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.1055, 73.4495, 67.70750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.033, 73.509, 67.69250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.367, 74.031, 67.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.292, 74.0875, 67.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.608000000000004, 74.5825, 67.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.5305, 74.636, 67.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.819500000000005, 75.104, 67.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.739000000000004, 75.155, 67.24249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.001000000000005, 75.60499999999999, 67.10749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.9185, 75.65299999999999, 67.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.1715, 76.06700000000001, 66.95750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.087, 76.1115, 66.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.313, 76.49849999999999, 66.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.226, 76.53999999999999, 66.79249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.434, 76.9, 66.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.3455, 76.938, 66.64250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.544500000000006, 77.262, 66.50750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.455000000000005, 77.29650000000001, 66.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.645, 77.5935, 66.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.554, 77.625, 66.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.726, 77.895, 66.20750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.6335, 77.923, 66.19250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.7965, 78.15700000000001, 66.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.703500000000005, 78.18100000000001, 66.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.8665, 78.379, 65.90750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.772999999999996, 78.399, 65.89250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.92700000000001, 78.56099999999999, 65.75750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.8325, 78.57749999999999, 65.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.9775, 78.7125, 65.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.882999999999996, 78.7255, 65.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.037000000000006, 78.8245, 65.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.9425, 78.8335, 65.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.0875, 78.8965, 65.30749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.9925, 78.9015, 65.29249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.1375, 78.92850000000001, 65.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.043, 78.93, 65.14250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.196999999999996, 78.93, 65.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.102999999999994, 78.92750000000001, 64.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.257000000000005, 78.88250000000001, 64.85749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.1635, 78.876, 64.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.3265, 78.804, 64.70750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.23350000000001, 78.794, 64.69250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.3965, 78.686, 64.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.304, 78.67200000000001, 64.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.476, 78.52799999999999, 64.40750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.3845, 78.50999999999999, 64.39250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.5655, 78.33, 64.25750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.475500000000004, 78.3085, 64.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.6745, 78.1015, 64.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.5855, 78.07650000000001, 64.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.7845, 77.8335, 63.95750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.6965, 77.80449999999999, 63.94250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.9135, 77.5255, 63.807500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.8275, 77.493, 63.792500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.06250000000001, 77.187, 63.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.978000000000005, 77.1515, 63.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.222, 76.8185, 63.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.139000000000003, 76.7795, 63.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.401000000000003, 76.4105, 63.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.32, 76.36800000000001, 63.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.6, 75.97200000000001, 63.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.5215, 75.926, 63.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.828500000000002, 75.494, 63.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.7525, 75.44500000000001, 63.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.0775, 74.995, 62.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.003500000000003, 74.9435, 62.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.3465, 74.4665, 62.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.275000000000002, 74.41199999999999, 62.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.645000000000003, 73.908, 62.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.576500000000003, 73.851, 62.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.9735, 73.329, 62.45750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.908, 73.2695, 62.44250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.332, 72.7205, 62.307500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.27, 72.658, 62.292500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.73, 72.082, 62.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.671, 72.0175, 62.142500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.149, 71.4325, 62.00750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.093500000000002, 71.366, 61.99250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.616500000000002, 70.754, 61.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.565, 70.685, 61.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.115, 70.055, 61.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.067, 69.9845, 61.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.653000000000002, 69.3455, 61.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.609, 69.2735, 61.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.231, 68.6165, 61.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.191000000000003, 68.543, 61.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.848999999999997, 67.87700000000001, 61.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.813, 67.802, 61.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.506999999999998, 67.118, 61.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.475499999999997, 67.0415, 61.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.214499999999997, 66.3485, 60.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.188, 66.2715, 60.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.972, 65.5785, 60.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.95, 65.5005, 60.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.77, 64.7895, 60.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.7525, 64.7105, 60.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.6175, 63.9995, 60.50750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.605, 63.92, 60.49250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.515000000000004, 63.2, 60.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.507000000000005, 63.120000000000005, 60.34250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.453000000000003, 62.400000000000006, 60.20750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.450000000000003, 62.32, 60.19250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.450000000000003, 61.6, 60.057500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.452, 61.52, 60.042500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.488, 60.8, 59.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.4945, 60.72, 59.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.575499999999998, 60.0, 59.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.587, 59.92, 59.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.713, 59.2, 59.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.729499999999998, 59.12, 59.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.900499999999997, 58.4, 59.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.921499999999998, 58.3205, 59.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.1285, 57.609500000000004, 59.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.154, 57.531000000000006, 59.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.406000000000002, 56.82899999999999, 59.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.436500000000002, 56.751, 59.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.7335, 56.049, 59.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.7685, 55.972, 58.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.1015, 55.288000000000004, 58.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.140500000000003, 55.212, 58.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.509500000000003, 54.528000000000006, 58.70750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.553, 54.453, 58.69250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.967, 53.787, 58.557500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.015, 53.7135, 58.542500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.464999999999996, 53.05650000000001, 58.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.517, 52.984500000000004, 58.392500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.003000000000004, 52.3455, 58.25750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.059000000000005, 52.275, 58.24250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.581000000000003, 51.644999999999996, 58.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.641000000000002, 51.576, 58.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.199, 50.964000000000006, 57.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.263, 50.897000000000006, 57.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.857000000000003, 50.303000000000004, 57.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.925000000000004, 50.238, 57.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.555, 49.662000000000006, 57.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.6265, 49.599000000000004, 57.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.2835, 49.041000000000004, 57.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.358, 48.980500000000006, 57.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.041999999999998, 48.4495, 57.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.119999999999997, 48.39150000000001, 57.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.84, 47.8785, 57.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.921, 47.82300000000001, 57.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.659, 47.337, 57.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.743000000000002, 47.284, 57.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.516999999999996, 46.815999999999995, 56.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.604, 46.766, 56.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.396000000000004, 46.334, 56.75750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.485000000000003, 46.287, 56.74250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.295, 45.873, 56.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.386500000000005, 45.829, 56.59250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.22350000000001, 45.451, 56.45750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.3175, 45.4105, 56.44250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.1725, 45.0595, 56.307500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.268, 45.022, 56.292500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.132, 44.698, 56.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.229, 44.664, 56.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.111, 44.376, 56.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.2095, 44.346, 55.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.100500000000004, 44.093999999999994, 55.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.200500000000005, 44.067499999999995, 55.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.109500000000004, 43.8425, 55.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.2105, 43.819500000000005, 55.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.1195, 43.6305, 55.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.221000000000004, 43.61149999999999, 55.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.138999999999996, 43.4585, 55.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.241, 43.44350000000001, 55.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.159, 43.3265, 55.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.2615, 43.3155, 55.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.188500000000005, 43.2345, 55.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.291000000000004, 43.2275, 55.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.208999999999996, 43.182500000000005, 54.95750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.311499999999995, 43.179500000000004, 54.94250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.238499999999995, 43.170500000000004, 54.807500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.3405, 43.1715, 54.792500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.2495, 43.1985, 54.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.3505, 43.203500000000005, 54.642500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.2595, 43.26650000000001, 54.50750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.3605, 43.27550000000001, 54.49250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.2695, 43.374500000000005, 54.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.3695, 43.3875, 54.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.26050000000001, 43.5225, 54.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.35900000000001, 43.5395, 54.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.241, 43.710499999999996, 54.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.338499999999996, 43.7315, 54.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.2115, 43.938500000000005, 53.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.307500000000005, 43.96350000000001, 53.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.1625, 44.206500000000005, 53.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.2565, 44.2355, 53.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.093500000000006, 44.514500000000005, 53.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.185500000000005, 44.547000000000004, 53.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.0045, 44.852999999999994, 53.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.0945, 44.888999999999996, 53.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.8955, 45.231, 53.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.983, 45.271, 53.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.757, 45.649, 53.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.842, 45.693000000000005, 53.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.598, 46.107000000000006, 53.00750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.6805, 46.154500000000006, 52.99250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.40950000000001, 46.5955, 52.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.489000000000004, 46.646, 52.84250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.191, 47.114000000000004, 52.70750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.2675, 47.168, 52.69250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.942499999999995, 47.672000000000004, 52.557500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.016, 47.72950000000001, 52.542500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.66400000000001, 48.2605, 52.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.734500000000004, 48.321, 52.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.3555, 48.879, 52.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.4225, 48.942499999999995, 52.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0075, 49.5275, 52.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0705, 49.59400000000001, 52.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.6195, 50.206, 51.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.679, 50.2755, 51.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.201, 50.914500000000004, 51.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.257, 50.98650000000001, 51.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.743, 51.6435, 51.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.795, 51.718, 51.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.245000000000005, 52.402, 51.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.293000000000006, 52.479, 51.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.707, 53.181000000000004, 51.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.7505, 53.260000000000005, 51.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.1195, 53.980000000000004, 51.20750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.158500000000004, 54.06100000000001, 51.19250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.4915, 54.79900000000001, 51.057500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.5265, 54.8815, 51.042500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.8235, 55.6285, 50.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.854000000000006, 55.712500000000006, 50.892500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.10600000000001, 56.477500000000006, 50.75750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.132, 56.563, 50.74250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.348, 57.337, 50.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.3695, 57.423500000000004, 50.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.5405, 58.206500000000005, 50.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.5575, 58.294000000000004, 50.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.69250000000001, 59.086000000000006, 50.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.705, 59.17450000000001, 50.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.795, 59.975500000000004, 50.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.8025, 60.0645, 50.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.8475, 60.8655, 50.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.8475, 60.8655, 49.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.8025, 60.0645, 49.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.795, 59.975500000000004, 49.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.705, 59.17450000000001, 49.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.69250000000001, 59.086000000000006, 49.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.5575, 58.294000000000004, 49.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.5405, 58.206500000000005, 49.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.3695, 57.423500000000004, 49.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.348, 57.337, 49.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.132, 56.563, 49.25750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.10600000000001, 56.477500000000006, 49.24250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.854000000000006, 55.712500000000006, 49.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.8235, 55.6285, 49.09250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.5265, 54.8815, 48.95750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.4915, 54.79900000000001, 48.94250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.158500000000004, 54.06100000000001, 48.807500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.1195, 53.980000000000004, 48.792500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.7505, 53.260000000000005, 48.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.707, 53.181000000000004, 48.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.293000000000006, 52.479, 48.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.245000000000005, 52.402, 48.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.795, 51.718, 48.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.743, 51.6435, 48.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.257, 50.98650000000001, 48.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.201, 50.914500000000004, 48.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.679, 50.2755, 48.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.6195, 50.206, 48.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0705, 49.59400000000001, 47.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0075, 49.5275, 47.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.4225, 48.942499999999995, 47.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.3555, 48.879, 47.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.734500000000004, 48.321, 47.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.66400000000001, 48.2605, 47.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.016, 47.72950000000001, 47.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.942499999999995, 47.672000000000004, 47.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.2675, 47.168, 47.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.191, 47.114000000000004, 47.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.489000000000004, 46.646, 47.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.40950000000001, 46.5955, 47.142500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.6805, 46.154500000000006, 47.00750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.598, 46.107000000000006, 46.99250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.842, 45.693000000000005, 46.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.757, 45.649, 46.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.983, 45.271, 46.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.8955, 45.231, 46.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.0945, 44.888999999999996, 46.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.0045, 44.852999999999994, 46.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.185500000000005, 44.547000000000004, 46.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.093500000000006, 44.514500000000005, 46.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.2565, 44.2355, 46.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.1625, 44.206500000000005, 46.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.307500000000005, 43.96350000000001, 46.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.2115, 43.938500000000005, 46.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.338499999999996, 43.7315, 45.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.241, 43.710499999999996, 45.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.35900000000001, 43.5395, 45.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.26050000000001, 43.5225, 45.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.3695, 43.3875, 45.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.2695, 43.374500000000005, 45.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.3605, 43.27550000000001, 45.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.2595, 43.26650000000001, 45.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.3505, 43.203500000000005, 45.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.2495, 43.1985, 45.34250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.3405, 43.1715, 45.20750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.238499999999995, 43.170500000000004, 45.19250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.311499999999995, 43.179500000000004, 45.057500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.208999999999996, 43.182500000000005, 45.042500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.291000000000004, 43.2275, 44.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.188500000000005, 43.2345, 44.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.2615, 43.3155, 44.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.159, 43.3265, 44.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.241, 43.44350000000001, 44.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.138999999999996, 43.4585, 44.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.221000000000004, 43.61149999999999, 44.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.1195, 43.6305, 44.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.2105, 43.819500000000005, 44.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.109500000000004, 43.8425, 44.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.200500000000005, 44.067499999999995, 44.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.100500000000004, 44.093999999999994, 44.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.2095, 44.346, 44.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.111, 44.376, 43.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.229, 44.664, 43.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.132, 44.698, 43.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.268, 45.022, 43.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.1725, 45.0595, 43.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.3175, 45.4105, 43.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.22350000000001, 45.451, 43.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.386500000000005, 45.829, 43.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.295, 45.873, 43.392500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.485000000000003, 46.287, 43.25750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.396000000000004, 46.334, 43.24250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.604, 46.766, 43.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.516999999999996, 46.815999999999995, 43.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.743000000000002, 47.284, 42.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.659, 47.337, 42.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.921, 47.82300000000001, 42.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.84, 47.8785, 42.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.119999999999997, 48.39150000000001, 42.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.041999999999998, 48.4495, 42.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.358, 48.980500000000006, 42.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.2835, 49.041000000000004, 42.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.6265, 49.599000000000004, 42.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.555, 49.662000000000006, 42.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.925000000000004, 50.238, 42.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.857000000000003, 50.303000000000004, 42.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.263, 50.897000000000006, 42.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.199, 50.964000000000006, 42.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.641000000000002, 51.576, 41.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.581000000000003, 51.644999999999996, 41.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.059000000000005, 52.275, 41.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.003000000000004, 52.3455, 41.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.517, 52.984500000000004, 41.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.464999999999996, 53.05650000000001, 41.59250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.015, 53.7135, 41.45750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.967, 53.787, 41.44250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.553, 54.453, 41.307500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.509500000000003, 54.528000000000006, 41.292500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.140500000000003, 55.212, 41.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.1015, 55.288000000000004, 41.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.7685, 55.972, 41.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.7335, 56.049, 40.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.436500000000002, 56.751, 40.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.406000000000002, 56.82899999999999, 40.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.154, 57.531000000000006, 40.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.1285, 57.609500000000004, 40.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.921499999999998, 58.3205, 40.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.900499999999997, 58.4, 40.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.729499999999998, 59.12, 40.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.713, 59.2, 40.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.587, 59.92, 40.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.575499999999998, 60.0, 40.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.4945, 60.72, 40.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.488, 60.8, 40.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.452, 61.52, 39.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.450000000000003, 61.6, 39.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.450000000000003, 62.32, 39.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.453000000000003, 62.400000000000006, 39.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.507000000000005, 63.120000000000005, 39.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.515000000000004, 63.2, 39.642500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.605, 63.92, 39.50750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.6175, 63.9995, 39.49250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.7525, 64.7105, 39.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.77, 64.7895, 39.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.95, 65.5005, 39.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.972, 65.5785, 39.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.188, 66.2715, 39.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.214499999999997, 66.3485, 39.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.475499999999997, 67.0415, 38.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.506999999999998, 67.118, 38.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.813, 67.802, 38.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.848999999999997, 67.87700000000001, 38.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.191000000000003, 68.543, 38.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.231, 68.6165, 38.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.609, 69.2735, 38.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.653000000000002, 69.3455, 38.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.067, 69.9845, 38.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.115, 70.055, 38.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.565, 70.685, 38.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.616500000000002, 70.754, 38.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.093500000000002, 71.366, 38.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.149, 71.4325, 37.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.671, 72.0175, 37.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.73, 72.082, 37.84250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.27, 72.658, 37.70750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.332, 72.7205, 37.69250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.908, 73.2695, 37.557500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.9735, 73.329, 37.542500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.576500000000003, 73.851, 37.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.645000000000003, 73.908, 37.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.275000000000002, 74.41199999999999, 37.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.3465, 74.4665, 37.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.003500000000003, 74.9435, 37.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.0775, 74.995, 37.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.7525, 75.44500000000001, 36.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.828500000000002, 75.494, 36.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.5215, 75.926, 36.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.6, 75.97200000000001, 36.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.32, 76.36800000000001, 36.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.401000000000003, 76.4105, 36.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.139000000000003, 76.7795, 36.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.222, 76.8185, 36.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.978000000000005, 77.1515, 36.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.06250000000001, 77.187, 36.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.8275, 77.493, 36.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.9135, 77.5255, 36.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.6965, 77.80449999999999, 36.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.7845, 77.8335, 36.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.5855, 78.07650000000001, 35.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.6745, 78.1015, 35.892500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.475500000000004, 78.3085, 35.75750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.5655, 78.33, 35.74250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.3845, 78.50999999999999, 35.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.476, 78.52799999999999, 35.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.304, 78.67200000000001, 35.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.3965, 78.686, 35.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.23350000000001, 78.794, 35.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.3265, 78.804, 35.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.1635, 78.876, 35.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.257000000000005, 78.88250000000001, 35.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.102999999999994, 78.92750000000001, 35.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.196999999999996, 78.93, 34.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.043, 78.93, 34.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.1375, 78.92850000000001, 34.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.9925, 78.9015, 34.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.0875, 78.8965, 34.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.9425, 78.8335, 34.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.037000000000006, 78.8245, 34.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.882999999999996, 78.7255, 34.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.9775, 78.7125, 34.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.8325, 78.57749999999999, 34.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.92700000000001, 78.56099999999999, 34.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.772999999999996, 78.399, 34.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.8665, 78.379, 34.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.703500000000005, 78.18100000000001, 33.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.7965, 78.15700000000001, 33.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.6335, 77.923, 33.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.726, 77.895, 33.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.554, 77.625, 33.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.645, 77.5935, 33.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.455000000000005, 77.29650000000001, 33.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.544500000000006, 77.262, 33.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.3455, 76.938, 33.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.434, 76.9, 33.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.226, 76.53999999999999, 33.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.313, 76.49849999999999, 33.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.087, 76.1115, 33.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.1715, 76.06700000000001, 33.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.9185, 75.65299999999999, 32.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.001000000000005, 75.60499999999999, 32.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.739000000000004, 75.155, 32.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.819500000000005, 75.104, 32.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.5305, 74.636, 32.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.608000000000004, 74.5825, 32.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.292, 74.0875, 32.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.367, 74.031, 32.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.033, 73.509, 32.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.1055, 73.4495, 32.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.7445, 72.90050000000001, 32.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.813500000000005, 72.83850000000001, 32.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.416500000000006, 72.27149999999999, 32.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.482000000000006, 72.2075, 31.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.05800000000001, 71.62250000000002, 31.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.12050000000001, 71.55650000000001, 31.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.669500000000006, 70.9535, 31.707500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.728500000000004, 70.885, 31.692500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.2415, 70.255, 31.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.297000000000004, 70.1845, 31.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.783, 69.5455, 31.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.8345, 69.4735, 31.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.275499999999994, 68.8165, 31.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.32299999999999, 68.743, 31.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.736999999999995, 68.077, 31.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.781, 68.00200000000001, 31.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.159, 67.318, 30.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.199, 67.2415, 30.942500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.541000000000004, 66.5485, 30.807500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.5765, 66.471, 30.792500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.8735, 65.769, 30.657500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.905, 65.6905, 30.642500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.175, 64.9795, 30.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.2025, 64.89999999999999, 30.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.427499999999995, 64.17999999999999, 30.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.449999999999996, 64.1, 30.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.63, 63.38000000000001, 30.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.648500000000006, 63.29950000000001, 30.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.801500000000004, 62.5705, 30.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.816, 62.489000000000004, 30.042500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.924, 61.751000000000005, 29.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.9335, 61.6695, 29.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.996500000000005, 60.9405, 29.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.00150000000001, 60.859, 29.742500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.02850000000001, 60.121, 29.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.029500000000006, 60.039, 29.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.020500000000006, 59.300999999999995, 29.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.017, 59.2195, 29.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.963, 58.490500000000004, 29.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.955, 58.40950000000001, 29.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.864999999999995, 57.68050000000001, 29.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.8525, 57.60000000000001, 29.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.7175, 56.88000000000001, 29.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.7005, 56.800000000000004, 28.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.5295, 56.08, 28.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.5085, 56.0005, 28.842500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.301500000000004, 55.289500000000004, 28.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.2765, 55.211, 28.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.033500000000004, 54.509, 28.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.00450000000001, 54.432, 28.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.725500000000004, 53.748, 28.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.692, 53.6725, 28.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.368, 52.9975, 28.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.3305, 52.923, 28.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.9795, 52.257, 28.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.938500000000005, 52.184, 28.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.551500000000004, 51.536, 27.957500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.5065, 51.465, 27.942500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0835, 50.835, 27.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.035000000000004, 50.766, 27.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.58500000000001, 50.153999999999996, 27.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.53300000000001, 50.086999999999996, 27.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.047000000000004, 49.493, 27.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.9915, 49.428000000000004, 27.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.478500000000004, 48.852000000000004, 27.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.42, 48.789, 27.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.88000000000001, 48.231, 27.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.818000000000005, 48.170500000000004, 27.192500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.242000000000004, 47.639500000000005, 27.057500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.17700000000001, 47.582, 27.042500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.583, 47.077999999999996, 26.907500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.515499999999996, 47.022999999999996, 26.892500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.8945, 46.537, 26.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.824, 46.484500000000004, 26.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.176, 46.0255, 26.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.10300000000001, 45.976, 26.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.437, 45.544000000000004, 26.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.3615, 45.4975, 26.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.6685, 45.0925, 26.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.590500000000006, 45.049, 26.292500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.87950000000001, 44.671, 26.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.800000000000004, 44.631, 26.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.08, 44.289, 26.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.9985, 44.252500000000005, 25.992500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.2515, 43.93750000000001, 25.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.168, 43.904, 25.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.412, 43.616, 25.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.3275, 43.586, 25.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.56250000000001, 43.334, 25.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.4765, 43.3075, 25.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.6935, 43.082499999999996, 25.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.605999999999995, 43.0595, 25.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.814, 42.8705, 25.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.726, 42.851, 25.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.934, 42.689, 25.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.8455, 42.673, 25.092500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.0445, 42.547000000000004, 24.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.955, 42.535000000000004, 24.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.145, 42.445, 24.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.05500000000001, 42.436499999999995, 24.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.245000000000005, 42.37349999999999, 24.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.155, 42.3685, 24.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.345, 42.3415, 24.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.254999999999995, 42.3405, 24.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.44499999999999, 42.3495, 24.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.355, 42.3525, 24.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.545, 42.397499999999994, 24.207500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.455, 42.403999999999996, 24.192500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.644999999999996, 42.476, 24.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.5555, 42.486, 24.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.75450000000001, 42.594, 23.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.666000000000004, 42.608000000000004, 23.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.874, 42.752, 23.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.786, 42.7695, 23.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.994, 42.9405, 23.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.9065, 42.9615, 23.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.1235, 43.1685, 23.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.0375, 43.193000000000005, 23.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.2725, 43.427, 23.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.188, 43.455, 23.292500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.432, 43.725, 23.157500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.349000000000004, 43.7565, 23.142500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.611, 44.05350000000001, 23.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.53, 44.088, 22.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.81, 44.412, 22.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.730500000000006, 44.4495, 22.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.0195, 44.8005, 22.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.942499999999995, 44.841, 22.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.2675, 45.219, 22.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.193, 45.2625, 22.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.526999999999997, 45.667500000000004, 22.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.455, 45.7135, 22.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.825, 46.1365, 22.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.756, 46.184999999999995, 22.242500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.144, 46.635, 22.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.078, 46.686, 22.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.502, 47.154, 21.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.4395, 47.207, 21.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.8905, 47.693, 21.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.831, 47.748000000000005, 21.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.309, 48.25200000000001, 21.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.253, 48.309000000000005, 21.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.766999999999996, 48.831, 21.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.714999999999996, 48.89, 21.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.264999999999997, 49.43000000000001, 21.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.217, 49.490500000000004, 21.342500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.803, 50.039500000000004, 21.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.759, 50.1015, 21.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.381, 50.6685, 21.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.341, 50.732, 21.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.999000000000002, 51.30800000000001, 20.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.963, 51.3725, 20.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.657, 51.9575, 20.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.625, 52.023, 20.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.355, 52.617, 20.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.3275, 52.683499999999995, 20.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.1025, 53.286500000000004, 20.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.0795, 53.354, 20.442500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.8905, 53.966, 20.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.8715, 54.034000000000006, 20.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.718500000000002, 54.646, 20.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.703500000000002, 54.7145, 20.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.5865, 55.335499999999996, 20.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.576, 55.4045, 19.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.504, 56.0255, 19.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.498, 56.095, 19.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.462000000000003, 56.724999999999994, 19.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.460000000000004, 56.7945, 19.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.460000000000004, 57.41550000000001, 19.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.462500000000002, 57.48500000000001, 19.542500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.5075, 58.115, 19.407500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.5145, 58.1845, 19.392500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.5955, 58.8055, 19.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.6065, 58.874500000000005, 19.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.7235, 59.49550000000001, 19.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.739, 59.56400000000001, 19.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.901, 60.176, 18.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.9205, 60.244, 18.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.1095, 60.856, 18.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.133000000000003, 60.923500000000004, 18.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.366999999999997, 61.526500000000006, 18.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.395, 61.593, 18.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.665000000000003, 62.187, 18.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.6965, 62.2525, 18.492500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.993500000000004, 62.8375, 18.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.0285, 62.902, 18.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.3615, 63.478, 18.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.4005, 63.5415, 18.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.7695, 64.10849999999999, 18.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.812, 64.1705, 18.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.208000000000002, 64.7195, 17.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.254, 64.78, 17.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.686, 65.32, 17.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.735500000000002, 65.37899999999999, 17.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.194499999999998, 65.90100000000001, 17.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.247, 65.95800000000001, 17.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.733, 66.46199999999999, 17.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.7885, 66.517, 17.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.301499999999997, 67.003, 17.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.36, 67.0565, 17.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.900000000000002, 67.5335, 17.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.9615, 67.58500000000001, 17.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.528499999999998, 68.03500000000001, 17.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.592499999999998, 68.084, 16.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.177500000000002, 68.516, 16.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.244000000000003, 68.563, 16.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.856, 68.977, 16.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.9255, 69.0215, 16.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.5645, 69.4085, 16.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.636500000000005, 69.4505, 16.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.2935, 69.8195, 16.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.3675, 69.8595, 16.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.042500000000004, 70.21050000000001, 16.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.1185, 70.2475, 16.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.8115, 70.5625, 16.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.889500000000005, 70.59649999999999, 16.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.600500000000004, 70.89349999999999, 15.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.6805, 70.925, 15.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.40950000000001, 71.195, 15.807500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.49100000000001, 71.2235, 15.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.229000000000006, 71.46650000000001, 15.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.312000000000005, 71.4925, 15.642500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.068, 71.7175, 15.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.152499999999996, 71.7405, 15.492500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.9175, 71.92949999999999, 15.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.003, 71.949, 15.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.777, 72.111, 15.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.8635, 72.1275, 15.192499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.6465, 72.26249999999999, 15.057500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.7335, 72.276, 15.042500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.5165, 72.384, 14.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.604000000000006, 72.3945, 14.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.396, 72.4755, 14.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.4845, 72.4825, 14.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.2855, 72.5275, 14.607500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.3745, 72.5315, 14.592500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.1755, 72.55850000000001, 14.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.2645, 72.5595, 14.442499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0655, 72.5505, 14.307500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.154500000000006, 72.548, 14.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.9555, 72.512, 14.157500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.0445, 72.5065, 14.142500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.8455, 72.4435, 14.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.934, 72.435, 13.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.726, 72.34500000000001, 13.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.814, 72.33350000000002, 13.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.605999999999995, 72.2165, 13.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.6935, 72.20199999999998, 13.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.4765, 72.05799999999999, 13.557500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.563500000000005, 72.0405, 13.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.3465, 71.8695, 13.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.4325, 71.849, 13.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.1975, 71.651, 13.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.282, 71.6275, 13.242500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.038, 71.4025, 13.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.1215, 71.37650000000001, 13.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.8685, 71.13350000000001, 12.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.9505, 71.105, 12.942499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.6795, 70.835, 12.807500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.76, 70.80349999999999, 12.792500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.480000000000004, 70.50649999999999, 12.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.55850000000001, 70.4725, 12.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.25150000000001, 70.1575, 12.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.3275, 70.1215, 12.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.0025, 69.7885, 12.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.0765, 69.7505, 12.342500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.73350000000001, 69.3995, 12.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.80500000000001, 69.359, 12.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.435, 68.981, 12.057500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.5035, 68.93849999999999, 12.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.1065, 68.5515, 11.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.1725, 68.507, 11.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.7575, 68.093, 11.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.8205, 68.0465, 11.742500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.3695, 67.62349999999999, 11.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.429, 67.57549999999999, 11.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.951, 67.1345, 11.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0075, 67.08500000000001, 11.442499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.502500000000005, 66.63499999999999, 11.307500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.5555, 66.584, 11.292500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.0145, 66.116, 11.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.064, 66.0635, 11.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.496, 65.5865, 11.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.542, 65.533, 10.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.938, 65.047, 10.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.980000000000004, 64.9925, 10.842500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.34, 64.4975, 10.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.378, 64.44200000000001, 10.692499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.702, 63.938, 10.557500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.736000000000004, 63.8815, 10.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.024, 63.36850000000001, 10.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.053999999999995, 63.31100000000001, 10.392500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.306, 62.789, 10.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.332, 62.731, 10.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.548, 62.209, 10.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.57, 62.151, 10.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.75, 61.629000000000005, 9.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.7675, 61.571000000000005, 9.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.902499999999996, 61.04900000000001, 9.807500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.915499999999994, 60.990500000000004, 9.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.0145, 60.4595, 9.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.0235, 60.401, 9.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.0865, 59.879000000000005, 9.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.09150000000001, 59.821000000000005, 9.492500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.11850000000001, 59.29900000000001, 9.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.119, 59.24100000000001, 9.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.101, 58.719, 9.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.097, 58.6615, 9.192499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.043, 58.1485, 9.057500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.03500000000001, 58.091499999999996, 9.042500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.945, 57.578500000000005, 8.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.9325, 57.5225, 8.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.7975, 57.0275, 8.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.781000000000006, 56.972500000000004, 8.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.619, 56.477500000000006, 8.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.5985, 56.423500000000004, 8.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.3915, 55.9465, 8.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.367000000000004, 55.894000000000005, 8.442499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.133, 55.426, 8.307500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.1045, 55.375, 8.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.825500000000005, 54.925, 8.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.793000000000006, 54.876, 8.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.487, 54.444, 8.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.451, 54.397000000000006, 7.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.10900000000001, 53.983000000000004, 7.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.06900000000001, 53.938, 7.842499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.691, 53.54200000000001, 7.7075000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.6475, 53.499500000000005, 7.692500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.2425, 53.1305, 7.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.196, 53.09, 7.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.764, 52.730000000000004, 7.407500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.714000000000006, 52.691500000000005, 7.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.246, 52.35850000000001, 7.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.193, 52.323, 7.242500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.70700000000001, 52.017, 7.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.651500000000006, 51.98400000000001, 7.092499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.1385, 51.696, 6.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.08, 51.6655, 6.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.54, 51.404500000000006, 6.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.479, 51.37700000000001, 6.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.921, 51.143, 6.657500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.858, 51.118, 6.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.282, 50.902, 6.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.216499999999996, 50.8795, 6.492500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.613499999999995, 50.6905, 6.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.5455, 50.67100000000001, 6.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.9245, 50.509, 6.2075000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.855000000000004, 50.49250000000001, 6.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.225, 50.3575, 6.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.153999999999996, 50.343500000000006, 6.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.506, 50.2265, 5.907500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.4335, 50.2155, 5.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.7765, 50.1345, 5.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.703, 50.12650000000001, 5.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.037000000000006, 50.063500000000005, 5.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.962500000000006, 50.05800000000001, 5.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.2875, 50.022000000000006, 5.4575000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.2125, 50.019000000000005, 5.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.5375, 50.001000000000005, 5.307499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.462500000000006, 50.0, 5.2924999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.78750000000001, 50.0, 5.157500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.712500000000006, 50.0, 5.142500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0375, 50.0, 5.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 4.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 4.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 3.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 3.0500000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 2.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 2.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 1.9500000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 1.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 0.9500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 0.05]) cube([0.4, 0.4, 0.1], center=true);
}

