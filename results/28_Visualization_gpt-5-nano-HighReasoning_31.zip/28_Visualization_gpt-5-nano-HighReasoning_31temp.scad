
translate([0, 0, 0]) cube([1, 1, 4.452309012997602]);

translate([1, 0, 0]) cube([1, 1, 4.601435305571878]);

translate([2, 0, 0]) cube([1, 1, 4.3924746378669814]);

translate([3, 0, 0]) cube([1, 1, 4.272943560002982]);

translate([4, 0, 0]) cube([1, 1, 4.17623372908504]);

translate([5, 0, 0]) cube([1, 1, 4.15441429785979]);

translate([6, 0, 0]) cube([1, 1, 3.869165769475775]);

translate([7, 0, 0]) cube([1, 1, 4.103140856083046]);

translate([8, 0, 0]) cube([1, 1, 4.213511938844514]);

translate([9, 0, 0]) cube([1, 1, 4.4]);

translate([10, 0, 0]) cube([1, 1, 4.5]);

translate([11, 0, 0]) cube([1, 1, 4.31]);

translate([12, 0, 0]) cube([1, 1, 3.6384779416218427]);

translate([13, 0, 0]) cube([1, 1, 4.220875456790123]);

translate([14, 0, 0]) cube([1, 1, 4.404377283950618]);

translate([15, 0, 0]) cube([1, 1, 4.802133333333333]);

translate([16, 0, 0]) cube([1, 1, 5.010666666666666]);

translate([17, 0, 0]) cube([1, 1, 5.253333333333334]);

translate([18, 0, 0]) cube([1, 1, 4.26421811899363]);

translate([19, 0, 0]) cube([1, 1, 5.4]);

translate([20, 0, 0]) cube([1, 1, 5.4]);

translate([21, 0, 0]) cube([1, 1, 5.2]);

translate([22, 0, 0]) cube([1, 1, 4.9]);

translate([23, 0, 0]) cube([1, 1, 4.608888888888888]);

translate([24, 0, 0]) cube([1, 1, 3.4420106836914663]);

translate([25, 0, 0]) cube([1, 1, 4.377318494762984]);

translate([26, 0, 0]) cube([1, 1, 4.321574810063708]);

translate([27, 0, 0]) cube([1, 1, 4.308060369182593]);

translate([28, 0, 0]) cube([1, 1, 4.410666666666667]);

translate([29, 0, 0]) cube([1, 1, 4.653333333333333]);

translate([30, 0, 0]) cube([1, 1, 3.6907071806500378]);

translate([31, 0, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.14831158427809]);

translate([2, 1, 0]) cube([1, 1, 4.773432209547884]);

translate([3, 1, 0]) cube([1, 1, 4.5617701778532]);

translate([4, 1, 0]) cube([1, 1, 4.298311688171186]);

translate([5, 1, 0]) cube([1, 1, 4.1630181087405616]);

translate([6, 1, 0]) cube([1, 1, 4.105611759226966]);

translate([7, 1, 0]) cube([1, 1, 4.112950624356194]);

translate([8, 1, 0]) cube([1, 1, 4.172850975480448]);

translate([9, 1, 0]) cube([1, 1, 4.240947234457486]);

translate([10, 1, 0]) cube([1, 1, 4.237086082143624]);

translate([11, 1, 0]) cube([1, 1, 4.137300783230206]);

translate([12, 1, 0]) cube([1, 1, 4.135747007613231]);

translate([13, 1, 0]) cube([1, 1, 4.149001923744886]);

translate([14, 1, 0]) cube([1, 1, 4.17456284495418]);

translate([15, 1, 0]) cube([1, 1, 4.330912654213008]);

translate([16, 1, 0]) cube([1, 1, 4.538620555015658]);

translate([17, 1, 0]) cube([1, 1, 4.667710182485693]);

translate([18, 1, 0]) cube([1, 1, 4.867975380628441]);

translate([19, 1, 0]) cube([1, 1, 4.955199222546161]);

translate([20, 1, 0]) cube([1, 1, 4.8110398445092315]);

translate([21, 1, 0]) cube([1, 1, 4.702207968901846]);

translate([22, 1, 0]) cube([1, 1, 4.502219371558147]);

translate([23, 1, 0]) cube([1, 1, 4.40925878414858]);

translate([24, 1, 0]) cube([1, 1, 4.26869506165641]);

translate([25, 1, 0]) cube([1, 1, 4.07795808590145]);

translate([26, 1, 0]) cube([1, 1, 3.8720981331009465]);

translate([27, 1, 0]) cube([1, 1, 3.76178295266803]);

translate([28, 1, 0]) cube([1, 1, 3.9458429430731026]);

translate([29, 1, 0]) cube([1, 1, 4.068265457294029]);

translate([30, 1, 0]) cube([1, 1, 4.271307029478457]);

translate([31, 1, 0]) cube([1, 1, 4.377801360544217]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

translate([2, 2, 0]) cube([1, 1, 5.468747298135508]);

translate([3, 2, 0]) cube([1, 1, 5.180333667887322]);

translate([4, 2, 0]) cube([1, 1, 4.886337717366359]);

translate([5, 2, 0]) cube([1, 1, 4.549681963531376]);

translate([6, 2, 0]) cube([1, 1, 4.436533595805236]);

translate([7, 2, 0]) cube([1, 1, 4.4288145289130725]);

translate([8, 2, 0]) cube([1, 1, 4.371705245682761]);

translate([9, 2, 0]) cube([1, 1, 4.275859696199747]);

translate([10, 2, 0]) cube([1, 1, 4.164116575510311]);

translate([11, 2, 0]) cube([1, 1, 4.144552292566834]);

translate([12, 2, 0]) cube([1, 1, 4.1456254665947885]);

translate([13, 2, 0]) cube([1, 1, 4.1578504110871455]);

translate([14, 2, 0]) cube([1, 1, 4.19999311017136]);

translate([15, 2, 0]) cube([1, 1, 4.227699714552241]);

translate([16, 2, 0]) cube([1, 1, 4.3112770519513]);

translate([17, 2, 0]) cube([1, 1, 4.377282288947535]);

translate([18, 2, 0]) cube([1, 1, 4.440034565667437]);

translate([19, 2, 0]) cube([1, 1, 4.526178598423496]);

translate([20, 2, 0]) cube([1, 1, 4.418925126876148]);

translate([21, 2, 0]) cube([1, 1, 4.306878462369074]);

translate([22, 2, 0]) cube([1, 1, 4.204112917395529]);

translate([23, 2, 0]) cube([1, 1, 4.034216500834743]);

translate([24, 2, 0]) cube([1, 1, 4.029787043284261]);

translate([25, 2, 0]) cube([1, 1, 3.9323696613819403]);

translate([26, 2, 0]) cube([1, 1, 3.666673594784613]);

translate([27, 2, 0]) cube([1, 1, 3.6157133165229713]);

translate([28, 2, 0]) cube([1, 1, 3.5968083226021905]);

translate([29, 2, 0]) cube([1, 1, 3.844328880879674]);

translate([30, 2, 0]) cube([1, 1, 3.936228974552784]);

translate([31, 2, 0]) cube([1, 1, 3.861779121525153]);

translate([0, 3, 0]) cube([1, 1, 6.9024]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

translate([3, 3, 0]) cube([1, 1, 4.691106238097387]);

translate([4, 3, 0]) cube([1, 1, 5.476230616594759]);

translate([5, 3, 0]) cube([1, 1, 5.149151565039433]);

translate([6, 3, 0]) cube([1, 1, 5.036689921919717]);

translate([7, 3, 0]) cube([1, 1, 4.928879765697135]);

translate([8, 3, 0]) cube([1, 1, 4.714519845194735]);

translate([9, 3, 0]) cube([1, 1, 3.4571549967859507]);

translate([10, 3, 0]) cube([1, 1, 4.224368153297298]);

translate([11, 3, 0]) cube([1, 1, 4.163939214454636]);

translate([12, 3, 0]) cube([1, 1, 4.2368389051955]);

translate([13, 3, 0]) cube([1, 1, 4.32969635020042]);

translate([14, 3, 0]) cube([1, 1, 4.3328789528598755]);

translate([15, 3, 0]) cube([1, 1, 3.4759999925652294]);

translate([16, 3, 0]) cube([1, 1, 4.343532583626254]);

translate([17, 3, 0]) cube([1, 1, 4.417066204160352]);

translate([18, 3, 0]) cube([1, 1, 4.417844790462958]);

translate([19, 3, 0]) cube([1, 1, 4.339063225545685]);

translate([20, 3, 0]) cube([1, 1, 4.225320191086084]);

translate([21, 3, 0]) cube([1, 1, 3.083339210646784]);

translate([22, 3, 0]) cube([1, 1, 3.8805914248008713]);

translate([23, 3, 0]) cube([1, 1, 3.659151651904459]);

translate([24, 3, 0]) cube([1, 1, 3.641124991959569]);

translate([25, 3, 0]) cube([1, 1, 3.6319418235508274]);

translate([26, 3, 0]) cube([1, 1, 3.550251969139314]);

translate([27, 3, 0]) cube([1, 1, 3.10495393661728]);

translate([28, 3, 0]) cube([1, 1, 3.553403389171286]);

translate([29, 3, 0]) cube([1, 1, 3.6330906283555513]);

translate([30, 3, 0]) cube([1, 1, 3.7260273560311306]);

translate([31, 3, 0]) cube([1, 1, 3.668543276057479]);

translate([0, 4, 0]) cube([1, 1, 7.212]);

translate([1, 4, 0]) cube([1, 1, 6.641129030544832]);

color([0,1,0])
translate([2, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.44946960188807]);

translate([7, 4, 0]) cube([1, 1, 5.3361572662876595]);

translate([8, 4, 0]) cube([1, 1, 5.0220820430423885]);

translate([9, 4, 0]) cube([1, 1, 4.660191952669777]);

translate([10, 4, 0]) cube([1, 1, 4.487527768605827]);

translate([11, 4, 0]) cube([1, 1, 4.484704354572086]);

translate([12, 4, 0]) cube([1, 1, 4.645220170333306]);

translate([13, 4, 0]) cube([1, 1, 4.824573654814116]);

translate([14, 4, 0]) cube([1, 1, 4.816582049291604]);

translate([15, 4, 0]) cube([1, 1, 4.707567167569494]);

translate([16, 4, 0]) cube([1, 1, 4.705085410304985]);

translate([17, 4, 0]) cube([1, 1, 4.707592338345963]);

translate([18, 4, 0]) cube([1, 1, 4.4177142757929495]);

translate([19, 4, 0]) cube([1, 1, 4.160635196689105]);

translate([20, 4, 0]) cube([1, 1, 4.0898607066100405]);

translate([21, 4, 0]) cube([1, 1, 3.9658879959459012]);

translate([22, 4, 0]) cube([1, 1, 3.7043633896332335]);

translate([23, 4, 0]) cube([1, 1, 3.641620770227154]);

translate([24, 4, 0]) cube([1, 1, 3.628879519813921]);

translate([25, 4, 0]) cube([1, 1, 3.597138666688292]);

translate([26, 4, 0]) cube([1, 1, 3.548814282463699]);

translate([27, 4, 0]) cube([1, 1, 3.5488076800171706]);

translate([28, 4, 0]) cube([1, 1, 3.5513684442944986]);

translate([29, 4, 0]) cube([1, 1, 3.570697030256654]);

translate([30, 4, 0]) cube([1, 1, 3.65802671174822]);

translate([31, 4, 0]) cube([1, 1, 3.6693332458807033]);

translate([0, 5, 0]) cube([1, 1, 7.460000000000001]);

translate([1, 5, 0]) cube([1, 1, 6.982498179059138]);

translate([2, 5, 0]) cube([1, 1, 6.647115437648365]);

color([0,1,0])
translate([3, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

translate([8, 5, 0]) cube([1, 1, 5.338691418389702]);

translate([9, 5, 0]) cube([1, 1, 4.970251880092439]);

translate([10, 5, 0]) cube([1, 1, 4.795222628391738]);

translate([11, 5, 0]) cube([1, 1, 4.9795588745119]);

translate([12, 5, 0]) cube([1, 1, 5.169082882410519]);

translate([13, 5, 0]) cube([1, 1, 5.35288544301954]);

translate([14, 5, 0]) cube([1, 1, 5.312938279458266]);

translate([15, 5, 0]) cube([1, 1, 5.1050482022373975]);

translate([16, 5, 0]) cube([1, 1, 5.102178876889269]);

translate([17, 5, 0]) cube([1, 1, 4.9021483545472915]);

translate([18, 5, 0]) cube([1, 1, 4.548267243802699]);

translate([19, 5, 0]) cube([1, 1, 4.092044348971624]);

translate([20, 5, 0]) cube([1, 1, 3.899527133502556]);

translate([21, 5, 0]) cube([1, 1, 3.7879512482649793]);

translate([22, 5, 0]) cube([1, 1, 3.696538314249148]);

translate([23, 5, 0]) cube([1, 1, 3.6561074495654684]);

translate([24, 5, 0]) cube([1, 1, 3.631951400833987]);

translate([25, 5, 0]) cube([1, 1, 3.6026321706178113]);

translate([26, 5, 0]) cube([1, 1, 3.5701984408250262]);

translate([27, 5, 0]) cube([1, 1, 3.5576761052223334]);

translate([28, 5, 0]) cube([1, 1, 3.559942791716171]);

translate([29, 5, 0]) cube([1, 1, 3.5912086248516886]);

translate([30, 5, 0]) cube([1, 1, 3.684529579484855]);

translate([31, 5, 0]) cube([1, 1, 3.7041077291042592]);

translate([0, 6, 0]) cube([1, 1, 6.676760205190225]);

translate([1, 6, 0]) cube([1, 1, 7.262776311845374]);

translate([2, 6, 0]) cube([1, 1, 7.036106117841845]);

translate([3, 6, 0]) cube([1, 1, 6.8146990859202665]);

translate([4, 6, 0]) cube([1, 1, 6.515300393454245]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

translate([6, 6, 0]) cube([1, 1, 5.087382556529738]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.267327866207214]);

translate([10, 6, 0]) cube([1, 1, 5.190247132448119]);

translate([11, 6, 0]) cube([1, 1, 5.373504763332343]);

translate([12, 6, 0]) cube([1, 1, 4.560663498827716]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([16, 6, 0]) cube([1, 1, 5.305729086062171]);

translate([17, 6, 0]) cube([1, 1, 5.004982172925248]);

translate([18, 6, 0]) cube([1, 1, 3.5907616454218916]);

translate([19, 6, 0]) cube([1, 1, 4.08968029758756]);

translate([20, 6, 0]) cube([1, 1, 3.863294511278473]);

translate([21, 6, 0]) cube([1, 1, 3.7729871671249926]);

translate([22, 6, 0]) cube([1, 1, 3.728510711562183]);

translate([23, 6, 0]) cube([1, 1, 3.695531295179835]);

translate([24, 6, 0]) cube([1, 1, 2.990542325725971]);

translate([25, 6, 0]) cube([1, 1, 3.7354795523817406]);

translate([26, 6, 0]) cube([1, 1, 3.8286526817868767]);

translate([27, 6, 0]) cube([1, 1, 3.9179249761131465]);

translate([28, 6, 0]) cube([1, 1, 3.840259598405108]);

translate([29, 6, 0]) cube([1, 1, 3.8362809950577947]);

translate([30, 6, 0]) cube([1, 1, 3.04096518945188]);

translate([31, 6, 0]) cube([1, 1, 3.8100020038532496]);

translate([0, 7, 0]) cube([1, 1, 8.0]);

translate([1, 7, 0]) cube([1, 1, 7.551485714285714]);

translate([2, 7, 0]) cube([1, 1, 7.318903781449087]);

translate([3, 7, 0]) cube([1, 1, 7.01886280309865]);

translate([4, 7, 0]) cube([1, 1, 6.816318969234825]);

translate([5, 7, 0]) cube([1, 1, 6.537462043774948]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([16, 7, 0]) cube([1, 1, 5.421985082246095]);

translate([17, 7, 0]) cube([1, 1, 4.935954349614939]);

translate([18, 7, 0]) cube([1, 1, 4.625811735754714]);

translate([19, 7, 0]) cube([1, 1, 4.288057027695792]);

translate([20, 7, 0]) cube([1, 1, 3.9533389973856496]);

translate([21, 7, 0]) cube([1, 1, 3.8880686239781492]);

translate([22, 7, 0]) cube([1, 1, 3.8797330502499543]);

translate([23, 7, 0]) cube([1, 1, 4.02256842153762]);

translate([24, 7, 0]) cube([1, 1, 4.0195903641662385]);

translate([25, 7, 0]) cube([1, 1, 4.124063219548062]);

translate([26, 7, 0]) cube([1, 1, 4.333980394905072]);

translate([27, 7, 0]) cube([1, 1, 4.431739266674478]);

translate([28, 7, 0]) cube([1, 1, 4.341830199589903]);

translate([29, 7, 0]) cube([1, 1, 4.237405825792658]);

translate([30, 7, 0]) cube([1, 1, 4.127640416137278]);

translate([31, 7, 0]) cube([1, 1, 4.048112345740376]);

translate([0, 8, 0]) cube([1, 1, 7.9004]);

translate([1, 8, 0]) cube([1, 1, 7.5106971428571425]);

translate([2, 8, 0]) cube([1, 1, 7.315134715363307]);

translate([3, 8, 0]) cube([1, 1, 7.0181774291977215]);

translate([4, 8, 0]) cube([1, 1, 6.850433246012995]);

translate([5, 8, 0]) cube([1, 1, 6.661858395036442]);

translate([6, 8, 0]) cube([1, 1, 6.567807660325272]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([16, 8, 0]) cube([1, 1, 5.469387152030538]);

translate([17, 8, 0]) cube([1, 1, 5.041733916703495]);

translate([18, 8, 0]) cube([1, 1, 4.746388250879732]);

translate([19, 8, 0]) cube([1, 1, 4.483944632183269]);

translate([20, 8, 0]) cube([1, 1, 4.2489411033335545]);

translate([21, 8, 0]) cube([1, 1, 4.1479234137252785]);

translate([22, 8, 0]) cube([1, 1, 4.290131229532929]);

translate([23, 8, 0]) cube([1, 1, 4.522158482512254]);

translate([24, 8, 0]) cube([1, 1, 4.607479975204476]);

translate([25, 8, 0]) cube([1, 1, 4.617732226085608]);

translate([26, 8, 0]) cube([1, 1, 4.661123504851508]);

translate([27, 8, 0]) cube([1, 1, 4.759306981257254]);

translate([28, 8, 0]) cube([1, 1, 4.67000511778143]);

translate([29, 8, 0]) cube([1, 1, 4.5480996334656325]);

translate([30, 8, 0]) cube([1, 1, 4.527094179939704]);

translate([31, 8, 0]) cube([1, 1, 4.425602443326859]);

translate([0, 9, 0]) cube([1, 1, 7.9016]);

translate([1, 9, 0]) cube([1, 1, 7.408222614717413]);

translate([2, 9, 0]) cube([1, 1, 7.114986305075847]);

translate([3, 9, 0]) cube([1, 1, 5.959022086360551]);

translate([4, 9, 0]) cube([1, 1, 6.737275944878789]);

translate([5, 9, 0]) cube([1, 1, 6.683827097482415]);

translate([6, 9, 0]) cube([1, 1, 6.667779286491595]);

translate([7, 9, 0]) cube([1, 1, 6.707348423681881]);

translate([8, 9, 0]) cube([1, 1, 6.505110688608988]);

translate([9, 9, 0]) cube([1, 1, 5.198277253359573]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

translate([15, 9, 0]) cube([1, 1, 4.966744296551454]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 5.1457541728094185]);

translate([18, 9, 0]) cube([1, 1, 4.938780713598091]);

translate([19, 9, 0]) cube([1, 1, 4.758049867609738]);

translate([20, 9, 0]) cube([1, 1, 4.571033682415404]);

translate([21, 9, 0]) cube([1, 1, 3.53575679796076]);

translate([22, 9, 0]) cube([1, 1, 4.725958529464092]);

translate([23, 9, 0]) cube([1, 1, 5.012498463514085]);

translate([24, 9, 0]) cube([1, 1, 5.107712602485434]);

translate([25, 9, 0]) cube([1, 1, 5.106258909562094]);

translate([26, 9, 0]) cube([1, 1, 5.011737784720748]);

translate([27, 9, 0]) cube([1, 1, 3.881678801042036]);

translate([28, 9, 0]) cube([1, 1, 4.878523337876313]);

translate([29, 9, 0]) cube([1, 1, 4.852616368202988]);

translate([30, 9, 0]) cube([1, 1, 4.9243950940493955]);

translate([31, 9, 0]) cube([1, 1, 4.925318057617813]);

translate([0, 10, 0]) cube([1, 1, 8.008]);

translate([1, 10, 0]) cube([1, 1, 7.512193316012507]);

translate([2, 10, 0]) cube([1, 1, 7.1268770814987965]);

translate([3, 10, 0]) cube([1, 1, 6.857477526338791]);

translate([4, 10, 0]) cube([1, 1, 6.769801139148485]);

translate([5, 10, 0]) cube([1, 1, 6.734918489443528]);

translate([6, 10, 0]) cube([1, 1, 6.827661219382685]);

translate([7, 10, 0]) cube([1, 1, 6.9113916786240726]);

translate([8, 10, 0]) cube([1, 1, 6.71192403080682]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 5.153686578550411]);

translate([18, 10, 0]) cube([1, 1, 4.9756869329627635]);

translate([19, 10, 0]) cube([1, 1, 4.882163113586936]);

translate([20, 10, 0]) cube([1, 1, 4.786279234145951]);

translate([21, 10, 0]) cube([1, 1, 4.7786762010304615]);

translate([22, 10, 0]) cube([1, 1, 5.1213010229076446]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 10, 0]) cube([1, 1, 6]);

translate([26, 10, 0]) cube([1, 1, 5.404648173194213]);

translate([27, 10, 0]) cube([1, 1, 5.204441803800515]);

translate([28, 10, 0]) cube([1, 1, 5.131323263981747]);

translate([29, 10, 0]) cube([1, 1, 5.143411254983223]);

translate([30, 10, 0]) cube([1, 1, 5.339835758998164]);

translate([31, 10, 0]) cube([1, 1, 5.437423435855549]);

translate([0, 11, 0]) cube([1, 1, 8.2]);

translate([1, 11, 0]) cube([1, 1, 7.75136658006254]);

translate([2, 11, 0]) cube([1, 1, 7.249423247383935]);

translate([3, 11, 0]) cube([1, 1, 6.970816841762451]);

translate([4, 11, 0]) cube([1, 1, 6.960071628277955]);

translate([5, 11, 0]) cube([1, 1, 7.047172668498032]);

translate([6, 11, 0]) cube([1, 1, 7.242102094745661]);

translate([7, 11, 0]) cube([1, 1, 7.137639655768738]);

translate([8, 11, 0]) cube([1, 1, 6.725792649362848]);

translate([9, 11, 0]) cube([1, 1, 6.524000769512572]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

translate([17, 11, 0]) cube([1, 1, 5.159705264746288]);

translate([18, 11, 0]) cube([1, 1, 5.091139689146962]);

translate([19, 11, 0]) cube([1, 1, 4.988726673774866]);

translate([20, 11, 0]) cube([1, 1, 4.899098170777345]);

translate([21, 11, 0]) cube([1, 1, 4.901920112444794]);

translate([22, 11, 0]) cube([1, 1, 5.238213718497551]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 7.1665962229141735]);

translate([1, 12, 0]) cube([1, 1, 7.770710656274171]);

translate([2, 12, 0]) cube([1, 1, 7.364813952146957]);

translate([3, 12, 0]) cube([1, 1, 7.250517922363091]);

translate([4, 12, 0]) cube([1, 1, 7.3124696313369375]);

translate([5, 12, 0]) cube([1, 1, 7.431808315697063]);

translate([6, 12, 0]) cube([1, 1, 6.3719091595278075]);

translate([7, 12, 0]) cube([1, 1, 7.243566576735192]);

translate([8, 12, 0]) cube([1, 1, 6.926199153149833]);

translate([9, 12, 0]) cube([1, 1, 6.622506645387097]);

translate([10, 12, 0]) cube([1, 1, 6.609580599960828]);

translate([11, 12, 0]) cube([1, 1, 6.603567988659288]);

translate([12, 12, 0]) cube([1, 1, 5.39919379251846]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

translate([17, 12, 0]) cube([1, 1, 5.350231785871753]);

translate([18, 12, 0]) cube([1, 1, 4.34061973305433]);

translate([19, 12, 0]) cube([1, 1, 5.09151371207657]);

translate([20, 12, 0]) cube([1, 1, 5.014355283440298]);

translate([21, 12, 0]) cube([1, 1, 5.061663530832129]);

translate([22, 12, 0]) cube([1, 1, 5.345580557667219]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

translate([24, 12, 0]) cube([1, 1, 4.968875463778798]);

color([0,1,0])
translate([25, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 12, 0]) cube([1, 1, 6]);

translate([30, 12, 0]) cube([1, 1, 5.049981278770288]);

color([0,1,0])
translate([31, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 8.15511111111111]);

translate([1, 13, 0]) cube([1, 1, 7.769407875466351]);

translate([2, 13, 0]) cube([1, 1, 7.546814366476203]);

translate([3, 13, 0]) cube([1, 1, 7.5209563310531555]);

translate([4, 13, 0]) cube([1, 1, 7.605107972375392]);

translate([5, 13, 0]) cube([1, 1, 7.604475538692451]);

translate([6, 13, 0]) cube([1, 1, 7.603342119174641]);

translate([7, 13, 0]) cube([1, 1, 7.3342632733437085]);

translate([8, 13, 0]) cube([1, 1, 7.015526260314458]);

translate([9, 13, 0]) cube([1, 1, 6.816113589034763]);

translate([10, 13, 0]) cube([1, 1, 6.806394929855823]);

translate([11, 13, 0]) cube([1, 1, 6.802887836356923]);

translate([12, 13, 0]) cube([1, 1, 6.603161754587604]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

translate([18, 13, 0]) cube([1, 1, 5.429989474476088]);

translate([19, 13, 0]) cube([1, 1, 5.334862100186598]);

translate([20, 13, 0]) cube([1, 1, 5.256609400840736]);

translate([21, 13, 0]) cube([1, 1, 5.264545857923164]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 13, 0]) cube([1, 1, 6]);

translate([27, 13, 0]) cube([1, 1, 6.605693129691618]);

translate([28, 13, 0]) cube([1, 1, 6.700296344287274]);

translate([29, 13, 0]) cube([1, 1, 6.6002575515803015]);

color([0,1,0])
translate([30, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 8.208888888888888]);

translate([1, 14, 0]) cube([1, 1, 7.821544973544974]);

translate([2, 14, 0]) cube([1, 1, 7.7159527948990485]);

translate([3, 14, 0]) cube([1, 1, 7.609641165720266]);

translate([4, 14, 0]) cube([1, 1, 7.606309024741714]);

translate([5, 14, 0]) cube([1, 1, 7.510958041989369]);

translate([6, 14, 0]) cube([1, 1, 7.4078911879585485]);

translate([7, 14, 0]) cube([1, 1, 7.207582763281769]);

translate([8, 14, 0]) cube([1, 1, 7.0099680205632895]);

translate([9, 14, 0]) cube([1, 1, 7.007831382333144]);

translate([10, 14, 0]) cube([1, 1, 7.0049295399048335]);

translate([11, 14, 0]) cube([1, 1, 6.80878656905117]);

translate([12, 14, 0]) cube([1, 1, 6.606043462268891]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

translate([14, 14, 0]) cube([1, 1, 6.537881626034788]);

translate([15, 14, 0]) cube([1, 1, 6.534965711705588]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 14, 0]) cube([1, 1, 6]);

translate([26, 14, 0]) cube([1, 1, 6.5412331387918705]);

translate([27, 14, 0]) cube([1, 1, 6.900529100529101]);

translate([28, 14, 0]) cube([1, 1, 7.0]);

translate([29, 14, 0]) cube([1, 1, 6.801248965194543]);

color([0,1,0])
translate([30, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 8.101777777777777]);

translate([1, 15, 0]) cube([1, 1, 7.804763920382968]);

translate([2, 15, 0]) cube([1, 1, 7.707043614804498]);

translate([3, 15, 0]) cube([1, 1, 6.458445703584462]);

translate([4, 15, 0]) cube([1, 1, 7.3480957924801595]);

translate([5, 15, 0]) cube([1, 1, 7.123793666350397]);

translate([6, 15, 0]) cube([1, 1, 6.910045131854517]);

translate([7, 15, 0]) cube([1, 1, 6.821855423161063]);

translate([8, 15, 0]) cube([1, 1, 6.916379033698548]);

translate([9, 15, 0]) cube([1, 1, 5.847298718979142]);

translate([10, 15, 0]) cube([1, 1, 6.948105994723576]);

translate([11, 15, 0]) cube([1, 1, 6.721653854042446]);

translate([12, 15, 0]) cube([1, 1, 6.5363173054787405]);

translate([13, 15, 0]) cube([1, 1, 6.532555640112929]);

translate([14, 15, 0]) cube([1, 1, 6.544392464352696]);

translate([15, 15, 0]) cube([1, 1, 5.460360834594905]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

translate([21, 15, 0]) cube([1, 1, 4.732711689846403]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 15, 0]) cube([1, 1, 6]);

translate([26, 15, 0]) cube([1, 1, 6.548451734805635]);

color([0,1,0])
translate([27, 15, 0]) cube([1, 1, 6]);

translate([28, 15, 0]) cube([1, 1, 6.903703703703704]);

translate([29, 15, 0]) cube([1, 1, 6.804923874311629]);

color([0,1,0])
translate([30, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 15, 0]) cube([1, 1, 6]);

translate([0, 16, 0]) cube([1, 1, 7.701635424540186]);

translate([1, 16, 0]) cube([1, 1, 7.412187004643942]);

translate([2, 16, 0]) cube([1, 1, 7.358006284087286]);

translate([3, 16, 0]) cube([1, 1, 7.260449547401166]);

translate([4, 16, 0]) cube([1, 1, 7.069207001426568]);

translate([5, 16, 0]) cube([1, 1, 6.73686446840391]);

translate([6, 16, 0]) cube([1, 1, 6.522752775154199]);

translate([7, 16, 0]) cube([1, 1, 6.525737511341995]);

translate([8, 16, 0]) cube([1, 1, 6.653122870163796]);

translate([9, 16, 0]) cube([1, 1, 6.760725904559164]);

translate([10, 16, 0]) cube([1, 1, 6.8464471688979565]);

translate([11, 16, 0]) cube([1, 1, 6.626839995987334]);

translate([12, 16, 0]) cube([1, 1, 6.548760880203147]);

translate([13, 16, 0]) cube([1, 1, 6.5389619358057045]);

translate([14, 16, 0]) cube([1, 1, 6.552300929276652]);

translate([15, 16, 0]) cube([1, 1, 6.607673919475408]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 16, 0]) cube([1, 1, 6]);

translate([27, 16, 0]) cube([1, 1, 6.550093738499611]);

translate([28, 16, 0]) cube([1, 1, 6.735624045536581]);

translate([29, 16, 0]) cube([1, 1, 6.607375270591986]);

color([0,1,0])
translate([30, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 16, 0]) cube([1, 1, 6]);

translate([0, 17, 0]) cube([1, 1, 7.103455607296033]);

translate([1, 17, 0]) cube([1, 1, 6.933473043963564]);

translate([2, 17, 0]) cube([1, 1, 6.941488270874451]);

translate([3, 17, 0]) cube([1, 1, 6.9387489456605795]);

translate([4, 17, 0]) cube([1, 1, 6.734417842203419]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

translate([10, 17, 0]) cube([1, 1, 6.536292839469577]);

translate([11, 17, 0]) cube([1, 1, 6.617821500185067]);

translate([12, 17, 0]) cube([1, 1, 6.560579161672399]);

translate([13, 17, 0]) cube([1, 1, 6.6420671653676795]);

translate([14, 17, 0]) cube([1, 1, 6.615760874932457]);

translate([15, 17, 0]) cube([1, 1, 6.607102308718406]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

translate([20, 17, 0]) cube([1, 1, 5.490944536055746]);

translate([21, 17, 0]) cube([1, 1, 5.490950719356277]);

color([0,1,0])
translate([22, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 17, 0]) cube([1, 1, 6]);

translate([0, 18, 0]) cube([1, 1, 5.923713683292775]);

translate([1, 18, 0]) cube([1, 1, 6.706462044375832]);

translate([2, 18, 0]) cube([1, 1, 6.669194033889575]);

translate([3, 18, 0]) cube([1, 1, 6.536769818525606]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

translate([6, 18, 0]) cube([1, 1, 5.226860855108691]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

translate([13, 18, 0]) cube([1, 1, 6.805555555555555]);

translate([14, 18, 0]) cube([1, 1, 6.9]);

translate([15, 18, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

translate([18, 18, 0]) cube([1, 1, 4.816480888682141]);

translate([19, 18, 0]) cube([1, 1, 5.493449592310512]);

translate([20, 18, 0]) cube([1, 1, 5.490992294891691]);

translate([21, 18, 0]) cube([1, 1, 5.491085418335374]);

translate([22, 18, 0]) cube([1, 1, 5.491363811711806]);

color([0,1,0])
translate([23, 18, 0]) cube([1, 1, 6]);

translate([24, 18, 0]) cube([1, 1, 4.901864014244318]);

color([0,1,0])
translate([25, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 18, 0]) cube([1, 1, 6]);

translate([30, 18, 0]) cube([1, 1, 5.089052315913987]);

color([0,1,0])
translate([31, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 6.892894050335845]);

translate([1, 19, 0]) cube([1, 1, 6.6940330994706825]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

translate([13, 19, 0]) cube([1, 1, 6.9]);

translate([14, 19, 0]) cube([1, 1, 7.1]);

translate([15, 19, 0]) cube([1, 1, 6.9]);

translate([16, 19, 0]) cube([1, 1, 6.510000000000001]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);

translate([20, 19, 0]) cube([1, 1, 5.491408195926252]);

translate([21, 19, 0]) cube([1, 1, 5.491677558466007]);

translate([22, 19, 0]) cube([1, 1, 5.494155242747707]);

color([0,1,0])
translate([23, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 19, 0]) cube([1, 1, 6]);

translate([0, 20, 0]) cube([1, 1, 7.013333333333334]);

translate([1, 20, 0]) cube([1, 1, 6.825578810067168]);

color([0,1,0])
translate([2, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

translate([13, 20, 0]) cube([1, 1, 6.8]);

translate([14, 20, 0]) cube([1, 1, 7.0]);

translate([15, 20, 0]) cube([1, 1, 6.81]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 20, 0]) cube([1, 1, 6]);

translate([31, 20, 0]) cube([1, 1, 5.423732186704469]);

translate([0, 21, 0]) cube([1, 1, 7.1]);

translate([1, 21, 0]) cube([1, 1, 6.905]);

color([0,1,0])
translate([2, 21, 0]) cube([1, 1, 6]);

translate([3, 21, 0]) cube([1, 1, 4.858028717876117]);

color([0,1,0])
translate([4, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 21, 0]) cube([1, 1, 6]);

translate([9, 21, 0]) cube([1, 1, 4.95838611973421]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

translate([13, 21, 0]) cube([1, 1, 6.706484634148984]);

translate([14, 21, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([15, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 21, 0]) cube([1, 1, 6]);

translate([21, 21, 0]) cube([1, 1, 4.568987893869035]);

color([0,1,0])
translate([22, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 21, 0]) cube([1, 1, 6]);

translate([27, 21, 0]) cube([1, 1, 4.71240017533625]);

color([0,1,0])
translate([28, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 21, 0]) cube([1, 1, 6]);

translate([30, 21, 0]) cube([1, 1, 5.432910642707396]);

translate([31, 21, 0]) cube([1, 1, 5.214543005102105]);

translate([0, 22, 0]) cube([1, 1, 7.1]);

translate([1, 22, 0]) cube([1, 1, 6.900833333333334]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

translate([13, 22, 0]) cube([1, 1, 6.722248762273508]);

translate([14, 22, 0]) cube([1, 1, 6.807195947161933]);

translate([15, 22, 0]) cube([1, 1, 6.603520328498242]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 22, 0]) cube([1, 1, 6]);

translate([30, 22, 0]) cube([1, 1, 5.2254378106992085]);

translate([31, 22, 0]) cube([1, 1, 5.005438914399927]);

translate([0, 23, 0]) cube([1, 1, 6.9002083333333335]);

translate([1, 23, 0]) cube([1, 1, 6.708506944444444]);

color([0,1,0])
translate([2, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 23, 0]) cube([1, 1, 6]);

translate([12, 23, 0]) cube([1, 1, 6.747709838713588]);

translate([13, 23, 0]) cube([1, 1, 6.937634781803878]);

translate([14, 23, 0]) cube([1, 1, 7.0055409011677225]);

translate([15, 23, 0]) cube([1, 1, 6.702842672720387]);

color([0,1,0])
translate([16, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 23, 0]) cube([1, 1, 6]);

translate([29, 23, 0]) cube([1, 1, 5.324413194288492]);

translate([30, 23, 0]) cube([1, 1, 5.0379863739425526]);

translate([31, 23, 0]) cube([1, 1, 4.881853420945985]);

color([0,1,0])
translate([0, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 24, 0]) cube([1, 1, 6]);

translate([6, 24, 0]) cube([1, 1, 5.069407671772692]);

color([0,1,0])
translate([7, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 24, 0]) cube([1, 1, 6]);

translate([11, 24, 0]) cube([1, 1, 6.745708001589579]);

color([0,1,0])
translate([12, 24, 0]) cube([1, 1, 6]);

translate([13, 24, 0]) cube([1, 1, 7.104837490551776]);

translate([14, 24, 0]) cube([1, 1, 7.104319187992657]);

translate([15, 24, 0]) cube([1, 1, 6.6028457749943]);

color([0,1,0])
translate([16, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 24, 0]) cube([1, 1, 6]);

translate([18, 24, 0]) cube([1, 1, 5.148619390866058]);

color([0,1,0])
translate([19, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 24, 0]) cube([1, 1, 6]);

translate([24, 24, 0]) cube([1, 1, 4.659953105885617]);

color([0,1,0])
translate([25, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 24, 0]) cube([1, 1, 6]);

translate([27, 24, 0]) cube([1, 1, 5.474240578039972]);

translate([28, 24, 0]) cube([1, 1, 5.34183987528984]);

translate([29, 24, 0]) cube([1, 1, 5.066884743537563]);

translate([30, 24, 0]) cube([1, 1, 4.407006123878101]);

translate([31, 24, 0]) cube([1, 1, 4.808884591874869]);

color([0,1,0])
translate([0, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 25, 0]) cube([1, 1, 6]);

translate([10, 25, 0]) cube([1, 1, 6.526637056172215]);

translate([11, 25, 0]) cube([1, 1, 6.938775510204082]);

translate([12, 25, 0]) cube([1, 1, 7.2]);

translate([13, 25, 0]) cube([1, 1, 7.2]);

translate([14, 25, 0]) cube([1, 1, 7.00152611309074]);

translate([15, 25, 0]) cube([1, 1, 6.501831005770915]);

color([0,1,0])
translate([16, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 25, 0]) cube([1, 1, 6]);

translate([27, 25, 0]) cube([1, 1, 5.477524634717872]);

translate([28, 25, 0]) cube([1, 1, 5.306716553711331]);

translate([29, 25, 0]) cube([1, 1, 5.075490746305029]);

translate([30, 25, 0]) cube([1, 1, 4.849855282716158]);

translate([31, 25, 0]) cube([1, 1, 4.812726052088921]);

color([0,1,0])
translate([0, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 26, 0]) cube([1, 1, 6]);

translate([10, 26, 0]) cube([1, 1, 6.708792472015263]);

translate([11, 26, 0]) cube([1, 1, 6.907256235827664]);

translate([12, 26, 0]) cube([1, 1, 7.004761904761905]);

translate([13, 26, 0]) cube([1, 1, 6.901257603570528]);

translate([14, 26, 0]) cube([1, 1, 6.600463952776877]);

color([0,1,0])
translate([15, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 26, 0]) cube([1, 1, 6]);

translate([28, 26, 0]) cube([1, 1, 5.468748534752445]);

translate([29, 26, 0]) cube([1, 1, 5.324141014904798]);

translate([30, 26, 0]) cube([1, 1, 5.042223372702063]);

translate([31, 26, 0]) cube([1, 1, 4.850025926874688]);

color([0,1,0])
translate([0, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 27, 0]) cube([1, 1, 6]);

translate([3, 27, 0]) cube([1, 1, 4.984540960696431]);

color([0,1,0])
translate([4, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 27, 0]) cube([1, 1, 6]);

translate([9, 27, 0]) cube([1, 1, 5.473276321176619]);

translate([10, 27, 0]) cube([1, 1, 6.709445879085446]);

translate([11, 27, 0]) cube([1, 1, 6.708171792810095]);

translate([12, 27, 0]) cube([1, 1, 6.604289507394038]);

translate([13, 27, 0]) cube([1, 1, 6.50215459370067]);

color([0,1,0])
translate([14, 27, 0]) cube([1, 1, 6]);

translate([15, 27, 0]) cube([1, 1, 5.085351646649517]);

color([0,1,0])
translate([16, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 27, 0]) cube([1, 1, 6]);

translate([21, 27, 0]) cube([1, 1, 5.147398166744652]);

color([0,1,0])
translate([22, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 27, 0]) cube([1, 1, 6]);

translate([27, 27, 0]) cube([1, 1, 4.479991413161439]);

color([0,1,0])
translate([28, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 27, 0]) cube([1, 1, 6]);

translate([31, 27, 0]) cube([1, 1, 5.212836926514958]);

color([0,1,0])
translate([0, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 28, 0]) cube([1, 1, 6]);

translate([9, 28, 0]) cube([1, 1, 6.537323067808319]);

translate([10, 28, 0]) cube([1, 1, 6.533699699175942]);

color([0,1,0])
translate([11, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 28, 0]) cube([1, 1, 6]);

translate([27, 28, 0]) cube([1, 1, 5.468898648298861]);

color([0,1,0])
translate([28, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 29, 0]) cube([1, 1, 6]);

translate([26, 29, 0]) cube([1, 1, 5.437044107528242]);

translate([27, 29, 0]) cube([1, 1, 5.431779792376797]);

translate([28, 29, 0]) cube([1, 1, 5.457303799632771]);

color([0,1,0])
translate([29, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 29, 0]) cube([1, 1, 6]);

translate([0, 30, 0]) cube([1, 1, 4.754574768561026]);

translate([1, 30, 0]) cube([1, 1, 5.494783449570093]);

translate([2, 30, 0]) cube([1, 1, 5.447376567477276]);

translate([3, 30, 0]) cube([1, 1, 5.427787915679313]);

translate([4, 30, 0]) cube([1, 1, 5.364809998582245]);

translate([5, 30, 0]) cube([1, 1, 5.283457935706776]);

translate([6, 30, 0]) cube([1, 1, 4.638798478810384]);

translate([7, 30, 0]) cube([1, 1, 5.345467319603449]);

translate([8, 30, 0]) cube([1, 1, 5.4335791442945265]);

color([0,1,0])
translate([9, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 30, 0]) cube([1, 1, 6]);

translate([11, 30, 0]) cube([1, 1, 5.309646409379049]);

translate([12, 30, 0]) cube([1, 1, 4.673360944958158]);

translate([13, 30, 0]) cube([1, 1, 5.312210338840185]);

translate([14, 30, 0]) cube([1, 1, 5.417052676166004]);

color([0,1,0])
translate([15, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 30, 0]) cube([1, 1, 6]);

translate([18, 30, 0]) cube([1, 1, 5.18154107535828]);

color([0,1,0])
translate([19, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 30, 0]) cube([1, 1, 6]);

translate([22, 30, 0]) cube([1, 1, 5.381146546635309]);

translate([23, 30, 0]) cube([1, 1, 5.380576831427036]);

translate([24, 30, 0]) cube([1, 1, 4.761171628715957]);

translate([25, 30, 0]) cube([1, 1, 5.442986263123337]);

translate([26, 30, 0]) cube([1, 1, 5.4172691956014]);

translate([27, 30, 0]) cube([1, 1, 5.421468008784011]);

color([0,1,0])
translate([28, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 30, 0]) cube([1, 1, 6]);

translate([30, 30, 0]) cube([1, 1, 4.948400046510005]);

color([0,1,0])
translate([31, 30, 0]) cube([1, 1, 6]);

translate([0, 31, 0]) cube([1, 1, 5.456096360679521]);

translate([1, 31, 0]) cube([1, 1, 5.387546203988528]);

translate([2, 31, 0]) cube([1, 1, 5.386565735677496]);

translate([3, 31, 0]) cube([1, 1, 5.379272796945015]);

translate([4, 31, 0]) cube([1, 1, 5.293602398383001]);

translate([5, 31, 0]) cube([1, 1, 5.181502957632586]);

translate([6, 31, 0]) cube([1, 1, 5.166005848082349]);

translate([7, 31, 0]) cube([1, 1, 5.166527534130611]);

translate([8, 31, 0]) cube([1, 1, 5.173449870959973]);

translate([9, 31, 0]) cube([1, 1, 5.16471947831091]);

translate([10, 31, 0]) cube([1, 1, 5.0983879143238]);

translate([11, 31, 0]) cube([1, 1, 4.993775843582886]);

translate([12, 31, 0]) cube([1, 1, 4.966470635613867]);

translate([13, 31, 0]) cube([1, 1, 4.999717350179725]);

translate([14, 31, 0]) cube([1, 1, 5.216626529739395]);

translate([15, 31, 0]) cube([1, 1, 5.385141597591712]);

color([0,1,0])
translate([16, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 31, 0]) cube([1, 1, 6]);

translate([22, 31, 0]) cube([1, 1, 5.351503057386031]);

translate([23, 31, 0]) cube([1, 1, 5.345890453279461]);

translate([24, 31, 0]) cube([1, 1, 5.353874191447676]);

translate([25, 31, 0]) cube([1, 1, 5.373853195500791]);

translate([26, 31, 0]) cube([1, 1, 5.41824750633241]);

translate([27, 31, 0]) cube([1, 1, 5.423988533622495]);

color([0,1,0])
translate([28, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 31, 0]) cube([1, 1, 6]);
