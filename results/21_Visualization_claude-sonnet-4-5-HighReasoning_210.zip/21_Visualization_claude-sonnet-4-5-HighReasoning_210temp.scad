
hull() {
    translate([17.9955, 10.0595, 18.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.9145, 11.1305, 18.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.8965, 11.2485, 18.905500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.6535, 12.3015, 18.824500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.618000000000002, 12.416, 18.815500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.222, 13.424000000000001, 18.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.17, 13.532000000000002, 18.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.630000000000003, 14.468, 18.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.5625, 14.5665, 18.6355]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.887500000000001, 15.4035, 18.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.806000000000001, 15.491, 18.545]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.014000000000001, 16.229, 18.455000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.9205, 16.3035, 18.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.0295, 16.9065, 18.3645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.926000000000002, 16.966, 18.3555]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.954, 17.434, 18.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.842500000000001, 17.4775, 18.265500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.807500000000001, 17.7925, 18.184500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.691, 17.8185, 18.175500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.629, 17.971500000000002, 18.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.509, 17.9795, 18.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.411, 17.970499999999998, 18.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.2915, 17.961, 17.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.2385, 17.799, 17.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.1245, 17.7725, 17.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.125500000000001, 17.457500000000003, 17.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.0185, 17.4155, 17.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.0915, 16.9745, 17.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.994, 16.9195, 17.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.166, 16.3705, 17.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.080500000000001, 16.305, 17.6355]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.3695, 15.675, 17.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.2975, 15.6035, 17.545]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.7125000000000004, 14.9465, 17.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6560000000000006, 14.875, 17.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.224, 14.245000000000001, 17.3645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.1845000000000003, 14.177000000000001, 17.3555]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.9055, 13.583, 17.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.883, 13.5185, 17.2655]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.757, 12.9515, 17.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.7520000000000002, 12.891, 17.1755]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.7880000000000003, 12.369, 17.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8005, 12.3145, 17.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.9895, 11.855500000000001, 17.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0185000000000004, 11.8095, 16.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.3515000000000006, 11.4405, 16.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3955, 11.4045, 16.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.8545, 11.1255, 16.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.912, 11.101, 16.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.4879999999999995, 10.939, 16.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.5569999999999995, 10.9275, 16.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.223, 10.882500000000002, 16.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.3004999999999995, 10.884000000000002, 16.6355]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.0295000000000005, 10.956000000000001, 16.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.113, 10.970500000000001, 16.545]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.8870000000000005, 11.159500000000001, 16.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.974, 11.1865, 16.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.766, 11.4835, 16.3645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.8535, 11.522, 16.3555]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.6365, 11.918000000000001, 16.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.7215, 11.967, 16.2655]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.468499999999999, 12.453000000000001, 16.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.548499999999999, 12.511500000000002, 16.1755]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.241499999999998, 13.0785, 16.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.314499999999999, 13.145, 16.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.935500000000001, 13.775, 16.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.999500000000001, 13.848, 15.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.5305, 14.532000000000002, 15.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.583, 14.610000000000001, 15.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.997, 15.33, 15.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.036999999999999, 15.4105, 15.815500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.343, 16.139499999999998, 15.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.3695, 16.221, 15.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.540500000000002, 16.959, 15.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.552500000000002, 17.04, 15.6355]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.5975, 17.759999999999998, 15.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.595, 17.8385, 15.545000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.505, 18.5315, 15.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.488, 18.6065, 15.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.272, 19.2635, 15.3645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.241000000000001, 19.3335, 15.3555]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.899000000000001, 19.9365, 15.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.855, 19.999499999999998, 15.2655]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.405000000000001, 20.530499999999996, 15.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.3495, 20.586, 15.175500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.8005, 21.054, 15.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.734499999999999, 21.100499999999997, 15.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0955, 21.469499999999996, 15.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.021, 21.505499999999998, 14.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.319, 21.7845, 14.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.238, 21.810000000000002, 14.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.482, 21.990000000000002, 14.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.3965, 22.004, 14.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.6135, 22.076, 14.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.526000000000001, 22.078, 14.725500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.734000000000001, 22.041999999999998, 14.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.646500000000001, 22.031499999999998, 14.6355]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.8635, 21.8785, 14.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.7785, 21.856, 14.545000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0315, 21.604, 14.454999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.9510000000000005, 21.57, 14.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.2490000000000006, 21.21, 14.3645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.1745, 21.1645, 14.3555]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.5355, 20.7055, 14.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.469, 20.649500000000003, 14.2655]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.911, 20.100500000000004, 14.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8545000000000003, 20.035000000000004, 14.1755]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3955, 19.405, 14.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.35, 19.331, 14.085500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.99, 18.629, 14.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.9569999999999999, 18.548000000000002, 13.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7229999999999999, 17.792, 13.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.7029999999999998, 17.706, 13.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.577, 16.914, 13.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.57, 16.825000000000003, 13.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.57, 16.015, 13.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.577, 15.925, 13.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7029999999999998, 15.115, 13.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.7229999999999999, 15.026, 13.635500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9569999999999999, 14.233999999999998, 13.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.99, 14.147499999999999, 13.545]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.35, 13.3825, 13.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3955, 13.301, 13.445500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.8545000000000003, 12.599, 13.3645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.911, 12.5245, 13.3555]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.469, 11.885499999999999, 13.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.5355, 11.818999999999999, 13.2655]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.1745, 11.261000000000001, 13.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.2490000000000006, 11.204500000000001, 13.1755]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.9510000000000005, 10.745500000000002, 13.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0315, 10.701000000000002, 13.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.7785, 10.359000000000002, 13.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.8635, 10.327000000000002, 12.995500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.646500000000001, 10.093000000000002, 12.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.734000000000001, 10.074000000000002, 12.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.526000000000001, 9.966000000000001, 12.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.6135, 9.96, 12.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.3965, 9.96, 12.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.482, 9.9665, 12.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.238, 10.083499999999999, 12.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.319, 10.1025, 12.6355]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.021, 10.3275, 12.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0955, 10.358, 12.545000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.734499999999999, 10.681999999999999, 12.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.8005, 10.7235, 12.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.3495, 11.146500000000001, 12.3645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.405000000000001, 11.198, 12.355500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.855, 11.702, 12.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.899000000000001, 11.762, 12.2655]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.241000000000001, 12.338, 12.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.272, 12.405, 12.1755]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.488, 13.035, 12.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.505, 13.107, 12.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.595, 13.773, 12.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.5975, 13.848, 11.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.552500000000002, 14.532000000000002, 11.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.540500000000002, 14.608500000000001, 11.905500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.3695, 15.3015, 11.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.343, 15.377500000000001, 11.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.036999999999999, 16.0525, 11.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.997, 16.126, 11.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.583, 16.774, 11.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.5305, 16.8435, 11.6355]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.999500000000001, 17.4465, 11.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.935500000000001, 17.5105, 11.545000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.314499999999999, 18.0595, 11.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.241499999999998, 18.116, 11.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.548499999999999, 18.584, 11.3645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.468499999999999, 18.631, 11.3555]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.7215, 19.009000000000004, 11.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.6365, 19.045500000000004, 11.265500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.8535, 19.3245, 11.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.766, 19.349, 11.1755]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.974, 19.511000000000003, 11.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.8870000000000005, 19.523, 11.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.113, 19.576999999999998, 11.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.0295000000000005, 19.576, 10.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.3004999999999995, 19.504, 10.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.223, 19.490000000000002, 10.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.5569999999999995, 19.310000000000002, 10.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.4879999999999995, 19.2835, 10.815500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.912, 18.9865, 10.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.8545, 18.9475, 10.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.3955, 18.5425, 10.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3515000000000006, 18.492, 10.6355]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.0185000000000004, 17.988000000000003, 10.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.9895, 17.928, 10.545000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.8005, 17.352, 10.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.7880000000000003, 17.2845, 10.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.7520000000000002, 16.6455, 10.3645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.757, 16.572499999999998, 10.3555]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.883, 15.897499999999999, 10.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.9055, 15.821499999999999, 10.2655]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.1845000000000003, 15.128499999999999, 10.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.224, 15.052, 10.175500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6560000000000006, 14.368, 10.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.7125000000000004, 14.293000000000001, 10.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.2975, 13.627, 10.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.3695, 13.556000000000001, 9.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.080500000000001, 12.943999999999999, 9.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.166, 12.8795, 9.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.994, 12.3305, 9.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.0915, 12.2745, 9.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.0185, 11.815499999999998, 9.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.125500000000001, 11.77, 9.725500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.1245, 11.410000000000002, 9.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.2385, 11.376500000000002, 9.6355]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.2915, 11.1335, 9.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.411, 11.113, 9.545]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.509, 10.987000000000002, 9.454999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.629, 10.980000000000002, 9.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.691, 10.980000000000002, 9.3645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.807500000000001, 10.987000000000002, 9.3555]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.842500000000001, 11.113, 9.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.954, 11.1335, 9.2655]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.926000000000002, 11.376500000000002, 9.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.0295, 11.410000000000002, 9.1755]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.9205, 11.77, 9.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.014000000000001, 11.815499999999998, 9.085500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.806000000000001, 12.2745, 9.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.887500000000001, 12.3305, 8.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.5625, 12.8795, 8.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.630000000000003, 12.943999999999999, 8.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.17, 13.556000000000001, 8.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.222, 13.627, 8.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.618000000000002, 14.293000000000001, 8.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.6535, 14.368, 8.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.8965, 15.052, 8.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.9145, 15.128499999999999, 8.6355]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.9955, 15.821499999999999, 8.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.9955, 15.897499999999999, 8.545000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.9145, 16.572499999999998, 8.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.8965, 16.6455, 8.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.6535, 17.2845, 8.3645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.618000000000002, 17.352, 8.3555]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.222, 17.928, 8.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.17, 17.988000000000003, 8.2655]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.630000000000003, 18.492, 8.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.5625, 18.5425, 8.1755]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.887500000000001, 18.9475, 8.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.806000000000001, 18.9865, 8.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.014000000000001, 19.2835, 8.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.9205, 19.310000000000002, 7.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.0295, 19.490000000000002, 7.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.926000000000002, 19.504, 7.905500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.954, 19.576, 7.8245000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.842500000000001, 19.576999999999998, 7.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.807500000000001, 19.523, 7.734500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.691, 19.511000000000003, 7.725500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.629, 19.349, 7.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.509, 19.3245, 7.6354999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.411, 19.045500000000004, 7.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.2915, 19.009000000000004, 7.545]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.2385, 18.631, 7.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.1245, 18.584, 7.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.125500000000001, 18.116, 7.3645000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.0185, 18.0595, 7.355500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.0915, 17.5105, 7.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.994, 17.4465, 7.2655]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.166, 16.8435, 7.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.080500000000001, 16.774, 7.1754999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.3695, 16.126, 7.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.2975, 16.0525, 7.085500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.7125000000000004, 15.377500000000001, 7.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6560000000000006, 15.3015, 6.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.224, 14.608500000000001, 6.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.1845000000000003, 14.532000000000002, 6.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.9055, 13.848, 6.8245000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.883, 13.773, 6.815500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.757, 13.107, 6.734500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.7520000000000002, 13.035, 6.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.7880000000000003, 12.405, 6.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8005, 12.338, 6.6355]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.9895, 11.762, 6.554499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0185000000000004, 11.702, 6.545]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.3515000000000006, 11.198, 6.455000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3955, 11.146500000000001, 6.445500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.8545, 10.7235, 6.3645000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.912, 10.681999999999999, 6.3555]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.4879999999999995, 10.358, 6.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.5569999999999995, 10.3275, 6.265499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.223, 10.1025, 6.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.3004999999999995, 10.083499999999999, 6.1755]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.0295000000000005, 9.9665, 6.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.113, 9.96, 6.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.8870000000000005, 9.96, 6.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.974, 9.966000000000001, 5.995500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.766, 10.074000000000002, 5.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.8535, 10.093000000000002, 5.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.6365, 10.327000000000002, 5.8245000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.7215, 10.359000000000002, 5.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.468499999999999, 10.701000000000002, 5.734500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.548499999999999, 10.745500000000002, 5.725500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.241499999999998, 11.204500000000001, 5.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.314499999999999, 11.261000000000001, 5.6354999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.935500000000001, 11.818999999999999, 5.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.999500000000001, 11.885499999999999, 5.545]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.5305, 12.5245, 5.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.583, 12.599, 5.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.997, 13.301, 5.3645000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.036999999999999, 13.3825, 5.355500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.343, 14.147499999999999, 5.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.3695, 14.233999999999998, 5.265499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.540500000000002, 15.026, 5.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.552500000000002, 15.115, 5.1754999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.5975, 15.925, 5.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.595, 16.015, 5.085500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.505, 16.825000000000003, 5.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.488, 16.914, 4.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.272, 17.706, 4.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.241000000000001, 17.792, 4.905500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.899000000000001, 18.548000000000002, 4.8245000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.855, 18.629, 4.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.405000000000001, 19.331, 4.734500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.3495, 19.405, 4.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.8005, 20.035000000000004, 4.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.734499999999999, 20.100500000000004, 4.6355]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0955, 20.649500000000003, 4.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.021, 20.7055, 4.545]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.319, 21.1645, 4.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.238, 21.21, 4.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.482, 21.57, 4.3645000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.3965, 21.604, 4.3555]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.6135, 21.856, 4.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.526000000000001, 21.8785, 4.265499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.734000000000001, 22.031499999999998, 4.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.646500000000001, 22.041999999999998, 4.1754999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.8635, 22.078, 4.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.7785, 22.076, 4.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0315, 22.004, 4.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.9510000000000005, 21.990000000000002, 3.9955000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.2490000000000006, 21.810000000000002, 3.9145000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.1745, 21.7845, 3.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.5355, 21.505499999999998, 3.8244999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.469, 21.469499999999996, 3.8154999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.911, 21.100499999999997, 3.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8545000000000003, 21.054, 3.7255000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3955, 20.586, 3.6445000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.35, 20.530499999999996, 3.6355000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.99, 19.999499999999998, 3.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.9569999999999999, 19.9365, 3.545]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7229999999999999, 19.3335, 3.4550000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.7029999999999998, 19.2635, 3.4455000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.577, 18.6065, 3.3645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.57, 18.5315, 3.3555]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.57, 17.8385, 3.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.577, 17.759999999999998, 3.2655000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7029999999999998, 17.04, 3.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.7229999999999999, 16.959, 3.1755]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9569999999999999, 16.221, 3.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.99, 16.139499999999998, 3.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.35, 15.4105, 3.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3955, 15.33, 2.9955000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.8545000000000003, 14.610000000000001, 2.9145000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.911, 14.532000000000002, 2.9055000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.469, 13.848, 2.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.5355, 13.775, 2.8154999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.1745, 13.145, 2.7344999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.2490000000000006, 13.0785, 2.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.9510000000000005, 12.511500000000002, 2.6445000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0315, 12.453000000000001, 2.6355000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.7785, 11.967, 2.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.8635, 11.918000000000001, 2.545]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.646500000000001, 11.522, 2.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.734000000000001, 11.4835, 2.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.526000000000001, 11.1865, 2.3645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.6135, 11.159500000000001, 2.3555]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.3965, 10.970500000000001, 2.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.482, 10.956000000000001, 2.2655000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.238, 10.884000000000002, 2.1845000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.319, 10.882500000000002, 2.1755]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.021, 10.9275, 2.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0955, 10.939, 2.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.734499999999999, 11.101, 2.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.8005, 11.1255, 1.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.3495, 11.4045, 1.9144999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.405000000000001, 11.4405, 1.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.855, 11.8095, 1.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.899000000000001, 11.855500000000001, 1.8155000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.241000000000001, 12.3145, 1.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.272, 12.369, 1.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.488, 12.891, 1.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.505, 12.9515, 1.6355]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.595, 13.5185, 1.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.5975, 13.583, 1.545]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.552500000000002, 14.177000000000001, 1.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.540500000000002, 14.245000000000001, 1.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.3695, 14.875, 1.3645000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.343, 14.9465, 1.3555000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.036999999999999, 15.6035, 1.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.997, 15.675, 1.2655]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.583, 16.305, 1.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.5305, 16.3705, 1.1755]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.999500000000001, 16.9195, 1.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.935500000000001, 16.9745, 1.0855000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.314499999999999, 17.4155, 1.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.241499999999998, 17.457500000000003, 0.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.548499999999999, 17.7725, 0.9145000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.468499999999999, 17.799, 0.9055000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.7215, 17.961, 0.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.6365, 17.970499999999998, 0.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.8535, 17.9795, 0.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.766, 17.971500000000002, 0.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.974, 17.8185, 0.6445000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.8870000000000005, 17.7925, 0.6355000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.113, 17.4775, 0.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.0295000000000005, 17.434, 0.545]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.3004999999999995, 16.966, 0.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.223, 16.9065, 0.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.5569999999999995, 16.3035, 0.36450000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.4879999999999995, 16.229, 0.35550000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.912, 15.491, 0.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.8545, 15.4035, 0.2655]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.3955, 14.5665, 0.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3515000000000006, 14.468, 0.17550000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.0185000000000004, 13.532000000000002, 0.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.75, 13.306000000000001, 0.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.25, 10.174, 0.0045]) cube([0.4, 0.4, 0.1], center=true);
}

