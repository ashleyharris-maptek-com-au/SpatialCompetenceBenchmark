color([0, 1, 0]) translate([0, 0, 0]) cube([1, 1, 4]);

translate([1, 0, 0]) cube([1, 1, 2.6884812476611772]);

color([0, 1, 0]) translate([2, 0, 0]) cube([1, 1, 4]);

translate([3, 0, 0]) cube([1, 1, 3.0362004080347997]);

color([0, 1, 0]) translate([4, 0, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 0, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 0, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 0, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 0, 0]) cube([1, 1, 4]);

translate([9, 0, 0]) cube([1, 1, 2.9135109929578853]);

translate([10, 0, 0]) cube([1, 1, 2.1976046061666783]);

translate([11, 0, 0]) cube([1, 1, 3.377136540122721]);

translate([12, 0, 0]) cube([1, 1, 3.0566684740787626]);

translate([13, 0, 0]) cube([1, 1, 2.2725748608699705]);

translate([14, 0, 0]) cube([1, 1, 2.156668474078763]);

translate([15, 0, 0]) cube([1, 1, 2.708949313705138]);

translate([0, 1, 0]) cube([1, 1, 3.1385407382545925]);

color([0, 1, 0]) translate([1, 1, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 1, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 1, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 1, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 1, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 1, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 1, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 1, 0]) cube([1, 1, 4]);

translate([9, 1, 0]) cube([1, 1, 3.3566684740787602]);

color([0, 1, 0]) translate([10, 1, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([11, 1, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 1, 0]) cube([1, 1, 4]);

translate([13, 1, 0]) cube([1, 1, 3.3839195684084284]);

translate([14, 1, 0]) cube([1, 1, 3.499825955199637]);

translate([15, 1, 0]) cube([1, 1, 2.4362004080348036]);

translate([0, 2, 0]) cube([1, 1, 2.2112896439249257]);

color([0, 1, 0]) translate([1, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 2, 0]) cube([1, 1, 4]);

translate([4, 2, 0]) cube([1, 1, 4.761230153331503]);

color([0, 1, 0]) translate([5, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([10, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([11, 2, 0]) cube([1, 1, 4]);

translate([12, 2, 0]) cube([1, 1, 3.015732341990841]);

translate([13, 2, 0]) cube([1, 1, 3.3157323419908415]);

translate([14, 2, 0]) cube([1, 1, 3.1316387287820535]);

translate([15, 2, 0]) cube([1, 1, 2.7839195684084292]);

color([0, 1, 0]) translate([0, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([1, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([10, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([11, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 3, 0]) cube([1, 1, 4]);

translate([13, 3, 0]) cube([1, 1, 3.452106794826009]);

translate([14, 3, 0]) cube([1, 1, 3.452106794826009]);

translate([15, 3, 0]) cube([1, 1, 2.2521067948260116]);

translate([0, 4, 0]) cube([1, 1, 3.499944936386468]);

color([0, 1, 0]) translate([1, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 4, 0]) cube([1, 1, 4]);

translate([6, 4, 0]) cube([1, 1, 4.61807267221063]);

color([0, 1, 0]) translate([7, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 4, 0]) cube([1, 1, 4]);

translate([10, 4, 0]) cube([1, 1, 3.1043876344523786]);

color([0, 1, 0]) translate([11, 4, 0]) cube([1, 1, 4]);

translate([12, 4, 0]) cube([1, 1, 3.1248557004963375]);

translate([13, 4, 0]) cube([1, 1, 3.1248557004963384]);

translate([14, 4, 0]) cube([1, 1, 3.424855700496341]);

translate([15, 4, 0]) cube([1, 1, 3.5407620872875523]);

translate([0, 5, 0]) cube([1, 1, 2.4840385495952604]);

color([0, 1, 0]) translate([1, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([10, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([11, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 5, 0]) cube([1, 1, 4]);

translate([14, 5, 0]) cube([1, 1, 3.445323766540299]);

translate([15, 5, 0]) cube([1, 1, 3.213510992957885]);

color([0, 1, 0]) translate([0, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([1, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([10, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([11, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 6, 0]) cube([1, 1, 4]);

translate([14, 6, 0]) cube([1, 1, 3.2544471250457985]);

translate([15, 6, 0]) cube([1, 1, 4.202166285419428]);

color([0, 1, 0]) translate([0, 7, 0]) cube([1, 1, 4]);

translate([1, 7, 0]) cube([1, 1, 3.431757709968882]);

color([0, 1, 0]) translate([2, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([10, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([11, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 7, 0]) cube([1, 1, 4]);

translate([14, 7, 0]) cube([1, 1, 3.3431024175073416]);

translate([15, 7, 0]) cube([1, 1, 3.1385407382545942]);

translate([0, 8, 0]) cube([1, 1, 2.531757709968884]);

color([0, 1, 0]) translate([1, 8, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 8, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 8, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 8, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 8, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 8, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 8, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 8, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 8, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([10, 8, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([11, 8, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 8, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 8, 0]) cube([1, 1, 4]);

translate([14, 8, 0]) cube([1, 1, 3.090821577880967]);

translate([15, 8, 0]) cube([1, 1, 3.7385407382545948]);

color([0, 1, 0]) translate([0, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([1, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([10, 9, 0]) cube([1, 1, 4]);

translate([11, 9, 0]) cube([1, 1, 4.713510992957879]);

translate([12, 9, 0]) cube([1, 1, 3.4180726722106307]);

translate([13, 9, 0]) cube([1, 1, 3.1862598986282133]);

translate([14, 9, 0]) cube([1, 1, 3.186259898628215]);

translate([15, 9, 0]) cube([1, 1, 3.0021662854194275]);

color([0, 1, 0]) translate([0, 10, 0]) cube([1, 1, 4]);

translate([1, 10, 0]) cube([1, 1, 3.2544471250457985]);

translate([2, 10, 0]) cube([1, 1, 4.549885445793047]);

color([0, 1, 0]) translate([3, 10, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 10, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 10, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 10, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 10, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 10, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 10, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([10, 10, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([11, 10, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 10, 0]) cube([1, 1, 4]);

translate([13, 10, 0]) cube([1, 1, 3.2339790590018405]);

translate([14, 10, 0]) cube([1, 1, 2.8180726722106337]);

translate([15, 10, 0]) cube([1, 1, 2.865791832584259]);

translate([0, 11, 0]) cube([1, 1, 3.227196030716134]);

translate([1, 11, 0]) cube([1, 1, 3.0703535118370064]);

color([0, 1, 0]) translate([2, 11, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 11, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 11, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 11, 0]) cube([1, 1, 4]);

translate([6, 11, 0]) cube([1, 1, 3.4385407382545896]);

color([0, 1, 0]) translate([7, 11, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 11, 0]) cube([1, 1, 4]);

translate([9, 11, 0]) cube([1, 1, 3.3498854457930474]);

translate([10, 11, 0]) cube([1, 1, 4.5498854457930475]);

color([0, 1, 0]) translate([11, 11, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 11, 0]) cube([1, 1, 4]);

translate([13, 11, 0]) cube([1, 1, 3.465791832584257]);

color([0, 1, 0]) translate([14, 11, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([15, 11, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([0, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([1, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 12, 0]) cube([1, 1, 4]);

translate([3, 12, 0]) cube([1, 1, 4.502166285419423]);

color([0, 1, 0]) translate([4, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 12, 0]) cube([1, 1, 4]);

translate([9, 12, 0]) cube([1, 1, 3.3498854457930465]);

color([0, 1, 0]) translate([10, 12, 0]) cube([1, 1, 4]);

translate([11, 12, 0]) cube([1, 1, 3.302166285419424]);

translate([12, 12, 0]) cube([1, 1, 3.465791832584257]);

color([0, 1, 0]) translate([13, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([14, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([15, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([0, 13, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([1, 13, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 13, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 13, 0]) cube([1, 1, 4]);

translate([4, 13, 0]) cube([1, 1, 3.370353511837007]);

color([0, 1, 0]) translate([5, 13, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 13, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 13, 0]) cube([1, 1, 4]);

translate([8, 13, 0]) cube([1, 1, 3.4180726722106316]);

color([0, 1, 0]) translate([9, 13, 0]) cube([1, 1, 4]);

translate([10, 13, 0]) cube([1, 1, 3.322634351463382]);

translate([11, 13, 0]) cube([1, 1, 3.3021662854194247]);

translate([12, 13, 0]) cube([1, 1, 3.281698219375466]);

translate([13, 13, 0]) cube([1, 1, 3.3976046061666763]);

translate([14, 13, 0]) cube([1, 1, 3.397604606166677]);

color([0, 1, 0]) translate([15, 13, 0]) cube([1, 1, 4]);

translate([0, 14, 0]) cube([1, 1, 2.2862598986282174]);

color([0, 1, 0]) translate([1, 14, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 14, 0]) cube([1, 1, 4]);

translate([3, 14, 0]) cube([1, 1, 3.349885445793049]);

translate([4, 14, 0]) cube([1, 1, 2.654447125045799]);

color([0, 1, 0]) translate([5, 14, 0]) cube([1, 1, 4]);

translate([6, 14, 0]) cube([1, 1, 2.9544471250457995]);

color([0, 1, 0]) translate([7, 14, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 14, 0]) cube([1, 1, 4]);

translate([9, 14, 0]) cube([1, 1, 3.4385407382545923]);

color([0, 1, 0]) translate([10, 14, 0]) cube([1, 1, 4]);

translate([11, 14, 0]) cube([1, 1, 3.34988544579305]);

color([0, 1, 0]) translate([12, 14, 0]) cube([1, 1, 4]);

translate([13, 14, 0]) cube([1, 1, 3.2816982193754676]);

color([0, 1, 0]) translate([14, 14, 0]) cube([1, 1, 4]);

translate([15, 14, 0]) cube([1, 1, 2.933979059001844]);

translate([0, 15, 0]) cube([1, 1, 2.08169821937547]);

translate([1, 15, 0]) cube([1, 1, 3.097604606166678]);

translate([2, 15, 0]) cube([1, 1, 2.6135109929578837]);

color([0, 1, 0]) translate([3, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 15, 0]) cube([1, 1, 4]);

translate([5, 15, 0]) cube([1, 1, 1.481698219375469]);

translate([6, 15, 0]) cube([1, 1, 2.4294173797490934]);

color([0, 1, 0]) translate([7, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 15, 0]) cube([1, 1, 4]);

translate([10, 15, 0]) cube([1, 1, 2.9339790590018433]);

translate([11, 15, 0]) cube([1, 1, 2.3135109929578848]);

translate([12, 15, 0]) cube([1, 1, 2.497604606166678]);

color([0, 1, 0]) translate([13, 15, 0]) cube([1, 1, 4]);

translate([14, 15, 0]) cube([1, 1, 3.2816982193754693]);

translate([15, 15, 0]) cube([1, 1, 3.418072672210637]);
