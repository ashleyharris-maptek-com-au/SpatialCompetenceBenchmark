
translate([0, 0, 0]) cube([1, 1, 5.219999999999995]);

translate([1, 0, 0]) cube([1, 1, 4.712832947426176]);

translate([2, 0, 0]) cube([1, 1, 4.702832947710165]);

translate([3, 0, 0]) cube([1, 1, 4.562832947978359]);

translate([4, 0, 0]) cube([1, 1, 4.511433701954927]);

translate([5, 0, 0]) cube([1, 1, 4.489900950235299]);

translate([6, 0, 0]) cube([1, 1, 4.5]);

translate([7, 0, 0]) cube([1, 1, 4.405977659223269]);

translate([8, 0, 0]) cube([1, 1, 4.40598318174815]);

translate([9, 0, 0]) cube([1, 1, 4.6]);

translate([10, 0, 0]) cube([1, 1, 5.0]);

translate([11, 0, 0]) cube([1, 1, 5.3]);

translate([12, 0, 0]) cube([1, 1, 5.4]);

translate([13, 0, 0]) cube([1, 1, 5.3]);

translate([14, 0, 0]) cube([1, 1, 4.8]);

translate([15, 0, 0]) cube([1, 1, 4.4]);

translate([16, 0, 0]) cube([1, 1, 4.3]);

translate([17, 0, 0]) cube([1, 1, 4.3]);

translate([18, 0, 0]) cube([1, 1, 4.6]);

translate([19, 0, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 1, 0]) cube([1, 1, 6]);

translate([2, 1, 0]) cube([1, 1, 5.179999999999992]);

translate([3, 1, 0]) cube([1, 1, 4.629999999999993]);

translate([4, 1, 0]) cube([1, 1, 4.549999999999993]);

translate([5, 1, 0]) cube([1, 1, 4.489999999999994]);

translate([6, 1, 0]) cube([1, 1, 4.492208829277688]);

translate([7, 1, 0]) cube([1, 1, 4.424607966524269]);

translate([8, 1, 0]) cube([1, 1, 4.417567218961222]);

translate([9, 1, 0]) cube([1, 1, 4.405983912024311]);

translate([10, 1, 0]) cube([1, 1, 4.399999999292241]);

translate([11, 1, 0]) cube([1, 1, 4.5]);

translate([12, 1, 0]) cube([1, 1, 4.6]);

translate([13, 1, 0]) cube([1, 1, 4.5]);

translate([14, 1, 0]) cube([1, 1, 4.3]);

translate([15, 1, 0]) cube([1, 1, 4.1]);

translate([16, 1, 0]) cube([1, 1, 3.8]);

translate([17, 1, 0]) cube([1, 1, 3.5466371819203353]);

translate([18, 1, 0]) cube([1, 1, 3.8]);

translate([19, 1, 0]) cube([1, 1, 4.0]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.489999999999994]);

translate([4, 2, 0]) cube([1, 1, 5.359999999999994]);

translate([5, 2, 0]) cube([1, 1, 4.889999999999998]);

translate([6, 2, 0]) cube([1, 1, 4.425150849648435]);

translate([7, 2, 0]) cube([1, 1, 4.425635111059238]);

translate([8, 2, 0]) cube([1, 1, 4.409442451478688]);

translate([9, 2, 0]) cube([1, 1, 4.419990594816416]);

translate([10, 2, 0]) cube([1, 1, 4.4]);

translate([11, 2, 0]) cube([1, 1, 4.4]);

translate([12, 2, 0]) cube([1, 1, 4.2]);

translate([13, 2, 0]) cube([1, 1, 4.1]);

translate([14, 2, 0]) cube([1, 1, 3.7]);

translate([15, 2, 0]) cube([1, 1, 3.6]);

translate([16, 2, 0]) cube([1, 1, 3.5481090872001255]);

translate([17, 2, 0]) cube([1, 1, 3.5480948819464824]);

translate([18, 2, 0]) cube([1, 1, 3.5478891117702336]);

translate([19, 2, 0]) cube([1, 1, 3.7]);

color([0,1,0])
translate([0, 3, 0]) cube([1, 1, 6]);

translate([1, 3, 0]) cube([1, 1, 6.729999999999997]);

translate([2, 3, 0]) cube([1, 1, 6.6899999999999915]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.3699999999999966]);

translate([6, 3, 0]) cube([1, 1, 4.799999999999998]);

translate([7, 3, 0]) cube([1, 1, 4.849999999999999]);

translate([8, 3, 0]) cube([1, 1, 5.2]);

translate([9, 3, 0]) cube([1, 1, 5.1]);

translate([10, 3, 0]) cube([1, 1, 5.0]);

translate([11, 3, 0]) cube([1, 1, 4.7]);

translate([12, 3, 0]) cube([1, 1, 4.0]);

translate([13, 3, 0]) cube([1, 1, 3.8]);

translate([14, 3, 0]) cube([1, 1, 3.5457761381487645]);

translate([15, 3, 0]) cube([1, 1, 3.546228872700634]);

translate([16, 3, 0]) cube([1, 1, 3.5471684658505995]);

translate([17, 3, 0]) cube([1, 1, 3.5482540670548612]);

translate([18, 3, 0]) cube([1, 1, 3.547673086594257]);

translate([19, 3, 0]) cube([1, 1, 3.6]);

color([0,1,0])
translate([0, 4, 0]) cube([1, 1, 6]);

translate([1, 4, 0]) cube([1, 1, 6.72703207955474]);

translate([2, 4, 0]) cube([1, 1, 6.719797309574828]);

translate([3, 4, 0]) cube([1, 1, 6.729999999999993]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.479999999999996]);

color([0,1,0])
translate([7, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 4, 0]) cube([1, 1, 6]);

translate([10, 4, 0]) cube([1, 1, 5.3]);

translate([11, 4, 0]) cube([1, 1, 4.7]);

translate([12, 4, 0]) cube([1, 1, 4.0]);

translate([13, 4, 0]) cube([1, 1, 3.6]);

translate([14, 4, 0]) cube([1, 1, 3.6]);

translate([15, 4, 0]) cube([1, 1, 3.7]);

translate([16, 4, 0]) cube([1, 1, 3.9]);

translate([17, 4, 0]) cube([1, 1, 4.1]);

translate([18, 4, 0]) cube([1, 1, 4.0]);

translate([19, 4, 0]) cube([1, 1, 3.9]);

color([0,1,0])
translate([0, 5, 0]) cube([1, 1, 6]);

translate([1, 5, 0]) cube([1, 1, 6.81782864962916]);

translate([2, 5, 0]) cube([1, 1, 6.7961329554501315]);

translate([3, 5, 0]) cube([1, 1, 6.899999999999993]);

translate([4, 5, 0]) cube([1, 1, 6.749999999999995]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 5, 0]) cube([1, 1, 6]);

translate([10, 5, 0]) cube([1, 1, 5.4]);

translate([11, 5, 0]) cube([1, 1, 4.8]);

translate([12, 5, 0]) cube([1, 1, 4.4]);

translate([13, 5, 0]) cube([1, 1, 4.0]);

translate([14, 5, 0]) cube([1, 1, 4.4]);

translate([15, 5, 0]) cube([1, 1, 4.6]);

translate([16, 5, 0]) cube([1, 1, 4.6]);

translate([17, 5, 0]) cube([1, 1, 4.72]);

translate([18, 5, 0]) cube([1, 1, 4.52]);

translate([19, 5, 0]) cube([1, 1, 4.51]);

color([0,1,0])
translate([0, 6, 0]) cube([1, 1, 6]);

translate([1, 6, 0]) cube([1, 1, 6.896446000055101]);

translate([2, 6, 0]) cube([1, 1, 6.900914396539741]);

translate([3, 6, 0]) cube([1, 1, 6.8999999999999915]);

translate([4, 6, 0]) cube([1, 1, 6.639813066378165]);

translate([5, 6, 0]) cube([1, 1, 6.739999999999997]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 6, 0]) cube([1, 1, 6]);

translate([11, 6, 0]) cube([1, 1, 5.0]);

translate([12, 6, 0]) cube([1, 1, 4.8]);

translate([13, 6, 0]) cube([1, 1, 4.6]);

translate([14, 6, 0]) cube([1, 1, 5.1]);

translate([15, 6, 0]) cube([1, 1, 5.41]);

translate([16, 6, 0]) cube([1, 1, 5.31]);

translate([17, 6, 0]) cube([1, 1, 5.139999999999999]);

translate([18, 6, 0]) cube([1, 1, 4.9399999999999995]);

translate([19, 6, 0]) cube([1, 1, 5.2299999999999995]);

translate([0, 7, 0]) cube([1, 1, 6.502998277751203]);

translate([1, 7, 0]) cube([1, 1, 6.898790141352251]);

translate([2, 7, 0]) cube([1, 1, 6.92089298280472]);

translate([3, 7, 0]) cube([1, 1, 6.8843988095237965]);

translate([4, 7, 0]) cube([1, 1, 6.632383636621489]);

translate([5, 7, 0]) cube([1, 1, 6.565323489490192]);

translate([6, 7, 0]) cube([1, 1, 6.569999999999997]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

translate([11, 7, 0]) cube([1, 1, 5.01]);

translate([12, 7, 0]) cube([1, 1, 4.9]);

translate([13, 7, 0]) cube([1, 1, 4.8]);

translate([14, 7, 0]) cube([1, 1, 5.42]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 6.598813346498358]);

translate([1, 8, 0]) cube([1, 1, 6.874996908742053]);

translate([2, 8, 0]) cube([1, 1, 6.8570829103581294]);

translate([3, 8, 0]) cube([1, 1, 6.715558074284814]);

translate([4, 8, 0]) cube([1, 1, 6.6210409005641795]);

translate([5, 8, 0]) cube([1, 1, 6.585768405115739]);

color([0,1,0])
translate([6, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

translate([11, 8, 0]) cube([1, 1, 5.319999999999999]);

translate([12, 8, 0]) cube([1, 1, 5.2]);

translate([13, 8, 0]) cube([1, 1, 5.1]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 8, 0]) cube([1, 1, 6]);

translate([17, 8, 0]) cube([1, 1, 6.639999999999999]);

translate([18, 8, 0]) cube([1, 1, 6.539999999999999]);

color([0,1,0])
translate([19, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 6.607495855847803]);

translate([1, 9, 0]) cube([1, 1, 6.677191258534755]);

translate([2, 9, 0]) cube([1, 1, 6.7455580577109]);

translate([3, 9, 0]) cube([1, 1, 6.729330403667508]);

translate([4, 9, 0]) cube([1, 1, 6.6475767928823055]);

translate([5, 9, 0]) cube([1, 1, 6.551060328484415]);

color([0,1,0])
translate([6, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 9, 0]) cube([1, 1, 6]);

translate([8, 9, 0]) cube([1, 1, 6.549999999999997]);

translate([9, 9, 0]) cube([1, 1, 6.559999999999999]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 6.724883223193834]);

translate([1, 10, 0]) cube([1, 1, 6.72912204197679]);

translate([2, 10, 0]) cube([1, 1, 6.733548821223909]);

translate([3, 10, 0]) cube([1, 1, 6.6699316651238965]);

translate([4, 10, 0]) cube([1, 1, 6.689999999999996]);

translate([5, 10, 0]) cube([1, 1, 6.6999999999999975]);

color([0,1,0])
translate([6, 10, 0]) cube([1, 1, 6]);

translate([7, 10, 0]) cube([1, 1, 6.709999999999997]);

translate([8, 10, 0]) cube([1, 1, 6.577621428571426]);

translate([9, 10, 0]) cube([1, 1, 6.659999999999998]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 6.629999999999999]);

color([0,1,0])
translate([18, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 6.674929726509303]);

translate([1, 11, 0]) cube([1, 1, 6.696108800104669]);

translate([2, 11, 0]) cube([1, 1, 6.799999999999995]);

translate([3, 11, 0]) cube([1, 1, 6.669999999999995]);

color([0,1,0])
translate([4, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.599999999999998]);

color([0,1,0])
translate([8, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

translate([12, 11, 0]) cube([1, 1, 5.434623478829625]);

translate([13, 11, 0]) cube([1, 1, 5.43465414976841]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 6.600507404542931]);

translate([1, 12, 0]) cube([1, 1, 6.719999999999995]);

translate([2, 12, 0]) cube([1, 1, 6.5299999999999905]);

color([0,1,0])
translate([3, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 12, 0]) cube([1, 1, 6]);

translate([10, 12, 0]) cube([1, 1, 6.549999999999999]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

translate([13, 12, 0]) cube([1, 1, 5.4359346622763995]);

translate([14, 12, 0]) cube([1, 1, 5.4399999999999995]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 13, 0]) cube([1, 1, 6]);

translate([1, 13, 0]) cube([1, 1, 6.719999999999997]);

color([0,1,0])
translate([2, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

translate([8, 13, 0]) cube([1, 1, 6.669999999999998]);

color([0,1,0])
translate([9, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

translate([14, 13, 0]) cube([1, 1, 5.436996036843794]);

translate([15, 13, 0]) cube([1, 1, 5.437213295390523]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

translate([19, 13, 0]) cube([1, 1, 5.339999999999999]);

color([0,1,0])
translate([0, 14, 0]) cube([1, 1, 6]);

translate([1, 14, 0]) cube([1, 1, 6.5699999999999985]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

translate([19, 14, 0]) cube([1, 1, 5.02]);

translate([0, 15, 0]) cube([1, 1, 6.639999999999999]);

color([0,1,0])
translate([1, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

translate([17, 15, 0]) cube([1, 1, 5.4]);

translate([18, 15, 0]) cube([1, 1, 5.1]);

translate([19, 15, 0]) cube([1, 1, 4.801841983428726]);

color([0,1,0])
translate([0, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 16, 0]) cube([1, 1, 6]);

translate([6, 16, 0]) cube([1, 1, 6.559999999999999]);

color([0,1,0])
translate([7, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 16, 0]) cube([1, 1, 6]);

translate([9, 16, 0]) cube([1, 1, 6.549999999999999]);

color([0,1,0])
translate([10, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

translate([16, 16, 0]) cube([1, 1, 5.401358156834216]);

translate([17, 16, 0]) cube([1, 1, 5.4]);

translate([18, 16, 0]) cube([1, 1, 5.2]);

translate([19, 16, 0]) cube([1, 1, 4.801898044175437]);

color([0,1,0])
translate([0, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

translate([7, 17, 0]) cube([1, 1, 6.669999999999998]);

translate([8, 17, 0]) cube([1, 1, 6.5699999999999985]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

translate([16, 18, 0]) cube([1, 1, 5.4]);

translate([17, 18, 0]) cube([1, 1, 5.300014000057538]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 5.467778840923361]);

translate([1, 19, 0]) cube([1, 1, 5.471411597834481]);

translate([2, 19, 0]) cube([1, 1, 5.472733326930196]);

translate([3, 19, 0]) cube([1, 1, 5.473293233379156]);

translate([4, 19, 0]) cube([1, 1, 5.47147107255589]);

translate([5, 19, 0]) cube([1, 1, 5.473249856555276]);

translate([6, 19, 0]) cube([1, 1, 5.472138895241495]);

translate([7, 19, 0]) cube([1, 1, 5.472147051554827]);

translate([8, 19, 0]) cube([1, 1, 5.472059869561907]);

translate([9, 19, 0]) cube([1, 1, 5.474562140035553]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

translate([14, 19, 0]) cube([1, 1, 5.2090922902970895]);

translate([15, 19, 0]) cube([1, 1, 5.3]);

translate([16, 19, 0]) cube([1, 1, 5.300002912641088]);

translate([17, 19, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);
