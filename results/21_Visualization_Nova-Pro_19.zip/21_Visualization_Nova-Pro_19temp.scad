
hull() {
    translate([0.05, 0.0, 4.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9500000000000001, 0.0, 4.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.05, 0.0, 3.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9500000000000002, 0.0, 3.0500000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.05, 0.0, 2.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.95, 0.0, 2.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0500000000000003, 0.0, 2.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.95, 0.0, 2.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.05, 0.0, 1.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.95, 0.0, 1.5250000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.05, 0.0, 1.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.95, 0.0, 1.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.050000000000001, 0.0, 0.9750000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.95, 0.0, 0.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.05, 0.0, 0.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.95, 0.0, 0.21500000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.05, 0.0, 0.19000000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.95, 0.0, 0.010000000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.025, 0.025, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.475000000000001, 0.47500000000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.5, 0.55, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.5, 1.4500000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.475000000000001, 1.55, 0.025]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.025, 2.45, 0.47500000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.95, 2.5, 0.55]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.05, 2.5, 1.4500000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.95, 2.5, 1.55]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.05, 2.5, 2.45]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.95, 2.5, 2.55]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.050000000000001, 2.5, 3.45]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.95, 2.5, 3.525]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.05, 2.5, 3.975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.95, 2.5, 4.025]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.05, 2.5, 4.475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.95, 2.5, 4.5249999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.0500000000000003, 2.5, 4.975]) cube([0.4, 0.4, 0.1], center=true);
}

