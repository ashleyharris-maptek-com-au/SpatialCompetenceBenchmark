
translate([0, 0, 0]) cube([1, 1, 5.000333996825397]);

translate([1, 0, 0]) cube([1, 1, 4.301937308360908]);

translate([2, 0, 0]) cube([1, 1, 4.107346200950277]);

translate([3, 0, 0]) cube([1, 1, 3.983393181164349]);

translate([4, 0, 0]) cube([1, 1, 3.9834135956520718]);

translate([5, 0, 0]) cube([1, 1, 4.232902704679477]);

translate([6, 0, 0]) cube([1, 1, 4.5]);

translate([7, 0, 0]) cube([1, 1, 4.3]);

translate([8, 0, 0]) cube([1, 1, 4.2]);

translate([9, 0, 0]) cube([1, 1, 4.6]);

translate([10, 0, 0]) cube([1, 1, 5.0]);

translate([11, 0, 0]) cube([1, 1, 5.3]);

translate([12, 0, 0]) cube([1, 1, 5.4]);

translate([13, 0, 0]) cube([1, 1, 5.3]);

translate([14, 0, 0]) cube([1, 1, 4.8]);

translate([15, 0, 0]) cube([1, 1, 4.4]);

translate([16, 0, 0]) cube([1, 1, 4.3]);

translate([17, 0, 0]) cube([1, 1, 4.3]);

translate([18, 0, 0]) cube([1, 1, 4.6]);

translate([19, 0, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.300667993650793]);

translate([2, 1, 0]) cube([1, 1, 4.802872626245625]);

translate([3, 1, 0]) cube([1, 1, 4.309214474870701]);

translate([4, 1, 0]) cube([1, 1, 4.232826298795247]);

translate([5, 1, 0]) cube([1, 1, 4.239603700602641]);

translate([6, 1, 0]) cube([1, 1, 4.2393063133408]);

translate([7, 1, 0]) cube([1, 1, 4.170963023754549]);

translate([8, 1, 0]) cube([1, 1, 4.170960991262574]);

translate([9, 1, 0]) cube([1, 1, 4.170961075997454]);

translate([10, 1, 0]) cube([1, 1, 4.358544764650369]);

translate([11, 1, 0]) cube([1, 1, 4.5]);

translate([12, 1, 0]) cube([1, 1, 4.6]);

translate([13, 1, 0]) cube([1, 1, 4.5]);

translate([14, 1, 0]) cube([1, 1, 4.3]);

translate([15, 1, 0]) cube([1, 1, 4.1]);

translate([16, 1, 0]) cube([1, 1, 3.800028840796911]);

translate([17, 1, 0]) cube([1, 1, 3.6537134893744074]);

translate([18, 1, 0]) cube([1, 1, 3.8]);

translate([19, 1, 0]) cube([1, 1, 4.0]);

translate([0, 2, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.210355169323368]);

translate([4, 2, 0]) cube([1, 1, 5.129920088998369]);

translate([5, 2, 0]) cube([1, 1, 4.851966711660961]);

translate([6, 2, 0]) cube([1, 1, 4.302100032043579]);

translate([7, 2, 0]) cube([1, 1, 4.259410278827279]);

translate([8, 2, 0]) cube([1, 1, 4.445566867000744]);

translate([9, 2, 0]) cube([1, 1, 4.3626421633362105]);

translate([10, 2, 0]) cube([1, 1, 4.432128502728371]);

translate([11, 2, 0]) cube([1, 1, 4.424263309791361]);

translate([12, 2, 0]) cube([1, 1, 4.215680541946824]);

translate([13, 2, 0]) cube([1, 1, 4.117309694464893]);

translate([14, 2, 0]) cube([1, 1, 3.84382529444578]);

translate([15, 2, 0]) cube([1, 1, 3.8001018717367665]);

translate([16, 2, 0]) cube([1, 1, 3.689874073783842]);

translate([17, 2, 0]) cube([1, 1, 3.653713511494111]);

translate([18, 2, 0]) cube([1, 1, 3.653713496912331]);

translate([19, 2, 0]) cube([1, 1, 3.7]);

translate([0, 3, 0]) cube([1, 1, 7.4]);

translate([1, 3, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.292055826699063]);

translate([6, 3, 0]) cube([1, 1, 4.914153498307808]);

translate([7, 3, 0]) cube([1, 1, 4.943840644286036]);

translate([8, 3, 0]) cube([1, 1, 5.263647595956755]);

translate([9, 3, 0]) cube([1, 1, 5.165912963084884]);

translate([10, 3, 0]) cube([1, 1, 5.041368283777651]);

translate([11, 3, 0]) cube([1, 1, 4.7384588615607415]);

translate([12, 3, 0]) cube([1, 1, 4.140664396881723]);

translate([13, 3, 0]) cube([1, 1, 3.9972443951259664]);

translate([14, 3, 0]) cube([1, 1, 3.881181300211222]);

translate([15, 3, 0]) cube([1, 1, 3.8438028255494534]);

translate([16, 3, 0]) cube([1, 1, 3.762170800465135]);

translate([17, 3, 0]) cube([1, 1, 3.653715282455072]);

translate([18, 3, 0]) cube([1, 1, 3.6537142356528753]);

translate([19, 3, 0]) cube([1, 1, 3.6537188048051203]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.2]);

translate([2, 4, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 4, 0]) cube([1, 1, 6]);

translate([10, 4, 0]) cube([1, 1, 5.3851470442536105]);

translate([11, 4, 0]) cube([1, 1, 4.825878349840229]);

translate([12, 4, 0]) cube([1, 1, 4.227502344259909]);

translate([13, 4, 0]) cube([1, 1, 4.0464946047386094]);

translate([14, 4, 0]) cube([1, 1, 4.025426929874626]);

translate([15, 4, 0]) cube([1, 1, 4.004426057717848]);

translate([16, 4, 0]) cube([1, 1, 4.010238529204551]);

translate([17, 4, 0]) cube([1, 1, 4.12493383690365]);

translate([18, 4, 0]) cube([1, 1, 4.014753646937947]);

translate([19, 4, 0]) cube([1, 1, 3.911950094615532]);

translate([0, 5, 0]) cube([1, 1, 7.9]);

translate([1, 5, 0]) cube([1, 1, 7.4]);

translate([2, 5, 0]) cube([1, 1, 7.0]);

translate([3, 5, 0]) cube([1, 1, 6.6066666666666665]);

translate([4, 5, 0]) cube([1, 1, 6.534880952380952]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

translate([8, 5, 0]) cube([1, 1, 5.487557948225129]);

translate([9, 5, 0]) cube([1, 1, 5.337636370396132]);

translate([10, 5, 0]) cube([1, 1, 4.637468938501171]);

translate([11, 5, 0]) cube([1, 1, 4.126693388629253]);

translate([12, 5, 0]) cube([1, 1, 4.051827513068721]);

translate([13, 5, 0]) cube([1, 1, 4.05044610559701]);

translate([14, 5, 0]) cube([1, 1, 4.050044632553656]);

translate([15, 5, 0]) cube([1, 1, 4.052121460874057]);

translate([16, 5, 0]) cube([1, 1, 4.662479419933985]);

translate([17, 5, 0]) cube([1, 1, 4.727737762290274]);

translate([18, 5, 0]) cube([1, 1, 4.513671553483362]);

translate([19, 5, 0]) cube([1, 1, 4.507425083425289]);

translate([0, 6, 0]) cube([1, 1, 7.9]);

translate([1, 6, 0]) cube([1, 1, 7.2]);

translate([2, 6, 0]) cube([1, 1, 6.7]);

translate([3, 6, 0]) cube([1, 1, 6.537380952380952]);

translate([4, 6, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 6, 0]) cube([1, 1, 6]);

translate([11, 6, 0]) cube([1, 1, 5.071781059206312]);

translate([12, 6, 0]) cube([1, 1, 4.925585261321263]);

translate([13, 6, 0]) cube([1, 1, 4.76723965720087]);

translate([14, 6, 0]) cube([1, 1, 5.179263505709552]);

translate([15, 6, 0]) cube([1, 1, 4.42507366428137]);

translate([16, 6, 0]) cube([1, 1, 5.389926681783823]);

translate([17, 6, 0]) cube([1, 1, 5.12864064695837]);

translate([18, 6, 0]) cube([1, 1, 4.909764006904203]);

translate([19, 6, 0]) cube([1, 1, 5.2005275205761325]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.4]);

translate([2, 7, 0]) cube([1, 1, 6.9]);

translate([3, 7, 0]) cube([1, 1, 7.1]);

translate([4, 7, 0]) cube([1, 1, 7.2]);

color([0,1,0])
translate([5, 7, 0]) cube([1, 1, 6]);

translate([6, 7, 0]) cube([1, 1, 6.580191431051777]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

translate([11, 7, 0]) cube([1, 1, 5.074129193178512]);

translate([12, 7, 0]) cube([1, 1, 5.013836351665981]);

translate([13, 7, 0]) cube([1, 1, 5.013519964566683]);

translate([14, 7, 0]) cube([1, 1, 5.492309105058698]);

translate([15, 7, 0]) cube([1, 1, 4.907311066024947]);

color([0,1,0])
translate([16, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 8.1]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 7.4]);

translate([3, 8, 0]) cube([1, 1, 7.6]);

translate([4, 8, 0]) cube([1, 1, 7.5]);

color([0,1,0])
translate([5, 8, 0]) cube([1, 1, 6]);

translate([6, 8, 0]) cube([1, 1, 6.889893999928013]);

translate([7, 8, 0]) cube([1, 1, 6.735643863239425]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

translate([11, 8, 0]) cube([1, 1, 5.321556007619095]);

translate([12, 8, 0]) cube([1, 1, 5.230980826278454]);

translate([13, 8, 0]) cube([1, 1, 5.230566801053476]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

translate([15, 8, 0]) cube([1, 1, 5.029165381857654]);

color([0,1,0])
translate([16, 8, 0]) cube([1, 1, 6]);

translate([17, 8, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([18, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 8.1]);

translate([1, 9, 0]) cube([1, 1, 7.8]);

translate([2, 9, 0]) cube([1, 1, 7.6]);

translate([3, 9, 0]) cube([1, 1, 7.4]);

translate([4, 9, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([5, 9, 0]) cube([1, 1, 6]);

translate([6, 9, 0]) cube([1, 1, 7.033963214915596]);

translate([7, 9, 0]) cube([1, 1, 6.733263789264762]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

translate([9, 9, 0]) cube([1, 1, 6.500015490518905]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

translate([15, 9, 0]) cube([1, 1, 5.141108945463122]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 6.9]);

translate([18, 9, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.7]);

translate([1, 10, 0]) cube([1, 1, 7.3]);

translate([2, 10, 0]) cube([1, 1, 7.2]);

translate([3, 10, 0]) cube([1, 1, 6.807619047619047]);

translate([4, 10, 0]) cube([1, 1, 6.589933412518447]);

color([0,1,0])
translate([5, 10, 0]) cube([1, 1, 6]);

translate([6, 10, 0]) cube([1, 1, 6.838023251628693]);

translate([7, 10, 0]) cube([1, 1, 6.621149190482801]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

translate([9, 10, 0]) cube([1, 1, 6.600123924151238]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

translate([15, 10, 0]) cube([1, 1, 5.2210385887590585]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 6.6]);

translate([18, 10, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 6.9]);

translate([1, 11, 0]) cube([1, 1, 6.7]);

translate([2, 11, 0]) cube([1, 1, 6.601523809523809]);

color([0,1,0])
translate([3, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 11, 0]) cube([1, 1, 6]);

translate([5, 11, 0]) cube([1, 1, 5.391604643541682]);

color([0,1,0])
translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.512454109178496]);

translate([8, 11, 0]) cube([1, 1, 6.700495696604956]);

translate([9, 11, 0]) cube([1, 1, 6.800371772453717]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

translate([15, 11, 0]) cube([1, 1, 5.147550402596509]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 6.8]);

translate([1, 12, 0]) cube([1, 1, 6.500507936507937]);

color([0,1,0])
translate([2, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 12, 0]) cube([1, 1, 6]);

translate([5, 12, 0]) cube([1, 1, 5.288941666332205]);

color([0,1,0])
translate([6, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 12, 0]) cube([1, 1, 6]);

translate([8, 12, 0]) cube([1, 1, 6.802602407176021]);

translate([9, 12, 0]) cube([1, 1, 7.1]);

translate([10, 12, 0]) cube([1, 1, 6.503098103780978]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

translate([15, 12, 0]) cube([1, 1, 5.00707938012004]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 7.1]);

translate([1, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

translate([5, 13, 0]) cube([1, 1, 5.174338586758383]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

translate([8, 13, 0]) cube([1, 1, 6.644251784771606]);

translate([9, 13, 0]) cube([1, 1, 6.818216850232156]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

translate([15, 13, 0]) cube([1, 1, 4.909667813307451]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

translate([19, 13, 0]) cube([1, 1, 5.33230300080769]);

translate([0, 14, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

translate([5, 14, 0]) cube([1, 1, 5.174888259972377]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

translate([8, 14, 0]) cube([1, 1, 6.796130247513467]);

translate([9, 14, 0]) cube([1, 1, 6.860057634164777]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

translate([15, 14, 0]) cube([1, 1, 4.836393718439864]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

translate([19, 14, 0]) cube([1, 1, 5.090321360009559]);

translate([0, 15, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

translate([11, 15, 0]) cube([1, 1, 5.309834066511505]);

translate([12, 15, 0]) cube([1, 1, 5.237930455098126]);

translate([13, 15, 0]) cube([1, 1, 5.231607680111047]);

translate([14, 15, 0]) cube([1, 1, 5.223101762242166]);

translate([15, 15, 0]) cube([1, 1, 5.194322638624289]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

translate([18, 15, 0]) cube([1, 1, 5.204299566381356]);

translate([19, 15, 0]) cube([1, 1, 4.938420125927401]);

color([0,1,0])
translate([0, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 16, 0]) cube([1, 1, 6]);

translate([6, 16, 0]) cube([1, 1, 6.5402027606310025]);

translate([7, 16, 0]) cube([1, 1, 7.022839506172839]);

translate([8, 16, 0]) cube([1, 1, 7.104938271604938]);

translate([9, 16, 0]) cube([1, 1, 6.560538535630301]);

color([0,1,0])
translate([10, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

translate([18, 16, 0]) cube([1, 1, 5.275541383493178]);

translate([19, 16, 0]) cube([1, 1, 4.938460791427376]);

color([0,1,0])
translate([0, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

translate([6, 17, 0]) cube([1, 1, 6.707021604938272]);

translate([7, 17, 0]) cube([1, 1, 6.611355452674897]);

translate([8, 17, 0]) cube([1, 1, 6.517998616885026]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

translate([16, 18, 0]) cube([1, 1, 5.421301921389392]);

translate([17, 18, 0]) cube([1, 1, 5.354206437900996]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 5.400622630481567]);

translate([1, 19, 0]) cube([1, 1, 5.305368775583539]);

translate([2, 19, 0]) cube([1, 1, 5.3052832793161135]);

translate([3, 19, 0]) cube([1, 1, 5.11244090404979]);

translate([4, 19, 0]) cube([1, 1, 5.040633835301066]);

translate([5, 19, 0]) cube([1, 1, 5.307795639068881]);

translate([6, 19, 0]) cube([1, 1, 5.307925468219658]);

translate([7, 19, 0]) cube([1, 1, 5.066618155348267]);

translate([8, 19, 0]) cube([1, 1, 5.067987356896333]);

translate([9, 19, 0]) cube([1, 1, 5.44453794374059]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

translate([14, 19, 0]) cube([1, 1, 5.276435843889373]);

translate([15, 19, 0]) cube([1, 1, 5.342567508247098]);

translate([16, 19, 0]) cube([1, 1, 5.349101612723848]);

translate([17, 19, 0]) cube([1, 1, 5.407100638730535]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);
