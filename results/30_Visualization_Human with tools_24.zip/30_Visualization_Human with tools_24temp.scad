translate([0,0,0]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([-5,5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,1.5]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([-5,5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,3.0]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([-5,5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,4.5]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,6.0]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,7.5]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,9.0]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([-5,5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,10.5]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,12.0]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([-5,5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,13.5]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,15.0]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([-5,5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,16.5]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([-5,5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,18.0]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([-5,5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,19.5]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,21.0]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,22.5]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,24.0]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,25.5]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,27.0]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,28.5]) union(){
translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,30.0]) union(){
translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,31.5])translate([5,0,10]) rotate([90,0,90]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,53.0])translate([5,0,10]) rotate([90,0,90]) union(){
translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,74.5])translate([5,0,10]) rotate([90,0,90]) union(){
translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


