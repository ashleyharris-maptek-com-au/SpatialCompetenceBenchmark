
translate([0, 0, 0]) cube([1, 1, 4.604167725494509]);

translate([1, 0, 0]) cube([1, 1, 4.018202699198875]);

translate([2, 0, 0]) cube([1, 1, 4.589999999999992]);

translate([3, 0, 0]) cube([1, 1, 4.509999999999991]);

translate([4, 0, 0]) cube([1, 1, 4.46200223625865]);

translate([5, 0, 0]) cube([1, 1, 4.407730532087883]);

translate([6, 0, 0]) cube([1, 1, 4.366832518449194]);

translate([7, 0, 0]) cube([1, 1, 4.2681802391386565]);

translate([8, 0, 0]) cube([1, 1, 4.249999999999999]);

translate([9, 0, 0]) cube([1, 1, 4.4]);

translate([10, 0, 0]) cube([1, 1, 4.5]);

translate([11, 0, 0]) cube([1, 1, 4.3]);

translate([12, 0, 0]) cube([1, 1, 4.2]);

translate([13, 0, 0]) cube([1, 1, 4.2]);

translate([14, 0, 0]) cube([1, 1, 4.4]);

translate([15, 0, 0]) cube([1, 1, 4.8]);

translate([16, 0, 0]) cube([1, 1, 5.0]);

translate([17, 0, 0]) cube([1, 1, 5.2]);

translate([18, 0, 0]) cube([1, 1, 5.3]);

translate([19, 0, 0]) cube([1, 1, 5.4]);

translate([20, 0, 0]) cube([1, 1, 5.4]);

translate([21, 0, 0]) cube([1, 1, 5.2]);

translate([22, 0, 0]) cube([1, 1, 4.9]);

translate([23, 0, 0]) cube([1, 1, 4.6]);

translate([24, 0, 0]) cube([1, 1, 4.4]);

translate([25, 0, 0]) cube([1, 1, 4.3]);

translate([26, 0, 0]) cube([1, 1, 4.3]);

translate([27, 0, 0]) cube([1, 1, 4.3]);

translate([28, 0, 0]) cube([1, 1, 4.4]);

translate([29, 0, 0]) cube([1, 1, 4.6]);

translate([30, 0, 0]) cube([1, 1, 4.7]);

translate([31, 0, 0]) cube([1, 1, 4.8]);

translate([0, 1, 0]) cube([1, 1, 4.619999999999994]);

translate([1, 1, 0]) cube([1, 1, 4.676992476851841]);

translate([2, 1, 0]) cube([1, 1, 4.819999999999998]);

translate([3, 1, 0]) cube([1, 1, 4.689999999999996]);

translate([4, 1, 0]) cube([1, 1, 4.499999999999994]);

translate([5, 1, 0]) cube([1, 1, 4.435295125743362]);

translate([6, 1, 0]) cube([1, 1, 4.386767875087482]);

translate([7, 1, 0]) cube([1, 1, 4.296364203476166]);

translate([8, 1, 0]) cube([1, 1, 4.256244900826179]);

translate([9, 1, 0]) cube([1, 1, 4.22]);

translate([10, 1, 0]) cube([1, 1, 4.2]);

translate([11, 1, 0]) cube([1, 1, 4.049962258117027]);

translate([12, 1, 0]) cube([1, 1, 4.051755166239187]);

translate([13, 1, 0]) cube([1, 1, 4.050991731115355]);

translate([14, 1, 0]) cube([1, 1, 4.050532393512279]);

translate([15, 1, 0]) cube([1, 1, 4.3]);

translate([16, 1, 0]) cube([1, 1, 4.5]);

translate([17, 1, 0]) cube([1, 1, 4.6]);

translate([18, 1, 0]) cube([1, 1, 4.8]);

translate([19, 1, 0]) cube([1, 1, 4.9]);

translate([20, 1, 0]) cube([1, 1, 4.8]);

translate([21, 1, 0]) cube([1, 1, 4.7]);

translate([22, 1, 0]) cube([1, 1, 4.5]);

translate([23, 1, 0]) cube([1, 1, 4.4]);

translate([24, 1, 0]) cube([1, 1, 4.2]);

translate([25, 1, 0]) cube([1, 1, 4.0]);

translate([26, 1, 0]) cube([1, 1, 3.8]);

translate([27, 1, 0]) cube([1, 1, 3.7]);

translate([28, 1, 0]) cube([1, 1, 3.9]);

translate([29, 1, 0]) cube([1, 1, 4.0]);

translate([30, 1, 0]) cube([1, 1, 4.2]);

translate([31, 1, 0]) cube([1, 1, 4.3]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

translate([2, 2, 0]) cube([1, 1, 4.676992371182064]);

translate([3, 2, 0]) cube([1, 1, 5.189999999999998]);

translate([4, 2, 0]) cube([1, 1, 4.899999999999998]);

translate([5, 2, 0]) cube([1, 1, 4.609999999999998]);

translate([6, 2, 0]) cube([1, 1, 4.509999999999998]);

translate([7, 2, 0]) cube([1, 1, 4.489999999999998]);

translate([8, 2, 0]) cube([1, 1, 4.329999999999999]);

translate([9, 2, 0]) cube([1, 1, 4.2]);

translate([10, 2, 0]) cube([1, 1, 4.049889802388676]);

translate([11, 2, 0]) cube([1, 1, 4.049922343034535]);

translate([12, 2, 0]) cube([1, 1, 4.051013204410563]);

translate([13, 2, 0]) cube([1, 1, 4.050992370141878]);

translate([14, 2, 0]) cube([1, 1, 4.050532360691746]);

translate([15, 2, 0]) cube([1, 1, 4.05071706132774]);

translate([16, 2, 0]) cube([1, 1, 4.2]);

translate([17, 2, 0]) cube([1, 1, 4.3]);

translate([18, 2, 0]) cube([1, 1, 4.4]);

translate([19, 2, 0]) cube([1, 1, 4.5]);

translate([20, 2, 0]) cube([1, 1, 4.4]);

translate([21, 2, 0]) cube([1, 1, 4.3]);

translate([22, 2, 0]) cube([1, 1, 4.2]);

translate([23, 2, 0]) cube([1, 1, 4.0]);

translate([24, 2, 0]) cube([1, 1, 4.0]);

translate([25, 2, 0]) cube([1, 1, 3.9]);

translate([26, 2, 0]) cube([1, 1, 3.6]);

translate([27, 2, 0]) cube([1, 1, 3.4534817038459136]);

translate([28, 2, 0]) cube([1, 1, 3.5]);

translate([29, 2, 0]) cube([1, 1, 3.8]);

translate([30, 2, 0]) cube([1, 1, 3.9]);

translate([31, 2, 0]) cube([1, 1, 3.8]);

translate([0, 3, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

translate([3, 3, 0]) cube([1, 1, 4.68125685967808]);

translate([4, 3, 0]) cube([1, 1, 5.499999999999998]);

translate([5, 3, 0]) cube([1, 1, 5.209999999999997]);

translate([6, 3, 0]) cube([1, 1, 5.099999999999998]);

translate([7, 3, 0]) cube([1, 1, 4.999999999999998]);

translate([8, 3, 0]) cube([1, 1, 4.759999999999999]);

translate([9, 3, 0]) cube([1, 1, 4.459999999999999]);

translate([10, 3, 0]) cube([1, 1, 4.169999999999998]);

translate([11, 3, 0]) cube([1, 1, 4.050673264183278]);

translate([12, 3, 0]) cube([1, 1, 4.2]);

translate([13, 3, 0]) cube([1, 1, 4.3]);

translate([14, 3, 0]) cube([1, 1, 4.3]);

translate([15, 3, 0]) cube([1, 1, 4.2]);

translate([16, 3, 0]) cube([1, 1, 4.3]);

translate([17, 3, 0]) cube([1, 1, 4.41]);

translate([18, 3, 0]) cube([1, 1, 4.41]);

translate([19, 3, 0]) cube([1, 1, 4.31]);

translate([20, 3, 0]) cube([1, 1, 4.21]);

translate([21, 3, 0]) cube([1, 1, 4.109999999999999]);

translate([22, 3, 0]) cube([1, 1, 3.8]);

translate([23, 3, 0]) cube([1, 1, 3.6399988654430304]);

translate([24, 3, 0]) cube([1, 1, 3.6299999999999994]);

translate([25, 3, 0]) cube([1, 1, 3.6]);

translate([26, 3, 0]) cube([1, 1, 3.453496614154214]);

translate([27, 3, 0]) cube([1, 1, 3.453587267886161]);

translate([28, 3, 0]) cube([1, 1, 3.453526294444625]);

translate([29, 3, 0]) cube([1, 1, 3.6]);

translate([30, 3, 0]) cube([1, 1, 3.7]);

translate([31, 3, 0]) cube([1, 1, 3.6]);

translate([0, 4, 0]) cube([1, 1, 7.2]);

translate([1, 4, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

translate([4, 4, 0]) cube([1, 1, 4.68125622225751]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 4, 0]) cube([1, 1, 6]);

translate([7, 4, 0]) cube([1, 1, 5.399999999999998]);

translate([8, 4, 0]) cube([1, 1, 5.079999999999998]);

translate([9, 4, 0]) cube([1, 1, 4.709999999999997]);

translate([10, 4, 0]) cube([1, 1, 4.509999999999998]);

translate([11, 4, 0]) cube([1, 1, 4.459999999999999]);

translate([12, 4, 0]) cube([1, 1, 4.6]);

translate([13, 4, 0]) cube([1, 1, 4.8]);

translate([14, 4, 0]) cube([1, 1, 4.8]);

translate([15, 4, 0]) cube([1, 1, 4.7]);

translate([16, 4, 0]) cube([1, 1, 4.7]);

translate([17, 4, 0]) cube([1, 1, 4.7]);

translate([18, 4, 0]) cube([1, 1, 4.41]);

translate([19, 4, 0]) cube([1, 1, 4.119999999999999]);

translate([20, 4, 0]) cube([1, 1, 4.039999999999999]);

translate([21, 4, 0]) cube([1, 1, 3.939999999999999]);

translate([22, 4, 0]) cube([1, 1, 3.7599999999999967]);

translate([23, 4, 0]) cube([1, 1, 3.6986281277593234]);

translate([24, 4, 0]) cube([1, 1, 3.632944532242225]);

translate([25, 4, 0]) cube([1, 1, 3.5199999999999996]);

translate([26, 4, 0]) cube([1, 1, 3.4533761823890523]);

translate([27, 4, 0]) cube([1, 1, 3.453624946400604]);

translate([28, 4, 0]) cube([1, 1, 3.4535877635705785]);

translate([29, 4, 0]) cube([1, 1, 3.5]);

translate([30, 4, 0]) cube([1, 1, 3.6]);

translate([31, 4, 0]) cube([1, 1, 3.558080000269414]);

translate([0, 5, 0]) cube([1, 1, 7.4]);

translate([1, 5, 0]) cube([1, 1, 6.9]);

translate([2, 5, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

translate([5, 5, 0]) cube([1, 1, 5.201726103174601]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

translate([8, 5, 0]) cube([1, 1, 5.4099999999999975]);

translate([9, 5, 0]) cube([1, 1, 5.039999999999997]);

translate([10, 5, 0]) cube([1, 1, 4.839999999999997]);

translate([11, 5, 0]) cube([1, 1, 4.979999999999999]);

translate([12, 5, 0]) cube([1, 1, 5.1]);

translate([13, 5, 0]) cube([1, 1, 5.3]);

translate([14, 5, 0]) cube([1, 1, 5.3]);

translate([15, 5, 0]) cube([1, 1, 5.1]);

translate([16, 5, 0]) cube([1, 1, 5.1]);

translate([17, 5, 0]) cube([1, 1, 4.9]);

translate([18, 5, 0]) cube([1, 1, 4.5]);

translate([19, 5, 0]) cube([1, 1, 4.0699999999999985]);

translate([20, 5, 0]) cube([1, 1, 3.9099999999999975]);

translate([21, 5, 0]) cube([1, 1, 3.839999999999997]);

translate([22, 5, 0]) cube([1, 1, 3.7708703983201084]);

translate([23, 5, 0]) cube([1, 1, 3.7659910629021573]);

translate([24, 5, 0]) cube([1, 1, 3.7115171425258326]);

translate([25, 5, 0]) cube([1, 1, 3.5299999999999994]);

translate([26, 5, 0]) cube([1, 1, 3.5]);

translate([27, 5, 0]) cube([1, 1, 3.4535150065958926]);

translate([28, 5, 0]) cube([1, 1, 3.4535975737210274]);

translate([29, 5, 0]) cube([1, 1, 3.5]);

translate([30, 5, 0]) cube([1, 1, 3.6]);

translate([31, 5, 0]) cube([1, 1, 3.6]);

translate([0, 6, 0]) cube([1, 1, 7.7]);

translate([1, 6, 0]) cube([1, 1, 7.2]);

translate([2, 6, 0]) cube([1, 1, 7.0]);

translate([3, 6, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([4, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

translate([6, 6, 0]) cube([1, 1, 5.2883273317460295]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.359999999999997]);

translate([10, 6, 0]) cube([1, 1, 5.2499999999999964]);

translate([11, 6, 0]) cube([1, 1, 5.389999999999998]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([16, 6, 0]) cube([1, 1, 5.3]);

translate([17, 6, 0]) cube([1, 1, 5.0]);

translate([18, 6, 0]) cube([1, 1, 4.5]);

translate([19, 6, 0]) cube([1, 1, 3.343372004651603]);

translate([20, 6, 0]) cube([1, 1, 3.899999999999996]);

translate([21, 6, 0]) cube([1, 1, 3.8099999999999934]);

translate([22, 6, 0]) cube([1, 1, 3.7999999999999936]);

translate([23, 6, 0]) cube([1, 1, 3.761469604356269]);

translate([24, 6, 0]) cube([1, 1, 3.7199999999999975]);

translate([25, 6, 0]) cube([1, 1, 3.7299999999999995]);

translate([26, 6, 0]) cube([1, 1, 3.8]);

translate([27, 6, 0]) cube([1, 1, 3.9]);

translate([28, 6, 0]) cube([1, 1, 3.8]);

translate([29, 6, 0]) cube([1, 1, 3.8]);

translate([30, 6, 0]) cube([1, 1, 3.8]);

translate([31, 6, 0]) cube([1, 1, 3.7]);

translate([0, 7, 0]) cube([1, 1, 8.0]);

translate([1, 7, 0]) cube([1, 1, 7.5]);

translate([2, 7, 0]) cube([1, 1, 7.3]);

translate([3, 7, 0]) cube([1, 1, 7.0]);

translate([4, 7, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([5, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

translate([7, 7, 0]) cube([1, 1, 5.341761690178237]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([16, 7, 0]) cube([1, 1, 5.4]);

translate([17, 7, 0]) cube([1, 1, 4.9]);

translate([18, 7, 0]) cube([1, 1, 4.6]);

translate([19, 7, 0]) cube([1, 1, 4.249999999999999]);

translate([20, 7, 0]) cube([1, 1, 3.346339894750114]);

translate([21, 7, 0]) cube([1, 1, 3.899999999999996]);

translate([22, 7, 0]) cube([1, 1, 3.939999999999997]);

translate([23, 7, 0]) cube([1, 1, 4.089999999999998]);

translate([24, 7, 0]) cube([1, 1, 4.089999999999998]);

translate([25, 7, 0]) cube([1, 1, 4.149999999999999]);

translate([26, 7, 0]) cube([1, 1, 4.31]);

translate([27, 7, 0]) cube([1, 1, 4.4]);

translate([28, 7, 0]) cube([1, 1, 4.3]);

translate([29, 7, 0]) cube([1, 1, 4.2]);

translate([30, 7, 0]) cube([1, 1, 4.1]);

translate([31, 7, 0]) cube([1, 1, 4.0]);

translate([0, 8, 0]) cube([1, 1, 7.9]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 7.3]);

translate([3, 8, 0]) cube([1, 1, 7.0]);

translate([4, 8, 0]) cube([1, 1, 6.8]);

translate([5, 8, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([6, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

translate([8, 8, 0]) cube([1, 1, 5.351849206419136]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([16, 8, 0]) cube([1, 1, 5.4]);

translate([17, 8, 0]) cube([1, 1, 5.0]);

translate([18, 8, 0]) cube([1, 1, 4.7]);

translate([19, 8, 0]) cube([1, 1, 4.41]);

translate([20, 8, 0]) cube([1, 1, 4.209999999999997]);

translate([21, 8, 0]) cube([1, 1, 3.343721977884876]);

translate([22, 8, 0]) cube([1, 1, 4.309999999999998]);

translate([23, 8, 0]) cube([1, 1, 4.599999999999998]);

translate([24, 8, 0]) cube([1, 1, 4.689999999999998]);

translate([25, 8, 0]) cube([1, 1, 4.689999999999998]);

translate([26, 8, 0]) cube([1, 1, 4.669999999999998]);

translate([27, 8, 0]) cube([1, 1, 4.72]);

translate([28, 8, 0]) cube([1, 1, 4.609999999999999]);

translate([29, 8, 0]) cube([1, 1, 4.5]);

translate([30, 8, 0]) cube([1, 1, 4.5]);

translate([31, 8, 0]) cube([1, 1, 4.4]);

translate([0, 9, 0]) cube([1, 1, 7.9]);

translate([1, 9, 0]) cube([1, 1, 7.4]);

translate([2, 9, 0]) cube([1, 1, 7.1]);

translate([3, 9, 0]) cube([1, 1, 6.9]);

translate([4, 9, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([5, 9, 0]) cube([1, 1, 6]);

translate([6, 9, 0]) cube([1, 1, 6.6]);

translate([7, 9, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

translate([9, 9, 0]) cube([1, 1, 5.375070318171679]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 5.1]);

translate([18, 9, 0]) cube([1, 1, 4.9]);

translate([19, 9, 0]) cube([1, 1, 4.7]);

translate([20, 9, 0]) cube([1, 1, 4.579999999999998]);

translate([21, 9, 0]) cube([1, 1, 4.509999999999998]);

translate([22, 9, 0]) cube([1, 1, 3.632924990496201]);

translate([23, 9, 0]) cube([1, 1, 5.089999999999998]);

translate([24, 9, 0]) cube([1, 1, 5.189999999999998]);

translate([25, 9, 0]) cube([1, 1, 5.189999999999998]);

translate([26, 9, 0]) cube([1, 1, 5.079999999999998]);

translate([27, 9, 0]) cube([1, 1, 4.959999999999999]);

translate([28, 9, 0]) cube([1, 1, 4.849999999999999]);

translate([29, 9, 0]) cube([1, 1, 4.8]);

translate([30, 9, 0]) cube([1, 1, 4.9]);

translate([31, 9, 0]) cube([1, 1, 4.9]);

translate([0, 10, 0]) cube([1, 1, 8.0]);

translate([1, 10, 0]) cube([1, 1, 7.5]);

translate([2, 10, 0]) cube([1, 1, 7.1]);

translate([3, 10, 0]) cube([1, 1, 6.7]);

translate([4, 10, 0]) cube([1, 1, 6.6]);

translate([5, 10, 0]) cube([1, 1, 6.6]);

translate([6, 10, 0]) cube([1, 1, 6.8]);

translate([7, 10, 0]) cube([1, 1, 6.9]);

translate([8, 10, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

translate([10, 10, 0]) cube([1, 1, 5.392887465270341]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 5.119999999999999]);

translate([18, 10, 0]) cube([1, 1, 4.9]);

translate([19, 10, 0]) cube([1, 1, 4.81]);

translate([20, 10, 0]) cube([1, 1, 4.7799999999999985]);

translate([21, 10, 0]) cube([1, 1, 4.799999999999998]);

translate([22, 10, 0]) cube([1, 1, 5.189999999999998]);

translate([23, 10, 0]) cube([1, 1, 4.167135064934079]);

color([0,1,0])
translate([24, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 10, 0]) cube([1, 1, 6]);

translate([26, 10, 0]) cube([1, 1, 5.499999999999998]);

translate([27, 10, 0]) cube([1, 1, 5.289999999999998]);

translate([28, 10, 0]) cube([1, 1, 5.159999999999998]);

translate([29, 10, 0]) cube([1, 1, 5.129999999999999]);

translate([30, 10, 0]) cube([1, 1, 5.3]);

translate([31, 10, 0]) cube([1, 1, 5.4]);

translate([0, 11, 0]) cube([1, 1, 8.2]);

translate([1, 11, 0]) cube([1, 1, 7.7]);

translate([2, 11, 0]) cube([1, 1, 7.2]);

translate([3, 11, 0]) cube([1, 1, 6.9]);

translate([4, 11, 0]) cube([1, 1, 6.9]);

translate([5, 11, 0]) cube([1, 1, 7.0]);

translate([6, 11, 0]) cube([1, 1, 7.2]);

translate([7, 11, 0]) cube([1, 1, 7.1]);

translate([8, 11, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

translate([11, 11, 0]) cube([1, 1, 5.409101360624212]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

translate([17, 11, 0]) cube([1, 1, 5.149999999999999]);

translate([18, 11, 0]) cube([1, 1, 5.0]);

translate([19, 11, 0]) cube([1, 1, 4.9]);

translate([20, 11, 0]) cube([1, 1, 4.869999999999998]);

translate([21, 11, 0]) cube([1, 1, 4.899999999999998]);

translate([22, 11, 0]) cube([1, 1, 5.309999999999998]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

translate([24, 11, 0]) cube([1, 1, 4.598302452962909]);

color([0,1,0])
translate([25, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 8.2]);

translate([1, 12, 0]) cube([1, 1, 7.7]);

translate([2, 12, 0]) cube([1, 1, 7.3]);

translate([3, 12, 0]) cube([1, 1, 7.2]);

translate([4, 12, 0]) cube([1, 1, 7.3]);

translate([5, 12, 0]) cube([1, 1, 7.4]);

translate([6, 12, 0]) cube([1, 1, 7.5]);

translate([7, 12, 0]) cube([1, 1, 7.2]);

translate([8, 12, 0]) cube([1, 1, 6.9]);

translate([9, 12, 0]) cube([1, 1, 6.6]);

translate([10, 12, 0]) cube([1, 1, 6.609999999999999]);

translate([11, 12, 0]) cube([1, 1, 6.619999999999999]);

translate([12, 12, 0]) cube([1, 1, 5.449055857463566]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

translate([17, 12, 0]) cube([1, 1, 5.3599999999999985]);

translate([18, 12, 0]) cube([1, 1, 5.129999999999999]);

translate([19, 12, 0]) cube([1, 1, 5.0]);

translate([20, 12, 0]) cube([1, 1, 4.949999999999999]);

translate([21, 12, 0]) cube([1, 1, 5.059999999999999]);

translate([22, 12, 0]) cube([1, 1, 5.389999999999998]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 12, 0]) cube([1, 1, 6]);

translate([25, 12, 0]) cube([1, 1, 4.624272907420732]);

color([0,1,0])
translate([26, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 8.1]);

translate([1, 13, 0]) cube([1, 1, 7.7]);

translate([2, 13, 0]) cube([1, 1, 7.5]);

translate([3, 13, 0]) cube([1, 1, 7.5]);

translate([4, 13, 0]) cube([1, 1, 7.6]);

translate([5, 13, 0]) cube([1, 1, 7.6]);

translate([6, 13, 0]) cube([1, 1, 7.6]);

translate([7, 13, 0]) cube([1, 1, 7.3]);

translate([8, 13, 0]) cube([1, 1, 7.0]);

translate([9, 13, 0]) cube([1, 1, 6.8]);

translate([10, 13, 0]) cube([1, 1, 6.8]);

translate([11, 13, 0]) cube([1, 1, 6.8]);

translate([12, 13, 0]) cube([1, 1, 6.649999999999999]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

translate([18, 13, 0]) cube([1, 1, 5.4]);

translate([19, 13, 0]) cube([1, 1, 5.3]);

translate([20, 13, 0]) cube([1, 1, 5.2]);

translate([21, 13, 0]) cube([1, 1, 5.249999999999999]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 13, 0]) cube([1, 1, 6]);

translate([26, 13, 0]) cube([1, 1, 5.088625466741458]);

translate([27, 13, 0]) cube([1, 1, 6.629999999999999]);

translate([28, 13, 0]) cube([1, 1, 6.7299999999999995]);

translate([29, 13, 0]) cube([1, 1, 6.619999999999999]);

color([0,1,0])
translate([30, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 8.2]);

translate([1, 14, 0]) cube([1, 1, 7.8]);

translate([2, 14, 0]) cube([1, 1, 7.7]);

translate([3, 14, 0]) cube([1, 1, 7.6]);

translate([4, 14, 0]) cube([1, 1, 7.6]);

translate([5, 14, 0]) cube([1, 1, 7.5]);

translate([6, 14, 0]) cube([1, 1, 7.4]);

translate([7, 14, 0]) cube([1, 1, 7.2]);

translate([8, 14, 0]) cube([1, 1, 7.0]);

translate([9, 14, 0]) cube([1, 1, 7.0]);

translate([10, 14, 0]) cube([1, 1, 7.0]);

translate([11, 14, 0]) cube([1, 1, 6.8]);

translate([12, 14, 0]) cube([1, 1, 6.639999999999999]);

translate([13, 14, 0]) cube([1, 1, 6.529999999999998]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

translate([15, 14, 0]) cube([1, 1, 6.539999999999999]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 14, 0]) cube([1, 1, 6]);

translate([26, 14, 0]) cube([1, 1, 6.539999999999999]);

translate([27, 14, 0]) cube([1, 1, 5.300695167247107]);

translate([28, 14, 0]) cube([1, 1, 7.01]);

translate([29, 14, 0]) cube([1, 1, 6.819999999999999]);

color([0,1,0])
translate([30, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 8.1]);

translate([1, 15, 0]) cube([1, 1, 7.8]);

translate([2, 15, 0]) cube([1, 1, 7.7]);

translate([3, 15, 0]) cube([1, 1, 7.5]);

translate([4, 15, 0]) cube([1, 1, 7.3]);

translate([5, 15, 0]) cube([1, 1, 7.1]);

translate([6, 15, 0]) cube([1, 1, 6.9]);

translate([7, 15, 0]) cube([1, 1, 6.8]);

translate([8, 15, 0]) cube([1, 1, 6.9]);

translate([9, 15, 0]) cube([1, 1, 6.9]);

translate([10, 15, 0]) cube([1, 1, 6.9]);

translate([11, 15, 0]) cube([1, 1, 6.72]);

translate([12, 15, 0]) cube([1, 1, 6.5699999999999985]);

translate([13, 15, 0]) cube([1, 1, 6.569999999999997]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

translate([15, 15, 0]) cube([1, 1, 6.619999999999999]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 15, 0]) cube([1, 1, 6]);

translate([26, 15, 0]) cube([1, 1, 6.539999999999999]);

translate([27, 15, 0]) cube([1, 1, 6.829999999999999]);

translate([28, 15, 0]) cube([1, 1, 6.91]);

translate([29, 15, 0]) cube([1, 1, 6.81]);

color([0,1,0])
translate([30, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 15, 0]) cube([1, 1, 6]);

translate([0, 16, 0]) cube([1, 1, 7.7]);

translate([1, 16, 0]) cube([1, 1, 7.4]);

translate([2, 16, 0]) cube([1, 1, 7.3]);

translate([3, 16, 0]) cube([1, 1, 7.2]);

translate([4, 16, 0]) cube([1, 1, 7.0]);

translate([5, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([6, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 16, 0]) cube([1, 1, 6]);

translate([8, 16, 0]) cube([1, 1, 6.6]);

translate([9, 16, 0]) cube([1, 1, 6.7]);

translate([10, 16, 0]) cube([1, 1, 6.8]);

translate([11, 16, 0]) cube([1, 1, 6.609999999999999]);

translate([12, 16, 0]) cube([1, 1, 6.589999999999998]);

translate([13, 16, 0]) cube([1, 1, 6.598499999999997]);

translate([14, 16, 0]) cube([1, 1, 6.589999999999998]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 16, 0]) cube([1, 1, 6]);

translate([27, 16, 0]) cube([1, 1, 6.52]);

translate([28, 16, 0]) cube([1, 1, 6.71]);

translate([29, 16, 0]) cube([1, 1, 6.609999999999999]);

color([0,1,0])
translate([30, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 16, 0]) cube([1, 1, 6]);

translate([0, 17, 0]) cube([1, 1, 7.1]);

translate([1, 17, 0]) cube([1, 1, 6.9]);

translate([2, 17, 0]) cube([1, 1, 6.9]);

translate([3, 17, 0]) cube([1, 1, 6.9]);

translate([4, 17, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 17, 0]) cube([1, 1, 6]);

translate([11, 17, 0]) cube([1, 1, 6.609999999999999]);

translate([12, 17, 0]) cube([1, 1, 6.559999999999999]);

translate([13, 17, 0]) cube([1, 1, 6.629999999999999]);

translate([14, 17, 0]) cube([1, 1, 6.629999999999999]);

translate([15, 17, 0]) cube([1, 1, 6.619999999999999]);

translate([16, 17, 0]) cube([1, 1, 5.406841110668172]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

translate([20, 17, 0]) cube([1, 1, 5.479999999999999]);

translate([21, 17, 0]) cube([1, 1, 5.43]);

color([0,1,0])
translate([22, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 17, 0]) cube([1, 1, 6]);

translate([0, 18, 0]) cube([1, 1, 6.8]);

translate([1, 18, 0]) cube([1, 1, 6.6]);

translate([2, 18, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

translate([12, 18, 0]) cube([1, 1, 6.6]);

translate([13, 18, 0]) cube([1, 1, 6.8]);

translate([14, 18, 0]) cube([1, 1, 6.9]);

translate([15, 18, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

translate([17, 18, 0]) cube([1, 1, 5.35201336837108]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([20, 18, 0]) cube([1, 1, 5.377734777760529]);

translate([21, 18, 0]) cube([1, 1, 5.369412725870405]);

translate([22, 18, 0]) cube([1, 1, 5.352217869779522]);

color([0,1,0])
translate([23, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 6.8]);

translate([1, 19, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

translate([13, 19, 0]) cube([1, 1, 6.9]);

translate([14, 19, 0]) cube([1, 1, 7.1]);

translate([15, 19, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([16, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);

translate([20, 19, 0]) cube([1, 1, 5.449999999999999]);

translate([21, 19, 0]) cube([1, 1, 5.362736077051079]);

translate([22, 19, 0]) cube([1, 1, 5.3444627611747215]);

color([0,1,0])
translate([23, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 19, 0]) cube([1, 1, 6]);

translate([0, 20, 0]) cube([1, 1, 7.0]);

translate([1, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([2, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

translate([6, 20, 0]) cube([1, 1, 5.499999999999998]);

color([0,1,0])
translate([7, 20, 0]) cube([1, 1, 6]);

translate([8, 20, 0]) cube([1, 1, 4.838259956835696]);

color([0,1,0])
translate([9, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

translate([13, 20, 0]) cube([1, 1, 6.8]);

translate([14, 20, 0]) cube([1, 1, 7.0]);

translate([15, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

translate([21, 20, 0]) cube([1, 1, 5.344042448885824]);

translate([22, 20, 0]) cube([1, 1, 5.346728737496041]);

translate([23, 20, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([24, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 20, 0]) cube([1, 1, 6]);

translate([31, 20, 0]) cube([1, 1, 5.3]);

translate([0, 21, 0]) cube([1, 1, 7.1]);

translate([1, 21, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

translate([4, 21, 0]) cube([1, 1, 5.436552665549]);

translate([5, 21, 0]) cube([1, 1, 5.432710363690963]);

translate([6, 21, 0]) cube([1, 1, 5.499999999999996]);

color([0,1,0])
translate([7, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 21, 0]) cube([1, 1, 6]);

translate([9, 21, 0]) cube([1, 1, 5.251465795304228]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

translate([13, 21, 0]) cube([1, 1, 6.72]);

translate([14, 21, 0]) cube([1, 1, 6.9]);

translate([15, 21, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

translate([22, 21, 0]) cube([1, 1, 5.346200484367161]);

translate([23, 21, 0]) cube([1, 1, 5.3472973259024075]);

translate([24, 21, 0]) cube([1, 1, 5.344210664584735]);

translate([25, 21, 0]) cube([1, 1, 5.342835576876968]);

color([0,1,0])
translate([26, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 21, 0]) cube([1, 1, 6]);

translate([30, 21, 0]) cube([1, 1, 5.4]);

translate([31, 21, 0]) cube([1, 1, 5.1]);

translate([0, 22, 0]) cube([1, 1, 7.1]);

translate([1, 22, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

translate([4, 22, 0]) cube([1, 1, 5.438647070659356]);

translate([5, 22, 0]) cube([1, 1, 5.439752648363373]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

translate([10, 22, 0]) cube([1, 1, 5.250071404105076]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

translate([13, 22, 0]) cube([1, 1, 6.739999999999999]);

translate([14, 22, 0]) cube([1, 1, 6.819999999999999]);

translate([15, 22, 0]) cube([1, 1, 6.609999999999999]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

translate([24, 22, 0]) cube([1, 1, 5.4]);

translate([25, 22, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([26, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 22, 0]) cube([1, 1, 6]);

translate([30, 22, 0]) cube([1, 1, 5.2]);

translate([31, 22, 0]) cube([1, 1, 4.9]);

translate([0, 23, 0]) cube([1, 1, 6.9]);

translate([1, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 23, 0]) cube([1, 1, 6]);

translate([4, 23, 0]) cube([1, 1, 5.439599921457394]);

color([0,1,0])
translate([5, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 23, 0]) cube([1, 1, 6]);

translate([11, 23, 0]) cube([1, 1, 5.480709876448883]);

translate([12, 23, 0]) cube([1, 1, 6.759999999999999]);

translate([13, 23, 0]) cube([1, 1, 6.9399999999999995]);

translate([14, 23, 0]) cube([1, 1, 7.029999999999999]);

translate([15, 23, 0]) cube([1, 1, 6.7299999999999995]);

color([0,1,0])
translate([16, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 23, 0]) cube([1, 1, 6]);

translate([29, 23, 0]) cube([1, 1, 5.3]);

translate([30, 23, 0]) cube([1, 1, 5.0]);

translate([31, 23, 0]) cube([1, 1, 4.8]);

translate([0, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 24, 0]) cube([1, 1, 6]);

translate([11, 24, 0]) cube([1, 1, 6.749999999999999]);

color([0,1,0])
translate([12, 24, 0]) cube([1, 1, 6]);

translate([13, 24, 0]) cube([1, 1, 7.139999999999999]);

translate([14, 24, 0]) cube([1, 1, 7.139999999999999]);

translate([15, 24, 0]) cube([1, 1, 6.629999999999999]);

color([0,1,0])
translate([16, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 24, 0]) cube([1, 1, 6]);

translate([27, 24, 0]) cube([1, 1, 5.4]);

translate([28, 24, 0]) cube([1, 1, 5.3]);

translate([29, 24, 0]) cube([1, 1, 5.0]);

translate([30, 24, 0]) cube([1, 1, 4.8]);

translate([31, 24, 0]) cube([1, 1, 4.6]);

color([0,1,0])
translate([0, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 25, 0]) cube([1, 1, 6]);

translate([10, 25, 0]) cube([1, 1, 6.539999999999999]);

translate([11, 25, 0]) cube([1, 1, 6.9399999999999995]);

translate([12, 25, 0]) cube([1, 1, 7.21]);

color([0,1,0])
translate([13, 25, 0]) cube([1, 1, 6]);

translate([14, 25, 0]) cube([1, 1, 7.029999999999999]);

translate([15, 25, 0]) cube([1, 1, 6.539999999999999]);

color([0,1,0])
translate([16, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 25, 0]) cube([1, 1, 6]);

translate([25, 25, 0]) cube([1, 1, 5.400019783659232]);

translate([26, 25, 0]) cube([1, 1, 5.4]);

translate([27, 25, 0]) cube([1, 1, 5.4]);

translate([28, 25, 0]) cube([1, 1, 5.2]);

translate([29, 25, 0]) cube([1, 1, 5.0]);

translate([30, 25, 0]) cube([1, 1, 4.7]);

translate([31, 25, 0]) cube([1, 1, 4.542264557440601]);

color([0,1,0])
translate([0, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 26, 0]) cube([1, 1, 6]);

translate([10, 26, 0]) cube([1, 1, 6.72]);

translate([11, 26, 0]) cube([1, 1, 6.93]);

translate([12, 26, 0]) cube([1, 1, 7.029999999999999]);

translate([13, 26, 0]) cube([1, 1, 6.93]);

color([0,1,0])
translate([14, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 26, 0]) cube([1, 1, 6]);

translate([25, 26, 0]) cube([1, 1, 5.400054856733055]);

translate([26, 26, 0]) cube([1, 1, 5.400069771860271]);

color([0,1,0])
translate([27, 26, 0]) cube([1, 1, 6]);

translate([28, 26, 0]) cube([1, 1, 5.4]);

translate([29, 26, 0]) cube([1, 1, 5.3]);

translate([30, 26, 0]) cube([1, 1, 5.0]);

translate([31, 26, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 27, 0]) cube([1, 1, 6]);

translate([9, 27, 0]) cube([1, 1, 6.6]);

translate([10, 27, 0]) cube([1, 1, 6.7]);

translate([11, 27, 0]) cube([1, 1, 6.72]);

translate([12, 27, 0]) cube([1, 1, 6.629999999999999]);

translate([13, 27, 0]) cube([1, 1, 6.549999999999999]);

color([0,1,0])
translate([14, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 27, 0]) cube([1, 1, 6]);

translate([31, 27, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([0, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 28, 0]) cube([1, 1, 6]);

translate([27, 28, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 29, 0]) cube([1, 1, 6]);

translate([26, 29, 0]) cube([1, 1, 5.4]);

translate([27, 29, 0]) cube([1, 1, 5.3]);

translate([28, 29, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([29, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 30, 0]) cube([1, 1, 6]);

translate([1, 30, 0]) cube([1, 1, 5.4]);

translate([2, 30, 0]) cube([1, 1, 5.4]);

translate([3, 30, 0]) cube([1, 1, 5.4]);

translate([4, 30, 0]) cube([1, 1, 5.3]);

translate([5, 30, 0]) cube([1, 1, 5.2]);

translate([6, 30, 0]) cube([1, 1, 5.1]);

translate([7, 30, 0]) cube([1, 1, 5.3]);

translate([8, 30, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([9, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 30, 0]) cube([1, 1, 6]);

translate([11, 30, 0]) cube([1, 1, 5.3]);

translate([12, 30, 0]) cube([1, 1, 5.2299999999999995]);

translate([13, 30, 0]) cube([1, 1, 5.329999999999999]);

translate([14, 30, 0]) cube([1, 1, 5.43]);

color([0,1,0])
translate([15, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 30, 0]) cube([1, 1, 6]);

translate([22, 30, 0]) cube([1, 1, 5.3]);

translate([23, 30, 0]) cube([1, 1, 5.3]);

translate([24, 30, 0]) cube([1, 1, 5.4]);

translate([25, 30, 0]) cube([1, 1, 5.4]);

translate([26, 30, 0]) cube([1, 1, 5.3]);

translate([27, 30, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([28, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 30, 0]) cube([1, 1, 6]);

translate([0, 31, 0]) cube([1, 1, 5.3]);

translate([1, 31, 0]) cube([1, 1, 5.201623594984261]);

translate([2, 31, 0]) cube([1, 1, 5.20162222617246]);

translate([3, 31, 0]) cube([1, 1, 5.3]);

translate([4, 31, 0]) cube([1, 1, 5.2]);

translate([5, 31, 0]) cube([1, 1, 5.0]);

translate([6, 31, 0]) cube([1, 1, 4.9683792571839]);

translate([7, 31, 0]) cube([1, 1, 5.0]);

translate([8, 31, 0]) cube([1, 1, 5.1]);

translate([9, 31, 0]) cube([1, 1, 5.1]);

translate([10, 31, 0]) cube([1, 1, 5.0]);

translate([11, 31, 0]) cube([1, 1, 4.857157694527178]);

translate([12, 31, 0]) cube([1, 1, 4.861758549287915]);

translate([13, 31, 0]) cube([1, 1, 4.861705551448298]);

translate([14, 31, 0]) cube([1, 1, 5.139999999999999]);

translate([15, 31, 0]) cube([1, 1, 5.339999999999999]);

translate([16, 31, 0]) cube([1, 1, 5.41]);

color([0,1,0])
translate([17, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 31, 0]) cube([1, 1, 6]);

translate([22, 31, 0]) cube([1, 1, 5.2]);

translate([23, 31, 0]) cube([1, 1, 5.1]);

translate([24, 31, 0]) cube([1, 1, 5.2]);

translate([25, 31, 0]) cube([1, 1, 5.2]);

translate([26, 31, 0]) cube([1, 1, 5.3]);

translate([27, 31, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 31, 0]) cube([1, 1, 6]);
