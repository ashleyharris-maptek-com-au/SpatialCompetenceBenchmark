
hull() {
    translate([10.045, 10.0, 94.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.855, 10.0, 94.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.945, 10.0, 94.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.755, 10.0, 94.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.845, 10.0, 94.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.655, 10.0, 94.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.745, 10.0, 94.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.555, 10.0, 93.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.645, 10.0, 93.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.455000000000002, 10.0, 93.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.545000000000002, 10.0, 93.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.355, 10.0, 93.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.445000000000002, 10.0, 93.18500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.255000000000003, 10.0, 92.91500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.345000000000002, 10.0, 92.88500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.155, 10.0, 92.61500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.245, 10.0, 92.58500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.055000000000003, 10.0, 92.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.145000000000003, 10.0, 92.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.955000000000002, 10.0, 92.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.045, 10.0, 91.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.855, 10.0, 91.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.945, 10.0, 91.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.755000000000003, 10.0, 91.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.845000000000002, 10.0, 91.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.655, 10.0, 91.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.745, 10.0, 91.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.555000000000003, 10.0, 90.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.645000000000003, 10.0, 90.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.455000000000002, 10.0, 90.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.545, 10.0, 90.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.355, 10.0, 90.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.445, 10.0, 90.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.255, 10.0, 89.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.345, 10.0, 89.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.154999999999998, 10.0, 89.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.244999999999997, 10.0, 89.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.055, 10.0, 89.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.145, 10.0, 89.28500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.955, 10.0, 89.01500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.044999999999998, 10.0, 88.98500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.854999999999997, 10.0, 88.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.945, 10.0, 88.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.755000000000003, 10.0, 88.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.845, 10.0, 88.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.655, 10.0, 88.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.744999999999997, 10.0, 88.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.555, 10.0, 87.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.645000000000003, 10.0, 87.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.455, 10.0, 87.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.545, 10.0, 87.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.355, 10.0, 87.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.445, 10.0, 87.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.254999999999995, 10.0, 86.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.345, 10.0, 86.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.155, 10.0, 86.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.245000000000005, 10.0, 86.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.055, 10.0, 86.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.145, 10.0, 86.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.955000000000005, 10.0, 86.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.045, 10.0, 85.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.855, 10.0, 85.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.945, 10.0, 85.68500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.755, 10.0, 85.41500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.845, 10.0, 85.38500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.655, 10.0, 85.11500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.745000000000005, 10.0, 85.08500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.555, 10.0, 84.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.644999999999996, 10.0, 84.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.455, 10.0, 84.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.545, 10.0, 84.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.355, 10.0, 84.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.44499999999999, 10.0, 84.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.254999999999995, 10.0, 83.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.345, 10.0, 83.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.155, 10.0, 83.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.245000000000005, 10.0, 83.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.05500000000001, 10.0, 83.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.145, 10.0, 83.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.955, 10.0, 83.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.045, 10.0, 82.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.855000000000004, 10.0, 82.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.945, 10.0, 82.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.754999999999995, 10.0, 82.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.845, 10.0, 82.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.65500000000001, 10.0, 82.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.745000000000005, 10.0, 82.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.555, 10.0, 81.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.645, 10.0, 81.78500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.455000000000005, 10.0, 81.51500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.545, 10.0, 81.48500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.355, 10.0, 81.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.445, 10.0, 81.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.255, 10.0, 80.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.345, 10.0, 80.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.155, 10.0, 80.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.245000000000005, 10.0, 80.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.05500000000001, 10.0, 80.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.145, 10.0, 80.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.955, 10.0, 80.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.045, 10.0, 79.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.855000000000004, 10.0, 79.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.945, 10.0, 79.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.754999999999995, 10.0, 79.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.845, 10.0, 79.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.65500000000001, 10.0, 79.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.745000000000005, 10.0, 79.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.55500000000001, 10.0, 78.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.645, 10.0, 78.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.455000000000005, 10.0, 78.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.545, 10.0, 78.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.355000000000004, 10.0, 78.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.445, 10.0, 78.18500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.255, 10.0, 77.91500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.345, 10.0, 77.88500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.155, 10.0, 77.61500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.245000000000005, 10.0, 77.58500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.055, 10.0, 77.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.144999999999996, 10.0, 77.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.955, 10.0, 77.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.045, 10.0, 76.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.855, 10.0, 76.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.94500000000001, 10.0, 76.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.755, 10.0, 76.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.845, 10.0, 76.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.655, 10.0, 76.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.745, 10.0, 76.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.55499999999999, 10.0, 75.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.645, 10.0, 75.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.455, 10.0, 75.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.545, 10.0, 75.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.355, 10.0, 75.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.44500000000001, 10.0, 75.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.255, 10.0, 74.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.345, 10.0, 74.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.155, 10.0, 74.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.245, 10.0, 74.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.055, 10.0, 74.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.145, 10.0, 74.28500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.955, 10.0, 74.01500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.045, 10.0, 73.98500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.855, 10.0, 73.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.94500000000001, 10.0, 73.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.755, 10.0, 73.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.845, 10.0, 73.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.65500000000002, 10.0, 73.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.745, 10.0, 73.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.55499999999999, 10.0, 72.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.645, 10.0, 72.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.455, 10.0, 72.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.545, 10.0, 72.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.355, 10.0, 72.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.44500000000001, 10.0, 72.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.25500000000001, 10.0, 71.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.345, 10.0, 71.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.155, 10.0, 71.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.245, 10.0, 71.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.05499999999999, 10.0, 71.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.145, 10.0, 71.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.955, 10.0, 71.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.045, 10.0, 70.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.85500000000002, 10.0, 70.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.94500000000001, 10.0, 70.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.755, 10.0, 70.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.845, 10.0, 70.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.655, 10.0, 70.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.745, 10.0, 70.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.55499999999999, 10.0, 69.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.645, 10.0, 69.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.45500000000001, 10.0, 69.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.54500000000002, 10.0, 69.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.35500000000002, 10.0, 69.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.44500000000001, 10.0, 69.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.255, 10.0, 68.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.345, 10.0, 68.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.155, 10.0, 68.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.245, 10.0, 68.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.055, 10.0, 68.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.14500000000001, 10.0, 68.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.95500000000001, 10.0, 68.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.045, 10.0, 67.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.855, 10.0, 67.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.94500000000001, 10.0, 67.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.755, 10.0, 67.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.845, 10.0, 67.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.655, 10.0, 67.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.745, 10.0, 67.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.555, 10.0, 66.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.645, 10.0, 66.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.455, 10.0, 66.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.545, 10.0, 66.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.355, 10.0, 66.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.44500000000001, 10.0, 66.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.255, 10.0, 65.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.345, 10.0, 65.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.15500000000002, 10.0, 65.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.245, 10.0, 65.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.055, 10.0, 65.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.145, 10.0, 65.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.955, 10.0, 65.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.0, 10.05, 64.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.0, 10.950000000000001, 64.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.0, 11.05, 64.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.0, 11.950000000000001, 64.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.0, 12.05, 64.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.0, 12.950000000000001, 64.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.0, 13.05, 64.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.0, 13.95, 63.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.0, 14.05, 63.785000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.0, 14.95, 63.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.0, 15.05, 63.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.0, 15.950000000000001, 63.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.0, 16.05, 63.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.0, 16.95, 62.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.0, 17.05, 62.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.0, 17.95, 62.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.0, 18.05, 62.58500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.0, 18.950000000000003, 62.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.0, 19.05, 62.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.0, 19.95, 62.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.95, 20.05, 61.98500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.05000000000001, 20.950000000000003, 61.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.95000000000002, 21.05, 61.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.05000000000001, 21.95, 61.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.95, 22.05, 61.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.05, 22.95, 61.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.95, 23.05, 61.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.05000000000001, 23.950000000000003, 60.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.95, 24.05, 60.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.05, 24.95, 60.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.95, 25.05, 60.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.05000000000001, 25.950000000000003, 60.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.95, 26.050000000000004, 60.18500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.05, 26.950000000000003, 59.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.95, 27.05, 59.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.05, 27.95, 59.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.95, 28.05, 59.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.05000000000001, 28.950000000000003, 59.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.95, 29.05, 59.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.05, 29.95, 59.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.95, 30.05, 58.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.05000000000001, 30.950000000000003, 58.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.95, 31.050000000000004, 58.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.05, 31.950000000000003, 58.415000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.95, 32.05, 58.385000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.05, 32.95, 58.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.95, 33.05, 58.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.05000000000001, 33.95, 57.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.95, 34.050000000000004, 57.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.05, 34.95, 57.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.95, 35.05, 57.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.05000000000001, 35.949999999999996, 57.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.95, 36.05, 57.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.05, 36.95, 56.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.95, 37.050000000000004, 56.885000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.05, 37.95, 56.61500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.95, 38.050000000000004, 56.58500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.05000000000001, 38.95, 56.315000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.95, 39.050000000000004, 56.285000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.05, 39.95, 56.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.95, 40.05, 55.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.05000000000001, 40.949999999999996, 55.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.95, 41.05, 55.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.05, 41.95, 55.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.95, 42.050000000000004, 55.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.05, 42.95, 55.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.95, 43.050000000000004, 55.08500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.05000000000001, 43.95, 54.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.95, 44.050000000000004, 54.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.05, 44.95, 54.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.95, 45.05, 54.48500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.05000000000001, 45.949999999999996, 54.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.95, 46.05, 54.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.05, 46.95, 53.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.95, 47.050000000000004, 53.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.05, 47.95, 53.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.95, 48.050000000000004, 53.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.05, 48.95, 53.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.95, 49.050000000000004, 53.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.05, 49.95, 53.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.95, 50.05, 52.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.05, 50.95, 52.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.95, 51.05, 52.68500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.05, 51.95, 52.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.95, 52.050000000000004, 52.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.05000000000001, 52.95, 52.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.95, 53.050000000000004, 52.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.05, 53.95, 51.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.95, 54.050000000000004, 51.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.05, 54.95, 51.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.95, 55.05, 51.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.05, 55.95, 51.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.95, 56.05, 51.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.050000000000004, 56.95, 50.915000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.95, 57.050000000000004, 50.885000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.050000000000004, 57.95, 50.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.95, 58.050000000000004, 50.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.05, 58.95, 50.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.95, 59.050000000000004, 50.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.05, 59.95, 50.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 60.05, 49.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 60.95, 49.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 61.05, 49.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 61.95, 49.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 62.050000000000004, 49.385000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 62.95, 49.11500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 63.050000000000004, 49.08500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 63.95, 48.815000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 64.05, 48.785000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 64.95, 48.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 65.05, 48.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 65.95, 48.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 66.05, 48.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 66.95, 47.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 67.05000000000001, 47.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 67.95, 47.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 68.05, 47.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 68.95, 47.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 69.05, 47.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 69.95, 47.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.95, 70.05, 46.98500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.050000000000004, 70.95, 46.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.95, 71.05, 46.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.050000000000004, 71.95, 46.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.95, 72.05, 46.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.050000000000004, 72.95, 46.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.95, 73.05, 46.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.05, 73.95, 45.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.95, 74.05000000000001, 45.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.05, 74.95, 45.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.95, 75.05, 45.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.050000000000004, 75.95, 45.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.95, 76.05000000000001, 45.18500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.050000000000004, 76.95, 44.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.95, 77.05, 44.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.050000000000004, 77.95, 44.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.95, 78.05, 44.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.05, 78.95, 44.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.95, 79.05000000000001, 44.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.05, 79.95, 44.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.95, 80.05, 43.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.050000000000004, 80.95, 43.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.95, 81.05000000000001, 43.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.050000000000004, 81.95, 43.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.95, 82.05, 43.385000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.050000000000004, 82.95, 43.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.95, 83.05, 43.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.05, 83.95, 42.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.949999999999996, 84.05000000000001, 42.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.05, 84.95, 42.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.95, 85.05, 42.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.050000000000004, 85.95, 42.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.95, 86.05000000000001, 42.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.050000000000004, 86.95, 41.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.95, 87.05, 41.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.050000000000004, 87.95, 41.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.95, 88.05, 41.58500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.05, 88.95, 41.315000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.949999999999996, 89.05000000000001, 41.285000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.05, 89.95, 41.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.0, 90.05, 40.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.0, 90.95, 40.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.0, 91.05000000000001, 40.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.0, 91.95, 40.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.0, 92.05, 40.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.0, 92.95, 40.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.0, 93.05, 40.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.0, 93.95, 39.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.0, 94.05000000000001, 39.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.0, 94.95, 39.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.0, 95.05, 39.48500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.0, 95.95, 39.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.0, 96.05000000000001, 39.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.0, 96.95, 38.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.0, 97.05, 38.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.0, 97.95, 38.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.0, 98.05000000000001, 38.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.0, 98.95000000000002, 38.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.0, 99.05000000000001, 38.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.0, 99.95, 38.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.05, 100.0, 37.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.949999999999996, 100.0, 37.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.05, 100.0, 37.68500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.95, 100.0, 37.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.050000000000004, 100.0, 37.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.95, 100.0, 37.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.050000000000004, 100.0, 37.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.95, 100.0, 36.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.050000000000004, 100.0, 36.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.95, 100.0, 36.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.05, 100.0, 36.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.949999999999996, 100.0, 36.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.05, 100.0, 36.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.95, 100.0, 35.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.050000000000004, 100.0, 35.885000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.95, 100.0, 35.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.050000000000004, 100.0, 35.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.95, 100.0, 35.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.050000000000004, 100.0, 35.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.95, 100.0, 35.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.05, 99.95, 34.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.95, 99.05000000000001, 34.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.05, 98.95000000000002, 34.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.95, 98.05000000000001, 34.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.050000000000004, 97.95, 34.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.95, 97.05, 34.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.050000000000004, 96.95, 34.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.95, 96.05000000000001, 33.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.050000000000004, 95.95, 33.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.95, 95.05, 33.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.05, 94.95, 33.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.95, 94.05000000000001, 33.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.05, 93.95, 33.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.95, 93.05, 32.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.050000000000004, 92.95, 32.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.95, 92.05, 32.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.050000000000004, 91.95, 32.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.95, 91.05000000000001, 32.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.050000000000004, 90.95, 32.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.95, 90.05, 32.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.05, 89.95, 31.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.95, 89.05000000000001, 31.715000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.05, 88.95, 31.685000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.95, 88.05, 31.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.050000000000004, 87.95, 31.384999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.95, 87.05, 31.115000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.050000000000004, 86.95, 31.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.95, 86.05000000000001, 30.815000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.05, 85.95, 30.785000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.95, 85.05, 30.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.05, 84.95, 30.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.95, 84.05000000000001, 30.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.05, 83.95, 30.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.95, 83.05, 29.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.05000000000001, 82.95, 29.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.95, 82.05, 29.615000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.05, 81.95, 29.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.95, 81.05000000000001, 29.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.05, 80.95, 29.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.95, 80.05, 29.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.0, 79.95, 28.985000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.0, 79.05000000000001, 28.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.0, 78.95, 28.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.0, 78.05, 28.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.0, 77.95, 28.384999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.0, 77.05, 28.115000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.0, 76.95, 28.085000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.0, 76.05000000000001, 27.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.0, 75.95, 27.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.0, 75.05, 27.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.0, 74.95, 27.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.0, 74.05000000000001, 27.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.0, 73.95, 27.185000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.0, 73.05, 26.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.0, 72.95, 26.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.0, 72.05, 26.615000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.0, 71.95, 26.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.0, 71.05, 26.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.0, 70.95, 26.285000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.0, 70.05, 26.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.95, 69.95, 25.985000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.05, 69.05, 25.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.95, 68.95, 25.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.05, 68.05, 25.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.95, 67.95, 25.384999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.05000000000001, 67.05000000000001, 25.115000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.95, 66.95, 25.085000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.05, 66.05, 24.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.95, 65.95, 24.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.05, 65.05, 24.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.95, 64.95, 24.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.05, 64.05, 24.215000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.95, 63.95, 24.185000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.050000000000004, 63.050000000000004, 23.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.95, 62.95, 23.884999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.050000000000004, 62.050000000000004, 23.615000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.95, 61.95, 23.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.05, 61.05, 23.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.95, 60.95, 23.285000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.05, 60.05, 23.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.95, 59.95, 22.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.050000000000004, 59.050000000000004, 22.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.95, 58.95, 22.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.050000000000004, 58.050000000000004, 22.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.95, 57.95, 22.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.050000000000004, 57.050000000000004, 22.115000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.95, 56.95, 22.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.05, 56.05, 21.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.95, 55.95, 21.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.05, 55.05, 21.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.95, 54.95, 21.485000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.050000000000004, 54.050000000000004, 21.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.95, 53.95, 21.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.050000000000004, 53.050000000000004, 20.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.95, 52.95, 20.884999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.050000000000004, 52.050000000000004, 20.615000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.95, 51.95, 20.585000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.05, 51.05, 20.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.95, 50.95, 20.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.05, 50.05, 20.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.95, 49.95, 19.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.050000000000004, 49.050000000000004, 19.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.95, 48.95, 19.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.050000000000004, 48.050000000000004, 19.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.95, 47.95, 19.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.050000000000004, 47.050000000000004, 19.115000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.95, 46.95, 19.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.05, 46.05, 18.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.949999999999996, 45.949999999999996, 18.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.05, 45.05, 18.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.95, 44.95, 18.485000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.050000000000004, 44.050000000000004, 18.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.95, 43.95, 18.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.050000000000004, 43.050000000000004, 17.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.95, 42.95, 17.884999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.050000000000004, 42.050000000000004, 17.615000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.95, 41.95, 17.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.05, 41.05, 17.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.949999999999996, 40.949999999999996, 17.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.05, 40.05, 17.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.95, 39.95, 16.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.050000000000004, 39.050000000000004, 16.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.95, 38.95, 16.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.050000000000004, 38.050000000000004, 16.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.95, 37.95, 16.384999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.050000000000004, 37.050000000000004, 16.115000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.95, 36.95, 16.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.05, 36.05, 15.815000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.949999999999996, 35.949999999999996, 15.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.05, 35.05, 15.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.95, 34.95, 15.485000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.050000000000004, 34.050000000000004, 15.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.95, 33.95, 15.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.05, 33.05, 14.915000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.95, 32.95, 14.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.05, 32.05, 14.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.950000000000003, 31.950000000000003, 14.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.050000000000004, 31.050000000000004, 14.315000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.950000000000003, 30.950000000000003, 14.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.05, 30.05, 14.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.95, 29.95, 13.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.05, 29.05, 13.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.950000000000003, 28.950000000000003, 13.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.05, 28.05, 13.415000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.95, 27.95, 13.385000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.05, 27.05, 13.114999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.950000000000003, 26.950000000000003, 13.084999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.050000000000004, 26.050000000000004, 12.815000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.950000000000003, 25.950000000000003, 12.785000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.05, 25.05, 12.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.95, 24.95, 12.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.05, 24.05, 12.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.950000000000003, 23.950000000000003, 12.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.05, 23.05, 11.915000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.95, 22.95, 11.885000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.05, 22.05, 11.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.95, 21.95, 11.584999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.05, 21.05, 11.315000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.950000000000003, 20.950000000000003, 11.285000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.05, 20.05, 11.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 20.05, 10.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 20.950000000000003, 10.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 21.05, 10.684999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 21.95, 10.415000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 22.05, 10.385000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 22.95, 10.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 23.05, 10.084999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 23.950000000000003, 9.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 24.05, 9.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 24.95, 9.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 25.05, 9.485000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 25.950000000000003, 9.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 26.050000000000004, 9.184999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 26.950000000000003, 8.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 27.05, 8.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 27.95, 8.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 28.05, 8.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 28.950000000000003, 8.315000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 29.05, 8.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 29.95, 8.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 30.05, 7.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 30.950000000000003, 7.715000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 31.050000000000004, 7.6850000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 31.950000000000003, 7.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 32.05, 7.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 32.95, 7.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 33.05, 7.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 33.95, 6.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 34.050000000000004, 6.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 34.95, 6.515000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 35.05, 6.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 35.949999999999996, 6.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 36.05, 6.1850000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 36.95, 5.915000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 37.050000000000004, 5.885000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 37.95, 5.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 38.050000000000004, 5.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 38.95, 5.3149999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 39.050000000000004, 5.284999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 39.95, 5.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.05, 40.0, 4.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.950000000000003, 40.0, 4.715000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.05, 40.0, 4.6850000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.95, 40.0, 4.415000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.05, 40.0, 4.385000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.95, 40.0, 4.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.05, 40.0, 4.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.950000000000003, 40.0, 3.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.05, 40.0, 3.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.95, 40.0, 3.5149999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.05, 40.0, 3.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.950000000000003, 40.0, 3.2150000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.050000000000004, 40.0, 3.1850000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.950000000000003, 40.0, 2.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.05, 40.0, 2.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.95, 40.0, 2.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.05, 40.0, 2.5850000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.950000000000003, 40.0, 2.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.05, 40.0, 2.2849999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.95, 40.0, 2.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.05, 40.0, 1.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.950000000000003, 40.0, 1.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.050000000000004, 40.0, 1.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.950000000000003, 40.0, 1.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.05, 40.0, 1.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.95, 40.0, 1.1150000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.05, 40.0, 1.0850000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.95, 40.0, 0.8150000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.050000000000004, 40.0, 0.7850000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.95, 40.0, 0.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.05, 40.0, 0.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.949999999999996, 40.0, 0.21500000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.05, 40.0, 0.19500000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.95, 40.0, 0.10500000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.050000000000004, 40.0, 0.09750000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.95, 40.0, 0.052500000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.050000000000004, 40.0, 0.04850000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.95, 40.0, 0.021500000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.050000000000004, 40.0, 0.019000000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.95, 40.0, 0.001]) cube([0.4, 0.4, 0.1], center=true);
}

