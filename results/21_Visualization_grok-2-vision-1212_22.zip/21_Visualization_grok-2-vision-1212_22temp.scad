
hull() {
    translate([0.045000000000000005, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.8550000000000001, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9450000000000001, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7550000000000001, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8450000000000002, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6550000000000002, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.745, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.555, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6450000000000005, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.455, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.545, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.355, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.445, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.255, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.345, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.155, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.245000000000001, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.055, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.145, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.955, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.045, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.855, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.945, 0.0, 4.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.755, 0.0, 4.5249999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.845, 0.0, 4.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.655, 0.0, 4.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.745, 0.0, 3.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.555, 0.0, 3.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.645, 0.0, 3.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.455, 0.0, 3.0250000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.545, 0.0, 2.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.355, 0.0, 2.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.445, 0.0, 2.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.255000000000003, 0.0, 2.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.345000000000002, 0.0, 1.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.155, 0.0, 1.5250000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.245, 0.0, 1.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.055000000000003, 0.0, 1.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.145000000000003, 0.0, 0.9750000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.955, 0.0, 0.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.044999999999998, 0.0, 0.47500000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.854999999999997, 0.0, 0.025]) cube([0.4, 0.4, 0.1], center=true);
}

