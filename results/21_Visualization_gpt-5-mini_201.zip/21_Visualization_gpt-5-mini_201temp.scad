
hull() {
    translate([150.15, 150.025, 249.98000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([152.85000000000002, 150.47500000000002, 249.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([153.15, 150.525, 249.57999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([155.85, 150.975, 249.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([156.15, 151.03, 249.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([158.85, 151.57, 248.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.15, 151.63, 248.78000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([161.85000000000002, 152.17, 248.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.15, 152.23499999999999, 248.38]) cube([0.4, 0.4, 0.1], center=true);
    translate([164.85, 152.865, 248.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.15, 152.935, 247.98000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([167.85000000000002, 153.565, 247.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.15, 153.64000000000001, 247.58]) cube([0.4, 0.4, 0.1], center=true);
    translate([170.85, 154.36, 247.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([171.15, 154.44, 247.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([173.85, 155.16, 246.82]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([174.15, 155.245, 246.78]) cube([0.4, 0.4, 0.1], center=true);
    translate([176.85000000000002, 156.055, 246.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([177.15, 156.145, 246.38000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([179.85, 156.955, 246.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.15, 157.05, 245.98000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([182.85000000000002, 157.95000000000002, 245.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.15, 158.055, 245.57999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([185.85, 159.045, 245.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([186.15, 159.155, 245.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([188.85, 160.145, 244.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([189.15, 160.26000000000002, 244.78000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([191.85000000000002, 161.34000000000003, 244.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.15, 161.46500000000003, 244.38]) cube([0.4, 0.4, 0.1], center=true);
    translate([194.85, 162.63500000000002, 244.01999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.15, 162.76500000000001, 243.98]) cube([0.4, 0.4, 0.1], center=true);
    translate([197.85000000000002, 163.935, 243.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([198.15000000000003, 164.07, 243.58]) cube([0.4, 0.4, 0.1], center=true);
    translate([200.85000000000002, 165.33, 243.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([201.15, 165.47500000000002, 243.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([203.85, 166.82500000000002, 242.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([204.15, 166.97500000000002, 242.78000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([206.85000000000002, 168.325, 242.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([207.15, 168.48, 242.38]) cube([0.4, 0.4, 0.1], center=true);
    translate([209.85, 169.92, 242.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([210.15, 170.085, 241.98000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([212.85000000000002, 171.615, 241.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([213.15000000000003, 171.79, 241.57999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([215.85000000000002, 173.41, 241.21999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.15, 173.59, 241.17999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([218.85, 175.21, 240.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([219.15, 175.395, 240.78000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([221.85000000000002, 177.105, 240.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([222.15, 177.29999999999998, 240.38000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([224.85, 179.1, 240.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([225.15, 179.305, 239.98000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([227.85000000000002, 181.19500000000002, 239.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([228.15000000000003, 181.41000000000003, 239.57999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([230.85000000000002, 183.39000000000001, 239.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([231.15, 183.61, 239.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([233.85, 185.59, 238.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([234.15, 185.81, 238.78000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([236.85000000000002, 187.79000000000002, 238.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([237.15, 188.01500000000001, 238.38]) cube([0.4, 0.4, 0.1], center=true);
    translate([239.85, 190.085, 238.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([239.8, 190.23000000000002, 237.97000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([236.20000000000002, 190.77000000000004, 237.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([235.8, 190.83000000000004, 237.37]) cube([0.4, 0.4, 0.1], center=true);
    translate([232.20000000000002, 191.37000000000003, 236.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([231.8, 191.43, 236.77]) cube([0.4, 0.4, 0.1], center=true);
    translate([228.20000000000002, 191.97, 236.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.8, 192.03000000000003, 236.17]) cube([0.4, 0.4, 0.1], center=true);
    translate([224.2, 192.57, 235.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([223.8, 192.63, 235.57]) cube([0.4, 0.4, 0.1], center=true);
    translate([220.2, 193.17, 235.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([219.8, 193.23, 234.97]) cube([0.4, 0.4, 0.1], center=true);
    translate([216.20000000000002, 193.77, 234.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([215.8, 193.83, 234.37]) cube([0.4, 0.4, 0.1], center=true);
    translate([212.20000000000002, 194.37, 233.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([211.8, 194.43, 233.77]) cube([0.4, 0.4, 0.1], center=true);
    translate([208.20000000000002, 194.97, 233.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([207.8, 195.03, 233.17]) cube([0.4, 0.4, 0.1], center=true);
    translate([204.2, 195.57, 232.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([203.8, 195.63, 232.57]) cube([0.4, 0.4, 0.1], center=true);
    translate([200.2, 196.17, 232.03000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([199.8, 196.23, 231.97000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([196.20000000000002, 196.77, 231.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.8, 196.83, 231.37000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([192.20000000000002, 197.37, 230.83000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([191.8, 197.43, 230.77000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([188.20000000000002, 197.97000000000003, 230.23000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([187.8, 198.03000000000003, 230.17000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([184.2, 198.57000000000002, 229.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.79999999999998, 198.63, 229.57]) cube([0.4, 0.4, 0.1], center=true);
    translate([180.2, 199.17000000000002, 229.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([179.8, 199.23000000000002, 228.97]) cube([0.4, 0.4, 0.1], center=true);
    translate([176.20000000000002, 199.77000000000004, 228.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([175.8, 199.83000000000004, 228.37]) cube([0.4, 0.4, 0.1], center=true);
    translate([172.20000000000002, 200.37, 227.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([171.8, 200.43, 227.77]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.20000000000002, 200.97, 227.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.8, 201.03, 227.17]) cube([0.4, 0.4, 0.1], center=true);
    translate([164.2, 201.57, 226.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([163.79999999999998, 201.63, 226.57]) cube([0.4, 0.4, 0.1], center=true);
    translate([160.2, 202.17, 226.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.8, 202.23, 225.97]) cube([0.4, 0.4, 0.1], center=true);
    translate([156.20000000000002, 202.77, 225.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.8, 202.83, 225.37]) cube([0.4, 0.4, 0.1], center=true);
    translate([152.20000000000002, 203.37, 224.83000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([151.8, 203.43, 224.77000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([148.20000000000002, 203.97, 224.23000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([147.8, 204.03, 224.17000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([144.2, 204.57, 223.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([143.79999999999998, 204.63, 223.57000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([140.2, 205.17000000000002, 223.03000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([139.8, 205.23000000000002, 222.97000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.20000000000002, 205.77000000000004, 222.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.8, 205.83000000000004, 222.37]) cube([0.4, 0.4, 0.1], center=true);
    translate([132.2, 206.37000000000003, 221.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([131.8, 206.43, 221.77]) cube([0.4, 0.4, 0.1], center=true);
    translate([128.2, 206.97000000000003, 221.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([127.80000000000001, 207.03000000000003, 221.17]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.20000000000002, 207.57, 220.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.80000000000001, 207.63, 220.57]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.2, 208.17, 220.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.8, 208.23, 219.97]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.2, 208.77, 219.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([115.80000000000001, 208.83, 219.37]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.2, 209.37, 218.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.8, 209.43, 218.77]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.2, 209.97, 218.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.80000000000001, 210.03, 218.17]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.20000000000002, 210.57, 217.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.80000000000001, 210.63, 217.57]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.2, 211.17, 217.03000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.8, 211.23, 216.97000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.2, 211.77, 216.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.80000000000001, 211.83, 216.37000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.2, 212.37, 215.83000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.8, 212.43, 215.77000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.2, 212.97000000000003, 215.23000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.8, 213.03000000000003, 215.17000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.2, 213.57000000000002, 214.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.80000000000001, 213.63, 214.57]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.2, 214.17000000000002, 214.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.8, 214.23000000000002, 213.97]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.2, 214.77000000000004, 213.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.80000000000001, 214.83000000000004, 213.37]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.2, 215.37, 212.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.8, 215.43, 212.77]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.2, 215.97, 212.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.8, 216.03, 212.17]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.2, 216.57, 211.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.800000000000004, 216.63, 211.57]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.2, 217.17, 211.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.8, 217.23, 210.97]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.2, 217.77, 210.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.8, 217.83, 210.37]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.2, 218.37, 209.83000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.800000000000004, 218.43, 209.77000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.2, 218.97, 209.23000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.800000000000004, 219.03, 209.17000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.2, 219.57, 208.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.800000000000004, 219.63, 208.57000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.2, 220.17000000000002, 208.03000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.2, 220.24, 207.98000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.800000000000004, 220.96, 207.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.2, 221.04000000000002, 207.58]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.800000000000004, 221.76, 207.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.2, 221.84, 207.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.800000000000004, 222.56, 206.82]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.2, 222.64000000000001, 206.78]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.8, 223.36, 206.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.2, 223.44, 206.38000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.8, 224.16, 206.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.2, 224.24, 205.98000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.800000000000004, 224.96, 205.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.2, 225.04, 205.57999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.8, 225.76000000000002, 205.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.2, 225.84000000000003, 205.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.8, 226.56, 204.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.2, 226.64, 204.78000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.80000000000001, 227.36, 204.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.2, 227.44, 204.38]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.8, 228.16, 204.01999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.2, 228.24, 203.98]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.80000000000001, 228.95999999999998, 203.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.2, 229.04, 203.58]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.8, 229.76000000000002, 203.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.2, 229.84000000000003, 203.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.8, 230.56, 202.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.2, 230.64, 202.78000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.80000000000001, 231.36, 202.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.2, 231.44000000000003, 202.38]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.8, 232.16, 202.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.2, 232.23999999999998, 201.98000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.80000000000001, 232.96, 201.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.20000000000002, 233.04000000000002, 201.57999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.80000000000001, 233.76000000000002, 201.21999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.2, 233.84000000000003, 201.17999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([111.8, 234.56, 200.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([112.2, 234.64, 200.78000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.80000000000001, 235.36, 200.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.2, 235.44000000000003, 200.38000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.8, 236.16, 200.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.2, 236.23999999999998, 199.98000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([123.80000000000001, 236.96, 199.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([124.20000000000002, 237.04000000000002, 199.57999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.80000000000001, 237.76000000000002, 199.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.2, 237.84, 199.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([131.8, 238.56, 198.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([132.2, 238.64000000000001, 198.78000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.8, 239.36, 198.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([136.20000000000002, 239.44, 198.38]) cube([0.4, 0.4, 0.1], center=true);
    translate([139.8, 240.16000000000003, 198.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([140.2, 240.24, 197.98000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([143.79999999999998, 240.96, 197.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([144.2, 241.04000000000002, 197.58]) cube([0.4, 0.4, 0.1], center=true);
    translate([147.8, 241.76, 197.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([148.20000000000002, 241.84, 197.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.8, 242.56, 196.82]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([152.20000000000002, 242.64000000000001, 196.78]) cube([0.4, 0.4, 0.1], center=true);
    translate([155.8, 243.36, 196.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([156.20000000000002, 243.44, 196.38000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([159.8, 244.16, 196.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([160.2, 244.24, 195.98000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([163.79999999999998, 244.96, 195.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([164.2, 245.04, 195.57999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([167.8, 245.76000000000002, 195.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.20000000000002, 245.84000000000003, 195.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([171.8, 246.56, 194.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([172.20000000000002, 246.64, 194.78000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([175.8, 247.36, 194.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.20000000000002, 247.44, 194.38]) cube([0.4, 0.4, 0.1], center=true);
    translate([179.8, 248.16, 194.01999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.2, 248.24, 193.98]) cube([0.4, 0.4, 0.1], center=true);
    translate([183.79999999999998, 248.95999999999998, 193.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([184.2, 249.04, 193.58]) cube([0.4, 0.4, 0.1], center=true);
    translate([187.8, 249.76000000000002, 193.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([188.20000000000002, 249.84000000000003, 193.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([191.8, 250.56, 192.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.20000000000002, 250.64, 192.78000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([195.8, 251.36, 192.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([196.20000000000002, 251.44000000000003, 192.38]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.8, 252.16, 192.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.2, 252.23999999999998, 191.98000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([203.8, 252.96, 191.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([204.2, 253.04000000000002, 191.57999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([207.8, 253.76000000000002, 191.21999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([208.20000000000002, 253.84000000000003, 191.17999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([211.8, 254.56, 190.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([212.20000000000002, 254.64, 190.78000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([215.8, 255.36, 190.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.20000000000002, 255.44000000000003, 190.38000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([219.8, 256.15999999999997, 190.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([220.2, 256.24, 189.98]) cube([0.4, 0.4, 0.1], center=true);
    translate([223.8, 256.96000000000004, 189.61999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.2, 257.04, 189.57999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([227.8, 257.76, 189.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([228.20000000000002, 257.84000000000003, 189.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([231.8, 258.56000000000006, 188.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([232.20000000000002, 258.64000000000004, 188.78000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([235.8, 259.35999999999996, 188.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([236.20000000000002, 259.44, 188.38]) cube([0.4, 0.4, 0.1], center=true);
    translate([239.8, 260.16, 188.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([239.8, 260.23, 187.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([236.20000000000002, 260.77000000000004, 187.23999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([235.8, 260.83000000000004, 187.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([232.20000000000002, 261.37, 186.44000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([231.8, 261.43, 186.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([228.20000000000002, 261.97, 185.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.8, 262.03000000000003, 185.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([224.2, 262.57000000000005, 184.84000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([223.8, 262.63000000000005, 184.76000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([220.2, 263.17, 184.04]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([219.8, 263.23, 183.95999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([216.20000000000002, 263.77000000000004, 183.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([215.8, 263.83000000000004, 183.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([212.20000000000002, 264.37, 182.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([211.8, 264.42999999999995, 182.35999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([208.20000000000002, 264.97, 181.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([207.8, 265.03, 181.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([204.2, 265.57000000000005, 180.84000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([203.8, 265.63, 180.76000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([200.2, 266.16999999999996, 180.04]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([199.8, 266.22999999999996, 179.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([196.20000000000002, 266.77, 179.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.8, 266.83, 179.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([192.20000000000002, 267.37, 178.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([191.8, 267.43, 178.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([188.20000000000002, 267.97, 177.64000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([187.8, 268.03000000000003, 177.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([184.2, 268.57000000000005, 176.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.79999999999998, 268.63000000000005, 176.76]) cube([0.4, 0.4, 0.1], center=true);
    translate([180.2, 269.17, 176.04000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([179.8, 269.23, 175.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([176.20000000000002, 269.77000000000004, 175.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([175.8, 269.83000000000004, 175.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([172.20000000000002, 270.37, 174.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([171.8, 270.43, 174.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.20000000000002, 270.97, 173.64000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.8, 271.03000000000003, 173.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([164.2, 271.57000000000005, 172.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([163.79999999999998, 271.63, 172.76000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([160.2, 272.16999999999996, 172.04000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.8, 272.23, 171.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([156.20000000000002, 272.77, 171.23999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.8, 272.83000000000004, 171.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([152.20000000000002, 273.37, 170.44000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([151.8, 273.42999999999995, 170.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([148.20000000000002, 273.96999999999997, 169.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([147.8, 274.03, 169.55999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([144.2, 274.57, 168.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([143.79999999999998, 274.63, 168.76000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([140.2, 275.17, 168.04000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([139.8, 275.23, 167.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.20000000000002, 275.77000000000004, 167.23999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.8, 275.83000000000004, 167.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([132.2, 276.37, 166.44000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([131.8, 276.43, 166.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([128.2, 276.97, 165.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([127.80000000000001, 277.03000000000003, 165.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.20000000000002, 277.57000000000005, 164.84000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.80000000000001, 277.63000000000005, 164.76000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.2, 278.17, 164.04]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.8, 278.23, 163.95999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.2, 278.77000000000004, 163.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([115.80000000000001, 278.83000000000004, 163.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.2, 279.37, 162.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.8, 279.42999999999995, 162.35999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.2, 279.97, 161.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.80000000000001, 280.03, 161.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.20000000000002, 280.57000000000005, 160.84000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.80000000000001, 280.63, 160.76000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.2, 281.16999999999996, 160.04]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.8, 281.22999999999996, 159.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.2, 281.77, 159.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.80000000000001, 281.83, 159.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.2, 282.37, 158.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.8, 282.43, 158.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.2, 282.97, 157.64000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.8, 283.03000000000003, 157.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.2, 283.57000000000005, 156.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.80000000000001, 283.63000000000005, 156.76]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.2, 284.17, 156.04000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.8, 284.23, 155.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.2, 284.77, 155.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.80000000000001, 284.83, 155.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.2, 285.37, 154.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.8, 285.43, 154.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.2, 285.97, 153.64000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.8, 286.03000000000003, 153.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.2, 286.57000000000005, 152.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.800000000000004, 286.63000000000005, 152.76000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.2, 287.17, 152.04000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.8, 287.23, 151.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.2, 287.77000000000004, 151.23999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.8, 287.83000000000004, 151.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.2, 288.37, 150.44000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.800000000000004, 288.43, 150.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.2, 288.97, 149.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.800000000000004, 289.03000000000003, 149.55999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.2, 289.57000000000005, 148.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.800000000000004, 289.63000000000005, 148.76000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.2, 290.17, 148.04000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.8, 290.23, 147.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.199999999999996, 290.77000000000004, 147.23999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.8, 290.83000000000004, 147.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.2, 291.37, 146.44000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.8, 291.43, 146.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.2, 291.97, 145.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.8, 292.03000000000003, 145.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.200000000000003, 292.57000000000005, 144.84000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.8, 292.63000000000005, 144.76000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.2, 293.17, 144.04]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.8, 293.23, 143.95999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.2, 293.77000000000004, 143.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.8, 293.83000000000004, 143.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.200000000000001, 294.37, 142.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.8, 294.42999999999995, 142.35999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.2, 294.97, 141.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.800000000000001, 295.03, 141.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.2, 295.57000000000005, 140.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.2, 295.62, 140.79000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.800000000000001, 295.98, 140.60999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.2, 296.02000000000004, 140.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.8, 296.38, 140.41000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.200000000000001, 296.42, 140.39000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.8, 296.78000000000003, 140.20999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.2, 296.82, 140.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.8, 297.18, 140.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.2, 297.22, 139.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.8, 297.58000000000004, 139.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.200000000000003, 297.62, 139.79000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.8, 297.98, 139.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.2, 298.02, 139.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.8, 298.38, 139.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.2, 298.42, 139.39000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.8, 298.78000000000003, 139.20999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.199999999999996, 298.82, 139.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.8, 299.17999999999995, 139.01000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.2, 299.21999999999997, 138.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.800000000000004, 299.58000000000004, 138.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.2, 299.62000000000006, 138.79000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.800000000000004, 299.98, 138.60999999999999]) cube([0.4, 0.4, 0.1], center=true);
}

