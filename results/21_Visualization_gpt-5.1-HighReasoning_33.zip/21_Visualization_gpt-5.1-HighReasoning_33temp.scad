
hull() {
    translate([10.5, 10.0, 94.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.5, 10.0, 90.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.5, 10.0, 89.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.5, 10.0, 85.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.5, 10.0, 84.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.5, 10.0, 80.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.5, 10.0, 79.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.5, 10.0, 75.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.5, 10.0, 74.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.5, 10.0, 70.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.5, 10.25, 69.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.5, 14.75, 65.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.5, 15.25, 64.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.5, 19.75, 60.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.25, 20.5, 59.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.75, 29.5, 55.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.25, 30.5, 54.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.75, 39.5, 50.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 40.5, 49.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 49.5, 45.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.75, 50.5, 44.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.25, 59.5, 40.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.75, 60.5, 39.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.25, 69.5, 35.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.5, 70.5, 34.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.5, 79.5, 30.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.5, 80.25, 29.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.5, 84.75, 28.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.5, 85.25, 27.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.5, 89.75, 27.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 89.5, 26.650000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 80.5, 20.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 79.75, 20.25]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 75.25, 24.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 74.75, 25.35]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 70.25, 31.650000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 70.25, 32.4]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 74.75, 39.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 75.25, 40.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 79.75, 49.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 80.25, 49.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 84.75, 40.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 85.25, 39.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 89.75, 32.4]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 89.75, 31.650000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 85.25, 25.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 84.75, 24.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 80.25, 20.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.25, 79.75, 19.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.75, 75.25, 18.099999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.25, 74.75, 17.849999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.75, 70.25, 15.15]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.25, 69.75, 14.85]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.75, 65.25, 12.15]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.25, 64.75, 11.850000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.75, 60.25, 9.15]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.25, 59.75, 8.85]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.75, 55.25, 6.15]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.25, 54.75, 5.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.75, 50.25, 4.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.25, 49.75, 3.9000000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.75, 45.25, 2.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.25, 44.75, 1.9000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.75, 40.25, 0.1]) cube([0.4, 0.4, 0.1], center=true);
}

