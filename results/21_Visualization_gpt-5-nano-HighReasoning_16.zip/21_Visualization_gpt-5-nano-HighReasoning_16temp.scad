
hull() {
    translate([0.04715, 0.0, 4.98335]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.89585, 0.0, 4.68365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9894000000000001, 0.008450000000000001, 4.6503000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8246, 0.16055000000000003, 4.3497]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.91515, 0.18560000000000001, 4.31635]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.7098500000000003, 0.48440000000000005, 4.01665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.7945, 0.52525, 3.98335]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.5235000000000003, 0.96175, 3.68365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.5997000000000003, 1.01715, 3.65035]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.242299999999999, 1.57785, 3.35065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.3073, 1.6461999999999999, 3.31735]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.8347, 2.3158000000000003, 3.0176499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.8863, 2.39485, 2.98435]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2877, 3.1481500000000002, 2.6846500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.32455, 3.23485, 2.6513500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.586449999999999, 4.0421499999999995, 2.3516500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.60725, 4.13375, 2.31835]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.71975, 4.97525, 2.01865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.7236, 5.06945, 1.98535]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.6804, 5.92355, 1.6856499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.6672, 6.01725, 1.65235]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.4728, 6.84975, 1.3526500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.4426, 6.939450000000001, 1.31935]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0934, 7.721550000000001, 1.01965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0476, 7.8044, 0.98635]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.5724, 8.5136, 0.6866500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.51315, 8.5873, 0.6533500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.92185, 9.2047, 0.35365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.8503499999999997, 9.26665, 0.32015]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.15465, 9.764349999999999, 0.01685]) cube([0.4, 0.4, 0.1], center=true);
}

