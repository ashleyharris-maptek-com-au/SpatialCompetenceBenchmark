
hull() {
    translate([44.997551, 25.06994285, 47.9959933]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.953469000000005, 26.32891415, 47.9238727]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.943685, 26.46845725, 47.91585935]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.811654999999995, 27.721261750000004, 47.84373965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.79213489999999, 27.8597788, 47.835726300000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.572803099999994, 29.100281200000005, 47.76360570000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.543642549999994, 29.237093750000003, 47.75559235000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.238084449999995, 30.459217250000002, 47.68347265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.19941835, 30.593459950000003, 47.67545929999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.808986649999994, 31.78770505, 47.603338699999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.76096475, 31.918360550000003, 47.5953253]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.28700225000001, 33.07591445, 47.52320470000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.22976775000001, 33.20205105, 47.51519135000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.67350925, 34.31495595, 47.44307165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.6072247, 34.4361827, 47.435058299999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.97036130000001, 35.505359299999995, 47.3629377]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.895235400000004, 35.6221901, 47.3549243]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.1798326, 36.6559679, 47.2828037]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.0961232, 36.76886655, 47.2747903]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.30475680000001, 37.76726445, 47.2026697]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.212751850000004, 37.8762075, 47.194656300000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.348029149999995, 38.838784499999996, 47.12253570000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.247996549999996, 38.9437399, 47.114522300000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.31213245, 39.8703601, 47.0424017]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.204329, 39.971345199999995, 47.0343883]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.19973100000001, 40.8624568, 46.962267700000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.0843355, 40.95947555, 46.9542543]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.0118145, 41.81470145, 46.8821337]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.888941300000006, 41.9077126, 46.874120299999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.7497447, 42.7266874, 46.801999699999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.6195007, 42.8157158, 46.7939863]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.4143053, 43.599252199999995, 46.7218657]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.276786, 43.684313849999995, 46.7138523]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.006634, 44.43188715, 46.6417317]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.8619682, 44.512973550000005, 46.633718300000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.5281358, 45.22495545, 46.56159770000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.376478600000002, 45.30210725, 46.553584300000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.980481400000002, 45.97885775, 46.4814637]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.82201085, 46.0521157, 46.473450299999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.36553815, 46.6940083, 46.401329700000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.2004554, 46.763414100000006, 46.3933163]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.6854386, 47.3708259, 46.321195700000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.5139624, 47.4364722, 46.3131823]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.9424076, 48.0106938, 46.241061699999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.76471545, 48.072675, 46.2330483]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.137811550000002, 48.614115000000005, 46.1609277]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.954094650000002, 48.67252640000001, 46.1529143]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.274094350000002, 49.1824916, 46.0807937]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.084660550000002, 49.2374291, 46.072780300000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.354852450000003, 49.7163389, 46.00065970000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.159974800000004, 49.767799249999996, 45.992646300000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.3819852, 50.21517575, 45.9205257]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.2190476, 50.22802849999999, 45.91251235]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0641604, 50.0120015, 45.84039265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.950166, 49.954866100000004, 45.8323793]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.053154, 49.1424559, 45.76025870000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.962263, 49.0487406, 45.752245300000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.223237000000001, 48.1742754, 45.6801247]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.148947000000001, 48.07386365, 45.6721113]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.550753, 47.140917349999995, 45.599990700000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.4911525, 47.03490865, 45.5919773]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.016537500000002, 46.05969835, 45.519856700000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.969706500000001, 45.948997399999996, 45.5118433]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.6013635, 44.9315906, 45.4397227]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.565199, 44.81665815, 45.4317093]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.282581, 43.76528085, 45.3595887]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.254956, 43.64697995, 45.3515753]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.040323999999998, 42.56894105000001, 45.279454699999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.019219999999999, 42.44817390000001, 45.2714413]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.85398, 41.3524041, 45.19932070000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.8379995, 41.23011075, 45.191307300000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.715590500000001, 40.12460025000001, 45.1191867]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.703972, 40.00164405, 45.1111733]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.617248, 38.893942949999996, 45.0390527]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.6091605, 38.77116935, 45.0310393]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.550309500000001, 37.668945650000005, 44.958918700000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.544840000000002, 37.5478103, 44.9509053]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.50524, 36.4695977, 44.8787847]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.501435, 36.3522501, 44.8707713]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.472545, 35.3182059, 44.7986507]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.469456000000001, 35.206635500000004, 44.7906373]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.442744, 34.2324125, 44.718516699999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.439525, 34.12735285, 44.71050329999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.408295, 33.210502149999996, 44.6383827]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.404598, 33.112130449999995, 44.630369300000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.369282, 32.25829055, 44.55824870000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.365096000000001, 32.16718805, 44.550235300000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.325064000000001, 31.381182950000003, 44.4781147]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.320426000000001, 31.29783325, 44.4701013]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.276974000000001, 30.58354375, 44.397980700000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.272083, 30.5082704, 44.3899673]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.227497000000001, 29.8676396, 44.3178467]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.222664000000002, 29.8006913, 44.309833299999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.180256, 29.2362527, 44.2377127]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.175747, 29.17794955, 44.2296993]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.136993, 28.69293145, 44.1575787]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.132958, 28.64359825, 44.1495653]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.099082000000001, 28.24061875, 44.0774447]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.09566, 28.2005281, 44.069431300000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.06794, 27.8818759, 43.99731070000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.065217, 27.85118525, 43.989297300000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.043923, 27.61740575, 43.9171767]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.041936999999999, 27.59609375, 43.9091633]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.027483, 27.446257250000002, 43.837042700000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.026280000000002, 27.4342112, 43.8290293]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.01908, 27.3672188, 43.7569087]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.01868, 27.364327850000002, 43.748895299999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.01868, 27.379283150000003, 43.676774699999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.01908, 27.3854671, 43.6687613]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.026280000000002, 27.481822900000004, 43.5966407]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.027483, 27.497066850000003, 43.5886273]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.041936999999999, 27.67510215, 43.5165067]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.043923, 27.69900015, 43.508493300000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.065217, 27.95112885, 43.43637270000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.06794, 27.98302285, 43.428359300000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.09566, 28.30498615, 43.3562387]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.099082000000001, 28.3447965, 43.348225299999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.132958, 28.7394195, 43.276104700000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.136993, 28.7865442, 43.2680913]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.175747, 29.2401658, 43.195970700000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.180256, 29.29356255, 43.1879573]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.222664000000002, 29.80108245, 43.115836699999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.227497000000001, 29.8607202, 43.1078233]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.272083, 30.4266798, 43.0357027]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.277084, 30.49255985, 43.0276893]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.322516, 31.11244115, 42.9555687]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.328129, 31.18402185, 42.947555300000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.383731000000001, 31.852593149999997, 42.87543470000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.390492, 31.929319149999998, 42.867421300000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.456588, 32.64181585, 42.7953007]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.464534, 32.7231846, 42.787287299999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.541466, 33.4753254, 42.7151667]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.550587, 33.560882750000005, 42.7071533]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.637833, 34.348774250000005, 42.635032700000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.648074, 34.43807615000001, 42.6270193]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.745166, 35.25761885, 42.554898699999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.756476, 35.3503409, 42.5468853]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.862964000000002, 36.1997951, 42.4747647]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.875292, 36.29574545, 42.4667513]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.990708, 37.17339755, 42.3946307]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.0039535, 37.2723897, 42.3866173]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.126956499999999, 38.1765963, 42.31449670000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.1408215, 38.278456750000004, 42.306483300000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.2673885, 39.207738250000006, 42.234362700000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.281414999999999, 39.31226435000001, 42.2263493]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.407325, 40.26445265, 42.1542287]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.421038, 40.3714422, 42.1462153]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.541961999999998, 41.34506579999999, 42.0740947]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.554872999999999, 41.4543566, 42.0660813]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.666347, 42.4479674, 41.993960699999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.677995, 42.55945015, 41.9859473]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.776185, 43.572528850000005, 41.91382670000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.786118, 43.686297, 41.905813300000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.866722, 44.721045000000004, 41.8336927]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.874471, 44.837089000000006, 41.8256793]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.933349, 45.891133, 41.7535587]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.939789, 46.00920645, 41.7455453]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.996831, 47.08048455, 41.673424700000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.2, 41.6654113]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.28000000000001, 41.5932907]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.400000000000006, 41.5852773]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 49.48, 41.5131567]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 49.6, 41.5051433]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 50.68000000000001, 41.433022699999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 50.7505, 41.42500929999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 50.9395, 41.3528887]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 50.917, 41.344875300000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 50.32300000000001, 41.27275470000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 50.258, 41.264741300000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 49.682, 41.1926207]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 49.619, 41.1846073]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 49.06100000000001, 41.112486700000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 49.0, 41.1044733]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.46000000000001, 41.0323527]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.401, 41.024339299999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.879000000000005, 40.9522187]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.822, 40.9442053]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.318, 40.8720847]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.263, 40.8640713]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 46.777, 40.7919507]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 46.724000000000004, 40.783937300000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 46.256, 40.71181670000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 46.205, 40.703803300000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 45.754999999999995, 40.6316827]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 45.705999999999996, 40.6236693]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 45.274, 40.551548700000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 45.227000000000004, 40.5435353]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 44.813, 40.4714147]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 44.768, 40.463401299999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 44.372, 40.391280699999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 44.329, 40.3832673]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 43.951, 40.3111467]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 43.91, 40.303083]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 43.55, 40.230057]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 43.51115, 40.222]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 43.17185, 40.15]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 43.13525, 40.141999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 42.81575, 40.07000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 42.7814, 40.062000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 42.4826, 39.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 42.4505, 39.982]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 42.171499999999995, 39.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 42.1416, 39.902]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 41.882400000000004, 39.830000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 41.8547, 39.822]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 41.6153, 39.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 41.5898, 39.742]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 41.3702, 39.669999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 41.3469, 39.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 41.1471, 39.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 41.126000000000005, 39.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.946, 39.51]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.927099999999996, 39.501999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.7669, 39.43000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.750150000000005, 39.422000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.608850000000004, 39.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.59425, 39.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.472750000000005, 39.269999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.460300000000004, 39.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.3577, 39.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.3474, 39.182]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.2646, 39.11]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.2565, 39.102]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.1935, 39.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.1875, 39.022000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.142500000000005, 38.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.138600000000004, 38.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.1134, 38.87]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.1116, 38.861999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.104400000000005, 38.790000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.104150000000004, 38.782000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.10685, 38.71000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.1082, 38.702000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.129799999999996, 38.629999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.13315, 38.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.17185, 38.550000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.177099999999996, 38.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.232899999999994, 38.47]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.24005, 38.461999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.31295, 38.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.322, 38.382000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.412000000000006, 38.31]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.422900000000006, 38.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.5291, 38.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.54174999999999, 38.221999999999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.663250000000005, 38.150000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.6776, 38.142]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.814400000000006, 38.07000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.8804, 38.062000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 41.9316, 37.989999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 42.018800000000006, 37.982]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 42.537200000000006, 37.910000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 42.5737, 37.902]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 42.7123, 37.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 42.733, 37.821999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 42.96699999999999, 37.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 42.9935, 37.742000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 43.23650000000001, 37.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 43.26350000000001, 37.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 43.50650000000001, 37.589999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 43.53300000000001, 37.581999999999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 43.767, 37.510000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 43.793, 37.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 44.027, 37.43000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 44.053000000000004, 37.422000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 44.287, 37.349999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 44.312999999999995, 37.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 44.547000000000004, 37.27]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 44.57300000000001, 37.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 44.807, 37.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 44.833, 37.181999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 45.067, 37.11]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 45.093, 37.102000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 45.327000000000005, 37.03000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 45.352000000000004, 37.022000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 45.568, 36.949999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 45.592, 36.94199999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 45.808, 36.870000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 45.832, 36.862]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 46.048, 36.790000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 46.0715, 36.782000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 46.2785, 36.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 46.301, 36.702000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 46.499, 36.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 46.5205, 36.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 46.7095, 36.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 46.730000000000004, 36.541999999999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 46.910000000000004, 36.47]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 46.929500000000004, 36.462]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.100500000000004, 36.39000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.119, 36.382000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.281, 36.309999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.298, 36.30199999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.44200000000001, 36.230000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.4575, 36.222]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.5925, 36.150000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.607000000000006, 36.142]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.733000000000004, 36.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.746, 36.062000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.854, 35.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.8655, 35.982]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.9645, 35.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.975, 35.901999999999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.065, 35.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.0745, 35.822]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.1555, 35.75000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.1635, 35.742000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.226499999999994, 35.669999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.233, 35.66199999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.287, 35.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.2925, 35.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.337500000000006, 35.51]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.342000000000006, 35.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.378, 35.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.381, 35.422000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.399, 35.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.4005, 35.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.409499999999994, 35.269999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.41, 35.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.41, 35.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.409499999999994, 35.182]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.4005, 35.11]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.3985, 35.102000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.3715, 35.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.3675, 35.022000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.3225, 34.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.317, 34.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.263, 34.87]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.256499999999996, 34.862]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.1935, 34.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.186, 34.782000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.114, 34.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.1055, 34.702]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 48.0245, 34.629999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 48.015, 34.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.925, 34.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.914500000000004, 34.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.8155, 34.47]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.804, 34.462]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.696, 34.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.6835, 34.382000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.566500000000005, 34.31]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.5535, 34.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.436499999999995, 34.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.422999999999995, 34.222]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.297, 34.15]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.2825, 34.142]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 47.1475, 34.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 47.132000000000005, 34.062]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 46.988, 33.989999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 46.9715, 33.982]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 46.81850000000001, 33.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 46.801, 33.902]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 46.639, 33.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 46.62050000000001, 33.822]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 46.4495, 33.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 46.43, 33.742000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 46.25, 33.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 46.2295, 33.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 46.0405, 33.589999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 46.019, 33.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 45.821000000000005, 33.51]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 45.798500000000004, 33.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 45.591499999999996, 33.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 45.568, 33.422]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 45.352000000000004, 33.349999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 45.32750000000001, 33.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 45.102500000000006, 33.269999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 45.077000000000005, 33.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 44.843, 33.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 44.816500000000005, 33.182]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 44.57350000000001, 33.11]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 44.54600000000001, 33.102000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 44.294000000000004, 33.03000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 44.266000000000005, 33.022000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 44.014, 32.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 43.9855, 32.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 43.7245, 32.87]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 43.695, 32.862]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 43.425, 32.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 43.394499999999994, 32.782000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 43.1155, 32.71000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 43.083999999999996, 32.702000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 42.796, 32.629999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 42.7635, 32.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 42.4665, 32.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 42.43300000000001, 32.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 42.127, 32.47]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 42.0925, 32.462]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 41.777499999999996, 32.39000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 41.742, 32.382000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 41.418, 32.31]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 41.381499999999996, 32.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 41.0485, 32.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 41.011, 32.222]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.669000000000004, 32.15]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.6305, 32.142]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 40.2795, 32.07000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 40.24, 32.062000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 39.88, 31.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 39.8395, 31.982000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 39.4705, 31.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 39.429, 31.902]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 39.051, 31.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 39.008500000000005, 31.822]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 38.621500000000005, 31.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 38.578, 31.742]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 38.182, 31.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 38.1375, 31.662000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 37.7325, 31.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 37.687, 31.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 37.272999999999996, 31.509999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 37.2265, 31.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 36.80350000000001, 31.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 36.756, 31.422]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 36.324, 31.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 36.2755, 31.342000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 35.834500000000006, 31.27]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 35.785000000000004, 31.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 35.335, 31.189999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 35.2845, 31.182]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 34.8255, 31.110000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 34.773999999999994, 31.102000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 34.306, 31.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 34.2535, 31.022000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 33.7765, 30.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 33.723, 30.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 33.237, 30.869999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 33.182500000000005, 30.862]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 32.6875, 30.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 32.632, 30.782000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 32.128, 30.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 32.0715, 30.702]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 31.558500000000002, 30.630000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 31.501000000000005, 30.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 30.979, 30.549999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 30.9205, 30.541999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 30.3895, 30.470000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 30.330000000000002, 30.462000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 29.790000000000003, 30.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 29.7295, 30.382]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 29.1805, 30.310000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 29.119, 30.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 28.561000000000003, 30.229999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 28.498500000000003, 30.221999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 27.9315, 30.150000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 27.868, 30.142000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 27.292, 30.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 27.227500000000003, 30.062]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 26.642500000000002, 29.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 26.577, 29.982]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 25.983, 29.909999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 25.9165, 29.901999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 25.313500000000005, 29.830000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 25.246000000000002, 29.822000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 24.634, 29.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 24.5655, 29.742]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 23.9445, 29.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 23.875000000000004, 29.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 23.245000000000005, 29.589999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 23.174500000000002, 29.581999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 22.5355, 29.51]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 22.464, 29.502000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 21.816, 29.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 21.7435, 29.422]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 21.0865, 29.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 21.013, 29.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 20.347, 29.269999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 20.2725, 29.261999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 19.5975, 29.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 19.522, 29.182000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 18.838, 29.110000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 18.7615, 29.102000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 18.0685, 29.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 17.991, 29.022]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 17.289, 28.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 17.2105, 28.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 16.4995, 28.87]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 16.42, 28.862000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 15.700000000000001, 28.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 15.619500000000002, 28.782000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 14.8905, 28.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 14.809000000000001, 28.701999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 14.070999999999998, 28.630000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 13.988499999999998, 28.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 13.241499999999998, 28.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 13.158, 28.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 12.402000000000001, 28.470000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 12.3175, 28.462000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 11.5525, 28.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 11.467, 28.381999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 10.693000000000001, 28.310000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 10.6065, 28.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 9.8235, 28.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 9.735999999999999, 28.222]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 8.943999999999999, 28.150000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 8.8555, 28.142000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 8.054499999999999, 28.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 7.965, 28.061999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 7.155, 27.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 7.065, 27.982]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 6.255000000000001, 27.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 6.1645, 27.902]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 5.3454999999999995, 27.830000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 5.254, 27.822000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 4.426, 27.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 4.3335, 27.741999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 3.4965000000000006, 27.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 3.4030000000000005, 27.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 2.557, 27.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 2.4625, 27.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 1.6075000000000002, 27.51]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 1.5120000000000002, 27.502000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, 0.648, 27.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, 0.552, 27.421999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -0.312, 27.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -0.41000000000000003, 27.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -1.3100000000000003, 27.27]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -1.4100000000000001, 27.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -2.31, 27.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -2.41, 27.182000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -3.31, 27.110000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -3.41, 27.102000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -4.3100000000000005, 27.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -4.41, 27.022]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -5.3100000000000005, 26.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -5.410000000000001, 26.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -6.3100000000000005, 26.87]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -6.41, 26.862000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -7.3100000000000005, 26.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -7.41, 26.782000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -8.31, 26.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -8.41, 26.701999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -9.309999999999999, 26.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -9.41, 26.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -10.31, 26.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -10.41, 26.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -11.31, 26.470000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -11.41, 26.462000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -12.31, 26.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -12.41, 26.381999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -13.309999999999999, 26.31]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -13.41, 26.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -14.309999999999999, 26.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -14.41, 26.222]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -15.31, 26.150000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -15.41, 26.142000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -16.31, 26.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -16.41, 26.061999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -17.310000000000002, 25.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -17.41, 25.982]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -18.310000000000002, 25.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -18.41, 25.902]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -19.31, 25.830000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -19.41, 25.822000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -20.310000000000002, 25.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -20.41, 25.741999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -21.31, 25.669999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -21.41, 25.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -22.31, 25.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -22.41, 25.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -23.310000000000002, 25.51]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -23.41, 25.502000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -24.31, 25.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -24.41, 25.421999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -25.310000000000002, 25.349999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -25.410000000000004, 25.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -26.310000000000002, 25.27]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -26.41, 25.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -27.31, 25.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -27.41, 25.182000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -28.310000000000002, 25.110000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -28.41, 25.102000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -29.31, 25.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -29.41, 25.022]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -30.310000000000002, 24.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -30.410000000000004, 24.942000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -31.310000000000002, 24.87]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -31.41, 24.862000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -32.31, 24.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -32.41, 24.782000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -33.31, 24.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -33.410000000000004, 24.701999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -34.31, 24.630000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -34.41, 24.622000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -35.31, 24.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -35.410000000000004, 24.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -36.31, 24.470000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -36.410000000000004, 24.462000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -37.31, 24.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -37.410000000000004, 24.381999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -38.31, 24.310000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -38.410000000000004, 24.302000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -39.31, 24.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -39.41, 24.222]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -40.309999999999995, 24.150000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -40.41, 24.142000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -41.31, 24.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -41.410000000000004, 24.061999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -42.31, 23.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -42.410000000000004, 23.982000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -43.31, 23.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -43.410000000000004, 23.902]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -44.31, 23.830000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -44.41, 23.822]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -45.309999999999995, 23.749999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -45.41, 23.741999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -46.31, 23.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -46.410000000000004, 23.662000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -47.31, 23.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -47.410000000000004, 23.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -48.31, 23.51]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -48.410000000000004, 23.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -49.31, 23.429999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -49.41, 23.421999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -50.31, 23.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -50.41, 23.342000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -51.31, 23.27]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -51.410000000000004, 23.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -52.31, 23.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -52.410000000000004, 23.182]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -53.31, 23.11]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -53.410000000000004, 23.102]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -54.31, 23.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -54.41, 23.022000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -55.31, 22.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -55.41, 22.942000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -56.31, 22.87]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -56.410000000000004, 22.862]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -57.31, 22.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -57.410000000000004, 22.782]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -58.31, 22.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -58.410000000000004, 22.702]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -59.31, 22.630000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -59.41, 22.622000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -60.31, 22.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -60.41, 22.541999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -61.31, 22.47]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -61.410000000000004, 22.462]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -62.31, 22.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -62.410000000000004, 22.382]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -63.31, 22.310000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -63.410000000000004, 22.302000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -64.31, 22.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -64.41, 22.221999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -65.31, 22.15]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -65.41, 22.142]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -66.31, 22.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -66.41, 22.062]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -67.31, 21.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -67.41, 21.982000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -68.31, 21.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -68.41, 21.901999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -69.31, 21.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -69.41, 21.822]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -70.31, 21.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -70.41, 21.742]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -71.31, 21.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -71.41, 21.662000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -72.31, 21.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -72.41, 21.581999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -73.31, 21.509999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -73.41, 21.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -74.31, 21.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -74.41000000000001, 21.422]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -75.31, 21.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -75.41, 21.342000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -76.31, 21.27]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -76.41, 21.261999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -77.31, 21.189999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -77.41, 21.182]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -78.31, 21.110000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -78.41, 21.102000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -79.31, 21.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -79.41000000000001, 21.022000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -80.31, 20.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -80.41, 20.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -81.31, 20.869999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -81.41, 20.862]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -82.31, 20.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -82.41, 20.782000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -83.31, 20.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -83.41, 20.702]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -84.31, 20.630000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -84.41000000000001, 20.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -85.31, 20.549999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -85.41, 20.541999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -86.31, 20.470000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -86.41, 20.462000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -87.31, 20.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -87.41, 20.382]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -88.31, 20.310000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -88.41, 20.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -89.31, 20.229999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -89.41000000000001, 20.221999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -90.31, 20.150000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -90.41, 20.142000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -91.31, 20.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -91.41, 20.062]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -92.31, 19.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -92.41, 19.982]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -93.31, 19.909999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -93.41, 19.901999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -94.31, 19.830000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -94.41000000000001, 19.822000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -95.31, 19.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -95.41, 19.742]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -96.31, 19.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -96.41, 19.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -97.31, 19.589999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -97.41, 19.581999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -98.31, 19.51]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -98.41, 19.502000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -99.31, 19.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -99.41000000000001, 19.422]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -100.31, 19.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -100.41, 19.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -101.31, 19.269999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -101.41, 19.261999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -102.31, 19.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -102.41, 19.182000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -103.31, 19.110000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -103.41, 19.102000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -104.31, 19.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -104.41000000000001, 19.022]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -105.31, 18.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -105.41, 18.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -106.31, 18.87]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -106.41, 18.862000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -107.31, 18.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -107.41, 18.782000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -108.31, 18.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -108.41, 18.701999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -109.31, 18.630000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -109.41000000000001, 18.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -110.31, 18.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -110.41, 18.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -111.31, 18.470000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -111.41, 18.462000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -112.31, 18.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -112.41, 18.381999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -113.31, 18.310000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -113.41, 18.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -114.31, 18.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -114.41000000000001, 18.222]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -115.31, 18.150000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -115.41, 18.142000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -116.31, 18.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -116.41, 18.061999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -117.31, 17.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -117.41, 17.982]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -118.31, 17.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -118.41, 17.902]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -119.31, 17.830000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -119.41000000000001, 17.822000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -120.31, 17.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -120.41, 17.741999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -121.31, 17.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -121.41, 17.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -122.31, 17.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -122.41, 17.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -123.31, 17.509999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -123.41, 17.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -124.31, 17.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -124.41000000000001, 17.421999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -125.31, 17.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -125.41, 17.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -126.31, 17.27]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -126.41, 17.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -127.31, 17.189999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -127.41, 17.182]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -128.31, 17.110000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -128.41000000000003, 17.102000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -129.31000000000003, 17.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -129.41000000000003, 17.022]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -130.31, 16.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -130.41000000000003, 16.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -131.31000000000003, 16.869999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -131.41000000000003, 16.862]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -132.31, 16.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -132.41000000000003, 16.782000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -133.31, 16.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -133.41000000000003, 16.701999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -134.31000000000003, 16.630000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -134.41000000000003, 16.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -135.31, 16.549999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -135.41000000000003, 16.541999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -136.31000000000003, 16.470000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -136.41000000000003, 16.462000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -137.31, 16.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -137.41000000000003, 16.381999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -138.31, 16.310000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -138.41000000000003, 16.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -139.31000000000003, 16.229999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -139.41000000000003, 16.221999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -140.31, 16.150000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -140.41000000000003, 16.142000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -141.31000000000003, 16.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -141.41000000000003, 16.061999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -142.31000000000003, 15.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -142.41000000000003, 15.982000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -143.31000000000003, 15.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -143.41000000000003, 15.902000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -144.31, 15.830000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -144.41, 15.822000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -145.31, 15.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -145.41000000000003, 15.742]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -146.31000000000003, 15.670000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -146.41000000000003, 15.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -147.31000000000003, 15.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -147.41000000000003, 15.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -148.31000000000003, 15.510000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -148.41000000000003, 15.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -149.31, 15.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -149.41, 15.422]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -150.31, 15.350000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -150.41000000000003, 15.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -151.31000000000003, 15.27]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -151.41000000000003, 15.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -152.31000000000003, 15.190000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -152.41000000000003, 15.182]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -153.31000000000003, 15.11]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -153.41000000000003, 15.102]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -154.31, 15.030000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -154.41, 15.022]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -155.31, 14.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -155.41000000000003, 14.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -156.31000000000003, 14.870000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -156.41000000000003, 14.862]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -157.31000000000003, 14.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -157.41000000000003, 14.782]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -158.31000000000003, 14.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -158.41000000000003, 14.702]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -159.31, 14.629999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -159.41, 14.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -160.31, 14.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -160.41000000000003, 14.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -161.31000000000003, 14.469999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -161.41000000000003, 14.462]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -162.31000000000003, 14.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -162.41000000000003, 14.382]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -163.31000000000003, 14.309999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -163.41000000000003, 14.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -164.31, 14.230000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -164.41, 14.222000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -165.31, 14.15]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -165.41000000000003, 14.142000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -166.31000000000003, 14.070000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -166.41000000000003, 14.062000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -167.31000000000003, 13.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -167.41000000000003, 13.982000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -168.31000000000003, 13.910000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -168.41000000000003, 13.902000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -169.31, 13.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -169.41, 13.822000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -170.31, 13.750000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -170.41000000000003, 13.742]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -171.31000000000003, 13.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -171.41000000000003, 13.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -172.31000000000003, 13.590000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -172.41000000000003, 13.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -173.31000000000003, 13.51]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -173.41000000000003, 13.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -174.31, 13.430000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -174.41, 13.422]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -175.31, 13.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -175.41000000000003, 13.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -176.31000000000003, 13.270000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -176.41000000000003, 13.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -177.31000000000003, 13.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -177.41000000000003, 13.182]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -178.31000000000003, 13.110000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -178.41000000000003, 13.102]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -179.31, 13.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -179.41, 13.022]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -180.31, 12.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -180.41000000000003, 12.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -181.31000000000003, 12.87]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -181.41000000000003, 12.862]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -182.31000000000003, 12.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -182.41000000000003, 12.782]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -183.31000000000003, 12.709999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -183.41000000000003, 12.702]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -184.31, 12.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -184.41, 12.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -185.31, 12.549999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -185.41000000000003, 12.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -186.31000000000003, 12.47]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -186.41000000000003, 12.462]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -187.31000000000003, 12.389999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -187.41000000000003, 12.382]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -188.31000000000003, 12.31]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -188.41000000000003, 12.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -189.31, 12.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -189.41, 12.222000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -190.31, 12.150000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -190.41000000000003, 12.142000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -191.31000000000003, 12.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -191.41000000000003, 12.062000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -192.31000000000003, 11.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -192.41000000000003, 11.982000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -193.31000000000003, 11.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -193.41000000000003, 11.902000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -194.31, 11.830000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -194.41000000000003, 11.822000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -195.31, 11.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -195.41000000000003, 11.742]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -196.31000000000003, 11.670000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -196.41000000000003, 11.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -197.31000000000003, 11.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -197.41000000000003, 11.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -198.31000000000003, 11.510000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -198.41000000000003, 11.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -199.31, 11.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -199.41000000000003, 11.422]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -200.31, 11.350000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -200.41000000000003, 11.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -201.31000000000003, 11.27]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -201.41000000000003, 11.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -202.31000000000003, 11.190000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -202.41000000000003, 11.182]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -203.31000000000003, 11.11]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -203.41000000000003, 11.102]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -204.31, 11.030000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -204.41000000000003, 11.022]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -205.31, 10.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -205.41000000000003, 10.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -206.31000000000003, 10.870000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -206.41000000000003, 10.862]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -207.31000000000003, 10.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -207.41000000000003, 10.782]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -208.31000000000003, 10.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -208.41000000000003, 10.702]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -209.31, 10.629999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -209.41000000000003, 10.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -210.31, 10.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -210.41000000000003, 10.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -211.31000000000003, 10.469999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -211.41000000000003, 10.462]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -212.31000000000003, 10.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -212.41000000000003, 10.382]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -213.31000000000003, 10.309999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -213.41000000000003, 10.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -214.31, 10.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -214.41000000000003, 10.222]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -215.31, 10.15]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -215.41000000000003, 10.142000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -216.31000000000003, 10.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -216.41000000000003, 10.062]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -217.31000000000003, 9.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -217.41000000000003, 9.982000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -218.31000000000003, 9.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -218.41000000000003, 9.902]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -219.31, 9.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -219.41000000000003, 9.822000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -220.31, 9.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -220.41000000000003, 9.741999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -221.31000000000003, 9.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -221.41000000000003, 9.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -222.31000000000003, 9.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -222.41000000000003, 9.581999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -223.31000000000003, 9.51]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -223.41000000000003, 9.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -224.31, 9.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -224.41000000000003, 9.421999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -225.31, 9.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -225.41000000000003, 9.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -226.31000000000003, 9.27]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -226.41000000000003, 9.261999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -227.31000000000003, 9.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -227.41000000000003, 9.182]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -228.31000000000003, 9.11]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -228.41000000000003, 9.101999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -229.31, 9.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -229.41000000000003, 9.022]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -230.31, 8.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -230.41000000000003, 8.941999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -231.31000000000003, 8.87]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -231.41000000000003, 8.862]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -232.31000000000003, 8.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -232.41000000000003, 8.782]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -233.31000000000003, 8.709999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -233.41000000000003, 8.702]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -234.31, 8.629999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -234.41000000000003, 8.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -235.31, 8.549999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -235.41000000000003, 8.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -236.31000000000003, 8.469999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -236.41000000000003, 8.462]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -237.31000000000003, 8.389999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -237.41000000000003, 8.382]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -238.31000000000003, 8.309999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -238.41000000000003, 8.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -239.31, 8.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -239.41000000000003, 8.222000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -240.31, 8.150000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -240.41000000000003, 8.142000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -241.31000000000003, 8.070000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -241.41000000000003, 8.062000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -242.31000000000003, 7.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -242.41000000000003, 7.982]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -243.31000000000003, 7.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -243.41000000000003, 7.902]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -244.31, 7.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -244.41000000000003, 7.822]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -245.31, 7.750000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -245.41000000000003, 7.742000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -246.31000000000003, 7.670000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -246.41000000000003, 7.662000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -247.31000000000003, 7.590000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -247.41000000000003, 7.582000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -248.31000000000003, 7.510000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -248.41000000000003, 7.502000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -249.31, 7.430000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -249.41000000000003, 7.422000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -250.31, 7.3500000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -250.41000000000003, 7.3420000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -251.31000000000003, 7.2700000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -251.41000000000003, 7.2620000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -252.31000000000003, 7.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -252.41000000000003, 7.182]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -253.31000000000003, 7.11]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -253.41000000000003, 7.102]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -254.31, 7.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -254.41000000000003, 7.022]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -255.31, 6.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -255.41000000000003, 6.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -256.31, 6.87]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -256.41, 6.862]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -257.31, 6.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -257.41, 6.782]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -258.31000000000006, 6.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -258.41, 6.702]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -259.31, 6.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -259.41, 6.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -260.31, 6.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -260.41, 6.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -261.31, 6.47]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -261.41, 6.462]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -262.31, 6.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -262.41, 6.382]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -263.31000000000006, 6.31]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -263.41, 6.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -264.31, 6.2299999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -264.41, 6.2219999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -265.31, 6.1499999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -265.41, 6.1419999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -266.31, 6.069999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -266.41, 6.061999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -267.31, 5.989999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -267.41, 5.981999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -268.31000000000006, 5.909999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -268.41, 5.901999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -269.31, 5.829999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -269.41, 5.821999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -270.31, 5.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -270.41, 5.742]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -271.31, 5.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -271.41, 5.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -272.31, 5.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -272.41, 5.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -273.31000000000006, 5.51]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -273.41, 5.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -274.31, 5.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -274.41, 5.422]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -275.31, 5.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -275.41, 5.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -276.31, 5.27]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -276.41, 5.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -277.31, 5.1899999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -277.41, 5.1819999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -278.31000000000006, 5.109999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -278.41, 5.101999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -279.31, 5.029999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -279.41, 5.021999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -280.31, 4.949999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -280.41, 4.941999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -281.31, 4.869999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -281.41, 4.861999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -282.31, 4.789999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -282.41, 4.781999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -283.31000000000006, 4.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -283.41, 4.702]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -284.31, 4.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -284.41, 4.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -285.31, 4.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -285.41, 4.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -286.31000000000006, 4.47]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -286.41, 4.462]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -287.31, 4.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -287.41, 4.382]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -288.31, 4.31]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -288.41, 4.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -289.31000000000006, 4.2299999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -289.41, 4.2219999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -290.31, 4.1499999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -290.41, 4.1419999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -291.31000000000006, 4.069999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -291.41, 4.061999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -292.31, 3.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -292.41, 3.982]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -293.31, 3.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -293.41, 3.902]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -294.31000000000006, 3.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -294.41, 3.822]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -295.31, 3.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -295.41, 3.742]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -296.31000000000006, 3.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -296.41, 3.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -297.31, 3.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -297.41, 3.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -298.31, 3.51]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -298.41, 3.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -299.31000000000006, 3.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -299.41, 3.422]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -300.31, 3.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -300.41, 3.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -301.31000000000006, 3.27]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -301.41, 3.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -302.31, 3.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -302.41, 3.182]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -303.31, 3.11]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -303.41, 3.102]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -304.31000000000006, 3.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -304.41, 3.022]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -305.31, 2.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -305.41, 2.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -306.31000000000006, 2.87]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -306.41, 2.862]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -307.31, 2.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -307.41, 2.782]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -308.31, 2.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -308.41, 2.702]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -309.31000000000006, 2.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -309.41, 2.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -310.31, 2.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -310.41, 2.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -311.31000000000006, 2.47]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -311.41, 2.462]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -312.31, 2.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -312.41, 2.382]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -313.31, 2.31]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -313.41, 2.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -314.31000000000006, 2.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -314.41, 2.222]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -315.31, 2.15]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -315.41, 2.142]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -316.31000000000006, 2.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -316.41, 2.062]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -317.31, 1.9900000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -317.41, 1.9820000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -318.31, 1.9100000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -318.41, 1.9020000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -319.31000000000006, 1.8300000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -319.41, 1.8220000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -320.31, 1.7500000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -320.41, 1.7420000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -321.31000000000006, 1.6700000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -321.41, 1.6620000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -322.31, 1.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -322.41, 1.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -323.31, 1.51]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -323.41, 1.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -324.31000000000006, 1.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -324.41, 1.422]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -325.31, 1.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -325.41, 1.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -326.31000000000006, 1.27]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -326.41, 1.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -327.31, 1.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -327.41, 1.182]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -328.31, 1.11]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -328.41, 1.102]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -329.31000000000006, 1.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -329.41, 1.022]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -330.31, 0.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -330.41, 0.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -331.31000000000006, 0.87]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -331.41, 0.862]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -332.31, 0.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -332.41, 0.782]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -333.31, 0.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -333.41, 0.702]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -334.31000000000006, 0.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -334.41, 0.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -335.31, 0.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -335.41, 0.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -336.31000000000006, 0.4700000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -336.41, 0.4620000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -337.31, 0.39000000000000007]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -337.41, 0.38200000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -338.31, 0.31]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -338.41, 0.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -339.31000000000006, 0.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -339.41, 0.222]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -340.31, 0.15]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -340.41, 0.142]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -341.31000000000006, 0.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0, -341.41, 0.0627]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0, -342.31, 0.0033000000000000004]) cube([0.4, 0.4, 0.1], center=true);
}

