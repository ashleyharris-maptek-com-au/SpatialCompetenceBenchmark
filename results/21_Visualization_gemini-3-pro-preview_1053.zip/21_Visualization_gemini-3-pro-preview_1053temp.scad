
hull() {
    translate([50.0, 5.02, 94.94]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 5.380000000000001, 93.86]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 5.42, 93.74]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 5.779999999999999, 92.66]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 5.82, 92.54]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 6.18, 91.46000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 6.220000000000001, 91.34]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 6.58, 90.26]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 6.619999999999999, 90.14]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 6.9799999999999995, 89.06]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 7.02, 88.94000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 7.38, 87.86]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 7.42, 87.74]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 7.779999999999999, 86.66]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 7.819999999999999, 86.53999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 8.18, 85.46000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 8.219999999999999, 85.34000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 8.58, 84.26]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 8.620000000000001, 84.14]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 8.98, 83.06]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 9.02, 82.94]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 9.38, 81.86]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 9.420000000000002, 81.74000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 9.780000000000001, 80.66]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 9.82, 80.53999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 10.18, 79.46000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 10.219999999999999, 79.34]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 10.579999999999998, 78.26]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 10.62, 78.14000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 10.98, 77.06]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 11.02, 76.94]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 11.379999999999999, 75.86]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 11.42, 75.74]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 11.780000000000001, 74.66]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 11.82, 74.54]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 12.18, 73.46000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 12.22, 73.34]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 12.58, 72.26]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 12.620000000000001, 72.14]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 12.98, 71.06]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 13.020000000000001, 70.94]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 13.38, 69.86]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 13.420000000000002, 69.74]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 13.780000000000001, 68.66]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 13.820000000000002, 68.53999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 14.18, 67.46000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 14.219999999999999, 67.34]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 14.58, 66.26]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 14.620000000000001, 66.14]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 14.98, 65.06]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.005, 64.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.095, 64.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.11, 64.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.290000000000001, 64.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.315000000000001, 64.57499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.584999999999999, 64.125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.62, 64.07]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.98, 63.53]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 16.025, 63.47]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 16.475, 62.93]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 16.53, 62.875]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 17.070000000000004, 62.425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 17.135, 62.379999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 17.765, 62.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 17.84, 61.98500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 18.560000000000002, 61.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 18.64, 61.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 19.36, 61.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 19.44, 61.715]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 20.16, 61.98500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 20.235, 62.03]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 20.865, 62.57000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 20.935, 62.64]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 21.565, 63.36]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 21.625, 63.45]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 22.075, 64.35000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 22.125, 64.45500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 22.575000000000003, 65.44500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 22.615000000000002, 65.565]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 22.884999999999998, 66.735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 22.915, 66.865]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 23.185, 68.035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 23.209999999999997, 68.16499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 23.389999999999997, 69.33500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 23.404999999999998, 69.47000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 23.495, 70.73]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 23.500000000000004, 70.87]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 23.500000000000004, 72.13000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 23.495, 72.265]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 23.404999999999998, 73.435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 23.395, 73.56500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 23.305000000000003, 74.735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 23.290000000000003, 74.865]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 23.110000000000003, 76.035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 23.085000000000004, 76.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 22.815, 77.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 22.785, 77.35499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 22.515, 78.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 22.485, 78.45]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 22.215, 79.35000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 22.18, 79.44500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 21.82, 80.255]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 21.78, 80.33999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 21.419999999999998, 81.05999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 21.38, 81.13499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 21.020000000000003, 81.765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 20.975, 81.825]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 20.525, 82.27499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 20.474999999999998, 82.32]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 20.025, 82.68]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 19.975, 82.715]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 19.525000000000002, 82.985]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 19.475, 83.005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 19.025000000000002, 83.095]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 18.975, 83.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 18.525000000000002, 83.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 18.475, 83.08999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 18.025, 82.91000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 17.974999999999998, 82.88500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 17.525, 82.61500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 17.48, 82.58]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 17.12, 82.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 17.075000000000003, 82.17500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 16.625, 81.725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 16.580000000000002, 81.665]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 16.22, 81.03500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 16.185, 80.965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.915000000000001, 80.335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.885000000000002, 80.25999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.614999999999998, 79.53999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.584999999999999, 79.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.315000000000001, 78.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.290000000000001, 78.55499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.11, 77.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.095, 77.65]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.005, 76.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 14.995000000000001, 76.645]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 14.905000000000001, 75.65499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 14.9, 75.54499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 14.9, 74.55499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 14.9, 74.445]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 14.9, 73.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 14.905000000000001, 73.345]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 14.995000000000001, 72.35499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.01, 72.24499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.19, 71.255]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.21, 71.15]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.39, 70.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.415000000000001, 70.14500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.684999999999999, 69.155]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.719999999999999, 69.05499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 16.080000000000002, 68.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 16.12, 68.15]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 16.48, 67.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 16.525, 67.16000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 16.975, 66.44000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 17.025000000000002, 66.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 17.475, 65.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 17.53, 65.565]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 18.070000000000004, 64.935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 18.135, 64.87]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 18.765, 64.33]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 18.835, 64.28]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 19.465, 63.92]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 19.535, 63.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 20.165, 63.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 20.24, 63.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 20.96, 63.410000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 21.040000000000003, 63.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 21.76, 63.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 21.84, 63.305]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 22.560000000000002, 63.395]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 22.645000000000003, 63.405]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 23.455000000000002, 63.495]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 23.540000000000003, 63.51]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 24.26, 63.690000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 24.345000000000002, 63.715]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 25.155, 63.985]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 25.240000000000002, 64.015]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 25.96, 64.285]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 26.045, 64.315]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 26.855, 64.585]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 26.945, 64.615]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 27.755, 64.885]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 27.845, 64.915]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 28.654999999999998, 65.185]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 28.74, 65.215]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 29.46, 65.485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 29.545, 65.51]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 30.355, 65.69]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.005, 30.445, 65.71000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.095000000000006, 31.255000000000003, 65.89000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.11000000000001, 31.345000000000002, 65.91000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.29, 32.155, 66.08999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.315, 32.245000000000005, 66.11]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.585, 33.05500000000001, 66.29]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.62, 33.14, 66.305]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.98, 33.86, 66.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.025, 33.945, 66.405]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.475, 34.754999999999995, 66.495]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.53, 34.839999999999996, 66.505]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.07, 35.56, 66.595]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.135000000000005, 35.64, 66.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.765, 36.36, 66.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.839999999999996, 36.434999999999995, 66.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.56, 37.065, 66.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.645, 37.135, 66.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.455000000000005, 37.76499999999999, 66.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.545, 37.834999999999994, 66.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.355000000000004, 38.464999999999996, 66.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.45, 38.53, 66.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.349999999999994, 39.07000000000001, 66.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.449999999999996, 39.13, 66.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.349999999999994, 39.67, 66.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.455, 39.725, 66.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.445, 40.175000000000004, 66.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.555, 40.22500000000001, 66.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.545, 40.675000000000004, 66.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.655, 40.720000000000006, 66.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.645, 41.080000000000005, 66.00999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.760000000000005, 41.120000000000005, 65.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.84, 41.480000000000004, 65.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.955, 41.515, 65.89000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.94500000000001, 41.785, 65.71000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.06, 41.815, 65.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.14, 42.085, 65.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.26, 42.11, 65.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.34, 42.29, 65.41000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.46000000000001, 42.31, 65.39000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.53999999999999, 42.49, 65.21000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.66499999999999, 42.51, 65.19000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.83500000000001, 42.690000000000005, 65.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.96000000000001, 42.705000000000005, 64.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.03999999999999, 42.794999999999995, 64.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.16, 42.8, 64.89]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.24, 42.8, 64.71000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.365, 42.8, 64.69]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.535, 42.8, 64.51]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.66, 42.8, 64.49000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.74, 42.8, 64.31]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.86, 42.8, 64.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.94000000000001, 42.8, 64.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.06, 42.794999999999995, 64.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.14, 42.705000000000005, 64.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.26, 42.69500000000001, 63.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.34, 42.605000000000004, 63.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.46000000000001, 42.59, 63.89]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.54, 42.41, 63.71000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.66, 42.38999999999999, 63.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.74, 42.21, 63.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.855, 42.190000000000005, 63.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.84500000000001, 42.010000000000005, 63.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.95500000000001, 41.98500000000001, 63.489999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.94500000000001, 41.715, 63.31]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.055, 41.69, 63.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.045, 41.510000000000005, 63.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.15, 41.480000000000004, 63.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.05, 41.120000000000005, 63.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.14999999999999, 41.085, 63.09]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.05, 40.815, 62.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.14999999999999, 40.78, 62.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.05, 40.42, 62.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.14500000000001, 40.38, 62.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.95500000000001, 40.02, 62.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.04, 39.98, 62.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.76, 39.62, 62.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.84, 39.575, 62.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.56, 39.12500000000001, 62.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.635, 39.080000000000005, 62.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.265, 38.720000000000006, 62.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.33, 38.675000000000004, 62.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.87, 38.225, 62.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.93, 38.17, 62.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.47, 37.63, 62.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.52499999999999, 37.575, 62.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.975, 37.125, 62.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.02, 37.07, 62.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.38000000000001, 36.53, 62.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.42000000000002, 36.47, 62.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.78, 35.93, 62.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.815, 35.870000000000005, 61.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.085, 35.33, 61.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.115, 35.269999999999996, 61.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.385, 34.730000000000004, 61.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.41000000000001, 34.67, 61.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.59, 34.13, 61.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.605, 34.065, 61.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.69500000000001, 33.435, 61.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.705, 33.37, 61.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.795, 32.83, 61.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.80000000000001, 32.765, 61.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.80000000000001, 32.135, 61.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.80000000000001, 32.07, 61.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.80000000000001, 31.53, 61.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.795, 31.470000000000002, 61.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.705, 30.93, 61.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.69, 30.865, 61.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.51, 30.235, 61.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.49000000000001, 30.17, 61.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.31, 29.630000000000003, 61.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.29, 29.57, 61.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.11, 29.03, 61.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.085, 28.970000000000002, 61.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.815, 28.43, 61.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.785, 28.369999999999997, 61.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.515, 27.83, 61.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.48, 27.77, 61.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.12, 27.23, 61.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.08, 27.17, 60.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.72, 26.630000000000003, 60.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.67500000000001, 26.57, 60.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.225, 26.03, 60.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.175, 25.975, 60.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.725, 25.525, 60.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.675, 25.475, 60.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.22500000000001, 25.025, 60.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.17000000000002, 24.975, 60.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.63000000000001, 24.525000000000002, 60.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.57000000000001, 24.475, 60.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.03, 24.025000000000002, 60.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.97, 23.975, 60.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.43, 23.525000000000002, 60.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.37, 23.480000000000004, 60.4]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.83, 23.120000000000005, 60.4]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.765, 23.080000000000002, 60.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.135, 22.72, 60.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.065, 22.68, 60.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.435, 22.32, 60.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.36500000000001, 22.28, 60.20000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.735, 21.92, 60.20000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.66499999999999, 21.885, 60.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.035, 21.615000000000002, 60.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.96000000000001, 21.580000000000002, 60.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.24000000000001, 21.22, 60.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.165, 21.185, 59.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.53500000000001, 20.915, 59.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.46000000000001, 20.889999999999997, 59.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.74000000000001, 20.709999999999997, 59.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.66000000000001, 20.685, 59.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.94000000000001, 20.415, 59.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.86000000000001, 20.39, 59.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.14, 20.21, 59.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.06, 20.19, 59.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.34, 20.01, 59.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.26, 19.99, 59.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.54, 19.81, 59.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.46, 19.795, 59.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.74, 19.705000000000002, 59.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.66, 19.695, 59.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.94, 19.605, 59.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.86, 19.595, 59.4]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.14, 19.505000000000003, 59.4]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.06, 19.5, 59.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.34, 19.5, 59.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.26, 19.5, 59.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.54, 19.5, 59.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.46000000000001, 19.5, 59.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.74000000000001, 19.5, 59.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.66000000000001, 19.5, 59.10000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.94000000000001, 19.5, 59.10000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.86000000000001, 19.505000000000003, 59.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.14, 19.595, 59.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.05999999999999, 19.605, 58.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.33999999999999, 19.695, 58.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.25999999999999, 19.705000000000002, 58.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.54, 19.795, 58.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.46000000000001, 19.805, 58.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.74000000000001, 19.895, 58.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.66000000000001, 19.91, 58.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.94000000000001, 20.090000000000003, 58.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.86000000000001, 20.110000000000003, 58.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.13999999999999, 20.29, 58.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.05999999999999, 20.31, 58.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.34, 20.49, 58.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.26, 20.509999999999998, 58.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.54, 20.689999999999998, 58.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.46000000000001, 20.715, 58.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.74000000000001, 20.985000000000003, 58.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.66, 21.015, 58.400000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.94, 21.285, 58.400000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.864999999999995, 21.315, 58.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.235, 21.585, 58.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.160000000000004, 21.615000000000002, 58.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.44, 21.885, 58.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.364999999999995, 21.92, 58.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.735, 22.28, 58.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.660000000000004, 22.32, 58.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.940000000000005, 22.68, 58.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.865, 22.72, 58.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.23500000000001, 23.080000000000002, 58.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.165000000000006, 23.125000000000004, 57.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.535000000000004, 23.575000000000003, 57.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.465, 23.62, 57.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.835, 23.98, 57.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.765, 24.025000000000002, 57.8]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.135, 24.475, 57.8]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.065, 24.525000000000002, 57.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.434999999999995, 24.975, 57.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.37, 25.025, 57.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.83, 25.475, 57.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.765, 25.53, 57.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.135000000000005, 26.07, 57.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.07, 26.125000000000004, 57.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.53, 26.575000000000003, 57.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.470000000000006, 26.630000000000003, 57.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.93, 27.17, 57.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.87, 27.23, 57.4]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.33, 27.77, 57.4]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.269999999999996, 27.83, 57.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.730000000000004, 28.369999999999997, 57.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.675000000000004, 28.43, 57.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.225, 28.970000000000002, 57.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.17, 29.03, 57.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.63, 29.57, 57.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.575, 29.630000000000003, 57.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.125, 30.17, 57.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.075, 30.235, 57.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.62500000000001, 30.865, 57.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.580000000000005, 30.935, 56.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.220000000000006, 31.565, 56.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.175000000000004, 31.630000000000003, 56.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.725, 32.17, 56.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.68000000000001, 32.23500000000001, 56.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.31999999999999, 32.865, 56.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.279999999999994, 32.935, 56.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.919999999999995, 33.565000000000005, 56.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.879999999999995, 33.635000000000005, 56.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.52, 34.265, 56.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.48500000000001, 34.334999999999994, 56.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.215, 34.965, 56.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.18, 35.035, 56.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.82, 35.665000000000006, 56.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.785000000000004, 35.735, 56.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.515, 36.364999999999995, 56.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.485, 36.434999999999995, 56.4]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.215, 37.065, 56.4]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.185, 37.135, 56.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.915, 37.76499999999999, 56.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.89, 37.839999999999996, 56.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.71000000000001, 38.56, 56.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.690000000000005, 38.635000000000005, 56.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.51, 39.265, 56.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.49, 39.334999999999994, 56.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.31, 39.965, 56.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.29, 40.04, 56.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.11, 40.76, 56.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.09, 40.835, 55.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.910000000000004, 41.465, 55.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.895, 41.54, 55.900000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.805, 42.26, 55.900000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.794999999999995, 42.335, 55.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.705, 42.965, 55.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.695, 43.040000000000006, 55.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.605000000000004, 43.760000000000005, 55.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.60000000000001, 43.835, 55.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.60000000000001, 44.465, 55.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.595000000000006, 44.540000000000006, 55.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.505, 45.26, 55.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.5, 45.334999999999994, 55.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.5, 45.964999999999996, 55.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.505, 46.04, 55.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.595000000000006, 46.76, 55.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.60000000000001, 46.834999999999994, 55.4]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.60000000000001, 47.465, 55.4]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.605000000000004, 47.54, 55.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.695, 48.26, 55.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.705, 48.335, 55.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.794999999999995, 48.965, 55.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.805, 49.04, 55.20000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.895, 49.76, 55.20000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.905, 49.835, 55.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.995000000000005, 50.465, 55.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.010000000000005, 50.540000000000006, 55.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.190000000000005, 51.260000000000005, 55.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.21, 51.335, 55.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.38999999999999, 51.965, 55.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.41, 52.040000000000006, 54.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.59, 52.76, 54.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.61000000000001, 52.834999999999994, 54.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.79, 53.464999999999996, 54.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.809999999999995, 53.535, 54.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.99, 54.165, 54.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.015, 54.24, 54.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.285, 54.96, 54.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.315, 55.035, 54.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.585, 55.665000000000006, 54.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.615, 55.735, 54.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.885, 56.364999999999995, 54.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.915, 56.435, 54.50000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.185, 57.065, 54.50000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.22, 57.135000000000005, 54.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.58, 57.765, 54.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.615, 57.834999999999994, 54.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.885, 58.464999999999996, 54.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.919999999999995, 58.535, 54.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.279999999999994, 59.165, 54.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.31999999999999, 59.235, 54.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.68000000000001, 59.864999999999995, 54.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.720000000000006, 59.934999999999995, 54.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.080000000000005, 60.565, 54.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.125, 60.635, 54.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.575, 61.265, 54.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.620000000000005, 61.33, 54.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.980000000000004, 61.870000000000005, 54.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.025000000000006, 61.935, 53.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.475, 62.565000000000005, 53.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.525, 62.63, 53.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.975, 63.17, 53.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.025000000000006, 63.230000000000004, 53.800000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.475, 63.77, 53.800000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.525, 63.83, 53.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.975, 64.37, 53.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.03, 64.43, 53.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.57, 64.97, 53.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.625, 65.03, 53.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.075, 65.57, 53.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.13, 65.63, 53.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.67, 66.17, 53.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.730000000000004, 66.23, 53.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.27, 66.77, 53.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.33, 66.825, 53.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.870000000000005, 67.275, 53.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.93, 67.33, 53.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.47, 67.87, 53.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.535, 67.92500000000001, 53.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.165000000000006, 68.37500000000001, 53.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.230000000000004, 68.42500000000001, 53.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.77, 68.875, 53.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.835, 68.92500000000001, 53.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.465, 69.37500000000001, 53.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.53, 69.42500000000001, 53.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.07000000000001, 69.875, 53.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.135000000000005, 69.92, 52.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.765, 70.28, 52.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.835, 70.32499999999999, 52.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.465, 70.775, 52.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.535000000000004, 70.82, 52.8]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.165000000000006, 71.17999999999999, 52.8]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.23500000000001, 71.22, 52.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.865, 71.58, 52.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.935, 71.62, 52.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.565000000000005, 71.97999999999999, 52.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.635000000000005, 72.02, 52.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.265, 72.38000000000001, 52.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.34, 72.42000000000002, 52.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.06, 72.78, 52.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.13499999999999, 72.815, 52.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.765, 73.085, 52.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.84, 73.11999999999999, 52.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.56, 73.48, 52.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.63499999999999, 73.515, 52.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.265, 73.785, 52.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.34, 73.81, 52.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.06, 73.99000000000001, 52.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.13499999999999, 74.01500000000001, 52.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.765, 74.28500000000001, 52.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.84, 74.315, 52.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.55999999999999, 74.585, 52.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.63999999999999, 74.61, 52.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.36000000000001, 74.78999999999999, 52.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.44000000000001, 74.80999999999999, 51.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.16, 74.99, 51.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.24, 75.01, 51.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.96, 75.19000000000001, 51.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.035, 75.21000000000001, 51.8]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.665, 75.39000000000001, 51.8]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.74000000000001, 75.40500000000002, 51.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.46000000000001, 75.495, 51.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.54, 75.51, 51.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.26, 75.69000000000001, 51.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.34, 75.70500000000001, 51.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.06, 75.795, 51.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.14, 75.80499999999999, 51.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.86, 75.895, 51.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.94, 75.9, 51.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.66, 75.9, 51.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.74, 75.905, 51.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.46, 75.995, 51.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.54, 76.0, 51.300000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.26, 76.0, 51.300000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.34, 76.0, 51.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.06, 76.0, 51.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.14, 76.0, 51.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.86000000000001, 76.0, 51.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.94000000000001, 76.0, 51.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.66000000000001, 76.0, 51.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.74000000000001, 75.995, 51.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.46000000000001, 75.905, 51.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.54, 75.895, 50.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.25999999999999, 75.80499999999999, 50.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.33999999999999, 75.795, 50.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.05999999999999, 75.70500000000001, 50.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.13999999999999, 75.69500000000001, 50.8]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.86, 75.60499999999999, 50.8]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.94000000000001, 75.58999999999999, 50.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.66000000000001, 75.41000000000001, 50.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.74000000000001, 75.39000000000001, 50.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.46000000000001, 75.21000000000001, 50.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.535, 75.19000000000001, 50.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.16499999999999, 75.01, 50.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.24, 74.99, 50.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.96, 74.80999999999999, 50.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.03999999999999, 74.785, 50.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.75999999999999, 74.515, 50.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.835, 74.485, 50.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.465, 74.215, 50.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.54, 74.185, 50.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.26, 73.915, 50.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.33500000000001, 73.885, 50.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.965, 73.615, 50.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.035, 73.58, 50.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.665, 73.22000000000001, 50.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.73500000000001, 73.18, 50.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.36500000000001, 72.82, 50.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.435, 72.78, 50.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.065, 72.42000000000002, 50.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.135, 72.38000000000001, 49.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.765, 72.02, 49.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.835, 71.975, 49.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.465, 71.525, 49.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.53, 71.47500000000001, 49.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.07, 71.025, 49.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.13499999999999, 70.975, 49.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.76499999999999, 70.525, 49.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.83, 70.47500000000001, 49.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.37000000000002, 70.025, 49.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.43, 69.975, 49.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.97, 69.525, 49.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.03, 69.47500000000001, 49.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.57, 69.025, 49.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.63, 68.97, 49.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.17, 68.43, 49.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.23, 68.37, 49.4]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.77, 67.83, 49.4]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.82499999999999, 67.77, 49.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.275, 67.23, 49.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.33, 67.17, 49.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.87, 66.63, 49.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.92500000000001, 66.57, 49.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.37500000000001, 66.03, 49.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.42000000000002, 65.97, 49.10000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.78, 65.43, 49.10000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.81, 65.36500000000001, 49.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.99000000000001, 64.735, 49.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.99000000000001, 64.665, 48.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.81, 64.035, 48.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.78999999999999, 63.965, 48.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.61, 63.335, 48.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.59, 63.265, 48.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.41000000000001, 62.635000000000005, 48.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.39000000000001, 62.565000000000005, 48.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.21000000000001, 61.935, 48.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.19, 61.865, 48.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.01, 61.23500000000001, 48.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.98500000000001, 61.165000000000006, 48.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.715, 60.535000000000004, 48.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.685, 60.465, 48.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.415, 59.835, 48.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.385, 59.765, 48.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.115, 59.135000000000005, 48.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.08, 59.065000000000005, 48.400000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.72000000000001, 58.435, 48.400000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.68, 58.365, 48.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.32, 57.73500000000001, 48.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.28, 57.665000000000006, 48.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.92000000000002, 57.035000000000004, 48.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.88000000000001, 56.970000000000006, 48.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.52000000000001, 56.43, 48.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.47500000000001, 56.364999999999995, 48.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.025, 55.735, 48.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.97500000000001, 55.665000000000006, 48.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.525, 55.035, 48.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.47500000000001, 54.97, 48.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.025, 54.43, 48.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.975, 54.365, 47.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.52499999999999, 53.73500000000001, 47.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.47, 53.67000000000001, 47.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.93, 53.13, 47.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.875, 53.065, 47.8]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.425, 52.434999999999995, 47.8]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.37, 52.37, 47.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.83, 51.83, 47.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.765, 51.769999999999996, 47.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.135, 51.230000000000004, 47.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.07, 51.17000000000001, 47.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.53, 50.63, 47.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.47000000000001, 50.57, 47.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.93, 50.03, 47.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.86500000000001, 49.97, 47.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.23500000000001, 49.43, 47.404999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.165, 49.375, 47.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.535, 48.925, 47.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.465, 48.87, 47.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.83500000000001, 48.33, 47.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.765, 48.269999999999996, 47.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.13499999999999, 47.730000000000004, 47.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.05999999999999, 47.675000000000004, 47.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.33999999999999, 47.225, 47.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.26499999999999, 47.175000000000004, 47.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.63499999999999, 46.725, 47.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.56, 46.675000000000004, 47.00000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.84, 46.22500000000001, 47.00000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.76, 46.175000000000004, 46.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.04, 45.725, 46.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.96, 45.675000000000004, 46.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.24, 45.22500000000001, 46.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.16, 45.175000000000004, 46.8]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.44, 44.725, 46.8]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.36, 44.68000000000001, 46.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.64, 44.32, 46.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.56, 44.275, 46.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.84, 43.825, 46.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.75500000000001, 43.78, 46.60000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.94500000000001, 43.42, 46.60000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.86, 43.38, 46.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.14, 43.02, 46.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.055, 42.980000000000004, 46.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.245, 42.620000000000005, 46.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.16, 42.580000000000005, 46.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.44, 42.220000000000006, 46.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.355, 42.185, 46.300000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.545, 41.915, 46.300000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.455, 41.88, 46.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.645, 41.52, 46.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.55499999999999, 41.485, 46.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.745, 41.215, 46.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.65500000000002, 41.185, 46.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.845, 40.915, 46.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.755, 40.885000000000005, 46.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.94500000000001, 40.615, 46.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.855, 40.585, 45.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.045, 40.315, 45.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.955, 40.285, 45.900000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.145, 40.015, 45.900000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.055, 39.99, 45.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.245, 39.81, 45.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.155, 39.785, 45.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.345, 39.515, 45.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.255, 39.49, 45.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.44500000000001, 39.309999999999995, 45.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.355, 39.29, 45.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.545, 39.11000000000001, 45.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.455, 39.09, 45.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.645, 38.91, 45.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.55499999999999, 38.89, 45.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.745, 38.71000000000001, 45.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.655, 38.69500000000001, 45.4]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.845, 38.605000000000004, 45.4]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.755, 38.59, 45.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.94500000000001, 38.410000000000004, 45.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.855, 38.395, 45.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.045, 38.305, 45.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.955, 38.295, 45.20000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.144999999999996, 38.205000000000005, 45.20000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.055, 38.195, 45.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.245000000000005, 38.105, 45.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.155, 38.095, 45.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.345, 38.005, 45.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.255, 37.995000000000005, 45.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.445, 37.905, 45.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.355000000000004, 37.9, 44.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.545, 37.9, 44.904999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.455000000000005, 37.894999999999996, 44.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.645, 37.80499999999999, 44.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.55500000000001, 37.8, 44.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.745000000000005, 37.8, 44.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.65500000000001, 37.8, 44.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.845, 37.8, 44.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.754999999999995, 37.8, 44.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.945, 37.8, 44.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.855000000000004, 37.8, 44.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.045, 37.8, 44.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.955, 37.8, 44.50000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.145, 37.8, 44.50000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.05500000000001, 37.80499999999999, 44.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.245000000000005, 37.894999999999996, 44.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.155, 37.905, 44.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.345, 37.995000000000005, 44.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.26, 38.005, 44.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.54, 38.095, 44.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.455, 38.105, 44.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.644999999999996, 38.195, 44.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.555, 38.205000000000005, 44.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.745000000000005, 38.295, 44.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.655, 38.31, 44.10000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.845, 38.489999999999995, 44.10000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.760000000000005, 38.51, 44.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.040000000000006, 38.690000000000005, 44.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.955000000000005, 38.71000000000001, 43.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.145, 38.89, 43.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.06, 38.91, 43.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.34, 39.09, 43.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.255, 39.11000000000001, 43.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.445, 39.29, 43.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.36, 39.315, 43.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.64, 39.585, 43.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.56, 39.61, 43.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.84, 39.79, 43.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.755, 39.815, 43.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.945, 40.085, 43.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.86, 40.115, 43.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.14, 40.385, 43.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.06, 40.42, 43.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.34, 40.78, 43.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.260000000000005, 40.815, 43.400000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.540000000000006, 41.085, 43.400000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.465, 41.120000000000005, 43.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.835, 41.480000000000004, 43.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.76, 41.52, 43.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.04, 41.88, 43.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.96, 41.92, 43.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.24, 42.28, 43.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.165000000000006, 42.32, 43.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.535, 42.68000000000001, 43.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.465, 42.720000000000006, 43.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.834999999999994, 43.08, 43.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.76, 43.125, 43.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.04, 43.575, 43.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.964999999999996, 43.620000000000005, 42.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.335, 43.980000000000004, 42.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.269999999999996, 44.025, 42.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.730000000000004, 44.475, 42.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.665000000000006, 44.525000000000006, 42.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.035000000000004, 44.975, 42.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.965, 45.025, 42.70000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.335, 45.475, 42.70000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.269999999999996, 45.53, 42.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.730000000000004, 46.07, 42.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.67, 46.125, 42.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.13, 46.575, 42.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.065, 46.62500000000001, 42.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.435, 47.075, 42.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.369999999999997, 47.13, 42.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.830000000000002, 47.67000000000001, 42.404999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.775000000000002, 47.730000000000004, 42.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.325, 48.269999999999996, 42.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.27, 48.33, 42.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.73, 48.87, 42.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.675, 48.93, 42.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.225, 49.470000000000006, 42.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.175, 49.53, 42.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.724999999999998, 50.07000000000001, 42.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.674999999999997, 50.13, 42.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.224999999999998, 50.67, 42.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.174999999999997, 50.730000000000004, 42.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.725, 51.27, 42.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.675, 51.33, 41.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.225, 51.870000000000005, 41.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.18, 51.935, 41.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.82, 52.565000000000005, 41.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.775000000000002, 52.63, 41.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.325000000000003, 53.17, 41.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.28, 53.235, 41.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.919999999999998, 53.864999999999995, 41.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.88, 53.93, 41.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.52, 54.470000000000006, 41.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.48, 54.535000000000004, 41.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.120000000000005, 55.165000000000006, 41.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.085000000000004, 55.23500000000001, 41.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.815, 55.865, 41.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.78, 55.935, 41.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.42, 56.565000000000005, 41.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.385, 56.635000000000005, 41.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.115000000000002, 57.265, 41.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.085, 57.335, 41.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.815, 57.965, 41.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.785, 58.035000000000004, 41.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.515, 58.665000000000006, 41.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.490000000000002, 58.73500000000001, 41.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.310000000000002, 59.365, 41.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.285000000000004, 59.435, 41.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.015, 60.065000000000005, 41.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.99, 60.135000000000005, 41.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.81, 60.765, 41.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.79, 60.835, 41.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.610000000000003, 61.465, 41.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.590000000000003, 61.54, 40.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.41, 62.26, 40.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.395, 62.335, 40.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.305, 62.965, 40.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.29, 63.035000000000004, 40.8]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.11, 63.665000000000006, 40.8]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.095, 63.74000000000001, 40.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.005000000000003, 64.46000000000001, 40.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.995, 64.535, 40.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.905, 65.165, 40.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.900000000000002, 65.24000000000001, 40.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.900000000000002, 65.96, 40.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.895, 66.035, 40.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.805, 66.665, 40.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.8, 66.74, 40.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.8, 67.46, 40.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.8, 67.535, 40.4]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.8, 68.165, 40.4]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.8, 68.24000000000001, 40.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.8, 68.96000000000001, 40.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.805, 69.035, 40.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.895, 69.665, 40.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.900000000000002, 69.74000000000001, 40.20000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.900000000000002, 70.46000000000001, 40.20000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.905, 70.54, 40.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.995, 71.26, 40.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.005000000000003, 71.33500000000001, 40.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.095, 71.965, 40.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.11, 72.03999999999999, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.29, 72.75999999999999, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.305, 72.83999999999999, 39.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.395, 73.55999999999999, 39.904999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.41, 73.63499999999999, 39.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.590000000000003, 74.265, 39.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.610000000000003, 74.34, 39.8]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.79, 75.06, 39.8]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.815, 75.14, 39.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.085000000000004, 75.86, 39.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.110000000000003, 75.935, 39.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.290000000000003, 76.565, 39.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.315, 76.64, 39.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.585, 77.36000000000001, 39.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.615000000000002, 77.43500000000002, 39.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.884999999999998, 78.065, 39.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.915, 78.13999999999999, 39.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.185000000000002, 78.86, 39.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.215000000000003, 78.94000000000001, 39.4]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.485, 79.66000000000001, 39.4]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.52, 79.735, 39.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.88, 80.36500000000001, 39.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.92, 80.44000000000001, 39.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.28, 81.16, 39.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.32, 81.235, 39.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.68, 81.86500000000001, 39.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.72, 81.94000000000001, 39.10000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.080000000000002, 82.66000000000001, 39.10000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.125000000000004, 82.73500000000001, 39.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.575000000000003, 83.36500000000001, 39.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.62, 83.44, 38.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.98, 84.16, 38.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.025000000000002, 84.235, 38.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.475, 84.86500000000001, 38.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.525, 84.93500000000002, 38.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.975, 85.565, 38.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.03, 85.63999999999999, 38.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.57, 86.36, 38.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.625000000000004, 86.435, 38.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.075000000000003, 87.065, 38.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.130000000000003, 87.135, 38.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.67, 87.765, 38.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.73, 87.835, 38.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.27, 88.465, 38.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.33, 88.53500000000001, 38.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.869999999999997, 89.165, 38.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.93, 89.235, 38.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.470000000000002, 89.86500000000001, 38.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.53, 89.93500000000002, 38.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.07, 90.565, 38.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.135, 90.63499999999999, 38.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.765, 91.265, 38.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.835, 91.33, 38.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.465, 91.87, 38.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.53, 91.935, 38.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.07, 92.565, 38.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.135000000000005, 92.63000000000001, 38.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.765, 93.17000000000002, 38.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.839999999999996, 93.23500000000001, 38.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.56, 93.86500000000001, 38.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.635, 93.93, 37.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.265, 94.47, 37.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.34, 94.53, 37.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.06, 95.07000000000001, 37.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.135, 95.13000000000001, 37.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.76499999999999, 95.67000000000002, 37.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.839999999999996, 95.73000000000002, 37.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.56, 96.27000000000001, 37.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.64, 96.33, 37.70000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.36, 96.87, 37.70000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.44, 96.92500000000001, 37.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.160000000000004, 97.37500000000001, 37.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.24000000000001, 97.43, 37.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.96, 97.97, 37.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.04, 98.025, 37.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.76, 98.47500000000001, 37.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.839999999999996, 98.525, 37.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.56, 98.97500000000001, 37.404999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.645, 99.025, 37.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.455, 99.475, 37.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.54, 99.525, 37.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.26, 99.975, 37.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.345, 100.025, 37.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.15500000000001, 100.47500000000001, 37.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.245000000000005, 100.52000000000001, 37.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.055, 100.88, 37.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.145, 100.92, 37.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.955000000000005, 101.28, 37.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.045, 101.325, 37.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.855, 101.775, 37.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.945, 101.82000000000001, 36.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.755, 102.18, 36.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.845, 102.215, 36.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.655, 102.485, 36.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.745000000000005, 102.52, 36.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.555, 102.88000000000001, 36.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.644999999999996, 102.91500000000002, 36.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.455, 103.18500000000002, 36.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.545, 103.215, 36.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.355, 103.48500000000001, 36.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.44499999999999, 103.51500000000001, 36.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.254999999999995, 103.785, 36.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.345, 103.815, 36.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.155, 104.085, 36.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.245000000000005, 104.11, 36.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.05500000000001, 104.29, 36.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.150000000000006, 104.31, 36.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.050000000000004, 104.49, 36.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.145, 104.50999999999999, 36.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.955000000000005, 104.69, 36.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.045, 104.71000000000001, 36.300000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.855000000000004, 104.89000000000001, 36.300000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.95, 104.90500000000002, 36.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.849999999999994, 104.995, 36.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.945, 105.01, 36.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.755, 105.19000000000001, 36.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.845, 105.20500000000001, 36.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.655, 105.295, 36.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.75, 105.3, 36.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.650000000000006, 105.3, 36.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.745000000000005, 105.30499999999999, 35.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.55500000000001, 105.39500000000001, 35.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.650000000000006, 105.40000000000002, 35.900000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.550000000000004, 105.40000000000002, 35.900000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.645, 105.40000000000002, 35.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.455, 105.40000000000002, 35.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.545, 105.40000000000002, 35.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.355, 105.40000000000002, 35.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.45, 105.39500000000001, 35.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.35000000000001, 105.30499999999999, 35.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.44500000000001, 105.3, 35.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.255, 105.3, 35.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.35, 105.295, 35.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.25, 105.20500000000001, 35.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.345, 105.19500000000001, 35.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.155, 105.105, 35.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.245, 105.095, 35.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.05499999999999, 105.005, 35.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.14999999999999, 104.99000000000001, 35.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.05, 104.81, 35.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.145, 104.78999999999999, 35.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.955, 104.61, 35.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.045, 104.59, 35.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.85500000000002, 104.41000000000001, 35.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.94500000000001, 104.39000000000001, 35.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.755, 104.21000000000001, 35.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.845, 104.19, 35.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.655, 104.01, 35.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.745, 103.98500000000001, 35.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.55499999999999, 103.715, 35.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.645, 103.685, 34.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.45500000000001, 103.415, 34.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.54500000000002, 103.385, 34.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.35500000000002, 103.115, 34.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.44500000000001, 103.085, 34.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.255, 102.815, 34.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.345, 102.78, 34.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.155, 102.42000000000002, 34.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.245, 102.38000000000001, 34.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.055, 102.02, 34.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.14500000000001, 101.97999999999999, 34.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.95500000000001, 101.62, 34.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.04, 101.58, 34.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.76, 101.22, 34.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.845, 101.18, 34.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.655, 100.82, 34.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.74000000000001, 100.775, 34.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.46000000000001, 100.32499999999999, 34.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.545, 100.27499999999999, 34.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.355, 99.82499999999999, 34.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.44000000000001, 99.77499999999999, 34.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.16000000000001, 99.325, 34.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.24000000000001, 99.275, 34.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.96000000000001, 98.825, 34.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.045, 98.775, 34.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.855, 98.325, 34.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.94000000000001, 98.27, 34.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.66000000000001, 97.73, 34.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.74000000000001, 97.67000000000002, 34.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.46000000000001, 97.13, 34.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.54, 97.075, 33.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.26, 96.625, 33.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.33500000000001, 96.57, 33.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.965, 96.03, 33.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.04, 95.965, 33.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.76, 95.335, 33.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.84, 95.27, 33.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.56, 94.73, 33.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.63499999999999, 94.67, 33.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.26499999999999, 94.13, 33.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.335, 94.065, 33.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.965, 93.435, 33.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.035, 93.36500000000001, 33.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.66499999999999, 92.73500000000001, 33.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.735, 92.665, 33.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.36500000000001, 92.035, 33.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.435, 91.965, 33.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.065, 91.33500000000001, 33.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.135, 91.265, 33.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.765, 90.63499999999999, 33.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.83, 90.565, 33.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.37, 89.93500000000002, 33.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.435, 89.86500000000001, 33.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.065, 89.235, 33.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.13, 89.16, 33.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.67000000000002, 88.44, 33.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.73, 88.36500000000001, 33.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.27, 87.73500000000001, 33.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.33, 87.66000000000001, 33.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.87, 86.94000000000001, 33.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.93, 86.86000000000001, 32.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.47, 86.14, 32.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.525, 86.05999999999999, 32.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.975, 85.33999999999999, 32.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.03, 85.25999999999999, 32.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.57, 84.53999999999999, 32.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.625, 84.46, 32.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([101.07499999999999, 83.74, 32.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.125, 83.66, 32.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([101.575, 82.94000000000001, 32.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.625, 82.86000000000001, 32.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.075, 82.14, 32.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.125, 82.06, 32.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.575, 81.34, 32.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.62, 81.255, 32.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.98, 80.44500000000001, 32.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.02000000000001, 80.36000000000001, 32.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.38, 79.64, 32.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.42500000000001, 79.56, 32.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.875, 78.84, 32.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.92, 78.755, 32.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.28, 77.94500000000001, 32.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.315, 77.86000000000001, 32.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.58500000000001, 77.14, 32.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.62, 77.055, 32.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.98, 76.245, 32.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.015, 76.155, 32.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.285, 75.345, 32.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.32, 75.255, 32.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.68, 74.44500000000001, 32.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.715, 74.36000000000001, 31.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.98500000000001, 73.64, 31.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.01500000000001, 73.55499999999999, 31.900000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.285, 72.745, 31.900000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.31, 72.655, 31.895000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.49000000000001, 71.845, 31.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.51500000000001, 71.75500000000001, 31.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.78500000000001, 70.94500000000001, 31.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.81, 70.855, 31.700000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.99, 70.045, 31.700000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.00999999999999, 69.955, 31.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.19, 69.145, 31.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.21000000000001, 69.05499999999999, 31.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.39000000000001, 68.245, 31.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.41000000000001, 68.155, 31.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.59, 67.345, 31.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.605, 67.255, 31.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.69500000000001, 66.44500000000001, 31.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.71000000000001, 66.355, 31.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.89000000000001, 65.545, 31.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.90500000000002, 65.455, 31.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.995, 64.645, 31.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.005, 64.55499999999999, 31.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.095, 63.745000000000005, 31.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.10499999999999, 63.65500000000001, 31.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.19500000000001, 62.845, 31.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.20000000000002, 62.754999999999995, 31.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.20000000000002, 61.945, 31.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.20500000000001, 61.855000000000004, 31.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.295, 61.045, 31.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.3, 60.955, 30.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.3, 60.145, 30.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.3, 60.050000000000004, 30.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.3, 59.150000000000006, 30.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.3, 59.05500000000001, 30.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.3, 58.245000000000005, 30.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.3, 58.155, 30.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.3, 57.345, 30.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.295, 57.255, 30.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.20500000000001, 56.445, 30.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.19500000000001, 56.355, 30.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.10499999999999, 55.545, 30.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.1, 55.455000000000005, 30.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.1, 54.645, 30.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.095, 54.555, 30.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.005, 53.745000000000005, 30.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.99000000000001, 53.65500000000001, 30.494999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.81, 52.845, 30.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.795, 52.754999999999995, 30.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.70500000000001, 51.945, 30.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.69000000000001, 51.855000000000004, 30.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.51, 51.045, 30.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.49000000000001, 50.955, 30.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.31, 50.145, 30.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.28999999999999, 50.05500000000001, 30.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.11, 49.245000000000005, 30.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.09, 49.155, 30.100000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.91000000000001, 48.345, 30.100000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.885, 48.254999999999995, 30.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.615, 47.44499999999999, 30.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.59, 47.355, 29.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.41000000000001, 46.545, 29.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.385, 46.455, 29.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.115, 45.644999999999996, 29.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.085, 45.555, 29.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.815, 44.745000000000005, 29.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.785, 44.655, 29.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.515, 43.845, 29.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.485, 43.760000000000005, 29.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.215, 43.040000000000006, 29.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.185, 42.955000000000005, 29.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.91500000000002, 42.145, 29.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.88000000000001, 42.055, 29.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.52, 41.245000000000005, 29.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.47999999999999, 41.15500000000001, 29.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.12, 40.345, 29.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.08, 40.26, 29.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.72, 39.540000000000006, 29.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.68, 39.455000000000005, 29.395000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.32, 38.645, 29.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.28, 38.56, 29.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.92000000000002, 37.839999999999996, 29.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.88000000000001, 37.754999999999995, 29.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.52, 36.945, 29.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.475, 36.86, 29.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.025, 36.14, 29.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.975, 36.055, 29.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([101.525, 35.245000000000005, 29.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.47500000000001, 35.160000000000004, 29.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([101.025, 34.44, 29.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.97500000000001, 34.36, 28.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.525, 33.64, 28.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.47500000000001, 33.56, 28.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.025, 32.84, 28.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.975, 32.754999999999995, 28.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.525, 31.945, 28.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.47, 31.86, 28.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.93, 31.14, 28.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.875, 31.060000000000002, 28.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.42500000000001, 30.34, 28.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.37, 30.259999999999998, 28.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.83, 29.54, 28.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.77, 29.465, 28.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.23, 28.835, 28.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.17, 28.76, 28.500000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.63, 28.04, 28.500000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.57, 27.96, 28.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.03, 27.240000000000002, 28.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.97, 27.165, 28.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.43, 26.535000000000004, 28.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.36500000000001, 26.46, 28.300000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.735, 25.74, 28.300000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.665, 25.665, 28.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.03500000000001, 25.035, 28.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.97000000000001, 24.965, 28.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.43, 24.335, 28.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.36500000000001, 24.265, 28.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.73500000000001, 23.635, 28.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.665, 23.560000000000002, 28.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.035, 22.84, 28.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.965, 22.765, 27.994999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.33500000000001, 22.135, 27.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.265, 22.065, 27.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.63499999999999, 21.435, 27.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.55999999999999, 21.369999999999997, 27.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.83999999999999, 20.830000000000002, 27.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.76499999999999, 20.765000000000004, 27.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.13499999999999, 20.135000000000005, 27.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.06, 20.065000000000005, 27.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.34, 19.435000000000002, 27.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.265, 19.37, 27.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.635, 18.830000000000002, 27.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.56, 18.770000000000003, 27.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.84, 18.23, 27.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.76, 18.165, 27.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.04, 17.535, 27.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.96000000000001, 17.47, 27.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.24000000000001, 16.93, 27.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.16000000000001, 16.869999999999997, 27.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.44000000000001, 16.330000000000002, 27.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.36000000000001, 16.270000000000003, 27.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.64, 15.729999999999999, 27.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.55999999999999, 15.674999999999999, 27.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.83999999999999, 15.225, 27.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.755, 15.17, 27.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.94500000000001, 14.63, 27.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.86000000000001, 14.575000000000001, 27.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.14, 14.125, 27.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.05499999999999, 14.07, 27.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.245, 13.530000000000001, 27.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.16000000000001, 13.475000000000001, 26.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.44000000000001, 13.025000000000002, 26.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.355, 12.975000000000001, 26.900000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.545, 12.525, 26.900000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.46000000000001, 12.475, 26.895000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.74000000000001, 12.025, 26.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.655, 11.975000000000001, 26.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.845, 11.525, 26.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.75500000000001, 11.475, 26.700000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.94500000000001, 11.025, 26.700000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.855, 10.98, 26.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.045, 10.62, 26.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.955, 10.575, 26.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.145, 10.125, 26.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.05499999999999, 10.08, 26.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.245, 9.72, 26.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.15500000000002, 9.68, 26.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.345, 9.32, 26.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.255, 9.280000000000001, 26.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.44500000000001, 8.92, 26.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.355, 8.879999999999999, 26.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.545, 8.52, 26.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.455, 8.48, 26.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.645, 8.120000000000001, 26.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.55499999999999, 8.085, 26.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.745, 7.8149999999999995, 26.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.655, 7.779999999999999, 26.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.845, 7.42, 26.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.755, 7.385, 26.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.94500000000001, 7.115, 26.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.85000000000001, 7.085, 25.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.95000000000002, 6.815, 25.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.855, 6.785, 25.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.045, 6.515000000000001, 25.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.955, 6.485, 25.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.145, 6.215, 25.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.05499999999999, 6.1850000000000005, 25.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.245000000000005, 5.915000000000001, 25.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.155, 5.890000000000001, 25.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.345, 5.71, 25.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.25, 5.685, 25.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.35, 5.415, 25.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.255, 5.390000000000001, 25.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.445, 5.210000000000001, 25.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.355000000000004, 5.19, 25.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.545, 5.01, 25.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.455000000000005, 4.99, 25.494999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.645, 4.8100000000000005, 25.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.550000000000004, 4.79, 25.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.650000000000006, 4.609999999999999, 25.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.55500000000001, 4.595, 25.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.745000000000005, 4.505, 25.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.655, 4.49, 25.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.845, 4.3100000000000005, 25.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.75, 4.295, 25.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.85, 4.205, 25.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.755, 4.195, 25.100000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.945, 4.105, 25.100000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.855, 4.095, 25.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.045, 4.005, 25.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.95, 3.995, 24.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.050000000000004, 3.905, 24.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.955000000000005, 3.8949999999999996, 24.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.145, 3.8049999999999997, 24.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.05500000000001, 3.8, 24.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.245000000000005, 3.8, 24.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.15500000000001, 3.795, 24.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.345, 3.705, 24.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.25, 3.7, 24.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.35, 3.7, 24.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.254999999999995, 3.7, 24.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.44499999999999, 3.7, 24.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.355, 3.7, 24.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.545, 3.7, 24.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.455, 3.7, 24.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.644999999999996, 3.7, 24.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.55, 3.7, 24.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.65, 3.7, 24.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.555, 3.705, 24.395000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.745000000000005, 3.795, 24.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.65500000000001, 3.8049999999999997, 24.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.845, 3.8949999999999996, 24.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.754999999999995, 3.905, 24.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.945, 3.995, 24.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.855000000000004, 4.005, 24.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.045, 4.095, 24.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.949999999999996, 4.105, 24.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.05, 4.195, 24.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.955, 4.205, 24.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.145, 4.295, 24.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.05500000000001, 4.3100000000000005, 23.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.245000000000005, 4.49, 23.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.155, 4.505, 23.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.345, 4.595, 23.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.255, 4.609999999999999, 23.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.445, 4.79, 23.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.355, 4.8100000000000005, 23.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.545, 4.99, 23.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.455, 5.015, 23.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.645, 5.284999999999999, 23.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.555, 5.31, 23.694999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.745000000000005, 5.49, 23.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.660000000000004, 5.515000000000001, 23.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.94, 5.785, 23.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.855, 5.8149999999999995, 23.500000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.045, 6.085, 23.500000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.955000000000002, 6.115, 23.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.145000000000003, 6.385000000000001, 23.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.055000000000003, 6.415000000000001, 23.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.245, 6.6850000000000005, 23.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.16, 6.715, 23.300000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.44, 6.984999999999999, 23.300000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.355, 7.02, 23.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.545, 7.38, 23.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.46, 7.42, 23.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.740000000000002, 7.779999999999999, 23.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.655, 7.819999999999999, 23.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.845000000000002, 8.18, 23.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.76, 8.219999999999999, 23.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.040000000000003, 8.58, 23.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.96, 8.620000000000001, 22.994999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.240000000000002, 8.98, 22.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.155, 9.025, 22.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.345000000000002, 9.475000000000001, 22.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.26, 9.520000000000001, 22.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.540000000000003, 9.88, 22.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.46, 9.925, 22.794999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.74, 10.375000000000002, 22.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.66, 10.425, 22.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.94, 10.875, 22.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.86, 10.925, 22.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.14, 11.375, 22.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.060000000000002, 11.425, 22.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.34, 11.875, 22.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.259999999999998, 11.930000000000001, 22.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.54, 12.47, 22.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.465, 12.525, 22.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.835, 12.975000000000001, 22.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.76, 13.030000000000001, 22.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.04, 13.57, 22.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.965, 13.625, 22.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.335, 14.075, 22.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.26, 14.129999999999999, 22.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.54, 14.67, 22.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.465, 14.73, 22.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.835, 15.270000000000001, 22.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.765, 15.330000000000002, 22.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.135, 15.870000000000001, 22.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.065, 15.93, 22.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.435, 16.47, 22.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.365000000000002, 16.535, 21.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.735, 17.165, 21.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.665, 17.23, 21.900000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.035, 17.77, 21.900000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.97, 17.835, 21.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.43, 18.465000000000003, 21.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.365, 18.53, 21.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.735, 19.07, 21.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.67, 19.135, 21.700000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.13, 19.765, 21.700000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.07, 19.835, 21.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.530000000000001, 20.465, 21.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.47, 20.535, 21.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.93, 21.165, 21.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.870000000000001, 21.235, 21.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.330000000000002, 21.865000000000002, 21.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.270000000000001, 21.935000000000002, 21.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.729999999999999, 22.565000000000005, 21.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.669999999999998, 22.635000000000005, 21.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.129999999999999, 23.265000000000004, 21.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.075, 23.335, 21.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.625, 23.965, 21.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.57, 24.040000000000003, 21.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.029999999999999, 24.76, 21.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.975, 24.835, 21.194999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.525, 25.465, 21.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.4750000000000005, 25.535, 21.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.025, 26.165, 21.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.9750000000000005, 26.24, 21.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.525, 26.96, 21.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.48, 27.04, 20.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.12, 27.759999999999998, 20.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.075, 27.835, 20.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.625, 28.465000000000003, 20.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.58, 28.540000000000003, 20.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.220000000000001, 29.26, 20.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.175000000000001, 29.340000000000003, 20.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.725, 30.060000000000002, 20.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.68, 30.135000000000005, 20.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.32, 30.765000000000004, 20.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.28, 30.840000000000003, 20.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.92, 31.560000000000002, 20.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.885, 31.64, 20.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.615, 32.36, 20.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.5800000000000005, 32.44, 20.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.22, 33.160000000000004, 20.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.185, 33.24, 20.494999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.915, 33.96, 20.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.885, 34.04, 20.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6150000000000002, 34.76, 20.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5850000000000002, 34.839999999999996, 20.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.3150000000000002, 35.56, 20.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.2850000000000001, 35.64, 20.294999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0150000000000001, 36.36, 20.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.985, 36.445, 20.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.715, 37.255, 20.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.69, 37.34, 20.100000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.51, 38.06, 20.100000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.485, 38.14, 20.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.21500000000000002, 38.86, 20.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.19000000000000003, 38.945, 19.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.010000000000000002, 39.755, 19.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.005000000000000001, 39.84, 19.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.09500000000000001, 40.56, 19.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.11000000000000001, 40.644999999999996, 19.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.29000000000000004, 41.455, 19.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.305, 41.54, 19.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.395, 42.26, 19.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.405, 42.34, 19.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.495, 43.06, 19.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.505, 43.144999999999996, 19.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.5950000000000001, 43.955, 19.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.605, 44.045, 19.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.695, 44.855, 19.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.7050000000000001, 44.94, 19.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.7950000000000002, 45.660000000000004, 19.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.8, 45.745000000000005, 19.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.8, 46.55500000000001, 19.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.8, 46.64000000000001, 19.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.8, 47.36, 19.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.8, 47.44499999999999, 19.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.8, 48.254999999999995, 19.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.8, 48.345, 19.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.8, 49.155, 19.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.7950000000000002, 49.245000000000005, 19.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.7050000000000001, 50.05500000000001, 19.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.695, 50.14, 19.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.605, 50.86, 19.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.5950000000000001, 50.945, 19.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.505, 51.754999999999995, 19.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.495, 51.845, 18.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.405, 52.65500000000001, 18.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.39000000000000007, 52.74000000000001, 18.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.21000000000000002, 53.46, 18.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.19000000000000003, 53.545, 18.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.010000000000000002, 54.355000000000004, 18.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.005000000000000001, 54.445, 18.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.09500000000000001, 55.254999999999995, 18.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.11000000000000001, 55.345, 18.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.29000000000000004, 56.15500000000001, 18.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.31000000000000005, 56.24000000000001, 18.694999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.49, 56.96000000000001, 18.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.515, 57.045, 18.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.7850000000000001, 57.855000000000004, 18.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.81, 57.945, 18.500000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.99, 58.755, 18.500000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0150000000000001, 58.845, 18.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.2850000000000001, 59.655, 18.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.31, 59.74, 18.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.49, 60.46, 18.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5150000000000001, 60.545, 18.300000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7850000000000001, 61.355, 18.300000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8150000000000002, 61.445, 18.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.085, 62.255, 18.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.12, 62.34, 18.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.48, 63.06, 18.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.515, 63.144999999999996, 18.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.785, 63.955, 18.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8200000000000003, 64.045, 18.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.1800000000000006, 64.855, 18.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.2150000000000003, 64.94, 17.994999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.485, 65.66, 17.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.52, 65.745, 17.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.88, 66.55499999999999, 17.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.92, 66.64, 17.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.28, 67.36, 17.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.32, 67.44500000000001, 17.794999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.680000000000001, 68.255, 17.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.7250000000000005, 68.34, 17.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.175000000000001, 69.06, 17.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.220000000000001, 69.145, 17.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.58, 69.955, 17.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.625, 70.04, 17.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.075, 70.76, 17.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.125, 70.845, 17.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.574999999999999, 71.655, 17.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.625, 71.74, 17.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.074999999999999, 72.46, 17.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.125, 72.54, 17.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.575, 73.26, 17.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.625, 73.345, 17.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.075, 74.155, 17.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.129999999999999, 74.24, 17.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.669999999999998, 74.96, 17.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.725, 75.04, 17.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.174999999999999, 75.76, 17.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.229999999999999, 75.84, 17.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.77, 76.56, 17.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.83, 76.64, 17.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.370000000000001, 77.36000000000001, 17.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.430000000000001, 77.44500000000001, 16.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.97, 78.255, 16.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.030000000000001, 78.34, 16.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.57, 79.06, 16.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.635, 79.13499999999999, 16.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.265, 79.76499999999999, 16.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.33, 79.83999999999999, 16.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.870000000000001, 80.55999999999999, 16.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.935000000000002, 80.63999999999999, 16.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.565000000000001, 81.36, 16.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.63, 81.44000000000001, 16.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.17, 82.16000000000001, 16.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.235, 82.24000000000001, 16.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.865, 82.96000000000001, 16.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.935, 83.035, 16.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.565, 83.66499999999999, 16.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.635, 83.74, 16.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.265, 84.46, 16.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.335, 84.535, 16.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.965, 85.165, 16.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.04, 85.24000000000001, 16.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.759999999999998, 85.96000000000001, 16.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.835, 86.03500000000001, 16.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.465000000000003, 86.665, 16.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.540000000000003, 86.735, 16.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.26, 87.36500000000001, 16.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.335, 87.44000000000001, 16.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.965, 88.16000000000001, 16.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.04, 88.23500000000001, 16.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.76, 88.86500000000001, 16.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.840000000000003, 88.935, 15.995000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.560000000000002, 89.565, 15.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.64, 89.635, 15.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.36, 90.265, 15.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.44, 90.33, 15.895000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.16, 90.87, 15.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.24, 90.935, 15.795000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.96, 91.565, 15.704999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.045, 91.63499999999999, 15.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.855, 92.26499999999999, 15.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.94, 92.33, 15.694999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.66, 92.87000000000002, 15.604999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.74, 92.93500000000002, 15.594999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.46, 93.565, 15.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.545, 93.63, 15.500000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.355, 94.17, 15.500000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.445, 94.23, 15.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.255000000000003, 94.77, 15.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.340000000000003, 94.83, 15.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.060000000000002, 95.37000000000002, 15.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.145000000000003, 95.43, 15.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.955, 95.97, 15.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.045, 96.03, 15.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.854999999999997, 96.57, 15.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.945, 96.63, 15.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.755000000000003, 97.17, 15.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.845000000000002, 97.22500000000001, 15.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.655, 97.67500000000001, 15.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.745000000000005, 97.73, 15.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.555, 98.27, 15.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.650000000000006, 98.325, 14.995000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.55, 98.775, 14.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.645, 98.825, 14.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.455, 99.275, 14.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.545, 99.325, 14.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.355, 99.77499999999999, 14.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.449999999999996, 99.82499999999999, 14.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.349999999999994, 100.27499999999999, 14.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.44499999999999, 100.32499999999999, 14.700000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.254999999999995, 100.775, 14.700000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.35, 100.825, 14.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.25, 101.275, 14.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.345, 101.32000000000001, 14.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.15500000000001, 101.68, 14.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.25000000000001, 101.725, 14.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.150000000000006, 102.17500000000001, 14.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.245000000000005, 102.22, 14.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.055, 102.58000000000001, 14.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.15, 102.62, 14.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.05, 102.98, 14.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.15, 103.02000000000001, 14.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.050000000000004, 103.38, 14.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.150000000000006, 103.42, 14.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.050000000000004, 103.78, 14.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.150000000000006, 103.815, 14.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.050000000000004, 104.085, 14.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.150000000000006, 104.12, 14.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.05, 104.47999999999999, 14.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.15, 104.515, 14.094999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.05, 104.785, 14.004999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.15, 104.815, 13.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.050000000000004, 105.08500000000001, 13.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.150000000000006, 105.11500000000001, 13.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.050000000000004, 105.38500000000002, 13.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.150000000000006, 105.41500000000002, 13.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.050000000000004, 105.68500000000002, 13.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.150000000000006, 105.715, 13.795000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.05, 105.98500000000001, 13.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.15, 106.01, 13.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.05, 106.19, 13.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.155, 106.215, 13.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.145, 106.48500000000001, 13.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.25, 106.51, 13.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.150000000000006, 106.69, 13.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.25000000000001, 106.71000000000001, 13.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.150000000000006, 106.89000000000001, 13.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.25500000000001, 106.91000000000001, 13.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.245000000000005, 107.09, 13.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.35, 107.105, 13.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.25, 107.19500000000001, 13.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.35, 107.21000000000001, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.25, 107.39000000000001, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.355, 107.40500000000002, 13.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.345, 107.495, 13.204999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.45, 107.505, 13.194999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.349999999999994, 107.595, 13.104999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.455, 107.605, 13.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.445, 107.69500000000001, 13.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.55, 107.7, 13.094999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.45, 107.7, 13.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.555, 107.70500000000001, 12.995000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.54499999999999, 107.795, 12.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.64999999999999, 107.8, 12.900000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.55, 107.8, 12.900000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.65, 107.8, 12.895000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.55, 107.8, 12.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.655, 107.8, 12.795000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.64500000000001, 107.8, 12.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.75, 107.795, 12.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.65, 107.70500000000001, 12.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.75500000000001, 107.69500000000001, 12.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.745, 107.605, 12.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.85, 107.595, 12.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.75, 107.505, 12.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.85, 107.495, 12.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.75, 107.40500000000002, 12.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.855, 107.39500000000001, 12.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.84500000000001, 107.30499999999999, 12.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.95000000000002, 107.28999999999999, 12.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.85000000000001, 107.11, 12.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.95500000000001, 107.09, 12.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.945, 106.91000000000001, 12.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.05, 106.89000000000001, 12.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.95, 106.71000000000001, 12.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.05000000000001, 106.69, 12.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.95, 106.51, 12.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.05, 106.48500000000001, 12.100000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.95, 106.215, 12.100000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.055, 106.185, 12.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.045, 105.915, 12.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.14999999999999, 105.885, 11.995000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.05, 105.615, 11.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.15, 105.585, 11.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.05, 105.315, 11.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.14999999999999, 105.285, 11.895000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.05, 105.015, 11.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.15, 104.98, 11.795000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.05, 104.62, 11.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.14999999999999, 104.58, 11.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.05, 104.22, 11.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.14999999999999, 104.18, 11.694999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.05, 103.82000000000001, 11.604999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.15, 103.775, 11.594999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.05, 103.325, 11.504999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.14999999999999, 103.28, 11.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.05, 102.92000000000002, 11.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.145, 102.87500000000001, 11.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.955, 102.42500000000001, 11.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.05, 102.37500000000001, 11.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.95, 101.92500000000001, 11.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.05000000000001, 101.87500000000001, 11.300000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.95, 101.42500000000001, 11.300000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.045, 101.37, 11.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.855, 100.83, 11.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.95, 100.775, 11.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.85000000000001, 100.32499999999999, 11.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.94500000000001, 100.27, 11.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.755, 99.73, 11.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.845, 99.67, 11.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.655, 99.13, 11.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.745, 99.07, 10.995000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.555, 98.53, 10.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.645, 98.465, 10.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.455, 97.835, 10.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.545, 97.77, 10.895000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.355, 97.23, 10.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.44500000000001, 97.165, 10.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.255, 96.53500000000001, 10.704999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.345, 96.465, 10.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.15500000000002, 95.83500000000001, 10.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.24000000000001, 95.765, 10.694999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.96000000000001, 95.135, 10.604999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.04500000000002, 95.065, 10.594999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.85500000000002, 94.435, 10.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.94000000000001, 94.36500000000001, 10.500000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.66000000000001, 93.735, 10.500000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.74000000000001, 93.66, 10.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([101.46000000000001, 92.94000000000001, 10.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.54, 92.86000000000001, 10.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.25999999999999, 92.14, 10.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.33999999999999, 92.06, 10.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.05999999999999, 91.34, 10.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.13999999999999, 91.265, 10.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.86000000000001, 90.63499999999999, 10.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.94000000000001, 90.55999999999999, 10.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.66000000000001, 89.83999999999999, 10.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.73500000000001, 89.755, 10.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.36500000000001, 88.94500000000001, 10.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.44000000000001, 88.86, 10.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.16, 88.13999999999999, 10.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.235, 88.05999999999999, 9.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.86500000000001, 87.33999999999999, 9.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.935, 87.255, 9.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.565, 86.44500000000001, 9.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.635, 86.36, 9.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.265, 85.63999999999999, 9.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.33500000000001, 85.55499999999999, 9.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.965, 84.745, 9.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([109.03, 84.655, 9.700000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.57, 83.845, 9.700000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([109.635, 83.755, 9.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([110.265, 82.94500000000001, 9.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.33, 82.85500000000002, 9.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([110.87, 82.045, 9.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.93, 81.955, 9.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([111.47000000000001, 81.145, 9.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.53, 81.05499999999999, 9.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.07, 80.245, 9.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([112.13, 80.155, 9.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.67000000000002, 79.345, 9.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([112.73, 79.25, 9.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([113.27, 78.35, 9.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.325, 78.255, 9.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([113.775, 77.44500000000001, 9.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.825, 77.35000000000001, 9.194999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([114.275, 76.45, 9.104999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.325, 76.355, 9.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([114.77499999999999, 75.545, 9.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.82499999999999, 75.45, 9.094999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.27499999999999, 74.55, 9.004999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([115.32499999999999, 74.455, 8.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.775, 73.645, 8.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([115.825, 73.55, 8.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.275, 72.65, 8.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.32000000000001, 72.55, 8.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.68, 71.64999999999999, 8.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.72, 71.55499999999999, 8.795000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.08, 70.745, 8.704999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.12, 70.65, 8.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.48, 69.75, 8.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.52, 69.65, 8.694999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.88000000000001, 68.75, 8.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.91500000000002, 68.65, 8.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.18500000000002, 67.75, 8.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118.22000000000001, 67.65, 8.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.58, 66.75, 8.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118.615, 66.65, 8.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.885, 65.75, 8.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118.915, 65.65, 8.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.185, 64.75, 8.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.215, 64.65, 8.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.485, 63.75000000000001, 8.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.515, 63.650000000000006, 8.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.785, 62.75000000000001, 8.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.81, 62.650000000000006, 8.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.99000000000001, 61.75, 8.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.015, 61.650000000000006, 8.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.285, 60.75, 8.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.31, 60.650000000000006, 8.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.49000000000001, 59.75000000000001, 8.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.51, 59.650000000000006, 7.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.69000000000001, 58.75000000000001, 7.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.70500000000001, 58.64500000000001, 7.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.795, 57.655, 7.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.81, 57.550000000000004, 7.8950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.99000000000001, 56.650000000000006, 7.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.00500000000001, 56.550000000000004, 7.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.095, 55.65, 7.705000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.11, 55.55, 7.700000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.29, 54.65, 7.700000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.3, 54.55, 7.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.3, 53.650000000000006, 7.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.305, 53.550000000000004, 7.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.39500000000001, 52.650000000000006, 7.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.405, 52.545, 7.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.495, 51.555, 7.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.50000000000001, 51.45, 7.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.50000000000001, 50.550000000000004, 7.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.50000000000001, 50.45, 7.3950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.50000000000001, 49.550000000000004, 7.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.50000000000001, 49.45, 7.300000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.50000000000001, 48.55, 7.300000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.50000000000001, 48.45, 7.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.50000000000001, 47.55, 7.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.50000000000001, 47.445, 7.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.50000000000001, 46.455, 7.1049999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.495, 46.349999999999994, 7.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.405, 45.45, 7.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.39500000000001, 45.35, 7.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.305, 44.45, 7.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.295, 44.35, 6.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.205, 43.45, 6.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.19, 43.35, 6.900000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.01, 42.449999999999996, 6.900000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.995, 42.349999999999994, 6.895000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.905, 41.449999999999996, 6.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.89, 41.349999999999994, 6.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.71000000000001, 40.45, 6.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.69000000000001, 40.35, 6.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.51, 39.45, 6.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.49000000000001, 39.35, 6.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.31, 38.45, 6.6049999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.28999999999999, 38.35, 6.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.11, 37.449999999999996, 6.505000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.08500000000001, 37.349999999999994, 6.500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.815, 36.449999999999996, 6.500000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.78999999999999, 36.349999999999994, 6.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.61, 35.45, 6.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.58500000000001, 35.35, 6.3950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.315, 34.45, 6.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.28500000000001, 34.35, 6.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.01500000000001, 33.449999999999996, 6.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118.98, 33.355, 6.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.61999999999999, 32.545, 6.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118.585, 32.45, 6.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.315, 31.55, 6.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118.28, 31.455000000000002, 6.1000000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.92000000000002, 30.645000000000003, 6.1000000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.88000000000001, 30.550000000000004, 6.095000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.52, 29.650000000000002, 6.005000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.48, 29.555, 5.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.12, 28.744999999999997, 5.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.08, 28.65, 5.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.72, 27.75, 5.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.68, 27.655, 5.8950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.32000000000001, 26.845000000000002, 5.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.275, 26.755000000000003, 5.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.825, 25.945, 5.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([115.775, 25.854999999999997, 5.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.32499999999999, 25.045, 5.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([115.27499999999999, 24.955, 5.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([114.82499999999999, 24.145000000000003, 5.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.77499999999999, 24.055, 5.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([114.325, 23.244999999999997, 5.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.275, 23.154999999999998, 5.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([113.825, 22.345, 5.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.77000000000001, 22.255, 5.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([113.23000000000002, 21.444999999999997, 5.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.17500000000001, 21.36, 5.3950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.72500000000001, 20.640000000000004, 5.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([112.67000000000002, 20.555000000000003, 5.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.13, 19.745, 5.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([112.07, 19.66, 5.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([111.53, 18.939999999999998, 5.205000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.465, 18.86, 5.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([110.83500000000001, 18.140000000000004, 5.1049999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.77, 18.055000000000003, 5.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([110.23, 17.245, 5.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.165, 17.16, 5.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.535, 16.439999999999998, 5.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([109.47, 16.36, 4.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.93, 15.639999999999999, 4.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.86500000000001, 15.559999999999999, 4.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.23500000000001, 14.84, 4.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.165, 14.76, 4.8950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.535, 14.04, 4.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.465, 13.965, 4.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.83500000000001, 13.335, 4.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.76, 13.260000000000002, 4.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.04, 12.54, 4.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.965, 12.465, 4.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.335, 11.835, 4.6049999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.25999999999999, 11.765, 4.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.53999999999999, 11.135, 4.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.46, 11.065, 4.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.74, 10.435, 4.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.66, 10.365000000000002, 4.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.94000000000001, 9.735000000000001, 4.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.86000000000001, 9.665000000000001, 4.3950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.14, 9.035, 4.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.06, 8.965, 4.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([101.34, 8.335, 4.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.26, 8.270000000000001, 4.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.54, 7.73, 4.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.455, 7.670000000000001, 4.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.645, 7.13, 4.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.56, 7.069999999999999, 4.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.84, 6.53, 4.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.755, 6.470000000000001, 4.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.94500000000002, 5.930000000000001, 4.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.85500000000002, 5.87, 3.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.045, 5.329999999999999, 3.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.955, 5.27, 3.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.145, 4.73, 3.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.05499999999999, 4.675000000000001, 3.8949999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.245, 4.2250000000000005, 3.8049999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.155, 4.175000000000001, 3.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.345, 3.725, 3.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.25500000000001, 3.6750000000000003, 3.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.44500000000001, 3.2250000000000005, 3.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.355, 3.1750000000000003, 3.6950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.545, 2.725, 3.6050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.45, 2.6750000000000003, 3.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.55000000000001, 2.225, 3.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.45500000000001, 2.18, 3.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.645, 1.82, 3.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.55, 1.7800000000000002, 3.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.65, 1.42, 3.4050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.55, 1.38, 3.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.64999999999999, 1.02, 3.3049999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.55499999999999, 0.98, 3.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.745, 0.6200000000000001, 3.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.65, 0.5850000000000001, 3.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.75, 0.315, 3.2050000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.65, 0.28500000000000003, 3.1950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.75000000000001, 0.015, 3.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.65, -0.015, 3.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.75, -0.28500000000000003, 3.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.65, -0.315, 3.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.75, -0.5850000000000001, 3.0050000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.65, -0.61, 2.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.75, -0.79, 2.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.65, -0.81, 2.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.75, -0.99, 2.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.645, -1.01, 2.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.65499999999999, -1.1900000000000002, 2.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.55, -1.21, 2.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.65, -1.39, 2.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.55, -1.405, 2.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.64999999999999, -1.495, 2.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.55, -1.5050000000000001, 2.6950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.65, -1.5950000000000002, 2.6050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.55, -1.6050000000000002, 2.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.64999999999999, -1.695, 2.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.545, -1.7, 2.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.555, -1.7, 2.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.45, -1.705, 2.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.55, -1.7950000000000002, 2.4050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.45, -1.8, 2.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.55000000000001, -1.8, 2.3049999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.45, -1.8, 2.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.55, -1.8, 2.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.445, -1.7950000000000002, 2.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.45500000000001, -1.705, 2.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.35000000000001, -1.7, 2.1950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.45, -1.7, 2.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.35000000000001, -1.695, 2.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.45, -1.6050000000000002, 2.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.35000000000001, -1.5950000000000002, 2.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.45000000000002, -1.5050000000000001, 2.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.34500000000001, -1.495, 1.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.355, -1.405, 1.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.25, -1.39, 1.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.35, -1.21, 1.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.25, -1.1900000000000002, 1.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.35, -1.01, 1.8050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.25, -0.995, 1.7950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.35, -0.905, 1.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.25, -0.8900000000000001, 1.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.35, -0.71, 1.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.25, -0.685, 1.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.35, -0.41500000000000004, 1.6050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.25, -0.39000000000000007, 1.5950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.35, -0.21000000000000002, 1.5050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.25, -0.18500000000000003, 1.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.349999999999994, 0.085, 1.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.25, 0.11000000000000001, 1.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.349999999999994, 0.29000000000000004, 1.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.25, 0.315, 1.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.35, 0.5850000000000001, 1.3050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.25, 0.615, 1.3000000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.35, 0.885, 1.3000000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.25, 0.915, 1.2950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.35, 1.185, 1.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.25, 1.215, 1.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.349999999999994, 1.485, 1.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.254999999999995, 1.52, 1.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.445, 1.88, 1.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.35, 1.915, 1.0950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.45, 2.185, 1.0050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.355000000000004, 2.22, 0.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.545, 2.5800000000000005, 0.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.45, 2.62, 0.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.550000000000004, 2.98, 0.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.455, 3.0200000000000005, 0.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.644999999999996, 3.38, 0.8050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.555, 3.42, 0.7950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.745000000000005, 3.78, 0.7050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.655, 3.825, 0.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.845, 4.275, 0.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.75, 4.32, 0.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.849999999999994, 4.680000000000001, 0.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.754999999999995, 4.7250000000000005, 0.5950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.945, 5.175000000000001, 0.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.855000000000004, 5.2250000000000005, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.045, 5.675, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.96, 5.725, 0.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.24000000000001, 6.175, 0.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.15500000000001, 6.225, 0.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.345, 6.675000000000001, 0.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.254999999999995, 6.73, 0.30000000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.445, 7.2700000000000005, 0.30000000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.355000000000004, 7.325, 0.29500000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.545, 7.7749999999999995, 0.20500000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.46, 7.83, 0.19500000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.74, 8.370000000000001, 0.10500000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.655, 8.43, 0.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.845, 8.969999999999999, 0.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.76, 9.03, 0.09500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.04, 9.57, 0.005000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}

