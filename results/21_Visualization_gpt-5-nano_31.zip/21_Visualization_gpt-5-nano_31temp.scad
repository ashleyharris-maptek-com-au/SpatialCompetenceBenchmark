
hull() {
    translate([5.05, 5.0, 94.9975]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.95, 5.0, 94.9525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.050000000000001, 5.0, 94.9475]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.95, 5.0, 94.90250000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.05, 5.05, 94.89750000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.95, 5.95, 94.85249999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.05, 6.050000000000001, 94.8475]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.95, 6.95, 94.8025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.049999999999999, 7.1, 94.797]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.95, 8.9, 94.743]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.05, 9.1, 94.737]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.950000000000001, 10.9, 94.683]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.05, 11.100000000000001, 94.6765]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.950000000000001, 12.900000000000002, 94.6135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.05, 13.100000000000001, 94.606]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.950000000000001, 14.9, 94.53399999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.05, 15.1, 94.5255]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.95, 16.900000000000002, 94.44449999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.05, 17.1, 94.435]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.95, 18.900000000000002, 94.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.05, 19.1, 94.3345]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.950000000000001, 20.900000000000002, 94.2355]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.05, 21.1, 94.224]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.95, 22.9, 94.116]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.05, 23.1, 94.1035]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.95, 24.9, 93.9865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.05, 25.1, 93.97300000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.950000000000003, 26.900000000000002, 93.84700000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.05, 27.1, 93.83250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.95, 28.900000000000002, 93.69749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.05, 29.1, 93.682]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.950000000000003, 30.900000000000002, 93.53800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.05, 31.1, 93.5215]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.95, 32.9, 93.3685]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.05, 33.1, 93.351]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.95, 34.9, 93.18900000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.05, 35.1, 93.1705]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.950000000000003, 36.900000000000006, 92.9995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.05, 37.1, 92.98]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.95, 38.9, 92.80000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.05, 39.1, 92.77950000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.950000000000003, 40.9, 92.5905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.050000000000004, 41.1, 92.569]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.950000000000003, 42.900000000000006, 92.371]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.05, 43.1, 92.3485]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.95, 44.9, 92.14150000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.05, 45.1, 92.118]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.950000000000003, 46.900000000000006, 91.902]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.05, 47.10000000000001, 91.87750000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.95, 48.900000000000006, 91.6525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.05, 49.1, 91.627]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.950000000000003, 50.9, 91.393]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.050000000000004, 51.1, 91.3665]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.950000000000003, 52.900000000000006, 91.12349999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.05, 53.1, 91.09599999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.95, 54.9, 90.844]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.05, 55.1, 90.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.95, 56.900000000000006, 90.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.050000000000004, 57.10000000000001, 90.525]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.95, 58.900000000000006, 90.255]) cube([0.4, 0.4, 0.1], center=true);
}

