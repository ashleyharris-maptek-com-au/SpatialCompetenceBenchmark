
hull() {
    translate([45.0, 25.0, 45.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 25.0, 2.4000000000000004]) cube([0.4, 0.4, 0.1], center=true);
}

