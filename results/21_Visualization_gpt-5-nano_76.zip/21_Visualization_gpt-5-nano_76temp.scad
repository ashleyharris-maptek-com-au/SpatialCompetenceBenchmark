color([1, 0, 1]) hull()
{
  translate([209.8, 150.3, 249.825]) cube([0.4, 0.4, 0.1], center = true);
  translate([206.20000000000002, 155.70000000000002, 246.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([205.8, 156.3, 246.325]) cube([0.4, 0.4, 0.1], center = true);
  translate([202.20000000000002, 161.70000000000002, 243.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([201.8, 162.3, 242.82500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([198.20000000000002, 167.70000000000002, 239.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([197.70000000000002, 168.3, 239.32500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([192.3, 173.7, 236.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([191.70000000000002, 174.29999999999998, 235.82500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([186.3, 179.7, 232.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([185.70000000000002, 180.3, 232.325]) cube([0.4, 0.4, 0.1], center = true);
  translate([180.3, 185.70000000000002, 229.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([179.7, 186.3, 228.825]) cube([0.4, 0.4, 0.1], center = true);
  translate([174.29999999999998, 191.70000000000002, 225.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([173.7, 192.3, 225.32500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([168.3, 197.70000000000002, 222.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([167.70000000000002, 198.3, 221.82500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([162.3, 203.7, 218.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([161.70000000000002, 204.3, 218.32500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([156.3, 209.7, 215.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([155.70000000000002, 210.3, 214.825]) cube([0.4, 0.4, 0.1], center = true);
  translate([150.3, 215.70000000000002, 211.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([149.7, 216.3, 211.325]) cube([0.4, 0.4, 0.1], center = true);
  translate([144.29999999999998, 221.70000000000002, 208.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([143.7, 222.3, 207.82500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([138.3, 227.70000000000002, 204.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([137.7, 228.3, 204.32500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([132.3, 233.7, 201.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([131.7, 234.3, 200.82500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([126.30000000000001, 239.7, 197.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([125.7, 240.3, 197.325]) cube([0.4, 0.4, 0.1], center = true);
  translate([120.3, 245.70000000000002, 194.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([119.7, 246.3, 193.825]) cube([0.4, 0.4, 0.1], center = true);
  translate([114.30000000000001, 251.70000000000002, 190.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([113.70000000000002, 252.3, 190.32500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([108.30000000000001, 257.70000000000005, 187.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([107.7, 258.3, 186.85000000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([102.3, 263.7, 184.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([101.7, 264.3, 183.825]) cube([0.4, 0.4, 0.1], center = true);
  translate([96.30000000000001, 269.7, 180.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([95.7, 270.3, 180.32500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([90.3, 275.7, 177.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([90.0, 275.7, 176.8]) cube([0.4, 0.4, 0.1], center = true);
  translate([90.0, 270.3, 173.20000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([90.3, 269.7, 172.8]) cube([0.4, 0.4, 0.1], center = true);
  translate([95.7, 264.3, 169.2]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([96.30000000000001, 263.7, 168.825]) cube([0.4, 0.4, 0.1], center = true);
  translate([101.7, 258.3, 165.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([102.3, 257.70000000000005, 165.32500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([107.7, 252.3, 162.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([108.30000000000001, 251.70000000000002, 161.775]) cube([0.4, 0.4, 0.1], center = true);
  translate([113.70000000000002, 246.3, 157.725]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([114.30000000000001, 245.70000000000002, 157.3]) cube([0.4, 0.4, 0.1], center = true);
  translate([119.7, 240.3, 153.70000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([120.3, 239.7, 153.3]) cube([0.4, 0.4, 0.1], center = true);
  translate([125.7, 234.3, 149.70000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([126.30000000000001, 233.7, 149.32500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([131.7, 228.3, 146.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([132.3, 227.70000000000002, 145.82500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([137.7, 222.3, 142.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([138.3, 221.70000000000002, 142.325]) cube([0.4, 0.4, 0.1], center = true);
  translate([143.7, 216.3, 139.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([144.29999999999998, 215.70000000000002, 138.82500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([149.7, 210.3, 135.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([150.3, 209.7, 135.325]) cube([0.4, 0.4, 0.1], center = true);
  translate([155.70000000000002, 204.3, 132.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([156.3, 203.7, 131.825]) cube([0.4, 0.4, 0.1], center = true);
  translate([161.70000000000002, 198.3, 128.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([162.3, 197.70000000000002, 128.32500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([167.70000000000002, 192.3, 125.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([168.3, 191.70000000000002, 124.825]) cube([0.4, 0.4, 0.1], center = true);
  translate([173.7, 186.3, 121.67500000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([174.29999999999998, 185.70000000000002, 121.32500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([179.7, 180.3, 118.17500000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([180.3, 179.7, 117.825]) cube([0.4, 0.4, 0.1], center = true);
  translate([185.70000000000002, 174.29999999999998, 114.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([186.3, 173.7, 114.325]) cube([0.4, 0.4, 0.1], center = true);
  translate([191.70000000000002, 168.3, 111.17500000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([192.3, 167.70000000000002, 110.825]) cube([0.4, 0.4, 0.1], center = true);
  translate([197.70000000000002, 162.3, 107.675]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([198.20000000000002, 161.70000000000002, 107.325]) cube([0.4, 0.4, 0.1], center = true);
  translate([201.8, 156.3, 104.17500000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([202.20000000000002, 155.70000000000002, 103.82500000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([205.8, 150.3, 100.67500000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([206.20000000000002, 149.7, 100.325]) cube([0.4, 0.4, 0.1], center = true);
  translate([209.8, 144.29999999999998, 97.175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 144.29999999999998, 96.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 149.7, 94.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 93.85000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 91.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 90.85000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 88.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 87.85000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 85.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 84.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 82.14999999999999]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 81.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 79.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 78.85000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 76.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 75.85000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 73.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 72.85000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 70.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 69.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 67.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 66.85000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 64.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 63.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 61.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 60.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 58.150000000000006]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 57.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 55.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 54.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 52.150000000000006]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 51.85000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 49.150000000000006]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 48.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 46.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 45.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 43.150000000000006]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 42.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 40.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 39.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 37.150000000000006]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 36.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 34.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 33.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 31.150000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 30.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 28.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 27.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 25.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 24.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 22.150000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 21.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 19.150000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 18.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 16.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 15.850000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 13.150000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 12.850000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 10.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 9.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 7.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 6.85]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 4.15]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([210.0, 150.0, 3.8000000000000003]) cube([0.4, 0.4, 0.1], center = true);
  translate([210.0, 150.0, 0.2]) cube([0.4, 0.4, 0.1], center = true);
}
