
hull() {
    translate([10.04, 10.0, 18.955000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.760000000000002, 10.0, 18.145000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.84, 10.0, 18.055000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.559999999999999, 10.0, 17.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.64, 10.0, 17.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.36, 10.0, 16.345000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.440000000000001, 10.0, 16.255000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.16, 10.0, 15.445000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.239999999999998, 10.0, 15.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.959999999999999, 10.0, 14.545000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.04, 10.0, 14.455000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.76, 10.0, 13.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.84, 10.0, 13.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.559999999999999, 10.0, 12.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.639999999999999, 10.0, 12.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.36, 10.0, 11.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.439999999999998, 10.0, 11.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.16, 10.0, 10.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.240000000000002, 10.0, 10.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.96, 10.0, 10.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.0, 10.045, 9.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.0, 10.855, 9.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.0, 10.945, 9.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.0, 11.755, 8.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.0, 11.845, 8.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.0, 12.655, 7.345000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.0, 12.745, 7.255000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.0, 13.555, 6.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.0, 13.645, 6.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.0, 14.455000000000002, 5.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.0, 14.545000000000002, 5.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.0, 15.355, 4.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.0, 15.445000000000002, 4.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.0, 16.255000000000003, 3.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.0, 16.345000000000002, 3.6550000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.0, 17.155, 2.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.0, 17.245, 2.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.0, 18.055000000000003, 1.9449999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.0, 18.145000000000003, 1.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.0, 18.955000000000002, 1.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.955, 19.0, 0.9500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.145000000000003, 19.0, 0.05]) cube([0.4, 0.4, 0.1], center=true);
}

