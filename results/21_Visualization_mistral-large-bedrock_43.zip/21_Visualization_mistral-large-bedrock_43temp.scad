
hull() {
    translate([0.045000000000000005, 0.0, 5.045]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.8550000000000001, 0.0, 5.855]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9450000000000001, 0.0, 5.945]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7550000000000001, 0.0, 6.755]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8450000000000002, 0.0, 6.845000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6550000000000002, 0.0, 7.655000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.745, 0.0, 7.745000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.555, 0.0, 8.555]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6450000000000005, 0.0, 8.645]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.455, 0.0, 9.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.545, 0.0, 9.525]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.355, 0.0, 9.975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.445, 0.0, 10.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.255, 0.0, 10.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.345, 0.0, 10.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.155, 0.0, 10.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.245000000000001, 0.0, 10.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.055, 0.0, 10.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.145, 0.0, 10.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.955, 0.0, 10.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 0.045000000000000005, 10.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 0.8550000000000001, 10.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 0.9450000000000001, 9.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 1.7550000000000001, 9.049999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 1.8450000000000002, 8.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 2.6550000000000002, 8.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 2.745, 7.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 3.555, 7.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 3.6450000000000005, 6.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 4.455, 6.050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 4.545, 5.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 5.355, 5.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 5.445, 4.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 6.255, 4.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 6.345, 3.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 7.155, 3.0500000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 7.245000000000001, 2.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 8.055, 2.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 8.145, 1.9500000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 8.955, 1.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 9.045, 0.9500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 9.855, 0.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.955, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.145, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.055, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.245000000000001, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.155, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.345, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.255, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.445, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.355, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.545, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.455, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6450000000000005, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.555, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.745, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.6550000000000002, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8450000000000002, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.7550000000000001, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9450000000000001, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.8550000000000001, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.045000000000000005, 9.9, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 9.855, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 9.045, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 8.955, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 8.145, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 8.055, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 7.245000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 7.155, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 6.345, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 6.255, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 5.445, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 5.355, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 4.545, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 4.455, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.6450000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.555, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.745, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.6550000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 1.8450000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 1.7550000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.9450000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 0.8550000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.045000000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}

