
translate([0, 0, 0]) cube([1, 1, 5.029999999999999]);

translate([1, 0, 0]) cube([1, 1, 4.413982422641002]);

translate([2, 0, 0]) cube([1, 1, 4.436775061908758]);

translate([3, 0, 0]) cube([1, 1, 4.452139510727103]);

translate([4, 0, 0]) cube([1, 1, 4.469999999999994]);

translate([5, 0, 0]) cube([1, 1, 4.529999999999999]);

translate([6, 0, 0]) cube([1, 1, 4.289999999999998]);

translate([7, 0, 0]) cube([1, 1, 4.449999999999999]);

translate([8, 0, 0]) cube([1, 1, 5.01]);

translate([9, 0, 0]) cube([1, 1, 5.3]);

translate([10, 0, 0]) cube([1, 1, 5.4]);

translate([11, 0, 0]) cube([1, 1, 4.9]);

translate([12, 0, 0]) cube([1, 1, 4.4]);

translate([13, 0, 0]) cube([1, 1, 4.3]);

translate([14, 0, 0]) cube([1, 1, 4.4]);

translate([15, 0, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 3.60011977277188]);

translate([2, 1, 0]) cube([1, 1, 4.869999999999998]);

translate([3, 1, 0]) cube([1, 1, 4.529999999999998]);

translate([4, 1, 0]) cube([1, 1, 4.489999999999996]);

translate([5, 1, 0]) cube([1, 1, 4.252379518290696]);

translate([6, 1, 0]) cube([1, 1, 4.264528756523902]);

translate([7, 1, 0]) cube([1, 1, 4.253730325815247]);

translate([8, 1, 0]) cube([1, 1, 4.289999999999998]);

translate([9, 1, 0]) cube([1, 1, 3.008221196067805]);

translate([10, 1, 0]) cube([1, 1, 4.43]);

translate([11, 1, 0]) cube([1, 1, 4.22]);

translate([12, 1, 0]) cube([1, 1, 4.02]);

translate([13, 1, 0]) cube([1, 1, 3.06355228903699]);

translate([14, 1, 0]) cube([1, 1, 3.857960286733994]);

translate([15, 1, 0]) cube([1, 1, 3.9299999999999993]);

translate([0, 2, 0]) cube([1, 1, 7.2]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.469999999999999]);

translate([4, 2, 0]) cube([1, 1, 5.079999999999998]);

translate([5, 2, 0]) cube([1, 1, 4.539999999999997]);

translate([6, 2, 0]) cube([1, 1, 4.659999999999998]);

translate([7, 2, 0]) cube([1, 1, 4.8599999999999985]);

translate([8, 2, 0]) cube([1, 1, 4.749999999999999]);

translate([9, 2, 0]) cube([1, 1, 4.4399999999999995]);

translate([10, 2, 0]) cube([1, 1, 4.039999999999999]);

translate([11, 2, 0]) cube([1, 1, 3.8699999999999943]);

translate([12, 2, 0]) cube([1, 1, 3.855913015571145]);

translate([13, 2, 0]) cube([1, 1, 3.858419411847375]);

translate([14, 2, 0]) cube([1, 1, 3.85922890994363]);

translate([15, 2, 0]) cube([1, 1, 3.8588969813347385]);

translate([0, 3, 0]) cube([1, 1, 7.7]);

translate([1, 3, 0]) cube([1, 1, 7.02]);

translate([2, 3, 0]) cube([1, 1, 6.549999999999999]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.169999999999998]);

color([0,1,0])
translate([6, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 3, 0]) cube([1, 1, 6]);

translate([8, 3, 0]) cube([1, 1, 5.319999999999999]);

translate([9, 3, 0]) cube([1, 1, 4.559999999999999]);

translate([10, 3, 0]) cube([1, 1, 3.899999999999996]);

translate([11, 3, 0]) cube([1, 1, 3.89964285714285]);

translate([12, 3, 0]) cube([1, 1, 3.889999999999994]);

translate([13, 3, 0]) cube([1, 1, 3.9199999999999973]);

translate([14, 3, 0]) cube([1, 1, 3.9199999999999973]);

translate([15, 3, 0]) cube([1, 1, 3.9199999999999973]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.31]);

translate([2, 4, 0]) cube([1, 1, 6.849999999999999]);

translate([3, 4, 0]) cube([1, 1, 6.549999999999999]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 4, 0]) cube([1, 1, 6]);

translate([8, 4, 0]) cube([1, 1, 5.43]);

translate([9, 4, 0]) cube([1, 1, 4.769999999999999]);

translate([10, 4, 0]) cube([1, 1, 4.219999999999997]);

translate([11, 4, 0]) cube([1, 1, 4.269999999999999]);

translate([12, 4, 0]) cube([1, 1, 4.639999999999999]);

translate([13, 4, 0]) cube([1, 1, 4.639999999999999]);

translate([14, 4, 0]) cube([1, 1, 4.629999999999999]);

translate([15, 4, 0]) cube([1, 1, 4.529999999999999]);

translate([0, 5, 0]) cube([1, 1, 8.0]);

translate([1, 5, 0]) cube([1, 1, 5.68617012017882]);

translate([2, 5, 0]) cube([1, 1, 6.649999999999999]);

translate([3, 5, 0]) cube([1, 1, 6.839999999999999]);

translate([4, 5, 0]) cube([1, 1, 6.7299999999999995]);

translate([5, 5, 0]) cube([1, 1, 4.626767327611772]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 5, 0]) cube([1, 1, 6]);

translate([9, 5, 0]) cube([1, 1, 3.819706517404651]);

translate([10, 5, 0]) cube([1, 1, 4.789999999999998]);

translate([11, 5, 0]) cube([1, 1, 5.119999999999999]);

color([0,1,0])
translate([12, 5, 0]) cube([1, 1, 6]);

translate([13, 5, 0]) cube([1, 1, 3.8778747192205296]);

translate([14, 5, 0]) cube([1, 1, 5.119999999999999]);

translate([15, 5, 0]) cube([1, 1, 5.31]);

translate([0, 6, 0]) cube([1, 1, 8.2]);

translate([1, 6, 0]) cube([1, 1, 7.329999999999999]);

translate([2, 6, 0]) cube([1, 1, 7.319999999999999]);

translate([3, 6, 0]) cube([1, 1, 7.51]);

translate([4, 6, 0]) cube([1, 1, 6.92]);

translate([5, 6, 0]) cube([1, 1, 6.619999999999999]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.159999999999998]);

translate([10, 6, 0]) cube([1, 1, 4.959999999999999]);

translate([11, 6, 0]) cube([1, 1, 5.329999999999999]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.7]);

translate([2, 7, 0]) cube([1, 1, 7.609999999999999]);

translate([3, 7, 0]) cube([1, 1, 7.41]);

translate([4, 7, 0]) cube([1, 1, 7.01]);

translate([5, 7, 0]) cube([1, 1, 7.0]);

translate([6, 7, 0]) cube([1, 1, 6.609999999999999]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

translate([14, 7, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 7.7]);

translate([1, 8, 0]) cube([1, 1, 7.3]);

translate([2, 8, 0]) cube([1, 1, 7.01]);

translate([3, 8, 0]) cube([1, 1, 6.52]);

translate([4, 8, 0]) cube([1, 1, 6.6]);

translate([5, 8, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([6, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

translate([14, 8, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 6.81]);

translate([1, 9, 0]) cube([1, 1, 5.271461534770071]);

color([0,1,0])
translate([2, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 9, 0]) cube([1, 1, 6]);

translate([5, 9, 0]) cube([1, 1, 5.087476114859972]);

translate([6, 9, 0]) cube([1, 1, 6.6]);

translate([7, 9, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

translate([9, 9, 0]) cube([1, 1, 4.926632954484374]);

translate([10, 9, 0]) cube([1, 1, 5.480906762662107]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

translate([13, 9, 0]) cube([1, 1, 4.560699835079198]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 10, 0]) cube([1, 1, 6]);

translate([7, 10, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([1, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([8, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

translate([15, 11, 0]) cube([1, 1, 5.409999999999996]);

translate([0, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 12, 0]) cube([1, 1, 6]);

translate([6, 12, 0]) cube([1, 1, 7.0]);

translate([7, 12, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([8, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

translate([14, 12, 0]) cube([1, 1, 5.459999999999996]);

translate([15, 12, 0]) cube([1, 1, 5.378082728815374]);

color([0,1,0])
translate([0, 13, 0]) cube([1, 1, 6]);

translate([1, 13, 0]) cube([1, 1, 4.9242191247436695]);

color([0,1,0])
translate([2, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

translate([5, 13, 0]) cube([1, 1, 5.091674460022477]);

translate([6, 13, 0]) cube([1, 1, 7.0]);

translate([7, 13, 0]) cube([1, 1, 6.609999999999999]);

color([0,1,0])
translate([8, 13, 0]) cube([1, 1, 6]);

translate([9, 13, 0]) cube([1, 1, 4.723743313165906]);

translate([10, 13, 0]) cube([1, 1, 6.51]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

translate([13, 13, 0]) cube([1, 1, 4.100489821644156]);

translate([14, 13, 0]) cube([1, 1, 5.499999999999998]);

translate([15, 13, 0]) cube([1, 1, 5.379993023446913]);

color([0,1,0])
translate([0, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

translate([5, 14, 0]) cube([1, 1, 6.52]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

translate([11, 15, 0]) cube([1, 1, 5.341713009050297]);

translate([12, 15, 0]) cube([1, 1, 5.4]);

translate([13, 15, 0]) cube([1, 1, 5.36699035450906]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);
