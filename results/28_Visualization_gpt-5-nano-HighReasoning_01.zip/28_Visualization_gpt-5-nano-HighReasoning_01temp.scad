
translate([0, 0, 0]) cube([1, 1, 5.133333333333334]);

translate([1, 0, 0]) cube([1, 1, 4.502048811971852]);

translate([2, 0, 0]) cube([1, 1, 4.539487703311305]);

translate([3, 0, 0]) cube([1, 1, 4.408559048653275]);

translate([4, 0, 0]) cube([1, 1, 4.392254956097197]);

translate([5, 0, 0]) cube([1, 1, 4.518518518518518]);

translate([6, 0, 0]) cube([1, 1, 4.24212962962963]);

translate([7, 0, 0]) cube([1, 1, 4.438888888888889]);

translate([8, 0, 0]) cube([1, 1, 5.0]);

translate([9, 0, 0]) cube([1, 1, 5.3]);

translate([10, 0, 0]) cube([1, 1, 5.4]);

translate([11, 0, 0]) cube([1, 1, 4.914285714285715]);

translate([12, 0, 0]) cube([1, 1, 4.402857142857143]);

translate([13, 0, 0]) cube([1, 1, 4.300714285714285]);

translate([14, 0, 0]) cube([1, 1, 4.4]);

translate([15, 0, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 3.4973409478245743]);

translate([2, 1, 0]) cube([1, 1, 4.912049214787365]);

translate([3, 1, 0]) cube([1, 1, 4.501784117719587]);

translate([4, 1, 0]) cube([1, 1, 4.409105360705113]);

translate([5, 1, 0]) cube([1, 1, 3.792268881687333]);

translate([6, 1, 0]) cube([1, 1, 4.187665193343343]);

translate([7, 1, 0]) cube([1, 1, 4.229617759348083]);

translate([8, 1, 0]) cube([1, 1, 4.339115929353179]);

translate([9, 1, 0]) cube([1, 1, 3.252226765552881]);

translate([10, 1, 0]) cube([1, 1, 4.491068511768653]);

translate([11, 1, 0]) cube([1, 1, 4.235927987935902]);

translate([12, 1, 0]) cube([1, 1, 4.021868136974826]);

translate([13, 1, 0]) cube([1, 1, 2.9709519592924947]);

translate([14, 1, 0]) cube([1, 1, 3.753736295400912]);

translate([15, 1, 0]) cube([1, 1, 3.9347222222222222]);

translate([0, 2, 0]) cube([1, 1, 7.2]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.429836420088832]);

translate([4, 2, 0]) cube([1, 1, 5.041460845476986]);

translate([5, 2, 0]) cube([1, 1, 4.498139442642445]);

translate([6, 2, 0]) cube([1, 1, 4.657732215950351]);

translate([7, 2, 0]) cube([1, 1, 4.83043168784239]);

translate([8, 2, 0]) cube([1, 1, 4.722738799849053]);

translate([9, 2, 0]) cube([1, 1, 4.437975998970399]);

translate([10, 2, 0]) cube([1, 1, 4.112479329195884]);

translate([11, 2, 0]) cube([1, 1, 3.782071860941224]);

translate([12, 2, 0]) cube([1, 1, 3.7683011204567247]);

translate([13, 2, 0]) cube([1, 1, 3.760861484726865]);

translate([14, 2, 0]) cube([1, 1, 3.760356853255917]);

translate([15, 2, 0]) cube([1, 1, 3.7821805172795524]);

translate([0, 3, 0]) cube([1, 1, 7.7]);

translate([1, 3, 0]) cube([1, 1, 7.017283950617284]);

translate([2, 3, 0]) cube([1, 1, 6.533356942974721]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.183107962623064]);

color([0,1,0])
translate([6, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 3, 0]) cube([1, 1, 6]);

translate([8, 3, 0]) cube([1, 1, 5.307468698528364]);

translate([9, 3, 0]) cube([1, 1, 4.532973376911315]);

translate([10, 3, 0]) cube([1, 1, 3.8714917739084083]);

translate([11, 3, 0]) cube([1, 1, 3.789725529708457]);

translate([12, 3, 0]) cube([1, 1, 3.7962829547878303]);

translate([13, 3, 0]) cube([1, 1, 3.876078623358708]);

translate([14, 3, 0]) cube([1, 1, 3.8796165771187305]);

translate([15, 3, 0]) cube([1, 1, 3.870779915413849]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.312345679012346]);

translate([2, 4, 0]) cube([1, 1, 6.901587301587302]);

translate([3, 4, 0]) cube([1, 1, 6.565996942974721]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 4, 0]) cube([1, 1, 6]);

translate([8, 4, 0]) cube([1, 1, 5.414856167641127]);

translate([9, 4, 0]) cube([1, 1, 4.797694375932048]);

translate([10, 4, 0]) cube([1, 1, 4.260514613337148]);

translate([11, 4, 0]) cube([1, 1, 4.27283762945776]);

translate([12, 4, 0]) cube([1, 1, 4.674239691677925]);

translate([13, 4, 0]) cube([1, 1, 4.689553494527845]);

translate([14, 4, 0]) cube([1, 1, 4.682679882361777]);

translate([15, 4, 0]) cube([1, 1, 4.556493724613932]);

translate([0, 5, 0]) cube([1, 1, 8.0]);

translate([1, 5, 0]) cube([1, 1, 6.06401646090535]);

translate([2, 5, 0]) cube([1, 1, 6.783416813639036]);

translate([3, 5, 0]) cube([1, 1, 6.836317460317461]);

translate([4, 5, 0]) cube([1, 1, 6.7128018812463255]);

translate([5, 5, 0]) cube([1, 1, 4.924082209466862]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 5, 0]) cube([1, 1, 6]);

translate([9, 5, 0]) cube([1, 1, 3.847599447611173]);

translate([10, 5, 0]) cube([1, 1, 4.82567577577457]);

translate([11, 5, 0]) cube([1, 1, 5.125124502666914]);

color([0,1,0])
translate([12, 5, 0]) cube([1, 1, 6]);

translate([13, 5, 0]) cube([1, 1, 4.112722664632354]);

translate([14, 5, 0]) cube([1, 1, 5.170134626690181]);

translate([15, 5, 0]) cube([1, 1, 5.316666666666666]);

translate([0, 6, 0]) cube([1, 1, 8.2]);

translate([1, 6, 0]) cube([1, 1, 7.3]);

translate([2, 6, 0]) cube([1, 1, 7.3]);

translate([3, 6, 0]) cube([1, 1, 7.5]);

translate([4, 6, 0]) cube([1, 1, 6.905925925925926]);

translate([5, 6, 0]) cube([1, 1, 6.603745561434449]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.153063590680589]);

translate([10, 6, 0]) cube([1, 1, 5.050805922131102]);

translate([11, 6, 0]) cube([1, 1, 5.331298840718162]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.7]);

translate([2, 7, 0]) cube([1, 1, 7.6]);

translate([3, 7, 0]) cube([1, 1, 7.4]);

translate([4, 7, 0]) cube([1, 1, 7.0]);

translate([5, 7, 0]) cube([1, 1, 7.0]);

translate([6, 7, 0]) cube([1, 1, 6.600624260239075]);

translate([7, 7, 0]) cube([1, 1, 6.5001280697575385]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

translate([14, 7, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 7.7]);

translate([1, 8, 0]) cube([1, 1, 7.3]);

translate([2, 8, 0]) cube([1, 1, 7.0]);

translate([3, 8, 0]) cube([1, 1, 6.520833333333334]);

translate([4, 8, 0]) cube([1, 1, 6.6]);

translate([5, 8, 0]) cube([1, 1, 6.8]);

translate([6, 8, 0]) cube([1, 1, 6.500224211401381]);

translate([7, 8, 0]) cube([1, 1, 6.500163984842307]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

translate([14, 8, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 6.8]);

translate([1, 9, 0]) cube([1, 1, 5.427460317460317]);

color([0,1,0])
translate([2, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 9, 0]) cube([1, 1, 6]);

translate([5, 9, 0]) cube([1, 1, 5.110420600718788]);

translate([6, 9, 0]) cube([1, 1, 6.6]);

translate([7, 9, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

translate([9, 9, 0]) cube([1, 1, 4.690594697539859]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

translate([13, 9, 0]) cube([1, 1, 4.801067137953586]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 10, 0]) cube([1, 1, 6]);

translate([7, 10, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([1, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([8, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

translate([15, 11, 0]) cube([1, 1, 5.345443637810827]);

translate([0, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 12, 0]) cube([1, 1, 6]);

translate([6, 12, 0]) cube([1, 1, 7.0]);

translate([7, 12, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([8, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

translate([14, 12, 0]) cube([1, 1, 5.438743879366763]);

translate([15, 12, 0]) cube([1, 1, 5.25311580136288]);

color([0,1,0])
translate([0, 13, 0]) cube([1, 1, 6]);

translate([1, 13, 0]) cube([1, 1, 4.979516870256958]);

color([0,1,0])
translate([2, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

translate([5, 13, 0]) cube([1, 1, 5.285030892317243]);

translate([6, 13, 0]) cube([1, 1, 7.0]);

translate([7, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 13, 0]) cube([1, 1, 6]);

translate([9, 13, 0]) cube([1, 1, 4.886984445583618]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

translate([13, 13, 0]) cube([1, 1, 4.381817534297239]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

translate([15, 13, 0]) cube([1, 1, 5.264416536382643]);

color([0,1,0])
translate([0, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

translate([5, 14, 0]) cube([1, 1, 6.544784580498866]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 15, 0]) cube([1, 1, 6]);

translate([2, 15, 0]) cube([1, 1, 5.489002958714371]);

translate([3, 15, 0]) cube([1, 1, 5.491479833887295]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

translate([6, 15, 0]) cube([1, 1, 5.489821236127156]);

color([0,1,0])
translate([7, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

translate([11, 15, 0]) cube([1, 1, 5.32422055287374]);

translate([12, 15, 0]) cube([1, 1, 5.4088824380643254]);

translate([13, 15, 0]) cube([1, 1, 5.3728185068237195]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);
