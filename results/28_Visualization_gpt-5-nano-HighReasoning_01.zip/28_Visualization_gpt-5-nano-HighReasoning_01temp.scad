
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.389452026966845]);

translate([2, 0, 0]) cube([1, 1, 4.3995975670083425]);

translate([3, 0, 0]) cube([1, 1, 4.397724071870864]);

translate([4, 0, 0]) cube([1, 1, 4.397729871809402]);

translate([5, 0, 0]) cube([1, 1, 4.5]);

translate([6, 0, 0]) cube([1, 1, 4.3983059928162715]);

translate([7, 0, 0]) cube([1, 1, 4.410317241902663]);

translate([8, 0, 0]) cube([1, 1, 5.0]);

translate([9, 0, 0]) cube([1, 1, 5.3]);

translate([10, 0, 0]) cube([1, 1, 5.4]);

translate([11, 0, 0]) cube([1, 1, 4.9]);

translate([12, 0, 0]) cube([1, 1, 4.4]);

translate([13, 0, 0]) cube([1, 1, 4.3]);

translate([14, 0, 0]) cube([1, 1, 4.4]);

translate([15, 0, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 4.389740349372458]);

translate([2, 1, 0]) cube([1, 1, 4.8]);

translate([3, 1, 0]) cube([1, 1, 4.4]);

translate([4, 1, 0]) cube([1, 1, 4.3980657179289695]);

translate([5, 1, 0]) cube([1, 1, 3.7505411987431767]);

translate([6, 1, 0]) cube([1, 1, 4.409582071279254]);

translate([7, 1, 0]) cube([1, 1, 4.39834199587566]);

translate([8, 1, 0]) cube([1, 1, 4.387399081484598]);

translate([9, 1, 0]) cube([1, 1, 3.9092475012158667]);

translate([10, 1, 0]) cube([1, 1, 4.4]);

translate([11, 1, 0]) cube([1, 1, 4.2]);

translate([12, 1, 0]) cube([1, 1, 4.0]);

translate([13, 1, 0]) cube([1, 1, 3.8500022675424974]);

translate([14, 1, 0]) cube([1, 1, 3.9096020823850712]);

translate([15, 1, 0]) cube([1, 1, 3.9832166866045444]);

translate([0, 2, 0]) cube([1, 1, 7.2]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.4]);

translate([4, 2, 0]) cube([1, 1, 5.0]);

translate([5, 2, 0]) cube([1, 1, 4.410317241902663]);

translate([6, 2, 0]) cube([1, 1, 4.6]);

translate([7, 2, 0]) cube([1, 1, 4.8]);

translate([8, 2, 0]) cube([1, 1, 4.7]);

translate([9, 2, 0]) cube([1, 1, 4.4]);

translate([10, 2, 0]) cube([1, 1, 4.0]);

translate([11, 2, 0]) cube([1, 1, 3.9302487293628645]);

translate([12, 2, 0]) cube([1, 1, 3.930493986397484]);

translate([13, 2, 0]) cube([1, 1, 3.945524957612608]);

translate([14, 2, 0]) cube([1, 1, 3.9537687365360705]);

translate([15, 2, 0]) cube([1, 1, 3.9804856202389067]);

translate([0, 3, 0]) cube([1, 1, 7.7]);

translate([1, 3, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.1]);

color([0,1,0])
translate([6, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 3, 0]) cube([1, 1, 6]);

translate([8, 3, 0]) cube([1, 1, 5.3]);

translate([9, 3, 0]) cube([1, 1, 4.5]);

translate([10, 3, 0]) cube([1, 1, 3.922942503121313]);

translate([11, 3, 0]) cube([1, 1, 3.9283168854854065]);

translate([12, 3, 0]) cube([1, 1, 3.928658088429828]);

translate([13, 3, 0]) cube([1, 1, 3.937399129419913]);

translate([14, 3, 0]) cube([1, 1, 3.925330678967165]);

translate([15, 3, 0]) cube([1, 1, 3.897520166736902]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.3]);

translate([2, 4, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 4, 0]) cube([1, 1, 6]);

translate([8, 4, 0]) cube([1, 1, 5.4]);

translate([9, 4, 0]) cube([1, 1, 4.7]);

translate([10, 4, 0]) cube([1, 1, 4.1]);

translate([11, 4, 0]) cube([1, 1, 4.2]);

translate([12, 4, 0]) cube([1, 1, 4.6]);

translate([13, 4, 0]) cube([1, 1, 4.6]);

translate([14, 4, 0]) cube([1, 1, 4.6]);

translate([15, 4, 0]) cube([1, 1, 4.5]);

translate([0, 5, 0]) cube([1, 1, 8.0]);

translate([1, 5, 0]) cube([1, 1, 5.768134706201646]);

translate([2, 5, 0]) cube([1, 1, 6.6]);

translate([3, 5, 0]) cube([1, 1, 6.8]);

translate([4, 5, 0]) cube([1, 1, 6.7]);

translate([5, 5, 0]) cube([1, 1, 4.665581569396824]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 5, 0]) cube([1, 1, 6]);

translate([9, 5, 0]) cube([1, 1, 3.9842892527851475]);

translate([10, 5, 0]) cube([1, 1, 4.7]);

translate([11, 5, 0]) cube([1, 1, 5.1]);

color([0,1,0])
translate([12, 5, 0]) cube([1, 1, 6]);

translate([13, 5, 0]) cube([1, 1, 3.9030071692837582]);

translate([14, 5, 0]) cube([1, 1, 5.1]);

translate([15, 5, 0]) cube([1, 1, 5.3]);

translate([0, 6, 0]) cube([1, 1, 8.2]);

translate([1, 6, 0]) cube([1, 1, 7.3]);

translate([2, 6, 0]) cube([1, 1, 7.3]);

translate([3, 6, 0]) cube([1, 1, 7.5]);

translate([4, 6, 0]) cube([1, 1, 6.9]);

translate([5, 6, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.1]);

translate([10, 6, 0]) cube([1, 1, 4.9]);

translate([11, 6, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.7]);

translate([2, 7, 0]) cube([1, 1, 7.6]);

translate([3, 7, 0]) cube([1, 1, 7.4]);

translate([4, 7, 0]) cube([1, 1, 7.0]);

translate([5, 7, 0]) cube([1, 1, 7.0]);

translate([6, 7, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

translate([14, 7, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 7.7]);

translate([1, 8, 0]) cube([1, 1, 7.3]);

translate([2, 8, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([3, 8, 0]) cube([1, 1, 6]);

translate([4, 8, 0]) cube([1, 1, 6.6]);

translate([5, 8, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([6, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

translate([14, 8, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([1, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 9, 0]) cube([1, 1, 6]);

translate([6, 9, 0]) cube([1, 1, 6.6]);

translate([7, 9, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

translate([9, 9, 0]) cube([1, 1, 5.499685809187642]);

translate([10, 9, 0]) cube([1, 1, 5.499841091260828]);

translate([11, 9, 0]) cube([1, 1, 5.491166629127059]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

translate([13, 9, 0]) cube([1, 1, 4.805896717347957]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 10, 0]) cube([1, 1, 6]);

translate([7, 10, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

translate([11, 10, 0]) cube([1, 1, 5.488480797472714]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([1, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([8, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

translate([12, 11, 0]) cube([1, 1, 5.491341703337885]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

translate([15, 11, 0]) cube([1, 1, 5.417002136199678]);

translate([0, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 12, 0]) cube([1, 1, 6]);

translate([6, 12, 0]) cube([1, 1, 7.0]);

translate([7, 12, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([8, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

translate([14, 12, 0]) cube([1, 1, 5.427578945316584]);

translate([15, 12, 0]) cube([1, 1, 5.42616312427584]);

color([0,1,0])
translate([0, 13, 0]) cube([1, 1, 6]);

translate([1, 13, 0]) cube([1, 1, 5.186908647190781]);

color([0,1,0])
translate([2, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

translate([5, 13, 0]) cube([1, 1, 5.171311152461831]);

translate([6, 13, 0]) cube([1, 1, 7.0]);

translate([7, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 13, 0]) cube([1, 1, 6]);

translate([9, 13, 0]) cube([1, 1, 4.861582012614983]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

translate([13, 13, 0]) cube([1, 1, 4.621576862010711]);

translate([14, 13, 0]) cube([1, 1, 5.443741352679975]);

translate([15, 13, 0]) cube([1, 1, 5.457771425229886]);

color([0,1,0])
translate([0, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

translate([11, 15, 0]) cube([1, 1, 5.41617563430789]);

translate([12, 15, 0]) cube([1, 1, 5.481306257138504]);

translate([13, 15, 0]) cube([1, 1, 5.455558866990349]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);
