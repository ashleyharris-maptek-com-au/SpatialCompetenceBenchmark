color([1, 0, 1]) hull()
{
  translate([0.05, 0.0, 4.995]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.9500000000000001, 0.0, 4.905]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([1.05, 0.0, 4.8950000000000005]) cube([0.4, 0.4, 0.1], center = true);
  translate([1.9500000000000002, 0.0, 4.805000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([2.05, 0.0, 4.795]) cube([0.4, 0.4, 0.1], center = true);
  translate([2.95, 0.0, 4.705]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([3.0500000000000003, 0.0, 4.695]) cube([0.4, 0.4, 0.1], center = true);
  translate([3.95, 0.0, 4.6049999999999995]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.05, 0.0, 4.595]) cube([0.4, 0.4, 0.1], center = true);
  translate([4.95, 0.0, 4.505]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.05, 0.0, 4.495]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.95, 0.0, 4.405]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([6.050000000000001, 0.0, 4.3950000000000005]) cube([0.4, 0.4, 0.1], center = true);
  translate([6.95, 0.0, 4.305]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.05, 0.0, 4.295]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.95, 0.0, 4.205]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.05, 0.0, 4.195]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.95, 0.0, 4.105]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([9.049999999999999, 0.0, 4.095]) cube([0.4, 0.4, 0.1], center = true);
  translate([9.95, 0.0, 4.005]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 0.05, 3.995]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 0.9500000000000001, 3.905]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 1.05, 3.8949999999999996]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 1.9500000000000002, 3.8049999999999997]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 2.05, 3.795]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 2.95, 3.705]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 3.0500000000000003, 3.6950000000000003]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 3.95, 3.6050000000000004]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 4.05, 3.595]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 4.95, 3.505]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 5.05, 3.495]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 5.95, 3.4050000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 6.050000000000001, 3.395]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 6.95, 3.3049999999999997]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 7.05, 3.295]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 7.95, 3.2050000000000005]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 8.05, 3.1950000000000003]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 8.95, 3.105]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 9.049999999999999, 3.095]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 9.95, 3.0050000000000003]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([9.95, 10.0, 2.995]) cube([0.4, 0.4, 0.1], center = true);
  translate([9.049999999999999, 10.0, 2.905]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.95, 10.0, 2.895]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.05, 10.0, 2.805]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.95, 10.0, 2.795]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.05, 10.0, 2.705]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([6.95, 10.0, 2.6950000000000003]) cube([0.4, 0.4, 0.1], center = true);
  translate([6.050000000000001, 10.0, 2.6050000000000004]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.95, 10.0, 2.595]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.05, 10.0, 2.505]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.95, 10.0, 2.495]) cube([0.4, 0.4, 0.1], center = true);
  translate([4.05, 10.0, 2.4050000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([3.95, 10.0, 2.395]) cube([0.4, 0.4, 0.1], center = true);
  translate([3.0500000000000003, 10.0, 2.3049999999999997]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([2.95, 10.0, 2.295]) cube([0.4, 0.4, 0.1], center = true);
  translate([2.05, 10.0, 2.205]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([1.9500000000000002, 10.0, 2.1950000000000003]) cube([0.4, 0.4, 0.1], center = true);
  translate([1.05, 10.0, 2.105]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.9500000000000001, 10.0, 2.095]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.05, 10.0, 2.005]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 9.95, 1.995]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 9.049999999999999, 1.905]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 8.95, 1.895]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 8.05, 1.8050000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 7.95, 1.7950000000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 7.05, 1.705]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 6.95, 1.695]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 6.050000000000001, 1.6050000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 5.95, 1.5950000000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 5.05, 1.5050000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 4.95, 1.495]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 4.05, 1.405]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 3.95, 1.395]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 3.0500000000000003, 1.3050000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 2.95, 1.2950000000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 2.05, 1.205]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 1.9500000000000002, 1.195]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 1.05, 1.105]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 0.9500000000000001, 1.0950000000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 0.05, 1.0050000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 0.0, 0.995]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 0.0, 0.905]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 0.0, 0.895]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 0.0, 0.8050000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 0.0, 0.7950000000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 0.0, 0.7050000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 0.0, 0.695]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 0.0, 0.605]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 0.0, 0.5950000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 0.0, 0.505]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 0.0, 0.495]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 0.0, 0.405]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 0.0, 0.395]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 0.0, 0.305]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 0.0, 0.29500000000000004]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 0.0, 0.20500000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 0.0, 0.19500000000000003]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 0.0, 0.10500000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 0.0, 0.09500000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 0.0, 0.005000000000000001]) cube([0.4, 0.4, 0.1], center = true);
}
