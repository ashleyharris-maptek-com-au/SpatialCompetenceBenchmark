
hull() {
    translate([39.9965, 25.071, 47.993500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.933499999999995, 26.349000000000004, 47.8765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.919999999999995, 26.490500000000004, 47.8635]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.739999999999995, 27.759500000000003, 47.7465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.713499999999996, 27.898500000000002, 47.7335]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.4165, 29.131500000000003, 47.6165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.377, 29.266000000000002, 47.603500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.963, 30.454, 47.4865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.911, 30.5835, 47.4735]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.389, 31.7265, 47.356500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.325, 31.8495, 47.3435]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.695, 32.9205, 47.226499999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.619499999999995, 33.0355, 47.213499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.890499999999996, 34.0345, 47.096500000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.804, 34.141000000000005, 47.08350000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.976000000000006, 35.059, 46.9665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.879000000000005, 35.156, 46.953500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.961, 35.984, 46.8365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.854, 36.071, 46.823499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.846000000000004, 36.809, 46.7065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.730000000000004, 36.8855, 46.6935]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.650000000000006, 37.5245, 46.5765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.5255, 37.589, 46.563500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.364500000000003, 38.111000000000004, 46.4465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.2325, 38.163000000000004, 46.4335]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.0175, 38.577000000000005, 46.316500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.88, 38.6165, 46.3035]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.62, 38.9135, 46.186499999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.478, 38.939499999999995, 46.1735]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.182000000000002, 39.1105, 46.0565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.0365, 39.122499999999995, 46.0435]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.7135, 39.1675, 45.926500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.566000000000003, 39.1655, 45.913500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.234, 39.0845, 45.7965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.086, 39.068999999999996, 45.7835]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.753999999999998, 38.871, 45.6665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.6065, 38.842000000000006, 45.6535]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.283500000000004, 38.518, 45.536500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.138, 38.475, 45.523500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.842, 38.025000000000006, 45.4065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.7, 37.968500000000006, 45.3935]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.44, 37.4015, 45.2765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.303, 37.331999999999994, 45.2635]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.097, 36.647999999999996, 45.1465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.966500000000003, 36.565999999999995, 45.133500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.8235, 35.773999999999994, 45.0165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.7005, 35.6795, 45.0035]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.629500000000002, 34.7705, 44.886500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.515, 34.664500000000004, 44.8735]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.525000000000002, 33.6655, 44.756499999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.4205, 33.5485, 44.7435]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.529500000000002, 32.441500000000005, 44.6265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.436000000000002, 32.314, 44.6135]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.644, 31.126, 44.496500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.562, 30.990000000000002, 44.48350000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.878, 29.73, 44.3665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.8085, 29.586, 44.3535]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.241500000000002, 28.254, 44.23649999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.185500000000001, 28.103, 44.223499999999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7445, 26.717000000000002, 44.106500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.7025, 26.561000000000003, 44.093500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3875, 25.139, 43.9765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3595, 24.979, 43.9635]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.1705, 23.521, 43.846500000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.1565, 23.3585, 43.8335]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0935, 21.891499999999997, 43.716499999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0935, 21.727999999999998, 43.7035]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.1565, 20.252000000000002, 43.5865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.1705, 20.088500000000003, 43.5735]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3595, 18.6215, 43.456500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3875, 18.4595, 43.44350000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7025, 17.0105, 43.3265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.7445, 16.851, 43.3135]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.185500000000001, 15.429, 43.1965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.241500000000002, 15.2735, 43.1835]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.8085, 13.896500000000001, 43.066500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.878, 13.746, 43.05350000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.562, 12.414, 42.9365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.644, 12.2695, 42.9235]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.436000000000002, 11.000499999999999, 42.80649999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.529500000000002, 10.863, 42.793499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.4205, 9.657, 42.676500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.525000000000002, 9.528, 42.663500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.515, 8.411999999999999, 42.5465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.629500000000002, 8.2925, 42.533500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.7005, 7.2575, 42.4165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.8235, 7.148000000000001, 42.403499999999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.966500000000003, 6.212000000000001, 42.2865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.097, 6.1135, 42.2735]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.303, 5.2765, 42.1565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.44, 5.19, 42.1435]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.7, 4.47, 42.026500000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.842, 4.395499999999999, 42.01350000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.138, 3.7745, 41.8965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.283500000000004, 3.7125000000000004, 41.8835]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.6065, 3.2175000000000002, 41.76649999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.753999999999998, 3.169, 41.753499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.086, 2.791, 41.636500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.234, 2.7555, 41.62350000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.566000000000003, 2.4945000000000004, 41.5065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.7135, 2.4725, 41.493500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.0365, 2.3375, 41.3765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.182000000000002, 2.3295, 41.363499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.478, 2.3205, 41.2465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.62, 2.326, 41.2335]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.88, 2.434, 41.1165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.0175, 2.4530000000000003, 41.103500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.2325, 2.6870000000000003, 40.9865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.364500000000003, 2.72, 40.9735]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.5255, 3.08, 40.8565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.650000000000006, 3.1265, 40.8435]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.730000000000004, 3.6035, 40.7265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.846000000000004, 3.6625, 40.7135]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.854, 4.2475000000000005, 40.596500000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.961, 4.319, 40.58350000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.879000000000005, 5.020999999999999, 40.4665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.976000000000006, 5.1045, 40.4535]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.804, 5.9055, 40.336499999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.890499999999996, 6.000500000000001, 40.323499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.619499999999995, 6.9095, 40.206500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.695, 7.0155, 40.19350000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.325, 8.014500000000002, 40.0765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.389, 8.13, 40.063500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.911, 9.21, 39.9465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.963, 9.335, 39.933499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.377, 10.504999999999999, 39.8165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.4165, 10.6385, 39.8035]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.713499999999996, 11.871500000000001, 39.6865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.739999999999995, 12.0115, 39.673500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.919999999999995, 13.298499999999999, 39.5565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.933499999999995, 13.4445, 39.5435]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.9965, 14.7855, 39.426500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.9965, 14.9365, 39.4135]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.933499999999995, 16.3135, 39.296499999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.919999999999995, 16.468, 39.2835]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.739999999999995, 17.872, 39.1665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.713499999999996, 18.0285, 39.1535]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.4165, 19.4415, 39.036500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.377, 19.599, 39.023500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.963, 21.021, 38.9065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.911, 21.178500000000003, 38.893499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.389, 22.591500000000003, 38.7765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.325, 22.748, 38.7635]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.695, 24.152, 38.6465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.619499999999995, 24.306500000000003, 38.633500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.890499999999996, 25.683500000000002, 38.5165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.804, 25.834500000000002, 38.5035]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.976000000000006, 27.175500000000003, 38.3865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.879000000000005, 27.322000000000003, 38.3735]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.961, 28.618000000000002, 38.2565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.854, 28.7585, 38.243500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.846000000000004, 29.9915, 38.1265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.730000000000004, 30.125, 38.1135]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.650000000000006, 31.295, 37.996500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.5255, 31.421, 37.9835]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.364500000000003, 32.519, 37.866499999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.2325, 32.635999999999996, 37.8535]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.0175, 33.644000000000005, 37.7365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.88, 33.751000000000005, 37.7235]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.62, 34.669000000000004, 37.606500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.478, 34.7655, 37.593500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.182000000000002, 35.5845, 37.4765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.0365, 35.6695, 37.463499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.7135, 36.380500000000005, 37.3465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.566000000000003, 36.453, 37.3335]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.234, 37.047, 37.2165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.086, 37.107, 37.203500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.753999999999998, 37.592999999999996, 37.0865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.6065, 37.64, 37.0735]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.283500000000004, 38.0, 36.956500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.138, 38.033, 36.9435]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.842, 38.267, 36.826499999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.7, 38.286500000000004, 36.8135]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.44, 38.403499999999994, 36.6965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.303, 38.40899999999999, 36.6835]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.097, 38.391000000000005, 36.566500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.966500000000003, 38.382000000000005, 36.55350000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.8235, 38.238, 36.4365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.7005, 38.2155, 36.4235]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.629500000000002, 37.9545, 36.3065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.515, 37.9185, 36.2935]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.525000000000002, 37.5315, 36.176500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.4205, 37.482, 36.163500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.529500000000002, 36.978, 36.0465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.436000000000002, 36.9155, 36.0335]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.644, 36.2945, 35.91649999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.562, 36.219500000000004, 35.903499999999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.878, 35.490500000000004, 35.786500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.8085, 35.40350000000001, 35.773500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.241500000000002, 34.566500000000005, 35.6565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.185500000000001, 34.468, 35.6435]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7445, 33.532, 35.526500000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.7025, 33.422999999999995, 35.5135]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3875, 32.397000000000006, 35.3965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3595, 32.27850000000001, 35.383500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.1705, 31.171499999999998, 35.2665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.1565, 31.0445, 35.253499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0935, 29.8655, 35.136500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0935, 29.731, 35.12350000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.1565, 28.489000000000004, 35.0065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.1705, 28.348000000000003, 34.9935]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3595, 27.052, 34.8765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3875, 26.9055, 34.8635]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7025, 25.5645, 34.746500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.7445, 25.413999999999998, 34.7335]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.185500000000001, 24.046, 34.6165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.241500000000002, 23.892500000000002, 34.603500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.8085, 22.497500000000002, 34.4865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.878, 22.3425, 34.473499999999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.562, 20.9475, 34.356500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.644, 20.792, 34.343500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.436000000000002, 19.387999999999998, 34.2265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.529500000000002, 19.232999999999997, 34.213499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.4205, 17.847, 34.096500000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.525000000000002, 17.694, 34.08350000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.515, 16.326, 33.9665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.629500000000002, 16.1755, 33.9535]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.7005, 14.8345, 33.8365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.8235, 14.688, 33.823499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.966500000000003, 13.392000000000001, 33.706500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.097, 13.250500000000002, 33.6935]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.303, 11.999500000000001, 33.5765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.44, 11.8635, 33.5635]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.7, 10.6665, 33.4465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.842, 10.536999999999999, 33.4335]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.138, 9.403, 33.316500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.283500000000004, 9.281, 33.3035]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.6065, 8.219000000000001, 33.1865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.753999999999998, 8.105500000000001, 33.173500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.086, 7.1245, 33.0565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.234, 7.0205, 33.043499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.566000000000003, 6.1295, 32.926500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.7135, 6.035500000000001, 32.913500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.0365, 5.234500000000001, 32.7965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.182000000000002, 5.1505, 32.7835]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.478, 4.439500000000001, 32.6665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.62, 4.3665, 32.6535]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.88, 3.7635000000000005, 32.536500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.0175, 3.7025, 32.5235]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.2325, 3.2075, 32.4065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.364500000000003, 3.1585, 32.3935]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.5255, 2.7715, 32.276500000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.650000000000006, 2.7350000000000003, 32.2635]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.730000000000004, 2.465, 32.1465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.846000000000004, 2.4415, 32.133500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.854, 2.2885, 32.0165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.961, 2.278, 32.003499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.879000000000005, 2.2420000000000004, 31.8865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.976000000000006, 2.2440000000000007, 31.8735]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.804, 2.3160000000000003, 31.7565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.890499999999996, 2.331, 31.7435]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.619499999999995, 2.529, 31.626500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.695, 2.557, 31.613500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.325, 2.863, 31.496499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.389, 2.9035, 31.4835]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.911, 3.3265000000000002, 31.366500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.963, 3.3795, 31.3535]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.377, 3.9105, 31.2365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.4165, 3.9755, 31.2235]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.713499999999996, 4.6145000000000005, 31.106500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.739999999999995, 4.691000000000001, 31.093500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.919999999999995, 5.429, 30.9765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.933499999999995, 5.516, 30.963500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.9965, 6.343999999999999, 30.8465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.9965, 6.4415, 30.8335]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.933499999999995, 7.3685, 30.716500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.919999999999995, 7.476, 30.703500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.739999999999995, 8.483999999999998, 30.586499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.713499999999996, 8.600499999999998, 30.5735]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.4165, 9.6895, 30.456500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.377, 9.8145, 30.4435]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.963, 10.9755, 30.3265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.911, 11.108, 30.3135]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.389, 12.332, 30.196500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.325, 12.471, 30.183500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.695, 13.749, 30.066499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.619499999999995, 13.894, 30.0535]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.890499999999996, 15.226, 29.936500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.804, 15.375500000000002, 29.9235]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.976000000000006, 16.7345, 29.8065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.879000000000005, 16.8875, 29.7935]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.961, 18.282500000000002, 29.676500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.854, 18.4385, 29.663500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.846000000000004, 19.8515, 29.546499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.730000000000004, 20.0085, 29.5335]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.650000000000006, 21.4215, 29.416500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.5255, 21.578500000000002, 29.4035]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.364500000000003, 22.991500000000002, 29.2865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.2325, 23.148000000000003, 29.2735]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.0175, 24.552, 29.1565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.88, 24.706999999999997, 29.1435]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.62, 26.093, 29.0265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.478, 26.2455, 29.0135]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.182000000000002, 27.604499999999998, 28.896500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.0365, 27.753, 28.8835]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.7135, 29.067000000000004, 28.7665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.566000000000003, 29.211000000000002, 28.753500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.234, 30.488999999999997, 28.636499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.086, 30.627499999999998, 28.6235]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.753999999999998, 31.8425, 28.506500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.6065, 31.974500000000003, 28.493500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.283500000000004, 33.1355, 28.3765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.138, 33.2605, 28.363500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.842, 34.3495, 28.2465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.7, 34.466499999999996, 28.2335]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.44, 35.4835, 28.1165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.303, 35.592, 28.1035]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.097, 36.528, 27.986500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.966500000000003, 36.626999999999995, 27.9735]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.8235, 37.473, 27.8565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.7005, 37.562, 27.843500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.629500000000002, 38.318, 27.7265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.515, 38.3965, 27.7135]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.525000000000002, 39.05350000000001, 27.5965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.4205, 39.121, 27.5835]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.529500000000002, 39.679, 27.466500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.436000000000002, 39.734500000000004, 27.453500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.644, 40.17550000000001, 27.336499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.562, 40.218500000000006, 27.3235]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.878, 40.5515, 27.206500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.8085, 40.582499999999996, 27.1935]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.241500000000002, 40.8075, 27.0765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.185500000000001, 40.826, 27.0635]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7445, 40.934, 26.946500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.7025, 40.939499999999995, 26.933500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3875, 40.9305, 26.816499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3595, 40.923, 26.8035]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.1705, 40.797, 26.686500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.1565, 40.7765, 26.6735]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0935, 40.533500000000004, 26.5565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0935, 40.5005, 26.5435]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.1565, 40.1495, 26.426500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.1705, 40.1045, 26.413500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3595, 39.6455, 26.2965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3875, 39.589, 26.283500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7025, 39.031, 26.1665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.7445, 38.9635, 26.1535]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.185500000000001, 38.30650000000001, 26.036500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.241500000000002, 38.22800000000001, 26.023500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.8085, 37.471999999999994, 25.906499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.878, 37.382999999999996, 25.8935]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.562, 36.537, 25.776500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.644, 36.438, 25.7635]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.436000000000002, 35.502, 25.6465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.529500000000002, 35.394000000000005, 25.6335]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.4205, 34.385999999999996, 25.516500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.525000000000002, 34.269999999999996, 25.503500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.515, 33.190000000000005, 25.386499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.629500000000002, 33.066, 25.3735]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.7005, 31.914, 25.256500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.8235, 31.783, 25.2435]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.966500000000003, 30.577000000000005, 25.1265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.097, 30.440000000000005, 25.113500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.303, 29.180000000000003, 24.9965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.44, 29.038000000000004, 24.9835]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.7, 27.742000000000004, 24.8665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.842, 27.596000000000004, 24.8535]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.138, 26.264000000000003, 24.736500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.283500000000004, 26.115000000000002, 24.7235]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.6065, 24.765, 24.6065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.753999999999998, 24.614, 24.5935]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.086, 23.246000000000002, 24.4765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.234, 23.093500000000002, 24.4635]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.566000000000003, 21.716500000000003, 24.3465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.7135, 21.5635, 24.3335]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.0365, 20.1865, 24.216500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.182000000000002, 20.034, 24.203500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.478, 18.666, 24.0865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.62, 18.515, 24.073500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.88, 17.165, 23.9565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.0175, 17.0165, 23.9435]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.2325, 15.6935, 23.826500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.364500000000003, 15.5475, 23.8135]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.5255, 14.2425, 23.6965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.650000000000006, 14.1, 23.683500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.730000000000004, 12.84, 23.5665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.846000000000004, 12.702, 23.5535]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.854, 11.478, 23.4365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.961, 11.3445, 23.4235]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.879000000000005, 10.1655, 23.306500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.976000000000006, 10.036999999999999, 23.2935]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.804, 8.903, 23.1765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.890499999999996, 8.780000000000001, 23.163500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.619499999999995, 7.699999999999999, 23.0465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.695, 7.583499999999999, 23.0335]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.325, 6.5665, 22.9165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.389, 6.457, 22.9035]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.911, 5.503, 22.786500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.963, 5.4005, 22.773500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.377, 4.5095, 22.656499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.4165, 4.415, 22.6435]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.713499999999996, 3.6050000000000004, 22.526500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.739999999999995, 3.519, 22.5135]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.919999999999995, 2.781, 22.3965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.933499999999995, 2.7035, 22.3835]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.9965, 2.0465, 22.266500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.9965, 1.978, 22.253500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.933499999999995, 1.4020000000000001, 22.136499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.919999999999995, 1.3425, 22.123499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.739999999999995, 0.8475, 22.0065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.713499999999996, 0.7975, 21.9935]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.4165, 0.3925, 21.8765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.377, 0.35250000000000004, 21.8635]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.963, 0.037500000000000006, 21.746499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.911, 0.0075, 21.7335]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.389, -0.21750000000000003, 21.616500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.325, -0.23800000000000002, 21.6035]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.695, -0.382, 21.4865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.619499999999995, -0.393, 21.4735]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.890499999999996, -0.44700000000000006, 21.356500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.804, -0.448, 21.343500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.976000000000006, -0.412, 21.226499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.879000000000005, -0.40349999999999997, 21.2135]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.961, -0.28650000000000003, 21.096500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.854, -0.2690000000000001, 21.0835]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.846000000000004, -0.07100000000000001, 20.9665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.730000000000004, -0.044, 20.953500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.650000000000006, 0.24400000000000002, 20.8365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.5255, 0.2805, 20.8235]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.364500000000003, 0.6495000000000001, 20.7065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.2325, 0.6950000000000001, 20.6935]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.0175, 1.145, 20.576500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.88, 1.1995, 20.5635]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.62, 1.7305000000000001, 20.4465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.478, 1.7935, 20.433500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.182000000000002, 2.3965000000000005, 20.3165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.0365, 2.4675000000000002, 20.3035]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.7135, 3.1425, 20.1865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.566000000000003, 3.2215000000000003, 20.1735]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.234, 3.9685, 20.056500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.086, 4.0545, 20.0435]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.753999999999998, 4.8555, 19.9265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.6065, 4.9485, 19.9135]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.283500000000004, 5.8215, 19.7965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.138, 5.921, 19.7835]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.842, 6.8389999999999995, 19.6665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.7, 6.944, 19.653499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.44, 7.916, 19.5365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.303, 8.0265, 19.523500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.097, 9.0435, 19.4065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.966500000000003, 9.158999999999999, 19.3935]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.8235, 10.220999999999998, 19.2765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.7005, 10.341, 19.2635]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.629500000000002, 11.439, 19.146500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.515, 11.562999999999999, 19.1335]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.525000000000002, 12.697, 19.0165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.4205, 12.824, 19.003500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.529500000000002, 13.975999999999999, 18.8865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.436000000000002, 14.1055, 18.8735]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.644, 15.2845, 18.7565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.562, 15.4165, 18.7435]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.878, 16.613500000000002, 18.626500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.8085, 16.747, 18.613500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.241500000000002, 17.953, 18.496499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.185500000000001, 18.087, 18.4835]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7445, 19.293, 18.366500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.7025, 19.427, 18.3535]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3875, 20.633, 18.2365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3595, 20.7665, 18.2235]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.1705, 21.963500000000003, 18.106500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.1565, 22.0955, 18.093500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0935, 23.2745, 17.976499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0935, 23.4045, 17.9635]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.1565, 24.565499999999997, 17.846500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.1705, 24.692999999999998, 17.8335]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3595, 25.827, 17.716500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3875, 25.951500000000003, 17.703500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7025, 27.058500000000002, 17.5865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.7445, 27.179000000000002, 17.5735]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.185500000000001, 28.241000000000003, 17.4565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.241500000000002, 28.356500000000004, 17.4435]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.8085, 29.373500000000003, 17.3265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.878, 29.484, 17.3135]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.562, 30.456000000000003, 17.1965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.644, 30.561000000000003, 17.183500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.436000000000002, 31.479000000000003, 17.066499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.529500000000002, 31.578000000000003, 17.0535]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.4205, 32.44200000000001, 16.9365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.525000000000002, 32.534000000000006, 16.9235]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.515, 33.326, 16.8065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.629500000000002, 33.4105, 16.7935]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.7005, 34.1395, 16.6765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.8235, 34.2165, 16.663500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.966500000000003, 34.8735, 16.546499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.097, 34.942499999999995, 16.5335]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.303, 35.5275, 16.4165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.44, 35.58800000000001, 16.4035]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.7, 36.092, 16.2865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.842, 36.143499999999996, 16.273500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.138, 36.566500000000005, 16.156499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.283500000000004, 36.60850000000001, 16.1435]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.6065, 36.941500000000005, 16.0265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.753999999999998, 36.974000000000004, 16.0135]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.086, 37.226000000000006, 15.8965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.234, 37.249, 15.8835]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.566000000000003, 37.411, 15.766499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.7135, 37.42400000000001, 15.753499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.0365, 37.496, 15.6365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.182000000000002, 37.499, 15.6235]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.478, 37.481, 15.5065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.62, 37.474, 15.493500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.88, 37.366, 15.3765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.0175, 37.349000000000004, 15.3635]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.2325, 37.151, 15.246500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.364500000000003, 37.1235, 15.233500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.5255, 36.8265, 15.1165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.650000000000006, 36.789, 15.1035]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.730000000000004, 36.411, 14.986500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.846000000000004, 36.36450000000001, 14.973500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.854, 35.9055, 14.8565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.961, 35.8495, 14.8435]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.879000000000005, 35.3005, 14.726500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.976000000000006, 35.2355, 14.713500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.804, 34.6145, 14.5965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.890499999999996, 34.5415, 14.5835]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.619499999999995, 33.8485, 14.466500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.695, 33.767, 14.453500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.325, 32.993, 14.336500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.389, 32.904, 14.323500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.911, 32.076, 14.2065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.963, 31.980000000000004, 14.1935]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.377, 31.080000000000005, 14.0765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.4165, 30.977000000000004, 14.063500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.713499999999996, 30.023, 13.9465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.739999999999995, 29.9145, 13.933499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.919999999999995, 28.9155, 13.816500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.933499999999995, 28.8015, 13.8035]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.9965, 27.748500000000003, 13.686499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.9965, 27.629500000000004, 13.673499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.933499999999995, 26.5405, 13.5565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.919999999999995, 26.418, 13.5435]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.739999999999995, 25.302, 13.426499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.713499999999996, 25.176499999999997, 13.413499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.4165, 24.0335, 13.2965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.377, 23.905, 13.2835]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.963, 22.735000000000003, 13.166500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.911, 22.6045, 13.153500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.389, 21.4255, 13.0365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.325, 21.2935, 13.0235]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.695, 20.096500000000002, 12.906500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.619499999999995, 19.9635, 12.893500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.890499999999996, 18.766499999999997, 12.7765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.804, 18.633999999999997, 12.7635]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.976000000000006, 17.445999999999998, 12.646500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.879000000000005, 17.3145, 12.633500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.961, 16.1355, 12.5165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.854, 16.005000000000003, 12.5035]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.846000000000004, 14.834999999999999, 12.386500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.730000000000004, 14.706499999999998, 12.373500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.650000000000006, 13.563500000000001, 12.2565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.5255, 13.438, 12.243500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.364500000000003, 12.322000000000001, 12.1265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.2325, 12.1995, 12.1135]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.0175, 11.1105, 11.996500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.88, 10.9915, 11.983500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.62, 9.938500000000001, 11.8665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.478, 9.824000000000002, 11.8535]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.182000000000002, 8.816, 11.7365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.0365, 8.706, 11.7235]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.7135, 7.734, 11.606499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.566000000000003, 7.6285, 11.593499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.234, 6.7015, 11.4765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.086, 6.601500000000001, 11.4635]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.753999999999998, 5.7285, 11.346499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.6065, 5.6345, 11.333499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.283500000000004, 4.8155, 11.2165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.138, 4.728, 11.2035]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.842, 3.9720000000000004, 11.0865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.7, 3.8915000000000006, 11.0735]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.44, 3.1985, 10.9565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.303, 3.1250000000000004, 10.9435]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.097, 2.495, 10.826500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.966500000000003, 2.429, 10.813500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.8235, 1.8710000000000002, 10.6965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.7005, 1.8130000000000002, 10.6835]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.629500000000002, 1.3270000000000002, 10.566500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.515, 1.2770000000000001, 10.553500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.525000000000002, 0.863, 10.4365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.4205, 0.8215, 10.4235]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.529500000000002, 0.4885, 10.306500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.436000000000002, 0.45549999999999996, 10.293500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.644, 0.1945, 10.1765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.562, 0.1695, 10.1635]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.878, -0.0195, 10.0465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.8085, -0.036500000000000005, 10.0335]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.241500000000002, -0.15350000000000003, 9.916500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.185500000000001, -0.1625, 9.903500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7445, -0.2075, 9.7865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.7025, -0.20850000000000002, 9.7735]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3875, -0.1815, 9.656500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3595, -0.17450000000000002, 9.643500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.1705, -0.07550000000000001, 9.5265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.1565, -0.06050000000000001, 9.5135]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0935, 0.1105, 9.3965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0935, 0.1335, 9.3835]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.1565, 0.37650000000000006, 9.266499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.1705, 0.40700000000000003, 9.253499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3595, 0.7130000000000001, 9.1365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3875, 0.7505000000000001, 9.1235]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7025, 1.1195, 9.006499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.7445, 1.164, 8.9935]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.185500000000001, 1.596, 8.8765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.241500000000002, 1.6475000000000002, 8.8635]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.8085, 2.1425, 8.746500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.878, 2.2, 8.733500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.562, 2.7399999999999998, 8.6165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.644, 2.8034999999999997, 8.6035]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.436000000000002, 3.4065000000000003, 8.486500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.529500000000002, 3.4755000000000003, 8.473500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.4205, 4.1145000000000005, 8.3565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.525000000000002, 4.1885, 8.343499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.515, 4.8815, 8.226500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.629500000000002, 4.961, 8.2135]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.7005, 5.699000000000001, 8.096499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.8235, 5.782500000000001, 8.083499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.966500000000003, 6.5475, 7.9665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.097, 6.635, 7.9535]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.303, 7.445, 7.836500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.44, 7.5365, 7.823500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.7, 8.3735, 7.706500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.842, 8.468, 7.6935]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.138, 9.332, 7.576500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.283500000000004, 9.4295, 7.563500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.6065, 10.320500000000001, 7.4465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.753999999999998, 10.4205, 7.4335]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.086, 11.329500000000001, 7.3165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.234, 11.431000000000001, 7.3035]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.566000000000003, 12.349, 7.1865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.7135, 12.452, 7.1735]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.0365, 13.388, 7.0565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.182000000000002, 13.492, 7.0435]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.478, 14.428, 6.9265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.62, 14.5325, 6.9135]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.88, 15.477500000000001, 6.7965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.0175, 15.582, 6.7835]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.2325, 16.518, 6.666500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.364500000000003, 16.622, 6.653500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.5255, 17.558, 6.536500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.650000000000006, 17.6615, 6.5235]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.730000000000004, 18.5885, 6.406500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.846000000000004, 18.6905, 6.3935]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.854, 19.5995, 6.2764999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.961, 19.6995, 6.2635]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.879000000000005, 20.5905, 6.1465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.976000000000006, 20.688000000000002, 6.1335]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.804, 21.552, 6.0165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.890499999999996, 21.647000000000002, 6.0035]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.619499999999995, 22.493000000000002, 5.8865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.695, 22.585, 5.8735]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.325, 23.395, 5.7565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.389, 23.483, 5.7435]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.911, 24.257, 5.6265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.963, 24.340500000000002, 5.6135]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.377, 25.0695, 5.496500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.4165, 25.148, 5.483500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.713499999999996, 25.832, 5.366500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.739999999999995, 25.905500000000004, 5.3535]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.919999999999995, 26.5445, 5.2365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.933499999999995, 26.6125, 5.2235000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.9965, 27.1975, 5.1065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.9965, 27.259500000000003, 5.0935]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.933499999999995, 27.7905, 4.9765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.919999999999995, 27.8465, 4.9635]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.739999999999995, 28.323500000000003, 4.8465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.713499999999996, 28.373, 4.8335]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.4165, 28.787, 4.7165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.377, 28.8295, 4.7035]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.963, 29.180500000000002, 4.5865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.911, 29.216, 4.5735]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.389, 29.504, 4.4565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.325, 29.532000000000004, 4.4435]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.695, 29.748000000000005, 4.3265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.619499999999995, 29.768500000000003, 4.3135]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.890499999999996, 29.9215, 4.1965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.804, 29.9345, 4.1835]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.976000000000006, 30.015500000000003, 4.0665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.879000000000005, 30.020500000000002, 4.0535]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.961, 30.029500000000002, 3.9365000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.854, 30.026500000000002, 3.9235000000000007]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.846000000000004, 29.963500000000003, 3.8064999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.730000000000004, 29.9525, 3.7935]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.650000000000006, 29.817500000000003, 3.6765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.5255, 29.7985, 3.6635]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.364500000000003, 29.5915, 3.5465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.2325, 29.5645, 3.5335]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.0175, 29.2855, 3.4165000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.88, 29.2505, 3.4035]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.62, 28.8995, 3.2865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.478, 28.8565, 3.2735]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.182000000000002, 28.4335, 3.1565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.0365, 28.383, 3.1435]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.7135, 27.897000000000002, 3.0265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.566000000000003, 27.839000000000002, 3.0135]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.234, 27.281000000000002, 2.8965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.086, 27.215500000000002, 2.8835]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.753999999999998, 26.5945, 2.7665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.6065, 26.522, 2.7535]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.283500000000004, 25.838, 2.6365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.138, 25.7585, 2.6235]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.842, 25.011499999999998, 2.5065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.7, 24.9255, 2.4935]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.44, 24.1245, 2.3765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.303, 24.0325, 2.3635]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.097, 23.1775, 2.2465000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.966500000000003, 23.0795, 2.2335000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.8235, 22.1705, 2.1165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.7005, 22.067, 2.1035]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.629500000000002, 21.113, 1.9865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.515, 21.005, 1.9735]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.525000000000002, 20.015, 1.8565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.4205, 19.902500000000003, 1.8435000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.529500000000002, 18.8675, 1.7265000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.436000000000002, 18.750999999999998, 1.7135]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.644, 17.689, 1.5965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.562, 17.569, 1.5835000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.878, 16.471, 1.4665000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.8085, 16.348, 1.4535]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.241500000000002, 15.232000000000001, 1.3365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.185500000000001, 15.107000000000001, 1.3235000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7445, 13.973, 1.2065000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.7025, 13.846, 1.1935]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3875, 12.694, 1.0765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3595, 12.5655, 1.0635000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.1705, 11.404499999999999, 0.9465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.1565, 11.274999999999999, 0.9335]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0935, 10.105, 0.8165000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0935, 9.9755, 0.8035000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.1565, 8.8145, 0.6865000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.1705, 8.6855, 0.6735000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3595, 7.524500000000001, 0.5565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3875, 7.3965000000000005, 0.5435000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7025, 6.253500000000001, 0.4265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.7445, 6.127000000000001, 0.4135]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.185500000000001, 4.993, 0.2965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.241500000000002, 4.8685, 0.28350000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.8085, 3.7615, 0.1665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.878, 3.6395, 0.15350000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.562, 2.5505, 0.036500000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.644499999999999, 2.431, 0.0285]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.4455, 1.369, 0.0015]) cube([0.4, 0.4, 0.1], center=true);
}

