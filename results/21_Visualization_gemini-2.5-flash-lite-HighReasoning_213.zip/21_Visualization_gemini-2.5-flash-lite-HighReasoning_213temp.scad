
hull() {
    translate([9.985, 10.015, 18.985000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.715, 10.285000000000002, 18.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.68, 10.315000000000001, 18.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.32, 10.584999999999999, 18.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.275, 10.614999999999998, 18.384999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.825000000000001, 10.885, 18.115000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.770000000000001, 10.92, 18.085000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.23, 11.280000000000001, 17.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.17, 11.315000000000001, 17.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.63, 11.584999999999999, 17.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.5649999999999995, 11.62, 17.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.9350000000000005, 11.98, 17.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.865000000000001, 12.020000000000001, 17.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.235, 12.38, 16.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.165, 12.42, 16.884999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.535, 12.780000000000001, 16.615000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.465, 12.815000000000001, 16.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.835, 13.084999999999999, 16.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.765000000000001, 13.12, 16.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.135, 13.48, 16.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.0649999999999995, 13.52, 15.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.435, 13.879999999999999, 15.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.365, 13.92, 15.684999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.7350000000000003, 14.280000000000001, 15.415000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.665, 14.32, 15.385000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.035, 14.68, 15.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.965, 14.72, 15.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.3350000000000002, 15.08, 14.815000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.2650000000000001, 15.120000000000001, 14.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.635, 15.48, 14.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.5700000000000001, 15.515, 14.485000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.03, 15.785, 14.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 15.82, 14.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 16.18, 14.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 16.22, 13.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 16.580000000000002, 13.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 16.62, 13.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 16.98, 13.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 17.02, 13.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 17.38, 13.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 17.419999999999998, 13.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 17.78, 13.209999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 17.82, 13.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 18.18, 13.010000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 18.22, 12.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 18.580000000000002, 12.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 18.62, 12.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 18.98, 12.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 19.020000000000003, 12.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 19.380000000000003, 12.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 19.42, 12.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 19.78, 12.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 19.81, 12.190000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 19.99, 12.010000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.020000000000000004, 19.995, 11.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.38000000000000006, 19.905, 11.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.44500000000000006, 19.89, 11.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.2550000000000001, 19.71, 11.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.3450000000000002, 19.69, 11.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1550000000000002, 19.51, 11.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.245, 19.490000000000002, 11.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.055, 19.310000000000002, 11.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.145, 19.290000000000003, 11.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.955, 19.110000000000003, 11.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.045, 19.09, 10.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.855, 18.909999999999997, 10.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.945, 18.889999999999997, 10.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.755, 18.709999999999997, 10.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.845, 18.689999999999998, 10.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.655, 18.51, 10.410000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.745, 18.490000000000002, 10.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.555, 18.310000000000002, 10.209999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.645, 18.290000000000003, 10.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.455, 18.110000000000003, 10.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.545, 18.090000000000003, 9.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.355, 17.91, 9.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.445, 17.89, 9.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.255, 17.71, 9.610000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.345, 17.69, 9.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.155, 17.51, 9.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.245, 17.49, 9.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.055, 17.31, 9.209999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.145000000000001, 17.29, 9.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.955000000000002, 17.110000000000003, 9.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.045000000000002, 17.090000000000003, 8.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.855, 16.91, 8.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.945, 16.89, 8.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.755, 16.71, 8.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.845, 16.689999999999998, 8.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.655, 16.509999999999998, 8.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.745, 16.49, 8.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.555, 16.310000000000002, 8.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.645000000000003, 16.290000000000003, 8.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.455, 16.110000000000003, 8.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.545, 16.090000000000003, 7.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.354999999999997, 15.91, 7.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.445, 15.89, 7.789999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.255000000000003, 15.709999999999999, 7.609999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.335, 15.69, 7.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.965, 15.510000000000002, 7.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 15.475000000000001, 7.390000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 15.025, 7.210000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 14.975, 7.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 14.525, 7.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 14.475000000000001, 6.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 14.025, 6.8100000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 13.975, 6.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 13.525, 6.609999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 13.475000000000001, 6.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 13.025000000000002, 6.410000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 12.975000000000001, 6.390000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 12.525, 6.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 12.475, 6.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 12.025, 6.010000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 11.975000000000001, 5.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 11.525, 5.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 11.475, 5.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 11.025, 5.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 10.975, 5.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 10.525, 5.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 10.475000000000001, 5.390000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 10.025, 5.210000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.965, 9.975, 5.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.335, 9.525, 5.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.265, 9.475000000000001, 4.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.635, 9.025, 4.8100000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.565, 8.975, 4.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.935, 8.525, 4.609999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.865, 8.475, 4.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.235, 8.025, 4.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.165, 7.9750000000000005, 4.390000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.535, 7.525, 4.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.465, 7.475, 4.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.835, 7.025, 4.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.765, 6.975, 3.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.135, 6.525, 3.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.065, 6.4750000000000005, 3.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.435, 6.025, 3.6100000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.365000000000002, 5.9750000000000005, 3.5900000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.735, 5.525, 3.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.665, 5.4750000000000005, 3.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.035, 5.025, 3.2100000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.965000000000002, 4.975, 3.1900000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.335, 4.5249999999999995, 3.0100000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.265, 4.475, 2.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.635, 4.025, 2.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.565, 3.975, 2.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.935, 3.525, 2.6100000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.865, 3.475, 2.5900000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.235, 3.0250000000000004, 2.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.165, 2.975, 2.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.535, 2.525, 2.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.465, 2.475, 2.1900000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.835, 2.025, 2.0100000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.765, 1.975, 1.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.135, 1.5250000000000001, 1.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.065, 1.475, 1.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.4350000000000005, 1.025, 1.6100000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.365, 0.9750000000000001, 1.5900000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.735, 0.525, 1.4100000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.665, 0.47500000000000003, 1.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.035, 0.025, 1.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.95, 0.0, 1.1900000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.05, 0.0, 1.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.95, 0.0, 0.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.05, 0.0, 0.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.95, 0.0, 0.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.0500000000000003, 0.0, 0.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.95, 0.0, 0.5900000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.05, 0.0, 0.41000000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.9500000000000002, 0.0, 0.39000000000000007]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.05, 0.0, 0.21000000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9500000000000001, 0.0, 0.19000000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.05, 0.0, 0.010000000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 0.025, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.47500000000000003, 0.7600000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 0.55, 0.8400000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 1.4500000000000002, 1.5600000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 1.55, 1.6400000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.45, 2.3600000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.55, 2.44]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.45, 3.16]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.55, 3.24]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 4.45, 3.96]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 4.55, 4.04]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 5.45, 4.760000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 5.550000000000001, 4.84]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 6.450000000000001, 5.56]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 6.550000000000001, 5.640000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 7.45, 6.360000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 7.55, 6.440000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 8.450000000000001, 7.16]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 8.55, 7.24]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 9.450000000000001, 7.96]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 9.55, 8.040000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 10.450000000000001, 8.760000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 10.55, 8.84]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 11.45, 9.56]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 11.55, 9.64]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 12.45, 10.360000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 12.55, 10.440000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 13.450000000000001, 11.16]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 13.55, 11.24]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 14.450000000000001, 11.96]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 14.55, 12.040000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 15.450000000000001, 12.760000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 15.55, 12.840000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 16.45, 13.56]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 16.55, 13.64]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 17.45, 14.360000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 17.55, 14.440000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 18.450000000000003, 15.16]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 18.55, 15.24]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 19.45, 15.96]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 19.525000000000002, 16.04]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 19.975, 16.76]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.05, 20.0, 16.84]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9500000000000001, 20.0, 17.560000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.05, 20.0, 17.64]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9500000000000002, 20.0, 18.36]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.05, 20.0, 18.439999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.95, 20.0, 19.16]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0500000000000003, 20.0, 19.240000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.95, 20.0, 19.96]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.05, 19.985, 19.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.95, 19.715, 19.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.05, 19.685, 19.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.95, 19.415, 19.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.050000000000001, 19.385, 19.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.95, 19.115000000000002, 19.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.05, 19.085, 19.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.95, 18.815, 19.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.05, 18.785, 19.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.95, 18.515, 19.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.049999999999999, 18.485000000000003, 18.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.95, 18.215, 18.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.05, 18.185, 18.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.950000000000001, 17.915, 18.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.05, 17.884999999999998, 18.590000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.950000000000001, 17.615000000000002, 18.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.05, 17.585, 18.389999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.950000000000001, 17.315, 18.209999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.05, 17.285, 18.189999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.95, 17.015, 18.009999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.05, 16.985, 17.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.95, 16.715, 17.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.05, 16.685, 17.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.950000000000001, 16.415, 17.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.05, 16.384999999999998, 17.590000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.95, 16.115000000000002, 17.409999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.05, 16.085, 17.389999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.95, 15.815000000000001, 17.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.05, 15.785, 17.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.950000000000003, 15.515, 17.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.040000000000003, 15.485000000000001, 16.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.76, 15.215, 16.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.81, 15.18, 16.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.99, 14.82, 16.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 14.775, 16.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 14.325000000000001, 16.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 14.275000000000002, 16.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 13.825000000000003, 16.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 13.775000000000002, 16.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 13.325000000000001, 16.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 13.275, 15.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 12.825000000000001, 15.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 12.775000000000002, 15.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 12.325000000000001, 15.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 12.275, 15.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 11.825000000000001, 15.410000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 11.775, 15.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 11.325000000000001, 15.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 11.275000000000002, 15.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 10.825000000000001, 15.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 10.775, 14.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 10.325000000000001, 14.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 10.275000000000002, 14.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 9.825000000000001, 14.610000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 9.775, 14.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 9.325000000000001, 14.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 9.275, 14.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 8.825000000000001, 14.209999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 8.775, 14.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 8.325000000000001, 14.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.965, 8.275, 13.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.335, 7.824999999999999, 13.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.265, 7.7749999999999995, 13.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.635, 7.325, 13.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.565, 7.275, 13.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.935, 6.825, 13.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.865, 6.775, 13.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.235, 6.325, 13.209999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.165, 6.275, 13.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.535, 5.824999999999999, 13.010000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.465, 5.7749999999999995, 12.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.835, 5.324999999999999, 12.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.765, 5.2749999999999995, 12.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.135, 4.825, 12.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.065, 4.775, 12.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.435, 4.325, 12.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.365000000000002, 4.275, 12.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.735, 3.825, 12.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.665, 3.775, 12.190000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.035, 3.3249999999999997, 12.010000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.965000000000002, 3.275, 11.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.335, 2.825, 11.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.265, 2.775, 11.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.635, 2.3249999999999997, 11.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.565, 2.275, 11.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.935, 1.8250000000000002, 11.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.865, 1.7750000000000001, 11.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.235, 1.3250000000000002, 11.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.165, 1.2750000000000001, 11.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.535, 0.8250000000000001, 11.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.465, 0.7750000000000001, 10.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.835, 0.325, 10.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.765, 0.28500000000000003, 10.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.135, 0.015, 10.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.045, 0.0, 10.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.055, 0.0, 10.410000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.95, 0.0, 10.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.050000000000001, 0.0, 10.209999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.95, 0.0, 10.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.05, 0.0, 10.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.95, 0.0, 9.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.05, 0.0, 9.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.95, 0.0, 9.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.0500000000000003, 0.0, 9.610000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.95, 0.0, 9.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.05, 0.0, 9.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.9500000000000002, 0.0, 9.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.05, 0.0, 9.209999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9500000000000001, 0.0, 9.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.05, 0.0, 9.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 0.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.9500000000000001, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 1.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 1.9500000000000002, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.95, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.0500000000000003, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.95, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 4.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 4.95, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 5.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 5.95, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 6.050000000000001, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 6.95, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 7.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 7.95, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 8.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 8.95, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 9.049999999999999, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 9.95, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 10.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 10.950000000000001, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 11.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 11.950000000000001, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 12.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 12.950000000000001, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 13.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 13.95, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 14.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 14.95, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 15.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 15.950000000000001, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 16.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 16.95, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 17.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 17.95, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 18.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 18.950000000000003, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 19.05, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 19.95, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.05, 20.0, 8.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9500000000000001, 20.0, 8.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.05, 20.0, 8.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9500000000000002, 20.0, 8.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.05, 20.0, 8.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.95, 20.0, 8.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0500000000000003, 20.0, 8.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.95, 20.0, 8.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.05, 20.0, 8.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.95, 20.0, 8.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.05, 20.0, 7.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.95, 20.0, 7.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.050000000000001, 20.0, 7.789999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.95, 20.0, 7.609999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.05, 20.0, 7.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.95, 20.0, 7.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.05, 20.0, 7.390000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.95, 20.0, 7.210000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.049999999999999, 20.0, 7.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.95, 20.0, 7.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.05, 20.0, 6.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.950000000000001, 20.0, 6.8100000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.05, 20.0, 6.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.950000000000001, 20.0, 6.609999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.05, 20.0, 6.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.950000000000001, 20.0, 6.410000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.05, 20.0, 6.390000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.95, 20.0, 6.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.05, 20.0, 6.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.95, 20.0, 6.010000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.05, 20.0, 5.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.950000000000001, 20.0, 5.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.05, 20.0, 5.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.95, 20.0, 5.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.05, 20.0, 5.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.95, 20.0, 5.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.05, 20.0, 5.390000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.950000000000003, 20.0, 5.210000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.05, 20.0, 5.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.95, 20.0, 5.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 19.95, 4.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 19.05, 4.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 18.950000000000003, 3.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 18.05, 3.0500000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 17.95, 2.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 17.05, 2.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 16.95, 1.9500000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 16.05, 1.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 15.950000000000001, 0.9500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 15.05, 0.05]) cube([0.4, 0.4, 0.1], center=true);
}

