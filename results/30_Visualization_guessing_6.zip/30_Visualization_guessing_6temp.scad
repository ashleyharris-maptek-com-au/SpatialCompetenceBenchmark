color("Yellow") translate([0, 0, 0]) // {'digit': 1, 'orientation': 'rotate90Y'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 1.2]) mirror([0, 1, 0]) // {'digit': 9, 'orientation': 'flippedY'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 2.4]) translate([-5, 0, 5]) rotate([0, 90, 0])
  // {'digit': 2, 'orientation': 'rotate90Y'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 8.6]) rotate([0, 0, 180]) // {'digit': 8, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 9.799999999999999]) mirror([1, 0, 0]) // {'digit': 5, 'orientation': 'flippedX'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 10.999999999999998]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}
