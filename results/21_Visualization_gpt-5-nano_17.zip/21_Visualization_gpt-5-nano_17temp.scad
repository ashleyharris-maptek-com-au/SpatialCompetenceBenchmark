color([1, 0, 1]) hull()
{
  translate([9.48643, 5.076955, 4.984375]) cube([0.4, 0.4, 0.1], center = true);
  translate([9.24217, 6.4621450000000005, 4.703125]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([9.18953, 6.606770000000001, 4.671875]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.486270000000001, 7.82483, 4.390625]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.387340000000002, 7.94273, 4.359375]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.3098600000000005, 8.846870000000001, 4.078125]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.176595000000001, 8.923825, 4.046875]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.855305, 9.404875, 3.765625]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.70371, 9.431600000000001, 3.734375]) cube([0.4, 0.4, 0.1], center = true);
  translate([4.29629, 9.431600000000001, 3.453125]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.144695, 9.404875, 3.421875]) cube([0.4, 0.4, 0.1], center = true);
  translate([2.823405, 8.923825, 3.140625]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([2.69014, 8.846870000000001, 3.109375]) cube([0.4, 0.4, 0.1], center = true);
  translate([1.61266, 7.94273, 2.828125]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([1.51373, 7.82483, 2.796875]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.81047, 6.606770000000001, 2.515625]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.75783, 6.4621450000000005, 2.484375]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.51357, 5.076955, 2.203125]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.51357, 4.923045, 2.171875]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.75783, 3.5378550000000004, 1.890625]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.81047, 3.3932300000000004, 1.859375]) cube([0.4, 0.4, 0.1], center = true);
  translate([1.51373, 2.17517, 1.578125]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([1.61266, 2.05727, 1.546875]) cube([0.4, 0.4, 0.1], center = true);
  translate([2.69014, 1.15313, 1.265625]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([2.823405, 1.076175, 1.234375]) cube([0.4, 0.4, 0.1], center = true);
  translate([4.144695, 0.595125, 0.953125]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.29629, 0.5684, 0.921875]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.70371, 0.5684, 0.640625]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.855305, 0.595125, 0.609375]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.176595000000001, 1.076175, 0.328125]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.3098600000000005, 1.15313, 0.296875]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.387340000000002, 2.05727, 0.015625]) cube([0.4, 0.4, 0.1], center = true);
}
