
translate([0, 0, 0]) cube([1, 1, 5.00037715252663]);

translate([1, 0, 0]) cube([1, 1, 4.301655638919334]);

translate([2, 0, 0]) cube([1, 1, 4.1077740528696385]);

translate([3, 0, 0]) cube([1, 1, 4.090590539670942]);

translate([4, 0, 0]) cube([1, 1, 4.091009833198943]);

translate([5, 0, 0]) cube([1, 1, 3.772076090867131]);

translate([6, 0, 0]) cube([1, 1, 3.9795912374645654]);

translate([7, 0, 0]) cube([1, 1, 4.359843253968254]);

translate([8, 0, 0]) cube([1, 1, 4.266233413305799]);

translate([9, 0, 0]) cube([1, 1, 4.620158730158729]);

translate([10, 0, 0]) cube([1, 1, 5.0]);

translate([11, 0, 0]) cube([1, 1, 5.3]);

translate([12, 0, 0]) cube([1, 1, 5.4]);

translate([13, 0, 0]) cube([1, 1, 5.3]);

translate([14, 0, 0]) cube([1, 1, 4.8]);

translate([15, 0, 0]) cube([1, 1, 4.41575]);

translate([16, 0, 0]) cube([1, 1, 3.7560295184789108]);

translate([17, 0, 0]) cube([1, 1, 3.7412369408716346]);

translate([18, 0, 0]) cube([1, 1, 4.6]);

translate([19, 0, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.300754305367414]);

translate([2, 1, 0]) cube([1, 1, 4.802179821600026]);

translate([3, 1, 0]) cube([1, 1, 4.31095834146735]);

translate([4, 1, 0]) cube([1, 1, 4.269878790949916]);

translate([5, 1, 0]) cube([1, 1, 4.266448984641609]);

translate([6, 1, 0]) cube([1, 1, 4.2770446930858625]);

translate([7, 1, 0]) cube([1, 1, 4.264636494822315]);

translate([8, 1, 0]) cube([1, 1, 4.24764683628563]);

translate([9, 1, 0]) cube([1, 1, 4.0816816915951115]);

translate([10, 1, 0]) cube([1, 1, 4.4592601342230616]);

translate([11, 1, 0]) cube([1, 1, 4.157715173466184]);

translate([12, 1, 0]) cube([1, 1, 4.154167950204294]);

translate([13, 1, 0]) cube([1, 1, 3.8390110036106138]);

translate([14, 1, 0]) cube([1, 1, 3.82380798316828]);

translate([15, 1, 0]) cube([1, 1, 3.776934557372777]);

translate([16, 1, 0]) cube([1, 1, 3.9251589625850336]);

translate([17, 1, 0]) cube([1, 1, 3.7520435803892367]);

translate([18, 1, 0]) cube([1, 1, 3.846190476190476]);

translate([19, 1, 0]) cube([1, 1, 4.007142857142857]);

translate([0, 2, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.206373276812207]);

translate([4, 2, 0]) cube([1, 1, 5.1100611587427025]);

translate([5, 2, 0]) cube([1, 1, 4.807401688980091]);

translate([6, 2, 0]) cube([1, 1, 4.272409976909582]);

translate([7, 2, 0]) cube([1, 1, 4.270960322460204]);

translate([8, 2, 0]) cube([1, 1, 4.472674321464191]);

translate([9, 2, 0]) cube([1, 1, 4.081695514860724]);

translate([10, 2, 0]) cube([1, 1, 4.5591974988349975]);

translate([11, 2, 0]) cube([1, 1, 4.189503836413026]);

translate([12, 2, 0]) cube([1, 1, 4.404987764550266]);

translate([13, 2, 0]) cube([1, 1, 4.255136021352987]);

translate([14, 2, 0]) cube([1, 1, 3.4229091561152063]);

translate([15, 2, 0]) cube([1, 1, 3.843359002177443]);

translate([16, 2, 0]) cube([1, 1, 3.769767626151435]);

translate([17, 2, 0]) cube([1, 1, 3.7527134807493234]);

translate([18, 2, 0]) cube([1, 1, 3.752259794196218]);

translate([19, 2, 0]) cube([1, 1, 3.7524003815811864]);

translate([0, 3, 0]) cube([1, 1, 7.4]);

translate([1, 3, 0]) cube([1, 1, 6.600014702125832]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.218605185407415]);

translate([6, 3, 0]) cube([1, 1, 4.732926908079789]);

translate([7, 3, 0]) cube([1, 1, 4.809953799129069]);

translate([8, 3, 0]) cube([1, 1, 5.207070074242322]);

translate([9, 3, 0]) cube([1, 1, 5.128190363366231]);

translate([10, 3, 0]) cube([1, 1, 4.3519051373404]);

translate([11, 3, 0]) cube([1, 1, 4.753182870370371]);

translate([12, 3, 0]) cube([1, 1, 4.056322567021793]);

translate([13, 3, 0]) cube([1, 1, 4.059878939533236]);

translate([14, 3, 0]) cube([1, 1, 3.906164423068857]);

translate([15, 3, 0]) cube([1, 1, 3.866030929539982]);

translate([16, 3, 0]) cube([1, 1, 3.783418789517837]);

translate([17, 3, 0]) cube([1, 1, 3.7536155276509495]);

translate([18, 3, 0]) cube([1, 1, 3.7524851750411043]);

translate([19, 3, 0]) cube([1, 1, 3.752555076228107]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.2]);

translate([2, 4, 0]) cube([1, 1, 6.900058808503328]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.326547890307418]);

translate([7, 4, 0]) cube([1, 1, 5.4113007182570545]);

color([0,1,0])
translate([8, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 4, 0]) cube([1, 1, 6]);

translate([10, 4, 0]) cube([1, 1, 4.525231944862614]);

translate([11, 4, 0]) cube([1, 1, 4.424318181608239]);

translate([12, 4, 0]) cube([1, 1, 4.079402058635045]);

translate([13, 4, 0]) cube([1, 1, 4.053162650667307]);

translate([14, 4, 0]) cube([1, 1, 3.919206909176951]);

translate([15, 4, 0]) cube([1, 1, 3.8881534426626656]);

translate([16, 4, 0]) cube([1, 1, 3.903174603174603]);

translate([17, 4, 0]) cube([1, 1, 4.1]);

translate([18, 4, 0]) cube([1, 1, 4.0]);

translate([19, 4, 0]) cube([1, 1, 3.9]);

translate([0, 5, 0]) cube([1, 1, 7.9]);

translate([1, 5, 0]) cube([1, 1, 7.4]);

translate([2, 5, 0]) cube([1, 1, 7.000352851019965]);

translate([3, 5, 0]) cube([1, 1, 6.638534261934734]);

translate([4, 5, 0]) cube([1, 1, 6.553059903549363]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 5, 0]) cube([1, 1, 6]);

translate([10, 5, 0]) cube([1, 1, 4.675546746810733]);

translate([11, 5, 0]) cube([1, 1, 4.408943707533984]);

translate([12, 5, 0]) cube([1, 1, 4.530128872267512]);

translate([13, 5, 0]) cube([1, 1, 4.166589698623622]);

translate([14, 5, 0]) cube([1, 1, 4.412131542081893]);

translate([15, 5, 0]) cube([1, 1, 4.6]);

translate([16, 5, 0]) cube([1, 1, 4.6]);

translate([17, 5, 0]) cube([1, 1, 4.7]);

translate([18, 5, 0]) cube([1, 1, 4.5]);

translate([19, 5, 0]) cube([1, 1, 4.5]);

translate([0, 6, 0]) cube([1, 1, 7.9]);

translate([1, 6, 0]) cube([1, 1, 7.2021171061197915]);

translate([2, 6, 0]) cube([1, 1, 6.7820107238723395]);

translate([3, 6, 0]) cube([1, 1, 6.672349920128589]);

translate([4, 6, 0]) cube([1, 1, 6.838366460494099]);

translate([5, 6, 0]) cube([1, 1, 6.621485737434294]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 6, 0]) cube([1, 1, 6]);

translate([10, 6, 0]) cube([1, 1, 4.743810006799627]);

translate([11, 6, 0]) cube([1, 1, 5.065332540161996]);

translate([12, 6, 0]) cube([1, 1, 4.860863335710588]);

translate([13, 6, 0]) cube([1, 1, 4.660657711770444]);

translate([14, 6, 0]) cube([1, 1, 5.1]);

translate([15, 6, 0]) cube([1, 1, 5.4]);

translate([16, 6, 0]) cube([1, 1, 5.3]);

translate([17, 6, 0]) cube([1, 1, 5.1]);

translate([18, 6, 0]) cube([1, 1, 4.9]);

translate([19, 6, 0]) cube([1, 1, 5.2]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.4084684244791665]);

translate([2, 7, 0]) cube([1, 1, 6.988279775329727]);

translate([3, 7, 0]) cube([1, 1, 6.575916962064256]);

translate([4, 7, 0]) cube([1, 1, 7.236830357142857]);

translate([5, 7, 0]) cube([1, 1, 6.8537176069687975]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

translate([11, 7, 0]) cube([1, 1, 5.059789957392385]);

translate([12, 7, 0]) cube([1, 1, 4.942536664245013]);

translate([13, 7, 0]) cube([1, 1, 4.852921323890817]);

translate([14, 7, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 8.1]);

translate([1, 8, 0]) cube([1, 1, 7.504910714285714]);

translate([2, 8, 0]) cube([1, 1, 7.428962983630953]);

translate([3, 8, 0]) cube([1, 1, 6.906289330655675]);

translate([4, 8, 0]) cube([1, 1, 6.896795295318603]);

translate([5, 8, 0]) cube([1, 1, 7.032470975974096]);

translate([6, 8, 0]) cube([1, 1, 6.821798253053187]);

translate([7, 8, 0]) cube([1, 1, 6.704327732182823]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

translate([11, 8, 0]) cube([1, 1, 5.308447913094793]);

translate([12, 8, 0]) cube([1, 1, 5.209308734342225]);

translate([13, 8, 0]) cube([1, 1, 5.103457988873902]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 8, 0]) cube([1, 1, 6]);

translate([17, 8, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([18, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 8.1]);

translate([1, 9, 0]) cube([1, 1, 7.8]);

translate([2, 9, 0]) cube([1, 1, 7.6]);

translate([3, 9, 0]) cube([1, 1, 7.439643787202382]);

translate([4, 9, 0]) cube([1, 1, 7.144591952992134]);

translate([5, 9, 0]) cube([1, 1, 7.027000129611795]);

translate([6, 9, 0]) cube([1, 1, 7.008495872226556]);

color([0,1,0])
translate([7, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

translate([9, 9, 0]) cube([1, 1, 6.516417172619048]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 6.9]);

translate([18, 9, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.7]);

translate([1, 10, 0]) cube([1, 1, 7.3]);

translate([2, 10, 0]) cube([1, 1, 7.207928757440477]);

translate([3, 10, 0]) cube([1, 1, 6.818432899526997]);

translate([4, 10, 0]) cube([1, 1, 6.536871561516553]);

translate([5, 10, 0]) cube([1, 1, 6.617817476732908]);

translate([6, 10, 0]) cube([1, 1, 6.808999428834049]);

translate([7, 10, 0]) cube([1, 1, 6.635763105732323]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

translate([9, 10, 0]) cube([1, 1, 6.604583333333333]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 6.6]);

translate([18, 10, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 6.9]);

translate([1, 11, 0]) cube([1, 1, 6.701982189360119]);

translate([2, 11, 0]) cube([1, 1, 6.6056687692655185]);

color([0,1,0])
translate([3, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.5209199831037505]);

translate([8, 11, 0]) cube([1, 1, 6.704583333333334]);

translate([9, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

translate([12, 11, 0]) cube([1, 1, 5.3030203726759595]);

translate([13, 11, 0]) cube([1, 1, 5.205426173004803]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 6.8]);

translate([1, 12, 0]) cube([1, 1, 6.50255031954188]);

color([0,1,0])
translate([2, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 12, 0]) cube([1, 1, 6]);

translate([4, 12, 0]) cube([1, 1, 5.431087201686496]);

translate([5, 12, 0]) cube([1, 1, 5.436712270452325]);

color([0,1,0])
translate([6, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 12, 0]) cube([1, 1, 6]);

translate([8, 12, 0]) cube([1, 1, 6.8]);

translate([9, 12, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

translate([13, 12, 0]) cube([1, 1, 5.2055175918137655]);

translate([14, 12, 0]) cube([1, 1, 5.400038022102096]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 7.1]);

translate([1, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 13, 0]) cube([1, 1, 6]);

translate([3, 13, 0]) cube([1, 1, 5.412711233400862]);

translate([4, 13, 0]) cube([1, 1, 5.361342112194196]);

color([0,1,0])
translate([5, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

translate([8, 13, 0]) cube([1, 1, 6.6]);

translate([9, 13, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

translate([14, 13, 0]) cube([1, 1, 5.300076658208683]);

translate([15, 13, 0]) cube([1, 1, 5.300076662536177]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

translate([19, 13, 0]) cube([1, 1, 5.3]);

translate([0, 14, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

translate([2, 14, 0]) cube([1, 1, 5.408586421444937]);

translate([3, 14, 0]) cube([1, 1, 5.36143850252177]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

translate([8, 14, 0]) cube([1, 1, 6.7]);

translate([9, 14, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

translate([19, 14, 0]) cube([1, 1, 5.000000051435144]);

translate([0, 15, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 15, 0]) cube([1, 1, 6]);

translate([7, 15, 0]) cube([1, 1, 6.8]);

translate([8, 15, 0]) cube([1, 1, 7.1]);

translate([9, 15, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

translate([17, 15, 0]) cube([1, 1, 5.400000161611945]);

translate([18, 15, 0]) cube([1, 1, 5.10000010378739]);

translate([19, 15, 0]) cube([1, 1, 4.700000211341357]);

color([0,1,0])
translate([0, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 16, 0]) cube([1, 1, 6]);

translate([7, 16, 0]) cube([1, 1, 7.0]);

translate([8, 16, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([9, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

translate([16, 16, 0]) cube([1, 1, 5.4000002511686525]);

translate([17, 16, 0]) cube([1, 1, 5.400000170557008]);

translate([18, 16, 0]) cube([1, 1, 5.200000083872104]);

translate([19, 16, 0]) cube([1, 1, 4.700000215412773]);

color([0,1,0])
translate([0, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

translate([6, 17, 0]) cube([1, 1, 6.7]);

translate([7, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

translate([16, 18, 0]) cube([1, 1, 5.400000006041804]);

translate([17, 18, 0]) cube([1, 1, 5.300000016921299]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 5.4]);

translate([1, 19, 0]) cube([1, 1, 5.3]);

translate([2, 19, 0]) cube([1, 1, 5.3]);

translate([3, 19, 0]) cube([1, 1, 5.1]);

translate([4, 19, 0]) cube([1, 1, 5.0]);

translate([5, 19, 0]) cube([1, 1, 5.3]);

translate([6, 19, 0]) cube([1, 1, 5.3]);

translate([7, 19, 0]) cube([1, 1, 5.0]);

translate([8, 19, 0]) cube([1, 1, 5.0]);

translate([9, 19, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

translate([14, 19, 0]) cube([1, 1, 5.200000015235583]);

translate([15, 19, 0]) cube([1, 1, 5.3000000114607495]);

translate([16, 19, 0]) cube([1, 1, 5.300000015215426]);

translate([17, 19, 0]) cube([1, 1, 5.400000001520006]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);
