
hull() {
    translate([14.69555, 7.5563, 8.99625]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.615450000000001, 8.5697, 8.92875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.597850000000001, 8.68095, 8.92125]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.361150000000002, 9.67005, 8.85375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.326350000000001, 9.777199999999999, 8.84625]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.93665, 10.7168, 8.77875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.8855, 10.81715, 8.77125]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.3545, 11.68385, 8.70375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.2883, 11.77495, 8.69625]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.627699999999999, 12.54805, 8.62875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.54805, 12.627699999999999, 8.62125]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.77495, 13.2883, 8.55375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.68385, 13.3545, 8.54625]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.81715, 13.8855, 8.47875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.7168, 13.93665, 8.47125]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.777199999999999, 14.326350000000001, 8.40375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.67005, 14.361150000000002, 8.39625]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.68095, 14.597850000000001, 8.32875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.5697, 14.615450000000001, 8.32125]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.5563, 14.69555, 8.25375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.4437, 14.69555, 8.24625]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.4303, 14.615450000000001, 8.17875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.31905, 14.597850000000001, 8.17125]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.32995, 14.361150000000002, 8.10375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2228, 14.326350000000001, 8.09625]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.2832, 13.93665, 8.02875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.18285, 13.8855, 8.02125]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.31615, 13.3545, 7.95375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.22505, 13.2883, 7.94625]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.45195, 12.627699999999999, 7.87875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3723, 12.54805, 7.871250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7117, 11.77495, 7.80375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.6455, 11.68385, 7.79625]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.1145, 10.81715, 7.72875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.06335, 10.7168, 7.7212499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.67365, 9.777199999999999, 7.6537500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.63885, 9.67005, 7.646250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.40215, 8.68095, 7.57875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.38455, 8.5697, 7.57125]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.30445, 7.5563, 7.50375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.30445, 7.4437, 7.49625]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.38455, 6.4303, 7.42875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.40215, 6.31905, 7.421250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.63885, 5.32995, 7.35375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.67365, 5.2228, 7.34625]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.06335, 4.2832, 7.2787500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1145, 4.18285, 7.27125]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6455, 3.31615, 7.20375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.7117, 3.22505, 7.196250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3723, 2.45195, 7.12875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.45195, 2.3723, 7.121250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.22505, 1.7117, 7.05375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.31615, 1.6455, 7.04625]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.18285, 1.1145, 6.97875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.2832, 1.06335, 6.9712499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2228, 0.67365, 6.9037500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.32995, 0.63885, 6.896250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.31905, 0.40215, 6.82875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.4303, 0.38455, 6.82125]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.4437, 0.30445, 6.75375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.5563, 0.30445, 6.74625]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.5697, 0.38455, 6.678750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.68095, 0.40215, 6.671250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.67005, 0.63885, 6.60375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.777199999999999, 0.67365, 6.5962499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.7168, 1.06335, 6.5287500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.81715, 1.1145, 6.52125]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.68385, 1.6455, 6.453750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.77495, 1.7117, 6.446250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.54805, 2.3723, 6.37875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.627699999999999, 2.45195, 6.37125]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.2883, 3.22505, 6.30375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.3545, 3.31615, 6.29625]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.8855, 4.18285, 6.22875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.93665, 4.2832, 6.22125]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.326350000000001, 5.2228, 6.1537500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.361150000000002, 5.32995, 6.14625]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.597850000000001, 6.31905, 6.07875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.615450000000001, 6.4303, 6.07125]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.69555, 7.4437, 6.00375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.69555, 7.5563, 5.996250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.615450000000001, 8.5697, 5.92875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.597850000000001, 8.68095, 5.92125]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.361150000000002, 9.67005, 5.85375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.326350000000001, 9.777199999999999, 5.8462499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.93665, 10.7168, 5.7787500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.8855, 10.81715, 5.771250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.3545, 11.68385, 5.70375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.2883, 11.77495, 5.69625]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.627699999999999, 12.54805, 5.62875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.54805, 12.627699999999999, 5.62125]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.77495, 13.2883, 5.55375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.68385, 13.3545, 5.54625]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.81715, 13.8855, 5.47875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.7168, 13.93665, 5.47125]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.777199999999999, 14.326350000000001, 5.4037500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.67005, 14.361150000000002, 5.39625]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.68095, 14.597850000000001, 5.32875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.5697, 14.615450000000001, 5.32125]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.5563, 14.69555, 5.25375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.4437, 14.69555, 5.246250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.4303, 14.615450000000001, 5.17875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.31905, 14.597850000000001, 5.17125]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.32995, 14.361150000000002, 5.10375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2228, 14.326350000000001, 5.0962499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.2832, 13.93665, 5.0287500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.18285, 13.8855, 5.021250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.31615, 13.3545, 4.95375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.22505, 13.2883, 4.94625]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.45195, 12.627699999999999, 4.87875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3723, 12.54805, 4.87125]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7117, 11.77495, 4.80375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.6455, 11.68385, 4.796250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.1145, 10.81715, 4.72875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.06335, 10.7168, 4.7212499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.67365, 9.777199999999999, 4.6537500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.63885, 9.67005, 4.64625]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.40215, 8.68095, 4.57875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.38455, 8.5697, 4.571250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.30445, 7.5563, 4.50375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.30445, 7.4437, 4.49625]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.38455, 6.4303, 4.42875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.40215, 6.31905, 4.42125]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.63885, 5.32995, 4.35375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.67365, 5.2228, 4.3462499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.06335, 4.2832, 4.2787500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1145, 4.18285, 4.27125]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6455, 3.31615, 4.20375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.7117, 3.22505, 4.19625]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3723, 2.45195, 4.12875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.45195, 2.3723, 4.12125]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.22505, 1.7117, 4.05375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.31615, 1.6455, 4.04625]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.18285, 1.1145, 3.9787500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.2832, 1.06335, 3.9712500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2228, 0.67365, 3.9037499999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.32995, 0.63885, 3.8962499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.31905, 0.40215, 3.8287500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.4303, 0.38455, 3.8212500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.4437, 0.30445, 3.75375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.5563, 0.30445, 3.74625]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.5697, 0.38455, 3.67875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.68095, 0.40215, 3.67125]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.67005, 0.63885, 3.6037500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.777199999999999, 0.67365, 3.5962500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.7168, 1.06335, 3.52875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.81715, 1.1145, 3.5212499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.68385, 1.6455, 3.4537500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.77495, 1.7117, 3.4462500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.54805, 2.3723, 3.37875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.627699999999999, 2.45195, 3.37125]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.2883, 3.22505, 3.30375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.3545, 3.31615, 3.2962499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.8855, 4.18285, 3.2287500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.93665, 4.2832, 3.2212500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.326350000000001, 5.2228, 3.15375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.361150000000002, 5.32995, 3.14625]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.597850000000001, 6.31905, 3.0787500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.615450000000001, 6.4303, 3.07125]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.69555, 7.4437, 3.00375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.69555, 7.5563, 2.9962500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.615450000000001, 8.5697, 2.92875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.597850000000001, 8.68095, 2.9212499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.361150000000002, 9.67005, 2.85375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.326350000000001, 9.777199999999999, 2.84625]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.93665, 10.7168, 2.77875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.8855, 10.81715, 2.77125]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.3545, 11.68385, 2.7037500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.2883, 11.77495, 2.69625]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.627699999999999, 12.54805, 2.62875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.54805, 12.627699999999999, 2.6212500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.77495, 13.2883, 2.55375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.68385, 13.3545, 2.54625]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.81715, 13.8855, 2.4787500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.7168, 13.93665, 2.47125]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.777199999999999, 14.326350000000001, 2.40375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.67005, 14.361150000000002, 2.39625]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.68095, 14.597850000000001, 2.3287500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.5697, 14.615450000000001, 2.32125]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.5563, 14.69555, 2.25375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.4437, 14.69555, 2.24625]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.4303, 14.615450000000001, 2.17875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.31905, 14.597850000000001, 2.1712499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.32995, 14.361150000000002, 2.1037500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2228, 14.326350000000001, 2.09625]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.2832, 13.93665, 2.02875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.18285, 13.8855, 2.02125]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.31615, 13.3545, 1.9537499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.22505, 13.2883, 1.94625]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.45195, 12.627699999999999, 1.8787500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3723, 12.54805, 1.87125]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7117, 11.77495, 1.8037500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.6455, 11.68385, 1.7962500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.1145, 10.81715, 1.7287500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.06335, 10.7168, 1.7212500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.67365, 9.777199999999999, 1.6537499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.63885, 9.67005, 1.6462499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.40215, 8.68095, 1.5787499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.38455, 8.5697, 1.57125]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.30445, 7.5563, 1.5037500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.30445, 7.4437, 1.49625]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.38455, 6.4303, 1.42875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.40215, 6.31905, 1.42125]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.63885, 5.32995, 1.35375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.67365, 5.2228, 1.3462500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.06335, 4.2832, 1.27875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1145, 4.18285, 1.27125]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6455, 3.31615, 1.20375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.7117, 3.22505, 1.19625]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3723, 2.45195, 1.12875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.45195, 2.3723, 1.1212499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.22505, 1.7117, 1.05375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.31615, 1.6455, 1.0462500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.18285, 1.1145, 0.97875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.2832, 1.06335, 0.97125]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2228, 0.67365, 0.90375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.32995, 0.63885, 0.8962500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.31905, 0.40215, 0.82875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.4303, 0.38455, 0.8212499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.4437, 0.30445, 0.75375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.5563, 0.30445, 0.7462500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.5697, 0.38455, 0.6787500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.68095, 0.40215, 0.67125]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.67005, 0.63885, 0.60375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.777199999999999, 0.67365, 0.5962500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.7168, 1.06335, 0.52875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.81715, 1.1145, 0.52125]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.68385, 1.6455, 0.45375000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.77495, 1.7117, 0.44625000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.54805, 2.3723, 0.37875000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.627699999999999, 2.45195, 0.37125]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.2883, 3.22505, 0.30375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.3545, 3.31615, 0.29625]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.8855, 4.18285, 0.22875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.93665, 4.2832, 0.22125]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.326350000000001, 5.2228, 0.15375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.361150000000002, 5.32995, 0.14625000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.597850000000001, 6.31905, 0.07875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.615450000000001, 6.4303, 0.07125000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.69555, 7.4437, 0.00375]) cube([0.4, 0.4, 0.1], center=true);
}

