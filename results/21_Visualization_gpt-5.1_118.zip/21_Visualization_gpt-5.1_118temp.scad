
hull() {
    translate([1.045, 1.0, 8.994]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.855, 1.0, 8.886000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.9449999999999998, 1.0, 8.868]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.755, 1.0, 8.652000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.845, 1.0, 8.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6550000000000002, 1.0, 8.298]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.745, 1.0, 8.256]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.555, 1.0, 7.824]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.645, 1.0, 7.77]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.455, 1.0, 7.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.545, 1.0, 7.164000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.355, 1.0, 6.516000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.445, 1.0, 6.438000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.255000000000001, 1.0, 5.6819999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.345000000000001, 1.0, 5.592]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.155, 1.0, 4.728]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.245, 1.0, 4.6259999999999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.055, 1.0, 3.6540000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.145, 1.0, 3.54]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.955, 1.0, 2.46]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.045, 1.0, 2.334]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.855, 1.0, 1.1460000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.945, 1.0, 1.058]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.755, 1.0, 0.6620000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.845, 1.0, 0.6220000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.655, 1.0, 0.29800000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.745, 1.0, 0.2720000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.555, 1.0, 0.128]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.645, 1.0, 0.11599999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.455000000000002, 1.0, 0.044000000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 1.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 1.9500000000000002, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 2.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 2.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 3.0500000000000003, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 3.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 4.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 4.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 5.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 5.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 6.050000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 6.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 7.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 7.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 8.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 8.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 9.049999999999999, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 9.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 10.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 10.950000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 11.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 11.950000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 12.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 12.950000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 13.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 13.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.455000000000002, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.645, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.555, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.745, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.655, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.845, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.755, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.945, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.855, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.045, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.955, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.145, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.055, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.245, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.155, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.345000000000001, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.255000000000001, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.445, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.355, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.545, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.455, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.645, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.555, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.745, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6550000000000002, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.845, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.755, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9449999999999998, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.855, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.045, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 13.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 13.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 12.950000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 12.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 11.950000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 11.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 10.950000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 10.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 9.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 9.049999999999999, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 8.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 8.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 7.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 7.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 6.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 6.050000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 5.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 5.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 4.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 4.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 3.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 3.0500000000000003, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 2.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 2.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 1.9500000000000002, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 1.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.045, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.855, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.9449999999999998, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.755, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.845, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6550000000000002, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.745, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.555, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.645, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.455, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.545, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.355, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.445, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.255000000000001, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.345000000000001, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.155, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.245, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.055, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.145, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.955, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 1.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 1.9500000000000002, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 2.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 2.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 3.0500000000000003, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 3.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 4.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 4.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 5.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 5.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 6.050000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 6.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 7.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 7.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 8.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 8.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 9.049999999999999, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 9.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 10.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 10.950000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 11.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 11.950000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 12.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 12.950000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 13.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 13.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.955, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.145, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.055, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.245, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.155, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.345000000000001, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.255000000000001, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.445, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.355, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.545, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.455, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.645, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.555, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.745, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6550000000000002, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.845, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.755, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9449999999999998, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.855, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.045, 14.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 13.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 13.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 12.950000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 12.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 11.950000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 11.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 10.950000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 10.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 9.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 9.049999999999999, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 8.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 8.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 7.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 7.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 6.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 6.050000000000001, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 5.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 5.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 4.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 4.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 3.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 3.0500000000000003, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 2.95, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 2.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0, 1.9500000000000002, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0, 1.05, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.045, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.855, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.9449999999999998, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.755, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.845, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6550000000000002, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.745, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.555, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.645, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.455, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.545, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.355, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.445, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.255000000000001, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.345000000000001, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.155, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.245, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.055, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.145, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.955, 1.0, 0.04000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.045, 1.0, 0.03950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.855, 1.0, 0.0305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.945, 1.0, 0.0295]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.755, 1.0, 0.020500000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.845, 1.0, 0.019500000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.655, 1.0, 0.0105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.745, 1.0, 0.009750000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.555, 1.0, 0.00525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.645, 1.0, 0.004750000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.455000000000002, 1.0, 0.00025]) cube([0.4, 0.4, 0.1], center=true);
}

