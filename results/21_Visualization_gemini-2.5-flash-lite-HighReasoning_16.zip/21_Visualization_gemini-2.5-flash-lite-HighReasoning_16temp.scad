
hull() {
    translate([5.0, 5.0, 4.925]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 5.0, 3.575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0035, 5.0035, 3.425]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0665000000000004, 5.0665000000000004, 2.075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.073500000000001, 5.073500000000001, 1.925]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.1365, 5.1365, 0.575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.1434999999999995, 5.1434999999999995, 0.47500000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2065, 5.2065, 0.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2135, 5.2135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2765, 5.2765, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.283500000000001, 5.283500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.3465, 5.3465, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.3534999999999995, 5.3534999999999995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.4165, 5.4165, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.4235, 5.4235, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.4865, 5.4865, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.493500000000001, 5.493500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.5565, 5.5565, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.5634999999999994, 5.5634999999999994, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.6265, 5.6265, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.6335, 5.6335, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.6965, 5.6965, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.7035, 5.7035, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.7665, 5.7665, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.773499999999999, 5.773499999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.8365, 5.8365, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.843500000000001, 5.843500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.9065, 5.9065, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.9135, 5.9135, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.976500000000001, 5.976500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}

