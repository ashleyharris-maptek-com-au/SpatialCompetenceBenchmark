
hull() {
    translate([50.0, 50.0, 94.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 94.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 93.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 93.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 92.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 92.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 91.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 91.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 90.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 90.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 89.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 89.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 88.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 88.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 87.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 87.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 86.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 86.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 85.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 85.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 84.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 84.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 83.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 83.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 82.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 82.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 81.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 81.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 80.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 80.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 79.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 79.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 78.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 78.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 77.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 77.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 76.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 76.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 75.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 75.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 74.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 74.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 74.00000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 74.00000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.00005, 74.00000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.00095, 74.00000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.00595, 74.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.09505, 74.095]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.120000000000005, 74.12]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.480000000000004, 74.47999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.525000000000006, 74.52499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.975, 74.975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 51.05, 75.05]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 51.95, 75.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 52.050000000000004, 76.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 52.95, 76.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 53.050000000000004, 77.05]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 53.95, 77.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 54.050000000000004, 78.05]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 54.95, 78.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 55.05, 79.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 55.95, 79.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 56.05, 80.05]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 56.95, 80.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 57.050000000000004, 81.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 57.95, 81.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 58.02, 82.02]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 58.38, 82.38000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 58.38, 82.38000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 58.02, 82.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 57.95, 81.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 57.050000000000004, 81.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 56.95, 80.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 56.05, 80.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 55.95, 79.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 55.05, 79.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 54.95, 78.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 54.050000000000004, 78.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 53.95, 77.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 53.050000000000004, 77.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 52.95, 76.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 52.050000000000004, 76.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 51.95, 75.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 51.05, 75.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.975, 74.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.525000000000006, 74.52499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.480000000000004, 74.47999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.120000000000005, 74.12]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.09505, 74.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.00595, 74.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.00095, 74.00000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.00005, 74.00000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 74.00000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 74.00000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 73.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 73.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 72.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 72.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 71.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 71.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 70.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 70.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 69.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 69.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 68.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 68.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 67.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 67.05000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 66.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 66.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 65.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 65.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 64.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 64.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 63.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 63.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 62.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 62.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 61.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 61.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 60.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 60.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 59.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 59.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 58.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 58.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 57.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 57.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 56.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 56.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 55.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 55.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 54.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 54.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 53.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 53.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 52.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 52.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 51.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 51.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 50.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 50.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 49.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 49.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 48.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 48.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 47.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 47.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 46.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 46.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 45.949999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 45.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 44.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 44.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 43.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 43.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 42.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 42.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 41.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 41.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 40.949999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 40.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 39.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 39.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 38.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 38.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 37.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 37.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 36.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 36.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 35.949999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 35.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 34.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 34.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 33.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 33.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 32.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 32.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 31.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 31.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 30.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 30.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 29.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 29.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 28.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 28.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 27.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 27.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 26.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 26.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 25.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 25.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 24.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 24.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 23.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 23.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 22.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 22.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 21.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 21.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 20.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 20.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 19.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 19.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 18.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 18.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 17.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 17.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 16.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 16.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 15.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 15.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 14.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 14.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 13.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 13.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 12.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 12.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 11.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 11.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 10.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 10.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 9.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 9.049999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 8.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 8.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 7.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 7.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 6.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 6.050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 5.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 5.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 4.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 4.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 3.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 3.0500000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 2.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 2.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 1.9500000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 1.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 50.0, 0.9500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.0, 0.05]) cube([0.4, 0.4, 0.1], center=true);
}

