
translate([0, 0, 0]) cube([1, 1, 5.0010666666666665]);

translate([1, 0, 0]) cube([1, 1, 4.30561917989418]);

translate([2, 0, 0]) cube([1, 1, 4.2173334138322]);

translate([3, 0, 0]) cube([1, 1, 4.048883938624453]);

translate([4, 0, 0]) cube([1, 1, 4.049219952313599]);

translate([5, 0, 0]) cube([1, 1, 4.061751106553149]);

translate([6, 0, 0]) cube([1, 1, 4.206256495451704]);

translate([7, 0, 0]) cube([1, 1, 4.5]);

translate([8, 0, 0]) cube([1, 1, 4.4]);

translate([9, 0, 0]) cube([1, 1, 4.2]);

translate([10, 0, 0]) cube([1, 1, 4.3]);

translate([11, 0, 0]) cube([1, 1, 4.7]);

translate([12, 0, 0]) cube([1, 1, 5.0]);

translate([13, 0, 0]) cube([1, 1, 5.2]);

translate([14, 0, 0]) cube([1, 1, 5.4]);

translate([15, 0, 0]) cube([1, 1, 5.4]);

translate([16, 0, 0]) cube([1, 1, 5.1]);

translate([17, 0, 0]) cube([1, 1, 4.7]);

translate([18, 0, 0]) cube([1, 1, 4.4]);

translate([19, 0, 0]) cube([1, 1, 4.3]);

translate([20, 0, 0]) cube([1, 1, 4.3]);

translate([21, 0, 0]) cube([1, 1, 4.4]);

translate([22, 0, 0]) cube([1, 1, 4.6]);

translate([23, 0, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.202133333333333]);

translate([2, 1, 0]) cube([1, 1, 4.70803835978836]);

translate([3, 1, 0]) cube([1, 1, 4.4188759546485255]);

translate([4, 1, 0]) cube([1, 1, 4.133656688062638]);

translate([5, 1, 0]) cube([1, 1, 4.138115381036144]);

translate([6, 1, 0]) cube([1, 1, 4.213273993600155]);

translate([7, 1, 0]) cube([1, 1, 4.210154015176103]);

translate([8, 1, 0]) cube([1, 1, 4.0084742537551605]);

translate([9, 1, 0]) cube([1, 1, 3.9379421933024426]);

translate([10, 1, 0]) cube([1, 1, 3.9691006813657923]);

translate([11, 1, 0]) cube([1, 1, 4.151372992392895]);

translate([12, 1, 0]) cube([1, 1, 4.404656296961779]);

translate([13, 1, 0]) cube([1, 1, 4.5]);

translate([14, 1, 0]) cube([1, 1, 4.7]);

translate([15, 1, 0]) cube([1, 1, 4.7]);

translate([16, 1, 0]) cube([1, 1, 4.5]);

translate([17, 1, 0]) cube([1, 1, 4.3]);

translate([18, 1, 0]) cube([1, 1, 4.1]);

translate([19, 1, 0]) cube([1, 1, 3.9]);

translate([20, 1, 0]) cube([1, 1, 3.603033491466145]);

translate([21, 1, 0]) cube([1, 1, 3.7015873015873018]);

translate([22, 1, 0]) cube([1, 1, 4.0]);

translate([23, 1, 0]) cube([1, 1, 4.1]);

translate([0, 2, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.2273917989418]);

translate([4, 2, 0]) cube([1, 1, 4.848282947845806]);

translate([5, 2, 0]) cube([1, 1, 4.833846710191483]);

translate([6, 2, 0]) cube([1, 1, 4.618915337049634]);

translate([7, 2, 0]) cube([1, 1, 4.2201103002951506]);

translate([8, 2, 0]) cube([1, 1, 3.9424066872562316]);

translate([9, 2, 0]) cube([1, 1, 4.008622999720785]);

translate([10, 2, 0]) cube([1, 1, 4.209337571204476]);

translate([11, 2, 0]) cube([1, 1, 4.168867800285163]);

translate([12, 2, 0]) cube([1, 1, 4.2546131882795235]);

translate([13, 2, 0]) cube([1, 1, 4.41862518784712]);

translate([14, 2, 0]) cube([1, 1, 4.315570141743115]);

translate([15, 2, 0]) cube([1, 1, 4.303114028267111]);

translate([16, 2, 0]) cube([1, 1, 4.100622805579172]);

translate([17, 2, 0]) cube([1, 1, 3.8031730287419814]);

translate([18, 2, 0]) cube([1, 1, 3.70063460546693]);

translate([19, 2, 0]) cube([1, 1, 3.6075131747558533]);

translate([20, 2, 0]) cube([1, 1, 3.4767290297347357]);

translate([21, 2, 0]) cube([1, 1, 3.4832620520479756]);

translate([22, 2, 0]) cube([1, 1, 3.7063492063492065]);

translate([23, 2, 0]) cube([1, 1, 3.702116402116402]);

translate([0, 3, 0]) cube([1, 1, 7.2]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

translate([4, 3, 0]) cube([1, 1, 5.4729589947089945]);

translate([5, 3, 0]) cube([1, 1, 5.456076908541195]);

translate([6, 3, 0]) cube([1, 1, 5.02356840356513]);

translate([7, 3, 0]) cube([1, 1, 4.523503704157415]);

translate([8, 3, 0]) cube([1, 1, 4.411719588119766]);

translate([9, 3, 0]) cube([1, 1, 4.602228514159817]);

translate([10, 3, 0]) cube([1, 1, 4.806364772631463]);

translate([11, 3, 0]) cube([1, 1, 4.74743214103508]);

translate([12, 3, 0]) cube([1, 1, 4.74947056082966]);

translate([13, 3, 0]) cube([1, 1, 4.643655379125344]);

translate([14, 3, 0]) cube([1, 1, 4.240967974770308]);

translate([15, 3, 0]) cube([1, 1, 4.023828522517654]);

translate([16, 3, 0]) cube([1, 1, 3.812069314239597]);

translate([17, 3, 0]) cube([1, 1, 3.430464967527863]);

translate([18, 3, 0]) cube([1, 1, 3.430481735386704]);

translate([19, 3, 0]) cube([1, 1, 3.510061970055291]);

translate([20, 3, 0]) cube([1, 1, 3.4637100867250523]);

translate([21, 3, 0]) cube([1, 1, 3.466317387195876]);

translate([22, 3, 0]) cube([1, 1, 3.5484877999764373]);

translate([23, 3, 0]) cube([1, 1, 3.621553779075653]);

translate([0, 4, 0]) cube([1, 1, 7.5]);

translate([1, 4, 0]) cube([1, 1, 6.9]);

translate([2, 4, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

translate([4, 4, 0]) cube([1, 1, 4.857226379440666]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.330476369992441]);

translate([7, 4, 0]) cube([1, 1, 4.916368336246537]);

translate([8, 4, 0]) cube([1, 1, 4.90468636977592]);

translate([9, 4, 0]) cube([1, 1, 5.200091428571429]);

color([0,1,0])
translate([10, 4, 0]) cube([1, 1, 6]);

translate([11, 4, 0]) cube([1, 1, 5.40000197041371]);

translate([12, 4, 0]) cube([1, 1, 4.103569209797331]);

translate([13, 4, 0]) cube([1, 1, 4.84870958550989]);

translate([14, 4, 0]) cube([1, 1, 4.235039140979936]);

translate([15, 4, 0]) cube([1, 1, 3.832781228013085]);

translate([16, 4, 0]) cube([1, 1, 3.6415215854809015]);

translate([17, 4, 0]) cube([1, 1, 3.4305855364129965]);

translate([18, 4, 0]) cube([1, 1, 3.430548666977654]);

translate([19, 4, 0]) cube([1, 1, 3.60777959810326]);

translate([20, 4, 0]) cube([1, 1, 2.7402951346241675]);

translate([21, 4, 0]) cube([1, 1, 3.591498712271307]);

translate([22, 4, 0]) cube([1, 1, 3.6302031128878003]);

translate([23, 4, 0]) cube([1, 1, 3.704853298879025]);

translate([0, 5, 0]) cube([1, 1, 7.9]);

translate([1, 5, 0]) cube([1, 1, 7.4]);

translate([2, 5, 0]) cube([1, 1, 7.1]);

translate([3, 5, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

translate([7, 5, 0]) cube([1, 1, 5.401828571428572]);

translate([8, 5, 0]) cube([1, 1, 5.400457142857143]);

color([0,1,0])
translate([9, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 5, 0]) cube([1, 1, 6]);

translate([12, 5, 0]) cube([1, 1, 5.400009852371098]);

translate([13, 5, 0]) cube([1, 1, 4.8476268129336795]);

translate([14, 5, 0]) cube([1, 1, 4.232868534674741]);

translate([15, 5, 0]) cube([1, 1, 3.8417994048408244]);

translate([16, 5, 0]) cube([1, 1, 3.6532341664979997]);

translate([17, 5, 0]) cube([1, 1, 3.7036834265309975]);

translate([18, 5, 0]) cube([1, 1, 3.9011211875102165]);

translate([19, 5, 0]) cube([1, 1, 4.000621327980521]);

translate([20, 5, 0]) cube([1, 1, 4.2004906291000434]);

translate([21, 5, 0]) cube([1, 1, 4.20040868245961]);

translate([22, 5, 0]) cube([1, 1, 4.100427516762329]);

translate([23, 5, 0]) cube([1, 1, 3.9004671602352508]);

translate([0, 6, 0]) cube([1, 1, 7.9]);

translate([1, 6, 0]) cube([1, 1, 7.4]);

translate([2, 6, 0]) cube([1, 1, 7.1]);

translate([3, 6, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([4, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 6, 0]) cube([1, 1, 6]);

translate([12, 6, 0]) cube([1, 1, 5.400059114466316]);

translate([13, 6, 0]) cube([1, 1, 4.908189010998346]);

translate([14, 6, 0]) cube([1, 1, 4.520343121319143]);

translate([15, 6, 0]) cube([1, 1, 4.122130675500413]);

translate([16, 6, 0]) cube([1, 1, 4.11343746818147]);

translate([17, 6, 0]) cube([1, 1, 4.40303899302733]);

translate([18, 6, 0]) cube([1, 1, 4.6008194852927335]);

translate([19, 6, 0]) cube([1, 1, 4.601126132159938]);

translate([20, 6, 0]) cube([1, 1, 4.70067039334989]);

translate([21, 6, 0]) cube([1, 1, 4.60075493710958]);

translate([22, 6, 0]) cube([1, 1, 4.500519765702658]);

translate([23, 6, 0]) cube([1, 1, 4.400454198539794]);

translate([0, 7, 0]) cube([1, 1, 7.9]);

translate([1, 7, 0]) cube([1, 1, 7.3]);

translate([2, 7, 0]) cube([1, 1, 6.9]);

translate([3, 7, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([4, 7, 0]) cube([1, 1, 6]);

translate([5, 7, 0]) cube([1, 1, 6.7]);

translate([6, 7, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

translate([13, 7, 0]) cube([1, 1, 5.0024852793293695]);

translate([14, 7, 0]) cube([1, 1, 4.807685421636589]);

translate([15, 7, 0]) cube([1, 1, 4.615385961163872]);

translate([16, 7, 0]) cube([1, 1, 4.612239665217196]);

translate([17, 7, 0]) cube([1, 1, 5.100954578515475]);

translate([18, 7, 0]) cube([1, 1, 5.301181236111249]);

translate([19, 7, 0]) cube([1, 1, 5.201593212852847]);

translate([20, 7, 0]) cube([1, 1, 5.101428085607497]);

translate([21, 7, 0]) cube([1, 1, 4.901001062172631]);

translate([22, 7, 0]) cube([1, 1, 4.900675144417889]);

translate([23, 7, 0]) cube([1, 1, 5.100167685498833]);

translate([0, 8, 0]) cube([1, 1, 8.1]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 6.9]);

translate([3, 8, 0]) cube([1, 1, 6.8]);

translate([4, 8, 0]) cube([1, 1, 7.0]);

translate([5, 8, 0]) cube([1, 1, 7.1]);

translate([6, 8, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

translate([13, 8, 0]) cube([1, 1, 5.011497493550077]);

translate([14, 8, 0]) cube([1, 1, 4.916255324305161]);

translate([15, 8, 0]) cube([1, 1, 4.730505371759176]);

translate([16, 8, 0]) cube([1, 1, 4.911074451746132]);

color([0,1,0])
translate([17, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 8.2]);

translate([1, 9, 0]) cube([1, 1, 7.6]);

translate([2, 9, 0]) cube([1, 1, 7.2]);

translate([3, 9, 0]) cube([1, 1, 7.3]);

translate([4, 9, 0]) cube([1, 1, 7.5]);

translate([5, 9, 0]) cube([1, 1, 7.4]);

translate([6, 9, 0]) cube([1, 1, 6.9]);

translate([7, 9, 0]) cube([1, 1, 6.6]);

translate([8, 9, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

translate([13, 9, 0]) cube([1, 1, 5.217970503492545]);

translate([14, 9, 0]) cube([1, 1, 5.117953080502106]);

translate([15, 9, 0]) cube([1, 1, 4.9261868366884585]);

translate([16, 9, 0]) cube([1, 1, 5.1123610003990825]);

color([0,1,0])
translate([17, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 8.1]);

translate([1, 10, 0]) cube([1, 1, 7.7]);

translate([2, 10, 0]) cube([1, 1, 7.5]);

translate([3, 10, 0]) cube([1, 1, 7.6]);

translate([4, 10, 0]) cube([1, 1, 7.6]);

translate([5, 10, 0]) cube([1, 1, 7.4]);

translate([6, 10, 0]) cube([1, 1, 7.0]);

translate([7, 10, 0]) cube([1, 1, 6.9]);

translate([8, 10, 0]) cube([1, 1, 6.9]);

translate([9, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

translate([14, 10, 0]) cube([1, 1, 5.428874265192117]);

translate([15, 10, 0]) cube([1, 1, 5.321280057366671]);

translate([16, 10, 0]) cube([1, 1, 5.4088999577206485]);

color([0,1,0])
translate([17, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

translate([20, 10, 0]) cube([1, 1, 6.605555555555555]);

translate([21, 10, 0]) cube([1, 1, 6.8]);

translate([22, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 8.1]);

translate([1, 11, 0]) cube([1, 1, 7.8]);

translate([2, 11, 0]) cube([1, 1, 7.6]);

translate([3, 11, 0]) cube([1, 1, 7.4]);

translate([4, 11, 0]) cube([1, 1, 7.2]);

translate([5, 11, 0]) cube([1, 1, 7.0]);

translate([6, 11, 0]) cube([1, 1, 7.0]);

translate([7, 11, 0]) cube([1, 1, 7.0]);

translate([8, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

translate([11, 11, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

translate([20, 11, 0]) cube([1, 1, 6.7]);

translate([21, 11, 0]) cube([1, 1, 7.0]);

translate([22, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 7.7]);

translate([1, 12, 0]) cube([1, 1, 7.4]);

translate([2, 12, 0]) cube([1, 1, 7.2]);

translate([3, 12, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([4, 12, 0]) cube([1, 1, 6]);

translate([5, 12, 0]) cube([1, 1, 6.578]);

translate([6, 12, 0]) cube([1, 1, 6.615]);

translate([7, 12, 0]) cube([1, 1, 6.8]);

translate([8, 12, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([9, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

translate([11, 12, 0]) cube([1, 1, 6.6]);

translate([12, 12, 0]) cube([1, 1, 5.062499199793296]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

translate([20, 12, 0]) cube([1, 1, 5.397867400928626]);

translate([21, 12, 0]) cube([1, 1, 6.7]);

translate([22, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 7.0]);

translate([1, 13, 0]) cube([1, 1, 6.8]);

translate([2, 13, 0]) cube([1, 1, 6.8]);

translate([3, 13, 0]) cube([1, 1, 6.608333333333333]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 13, 0]) cube([1, 1, 6]);

translate([9, 13, 0]) cube([1, 1, 6.6]);

translate([10, 13, 0]) cube([1, 1, 6.7]);

translate([11, 13, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

translate([15, 13, 0]) cube([1, 1, 5.390889103320687]);

translate([16, 13, 0]) cube([1, 1, 5.420060538432209]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 14, 0]) cube([1, 1, 6]);

translate([10, 14, 0]) cube([1, 1, 7.0]);

translate([11, 14, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

translate([15, 14, 0]) cube([1, 1, 5.379125083109213]);

translate([16, 14, 0]) cube([1, 1, 5.378156570163563]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 7.0]);

translate([1, 15, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

translate([5, 15, 0]) cube([1, 1, 5.412402240279269]);

translate([6, 15, 0]) cube([1, 1, 5.445867477239473]);

color([0,1,0])
translate([7, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

translate([10, 15, 0]) cube([1, 1, 6.9]);

translate([11, 15, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

translate([16, 15, 0]) cube([1, 1, 5.3782037108455825]);

translate([17, 15, 0]) cube([1, 1, 5.411965549573079]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

translate([23, 15, 0]) cube([1, 1, 5.425700267687156]);

translate([0, 16, 0]) cube([1, 1, 7.2]);

translate([1, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

translate([3, 16, 0]) cube([1, 1, 5.383997121971194]);

translate([4, 16, 0]) cube([1, 1, 5.384234647839483]);

translate([5, 16, 0]) cube([1, 1, 5.431283809618165]);

color([0,1,0])
translate([6, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 16, 0]) cube([1, 1, 6]);

translate([10, 16, 0]) cube([1, 1, 6.8]);

translate([11, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

translate([17, 16, 0]) cube([1, 1, 5.413254669239388]);

translate([18, 16, 0]) cube([1, 1, 5.39232889421449]);

translate([19, 16, 0]) cube([1, 1, 5.428125239854634]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

translate([23, 16, 0]) cube([1, 1, 5.12661381930877]);

translate([0, 17, 0]) cube([1, 1, 7.0]);

translate([1, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

translate([3, 17, 0]) cube([1, 1, 5.384770318136411]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

translate([9, 17, 0]) cube([1, 1, 6.6]);

translate([10, 17, 0]) cube([1, 1, 6.9]);

translate([11, 17, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 17, 0]) cube([1, 1, 6]);

translate([22, 17, 0]) cube([1, 1, 5.308152628949506]);

translate([23, 17, 0]) cube([1, 1, 4.930389740374424]);

translate([0, 18, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

translate([8, 18, 0]) cube([1, 1, 6.6]);

translate([9, 18, 0]) cube([1, 1, 7.0]);

translate([10, 18, 0]) cube([1, 1, 7.1]);

translate([11, 18, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([20, 18, 0]) cube([1, 1, 5.435194394923264]);

translate([21, 18, 0]) cube([1, 1, 5.334666945330984]);

translate([22, 18, 0]) cube([1, 1, 4.941716266797699]);

translate([23, 18, 0]) cube([1, 1, 4.765509777495026]);

color([0,1,0])
translate([0, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 19, 0]) cube([1, 1, 6]);

translate([8, 19, 0]) cube([1, 1, 6.8]);

translate([9, 19, 0]) cube([1, 1, 7.2]);

translate([10, 19, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

translate([19, 19, 0]) cube([1, 1, 5.460247470233577]);

translate([20, 19, 0]) cube([1, 1, 5.456174750024391]);

translate([21, 19, 0]) cube([1, 1, 5.360066522447116]);

translate([22, 19, 0]) cube([1, 1, 5.040969014006136]);

translate([23, 19, 0]) cube([1, 1, 4.765544591528545]);

color([0,1,0])
translate([0, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

translate([4, 20, 0]) cube([1, 1, 5.042795163209317]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 20, 0]) cube([1, 1, 6]);

translate([7, 20, 0]) cube([1, 1, 6.6]);

translate([8, 20, 0]) cube([1, 1, 6.8]);

translate([9, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

translate([12, 20, 0]) cube([1, 1, 5.273563555266684]);

color([0,1,0])
translate([13, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

translate([20, 20, 0]) cube([1, 1, 4.447717458755599]);

translate([21, 20, 0]) cube([1, 1, 5.542001150893974]);

translate([22, 20, 0]) cube([1, 1, 5.5179503254301405]);

translate([23, 20, 0]) cube([1, 1, 5.10919111316897]);

color([0,1,0])
translate([0, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

translate([20, 21, 0]) cube([1, 1, 5.4456495911399925]);

translate([21, 21, 0]) cube([1, 1, 5.53888331876599]);

translate([22, 21, 0]) cube([1, 1, 5.707083333333334]);

translate([23, 21, 0]) cube([1, 1, 5.702539682539683]);

color([0,1,0])
translate([0, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

translate([4, 22, 0]) cube([1, 1, 5.356747471618392]);

color([0,1,0])
translate([5, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

translate([17, 22, 0]) cube([1, 1, 5.401421163383223]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

translate([19, 22, 0]) cube([1, 1, 5.410809951557472]);

translate([20, 22, 0]) cube([1, 1, 5.351305443330846]);

translate([21, 22, 0]) cube([1, 1, 5.433138583635487]);

translate([22, 22, 0]) cube([1, 1, 5.704345238095239]);

translate([23, 22, 0]) cube([1, 1, 5.9]);

translate([0, 23, 0]) cube([1, 1, 5.32256074490233]);

translate([1, 23, 0]) cube([1, 1, 5.323022701409676]);

translate([2, 23, 0]) cube([1, 1, 5.325650374328767]);

translate([3, 23, 0]) cube([1, 1, 5.267657594739954]);

translate([4, 23, 0]) cube([1, 1, 5.133548795970397]);

translate([5, 23, 0]) cube([1, 1, 5.133362234124268]);

translate([6, 23, 0]) cube([1, 1, 5.207258779584993]);

translate([7, 23, 0]) cube([1, 1, 5.204825000217737]);

translate([8, 23, 0]) cube([1, 1, 5.002482766388329]);

translate([9, 23, 0]) cube([1, 1, 4.805594718680616]);

translate([10, 23, 0]) cube([1, 1, 5.002409289543517]);

translate([11, 23, 0]) cube([1, 1, 5.402710588959984]);

color([0,1,0])
translate([12, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 23, 0]) cube([1, 1, 6]);

translate([16, 23, 0]) cube([1, 1, 5.4015486548934035]);

translate([17, 23, 0]) cube([1, 1, 5.231726785008754]);

translate([18, 23, 0]) cube([1, 1, 5.233952917018789]);

translate([19, 23, 0]) cube([1, 1, 5.346556263725675]);

translate([20, 23, 0]) cube([1, 1, 5.350264451707872]);

translate([21, 23, 0]) cube([1, 1, 5.5015599017384735]);

translate([22, 23, 0]) cube([1, 1, 5.701894368858656]);

translate([23, 23, 0]) cube([1, 1, 5.703007369614513]);
