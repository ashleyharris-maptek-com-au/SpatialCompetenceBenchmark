
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.6]);

translate([2, 0, 0]) cube([1, 1, 4.3]);

translate([3, 0, 0]) cube([1, 1, 4.2]);

translate([4, 0, 0]) cube([1, 1, 4.2]);

translate([5, 0, 0]) cube([1, 1, 4.1]);

translate([6, 0, 0]) cube([1, 1, 4.0]);

translate([7, 0, 0]) cube([1, 1, 3.9000000469826013]);

translate([8, 0, 0]) cube([1, 1, 3.9000000472188785]);

translate([9, 0, 0]) cube([1, 1, 3.9000000508484693]);

translate([10, 0, 0]) cube([1, 1, 4.000000020805923]);

translate([11, 0, 0]) cube([1, 1, 4.100000013950817]);

translate([12, 0, 0]) cube([1, 1, 4.200000006604143]);

translate([13, 0, 0]) cube([1, 1, 4.3]);

translate([14, 0, 0]) cube([1, 1, 4.5]);

translate([15, 0, 0]) cube([1, 1, 4.5]);

translate([16, 0, 0]) cube([1, 1, 4.4]);

translate([17, 0, 0]) cube([1, 1, 4.3]);

translate([18, 0, 0]) cube([1, 1, 4.2]);

translate([19, 0, 0]) cube([1, 1, 4.2]);

translate([20, 0, 0]) cube([1, 1, 4.3]);

translate([21, 0, 0]) cube([1, 1, 4.4]);

translate([22, 0, 0]) cube([1, 1, 4.7]);

translate([23, 0, 0]) cube([1, 1, 4.9]);

translate([24, 0, 0]) cube([1, 1, 5.0]);

translate([25, 0, 0]) cube([1, 1, 5.1]);

translate([26, 0, 0]) cube([1, 1, 5.2]);

translate([27, 0, 0]) cube([1, 1, 5.3]);

translate([28, 0, 0]) cube([1, 1, 5.4]);

translate([29, 0, 0]) cube([1, 1, 5.4]);

translate([30, 0, 0]) cube([1, 1, 5.4]);

translate([31, 0, 0]) cube([1, 1, 5.3]);

translate([32, 0, 0]) cube([1, 1, 5.1]);

translate([33, 0, 0]) cube([1, 1, 4.9]);

translate([34, 0, 0]) cube([1, 1, 4.7]);

translate([35, 0, 0]) cube([1, 1, 4.6]);

translate([36, 0, 0]) cube([1, 1, 4.4]);

translate([37, 0, 0]) cube([1, 1, 4.4]);

translate([38, 0, 0]) cube([1, 1, 4.300033333333333]);

translate([39, 0, 0]) cube([1, 1, 4.300133333333333]);

translate([40, 0, 0]) cube([1, 1, 4.300666666666666]);

translate([41, 0, 0]) cube([1, 1, 4.303333333333333]);

translate([42, 0, 0]) cube([1, 1, 4.416666666666667]);

translate([43, 0, 0]) cube([1, 1, 4.208796296296296]);

translate([44, 0, 0]) cube([1, 1, 4.6]);

translate([45, 0, 0]) cube([1, 1, 4.7]);

translate([46, 0, 0]) cube([1, 1, 4.8]);

translate([47, 0, 0]) cube([1, 1, 4.9]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.0]);

translate([2, 1, 0]) cube([1, 1, 4.7]);

translate([3, 1, 0]) cube([1, 1, 4.5]);

translate([4, 1, 0]) cube([1, 1, 4.4]);

translate([5, 1, 0]) cube([1, 1, 4.3]);

translate([6, 1, 0]) cube([1, 1, 4.1]);

translate([7, 1, 0]) cube([1, 1, 4.0]);

translate([8, 1, 0]) cube([1, 1, 3.9000000489753543]);

translate([9, 1, 0]) cube([1, 1, 3.900000051956476]);

translate([10, 1, 0]) cube([1, 1, 3.9000000743121026]);

translate([11, 1, 0]) cube([1, 1, 4.000000072166736]);

translate([12, 1, 0]) cube([1, 1, 4.100000052715062]);

translate([13, 1, 0]) cube([1, 1, 4.200000028075263]);

translate([14, 1, 0]) cube([1, 1, 4.3]);

translate([15, 1, 0]) cube([1, 1, 4.3]);

translate([16, 1, 0]) cube([1, 1, 4.2]);

translate([17, 1, 0]) cube([1, 1, 4.0000003964100985]);

translate([18, 1, 0]) cube([1, 1, 3.900001289611731]);

translate([19, 1, 0]) cube([1, 1, 3.9000007727698787]);

translate([20, 1, 0]) cube([1, 1, 4.000000002663982]);

translate([21, 1, 0]) cube([1, 1, 4.1000000173546125]);

translate([22, 1, 0]) cube([1, 1, 4.4]);

translate([23, 1, 0]) cube([1, 1, 4.5]);

translate([24, 1, 0]) cube([1, 1, 4.7]);

translate([25, 1, 0]) cube([1, 1, 4.8]);

translate([26, 1, 0]) cube([1, 1, 4.9]);

translate([27, 1, 0]) cube([1, 1, 5.0]);

translate([28, 1, 0]) cube([1, 1, 5.0]);

translate([29, 1, 0]) cube([1, 1, 5.1]);

translate([30, 1, 0]) cube([1, 1, 5.0]);

translate([31, 1, 0]) cube([1, 1, 4.9]);

translate([32, 1, 0]) cube([1, 1, 4.8]);

translate([33, 1, 0]) cube([1, 1, 4.6]);

translate([34, 1, 0]) cube([1, 1, 4.5]);

translate([35, 1, 0]) cube([1, 1, 4.4]);

translate([36, 1, 0]) cube([1, 1, 4.3]);

translate([37, 1, 0]) cube([1, 1, 4.200006666666667]);

translate([38, 1, 0]) cube([1, 1, 4.100034666666667]);

translate([39, 1, 0]) cube([1, 1, 4.0001736]);

translate([40, 1, 0]) cube([1, 1, 3.9032584000000003]);

translate([41, 1, 0]) cube([1, 1, 3.9108600000000004]);

translate([42, 1, 0]) cube([1, 1, 4.0315]);

translate([43, 1, 0]) cube([1, 1, 4.128703703703703]);

translate([44, 1, 0]) cube([1, 1, 4.218055555555556]);

translate([45, 1, 0]) cube([1, 1, 4.3]);

translate([46, 1, 0]) cube([1, 1, 4.4]);

translate([47, 1, 0]) cube([1, 1, 4.5]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

translate([2, 2, 0]) cube([1, 1, 5.2]);

translate([3, 2, 0]) cube([1, 1, 4.9]);

translate([4, 2, 0]) cube([1, 1, 4.7]);

translate([5, 2, 0]) cube([1, 1, 4.6]);

translate([6, 2, 0]) cube([1, 1, 4.4]);

translate([7, 2, 0]) cube([1, 1, 4.2]);

translate([8, 2, 0]) cube([1, 1, 4.100000002028129]);

translate([9, 2, 0]) cube([1, 1, 4.000000019079751]);

translate([10, 2, 0]) cube([1, 1, 4.100000030685419]);

translate([11, 2, 0]) cube([1, 1, 4.100000062836516]);

translate([12, 2, 0]) cube([1, 1, 4.200000051764832]);

translate([13, 2, 0]) cube([1, 1, 4.200000044991369]);

translate([14, 2, 0]) cube([1, 1, 4.200000029288717]);

translate([15, 2, 0]) cube([1, 1, 4.100000570036088]);

translate([16, 2, 0]) cube([1, 1, 4.000001587756253]);

translate([17, 2, 0]) cube([1, 1, 3.9000047632876416]);

translate([18, 2, 0]) cube([1, 1, 3.8000276760605387]);

translate([19, 2, 0]) cube([1, 1, 3.800027675417]);

translate([20, 2, 0]) cube([1, 1, 3.9000010837959853]);

translate([21, 2, 0]) cube([1, 1, 3.9000012929162677]);

translate([22, 2, 0]) cube([1, 1, 4.100000075144351]);

translate([23, 2, 0]) cube([1, 1, 4.200000030987404]);

translate([24, 2, 0]) cube([1, 1, 4.4]);

translate([25, 2, 0]) cube([1, 1, 4.400000000530872]);

translate([26, 2, 0]) cube([1, 1, 4.5]);

translate([27, 2, 0]) cube([1, 1, 4.6]);

translate([28, 2, 0]) cube([1, 1, 4.7]);

translate([29, 2, 0]) cube([1, 1, 4.7]);

translate([30, 2, 0]) cube([1, 1, 4.7]);

translate([31, 2, 0]) cube([1, 1, 4.6]);

translate([32, 2, 0]) cube([1, 1, 4.5]);

translate([33, 2, 0]) cube([1, 1, 4.4]);

translate([34, 2, 0]) cube([1, 1, 4.3]);

translate([35, 2, 0]) cube([1, 1, 4.2]);

translate([36, 2, 0]) cube([1, 1, 4.100001333333333]);

translate([37, 2, 0]) cube([1, 1, 4.000008533333333]);

translate([38, 2, 0]) cube([1, 1, 3.9000446933333333]);

translate([39, 2, 0]) cube([1, 1, 3.8007022719999997]);

translate([40, 2, 0]) cube([1, 1, 3.606588637382716]);

translate([41, 2, 0]) cube([1, 1, 3.6131202775308644]);

translate([42, 2, 0]) cube([1, 1, 3.7182229876543214]);

translate([43, 2, 0]) cube([1, 1, 3.9173216049382718]);

translate([44, 2, 0]) cube([1, 1, 4.008348765432099]);

translate([45, 2, 0]) cube([1, 1, 4.00576774691358]);

translate([46, 2, 0]) cube([1, 1, 4.1]);

translate([47, 2, 0]) cube([1, 1, 4.2]);

color([0,1,0])
translate([0, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

translate([3, 3, 0]) cube([1, 1, 5.4]);

translate([4, 3, 0]) cube([1, 1, 5.2]);

translate([5, 3, 0]) cube([1, 1, 5.0]);

translate([6, 3, 0]) cube([1, 1, 4.8]);

translate([7, 3, 0]) cube([1, 1, 4.6]);

translate([8, 3, 0]) cube([1, 1, 4.400000003545083]);

translate([9, 3, 0]) cube([1, 1, 4.4000000098725724]);

translate([10, 3, 0]) cube([1, 1, 4.400000033939314]);

translate([11, 3, 0]) cube([1, 1, 4.400000061055409]);

translate([12, 3, 0]) cube([1, 1, 4.300000128487206]);

translate([13, 3, 0]) cube([1, 1, 4.300000082875624]);

translate([14, 3, 0]) cube([1, 1, 4.100002252251248]);

translate([15, 3, 0]) cube([1, 1, 4.000007370720054]);

translate([16, 3, 0]) cube([1, 1, 3.90002183299597]);

translate([17, 3, 0]) cube([1, 1, 3.8000284678474583]);

translate([18, 3, 0]) cube([1, 1, 3.8000277462203815]);

translate([19, 3, 0]) cube([1, 1, 3.9000016960374007]);

translate([20, 3, 0]) cube([1, 1, 3.900001388231807]);

translate([21, 3, 0]) cube([1, 1, 3.900001413549841]);

translate([22, 3, 0]) cube([1, 1, 4.000000593801474]);

translate([23, 3, 0]) cube([1, 1, 4.100000347797273]);

translate([24, 3, 0]) cube([1, 1, 4.200000129187353]);

translate([25, 3, 0]) cube([1, 1, 4.30000002895727]);

translate([26, 3, 0]) cube([1, 1, 4.400000008795495]);

translate([27, 3, 0]) cube([1, 1, 4.400000011317745]);

translate([28, 3, 0]) cube([1, 1, 4.5]);

translate([29, 3, 0]) cube([1, 1, 4.5]);

translate([30, 3, 0]) cube([1, 1, 4.4]);

translate([31, 3, 0]) cube([1, 1, 4.3]);

translate([32, 3, 0]) cube([1, 1, 4.3]);

translate([33, 3, 0]) cube([1, 1, 4.2]);

translate([34, 3, 0]) cube([1, 1, 4.1]);

translate([35, 3, 0]) cube([1, 1, 4.000000651851852]);

translate([36, 3, 0]) cube([1, 1, 4.000001718518519]);

translate([37, 3, 0]) cube([1, 1, 3.9000112557037037]);

translate([38, 3, 0]) cube([1, 1, 3.8001533508740737]);

translate([39, 3, 0]) cube([1, 1, 3.601497790718025]);

translate([40, 3, 0]) cube([1, 1, 3.5043817955263212]);

translate([41, 3, 0]) cube([1, 1, 3.4144312864091395]);

translate([42, 3, 0]) cube([1, 1, 3.5154114475423364]);

translate([43, 3, 0]) cube([1, 1, 3.709584380452676]);

translate([44, 3, 0]) cube([1, 1, 3.8067581738683125]);

translate([45, 3, 0]) cube([1, 1, 3.9023527520576136]);

translate([46, 3, 0]) cube([1, 1, 3.802075691504997]);

translate([47, 3, 0]) cube([1, 1, 3.8006918971683326]);

translate([0, 4, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([1, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

translate([5, 4, 0]) cube([1, 1, 5.4]);

translate([6, 4, 0]) cube([1, 1, 5.2]);

translate([7, 4, 0]) cube([1, 1, 5.0]);

translate([8, 4, 0]) cube([1, 1, 4.800000000594812]);

translate([9, 4, 0]) cube([1, 1, 4.800000006124403]);

translate([10, 4, 0]) cube([1, 1, 4.8000000120875335]);

translate([11, 4, 0]) cube([1, 1, 4.7000001143445465]);

translate([12, 4, 0]) cube([1, 1, 4.600000223334317]);

translate([13, 4, 0]) cube([1, 1, 4.400000196802461]);

translate([14, 4, 0]) cube([1, 1, 4.200008656645408]);

translate([15, 4, 0]) cube([1, 1, 4.0000179812351435]);

translate([16, 4, 0]) cube([1, 1, 3.900030977876888]);

translate([17, 4, 0]) cube([1, 1, 4.000008161461311]);

translate([18, 4, 0]) cube([1, 1, 4.000006258091468]);

translate([19, 4, 0]) cube([1, 1, 4.100001955846896]);

translate([20, 4, 0]) cube([1, 1, 4.200000715122213]);

translate([21, 4, 0]) cube([1, 1, 4.100000625559951]);

translate([22, 4, 0]) cube([1, 1, 4.100000525720599]);

translate([23, 4, 0]) cube([1, 1, 4.200000177751013]);

translate([24, 4, 0]) cube([1, 1, 4.200000181570413]);

translate([25, 4, 0]) cube([1, 1, 4.300000061571664]);

translate([26, 4, 0]) cube([1, 1, 4.400000019686033]);

translate([27, 4, 0]) cube([1, 1, 4.4000000159178265]);

translate([28, 4, 0]) cube([1, 1, 4.300000033610194]);

translate([29, 4, 0]) cube([1, 1, 4.300000017575483]);

translate([30, 4, 0]) cube([1, 1, 4.300000002403656]);

translate([31, 4, 0]) cube([1, 1, 4.2]);

translate([32, 4, 0]) cube([1, 1, 4.100000008387769]);

translate([33, 4, 0]) cube([1, 1, 3.9000000781295956]);

translate([34, 4, 0]) cube([1, 1, 3.8000001448589833]);

translate([35, 4, 0]) cube([1, 1, 3.7000026937199917]);

translate([36, 4, 0]) cube([1, 1, 3.7000082693846914]);

translate([37, 4, 0]) cube([1, 1, 3.700027720849383]);

translate([38, 4, 0]) cube([1, 1, 3.6003380236290368]);

translate([39, 4, 0]) cube([1, 1, 3.501274192149492]);

translate([40, 4, 0]) cube([1, 1, 3.4043170129605946]);

translate([41, 4, 0]) cube([1, 1, 3.317452663834826]);

translate([42, 4, 0]) cube([1, 1, 3.4111205280039614]);

translate([43, 4, 0]) cube([1, 1, 3.603396539593213]);

translate([44, 4, 0]) cube([1, 1, 3.704036683238291]);

translate([45, 4, 0]) cube([1, 1, 3.8014881098128552]);

translate([46, 4, 0]) cube([1, 1, 3.7016151264352906]);

translate([47, 4, 0]) cube([1, 1, 3.6016993324318567]);

translate([0, 5, 0]) cube([1, 1, 7.0]);

translate([1, 5, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

translate([7, 5, 0]) cube([1, 1, 5.3]);

translate([8, 5, 0]) cube([1, 1, 5.200000000426128]);

translate([9, 5, 0]) cube([1, 1, 5.200000001397141]);

translate([10, 5, 0]) cube([1, 1, 5.100000022127244]);

translate([11, 5, 0]) cube([1, 1, 5.000000048071488]);

translate([12, 5, 0]) cube([1, 1, 4.800000492209521]);

translate([13, 5, 0]) cube([1, 1, 4.60000046663848]);

translate([14, 5, 0]) cube([1, 1, 4.300014278082494]);

translate([15, 5, 0]) cube([1, 1, 4.20001964169071]);

translate([16, 5, 0]) cube([1, 1, 4.100027090831304]);

translate([17, 5, 0]) cube([1, 1, 4.200011538589592]);

translate([18, 5, 0]) cube([1, 1, 4.30000558000421]);

translate([19, 5, 0]) cube([1, 1, 4.400002558055489]);

translate([20, 5, 0]) cube([1, 1, 4.500000927190679]);

translate([21, 5, 0]) cube([1, 1, 4.400000807046469]);

translate([22, 5, 0]) cube([1, 1, 4.400000471342397]);

translate([23, 5, 0]) cube([1, 1, 4.400000231416856]);

translate([24, 5, 0]) cube([1, 1, 4.400000155888061]);

translate([25, 5, 0]) cube([1, 1, 4.50000004109038]);

translate([26, 5, 0]) cube([1, 1, 4.500000025779954]);

translate([27, 5, 0]) cube([1, 1, 4.400000044451899]);

translate([28, 5, 0]) cube([1, 1, 4.300000041883975]);

translate([29, 5, 0]) cube([1, 1, 4.200000229182136]);

translate([30, 5, 0]) cube([1, 1, 4.100000233770891]);

translate([31, 5, 0]) cube([1, 1, 4.100000038440078]);

translate([32, 5, 0]) cube([1, 1, 3.9000003122450395]);

translate([33, 5, 0]) cube([1, 1, 3.700000518830538]);

translate([34, 5, 0]) cube([1, 1, 3.6000014248679557]);

translate([35, 5, 0]) cube([1, 1, 3.5000118267346445]);

translate([36, 5, 0]) cube([1, 1, 3.5000348547556417]);

translate([37, 5, 0]) cube([1, 1, 3.6000623356438517]);

translate([38, 5, 0]) cube([1, 1, 3.5003404563116]);

translate([39, 5, 0]) cube([1, 1, 3.4015849730777044]);

translate([40, 5, 0]) cube([1, 1, 3.308865917302951]);

translate([41, 5, 0]) cube([1, 1, 3.3085058495713313]);

translate([42, 5, 0]) cube([1, 1, 3.402695921062124]);

translate([43, 5, 0]) cube([1, 1, 3.5016584587755686]);

translate([44, 5, 0]) cube([1, 1, 3.6019733577906643]);

translate([45, 5, 0]) cube([1, 1, 3.7009454563089634]);

translate([46, 5, 0]) cube([1, 1, 3.6010065485604037]);

translate([47, 5, 0]) cube([1, 1, 3.5024156156590127]);

translate([0, 6, 0]) cube([1, 1, 7.2]);

translate([1, 6, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([2, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

translate([8, 6, 0]) cube([1, 1, 5.40000000166726]);

translate([9, 6, 0]) cube([1, 1, 5.400000003764428]);

translate([10, 6, 0]) cube([1, 1, 5.400000005302928]);

translate([11, 6, 0]) cube([1, 1, 5.200000109403884]);

translate([12, 6, 0]) cube([1, 1, 5.000000106721498]);

translate([13, 6, 0]) cube([1, 1, 4.8000021996936075]);

translate([14, 6, 0]) cube([1, 1, 4.500021920440289]);

translate([15, 6, 0]) cube([1, 1, 4.400032329619229]);

translate([16, 6, 0]) cube([1, 1, 4.400029641574243]);

translate([17, 6, 0]) cube([1, 1, 4.500015212622286]);

translate([18, 6, 0]) cube([1, 1, 4.600007260399542]);

translate([19, 6, 0]) cube([1, 1, 4.800002870114717]);

translate([20, 6, 0]) cube([1, 1, 4.800001733277014]);

translate([21, 6, 0]) cube([1, 1, 4.8000009623034385]);

translate([22, 6, 0]) cube([1, 1, 4.70000041366845]);

translate([23, 6, 0]) cube([1, 1, 4.700000175122033]);

translate([24, 6, 0]) cube([1, 1, 4.700000098718618]);

translate([25, 6, 0]) cube([1, 1, 4.700000079147068]);

translate([26, 6, 0]) cube([1, 1, 4.600000055674905]);

translate([27, 6, 0]) cube([1, 1, 4.400000189193406]);

translate([28, 6, 0]) cube([1, 1, 4.200000823738548]);

translate([29, 6, 0]) cube([1, 1, 4.100000689077412]);

translate([30, 6, 0]) cube([1, 1, 4.000000925266083]);

translate([31, 6, 0]) cube([1, 1, 3.900001517550349]);

translate([32, 6, 0]) cube([1, 1, 3.8000015346715967]);

translate([33, 6, 0]) cube([1, 1, 3.6000028645214446]);

translate([34, 6, 0]) cube([1, 1, 3.400025056196753]);

translate([35, 6, 0]) cube([1, 1, 3.4000297997795963]);

translate([36, 6, 0]) cube([1, 1, 3.4000554009643684]);

translate([37, 6, 0]) cube([1, 1, 3.5000692118326797]);

translate([38, 6, 0]) cube([1, 1, 3.5000702061557263]);

translate([39, 6, 0]) cube([1, 1, 3.400406187257353]);

translate([40, 6, 0]) cube([1, 1, 3.304883520710381]);

translate([41, 6, 0]) cube([1, 1, 3.2400574487513825]);

translate([42, 6, 0]) cube([1, 1, 3.3043604778297193]);

translate([43, 6, 0]) cube([1, 1, 3.4020291892614094]);

translate([44, 6, 0]) cube([1, 1, 3.5012361012851403]);

translate([45, 6, 0]) cube([1, 1, 3.600654227110005]);

translate([46, 6, 0]) cube([1, 1, 3.6004343718949516]);

translate([47, 6, 0]) cube([1, 1, 3.5024102076026002]);

translate([0, 7, 0]) cube([1, 1, 7.4]);

translate([1, 7, 0]) cube([1, 1, 7.0]);

translate([2, 7, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

translate([11, 7, 0]) cube([1, 1, 5.4000000125245995]);

translate([12, 7, 0]) cube([1, 1, 5.200000521700748]);

translate([13, 7, 0]) cube([1, 1, 4.90001257041331]);

translate([14, 7, 0]) cube([1, 1, 4.700031479721848]);

translate([15, 7, 0]) cube([1, 1, 4.600040966513066]);

translate([16, 7, 0]) cube([1, 1, 4.600039136345006]);

translate([17, 7, 0]) cube([1, 1, 4.800019067137392]);

translate([18, 7, 0]) cube([1, 1, 4.900010600417947]);

translate([19, 7, 0]) cube([1, 1, 5.10000376466949]);

translate([20, 7, 0]) cube([1, 1, 5.100002071713512]);

translate([21, 7, 0]) cube([1, 1, 5.100000745130486]);

translate([22, 7, 0]) cube([1, 1, 5.000000262350601]);

translate([23, 7, 0]) cube([1, 1, 5.000000101002696]);

translate([24, 7, 0]) cube([1, 1, 4.900000100896465]);

translate([25, 7, 0]) cube([1, 1, 4.900000060516033]);

translate([26, 7, 0]) cube([1, 1, 4.700000197383505]);

translate([27, 7, 0]) cube([1, 1, 4.500000670104991]);

translate([28, 7, 0]) cube([1, 1, 4.200002353337298]);

translate([29, 7, 0]) cube([1, 1, 4.000002512071529]);

translate([30, 7, 0]) cube([1, 1, 3.900006393185853]);

translate([31, 7, 0]) cube([1, 1, 3.800005807024331]);

translate([32, 7, 0]) cube([1, 1, 3.700011361791828]);

translate([33, 7, 0]) cube([1, 1, 3.500031040639406]);

translate([34, 7, 0]) cube([1, 1, 3.300769860469467]);

translate([35, 7, 0]) cube([1, 1, 3.300771713480387]);

translate([36, 7, 0]) cube([1, 1, 3.4000429430629975]);

translate([37, 7, 0]) cube([1, 1, 3.500027613444161]);

translate([38, 7, 0]) cube([1, 1, 3.5000353014654078]);

translate([39, 7, 0]) cube([1, 1, 3.4001711603192333]);

translate([40, 7, 0]) cube([1, 1, 3.303253481267675]);

translate([41, 7, 0]) cube([1, 1, 3.303464332264626]);

translate([42, 7, 0]) cube([1, 1, 3.3040279528850505]);

translate([43, 7, 0]) cube([1, 1, 3.4013558780846718]);

translate([44, 7, 0]) cube([1, 1, 3.5005529187195994]);

translate([45, 7, 0]) cube([1, 1, 3.600257077186601]);

translate([46, 7, 0]) cube([1, 1, 3.6002872221272453]);

translate([47, 7, 0]) cube([1, 1, 3.5025229033520437]);

translate([0, 8, 0]) cube([1, 1, 7.5]);

translate([1, 8, 0]) cube([1, 1, 7.2]);

translate([2, 8, 0]) cube([1, 1, 6.9]);

translate([3, 8, 0]) cube([1, 1, 6.7]);

translate([4, 8, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([5, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

translate([12, 8, 0]) cube([1, 1, 5.300003084910014]);

translate([13, 8, 0]) cube([1, 1, 5.100016824551426]);

translate([14, 8, 0]) cube([1, 1, 4.9000297864222455]);

translate([15, 8, 0]) cube([1, 1, 4.800064538522792]);

translate([16, 8, 0]) cube([1, 1, 4.90004124394245]);

translate([17, 8, 0]) cube([1, 1, 5.100028514439485]);

translate([18, 8, 0]) cube([1, 1, 5.200014977571186]);

translate([19, 8, 0]) cube([1, 1, 5.400005745780041]);

color([0,1,0])
translate([20, 8, 0]) cube([1, 1, 6]);

translate([21, 8, 0]) cube([1, 1, 5.400000380510926]);

translate([22, 8, 0]) cube([1, 1, 5.400000109225022]);

translate([23, 8, 0]) cube([1, 1, 5.300000079024619]);

translate([24, 8, 0]) cube([1, 1, 5.20000005788917]);

translate([25, 8, 0]) cube([1, 1, 5.1000002383586445]);

translate([26, 8, 0]) cube([1, 1, 4.80000088742148]);

translate([27, 8, 0]) cube([1, 1, 4.50000221709841]);

translate([28, 8, 0]) cube([1, 1, 4.200008697174656]);

translate([29, 8, 0]) cube([1, 1, 3.9000278412635803]);

translate([30, 8, 0]) cube([1, 1, 3.800020200667815]);

translate([31, 8, 0]) cube([1, 1, 3.700047951411126]);

translate([32, 8, 0]) cube([1, 1, 3.6001394446696215]);

translate([33, 8, 0]) cube([1, 1, 3.4006976307312438]);

translate([34, 8, 0]) cube([1, 1, 3.300777342935597]);

translate([35, 8, 0]) cube([1, 1, 3.300778381069963]);

translate([36, 8, 0]) cube([1, 1, 3.4000521539010884]);

translate([37, 8, 0]) cube([1, 1, 3.500022655761123]);

translate([38, 8, 0]) cube([1, 1, 3.6000001460474063]);

translate([39, 8, 0]) cube([1, 1, 3.6000000837842387]);

translate([40, 8, 0]) cube([1, 1, 3.5000015668522555]);

translate([41, 8, 0]) cube([1, 1, 3.500006171766804]);

translate([42, 8, 0]) cube([1, 1, 3.5000308593714395]);

translate([43, 8, 0]) cube([1, 1, 3.500154296857198]);

translate([44, 8, 0]) cube([1, 1, 3.6000642692966505]);

translate([45, 8, 0]) cube([1, 1, 3.7]);

translate([46, 8, 0]) cube([1, 1, 3.7]);

translate([47, 8, 0]) cube([1, 1, 3.6001436106863602]);

translate([0, 9, 0]) cube([1, 1, 7.7]);

translate([1, 9, 0]) cube([1, 1, 7.4]);

translate([2, 9, 0]) cube([1, 1, 7.1]);

translate([3, 9, 0]) cube([1, 1, 7.0]);

translate([4, 9, 0]) cube([1, 1, 6.8]);

translate([5, 9, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([6, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

translate([13, 9, 0]) cube([1, 1, 5.300009676835785]);

translate([14, 9, 0]) cube([1, 1, 5.100051597631186]);

translate([15, 9, 0]) cube([1, 1, 5.100070791020336]);

translate([16, 9, 0]) cube([1, 1, 5.200064735342838]);

translate([17, 9, 0]) cube([1, 1, 5.3000421795816255]);

color([0,1,0])
translate([18, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 9, 0]) cube([1, 1, 6]);

translate([24, 9, 0]) cube([1, 1, 5.30000023971381]);

translate([25, 9, 0]) cube([1, 1, 5.100001133873978]);

translate([26, 9, 0]) cube([1, 1, 4.800003009456017]);

translate([27, 9, 0]) cube([1, 1, 4.500007001577105]);

translate([28, 9, 0]) cube([1, 1, 4.200033612853154]);

translate([29, 9, 0]) cube([1, 1, 3.9000642580257185]);

translate([30, 9, 0]) cube([1, 1, 3.7002073568199556]);

translate([31, 9, 0]) cube([1, 1, 3.6006321040606655]);

translate([32, 9, 0]) cube([1, 1, 3.501045917012078]);

translate([33, 9, 0]) cube([1, 1, 3.5006218584206636]);

translate([34, 9, 0]) cube([1, 1, 3.5002432701831245]);

translate([35, 9, 0]) cube([1, 1, 3.50008456899795]);

translate([36, 9, 0]) cube([1, 1, 3.6000042480155696]);

translate([37, 9, 0]) cube([1, 1, 3.7000004876146115]);

translate([38, 9, 0]) cube([1, 1, 3.700000319486776]);

translate([39, 9, 0]) cube([1, 1, 3.800000015442585]);

translate([40, 9, 0]) cube([1, 1, 3.9]);

translate([41, 9, 0]) cube([1, 1, 3.9]);

translate([42, 9, 0]) cube([1, 1, 3.8]);

translate([43, 9, 0]) cube([1, 1, 3.8]);

translate([44, 9, 0]) cube([1, 1, 3.8]);

translate([45, 9, 0]) cube([1, 1, 3.8]);

translate([46, 9, 0]) cube([1, 1, 3.8]);

translate([47, 9, 0]) cube([1, 1, 3.7]);

translate([0, 10, 0]) cube([1, 1, 7.9]);

translate([1, 10, 0]) cube([1, 1, 7.6]);

translate([2, 10, 0]) cube([1, 1, 7.4]);

translate([3, 10, 0]) cube([1, 1, 7.2]);

translate([4, 10, 0]) cube([1, 1, 7.1]);

translate([5, 10, 0]) cube([1, 1, 6.9]);

translate([6, 10, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([7, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

translate([14, 10, 0]) cube([1, 1, 5.400036365742179]);

translate([15, 10, 0]) cube([1, 1, 5.300118495999198]);

translate([16, 10, 0]) cube([1, 1, 5.400096697069447]);

color([0,1,0])
translate([17, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

translate([24, 10, 0]) cube([1, 1, 5.400001234348785]);

translate([25, 10, 0]) cube([1, 1, 5.1000041410581956]);

translate([26, 10, 0]) cube([1, 1, 4.800009542926562]);

translate([27, 10, 0]) cube([1, 1, 4.500021577025096]);

translate([28, 10, 0]) cube([1, 1, 4.200137278295186]);

translate([29, 10, 0]) cube([1, 1, 4.000141636027713]);

translate([30, 10, 0]) cube([1, 1, 3.8005754928456783]);

translate([31, 10, 0]) cube([1, 1, 3.6010871261339847]);

translate([32, 10, 0]) cube([1, 1, 3.600725724344645]);

translate([33, 10, 0]) cube([1, 1, 3.6005054028549384]);

translate([34, 10, 0]) cube([1, 1, 3.700070945520694]);

translate([35, 10, 0]) cube([1, 1, 3.8000181463991387]);

translate([36, 10, 0]) cube([1, 1, 3.9000016687618944]);

translate([37, 10, 0]) cube([1, 1, 3.900000941026921]);

translate([38, 10, 0]) cube([1, 1, 4.00000008001456]);

translate([39, 10, 0]) cube([1, 1, 4.1]);

translate([40, 10, 0]) cube([1, 1, 4.2]);

translate([41, 10, 0]) cube([1, 1, 4.3]);

translate([42, 10, 0]) cube([1, 1, 4.2]);

translate([43, 10, 0]) cube([1, 1, 4.1]);

translate([44, 10, 0]) cube([1, 1, 4.1]);

translate([45, 10, 0]) cube([1, 1, 4.0]);

translate([46, 10, 0]) cube([1, 1, 3.9]);

translate([47, 10, 0]) cube([1, 1, 3.8]);

translate([0, 11, 0]) cube([1, 1, 8.0]);

translate([1, 11, 0]) cube([1, 1, 7.7]);

translate([2, 11, 0]) cube([1, 1, 7.5]);

translate([3, 11, 0]) cube([1, 1, 7.3]);

translate([4, 11, 0]) cube([1, 1, 7.2]);

translate([5, 11, 0]) cube([1, 1, 7.0]);

translate([6, 11, 0]) cube([1, 1, 6.8]);

translate([7, 11, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([8, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

translate([24, 11, 0]) cube([1, 1, 5.4000051120525185]);

translate([25, 11, 0]) cube([1, 1, 5.100014127440264]);

translate([26, 11, 0]) cube([1, 1, 4.800028341142522]);

translate([27, 11, 0]) cube([1, 1, 4.600066974853656]);

translate([28, 11, 0]) cube([1, 1, 4.400298177490737]);

translate([29, 11, 0]) cube([1, 1, 4.200239112026629]);

translate([30, 11, 0]) cube([1, 1, 3.9010010570297813]);

translate([31, 11, 0]) cube([1, 1, 3.8011483533154546]);

translate([32, 11, 0]) cube([1, 1, 3.8008963616011946]);

translate([33, 11, 0]) cube([1, 1, 3.900249129703629]);

translate([34, 11, 0]) cube([1, 1, 4.100079452602975]);

translate([35, 11, 0]) cube([1, 1, 4.200008000170248]);

translate([36, 11, 0]) cube([1, 1, 4.200001613214333]);

translate([37, 11, 0]) cube([1, 1, 4.200000405354048]);

translate([38, 11, 0]) cube([1, 1, 4.300000000444444]);

translate([39, 11, 0]) cube([1, 1, 4.4]);

translate([40, 11, 0]) cube([1, 1, 4.5]);

translate([41, 11, 0]) cube([1, 1, 4.5]);

translate([42, 11, 0]) cube([1, 1, 4.5]);

translate([43, 11, 0]) cube([1, 1, 4.4]);

translate([44, 11, 0]) cube([1, 1, 4.3]);

translate([45, 11, 0]) cube([1, 1, 4.2]);

translate([46, 11, 0]) cube([1, 1, 4.1]);

translate([47, 11, 0]) cube([1, 1, 4.0]);

translate([0, 12, 0]) cube([1, 1, 7.9]);

translate([1, 12, 0]) cube([1, 1, 7.6]);

translate([2, 12, 0]) cube([1, 1, 7.4]);

translate([3, 12, 0]) cube([1, 1, 7.3]);

translate([4, 12, 0]) cube([1, 1, 7.1]);

translate([5, 12, 0]) cube([1, 1, 7.0]);

translate([6, 12, 0]) cube([1, 1, 6.8]);

translate([7, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

translate([24, 12, 0]) cube([1, 1, 5.400020249184565]);

translate([25, 12, 0]) cube([1, 1, 5.100044069970755]);

translate([26, 12, 0]) cube([1, 1, 4.900079329484775]);

translate([27, 12, 0]) cube([1, 1, 4.7002176629794326]);

translate([28, 12, 0]) cube([1, 1, 4.500437813687134]);

translate([29, 12, 0]) cube([1, 1, 4.400614925946679]);

translate([30, 12, 0]) cube([1, 1, 4.101276131772785]);

translate([31, 12, 0]) cube([1, 1, 4.001732424028893]);

translate([32, 12, 0]) cube([1, 1, 4.100776992353424]);

translate([33, 12, 0]) cube([1, 1, 4.200341272411758]);

translate([34, 12, 0]) cube([1, 1, 4.4000479331446565]);

translate([35, 12, 0]) cube([1, 1, 4.60000005939898]);

translate([36, 12, 0]) cube([1, 1, 4.600000011111111]);

translate([37, 12, 0]) cube([1, 1, 4.600000002222222]);

translate([38, 12, 0]) cube([1, 1, 4.600000000444444]);

translate([39, 12, 0]) cube([1, 1, 4.6]);

translate([40, 12, 0]) cube([1, 1, 4.7]);

translate([41, 12, 0]) cube([1, 1, 4.7]);

translate([42, 12, 0]) cube([1, 1, 4.6]);

translate([43, 12, 0]) cube([1, 1, 4.5]);

translate([44, 12, 0]) cube([1, 1, 4.5]);

translate([45, 12, 0]) cube([1, 1, 4.5]);

translate([46, 12, 0]) cube([1, 1, 4.4]);

translate([47, 12, 0]) cube([1, 1, 4.3]);

translate([0, 13, 0]) cube([1, 1, 7.9]);

translate([1, 13, 0]) cube([1, 1, 7.6]);

translate([2, 13, 0]) cube([1, 1, 7.3]);

translate([3, 13, 0]) cube([1, 1, 7.2]);

translate([4, 13, 0]) cube([1, 1, 7.0]);

translate([5, 13, 0]) cube([1, 1, 6.9]);

translate([6, 13, 0]) cube([1, 1, 6.7]);

translate([7, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 13, 0]) cube([1, 1, 6]);

translate([10, 13, 0]) cube([1, 1, 6.6]);

translate([11, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 13, 0]) cube([1, 1, 6]);

translate([25, 13, 0]) cube([1, 1, 5.200120282612046]);

translate([26, 13, 0]) cube([1, 1, 4.900218480026407]);

translate([27, 13, 0]) cube([1, 1, 4.800274061240294]);

translate([28, 13, 0]) cube([1, 1, 4.70039981624729]);

translate([29, 13, 0]) cube([1, 1, 4.6007927423343675]);

translate([30, 13, 0]) cube([1, 1, 4.401572128098813]);

translate([31, 13, 0]) cube([1, 1, 4.301885620637729]);

translate([32, 13, 0]) cube([1, 1, 4.301418823737622]);

translate([33, 13, 0]) cube([1, 1, 4.500239247416403]);

translate([34, 13, 0]) cube([1, 1, 4.800000362298422]);

translate([35, 13, 0]) cube([1, 1, 4.9]);

translate([36, 13, 0]) cube([1, 1, 4.9]);

translate([37, 13, 0]) cube([1, 1, 4.9]);

translate([38, 13, 0]) cube([1, 1, 4.9]);

translate([39, 13, 0]) cube([1, 1, 4.9]);

translate([40, 13, 0]) cube([1, 1, 4.9]);

translate([41, 13, 0]) cube([1, 1, 4.8]);

translate([42, 13, 0]) cube([1, 1, 4.8]);

translate([43, 13, 0]) cube([1, 1, 4.7]);

translate([44, 13, 0]) cube([1, 1, 4.7]);

translate([45, 13, 0]) cube([1, 1, 4.7]);

translate([46, 13, 0]) cube([1, 1, 4.8]);

translate([47, 13, 0]) cube([1, 1, 4.7]);

translate([0, 14, 0]) cube([1, 1, 7.9]);

translate([1, 14, 0]) cube([1, 1, 7.6]);

translate([2, 14, 0]) cube([1, 1, 7.3]);

translate([3, 14, 0]) cube([1, 1, 7.1]);

translate([4, 14, 0]) cube([1, 1, 6.9]);

translate([5, 14, 0]) cube([1, 1, 6.7]);

translate([6, 14, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

translate([9, 14, 0]) cube([1, 1, 6.6]);

translate([10, 14, 0]) cube([1, 1, 6.7]);

translate([11, 14, 0]) cube([1, 1, 6.7]);

translate([12, 14, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 14, 0]) cube([1, 1, 6]);

translate([25, 14, 0]) cube([1, 1, 5.200266955184939]);

translate([26, 14, 0]) cube([1, 1, 5.000293769120062]);

translate([27, 14, 0]) cube([1, 1, 4.900300237786448]);

translate([28, 14, 0]) cube([1, 1, 4.800420305932693]);

translate([29, 14, 0]) cube([1, 1, 4.701127380298628]);

translate([30, 14, 0]) cube([1, 1, 4.60227635461571]);

translate([31, 14, 0]) cube([1, 1, 4.5033700551677915]);

translate([32, 14, 0]) cube([1, 1, 4.601194062671326]);

translate([33, 14, 0]) cube([1, 1, 4.800001816114926]);

translate([34, 14, 0]) cube([1, 1, 5.1]);

translate([35, 14, 0]) cube([1, 1, 5.3]);

translate([36, 14, 0]) cube([1, 1, 5.3]);

translate([37, 14, 0]) cube([1, 1, 5.3]);

translate([38, 14, 0]) cube([1, 1, 5.2]);

translate([39, 14, 0]) cube([1, 1, 5.1]);

translate([40, 14, 0]) cube([1, 1, 5.1]);

translate([41, 14, 0]) cube([1, 1, 5.0]);

translate([42, 14, 0]) cube([1, 1, 4.9]);

translate([43, 14, 0]) cube([1, 1, 4.8]);

translate([44, 14, 0]) cube([1, 1, 4.9]);

translate([45, 14, 0]) cube([1, 1, 5.0]);

translate([46, 14, 0]) cube([1, 1, 5.1]);

translate([47, 14, 0]) cube([1, 1, 5.1]);

translate([0, 15, 0]) cube([1, 1, 8.0]);

translate([1, 15, 0]) cube([1, 1, 7.7]);

translate([2, 15, 0]) cube([1, 1, 7.4]);

translate([3, 15, 0]) cube([1, 1, 7.1]);

translate([4, 15, 0]) cube([1, 1, 6.8]);

translate([5, 15, 0]) cube([1, 1, 6.7]);

translate([6, 15, 0]) cube([1, 1, 6.6]);

translate([7, 15, 0]) cube([1, 1, 6.6]);

translate([8, 15, 0]) cube([1, 1, 6.7]);

translate([9, 15, 0]) cube([1, 1, 6.8]);

translate([10, 15, 0]) cube([1, 1, 6.9]);

translate([11, 15, 0]) cube([1, 1, 6.8]);

translate([12, 15, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 15, 0]) cube([1, 1, 6]);

translate([25, 15, 0]) cube([1, 1, 5.200500715614184]);

translate([26, 15, 0]) cube([1, 1, 5.000583805296419]);

translate([27, 15, 0]) cube([1, 1, 4.900533121640625]);

translate([28, 15, 0]) cube([1, 1, 4.900312833146339]);

translate([29, 15, 0]) cube([1, 1, 4.801091092446788]);

translate([30, 15, 0]) cube([1, 1, 4.7040413039949565]);

translate([31, 15, 0]) cube([1, 1, 4.605959414030422]);

translate([32, 15, 0]) cube([1, 1, 4.800009085591572]);

translate([33, 15, 0]) cube([1, 1, 5.100000000167616]);

translate([34, 15, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([35, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 15, 0]) cube([1, 1, 6]);

translate([39, 15, 0]) cube([1, 1, 5.4]);

translate([40, 15, 0]) cube([1, 1, 5.3]);

translate([41, 15, 0]) cube([1, 1, 5.2]);

translate([42, 15, 0]) cube([1, 1, 5.1]);

translate([43, 15, 0]) cube([1, 1, 5.1]);

translate([44, 15, 0]) cube([1, 1, 5.1]);

translate([45, 15, 0]) cube([1, 1, 5.3]);

translate([46, 15, 0]) cube([1, 1, 5.4]);

translate([47, 15, 0]) cube([1, 1, 5.4]);

translate([0, 16, 0]) cube([1, 1, 8.1]);

translate([1, 16, 0]) cube([1, 1, 7.8]);

translate([2, 16, 0]) cube([1, 1, 7.5]);

translate([3, 16, 0]) cube([1, 1, 7.1]);

translate([4, 16, 0]) cube([1, 1, 6.9]);

translate([5, 16, 0]) cube([1, 1, 6.8]);

translate([6, 16, 0]) cube([1, 1, 6.8]);

translate([7, 16, 0]) cube([1, 1, 6.8]);

translate([8, 16, 0]) cube([1, 1, 7.0]);

translate([9, 16, 0]) cube([1, 1, 7.1]);

translate([10, 16, 0]) cube([1, 1, 7.1]);

translate([11, 16, 0]) cube([1, 1, 6.9]);

translate([12, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 16, 0]) cube([1, 1, 6]);

translate([25, 16, 0]) cube([1, 1, 5.200796369115166]);

translate([26, 16, 0]) cube([1, 1, 5.000920249090774]);

translate([27, 16, 0]) cube([1, 1, 5.000574752626535]);

translate([28, 16, 0]) cube([1, 1, 4.900519673219153]);

translate([29, 16, 0]) cube([1, 1, 4.80542964392856]);

translate([30, 16, 0]) cube([1, 1, 4.71071144059416]);

translate([31, 16, 0]) cube([1, 1, 4.707923757317021]);

translate([32, 16, 0]) cube([1, 1, 4.900054509713257]);

translate([33, 16, 0]) cube([1, 1, 5.200000007118187]);

color([0,1,0])
translate([34, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 16, 0]) cube([1, 1, 6]);

translate([43, 16, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([44, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 16, 0]) cube([1, 1, 6]);

translate([0, 17, 0]) cube([1, 1, 8.2]);

translate([1, 17, 0]) cube([1, 1, 7.9]);

translate([2, 17, 0]) cube([1, 1, 7.5]);

translate([3, 17, 0]) cube([1, 1, 7.2]);

translate([4, 17, 0]) cube([1, 1, 7.0]);

translate([5, 17, 0]) cube([1, 1, 7.0]);

translate([6, 17, 0]) cube([1, 1, 7.0]);

translate([7, 17, 0]) cube([1, 1, 7.1]);

translate([8, 17, 0]) cube([1, 1, 7.3]);

translate([9, 17, 0]) cube([1, 1, 7.3]);

translate([10, 17, 0]) cube([1, 1, 7.2]);

translate([11, 17, 0]) cube([1, 1, 7.0]);

translate([12, 17, 0]) cube([1, 1, 6.8]);

translate([13, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 17, 0]) cube([1, 1, 6]);

translate([25, 17, 0]) cube([1, 1, 5.301106249551415]);

translate([26, 17, 0]) cube([1, 1, 5.101047687732147]);

translate([27, 17, 0]) cube([1, 1, 5.00100695228808]);

translate([28, 17, 0]) cube([1, 1, 4.900833616748073]);

translate([29, 17, 0]) cube([1, 1, 4.822208207208148]);

translate([30, 17, 0]) cube([1, 1, 4.806628222938628]);

translate([31, 17, 0]) cube([1, 1, 4.8040768904032225]);

translate([32, 17, 0]) cube([1, 1, 4.900272510233971]);

translate([33, 17, 0]) cube([1, 1, 5.2000000343083475]);

color([0,1,0])
translate([34, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 17, 0]) cube([1, 1, 6]);

translate([0, 18, 0]) cube([1, 1, 8.2]);

translate([1, 18, 0]) cube([1, 1, 7.9]);

translate([2, 18, 0]) cube([1, 1, 7.6]);

translate([3, 18, 0]) cube([1, 1, 7.3]);

translate([4, 18, 0]) cube([1, 1, 7.2]);

translate([5, 18, 0]) cube([1, 1, 7.2]);

translate([6, 18, 0]) cube([1, 1, 7.3]);

translate([7, 18, 0]) cube([1, 1, 7.4]);

translate([8, 18, 0]) cube([1, 1, 7.5]);

translate([9, 18, 0]) cube([1, 1, 7.5]);

translate([10, 18, 0]) cube([1, 1, 7.4]);

translate([11, 18, 0]) cube([1, 1, 7.1]);

translate([12, 18, 0]) cube([1, 1, 6.9]);

translate([13, 18, 0]) cube([1, 1, 6.7]);

translate([14, 18, 0]) cube([1, 1, 6.6]);

translate([15, 18, 0]) cube([1, 1, 6.6]);

translate([16, 18, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 18, 0]) cube([1, 1, 6]);

translate([25, 18, 0]) cube([1, 1, 5.401412376829604]);

translate([26, 18, 0]) cube([1, 1, 5.201538108962918]);

translate([27, 18, 0]) cube([1, 1, 5.101050051678028]);

translate([28, 18, 0]) cube([1, 1, 5.100368838158331]);

translate([29, 18, 0]) cube([1, 1, 5.000152241480785]);

translate([30, 18, 0]) cube([1, 1, 4.904185579377671]);

translate([31, 18, 0]) cube([1, 1, 4.901077219759346]);

translate([32, 18, 0]) cube([1, 1, 5.1000126305281555]);

translate([33, 18, 0]) cube([1, 1, 5.300000151499836]);

color([0,1,0])
translate([34, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 8.1]);

translate([1, 19, 0]) cube([1, 1, 7.9]);

translate([2, 19, 0]) cube([1, 1, 7.6]);

translate([3, 19, 0]) cube([1, 1, 7.4]);

translate([4, 19, 0]) cube([1, 1, 7.4]);

translate([5, 19, 0]) cube([1, 1, 7.4]);

translate([6, 19, 0]) cube([1, 1, 7.5]);

translate([7, 19, 0]) cube([1, 1, 7.6]);

translate([8, 19, 0]) cube([1, 1, 7.6]);

translate([9, 19, 0]) cube([1, 1, 7.6]);

translate([10, 19, 0]) cube([1, 1, 7.4]);

translate([11, 19, 0]) cube([1, 1, 7.2]);

translate([12, 19, 0]) cube([1, 1, 7.0]);

translate([13, 19, 0]) cube([1, 1, 6.8]);

translate([14, 19, 0]) cube([1, 1, 6.7]);

translate([15, 19, 0]) cube([1, 1, 6.8]);

translate([16, 19, 0]) cube([1, 1, 6.8]);

translate([17, 19, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 19, 0]) cube([1, 1, 6]);

translate([26, 19, 0]) cube([1, 1, 5.3013193401621255]);

translate([27, 19, 0]) cube([1, 1, 5.300462741841529]);

translate([28, 19, 0]) cube([1, 1, 5.200217665277853]);

translate([29, 19, 0]) cube([1, 1, 5.200113733530373]);

translate([30, 19, 0]) cube([1, 1, 5.100060971596014]);

translate([31, 19, 0]) cube([1, 1, 5.100040497966603]);

translate([32, 19, 0]) cube([1, 1, 5.2000092016365285]);

translate([33, 19, 0]) cube([1, 1, 5.4000006399953]);

color([0,1,0])
translate([34, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 19, 0]) cube([1, 1, 6]);

translate([41, 19, 0]) cube([1, 1, 6.6]);

translate([42, 19, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([43, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 19, 0]) cube([1, 1, 6]);

translate([0, 20, 0]) cube([1, 1, 8.1]);

translate([1, 20, 0]) cube([1, 1, 7.9]);

translate([2, 20, 0]) cube([1, 1, 7.7]);

translate([3, 20, 0]) cube([1, 1, 7.6]);

translate([4, 20, 0]) cube([1, 1, 7.5]);

translate([5, 20, 0]) cube([1, 1, 7.6]);

translate([6, 20, 0]) cube([1, 1, 7.6]);

translate([7, 20, 0]) cube([1, 1, 7.6]);

translate([8, 20, 0]) cube([1, 1, 7.6]);

translate([9, 20, 0]) cube([1, 1, 7.6]);

translate([10, 20, 0]) cube([1, 1, 7.4]);

translate([11, 20, 0]) cube([1, 1, 7.2]);

translate([12, 20, 0]) cube([1, 1, 7.0]);

translate([13, 20, 0]) cube([1, 1, 6.9]);

translate([14, 20, 0]) cube([1, 1, 6.9]);

translate([15, 20, 0]) cube([1, 1, 6.9]);

translate([16, 20, 0]) cube([1, 1, 6.9]);

translate([17, 20, 0]) cube([1, 1, 6.8]);

translate([18, 20, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 20, 0]) cube([1, 1, 6]);

translate([28, 20, 0]) cube([1, 1, 5.400193446898125]);

translate([29, 20, 0]) cube([1, 1, 5.400101361101052]);

translate([30, 20, 0]) cube([1, 1, 5.300056195807398]);

translate([31, 20, 0]) cube([1, 1, 5.300033567818272]);

translate([32, 20, 0]) cube([1, 1, 5.400002056111282]);

color([0,1,0])
translate([33, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 20, 0]) cube([1, 1, 6]);

translate([40, 20, 0]) cube([1, 1, 6.6]);

translate([41, 20, 0]) cube([1, 1, 6.8]);

translate([42, 20, 0]) cube([1, 1, 6.8]);

translate([43, 20, 0]) cube([1, 1, 6.8]);

translate([44, 20, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([45, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 20, 0]) cube([1, 1, 6]);

translate([47, 20, 0]) cube([1, 1, 5.4]);

translate([0, 21, 0]) cube([1, 1, 8.2]);

translate([1, 21, 0]) cube([1, 1, 7.9]);

translate([2, 21, 0]) cube([1, 1, 7.8]);

translate([3, 21, 0]) cube([1, 1, 7.7]);

translate([4, 21, 0]) cube([1, 1, 7.6]);

translate([5, 21, 0]) cube([1, 1, 7.6]);

translate([6, 21, 0]) cube([1, 1, 7.6]);

translate([7, 21, 0]) cube([1, 1, 7.5]);

translate([8, 21, 0]) cube([1, 1, 7.5]);

translate([9, 21, 0]) cube([1, 1, 7.4]);

translate([10, 21, 0]) cube([1, 1, 7.2]);

translate([11, 21, 0]) cube([1, 1, 7.1]);

translate([12, 21, 0]) cube([1, 1, 7.0]);

translate([13, 21, 0]) cube([1, 1, 7.0]);

translate([14, 21, 0]) cube([1, 1, 7.0]);

translate([15, 21, 0]) cube([1, 1, 7.0]);

translate([16, 21, 0]) cube([1, 1, 6.9]);

translate([17, 21, 0]) cube([1, 1, 6.7]);

translate([18, 21, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 21, 0]) cube([1, 1, 6]);

translate([21, 21, 0]) cube([1, 1, 6.508530496639061]);

translate([22, 21, 0]) cube([1, 1, 6.507485424170436]);

color([0,1,0])
translate([23, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 21, 0]) cube([1, 1, 6]);

translate([40, 21, 0]) cube([1, 1, 6.8]);

translate([41, 21, 0]) cube([1, 1, 6.9]);

translate([42, 21, 0]) cube([1, 1, 7.0]);

translate([43, 21, 0]) cube([1, 1, 6.9]);

translate([44, 21, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([45, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 21, 0]) cube([1, 1, 6]);

translate([47, 21, 0]) cube([1, 1, 5.4]);

translate([0, 22, 0]) cube([1, 1, 8.1]);

translate([1, 22, 0]) cube([1, 1, 7.9]);

translate([2, 22, 0]) cube([1, 1, 7.8]);

translate([3, 22, 0]) cube([1, 1, 7.7]);

translate([4, 22, 0]) cube([1, 1, 7.6]);

translate([5, 22, 0]) cube([1, 1, 7.5]);

translate([6, 22, 0]) cube([1, 1, 7.4]);

translate([7, 22, 0]) cube([1, 1, 7.3]);

translate([8, 22, 0]) cube([1, 1, 7.2]);

translate([9, 22, 0]) cube([1, 1, 7.0]);

translate([10, 22, 0]) cube([1, 1, 7.0]);

translate([11, 22, 0]) cube([1, 1, 7.0]);

translate([12, 22, 0]) cube([1, 1, 7.0]);

translate([13, 22, 0]) cube([1, 1, 7.0]);

translate([14, 22, 0]) cube([1, 1, 7.0]);

translate([15, 22, 0]) cube([1, 1, 7.0]);

translate([16, 22, 0]) cube([1, 1, 6.8]);

translate([17, 22, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 22, 0]) cube([1, 1, 6]);

translate([21, 22, 0]) cube([1, 1, 6.533290482590041]);

translate([22, 22, 0]) cube([1, 1, 6.6024996195428365]);

translate([23, 22, 0]) cube([1, 1, 6.600363230775939]);

color([0,1,0])
translate([24, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 22, 0]) cube([1, 1, 6]);

translate([39, 22, 0]) cube([1, 1, 6.6]);

translate([40, 22, 0]) cube([1, 1, 6.7]);

translate([41, 22, 0]) cube([1, 1, 6.9]);

translate([42, 22, 0]) cube([1, 1, 7.0]);

translate([43, 22, 0]) cube([1, 1, 6.9]);

translate([44, 22, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([45, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 22, 0]) cube([1, 1, 6]);

translate([47, 22, 0]) cube([1, 1, 5.4]);

translate([0, 23, 0]) cube([1, 1, 8.0]);

translate([1, 23, 0]) cube([1, 1, 7.8]);

translate([2, 23, 0]) cube([1, 1, 7.6]);

translate([3, 23, 0]) cube([1, 1, 7.6]);

translate([4, 23, 0]) cube([1, 1, 7.5]);

translate([5, 23, 0]) cube([1, 1, 7.4]);

translate([6, 23, 0]) cube([1, 1, 7.2]);

translate([7, 23, 0]) cube([1, 1, 7.1]);

translate([8, 23, 0]) cube([1, 1, 6.9]);

translate([9, 23, 0]) cube([1, 1, 6.7]);

translate([10, 23, 0]) cube([1, 1, 6.7]);

translate([11, 23, 0]) cube([1, 1, 6.8]);

translate([12, 23, 0]) cube([1, 1, 6.8]);

translate([13, 23, 0]) cube([1, 1, 6.9]);

translate([14, 23, 0]) cube([1, 1, 6.9]);

translate([15, 23, 0]) cube([1, 1, 6.9]);

translate([16, 23, 0]) cube([1, 1, 6.8]);

translate([17, 23, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([18, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

translate([22, 23, 0]) cube([1, 1, 6.528366635890453]);

translate([23, 23, 0]) cube([1, 1, 6.6004017993401565]);

color([0,1,0])
translate([24, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 23, 0]) cube([1, 1, 6]);

translate([40, 23, 0]) cube([1, 1, 6.6]);

translate([41, 23, 0]) cube([1, 1, 6.8]);

translate([42, 23, 0]) cube([1, 1, 6.8]);

translate([43, 23, 0]) cube([1, 1, 6.8]);

translate([44, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([45, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 23, 0]) cube([1, 1, 6]);

translate([0, 24, 0]) cube([1, 1, 7.7]);

translate([1, 24, 0]) cube([1, 1, 7.5]);

translate([2, 24, 0]) cube([1, 1, 7.4]);

translate([3, 24, 0]) cube([1, 1, 7.3]);

translate([4, 24, 0]) cube([1, 1, 7.2]);

translate([5, 24, 0]) cube([1, 1, 7.1]);

translate([6, 24, 0]) cube([1, 1, 7.0]);

translate([7, 24, 0]) cube([1, 1, 6.8]);

translate([8, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([9, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 24, 0]) cube([1, 1, 6]);

translate([11, 24, 0]) cube([1, 1, 6.6]);

translate([12, 24, 0]) cube([1, 1, 6.6]);

translate([13, 24, 0]) cube([1, 1, 6.7]);

translate([14, 24, 0]) cube([1, 1, 6.8]);

translate([15, 24, 0]) cube([1, 1, 6.8]);

translate([16, 24, 0]) cube([1, 1, 6.7]);

translate([17, 24, 0]) cube([1, 1, 6.6]);

translate([18, 24, 0]) cube([1, 1, 6.501208167453354]);

color([0,1,0])
translate([19, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 24, 0]) cube([1, 1, 6]);

translate([21, 24, 0]) cube([1, 1, 6.516499545691831]);

translate([22, 24, 0]) cube([1, 1, 6.600599326868511]);

translate([23, 24, 0]) cube([1, 1, 6.506016908851145]);

color([0,1,0])
translate([24, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 24, 0]) cube([1, 1, 6]);

translate([41, 24, 0]) cube([1, 1, 6.6]);

translate([42, 24, 0]) cube([1, 1, 6.7]);

translate([43, 24, 0]) cube([1, 1, 6.7]);

translate([44, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([45, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 24, 0]) cube([1, 1, 6]);

translate([0, 25, 0]) cube([1, 1, 7.3]);

translate([1, 25, 0]) cube([1, 1, 7.1]);

translate([2, 25, 0]) cube([1, 1, 7.1]);

translate([3, 25, 0]) cube([1, 1, 7.0]);

translate([4, 25, 0]) cube([1, 1, 7.0]);

translate([5, 25, 0]) cube([1, 1, 6.9]);

translate([6, 25, 0]) cube([1, 1, 6.8]);

translate([7, 25, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 25, 0]) cube([1, 1, 6]);

translate([14, 25, 0]) cube([1, 1, 6.6]);

translate([15, 25, 0]) cube([1, 1, 6.6]);

translate([16, 25, 0]) cube([1, 1, 6.6]);

translate([17, 25, 0]) cube([1, 1, 6.500679501529657]);

translate([18, 25, 0]) cube([1, 1, 6.501397279488159]);

translate([19, 25, 0]) cube([1, 1, 6.505528703340048]);

translate([20, 25, 0]) cube([1, 1, 6.5098657103672135]);

translate([21, 25, 0]) cube([1, 1, 6.603703872432476]);

translate([22, 25, 0]) cube([1, 1, 6.600716782431258]);

translate([23, 25, 0]) cube([1, 1, 6.5014667406085795]);

color([0,1,0])
translate([24, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 25, 0]) cube([1, 1, 6]);

translate([28, 25, 0]) cube([1, 1, 5.400691094346566]);

translate([29, 25, 0]) cube([1, 1, 5.400500646820669]);

translate([30, 25, 0]) cube([1, 1, 5.400198608446754]);

color([0,1,0])
translate([31, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 25, 0]) cube([1, 1, 6]);

translate([0, 26, 0]) cube([1, 1, 7.0]);

translate([1, 26, 0]) cube([1, 1, 6.8]);

translate([2, 26, 0]) cube([1, 1, 6.8]);

translate([3, 26, 0]) cube([1, 1, 6.8]);

translate([4, 26, 0]) cube([1, 1, 6.8]);

translate([5, 26, 0]) cube([1, 1, 6.7]);

translate([6, 26, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([7, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 26, 0]) cube([1, 1, 6]);

translate([16, 26, 0]) cube([1, 1, 6.500239459243169]);

translate([17, 26, 0]) cube([1, 1, 6.50051779585011]);

translate([18, 26, 0]) cube([1, 1, 6.600000001327806]);

translate([19, 26, 0]) cube([1, 1, 6.6000000049467085]);

translate([20, 26, 0]) cube([1, 1, 6.700000022862369]);

translate([21, 26, 0]) cube([1, 1, 6.700000137174212]);

translate([22, 26, 0]) cube([1, 1, 6.700000685871056]);

translate([23, 26, 0]) cube([1, 1, 6.500547080898749]);

color([0,1,0])
translate([24, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 26, 0]) cube([1, 1, 6]);

translate([28, 26, 0]) cube([1, 1, 5.400654849216025]);

translate([29, 26, 0]) cube([1, 1, 5.300635113744874]);

translate([30, 26, 0]) cube([1, 1, 5.300437414649809]);

translate([31, 26, 0]) cube([1, 1, 5.300165232517996]);

translate([32, 26, 0]) cube([1, 1, 5.400004292494749]);

color([0,1,0])
translate([33, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 26, 0]) cube([1, 1, 6]);

translate([0, 27, 0]) cube([1, 1, 6.8]);

translate([1, 27, 0]) cube([1, 1, 6.6]);

translate([2, 27, 0]) cube([1, 1, 6.6]);

translate([3, 27, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([4, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 27, 0]) cube([1, 1, 6]);

translate([18, 27, 0]) cube([1, 1, 6.600000001499208]);

translate([19, 27, 0]) cube([1, 1, 6.700000004572474]);

translate([20, 27, 0]) cube([1, 1, 6.9]);

translate([21, 27, 0]) cube([1, 1, 6.9]);

translate([22, 27, 0]) cube([1, 1, 6.9]);

translate([23, 27, 0]) cube([1, 1, 6.700004115226338]);

color([0,1,0])
translate([24, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 27, 0]) cube([1, 1, 6]);

translate([29, 27, 0]) cube([1, 1, 5.30054140754304]);

translate([30, 27, 0]) cube([1, 1, 5.200777187562206]);

translate([31, 27, 0]) cube([1, 1, 5.20051727688419]);

translate([32, 27, 0]) cube([1, 1, 5.200512211503453]);

translate([33, 27, 0]) cube([1, 1, 5.300005956830741]);

color([0,1,0])
translate([34, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 27, 0]) cube([1, 1, 6]);

translate([0, 28, 0]) cube([1, 1, 6.7]);

translate([1, 28, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 28, 0]) cube([1, 1, 6]);

translate([11, 28, 0]) cube([1, 1, 5.400106324111217]);

color([0,1,0])
translate([12, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 28, 0]) cube([1, 1, 6]);

translate([18, 28, 0]) cube([1, 1, 6.500029630783636]);

translate([19, 28, 0]) cube([1, 1, 6.8]);

translate([20, 28, 0]) cube([1, 1, 7.0]);

translate([21, 28, 0]) cube([1, 1, 7.1]);

translate([22, 28, 0]) cube([1, 1, 7.0]);

translate([23, 28, 0]) cube([1, 1, 6.800024691358025]);

translate([24, 28, 0]) cube([1, 1, 6.50007101051669]);

color([0,1,0])
translate([25, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 28, 0]) cube([1, 1, 6]);

translate([30, 28, 0]) cube([1, 1, 5.300281616036003]);

translate([31, 28, 0]) cube([1, 1, 5.2005149458375595]);

translate([32, 28, 0]) cube([1, 1, 5.102365566095243]);

translate([33, 28, 0]) cube([1, 1, 5.300013895374832]);

color([0,1,0])
translate([34, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 28, 0]) cube([1, 1, 6]);

translate([0, 29, 0]) cube([1, 1, 6.9]);

translate([1, 29, 0]) cube([1, 1, 6.7]);

translate([2, 29, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 29, 0]) cube([1, 1, 6]);

translate([10, 29, 0]) cube([1, 1, 5.300197378949931]);

translate([11, 29, 0]) cube([1, 1, 5.300221432742353]);

translate([12, 29, 0]) cube([1, 1, 5.400208857143939]);

color([0,1,0])
translate([13, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 29, 0]) cube([1, 1, 6]);

translate([19, 29, 0]) cube([1, 1, 6.700148148148148]);

translate([20, 29, 0]) cube([1, 1, 7.0]);

translate([21, 29, 0]) cube([1, 1, 7.1]);

translate([22, 29, 0]) cube([1, 1, 7.0]);

translate([23, 29, 0]) cube([1, 1, 6.800123456790123]);

translate([24, 29, 0]) cube([1, 1, 6.5002508001829]);

color([0,1,0])
translate([25, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 29, 0]) cube([1, 1, 6]);

translate([30, 29, 0]) cube([1, 1, 5.400242864872827]);

translate([31, 29, 0]) cube([1, 1, 5.300204597280878]);

translate([32, 29, 0]) cube([1, 1, 5.200528373832207]);

translate([33, 29, 0]) cube([1, 1, 5.3000683091154395]);

translate([34, 29, 0]) cube([1, 1, 5.400000004818513]);

color([0,1,0])
translate([35, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 29, 0]) cube([1, 1, 6]);

translate([47, 29, 0]) cube([1, 1, 5.3]);

translate([0, 30, 0]) cube([1, 1, 7.0]);

translate([1, 30, 0]) cube([1, 1, 6.9]);

translate([2, 30, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 30, 0]) cube([1, 1, 6]);

translate([9, 30, 0]) cube([1, 1, 5.400000008792973]);

translate([10, 30, 0]) cube([1, 1, 5.300187409280216]);

translate([11, 30, 0]) cube([1, 1, 5.300205375981306]);

translate([12, 30, 0]) cube([1, 1, 5.400206690157216]);

color([0,1,0])
translate([13, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 30, 0]) cube([1, 1, 6]);

translate([19, 30, 0]) cube([1, 1, 6.600635162212963]);

translate([20, 30, 0]) cube([1, 1, 6.9007407407407415]);

translate([21, 30, 0]) cube([1, 1, 7.0]);

translate([22, 30, 0]) cube([1, 1, 6.9007407407407415]);

translate([23, 30, 0]) cube([1, 1, 6.701308641975309]);

color([0,1,0])
translate([24, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 30, 0]) cube([1, 1, 6]);

translate([31, 30, 0]) cube([1, 1, 5.4001855022860905]);

translate([32, 30, 0]) cube([1, 1, 5.300170565048959]);

translate([33, 30, 0]) cube([1, 1, 5.300141147295478]);

translate([34, 30, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([35, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 30, 0]) cube([1, 1, 6]);

translate([46, 30, 0]) cube([1, 1, 5.4]);

translate([47, 30, 0]) cube([1, 1, 5.1]);

translate([0, 31, 0]) cube([1, 1, 7.1]);

translate([1, 31, 0]) cube([1, 1, 7.0]);

translate([2, 31, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 31, 0]) cube([1, 1, 6]);

translate([7, 31, 0]) cube([1, 1, 5.400000001711708]);

translate([8, 31, 0]) cube([1, 1, 5.300055633438516]);

translate([9, 31, 0]) cube([1, 1, 5.300091250609415]);

translate([10, 31, 0]) cube([1, 1, 5.300159069930566]);

translate([11, 31, 0]) cube([1, 1, 5.400062453015107]);

color([0,1,0])
translate([12, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 31, 0]) cube([1, 1, 6]);

translate([19, 31, 0]) cube([1, 1, 6.601047811214851]);

translate([20, 31, 0]) cube([1, 1, 6.801158271935352]);

translate([21, 31, 0]) cube([1, 1, 6.903703703703704]);

translate([22, 31, 0]) cube([1, 1, 6.805679012345679]);

translate([23, 31, 0]) cube([1, 1, 6.513561686710769]);

color([0,1,0])
translate([24, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 31, 0]) cube([1, 1, 6]);

translate([32, 31, 0]) cube([1, 1, 5.400143659353189]);

translate([33, 31, 0]) cube([1, 1, 5.300209125105109]);

translate([34, 31, 0]) cube([1, 1, 5.300188868449053]);

translate([35, 31, 0]) cube([1, 1, 5.300082344920796]);

translate([36, 31, 0]) cube([1, 1, 5.300066904270716]);

translate([37, 31, 0]) cube([1, 1, 5.400000067184155]);

color([0,1,0])
translate([38, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 31, 0]) cube([1, 1, 6]);

translate([46, 31, 0]) cube([1, 1, 5.3]);

translate([47, 31, 0]) cube([1, 1, 5.0]);

translate([0, 32, 0]) cube([1, 1, 7.2]);

translate([1, 32, 0]) cube([1, 1, 7.0]);

translate([2, 32, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 32, 0]) cube([1, 1, 6]);

translate([6, 32, 0]) cube([1, 1, 5.3000000174190225]);

translate([7, 32, 0]) cube([1, 1, 5.200081973587499]);

translate([8, 32, 0]) cube([1, 1, 5.300048606939394]);

translate([9, 32, 0]) cube([1, 1, 5.30007552646221]);

translate([10, 32, 0]) cube([1, 1, 5.400018507568756]);

color([0,1,0])
translate([11, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 32, 0]) cube([1, 1, 6]);

translate([19, 32, 0]) cube([1, 1, 6.601465293525749]);

translate([20, 32, 0]) cube([1, 1, 6.8023411833099185]);

translate([21, 32, 0]) cube([1, 1, 6.372078906165641]);

translate([22, 32, 0]) cube([1, 1, 6.739579061756761]);

translate([23, 32, 0]) cube([1, 1, 6.519040407014591]);

color([0,1,0])
translate([24, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 32, 0]) cube([1, 1, 6]);

translate([33, 32, 0]) cube([1, 1, 5.400130549011572]);

translate([34, 32, 0]) cube([1, 1, 5.400046807602863]);

translate([35, 32, 0]) cube([1, 1, 5.400011361326012]);

translate([36, 32, 0]) cube([1, 1, 5.300066920384525]);

translate([37, 32, 0]) cube([1, 1, 5.300067369119782]);

translate([38, 32, 0]) cube([1, 1, 5.400000273572059]);

color([0,1,0])
translate([39, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 32, 0]) cube([1, 1, 6]);

translate([45, 32, 0]) cube([1, 1, 5.4]);

translate([46, 32, 0]) cube([1, 1, 5.1]);

translate([47, 32, 0]) cube([1, 1, 4.9]);

translate([0, 33, 0]) cube([1, 1, 7.1]);

translate([1, 33, 0]) cube([1, 1, 7.0]);

translate([2, 33, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 33, 0]) cube([1, 1, 6]);

translate([5, 33, 0]) cube([1, 1, 5.400000070615403]);

translate([6, 33, 0]) cube([1, 1, 5.2000819780587495]);

translate([7, 33, 0]) cube([1, 1, 5.200082034503141]);

translate([8, 33, 0]) cube([1, 1, 5.300032282603779]);

color([0,1,0])
translate([9, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 33, 0]) cube([1, 1, 6]);

translate([19, 33, 0]) cube([1, 1, 6.601610675704501]);

translate([20, 33, 0]) cube([1, 1, 6.802655333654416]);

translate([21, 33, 0]) cube([1, 1, 6.810511373861714]);

translate([22, 33, 0]) cube([1, 1, 6.73978429893143]);

translate([23, 33, 0]) cube([1, 1, 6.517585559103777]);

color([0,1,0])
translate([24, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 33, 0]) cube([1, 1, 6]);

translate([36, 33, 0]) cube([1, 1, 5.400003826052878]);

translate([37, 33, 0]) cube([1, 1, 5.400000771999527]);

translate([38, 33, 0]) cube([1, 1, 5.400000363696514]);

color([0,1,0])
translate([39, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 33, 0]) cube([1, 1, 6]);

translate([44, 33, 0]) cube([1, 1, 5.4]);

translate([45, 33, 0]) cube([1, 1, 5.2]);

translate([46, 33, 0]) cube([1, 1, 5.0]);

translate([47, 33, 0]) cube([1, 1, 4.8]);

translate([0, 34, 0]) cube([1, 1, 7.0]);

translate([1, 34, 0]) cube([1, 1, 6.9]);

translate([2, 34, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 34, 0]) cube([1, 1, 6]);

translate([5, 34, 0]) cube([1, 1, 5.40000028290358]);

translate([6, 34, 0]) cube([1, 1, 5.30000403783507]);

translate([7, 34, 0]) cube([1, 1, 5.300009324970833]);

color([0,1,0])
translate([8, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 34, 0]) cube([1, 1, 6]);

translate([18, 34, 0]) cube([1, 1, 6.600541615521446]);

translate([19, 34, 0]) cube([1, 1, 6.700891640585856]);

translate([20, 34, 0]) cube([1, 1, 6.900705467372134]);

translate([21, 34, 0]) cube([1, 1, 6.904232804232804]);

translate([22, 34, 0]) cube([1, 1, 6.806622979879783]);

translate([23, 34, 0]) cube([1, 1, 6.51317636155773]);

color([0,1,0])
translate([24, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 34, 0]) cube([1, 1, 6]);

translate([43, 34, 0]) cube([1, 1, 5.4]);

translate([44, 34, 0]) cube([1, 1, 5.3]);

translate([45, 34, 0]) cube([1, 1, 5.1]);

translate([46, 34, 0]) cube([1, 1, 4.9]);

translate([47, 34, 0]) cube([1, 1, 4.8]);

translate([0, 35, 0]) cube([1, 1, 6.8]);

translate([1, 35, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 35, 0]) cube([1, 1, 6]);

translate([17, 35, 0]) cube([1, 1, 6.60011537777801]);

translate([18, 35, 0]) cube([1, 1, 6.800029394473839]);

translate([19, 35, 0]) cube([1, 1, 6.900176366843034]);

translate([20, 35, 0]) cube([1, 1, 7.0]);

translate([21, 35, 0]) cube([1, 1, 7.0]);

translate([22, 35, 0]) cube([1, 1, 6.801888969873664]);

translate([23, 35, 0]) cube([1, 1, 6.504413221057182]);

color([0,1,0])
translate([24, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 35, 0]) cube([1, 1, 6]);

translate([42, 35, 0]) cube([1, 1, 5.400000001296591]);

translate([43, 35, 0]) cube([1, 1, 5.300000001093528]);

translate([44, 35, 0]) cube([1, 1, 5.1000000011540925]);

translate([45, 35, 0]) cube([1, 1, 4.900000000410698]);

translate([46, 35, 0]) cube([1, 1, 4.8]);

translate([47, 35, 0]) cube([1, 1, 4.7]);

translate([0, 36, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 36, 0]) cube([1, 1, 6]);

translate([16, 36, 0]) cube([1, 1, 6.600024486490345]);

translate([17, 36, 0]) cube([1, 1, 6.800005878894767]);

translate([18, 36, 0]) cube([1, 1, 7.0]);

translate([19, 36, 0]) cube([1, 1, 7.1]);

translate([20, 36, 0]) cube([1, 1, 7.1]);

translate([21, 36, 0]) cube([1, 1, 7.1]);

translate([22, 36, 0]) cube([1, 1, 6.800377793974732]);

translate([23, 36, 0]) cube([1, 1, 6.501351108740106]);

color([0,1,0])
translate([24, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 36, 0]) cube([1, 1, 6]);

translate([40, 36, 0]) cube([1, 1, 5.400000023691197]);

translate([41, 36, 0]) cube([1, 1, 5.400000009923286]);

translate([42, 36, 0]) cube([1, 1, 5.300000007613317]);

translate([43, 36, 0]) cube([1, 1, 5.100000007716653]);

translate([44, 36, 0]) cube([1, 1, 4.900000006121779]);

translate([45, 36, 0]) cube([1, 1, 4.800000002985196]);

translate([46, 36, 0]) cube([1, 1, 4.700000001579714]);

translate([47, 36, 0]) cube([1, 1, 4.6]);

color([0,1,0])
translate([0, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 37, 0]) cube([1, 1, 6]);

translate([16, 37, 0]) cube([1, 1, 6.7000011757789535]);

translate([17, 37, 0]) cube([1, 1, 7.0]);

translate([18, 37, 0]) cube([1, 1, 7.2]);

translate([19, 37, 0]) cube([1, 1, 7.2]);

translate([20, 37, 0]) cube([1, 1, 7.2]);

translate([21, 37, 0]) cube([1, 1, 7.0]);

translate([22, 37, 0]) cube([1, 1, 6.700075558794947]);

color([0,1,0])
translate([23, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 37, 0]) cube([1, 1, 6]);

translate([38, 37, 0]) cube([1, 1, 5.400000073686628]);

translate([39, 37, 0]) cube([1, 1, 5.400000047388739]);

translate([40, 37, 0]) cube([1, 1, 5.400000028579191]);

translate([41, 37, 0]) cube([1, 1, 5.300000028975763]);

translate([42, 37, 0]) cube([1, 1, 5.200000018536938]);

translate([43, 37, 0]) cube([1, 1, 5.100000010615291]);

translate([44, 37, 0]) cube([1, 1, 4.900000008877459]);

translate([45, 37, 0]) cube([1, 1, 4.700000006463121]);

translate([46, 37, 0]) cube([1, 1, 4.6000000026545145]);

translate([47, 37, 0]) cube([1, 1, 4.500000002544988]);

color([0,1,0])
translate([0, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 38, 0]) cube([1, 1, 6]);

translate([15, 38, 0]) cube([1, 1, 6.6000002351557905]);

translate([16, 38, 0]) cube([1, 1, 6.8]);

translate([17, 38, 0]) cube([1, 1, 7.0]);

translate([18, 38, 0]) cube([1, 1, 7.2]);

translate([19, 38, 0]) cube([1, 1, 7.2]);

translate([20, 38, 0]) cube([1, 1, 7.1]);

translate([21, 38, 0]) cube([1, 1, 6.9]);

translate([22, 38, 0]) cube([1, 1, 6.500015111758989]);

color([0,1,0])
translate([23, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 38, 0]) cube([1, 1, 6]);

translate([37, 38, 0]) cube([1, 1, 5.400000104441062]);

translate([38, 38, 0]) cube([1, 1, 5.400000077161552]);

translate([39, 38, 0]) cube([1, 1, 5.400000062191148]);

translate([40, 38, 0]) cube([1, 1, 5.400000040269807]);

translate([41, 38, 0]) cube([1, 1, 5.400000015308947]);

translate([42, 38, 0]) cube([1, 1, 5.300000014937109]);

translate([43, 38, 0]) cube([1, 1, 5.100000015195481]);

translate([44, 38, 0]) cube([1, 1, 5.0000000064967915]);

translate([45, 38, 0]) cube([1, 1, 4.80000000281082]);

translate([46, 38, 0]) cube([1, 1, 4.600000002417897]);

translate([47, 38, 0]) cube([1, 1, 4.500000004168441]);

color([0,1,0])
translate([0, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 39, 0]) cube([1, 1, 6]);

translate([14, 39, 0]) cube([1, 1, 6.5000000470311585]);

translate([15, 39, 0]) cube([1, 1, 6.7]);

translate([16, 39, 0]) cube([1, 1, 6.8]);

translate([17, 39, 0]) cube([1, 1, 6.9]);

translate([18, 39, 0]) cube([1, 1, 7.0]);

translate([19, 39, 0]) cube([1, 1, 7.0]);

translate([20, 39, 0]) cube([1, 1, 6.8]);

translate([21, 39, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([22, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 39, 0]) cube([1, 1, 6]);

translate([37, 39, 0]) cube([1, 1, 5.400000154730433]);

translate([38, 39, 0]) cube([1, 1, 5.400000108239151]);

translate([39, 39, 0]) cube([1, 1, 5.400000094676314]);

color([0,1,0])
translate([40, 39, 0]) cube([1, 1, 6]);

translate([41, 39, 0]) cube([1, 1, 5.400000020663487]);

translate([42, 39, 0]) cube([1, 1, 5.400000011019584]);

translate([43, 39, 0]) cube([1, 1, 5.300000006871741]);

translate([44, 39, 0]) cube([1, 1, 5.200000000201528]);

translate([45, 39, 0]) cube([1, 1, 5.000000000259859]);

translate([46, 39, 0]) cube([1, 1, 4.8]);

translate([47, 39, 0]) cube([1, 1, 4.6]);

color([0,1,0])
translate([0, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 40, 0]) cube([1, 1, 6]);

translate([13, 40, 0]) cube([1, 1, 6.500000007838526]);

translate([14, 40, 0]) cube([1, 1, 6.6]);

translate([15, 40, 0]) cube([1, 1, 6.7]);

translate([16, 40, 0]) cube([1, 1, 6.8]);

translate([17, 40, 0]) cube([1, 1, 6.8]);

translate([18, 40, 0]) cube([1, 1, 6.8]);

translate([19, 40, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([20, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 40, 0]) cube([1, 1, 6]);

translate([45, 40, 0]) cube([1, 1, 5.3]);

translate([46, 40, 0]) cube([1, 1, 5.1]);

translate([47, 40, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 41, 0]) cube([1, 1, 6]);

translate([13, 41, 0]) cube([1, 1, 6.500000001306421]);

translate([14, 41, 0]) cube([1, 1, 6.7]);

translate([15, 41, 0]) cube([1, 1, 6.7]);

translate([16, 41, 0]) cube([1, 1, 6.6]);

translate([17, 41, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([18, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 41, 0]) cube([1, 1, 6]);

translate([47, 41, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([0, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 42, 0]) cube([1, 1, 6]);

translate([14, 42, 0]) cube([1, 1, 6.500000000217737]);

color([0,1,0])
translate([15, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 42, 0]) cube([1, 1, 6]);

translate([40, 42, 0]) cube([1, 1, 5.400000039552341]);

translate([41, 42, 0]) cube([1, 1, 5.400000016325856]);

color([0,1,0])
translate([42, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 42, 0]) cube([1, 1, 6]);

translate([47, 42, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([0, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 43, 0]) cube([1, 1, 6]);

translate([39, 43, 0]) cube([1, 1, 5.400000053202725]);

translate([40, 43, 0]) cube([1, 1, 5.3000000637385245]);

translate([41, 43, 0]) cube([1, 1, 5.300000062500625]);

translate([42, 43, 0]) cube([1, 1, 5.4000000039876594]);

color([0,1,0])
translate([43, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 44, 0]) cube([1, 1, 6]);

translate([7, 44, 0]) cube([1, 1, 5.4000001296629065]);

translate([8, 44, 0]) cube([1, 1, 5.300000287297426]);

translate([9, 44, 0]) cube([1, 1, 5.400000172167853]);

color([0,1,0])
translate([10, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 44, 0]) cube([1, 1, 6]);

translate([33, 44, 0]) cube([1, 1, 5.400024521895169]);

translate([34, 44, 0]) cube([1, 1, 5.400010105645707]);

color([0,1,0])
translate([35, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 44, 0]) cube([1, 1, 6]);

translate([38, 44, 0]) cube([1, 1, 5.400000084624039]);

translate([39, 44, 0]) cube([1, 1, 5.4000000453012325]);

translate([40, 44, 0]) cube([1, 1, 5.3000000590036676]);

translate([41, 44, 0]) cube([1, 1, 5.30000006026463]);

translate([42, 44, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([43, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 45, 0]) cube([1, 1, 6]);

translate([1, 45, 0]) cube([1, 1, 5.4]);

translate([2, 45, 0]) cube([1, 1, 5.4000000006640745]);

translate([3, 45, 0]) cube([1, 1, 5.400000003167424]);

color([0,1,0])
translate([4, 45, 0]) cube([1, 1, 6]);

translate([5, 45, 0]) cube([1, 1, 5.400000018903361]);

translate([6, 45, 0]) cube([1, 1, 5.3000000461150725]);

translate([7, 45, 0]) cube([1, 1, 5.200000106065352]);

translate([8, 45, 0]) cube([1, 1, 5.100000163522762]);

translate([9, 45, 0]) cube([1, 1, 5.100000170200843]);

translate([10, 45, 0]) cube([1, 1, 5.2000000707280085]);

translate([11, 45, 0]) cube([1, 1, 5.300000033125323]);

translate([12, 45, 0]) cube([1, 1, 5.400000009365443]);

color([0,1,0])
translate([13, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 45, 0]) cube([1, 1, 6]);

translate([16, 45, 0]) cube([1, 1, 5.4]);

translate([17, 45, 0]) cube([1, 1, 5.3000370362584]);

translate([18, 45, 0]) cube([1, 1, 5.200589008399249]);

translate([19, 45, 0]) cube([1, 1, 5.201393113903389]);

translate([20, 45, 0]) cube([1, 1, 5.303219262869026]);

translate([21, 45, 0]) cube([1, 1, 5.40643629236785]);

color([0,1,0])
translate([22, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 45, 0]) cube([1, 1, 6]);

translate([32, 45, 0]) cube([1, 1, 5.400056676172215]);

translate([33, 45, 0]) cube([1, 1, 5.300043233221851]);

translate([34, 45, 0]) cube([1, 1, 5.300020066958242]);

translate([35, 45, 0]) cube([1, 1, 5.400001814649895]);

translate([36, 45, 0]) cube([1, 1, 5.4000005399299384]);

translate([37, 45, 0]) cube([1, 1, 5.400000144545044]);

translate([38, 45, 0]) cube([1, 1, 5.400000060164234]);

translate([39, 45, 0]) cube([1, 1, 5.300000060415614]);

translate([40, 45, 0]) cube([1, 1, 5.300000058513769]);

translate([41, 45, 0]) cube([1, 1, 5.300000061761796]);

color([0,1,0])
translate([42, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 45, 0]) cube([1, 1, 6]);

translate([0, 46, 0]) cube([1, 1, 5.3]);

translate([1, 46, 0]) cube([1, 1, 5.3]);

translate([2, 46, 0]) cube([1, 1, 5.300000000714799]);

translate([3, 46, 0]) cube([1, 1, 5.300000002732235]);

translate([4, 46, 0]) cube([1, 1, 5.300000007314538]);

translate([5, 46, 0]) cube([1, 1, 5.3000000114304875]);

translate([6, 46, 0]) cube([1, 1, 5.200000036457256]);

translate([7, 46, 0]) cube([1, 1, 5.100000070140077]);

translate([8, 46, 0]) cube([1, 1, 5.000000108433635]);

translate([9, 46, 0]) cube([1, 1, 4.9000001671174305]);

translate([10, 46, 0]) cube([1, 1, 5.000000059450273]);

translate([11, 46, 0]) cube([1, 1, 5.100000023906976]);

translate([12, 46, 0]) cube([1, 1, 5.2000000069630525]);

translate([13, 46, 0]) cube([1, 1, 5.200000002899309]);

translate([14, 46, 0]) cube([1, 1, 5.2]);

translate([15, 46, 0]) cube([1, 1, 5.1]);

translate([16, 46, 0]) cube([1, 1, 5.000007406549443]);

translate([17, 46, 0]) cube([1, 1, 4.90012668993776]);

translate([18, 46, 0]) cube([1, 1, 4.801161609595363]);

translate([19, 46, 0]) cube([1, 1, 4.902500592155757]);

translate([20, 46, 0]) cube([1, 1, 5.007301576491737]);

translate([21, 46, 0]) cube([1, 1, 5.209171397888469]);

translate([22, 46, 0]) cube([1, 1, 5.406166789716967]);

color([0,1,0])
translate([23, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 46, 0]) cube([1, 1, 6]);

translate([32, 46, 0]) cube([1, 1, 5.400052736680043]);

translate([33, 46, 0]) cube([1, 1, 5.2000630643143175]);

translate([34, 46, 0]) cube([1, 1, 5.2000256356593875]);

translate([35, 46, 0]) cube([1, 1, 5.2000096114394925]);

translate([36, 46, 0]) cube([1, 1, 5.20000305843949]);

translate([37, 46, 0]) cube([1, 1, 5.300000124032161]);

translate([38, 46, 0]) cube([1, 1, 5.300000062983897]);

translate([39, 46, 0]) cube([1, 1, 5.300000058779173]);

translate([40, 46, 0]) cube([1, 1, 5.300000059484097]);

translate([41, 46, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([42, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 46, 0]) cube([1, 1, 6]);

translate([0, 47, 0]) cube([1, 1, 5.2]);

translate([1, 47, 0]) cube([1, 1, 5.100000007260448]);

translate([2, 47, 0]) cube([1, 1, 5.100000007902857]);

translate([3, 47, 0]) cube([1, 1, 5.200000013886595]);

translate([4, 47, 0]) cube([1, 1, 5.200000018318893]);

translate([5, 47, 0]) cube([1, 1, 5.2000000191662465]);

translate([6, 47, 0]) cube([1, 1, 5.100000068597033]);

translate([7, 47, 0]) cube([1, 1, 5.0000001248677775]);

translate([8, 47, 0]) cube([1, 1, 4.900000186528519]);

translate([9, 47, 0]) cube([1, 1, 4.800000410080407]);

translate([10, 47, 0]) cube([1, 1, 4.800000411513849]);

translate([11, 47, 0]) cube([1, 1, 4.9000000495897265]);

translate([12, 47, 0]) cube([1, 1, 5.000000010975822]);

translate([13, 47, 0]) cube([1, 1, 5.000000009628984]);

translate([14, 47, 0]) cube([1, 1, 5.000000005756282]);

translate([15, 47, 0]) cube([1, 1, 4.9000037032321195]);

translate([16, 47, 0]) cube([1, 1, 4.700068898633663]);

translate([17, 47, 0]) cube([1, 1, 4.600682301677897]);

translate([18, 47, 0]) cube([1, 1, 4.5179181225584975]);

translate([19, 47, 0]) cube([1, 1, 4.613446929191724]);

translate([20, 47, 0]) cube([1, 1, 4.815930080857303]);

translate([21, 47, 0]) cube([1, 1, 5.012886595967586]);

translate([22, 47, 0]) cube([1, 1, 5.21942124467983]);

translate([23, 47, 0]) cube([1, 1, 5.237140125825712]);

translate([24, 47, 0]) cube([1, 1, 5.250323248029657]);

translate([25, 47, 0]) cube([1, 1, 5.336300389242508]);

translate([26, 47, 0]) cube([1, 1, 5.423396956118433]);

color([0,1,0])
translate([27, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 47, 0]) cube([1, 1, 6]);

translate([32, 47, 0]) cube([1, 1, 5.300079544550304]);

translate([33, 47, 0]) cube([1, 1, 5.100110490602026]);

translate([34, 47, 0]) cube([1, 1, 5.100104401007615]);

translate([35, 47, 0]) cube([1, 1, 5.100078143409197]);

translate([36, 47, 0]) cube([1, 1, 5.100078512785911]);

translate([37, 47, 0]) cube([1, 1, 5.200001161630604]);

translate([38, 47, 0]) cube([1, 1, 5.200001226754013]);

translate([39, 47, 0]) cube([1, 1, 5.300000060368391]);

translate([40, 47, 0]) cube([1, 1, 5.300000062828713]);

translate([41, 47, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([42, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 47, 0]) cube([1, 1, 6]);

translate([46, 47, 0]) cube([1, 1, 5.4]);

translate([47, 47, 0]) cube([1, 1, 5.3]);
