
hull() {
    translate([5.0075, 5.0075, 47.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.142500000000001, 5.142500000000001, 47.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.157500000000001, 5.157500000000001, 46.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2924999999999995, 5.2924999999999995, 46.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.307499999999999, 5.307499999999999, 45.949999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.4425, 5.4425, 45.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.4575000000000005, 5.4575000000000005, 44.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.5925, 5.5925, 44.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.6075, 5.6075, 43.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.7425, 5.7425, 43.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.7575, 5.7575, 42.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.8925, 5.8925, 42.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.907500000000001, 5.907500000000001, 41.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.0425, 6.0425, 41.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.0575, 6.0575, 40.949999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.1925, 6.1925, 40.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.2075000000000005, 6.2075000000000005, 39.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.3425, 6.3425, 39.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.3575, 6.3575, 38.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.492500000000001, 6.492500000000001, 38.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.5075, 6.5075, 37.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.6425, 6.6425, 37.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.657500000000001, 6.657500000000001, 36.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.7925, 6.7925, 36.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.8075, 6.8075, 35.949999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.9425, 6.9425, 35.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.9575, 6.9575, 34.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.092499999999999, 7.092499999999999, 34.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.1075, 7.1075, 33.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.242500000000001, 7.242500000000001, 33.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.2575, 7.2575, 32.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.3925, 7.3925, 32.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.407500000000001, 7.407500000000001, 31.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.5425, 7.5425, 31.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.5575, 7.5575, 30.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.692500000000001, 7.692500000000001, 30.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.7075000000000005, 7.7075000000000005, 29.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.842499999999999, 7.842499999999999, 29.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.8575, 7.8575, 28.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.9925, 7.9925, 28.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.0075, 8.0075, 27.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.1425, 8.1425, 27.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.1575, 8.1575, 26.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.2925, 8.2925, 26.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.307500000000001, 8.307500000000001, 25.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.442499999999999, 8.442499999999999, 25.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.4575, 8.4575, 24.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.5925, 8.5925, 24.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.6075, 8.6075, 23.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.7425, 8.7425, 23.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.7575, 8.7575, 22.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.8925, 8.8925, 22.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.9075, 8.9075, 21.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.042500000000002, 9.042500000000002, 21.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.057500000000001, 9.057500000000001, 20.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.192499999999999, 9.192499999999999, 20.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.2075, 9.2075, 19.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3425, 9.3425, 19.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3575, 9.3575, 18.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.492500000000001, 9.492500000000001, 18.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.5075, 9.5075, 17.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.6425, 9.6425, 17.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.6575, 9.6575, 16.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7925, 9.7925, 16.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.807500000000001, 9.807500000000001, 15.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.9425, 9.9425, 15.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.9575, 9.9575, 14.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0925, 10.0925, 14.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.1075, 10.1075, 13.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.2425, 10.2425, 13.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.2575, 10.2575, 12.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.392500000000002, 10.392500000000002, 12.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.4075, 10.4075, 11.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.5425, 10.5425, 11.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.557500000000001, 10.557500000000001, 10.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.692499999999999, 10.692499999999999, 10.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.7075, 10.7075, 9.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.842500000000001, 10.842500000000001, 9.049999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.8575, 10.8575, 8.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.9925, 10.9925, 8.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.0075, 11.0075, 7.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.1425, 11.1425, 7.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.1575, 11.1575, 6.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.292500000000002, 11.292500000000002, 6.050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.307500000000001, 11.307500000000001, 5.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.442499999999999, 11.442499999999999, 5.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.4575, 11.4575, 4.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.5925, 11.5925, 4.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.6075, 11.6075, 3.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.742500000000001, 11.742500000000001, 3.0500000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.7575, 11.7575, 2.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.8925, 11.8925, 2.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.9075, 11.9075, 1.9500000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0425, 12.0425, 1.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.057500000000001, 12.057500000000001, 0.9500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.1925, 12.1925, 0.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.164, 12.164, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.516, 11.516, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.444, 11.444, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.796, 10.796, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.723999999999998, 10.723999999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.075999999999999, 10.075999999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.004, 10.004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.356, 9.356, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.284, 9.284, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.636000000000001, 8.636000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.564, 8.564, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.9159999999999995, 7.9159999999999995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.843999999999999, 7.843999999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.196, 7.196, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.1240000000000006, 7.1240000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.476000000000001, 6.476000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.404, 6.404, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.756, 5.756, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.683999999999999, 5.683999999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.036, 5.036, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.087, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.6530000000000005, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.827000000000001, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.393, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.567, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.133000000000001, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.307, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.873000000000001, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.047, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.613, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.787, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.353, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.527, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.093, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.267, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.833000000000002, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.007, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.573, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.747, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.313, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.487000000000002, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.053000000000004, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.227000000000004, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.793, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.967, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.533, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.707, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.273, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.447, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.013, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.187, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.75300000000001, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.92700000000001, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.493, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.667, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.233000000000004, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.407000000000004, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.973000000000006, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.147000000000006, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.713, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.887, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.453, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.627, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.193000000000005, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.367000000000004, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.933, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 5.087, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 6.6530000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 6.827000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 8.393, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 8.567, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 10.133000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 10.307, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 11.873000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 12.047, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 13.613, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 13.787, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 15.353, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 15.527, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 17.093, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 17.267, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 18.833000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 19.007, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 20.573, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 20.747, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 22.313, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 22.487000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 24.053000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 24.227000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 25.793, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 25.967, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 27.533, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 27.707, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 29.273, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 29.447, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 31.013, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 31.187, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 32.75300000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 32.92700000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 34.493, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 34.667, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 36.233000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 36.407000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 37.973000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 38.147000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 39.713, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 39.887, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 41.453, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 41.627, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 43.193000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 43.367000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 44.933, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.933, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.367000000000004, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.193000000000005, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.627, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.453, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.887, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.713, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.147000000000006, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.973000000000006, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.407000000000004, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.233000000000004, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.667, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.493, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.92700000000001, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.75300000000001, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.187, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.013, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.447, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.273, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.707, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.533, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.967, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.793, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.227000000000004, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.053000000000004, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.487000000000002, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.313, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.747, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.573, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.007, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.833000000000002, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.267, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.093, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.527, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.353, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.787, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.613, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.047, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.873000000000001, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.307, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.133000000000001, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.567, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.393, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.827000000000001, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.6530000000000005, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.087, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 44.933, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 43.367000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 43.193000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 41.627, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 41.453, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 39.887, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 39.713, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 38.147000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 37.973000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 36.407000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 36.233000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 34.667, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 34.493, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 32.92700000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 32.75300000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 31.187, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 31.013, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 29.447, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 29.273, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 27.707, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 27.533, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 25.967, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 25.793, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 24.227000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 24.053000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 22.487000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 22.313, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 20.747, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 20.573, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 19.007, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 18.833000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 17.267, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 17.093, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 15.527, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 15.353, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 13.787, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 13.613, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 12.047, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 11.873000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 10.307, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 10.133000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 8.567, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 8.393, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 6.827000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 6.6530000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 5.087, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.087, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.6530000000000005, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.827000000000001, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.393, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.567, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.133000000000001, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.307, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.873000000000001, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.047, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.613, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.787, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.353, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.527, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.093, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.267, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.833000000000002, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.007, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.573, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.747, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.313, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.487000000000002, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.053000000000004, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.227000000000004, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.793, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.967, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.533, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.707, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.273, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.447, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.013, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.187, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.75300000000001, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.92700000000001, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.493, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.667, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.233000000000004, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.407000000000004, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.973000000000006, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.147000000000006, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.713, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.887, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.453, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.627, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.193000000000005, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.367000000000004, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.933, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 5.087, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 6.6530000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 6.827000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 8.393, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 8.567, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 10.133000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 10.307, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 11.873000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 12.047, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 13.613, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 13.787, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 15.353, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 15.527, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 17.093, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 17.267, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 18.833000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 19.007, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 20.573, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 20.747, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 22.313, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 22.487000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 24.053000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 24.227000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 25.793, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 25.967, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 27.533, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 27.707, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 29.273, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 29.447, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 31.013, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 31.187, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 32.75300000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 32.92700000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 34.493, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 34.667, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 36.233000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 36.407000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 37.973000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 38.147000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 39.713, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 39.887, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 41.453, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 41.627, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 43.193000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 43.367000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 44.933, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.933, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.367000000000004, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.193000000000005, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.627, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.453, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.887, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.713, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.147000000000006, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.973000000000006, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.407000000000004, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.233000000000004, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.667, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.493, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.92700000000001, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.75300000000001, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.187, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.013, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.447, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.273, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.707, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.533, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.967, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.793, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.227000000000004, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.053000000000004, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.487000000000002, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.313, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.747, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.573, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.007, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.833000000000002, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.267, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.093, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.527, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.353, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.787, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.613, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.047, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.873000000000001, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.307, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.133000000000001, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.567, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.393, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.827000000000001, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.6530000000000005, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.087, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 44.933, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 43.367000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 43.193000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 41.627, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 41.453, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 39.887, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 39.713, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 38.147000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 37.973000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 36.407000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 36.233000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 34.667, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 34.493, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 32.92700000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 32.75300000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 31.187, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 31.013, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 29.447, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 29.273, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 27.707, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 27.533, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 25.967, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 25.793, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 24.227000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 24.053000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 22.487000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 22.313, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 20.747, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 20.573, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 19.007, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 18.833000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 17.267, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 17.093, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 15.527, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 15.353, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 13.787, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 13.613, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 12.047, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 11.873000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 10.307, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 10.133000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 8.567, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 8.393, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 6.827000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 6.6530000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 5.087, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.087, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.6530000000000005, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.827000000000001, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.393, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.567, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.133000000000001, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.307, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.873000000000001, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.047, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.613, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.787, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.353, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.527, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.093, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.267, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.833000000000002, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.007, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.573, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.747, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.313, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.487000000000002, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.053000000000004, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.227000000000004, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.793, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.967, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.533, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.707, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.273, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.447, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.013, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.187, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.75300000000001, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.92700000000001, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.493, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.667, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.233000000000004, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.407000000000004, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.973000000000006, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.147000000000006, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.713, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.887, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.453, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.627, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.193000000000005, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.367000000000004, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.933, 5.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 5.087, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 6.6530000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 6.827000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 8.393, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 8.567, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 10.133000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 10.307, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 11.873000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 12.047, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 13.613, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 13.787, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 15.353, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 15.527, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 17.093, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 17.267, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 18.833000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 19.007, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 20.573, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 20.747, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 22.313, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 22.487000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 24.053000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 24.227000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 25.793, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 25.967, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 27.533, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 27.707, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 29.273, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 29.447, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 31.013, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 31.187, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 32.75300000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 32.92700000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 34.493, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 34.667, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 36.233000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 36.407000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 37.973000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 38.147000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 39.713, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 39.887, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 41.453, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 41.627, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 43.193000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.02, 43.367000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.02, 44.933, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.933, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.367000000000004, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.193000000000005, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.627, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.453, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.887, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.713, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.147000000000006, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.973000000000006, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.407000000000004, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.233000000000004, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.667, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.493, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.92700000000001, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.75300000000001, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.187, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.013, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.447, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.273, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.707, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.533, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.967, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.793, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.227000000000004, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.053000000000004, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.487000000000002, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.313, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.747, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.573, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.007, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.833000000000002, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.267, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.093, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.527, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.353, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.787, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.613, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.047, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.873000000000001, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.307, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.133000000000001, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.567, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.393, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.827000000000001, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.6530000000000005, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.087, 45.02, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 44.933, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 43.367000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 43.193000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 41.627, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 41.453, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 39.887, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 39.713, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 38.147000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 37.973000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 36.407000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 36.233000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 34.667, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 34.493, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 32.92700000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 32.75300000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 31.187, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 31.013, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 29.447, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 29.273, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 27.707, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 27.533, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 25.967, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 25.793, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 24.227000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 24.053000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 22.487000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 22.313, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 20.747, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 20.573, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 19.007, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 18.833000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 17.267, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 17.093, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 15.527, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 15.353, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 13.787, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 13.613, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 12.047, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 11.873000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 10.307, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 10.133000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 8.567, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 8.393, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 6.827000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 6.6530000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 5.087, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}

