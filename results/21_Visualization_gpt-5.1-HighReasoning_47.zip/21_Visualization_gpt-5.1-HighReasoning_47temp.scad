
hull() {
    translate([57.5, 52.5, 246.88]) cube([0.4, 0.4, 0.1], center=true);
    translate([192.5, 97.5, 190.72]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.88400000000001, 100.0, 187.966]) cube([0.4, 0.4, 0.1], center=true);
    translate([216.796, 100.0, 194.554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([218.046, 100.0, 195.804]) cube([0.4, 0.4, 0.1], center=true);
    translate([224.63400000000001, 100.0, 211.716]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.63400000000001, 100.0, 213.484]) cube([0.4, 0.4, 0.1], center=true);
    translate([218.046, 100.0, 229.39600000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.796, 100.0, 230.64600000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([200.88400000000001, 100.0, 237.234]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([199.11599999999999, 100.0, 237.234]) cube([0.4, 0.4, 0.1], center=true);
    translate([183.204, 100.0, 230.64600000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([181.954, 100.0, 229.39600000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([175.36599999999999, 100.0, 213.484]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([175.36599999999999, 100.0, 211.716]) cube([0.4, 0.4, 0.1], center=true);
    translate([181.954, 100.0, 195.804]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.204, 100.0, 194.554]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.11599999999999, 100.0, 187.966]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.0, 105.0, 185.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([200.0, 195.0, 149.6]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.88400000000001, 200.0, 147.966]) cube([0.4, 0.4, 0.1], center=true);
    translate([216.796, 200.0, 154.554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([218.046, 200.0, 155.804]) cube([0.4, 0.4, 0.1], center=true);
    translate([224.63400000000001, 200.0, 171.716]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.63400000000001, 200.0, 173.484]) cube([0.4, 0.4, 0.1], center=true);
    translate([218.046, 200.0, 189.39600000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.796, 200.0, 190.64600000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([200.88400000000001, 200.0, 197.234]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([199.11599999999999, 200.0, 197.234]) cube([0.4, 0.4, 0.1], center=true);
    translate([183.204, 200.0, 190.64600000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([181.954, 200.0, 189.39600000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([175.36599999999999, 200.0, 173.484]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([175.36599999999999, 200.0, 171.716]) cube([0.4, 0.4, 0.1], center=true);
    translate([181.954, 200.0, 155.804]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.204, 200.0, 154.554]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.11599999999999, 200.0, 147.966]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.0, 200.0, 145.6]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.0, 200.0, 109.60000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.884, 200.0, 107.96600000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.796, 200.0, 114.554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118.046, 200.0, 115.804]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.634, 200.0, 131.716]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([124.634, 200.0, 133.484]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.046, 200.0, 149.39600000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.796, 200.0, 150.64600000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.884, 200.0, 157.234]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.116, 200.0, 157.234]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.204, 200.0, 150.64600000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.954, 200.0, 149.39600000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.366, 200.0, 133.484]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.366, 200.0, 131.716]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.954, 200.0, 115.804]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.204, 200.0, 114.554]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.116, 200.0, 107.96600000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.5, 200.0, 106.72]) cube([0.4, 0.4, 0.1], center=true);
    translate([242.5, 200.0, 90.88]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 202.5, 89.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 247.5, 80.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([240.0, 250.0, 79.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 250.0, 70.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 240.0, 69.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 60.0, 60.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 50.0, 59.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([240.0, 50.0, 50.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 57.5, 49.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 192.5, 40.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 200.0, 39.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 200.0, 35.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 202.5, 34.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 247.5, 30.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([240.0, 250.0, 29.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 250.0, 25.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 240.0, 24.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 60.0, 20.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 50.0, 19.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([240.0, 50.0, 15.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 57.5, 14.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 192.5, 10.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 202.5, 9.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 247.5, 9.049999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([240.0, 250.0, 8.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 250.0, 8.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 240.0, 7.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 60.0, 7.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 50.0, 6.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([240.0, 50.0, 6.050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 57.5, 5.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 192.5, 5.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([247.5, 200.0, 4.875]) cube([0.4, 0.4, 0.1], center=true);
    translate([202.5, 200.0, 2.625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([197.5, 197.5, 2.375]) cube([0.4, 0.4, 0.1], center=true);
    translate([152.5, 152.5, 0.125]) cube([0.4, 0.4, 0.1], center=true);
}

