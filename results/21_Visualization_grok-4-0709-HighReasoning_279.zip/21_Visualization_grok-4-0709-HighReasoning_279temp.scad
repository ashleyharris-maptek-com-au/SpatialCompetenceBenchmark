
hull() {
    translate([150.0, 150.0, 249.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 249.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 249.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 248.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 248.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 247.34500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 247.25500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 246.44500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 246.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 245.54500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 245.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 244.64499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 244.55499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 243.74499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 243.65499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 242.84500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 242.75500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 241.94500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 241.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 241.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 240.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 240.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 240.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 239.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 239.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 238.34500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 238.25500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 237.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 237.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 236.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 236.45499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 235.64499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 235.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 234.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 234.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 233.84500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 233.75500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 232.94500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 232.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 232.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 231.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 231.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 231.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 230.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 230.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 229.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 229.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 228.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 228.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 227.54500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 227.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 226.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 226.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 225.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 225.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 224.84500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 224.75500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 223.94500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 223.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 223.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 222.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 222.14499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 222.05499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 221.24499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 221.15499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 220.34500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 220.25500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 219.44500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 219.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 218.54500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 218.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 217.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 217.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 216.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 216.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 215.84500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 215.75500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 214.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 214.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 214.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 213.95499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 213.14499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 213.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 212.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 212.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 211.34500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 211.25500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 210.44500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 210.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 209.54500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 209.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 208.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 208.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 207.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 207.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 206.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 206.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 205.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 205.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 205.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 204.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 204.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 204.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 203.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 203.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 202.34500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 202.25500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 201.44500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 201.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 200.54500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 200.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 199.64499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 199.55499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 198.74499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 198.65499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 197.84500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 197.75500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 196.94500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 196.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 196.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 195.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 195.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 195.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 194.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 194.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 193.34500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 193.25500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 192.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 192.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 191.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 191.45499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 190.64499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 190.55499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 189.74499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 189.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 188.84500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 188.75500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 187.94500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 187.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 187.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 186.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 186.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 186.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 185.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 185.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 184.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 184.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 183.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 183.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 182.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 182.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 181.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 181.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 180.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 180.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 179.84500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 179.75500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 178.94500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 178.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 178.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 177.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 177.14499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 177.05499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 176.24499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 176.15499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 175.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 175.25500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 174.44500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 174.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 173.54500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 173.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 172.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 172.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 171.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 171.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 170.84500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 170.75500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 169.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 169.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 169.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 168.95499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 168.14499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 168.05499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 167.24499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 167.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 166.34500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 166.25500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 165.44500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 165.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 164.54500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 164.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 163.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 163.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 162.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 162.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 161.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 161.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 160.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 160.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 160.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 159.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 159.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 159.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 158.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 158.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 157.34500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 157.25500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 156.44500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 156.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 155.54500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 155.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 154.64499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 154.55499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 153.74499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 153.65499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 152.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 152.75500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 151.94500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 151.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 151.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 150.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 150.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 150.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 149.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 149.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 148.34500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 148.25500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 147.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 147.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 146.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 146.45499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 145.64499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 145.55499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 144.74499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 144.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 143.84500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 143.75500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 142.94500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 142.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 142.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 141.95499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 141.14499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 141.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 140.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 140.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 139.34500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 139.25500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 138.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 138.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 137.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 137.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 136.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 136.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 135.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 135.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 134.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 134.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 133.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 133.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 133.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 132.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 132.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 132.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 131.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 131.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 130.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 130.25500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 129.44500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 129.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 128.54500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 128.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 127.64500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 127.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 126.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 126.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 125.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 125.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 124.94500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 124.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 124.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 123.95500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 123.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 123.05499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 122.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 122.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 121.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 121.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 120.44500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 120.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 119.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 119.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 118.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 118.55499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 117.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 117.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 116.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 116.75500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 115.94500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 115.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 115.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 114.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 114.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 114.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 113.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 113.15500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 112.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 112.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 111.44500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 111.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 110.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 110.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 109.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 109.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 108.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 108.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 107.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 107.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 106.94500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 106.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 106.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 105.95500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 105.14500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 105.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 104.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 104.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 103.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 103.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 102.44500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 102.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 101.54500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 101.45500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 100.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 100.55499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 99.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 99.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 98.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 98.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 97.94500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 97.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 97.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 96.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 96.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 96.05499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 95.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 95.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 94.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 94.25500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 93.44500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 93.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 92.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 92.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 91.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 91.55499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 90.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 90.65500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 89.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 89.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 88.94500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 88.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 88.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 87.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 87.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 87.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 86.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 86.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 85.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 85.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 84.44500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 84.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 83.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 83.45500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 82.64500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 82.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 81.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 81.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 80.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 80.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 79.94500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 79.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 79.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 78.95500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 78.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 78.05499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 77.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 77.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 76.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 76.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 75.44500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 75.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 74.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 74.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 73.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 73.55499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 72.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 72.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 71.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 71.75500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 70.94500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 70.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 70.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 69.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 69.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 69.05499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 68.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 68.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 67.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 67.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 66.44500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 66.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 65.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 65.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 64.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 64.55499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 63.745000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 63.65500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 62.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 62.754999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 61.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 61.855000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 61.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 60.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 60.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 60.05500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 59.245000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 59.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 58.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 58.254999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 57.44499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 57.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 56.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 56.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 55.644999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 55.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 54.745000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 54.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 53.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 53.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 52.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 52.855000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 52.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 51.955000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 51.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 51.05500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 50.245000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 50.15500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 49.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 49.254999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 48.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 48.355000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 47.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 47.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 46.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 46.55500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 45.745000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 45.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 44.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 44.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 43.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 43.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 43.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 42.955000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 42.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 42.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 41.245000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 41.15500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 40.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 40.254999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 39.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 39.355000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 38.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 38.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 37.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 37.55500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 36.745000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 36.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 35.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 35.754999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 34.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 34.855000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 34.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 33.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 33.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 33.05500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 32.245000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 32.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 31.345000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 31.255000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 30.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 30.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 29.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 29.455000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 28.645000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 28.555000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 27.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 27.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 26.845000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 26.755000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 25.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 25.854999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 25.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 24.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 24.145000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 24.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 23.244999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 23.154999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 22.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 22.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 21.444999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 21.354999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 20.544999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 20.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 19.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 19.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 18.744999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 18.654999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 17.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 17.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 16.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 16.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 16.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 15.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 15.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 15.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 14.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 14.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 13.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 13.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 12.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 12.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 11.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 11.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 10.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 10.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 9.745000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 9.655000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 8.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 8.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 7.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 7.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 7.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 6.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 6.1450000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 6.055000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 5.245000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 5.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 4.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 4.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 3.4450000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 3.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 2.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 2.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 1.6450000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 1.5550000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 0.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 0.665]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 0.034999999999999996]) cube([0.4, 0.4, 0.1], center=true);
}

