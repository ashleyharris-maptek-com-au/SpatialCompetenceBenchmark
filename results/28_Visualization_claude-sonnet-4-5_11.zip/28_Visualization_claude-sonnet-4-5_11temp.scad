
translate([0, 0, 0]) cube([1, 1, 5.01]);

translate([1, 0, 0]) cube([1, 1, 4.700984301150618]);

translate([2, 0, 0]) cube([1, 1, 4.703636238193035]);

translate([3, 0, 0]) cube([1, 1, 4.702210194582293]);

translate([4, 0, 0]) cube([1, 1, 4.704102804804769]);

translate([5, 0, 0]) cube([1, 1, 4.70457215419791]);

translate([6, 0, 0]) cube([1, 1, 4.704552971576922]);

translate([7, 0, 0]) cube([1, 1, 4.7052935750414395]);

translate([8, 0, 0]) cube([1, 1, 4.705144792098777]);

translate([9, 0, 0]) cube([1, 1, 4.704660622395491]);

translate([10, 0, 0]) cube([1, 1, 5.02]);

translate([11, 0, 0]) cube([1, 1, 5.3]);

translate([12, 0, 0]) cube([1, 1, 5.4]);

translate([13, 0, 0]) cube([1, 1, 5.3]);

translate([14, 0, 0]) cube([1, 1, 4.8]);

translate([15, 0, 0]) cube([1, 1, 4.4]);

translate([16, 0, 0]) cube([1, 1, 4.3]);

translate([17, 0, 0]) cube([1, 1, 4.3]);

translate([18, 0, 0]) cube([1, 1, 4.6]);

translate([19, 0, 0]) cube([1, 1, 4.7]);

translate([0, 1, 0]) cube([1, 1, 6.2]);

translate([1, 1, 0]) cube([1, 1, 5.319999999999999]);

translate([2, 1, 0]) cube([1, 1, 4.849999999999999]);

translate([3, 1, 0]) cube([1, 1, 4.70394123826238]);

translate([4, 1, 0]) cube([1, 1, 4.70404273010664]);

translate([5, 1, 0]) cube([1, 1, 4.703955231591723]);

translate([6, 1, 0]) cube([1, 1, 4.704467878518518]);

translate([7, 1, 0]) cube([1, 1, 4.704327941777656]);

translate([8, 1, 0]) cube([1, 1, 4.70475532971405]);

translate([9, 1, 0]) cube([1, 1, 4.704835012248198]);

translate([10, 1, 0]) cube([1, 1, 4.7699999945102185]);

translate([11, 1, 0]) cube([1, 1, 4.719999999999995]);

translate([12, 1, 0]) cube([1, 1, 4.679999999999998]);

translate([13, 1, 0]) cube([1, 1, 4.5]);

translate([14, 1, 0]) cube([1, 1, 4.3]);

translate([15, 1, 0]) cube([1, 1, 4.1]);

translate([16, 1, 0]) cube([1, 1, 3.8]);

translate([17, 1, 0]) cube([1, 1, 3.604827998914101]);

translate([18, 1, 0]) cube([1, 1, 3.8]);

translate([19, 1, 0]) cube([1, 1, 4.0]);

translate([0, 2, 0]) cube([1, 1, 7.0]);

translate([1, 2, 0]) cube([1, 1, 6.109999999999999]);

translate([2, 2, 0]) cube([1, 1, 5.7299999999999995]);

translate([3, 2, 0]) cube([1, 1, 4.703852986016481]);

translate([4, 2, 0]) cube([1, 1, 4.756946868438973]);

translate([5, 2, 0]) cube([1, 1, 4.849160442443509]);

translate([6, 2, 0]) cube([1, 1, 4.863396991976661]);

translate([7, 2, 0]) cube([1, 1, 4.856949262516494]);

translate([8, 2, 0]) cube([1, 1, 4.842185793418169]);

translate([9, 2, 0]) cube([1, 1, 4.829457832399892]);

translate([10, 2, 0]) cube([1, 1, 4.799999999999992]);

translate([11, 2, 0]) cube([1, 1, 4.739999999999993]);

translate([12, 2, 0]) cube([1, 1, 4.379999999999996]);

translate([13, 2, 0]) cube([1, 1, 4.159999999999998]);

translate([14, 2, 0]) cube([1, 1, 3.7]);

translate([15, 2, 0]) cube([1, 1, 3.607214646932603]);

translate([16, 2, 0]) cube([1, 1, 3.6112777455115377]);

translate([17, 2, 0]) cube([1, 1, 3.612036342352954]);

translate([18, 2, 0]) cube([1, 1, 3.6116086067927387]);

translate([19, 2, 0]) cube([1, 1, 3.7]);

translate([0, 3, 0]) cube([1, 1, 7.4]);

translate([1, 3, 0]) cube([1, 1, 6.6]);

translate([2, 3, 0]) cube([1, 1, 6.31]);

translate([3, 3, 0]) cube([1, 1, 4.819999999999995]);

translate([4, 3, 0]) cube([1, 1, 4.939999999999992]);

translate([5, 3, 0]) cube([1, 1, 4.947916666666647]);

translate([6, 3, 0]) cube([1, 1, 5.017499999999973]);

translate([7, 3, 0]) cube([1, 1, 5.081601066468231]);

translate([8, 3, 0]) cube([1, 1, 5.028021418716485]);

translate([9, 3, 0]) cube([1, 1, 5.013694648336522]);

translate([10, 3, 0]) cube([1, 1, 5.049999999999999]);

translate([11, 3, 0]) cube([1, 1, 4.799999999999998]);

translate([12, 3, 0]) cube([1, 1, 4.169999999999996]);

translate([13, 3, 0]) cube([1, 1, 3.889999999999998]);

translate([14, 3, 0]) cube([1, 1, 3.7262075942118282]);

translate([15, 3, 0]) cube([1, 1, 3.6762076063803075]);

translate([16, 3, 0]) cube([1, 1, 3.6095555342928445]);

translate([17, 3, 0]) cube([1, 1, 3.612819350848149]);

translate([18, 3, 0]) cube([1, 1, 3.612083951936314]);

translate([19, 3, 0]) cube([1, 1, 3.6096065142671616]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.2]);

translate([2, 4, 0]) cube([1, 1, 6.9]);

translate([3, 4, 0]) cube([1, 1, 5.469999999999999]);

translate([4, 4, 0]) cube([1, 1, 5.449999999999997]);

translate([5, 4, 0]) cube([1, 1, 5.139999999999991]);

translate([6, 4, 0]) cube([1, 1, 5.188264435311146]);

translate([7, 4, 0]) cube([1, 1, 5.198259026006217]);

translate([8, 4, 0]) cube([1, 1, 5.159999999999986]);

translate([9, 4, 0]) cube([1, 1, 5.058488259523824]);

translate([10, 4, 0]) cube([1, 1, 5.329999999999999]);

translate([11, 4, 0]) cube([1, 1, 4.759999999999999]);

translate([12, 4, 0]) cube([1, 1, 4.039999999999999]);

translate([13, 4, 0]) cube([1, 1, 3.7444253325706924]);

translate([14, 4, 0]) cube([1, 1, 3.7370709089191205]);

translate([15, 4, 0]) cube([1, 1, 3.749999999999999]);

translate([16, 4, 0]) cube([1, 1, 3.949999999999999]);

translate([17, 4, 0]) cube([1, 1, 4.139999999999999]);

translate([18, 4, 0]) cube([1, 1, 4.039999999999999]);

translate([19, 4, 0]) cube([1, 1, 3.9199999999999995]);

translate([0, 5, 0]) cube([1, 1, 7.9]);

translate([1, 5, 0]) cube([1, 1, 7.4]);

translate([2, 5, 0]) cube([1, 1, 7.0]);

translate([3, 5, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

translate([5, 5, 0]) cube([1, 1, 5.489999999999996]);

translate([6, 5, 0]) cube([1, 1, 5.26999999999999]);

translate([7, 5, 0]) cube([1, 1, 5.249999999999988]);

translate([8, 5, 0]) cube([1, 1, 5.279999999999994]);

color([0,1,0])
translate([9, 5, 0]) cube([1, 1, 6]);

translate([10, 5, 0]) cube([1, 1, 5.43]);

translate([11, 5, 0]) cube([1, 1, 4.819999999999999]);

translate([12, 5, 0]) cube([1, 1, 4.459999999999999]);

translate([13, 5, 0]) cube([1, 1, 4.099999999999998]);

translate([14, 5, 0]) cube([1, 1, 4.499999999999998]);

translate([15, 5, 0]) cube([1, 1, 4.679999999999998]);

translate([16, 5, 0]) cube([1, 1, 4.719999999999997]);

translate([17, 5, 0]) cube([1, 1, 4.7799999999999985]);

translate([18, 5, 0]) cube([1, 1, 4.589999999999998]);

translate([19, 5, 0]) cube([1, 1, 4.539999999999999]);

translate([0, 6, 0]) cube([1, 1, 7.9]);

translate([1, 6, 0]) cube([1, 1, 7.2]);

translate([2, 6, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 6, 0]) cube([1, 1, 6]);

translate([4, 6, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

translate([7, 6, 0]) cube([1, 1, 5.374666666666657]);

translate([8, 6, 0]) cube([1, 1, 5.359999999999994]);

color([0,1,0])
translate([9, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 6, 0]) cube([1, 1, 6]);

translate([11, 6, 0]) cube([1, 1, 5.02]);

translate([12, 6, 0]) cube([1, 1, 4.879999999999998]);

translate([13, 6, 0]) cube([1, 1, 4.729999999999997]);

translate([14, 6, 0]) cube([1, 1, 5.189999999999998]);

translate([15, 6, 0]) cube([1, 1, 5.499999999999998]);

translate([16, 6, 0]) cube([1, 1, 5.389999999999998]);

translate([17, 6, 0]) cube([1, 1, 5.2499999999999964]);

translate([18, 6, 0]) cube([1, 1, 4.969999999999999]);

translate([19, 6, 0]) cube([1, 1, 5.21]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.4]);

translate([2, 7, 0]) cube([1, 1, 6.9]);

translate([3, 7, 0]) cube([1, 1, 7.1]);

translate([4, 7, 0]) cube([1, 1, 7.2]);

translate([5, 7, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

translate([11, 7, 0]) cube([1, 1, 5.01]);

translate([12, 7, 0]) cube([1, 1, 4.9399999999999995]);

translate([13, 7, 0]) cube([1, 1, 4.939999999999997]);

color([0,1,0])
translate([14, 7, 0]) cube([1, 1, 6]);

translate([15, 7, 0]) cube([1, 1, 5.194919415214]);

translate([16, 7, 0]) cube([1, 1, 5.225805895645242]);

color([0,1,0])
translate([17, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 8.1]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 7.4]);

translate([3, 8, 0]) cube([1, 1, 7.6]);

translate([4, 8, 0]) cube([1, 1, 7.5]);

translate([5, 8, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([6, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

translate([11, 8, 0]) cube([1, 1, 5.31]);

translate([12, 8, 0]) cube([1, 1, 5.21]);

translate([13, 8, 0]) cube([1, 1, 5.169999999999998]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

translate([15, 8, 0]) cube([1, 1, 5.211821598508227]);

translate([16, 8, 0]) cube([1, 1, 5.228818108705246]);

translate([17, 8, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([18, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 8.1]);

translate([1, 9, 0]) cube([1, 1, 7.8]);

translate([2, 9, 0]) cube([1, 1, 7.6]);

translate([3, 9, 0]) cube([1, 1, 7.4]);

translate([4, 9, 0]) cube([1, 1, 7.1]);

translate([5, 9, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([6, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 9, 0]) cube([1, 1, 6]);

translate([8, 9, 0]) cube([1, 1, 6.519999999999998]);

translate([9, 9, 0]) cube([1, 1, 6.539999999999999]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 6.9]);

translate([18, 9, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.7]);

translate([1, 10, 0]) cube([1, 1, 7.3]);

translate([2, 10, 0]) cube([1, 1, 7.2]);

translate([3, 10, 0]) cube([1, 1, 6.8]);

translate([4, 10, 0]) cube([1, 1, 6.51]);

translate([5, 10, 0]) cube([1, 1, 6.619999999999999]);

translate([6, 10, 0]) cube([1, 1, 6.819999999999999]);

color([0,1,0])
translate([7, 10, 0]) cube([1, 1, 6]);

translate([8, 10, 0]) cube([1, 1, 6.522373313492062]);

translate([9, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 6.6]);

translate([18, 10, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 6.9]);

translate([1, 11, 0]) cube([1, 1, 6.7]);

translate([2, 11, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 11, 0]) cube([1, 1, 6]);

translate([8, 11, 0]) cube([1, 1, 6.72]);

translate([9, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

translate([12, 11, 0]) cube([1, 1, 5.401586048551891]);

translate([13, 11, 0]) cube([1, 1, 5.462138041775578]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([1, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 12, 0]) cube([1, 1, 6]);

translate([4, 12, 0]) cube([1, 1, 5.4399999999999995]);

translate([5, 12, 0]) cube([1, 1, 5.489999999999998]);

color([0,1,0])
translate([6, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 12, 0]) cube([1, 1, 6]);

translate([8, 12, 0]) cube([1, 1, 6.8]);

translate([9, 12, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

translate([12, 12, 0]) cube([1, 1, 5.401588753394401]);

translate([13, 12, 0]) cube([1, 1, 5.411840629561661]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 7.1]);

translate([1, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 13, 0]) cube([1, 1, 6]);

translate([3, 13, 0]) cube([1, 1, 5.4]);

translate([4, 13, 0]) cube([1, 1, 5.396704224432849]);

color([0,1,0])
translate([5, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

translate([8, 13, 0]) cube([1, 1, 6.6]);

translate([9, 13, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

translate([12, 13, 0]) cube([1, 1, 5.4417324678049805]);

translate([13, 13, 0]) cube([1, 1, 5.399799999044633]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

translate([19, 13, 0]) cube([1, 1, 5.3]);

translate([0, 14, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

translate([2, 14, 0]) cube([1, 1, 5.4]);

translate([3, 14, 0]) cube([1, 1, 5.402541257732054]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

translate([8, 14, 0]) cube([1, 1, 6.7]);

translate([9, 14, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

translate([12, 14, 0]) cube([1, 1, 5.399799999999994]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

translate([19, 14, 0]) cube([1, 1, 5.0]);

translate([0, 15, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 15, 0]) cube([1, 1, 6]);

translate([7, 15, 0]) cube([1, 1, 6.8]);

translate([8, 15, 0]) cube([1, 1, 7.1]);

translate([9, 15, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 15, 0]) cube([1, 1, 6]);

translate([12, 15, 0]) cube([1, 1, 5.360809634637615]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

translate([17, 15, 0]) cube([1, 1, 5.4]);

translate([18, 15, 0]) cube([1, 1, 5.1]);

translate([19, 15, 0]) cube([1, 1, 4.766168909680712]);

color([0,1,0])
translate([0, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 16, 0]) cube([1, 1, 6]);

translate([7, 16, 0]) cube([1, 1, 7.0]);

translate([8, 16, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([9, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 16, 0]) cube([1, 1, 6]);

translate([12, 16, 0]) cube([1, 1, 5.360410692310606]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

translate([16, 16, 0]) cube([1, 1, 5.400836453703704]);

translate([17, 16, 0]) cube([1, 1, 5.4]);

translate([18, 16, 0]) cube([1, 1, 5.2]);

translate([19, 16, 0]) cube([1, 1, 4.767103787837596]);

color([0,1,0])
translate([0, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

translate([6, 17, 0]) cube([1, 1, 6.7]);

translate([7, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

translate([16, 18, 0]) cube([1, 1, 5.4]);

translate([17, 18, 0]) cube([1, 1, 5.30023254885563]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 5.4]);

translate([1, 19, 0]) cube([1, 1, 5.3]);

translate([2, 19, 0]) cube([1, 1, 5.3]);

translate([3, 19, 0]) cube([1, 1, 5.1]);

translate([4, 19, 0]) cube([1, 1, 5.0]);

translate([5, 19, 0]) cube([1, 1, 5.3]);

translate([6, 19, 0]) cube([1, 1, 5.3]);

translate([7, 19, 0]) cube([1, 1, 5.005694742228559]);

translate([8, 19, 0]) cube([1, 1, 5.018713803051987]);

translate([9, 19, 0]) cube([1, 1, 5.41]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

translate([14, 19, 0]) cube([1, 1, 5.272524316801526]);

translate([15, 19, 0]) cube([1, 1, 5.3]);

translate([16, 19, 0]) cube([1, 1, 5.300232553736772]);

translate([17, 19, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);
