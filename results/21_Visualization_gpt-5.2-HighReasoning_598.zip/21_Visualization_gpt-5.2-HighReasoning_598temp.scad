
hull() {
    translate([10.05, 10.0, 94.9977]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.950000000000001, 10.0, 94.95629999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.05, 10.0, 94.94704999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.950000000000001, 10.0, 94.82195]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.05, 10.0, 94.80355]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.950000000000001, 10.0, 94.59745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.05, 10.0, 94.57]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.95, 10.0, 94.28200000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.05, 10.0, 94.24560000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.95, 10.0, 93.8784]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.05, 10.0, 93.83335]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.950000000000001, 10.0, 93.38964999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.05, 10.0, 93.33624999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.95, 10.0, 92.81875000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.05, 10.0, 92.75725000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.95, 10.0, 92.16775000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.05, 10.0, 92.09855]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.950000000000003, 10.0, 91.44245000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.05, 10.0, 91.36605000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.95, 10.0, 90.64695]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.05, 10.0, 90.56375]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.950000000000003, 10.0, 89.78525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.05, 10.0, 89.69575]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.95, 10.0, 88.86325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.05, 10.0, 88.768]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.95, 10.0, 87.88600000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.05, 10.0, 87.78565]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.950000000000003, 10.0, 86.86135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.05, 10.0, 86.7565]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.95, 10.0, 85.7935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.05, 10.0, 85.68475]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.950000000000003, 10.0, 84.69025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.050000000000004, 10.0, 84.57835000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.950000000000003, 10.0, 83.55865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.05, 10.0, 83.44425]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.95, 10.0, 82.40474999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.05, 10.0, 82.28849999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.950000000000003, 10.0, 81.2355]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.05, 10.0, 81.11815000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.95, 10.0, 80.05885]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.05, 10.0, 79.94115]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.950000000000003, 10.0, 78.88184999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.050000000000004, 10.0, 78.7645]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.950000000000003, 10.0, 77.71150000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.05, 10.0, 77.59525000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.95, 10.0, 76.55575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.05, 10.0, 76.44135]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.95, 10.0, 75.42164999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.050000000000004, 10.0, 75.30975]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.95, 10.0, 74.31525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.05, 10.0, 74.2065]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.949999999999996, 10.0, 73.2435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.05, 10.0, 73.13865]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.95, 10.0, 72.21435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.050000000000004, 10.0, 72.11399999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.95, 10.0, 71.232]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.050000000000004, 10.0, 71.13675]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.95, 10.0, 70.30425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.050000000000004, 10.0, 70.21475]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.95, 10.0, 69.43625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.05, 10.0, 69.35305000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.949999999999996, 10.0, 68.63395]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.05, 10.0, 68.55754999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.95, 10.0, 67.90145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.050000000000004, 10.0, 67.83225]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.95, 10.0, 67.24275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.050000000000004, 10.0, 67.18124999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.95, 10.0, 66.66375000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.050000000000004, 10.0, 66.61035000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.95, 10.0, 66.16665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.05, 10.0, 66.1216]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.949999999999996, 10.0, 65.75439999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.05, 10.0, 65.71799999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.95, 10.0, 65.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.050000000000004, 10.0, 65.40255]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.95, 10.0, 65.19645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.050000000000004, 10.0, 65.17805000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.95, 10.0, 65.05295000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.050000000000004, 10.0, 65.04370000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.95, 10.0, 65.0023]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0835, 10.0, 65.00585]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.5865, 10.0, 65.11115000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.7519, 10.0, 65.1344]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.2261, 10.0, 65.4476]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.38665, 10.0, 65.49365]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.802350000000004, 10.0, 66.00935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.95490000000001, 10.0, 66.0773]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.2851, 10.0, 66.7847]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.426700000000004, 10.0, 66.8732]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.645300000000006, 10.0, 67.75880000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.773250000000004, 10.0, 67.8661]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.85775, 10.0, 68.9119]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.969500000000004, 10.0, 69.036]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.8965, 10.0, 70.224]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.989900000000006, 10.0, 70.36250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.7441, 10.0, 71.6675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.81735, 10.0, 71.8176]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.38164999999999, 10.0, 73.2144]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.433249999999994, 10.0, 73.3732]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.79775, 10.0, 74.8348]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.826750000000004, 10.0, 74.99925]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.98425, 10.0, 76.49775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.990050000000004, 10.0, 76.66465]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.93695, 10.0, 78.17035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.9195, 10.0, 78.33645]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.6585, 10.0, 79.82055]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.6181, 10.0, 79.9826]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.1519, 10.0, 81.4154]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.089299999999994, 10.0, 81.57025]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.428700000000006, 10.0, 82.92475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.345200000000006, 10.0, 83.0694]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.50280000000001, 10.0, 84.3186]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.400000000000006, 10.0, 84.45020000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.392, 10.0, 85.56980000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.27185, 10.0, 85.68580000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.117149999999995, 10.0, 86.6542]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.982049999999994, 10.0, 86.75234999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.70495, 10.0, 87.55064999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.5575, 10.0, 87.62904999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.1805, 10.0, 88.24194999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.02355, 10.0, 88.2991]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.575450000000004, 10.0, 88.7149]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.4121, 10.0, 88.74965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.919900000000005, 10.0, 88.95935000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.7533, 10.0, 88.971]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.2467, 10.0, 88.971]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.0801, 10.0, 88.95935000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.587900000000005, 10.0, 88.74965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.42455, 10.0, 88.7149]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.97645000000001, 10.0, 88.2991]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.819500000000005, 10.0, 88.24194999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.4425, 10.0, 87.62904999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.29505, 10.0, 87.55064999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.017950000000006, 10.0, 86.75234999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.882850000000005, 10.0, 86.6542]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.72815000000001, 10.0, 85.68580000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.608000000000004, 10.0, 85.56980000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.599999999999994, 10.0, 84.45020000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.49719999999999, 10.0, 84.3186]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.654799999999994, 10.0, 83.0694]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.5713, 10.0, 82.92475]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.910700000000006, 10.0, 81.57025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.8481, 10.0, 81.4154]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.3819, 10.0, 79.9826]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.3415, 10.0, 79.82055]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.08050000000001, 10.0, 78.33645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.063050000000004, 10.0, 78.17035]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.009949999999996, 10.0, 76.66465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.01575, 10.0, 76.49775]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.17325, 10.0, 74.99925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.20225000000001, 10.0, 74.8348]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.566750000000006, 10.0, 73.3732]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.61835000000001, 10.0, 73.2144]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.18265, 10.0, 71.8176]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.2559, 10.0, 71.6675]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.010099999999994, 10.0, 70.36250000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.1035, 10.0, 70.224]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.0305, 10.0, 69.036]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.142250000000004, 10.0, 68.9119]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.22675, 10.0, 67.8661]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.3547, 10.0, 67.75880000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.573299999999996, 10.0, 66.8732]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.7149, 10.0, 66.7847]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.045100000000005, 10.0, 66.0773]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.19765, 10.0, 66.00935]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.613350000000004, 10.0, 65.49365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.773900000000005, 10.0, 65.4476]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.2481, 10.0, 65.1344]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.4135, 10.0, 65.11115000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.9165, 10.0, 65.00585]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.08585, 10.0021, 64.99365]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.63115, 10.039900000000001, 64.87935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.8027, 10.048350000000001, 64.86665]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.345299999999995, 10.162650000000001, 64.75235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.51625, 10.1795, 64.73965]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.05075000000001, 10.3685, 64.62535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.220600000000005, 10.393699999999999, 64.61265]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.7434, 10.6583, 64.49835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.9118, 10.6918, 64.48565]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.420199999999994, 11.0302, 64.37135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.5868, 11.071900000000001, 64.35865]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0772, 11.4841, 64.24435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.24155, 11.533949999999999, 64.23165]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.70945, 12.01905, 64.11735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.87115, 12.0769, 64.10465]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.31385, 12.6331, 63.99035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.472500000000004, 12.6988, 63.97765]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.8855, 13.325199999999999, 63.86335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.04075, 13.39865, 63.85065]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.42225, 14.094349999999999, 63.73635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.57375, 14.1753, 63.7237]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.91925, 14.9367, 63.6103]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.06655, 15.025, 63.59765]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.37245, 15.853, 63.48335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.5152, 15.94845, 63.47065]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.7788, 16.83855, 63.35635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.91675000000001, 16.94085, 63.343650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.13624999999999, 17.89215, 63.229350000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.26905, 18.0011, 63.21665]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.43995, 19.0109, 63.10235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.5672, 19.1262, 63.08965]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.6868, 20.191800000000004, 62.97535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.8082, 20.313200000000002, 62.962650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.8738, 21.4328, 62.84835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.98910000000001, 21.56005, 62.83565]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.9989, 22.73095, 62.72135000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.10785000000001, 22.86375, 62.708650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.05914999999999, 24.08325, 62.59435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.16145, 24.221200000000003, 62.58165]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.05154999999999, 25.4848, 62.46735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.147, 25.62755, 62.45465]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.97500000000001, 26.93345, 62.34035000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.0633, 27.080750000000002, 62.327650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.8247, 28.42625, 62.21335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.90565000000001, 28.57775, 62.20065]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.60135, 29.959250000000004, 62.08635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.6748, 30.114500000000003, 62.07365]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.30120000000001, 31.527500000000003, 61.95935000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.3669, 31.686150000000005, 61.946650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.92309999999999, 33.12885000000001, 61.83235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.98094999999999, 33.29055, 61.81965]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.46605, 34.75845, 61.70535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.51589999999999, 34.92280000000001, 61.69265]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.9281, 36.4132, 61.57835000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.96979999999999, 36.579800000000006, 61.565650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.3082, 38.0882, 61.45135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.3417, 38.2566, 61.43865]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.6063, 39.7794, 61.32435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.6315, 39.94925, 61.31165]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.82050000000001, 41.48375, 61.19735000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.83735000000001, 41.654700000000005, 61.184650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.95165, 43.197300000000006, 61.07035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.9601, 43.36885, 61.0577]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.9979, 44.91415, 60.9443]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.9979, 45.08585, 60.931650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.9601, 46.63115, 60.817350000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.95165, 46.802699999999994, 60.80465]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.83735000000001, 48.345299999999995, 60.69035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.82050000000001, 48.51625, 60.67765]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.6315, 50.05075000000001, 60.56335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.6063, 50.220600000000005, 60.550650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.3417, 51.7434, 60.436350000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.3082, 51.9118, 60.42365]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.96979999999999, 53.420199999999994, 60.30935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.9281, 53.5868, 60.29665]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.51589999999999, 55.0772, 60.18235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.46605, 55.24155, 60.169650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.98094999999999, 56.70945, 60.055350000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.92309999999999, 56.87115, 60.04265]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.3669, 58.31385, 59.92835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.30120000000001, 58.472500000000004, 59.91565]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.6748, 59.8855, 59.80135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.60135, 60.040749999999996, 59.788650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.90565000000001, 61.42225, 59.674350000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.8247, 61.573750000000004, 59.66165]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.0633, 62.919250000000005, 59.54735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.97500000000001, 63.06655, 59.53465]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.147, 64.37245, 59.42035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.05154999999999, 64.5152, 59.407650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.16145, 65.7788, 59.293350000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.05914999999999, 65.91675000000001, 59.28065]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.10785000000001, 67.13624999999999, 59.16635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.9989, 67.26905, 59.15365]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.98910000000001, 68.43995, 59.03935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.8738, 68.5672, 59.026650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.8082, 69.68679999999999, 58.91235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.6868, 69.8082, 58.89965]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.5672, 70.8738, 58.78535000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.43995, 70.98910000000001, 58.772650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.26905, 71.9989, 58.65835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.13624999999999, 72.10785000000001, 58.64565]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.91675000000001, 73.05914999999999, 58.53135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.7788, 73.16145, 58.51865]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.5152, 74.05154999999999, 58.40435000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.37245, 74.147, 58.391650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.06655, 74.97500000000001, 58.27735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.91925, 75.0633, 58.2647]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.57375, 75.8247, 58.1513]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.42225, 75.90565000000001, 58.13865]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.04075, 76.60135, 58.02435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.8855, 76.6748, 58.01165]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.472500000000004, 77.30120000000001, 57.89735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.31385, 77.3669, 57.88465]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.87115, 77.92309999999999, 57.77035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.70945, 77.98094999999999, 57.75765]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.24155, 78.46605, 57.64335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0772, 78.51589999999999, 57.63065]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.5868, 78.9281, 57.51635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.420199999999994, 78.96979999999999, 57.50365]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.9118, 79.3082, 57.38935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.7434, 79.3417, 57.37665]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.220600000000005, 79.6063, 57.26235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.05075000000001, 79.6315, 57.24965]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.51625, 79.82050000000001, 57.13535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.345299999999995, 79.83735000000001, 57.12265]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.8027, 79.95165, 57.00835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.63115, 79.9601, 56.99565]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.08585, 79.9979, 56.88135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.91415, 79.9979, 56.86865]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.36885, 79.9601, 56.75435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.197300000000006, 79.95165, 56.74165]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.654700000000005, 79.83735000000001, 56.62735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.48375, 79.82050000000001, 56.61465]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.94925, 79.6315, 56.50035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.7794, 79.6063, 56.48765]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.2566, 79.3417, 56.37335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.0882, 79.3082, 56.36065]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.579800000000006, 78.96979999999999, 56.24635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.4132, 78.9281, 56.23365]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.9228, 78.51589999999999, 56.11935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.75845, 78.46605, 56.10665]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.29055, 77.98094999999999, 55.99235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.12885, 77.92309999999999, 55.97965]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.68615, 77.3669, 55.86535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.527499999999996, 77.30120000000001, 55.85265]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.1145, 76.6748, 55.73835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.959250000000004, 76.60135, 55.72565]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.57775, 75.90565000000001, 55.61135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.42625, 75.8247, 55.5987]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.08075, 75.0633, 55.4853]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.93345, 74.97500000000001, 55.47265]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.62755, 74.147, 55.35835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.4848, 74.05154999999999, 55.34565]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.221200000000003, 73.16145, 55.23135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.08325, 73.05914999999999, 55.218650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.863750000000003, 72.10785000000001, 55.104350000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.73095, 71.9989, 55.09165]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.56005, 70.98910000000001, 54.97735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.4328, 70.8738, 54.96465]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.313200000000002, 69.8082, 54.85035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.191800000000004, 69.68679999999999, 54.837650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.1262, 68.5672, 54.72335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.0109, 68.43995, 54.71065]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.0011, 67.26905, 54.59635000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.89215, 67.13624999999999, 54.583650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.94085, 65.91675000000001, 54.46935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.83855, 65.7788, 54.45665]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.94845, 64.5152, 54.34235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.853, 64.37245, 54.32965]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.025000000000002, 63.06655, 54.21535000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.936700000000002, 62.919250000000005, 54.202650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.1753, 61.573750000000004, 54.08835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.09435, 61.42225, 54.07565]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.39865, 60.040749999999996, 53.96135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.325200000000002, 59.8855, 53.94865]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.698800000000002, 58.472500000000004, 53.83435000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.633100000000002, 58.31385, 53.821650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.076900000000002, 56.87115, 53.70735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.01905, 56.70945, 53.69465]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.53395, 55.24155, 53.58035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.4841, 55.0772, 53.56765]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.0719, 53.5868, 53.45335000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.0302, 53.420199999999994, 53.440650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.6918, 51.9118, 53.32635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.6583, 51.7434, 53.31365]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.393699999999999, 50.220600000000005, 53.19935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.3685, 50.05075000000001, 53.18665]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.1795, 48.51625, 53.07235000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.162650000000001, 48.345299999999995, 53.059650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.048350000000001, 46.802699999999994, 52.94535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.039900000000001, 46.63115, 52.9327]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0021, 45.08585, 52.8193]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0021, 44.91415, 52.806650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.039900000000001, 43.36885, 52.692350000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.048350000000001, 43.197300000000006, 52.67965]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.162650000000001, 41.654700000000005, 52.56535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.1795, 41.48375, 52.55265]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.3685, 39.94925, 52.43835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.393699999999999, 39.7794, 52.425650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.6583, 38.2566, 52.311350000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.6918, 38.0882, 52.29865]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.0302, 36.579800000000006, 52.18435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.0719, 36.4132, 52.17165]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.4841, 34.92280000000001, 52.05735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.53395, 34.75845, 52.044650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.01905, 33.29055, 51.930350000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.076900000000002, 33.12885000000001, 51.91765]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.633100000000002, 31.686150000000005, 51.80335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.698800000000002, 31.527500000000003, 51.79065]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.325200000000002, 30.114500000000003, 51.67635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.39865, 29.959250000000004, 51.663650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.09435, 28.57775, 51.549350000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.1753, 28.42625, 51.53665]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.936700000000002, 27.080750000000002, 51.42235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.025000000000002, 26.93345, 51.40965]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.853, 25.62755, 51.29535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.94845, 25.4848, 51.282650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.83855, 24.221200000000003, 51.168350000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.94085, 24.08325, 51.15565]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.89215, 22.86375, 51.04135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.0011, 22.73095, 51.02865]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.0109, 21.56005, 50.91435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.1262, 21.4328, 50.901650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.191800000000004, 20.313200000000002, 50.78735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.313200000000002, 20.191800000000004, 50.77465]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.4328, 19.1262, 50.66035000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.56005, 19.0109, 50.647650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.73095, 18.0011, 50.53335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.863750000000003, 17.89215, 50.52065]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.08325, 16.94085, 50.40635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.221200000000003, 16.83855, 50.39365]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.4848, 15.94845, 50.27935000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.62755, 15.853, 50.266650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.93345, 15.025, 50.15235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.08075, 14.9367, 50.1397]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.42625, 14.1753, 50.0263]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.57775, 14.094349999999999, 50.01365]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.959250000000004, 13.39865, 49.89935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.1145, 13.325199999999999, 49.88665]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.527499999999996, 12.6988, 49.77235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.68615, 12.6331, 49.75965]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.12885, 12.0769, 49.64535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.29055, 12.01905, 49.63265]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.75845, 11.533949999999999, 49.51835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.9228, 11.4841, 49.50565]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.4132, 11.071900000000001, 49.39135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.579800000000006, 11.0302, 49.37865]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.0882, 10.6918, 49.26435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.2566, 10.6583, 49.25165]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.7794, 10.393699999999999, 49.13735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.94925, 10.3685, 49.12465]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.48375, 10.1795, 49.01035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.654700000000005, 10.162650000000001, 48.99765]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.197300000000006, 10.048350000000001, 48.88335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.36885, 10.039900000000001, 48.87065]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.91415, 10.0021, 48.75635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.08585, 10.0021, 48.74365]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.63115, 10.039900000000001, 48.62935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.8027, 10.048350000000001, 48.61665]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.345299999999995, 10.162650000000001, 48.50235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.51625, 10.1795, 48.48965]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.05075000000001, 10.3685, 48.37535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.220600000000005, 10.393699999999999, 48.36265]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.7434, 10.6583, 48.24835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.9118, 10.6918, 48.23565]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.420199999999994, 11.0302, 48.12135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.5868, 11.071900000000001, 48.10865]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0772, 11.4841, 47.99435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.24155, 11.533949999999999, 47.98165]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.70945, 12.01905, 47.86735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.87115, 12.0769, 47.85465]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.31385, 12.6331, 47.74035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.472500000000004, 12.6988, 47.72765]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.8855, 13.325199999999999, 47.61335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.04075, 13.39865, 47.60065]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.42225, 14.094349999999999, 47.48635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.57375, 14.1753, 47.4737]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.91925, 14.9367, 47.3603]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.06655, 15.025, 47.34765]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.37245, 15.853, 47.23335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.5152, 15.94845, 47.22065]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.7788, 16.83855, 47.10635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.91675000000001, 16.94085, 47.093650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.13624999999999, 17.89215, 46.979350000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.26905, 18.0011, 46.96665]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.43995, 19.0109, 46.85235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.5672, 19.1262, 46.83965]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.6868, 20.191800000000004, 46.72535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.8082, 20.313200000000002, 46.712650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.8738, 21.4328, 46.59835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.98910000000001, 21.56005, 46.58565]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.9989, 22.73095, 46.47135000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.10785000000001, 22.86375, 46.458650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.05914999999999, 24.08325, 46.34435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.16145, 24.221200000000003, 46.33165]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.05154999999999, 25.4848, 46.21735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.147, 25.62755, 46.20465]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.97500000000001, 26.93345, 46.09035000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.0633, 27.080750000000002, 46.077650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.8247, 28.42625, 45.96335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.90565000000001, 28.57775, 45.95065]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.60135, 29.959250000000004, 45.83635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.6748, 30.114500000000003, 45.82365]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.30120000000001, 31.527500000000003, 45.70935000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.3669, 31.686150000000005, 45.696650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.92309999999999, 33.12885000000001, 45.58235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.98094999999999, 33.29055, 45.56965]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.46605, 34.75845, 45.45535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.51589999999999, 34.92280000000001, 45.44265]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.9281, 36.4132, 45.32835000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.96979999999999, 36.579800000000006, 45.315650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.3082, 38.0882, 45.20135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.3417, 38.2566, 45.18865]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.6063, 39.7794, 45.07435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.6315, 39.94925, 45.06165]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.82050000000001, 41.48375, 44.94735000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.83735000000001, 41.654700000000005, 44.934650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.95165, 43.197300000000006, 44.82035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.9601, 43.36885, 44.8077]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.9979, 44.91415, 44.6943]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.9979, 45.08585, 44.68165]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.9601, 46.63115, 44.56735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.95165, 46.802699999999994, 44.55465]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.83735000000001, 48.345299999999995, 44.44035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.82050000000001, 48.51625, 44.42765]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.6315, 50.05075000000001, 44.31335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.6063, 50.220600000000005, 44.30065]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.3417, 51.7434, 44.18635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.3082, 51.9118, 44.17365]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.96979999999999, 53.420199999999994, 44.05935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.9281, 53.5868, 44.04665]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.51589999999999, 55.0772, 43.93235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.46605, 55.24155, 43.91965]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.98094999999999, 56.70945, 43.80535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.92309999999999, 56.87115, 43.79265]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.3669, 58.31385, 43.67835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.30120000000001, 58.472500000000004, 43.66565]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.6748, 59.8855, 43.55135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.60135, 60.040749999999996, 43.53865]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.90565000000001, 61.42225, 43.42435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.8247, 61.573750000000004, 43.41165]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.0633, 62.919250000000005, 43.29735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.97500000000001, 63.06655, 43.28465]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.147, 64.37245, 43.17035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.05154999999999, 64.5152, 43.15765]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.16145, 65.7788, 43.04335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.05914999999999, 65.91675000000001, 43.03065]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.10785000000001, 67.13624999999999, 42.91635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.9989, 67.26905, 42.90365]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.98910000000001, 68.43995, 42.78935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.8738, 68.5672, 42.77665]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.8082, 69.68679999999999, 42.662349999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.6868, 69.8082, 42.64965]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.5672, 70.8738, 42.53535000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.43995, 70.98910000000001, 42.522650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.26905, 71.9989, 42.40835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.13624999999999, 72.10785000000001, 42.395649999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.91675000000001, 73.05914999999999, 42.281349999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.7788, 73.16145, 42.26865]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.5152, 74.05154999999999, 42.15435000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.37245, 74.147, 42.141650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.06655, 74.97500000000001, 42.02735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.91925, 75.0633, 42.0147]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.57375, 75.8247, 41.9013]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.42225, 75.90565000000001, 41.88865]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.04075, 76.60135, 41.77435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.8855, 76.6748, 41.76165]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.472500000000004, 77.30120000000001, 41.64735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.31385, 77.3669, 41.63465]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.87115, 77.92309999999999, 41.52035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.70945, 77.98094999999999, 41.50765]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.24155, 78.46605, 41.39335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0772, 78.51589999999999, 41.38065]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.5868, 78.9281, 41.26635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.420199999999994, 78.96979999999999, 41.25365]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.9118, 79.3082, 41.13935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.7434, 79.3417, 41.12665]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.220600000000005, 79.6063, 41.01235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.05075000000001, 79.6315, 40.99965]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.51625, 79.82050000000001, 40.88535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.345299999999995, 79.83735000000001, 40.87265]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.8027, 79.95165, 40.75835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.63115, 79.9601, 40.74565]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.08585, 79.9979, 40.63135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.91415, 79.9979, 40.61865]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.36885, 79.9601, 40.50435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.197300000000006, 79.95165, 40.49165]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.654700000000005, 79.83735000000001, 40.37735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.48375, 79.82050000000001, 40.36465]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.94925, 79.6315, 40.25035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.7794, 79.6063, 40.23765]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.2566, 79.3417, 40.12335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.0882, 79.3082, 40.11065]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.579800000000006, 78.96979999999999, 39.99635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.4132, 78.9281, 39.98365]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.9228, 78.51589999999999, 39.86935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.75845, 78.46605, 39.85665]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.29055, 77.98094999999999, 39.74235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.12885, 77.92309999999999, 39.72965]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.68615, 77.3669, 39.61535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.527499999999996, 77.30120000000001, 39.60265]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.1145, 76.6748, 39.48835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.959250000000004, 76.60135, 39.47565]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.57775, 75.90565000000001, 39.36135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.42625, 75.8247, 39.3487]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.08075, 75.0633, 39.2353]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.93345, 74.97500000000001, 39.22265]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.62755, 74.147, 39.10835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.4848, 74.05154999999999, 39.09565]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.221200000000003, 73.16145, 38.98135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.08325, 73.05914999999999, 38.968650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.863750000000003, 72.10785000000001, 38.854350000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.73095, 71.9989, 38.84165]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.56005, 70.98910000000001, 38.72735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.4328, 70.8738, 38.71465]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.313200000000002, 69.8082, 38.60035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.191800000000004, 69.68679999999999, 38.587650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.1262, 68.5672, 38.47335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.0109, 68.43995, 38.46065]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.0011, 67.26905, 38.34635000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.89215, 67.13624999999999, 38.333650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.94085, 65.91675000000001, 38.21935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.83855, 65.7788, 38.20665]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.94845, 64.5152, 38.09235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.853, 64.37245, 38.07965]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.025000000000002, 63.06655, 37.96535000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.936700000000002, 62.919250000000005, 37.952650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.1753, 61.573750000000004, 37.83835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.09435, 61.42225, 37.82565]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.39865, 60.040749999999996, 37.71135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.325200000000002, 59.8855, 37.69865]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.698800000000002, 58.472500000000004, 37.58435000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.633100000000002, 58.31385, 37.571650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.076900000000002, 56.87115, 37.45735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.01905, 56.70945, 37.44465]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.53395, 55.24155, 37.33035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.4841, 55.0772, 37.31765]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.0719, 53.5868, 37.20335000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.0302, 53.420199999999994, 37.190650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.6918, 51.9118, 37.07635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.6583, 51.7434, 37.06365]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.393699999999999, 50.220600000000005, 36.94935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.3685, 50.05075000000001, 36.93665]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.1795, 48.51625, 36.82235000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.162650000000001, 48.345299999999995, 36.809650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.048350000000001, 46.802699999999994, 36.69535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.039900000000001, 46.63115, 36.6827]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0021, 45.08585, 36.5693]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0021, 44.91415, 36.55665]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.039900000000001, 43.36885, 36.44235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.048350000000001, 43.197300000000006, 36.42965]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.162650000000001, 41.654700000000005, 36.31535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.1795, 41.48375, 36.30265]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.3685, 39.94925, 36.18835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.393699999999999, 39.7794, 36.17565]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.6583, 38.2566, 36.06135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.6918, 38.0882, 36.04865]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.0302, 36.579800000000006, 35.93435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.0719, 36.4132, 35.92165]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.4841, 34.92280000000001, 35.80735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.53395, 34.75845, 35.79465]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.01905, 33.29055, 35.68035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.076900000000002, 33.12885000000001, 35.66765]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.633100000000002, 31.686150000000005, 35.553349999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.698800000000002, 31.527500000000003, 35.54065]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.325200000000002, 30.114500000000003, 35.426350000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.39865, 29.959250000000004, 35.413650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.09435, 28.57775, 35.29935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.1753, 28.42625, 35.28665]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.936700000000002, 27.080750000000002, 35.172349999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.025000000000002, 26.93345, 35.15965]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.853, 25.62755, 35.045350000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.94845, 25.4848, 35.032650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.83855, 24.221200000000003, 34.91835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.94085, 24.08325, 34.90565]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.89215, 22.86375, 34.791349999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.0011, 22.73095, 34.77865]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.0109, 21.56005, 34.664350000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.1262, 21.4328, 34.651650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.191800000000004, 20.313200000000002, 34.537349999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.313200000000002, 20.191800000000004, 34.52465]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.4328, 19.1262, 34.41035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.56005, 19.0109, 34.397650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.73095, 18.0011, 34.283350000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.863750000000003, 17.89215, 34.27065]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.08325, 16.94085, 34.156349999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.221200000000003, 16.83855, 34.14365]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.4848, 15.94845, 34.02935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.62755, 15.853, 34.016650000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.93345, 15.025, 33.902350000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.08075, 14.9367, 33.889700000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.42625, 14.1753, 33.776300000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.57775, 14.094349999999999, 33.763650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.959250000000004, 13.39865, 33.64935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.1145, 13.325199999999999, 33.63665]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.527499999999996, 12.6988, 33.52235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.68615, 12.6331, 33.50965]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.12885, 12.0769, 33.39535000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.29055, 12.01905, 33.382650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.75845, 11.533949999999999, 33.26835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.9228, 11.4841, 33.25565]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.4132, 11.071900000000001, 33.14135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.579800000000006, 11.0302, 33.12865]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.0882, 10.6918, 33.01435000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.2566, 10.6583, 33.001650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.7794, 10.393699999999999, 32.88735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.94925, 10.3685, 32.87465]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.48375, 10.1795, 32.76035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.654700000000005, 10.162650000000001, 32.74765]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.197300000000006, 10.048350000000001, 32.63335000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.36885, 10.039900000000001, 32.620650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.91415, 10.0021, 32.50635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.08585, 10.0021, 32.49365]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.63115, 10.039900000000001, 32.37935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.8027, 10.048350000000001, 32.36665]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.345299999999995, 10.162650000000001, 32.25235000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.51625, 10.1795, 32.239650000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.05075000000001, 10.3685, 32.12535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.220600000000005, 10.393699999999999, 32.11265]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.7434, 10.6583, 31.998350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.9118, 10.6918, 31.98565]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.420199999999994, 11.0302, 31.87135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.5868, 11.071900000000001, 31.85865]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0772, 11.4841, 31.74435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.24155, 11.533949999999999, 31.731650000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.70945, 12.01905, 31.617350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.87115, 12.0769, 31.60465]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.31385, 12.6331, 31.490350000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.472500000000004, 12.6988, 31.477650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.8855, 13.325199999999999, 31.36335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.04075, 13.39865, 31.35065]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.42225, 14.094349999999999, 31.23635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.57375, 14.1753, 31.2237]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.91925, 14.9367, 31.110300000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.06655, 15.025, 31.09765]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.37245, 15.853, 30.98335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.5152, 15.94845, 30.97065]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.7788, 16.83855, 30.85635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.91675000000001, 16.94085, 30.84365]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.13624999999999, 17.89215, 30.72935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.26905, 18.0011, 30.71665]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.43995, 19.0109, 30.60235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.5672, 19.1262, 30.58965]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.6868, 20.191800000000004, 30.47535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.8082, 20.313200000000002, 30.46265]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.8738, 21.4328, 30.34835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.98910000000001, 21.56005, 30.33565]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.9989, 22.73095, 30.22135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.10785000000001, 22.86375, 30.20865]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.05914999999999, 24.08325, 30.09435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.16145, 24.221200000000003, 30.08165]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.05154999999999, 25.4848, 29.96735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.147, 25.62755, 29.95465]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.97500000000001, 26.93345, 29.84035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.0633, 27.080750000000002, 29.82765]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.8247, 28.42625, 29.71335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.90565000000001, 28.57775, 29.70065]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.60135, 29.959250000000004, 29.58635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.6748, 30.114500000000003, 29.57365]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.30120000000001, 31.527500000000003, 29.45935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.3669, 31.686150000000005, 29.446649999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.92309999999999, 33.12885000000001, 29.332349999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.98094999999999, 33.29055, 29.31965]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.46605, 34.75845, 29.205350000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.51589999999999, 34.92280000000001, 29.192650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.9281, 36.4132, 29.07835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.96979999999999, 36.579800000000006, 29.065649999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.3082, 38.0882, 28.951349999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.3417, 38.2566, 28.93865]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.6063, 39.7794, 28.824350000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.6315, 39.94925, 28.811650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.82050000000001, 41.48375, 28.69735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.83735000000001, 41.654700000000005, 28.684649999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.95165, 43.197300000000006, 28.570349999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.9601, 43.36885, 28.5577]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.9979, 44.91415, 28.444300000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.9979, 45.08585, 28.43165]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.9601, 46.63115, 28.31735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.95165, 46.802699999999994, 28.304650000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.83735000000001, 48.345299999999995, 28.190350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.82050000000001, 48.51625, 28.17765]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.6315, 50.05075000000001, 28.06335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.6063, 50.220600000000005, 28.05065]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.3417, 51.7434, 27.93635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.3082, 51.9118, 27.923650000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.96979999999999, 53.420199999999994, 27.809350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.9281, 53.5868, 27.79665]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.51589999999999, 55.0772, 27.68235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.46605, 55.24155, 27.66965]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.98094999999999, 56.70945, 27.55535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.92309999999999, 56.87115, 27.542650000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.3669, 58.31385, 27.428350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.30120000000001, 58.472500000000004, 27.41565]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.6748, 59.8855, 27.301350000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.60135, 60.040749999999996, 27.288650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.90565000000001, 61.42225, 27.17435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.8247, 61.573750000000004, 27.16165]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.0633, 62.919250000000005, 27.04735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.97500000000001, 63.06655, 27.03465]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.147, 64.37245, 26.920350000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.05154999999999, 64.5152, 26.907650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.16145, 65.7788, 26.79335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.05914999999999, 65.91675000000001, 26.78065]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.10785000000001, 67.13624999999999, 26.66635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.9989, 67.26905, 26.65365]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.98910000000001, 68.43995, 26.539350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.8738, 68.5672, 26.526650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.8082, 69.68679999999999, 26.41235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.6868, 69.8082, 26.39965]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.5672, 70.8738, 26.28535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.43995, 70.98910000000001, 26.27265]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.26905, 71.9989, 26.158350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.13624999999999, 72.10785000000001, 26.145650000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.91675000000001, 73.05914999999999, 26.03135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.7788, 73.16145, 26.01865]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.5152, 74.05154999999999, 25.90435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.37245, 74.147, 25.89165]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.06655, 74.97500000000001, 25.777350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.91925, 75.0633, 25.764700000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.57375, 75.8247, 25.6513]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.42225, 75.90565000000001, 25.638650000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.04075, 76.60135, 25.524350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.8855, 76.6748, 25.51165]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.472500000000004, 77.30120000000001, 25.39735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.31385, 77.3669, 25.38465]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.87115, 77.92309999999999, 25.27035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.70945, 77.98094999999999, 25.25765]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.24155, 78.46605, 25.14335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0772, 78.51589999999999, 25.130650000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.5868, 78.9281, 25.016350000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.420199999999994, 78.96979999999999, 25.00365]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.9118, 79.3082, 24.88935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.7434, 79.3417, 24.87665]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.220600000000005, 79.6063, 24.76235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.05075000000001, 79.6315, 24.749650000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.51625, 79.82050000000001, 24.635350000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.345299999999995, 79.83735000000001, 24.62265]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.8027, 79.95165, 24.50835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.63115, 79.9601, 24.49565]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.08585, 79.9979, 24.38135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.91415, 79.9979, 24.368650000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.36885, 79.9601, 24.254350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.197300000000006, 79.95165, 24.24165]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.654700000000005, 79.83735000000001, 24.12735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.48375, 79.82050000000001, 24.11465]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.94925, 79.6315, 24.00035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.7794, 79.6063, 23.98765]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.2566, 79.3417, 23.87335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.0882, 79.3082, 23.86065]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.579800000000006, 78.96979999999999, 23.74635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.4132, 78.9281, 23.73365]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.9228, 78.51589999999999, 23.61935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.75845, 78.46605, 23.60665]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.29055, 77.98094999999999, 23.49235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.12885, 77.92309999999999, 23.47965]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.68615, 77.3669, 23.365350000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.527499999999996, 77.30120000000001, 23.352650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.1145, 76.6748, 23.23835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.959250000000004, 76.60135, 23.225649999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.57775, 75.90565000000001, 23.111349999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.42625, 75.8247, 23.0987]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.08075, 75.0633, 22.985300000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.93345, 74.97500000000001, 22.97265]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.62755, 74.147, 22.85835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.4848, 74.05154999999999, 22.84565]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.221200000000003, 73.16145, 22.73135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.08325, 73.05914999999999, 22.71865]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.863750000000003, 72.10785000000001, 22.60435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.73095, 71.9989, 22.59165]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.56005, 70.98910000000001, 22.47735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.4328, 70.8738, 22.46465]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.313200000000002, 69.8082, 22.35035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.191800000000004, 69.68679999999999, 22.33765]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.1262, 68.5672, 22.22335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.0109, 68.43995, 22.21065]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.0011, 67.26905, 22.09635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.89215, 67.13624999999999, 22.08365]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.94085, 65.91675000000001, 21.96935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.83855, 65.7788, 21.95665]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.94845, 64.5152, 21.84235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.853, 64.37245, 21.82965]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.025000000000002, 63.06655, 21.71535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.936700000000002, 62.919250000000005, 21.70265]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.1753, 61.573750000000004, 21.58835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.09435, 61.42225, 21.57565]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.39865, 60.040749999999996, 21.46135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.325200000000002, 59.8855, 21.44865]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.698800000000002, 58.472500000000004, 21.33435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.633100000000002, 58.31385, 21.321649999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.076900000000002, 56.87115, 21.207349999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.01905, 56.70945, 21.19465]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.53395, 55.24155, 21.080350000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.4841, 55.0772, 21.067650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.0719, 53.5868, 20.95335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.0302, 53.420199999999994, 20.940649999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.6918, 51.9118, 20.826349999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.6583, 51.7434, 20.81365]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.393699999999999, 50.220600000000005, 20.699350000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.3685, 50.05075000000001, 20.686650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.1795, 48.51625, 20.57235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.162650000000001, 48.345299999999995, 20.559649999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.048350000000001, 46.802699999999994, 20.445349999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.039900000000001, 46.63115, 20.4327]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0021, 45.08585, 20.319300000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0021, 44.91415, 20.30665]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.039900000000001, 43.36885, 20.19235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.048350000000001, 43.197300000000006, 20.179650000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.162650000000001, 41.654700000000005, 20.065350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.1795, 41.48375, 20.05265]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.3685, 39.94925, 19.93835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.393699999999999, 39.7794, 19.92565]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.6583, 38.2566, 19.81135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.6918, 38.0882, 19.798650000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.0302, 36.579800000000006, 19.684350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.0719, 36.4132, 19.67165]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.4841, 34.92280000000001, 19.55735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.53395, 34.75845, 19.54465]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.01905, 33.29055, 19.43035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.076900000000002, 33.12885000000001, 19.417650000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.633100000000002, 31.686150000000005, 19.303350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.698800000000002, 31.527500000000003, 19.29065]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.325200000000002, 30.114500000000003, 19.176350000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.39865, 29.959250000000004, 19.163650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.09435, 28.57775, 19.04935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.1753, 28.42625, 19.03665]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.936700000000002, 27.080750000000002, 18.92235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.025000000000002, 26.93345, 18.90965]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.853, 25.62755, 18.795350000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.94845, 25.4848, 18.782650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.83855, 24.221200000000003, 18.66835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.94085, 24.08325, 18.65565]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.89215, 22.86375, 18.54135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.0011, 22.73095, 18.52865]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.0109, 21.56005, 18.414350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.1262, 21.4328, 18.401650000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.191800000000004, 20.313200000000002, 18.28735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.313200000000002, 20.191800000000004, 18.27465]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.4328, 19.1262, 18.16035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.56005, 19.0109, 18.14765]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.73095, 18.0011, 18.033350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.863750000000003, 17.89215, 18.020650000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.08325, 16.94085, 17.90635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.221200000000003, 16.83855, 17.89365]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.4848, 15.94845, 17.77935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.62755, 15.853, 17.76665]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.93345, 15.025, 17.652350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.08075, 14.9367, 17.6397]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.42625, 14.1753, 17.5263]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.57775, 14.094349999999999, 17.513650000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.959250000000004, 13.39865, 17.399350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.1145, 13.325199999999999, 17.38665]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.527499999999996, 12.6988, 17.27235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.68615, 12.6331, 17.25965]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.12885, 12.0769, 17.14535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.29055, 12.01905, 17.13265]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.75845, 11.533949999999999, 17.01835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.9228, 11.4841, 17.00565]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.4132, 11.071900000000001, 16.891350000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.579800000000006, 11.0302, 16.87865]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.0882, 10.6918, 16.76435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.2566, 10.6583, 16.75165]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.7794, 10.393699999999999, 16.63735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.94925, 10.3685, 16.62465]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.48375, 10.1795, 16.510350000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.654700000000005, 10.162650000000001, 16.49765]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.197300000000006, 10.048350000000001, 16.38335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.36885, 10.039900000000001, 16.37065]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.91415, 10.0021, 16.25635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.08585, 10.0021, 16.24365]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.63115, 10.039900000000001, 16.129350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.8027, 10.048350000000001, 16.11665]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.345299999999995, 10.162650000000001, 16.00235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.51625, 10.1795, 15.989650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.05075000000001, 10.3685, 15.875350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.220600000000005, 10.393699999999999, 15.86265]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.7434, 10.6583, 15.748350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.9118, 10.6918, 15.735650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.420199999999994, 11.0302, 15.62135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.5868, 11.071900000000001, 15.60865]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0772, 11.4841, 15.49435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.24155, 11.533949999999999, 15.48165]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.70945, 12.01905, 15.367350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.87115, 12.0769, 15.354650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.31385, 12.6331, 15.24035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.472500000000004, 12.6988, 15.22765]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.8855, 13.325199999999999, 15.11335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.04075, 13.39865, 15.10065]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.42225, 14.094349999999999, 14.986350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.57375, 14.1753, 14.973700000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.91925, 14.9367, 14.860299999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.06655, 15.025, 14.847649999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.37245, 15.853, 14.733350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.5152, 15.94845, 14.720650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.7788, 16.83855, 14.60635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.91675000000001, 16.94085, 14.59365]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.13624999999999, 17.89215, 14.47935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.26905, 18.0011, 14.466650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.43995, 19.0109, 14.352350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.5672, 19.1262, 14.33965]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.6868, 20.191800000000004, 14.22535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.8082, 20.313200000000002, 14.21265]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.8738, 21.4328, 14.09835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.98910000000001, 21.56005, 14.085650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.9989, 22.73095, 13.971350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.10785000000001, 22.86375, 13.95865]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.05914999999999, 24.08325, 13.84435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.16145, 24.221200000000003, 13.83165]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.05154999999999, 25.4848, 13.71735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.147, 25.62755, 13.70465]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.97500000000001, 26.93345, 13.59035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.0633, 27.080750000000002, 13.57765]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.8247, 28.42625, 13.463350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.90565000000001, 28.57775, 13.450650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.60135, 29.959250000000004, 13.33635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.6748, 30.114500000000003, 13.32365]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.30120000000001, 31.527500000000003, 13.20935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.3669, 31.686150000000005, 13.19665]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.92309999999999, 33.12885000000001, 13.082350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.98094999999999, 33.29055, 13.069650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.46605, 34.75845, 12.95535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.51589999999999, 34.92280000000001, 12.94265]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.9281, 36.4132, 12.82835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.96979999999999, 36.579800000000006, 12.81565]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.3082, 38.0882, 12.701350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.3417, 38.2566, 12.68865]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.6063, 39.7794, 12.574349999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.6315, 39.94925, 12.56165]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.82050000000001, 41.48375, 12.447350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.83735000000001, 41.654700000000005, 12.434650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.95165, 43.197300000000006, 12.320350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.9601, 43.36885, 12.3077]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.9979, 44.91415, 12.194300000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.9979, 45.08585, 12.181650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.9601, 46.63115, 12.067350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.95165, 46.802699999999994, 12.05465]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.83735000000001, 48.345299999999995, 11.940349999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.82050000000001, 48.51625, 11.927649999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.6315, 50.05075000000001, 11.81335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.6063, 50.220600000000005, 11.800650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.3417, 51.7434, 11.686350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.3082, 51.9118, 11.67365]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.96979999999999, 53.420199999999994, 11.55935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.9281, 53.5868, 11.54665]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.51589999999999, 55.0772, 11.43235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.46605, 55.24155, 11.41965]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.98094999999999, 56.70945, 11.30535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.92309999999999, 56.87115, 11.29265]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.3669, 58.31385, 11.17835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.30120000000001, 58.472500000000004, 11.16565]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.6748, 59.8855, 11.05135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.60135, 60.040749999999996, 11.03865]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.90565000000001, 61.42225, 10.92435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.8247, 61.573750000000004, 10.91165]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.0633, 62.919250000000005, 10.79735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.97500000000001, 63.06655, 10.78465]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.147, 64.37245, 10.67035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.05154999999999, 64.5152, 10.65765]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.16145, 65.7788, 10.543350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.05914999999999, 65.91675000000001, 10.530650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.10785000000001, 67.13624999999999, 10.41635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.9989, 67.26905, 10.403649999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.98910000000001, 68.43995, 10.289349999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.8738, 68.5672, 10.27665]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.8082, 69.68679999999999, 10.162350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.6868, 69.8082, 10.149650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.5672, 70.8738, 10.03535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.43995, 70.98910000000001, 10.022649999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.26905, 71.9989, 9.908349999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.13624999999999, 72.10785000000001, 9.89565]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.91675000000001, 73.05914999999999, 9.781350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.7788, 73.16145, 9.768650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.5152, 74.05154999999999, 9.654349999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.37245, 74.147, 9.641649999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.06655, 74.97500000000001, 9.527350000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.91925, 75.0633, 9.514700000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.57375, 75.8247, 9.4013]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.42225, 75.90565000000001, 9.38865]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.04075, 76.60135, 9.27435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.8855, 76.6748, 9.261650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.472500000000004, 77.30120000000001, 9.147350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.31385, 77.3669, 9.13465]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.87115, 77.92309999999999, 9.02035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.70945, 77.98094999999999, 9.00765]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.24155, 78.46605, 8.89335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0772, 78.51589999999999, 8.880650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.5868, 78.9281, 8.766350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.420199999999994, 78.96979999999999, 8.75365]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.9118, 79.3082, 8.63935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.7434, 79.3417, 8.62665]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.220600000000005, 79.6063, 8.51235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.05075000000001, 79.6315, 8.49965]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.51625, 79.82050000000001, 8.38535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.345299999999995, 79.83735000000001, 8.37265]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.8027, 79.95165, 8.25835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.63115, 79.9601, 8.245650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.08585, 79.9979, 8.13135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.91415, 79.9979, 8.11865]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.36885, 79.9601, 8.00435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.197300000000006, 79.95165, 7.99165]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.654700000000005, 79.83735000000001, 7.877350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.48375, 79.82050000000001, 7.864650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.94925, 79.6315, 7.75035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.7794, 79.6063, 7.73765]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.2566, 79.3417, 7.62335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.0882, 79.3082, 7.61065]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.579800000000006, 78.96979999999999, 7.4963500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.4132, 78.9281, 7.483650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.9228, 78.51589999999999, 7.369350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.75845, 78.46605, 7.35665]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.29055, 77.98094999999999, 7.24235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.12885, 77.92309999999999, 7.2296499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.68615, 77.3669, 7.11535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.527499999999996, 77.30120000000001, 7.102650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.1145, 76.6748, 6.9883500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.959250000000004, 76.60135, 6.97565]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.57775, 75.90565000000001, 6.86135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.42625, 75.8247, 6.8487]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.08075, 75.0633, 6.7353]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.93345, 74.97500000000001, 6.72265]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.62755, 74.147, 6.608350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.4848, 74.05154999999999, 6.595650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.221200000000003, 73.16145, 6.48135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.08325, 73.05914999999999, 6.46865]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.863750000000003, 72.10785000000001, 6.35435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.73095, 71.9989, 6.34165]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.56005, 70.98910000000001, 6.22735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.4328, 70.8738, 6.214650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.313200000000002, 69.8082, 6.100350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.191800000000004, 69.68679999999999, 6.08765]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.1262, 68.5672, 5.97335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.0109, 68.43995, 5.960649999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.0011, 67.26905, 5.84635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.89215, 67.13624999999999, 5.8336500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.94085, 65.91675000000001, 5.71935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.83855, 65.7788, 5.70665]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.94845, 64.5152, 5.59235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.853, 64.37245, 5.57965]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.025000000000002, 63.06655, 5.46535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.936700000000002, 62.919250000000005, 5.45265]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.1753, 61.573750000000004, 5.33835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.09435, 61.42225, 5.3256499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.39865, 60.040749999999996, 5.2113499999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.325200000000002, 59.8855, 5.19865]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.698800000000002, 58.472500000000004, 5.084350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.633100000000002, 58.31385, 5.071650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.076900000000002, 56.87115, 4.95735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.01905, 56.70945, 4.944649999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.53395, 55.24155, 4.830349999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.4841, 55.0772, 4.8176499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.0719, 53.5868, 4.70335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.0302, 53.420199999999994, 4.690650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.6918, 51.9118, 4.576350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.6583, 51.7434, 4.563650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.393699999999999, 50.220600000000005, 4.44935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.3685, 50.05075000000001, 4.43665]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.1795, 48.51625, 4.32235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.162650000000001, 48.345299999999995, 4.3096499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.048350000000001, 46.802699999999994, 4.19535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.039900000000001, 46.63115, 4.1827000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0021, 45.08585, 4.0693]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0021, 44.91415, 4.056649999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.039900000000001, 43.36885, 3.9423500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.048350000000001, 43.197300000000006, 3.92965]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.162650000000001, 41.654700000000005, 3.81535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.1795, 41.48375, 3.8026500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.3685, 39.94925, 3.6883500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.393699999999999, 39.7794, 3.67565]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.6583, 38.2566, 3.56135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.6918, 38.0882, 3.5486500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.0302, 36.579800000000006, 3.4343500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.0719, 36.4132, 3.42165]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.4841, 34.92280000000001, 3.3073500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.53395, 34.75845, 3.2946500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.01905, 33.29055, 3.18035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.076900000000002, 33.12885000000001, 3.16765]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.633100000000002, 31.686150000000005, 3.05335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.698800000000002, 31.527500000000003, 3.0406500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.325200000000002, 30.114500000000003, 2.9263500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.39865, 29.959250000000004, 2.91365]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.09435, 28.57775, 2.79935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.1753, 28.42625, 2.78665]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.936700000000002, 27.080750000000002, 2.67235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.025000000000002, 26.93345, 2.65965]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.853, 25.62755, 2.5453500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.94845, 25.4848, 2.5326500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.83855, 24.221200000000003, 2.4183499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.94085, 24.08325, 2.4056499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.89215, 22.86375, 2.2913500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.0011, 22.73095, 2.2786500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.0109, 21.56005, 2.1643499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.1262, 21.4328, 2.15165]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.191800000000004, 20.313200000000002, 2.03735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.313200000000002, 20.191800000000004, 2.0246500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.4328, 19.1262, 1.91035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.56005, 19.0109, 1.89765]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.73095, 18.0011, 1.78335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.863750000000003, 17.89215, 1.7706499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.08325, 16.94085, 1.6563499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.221200000000003, 16.83855, 1.6436499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.4848, 15.94845, 1.52935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.62755, 15.853, 1.51665]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.93345, 15.025, 1.40235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.08075, 14.9367, 1.3897]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.42625, 14.1753, 1.2763]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.57775, 14.094349999999999, 1.26365]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.959250000000004, 13.39865, 1.1493499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.1145, 13.325199999999999, 1.13665]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.527499999999996, 12.6988, 1.0223499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.68615, 12.6331, 1.00965]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.12885, 12.0769, 0.8953500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.29055, 12.01905, 0.88265]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.75845, 11.533949999999999, 0.7683500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.9228, 11.4841, 0.75565]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.4132, 11.071900000000001, 0.64135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.579800000000006, 11.0302, 0.62865]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.0882, 10.6918, 0.51435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.2566, 10.6583, 0.50165]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.7794, 10.393699999999999, 0.38735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.94925, 10.3685, 0.37465000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.48375, 10.1795, 0.26034999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.654700000000005, 10.162650000000001, 0.24765]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.197300000000006, 10.048350000000001, 0.13335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.36885, 10.039900000000001, 0.12065]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.91415, 10.0021, 0.006350000000000001]) cube([0.4, 0.4, 0.1], center=true);
}

