translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.2]);

translate([2, 0, 0]) cube([1, 1, 4.0]);

translate([3, 0, 0]) cube([1, 1, 3.9000081250321053]);

translate([4, 0, 0]) cube([1, 1, 4.2]);

translate([5, 0, 0]) cube([1, 1, 4.5]);

translate([6, 0, 0]) cube([1, 1, 4.2]);

translate([7, 0, 0]) cube([1, 1, 4.41]);

translate([8, 0, 0]) cube([1, 1, 5.01]);

translate([9, 0, 0]) cube([1, 1, 5.31]);

translate([10, 0, 0]) cube([1, 1, 4.393255585883612]);

translate([11, 0, 0]) cube([1, 1, 4.393260827506905]);

translate([12, 0, 0]) cube([1, 1, 4.387119748452454]);

translate([13, 0, 0]) cube([1, 1, 4.390081224636373]);

translate([14, 0, 0]) cube([1, 1, 4.390245974194368]);

translate([15, 0, 0]) cube([1, 1, 4.390229091093031]);

color([0, 1, 0]) translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.4]);

translate([2, 1, 0]) cube([1, 1, 4.8]);

translate([3, 1, 0]) cube([1, 1, 4.4]);

translate([4, 1, 0]) cube([1, 1, 4.3]);

translate([5, 1, 0]) cube([1, 1, 4.034030147586757]);

translate([6, 1, 0]) cube([1, 1, 4.034515088319395]);

translate([7, 1, 0]) cube([1, 1, 4.034375061384058]);

translate([8, 1, 0]) cube([1, 1, 4.269999999999999]);

translate([9, 1, 0]) cube([1, 1, 4.519999999999998]);

translate([10, 1, 0]) cube([1, 1, 4.395101943468359]);

translate([11, 1, 0]) cube([1, 1, 4.395139312682565]);

translate([12, 1, 0]) cube([1, 1, 4.425188708021523]);

translate([13, 1, 0]) cube([1, 1, 4.398015601140894]);

translate([14, 1, 0]) cube([1, 1, 4.3913418490080165]);

translate([15, 1, 0]) cube([1, 1, 4.392254654711949]);

translate([0, 2, 0]) cube([1, 1, 7.2]);

color([0, 1, 0]) translate([1, 2, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.4]);

translate([4, 2, 0]) cube([1, 1, 5.0]);

translate([5, 2, 0]) cube([1, 1, 4.4]);

translate([6, 2, 0]) cube([1, 1, 4.6]);

translate([7, 2, 0]) cube([1, 1, 4.8]);

translate([8, 2, 0]) cube([1, 1, 4.71]);

translate([9, 2, 0]) cube([1, 1, 4.549999999999997]);

translate([10, 2, 0]) cube([1, 1, 4.439707681927535]);

translate([11, 2, 0]) cube([1, 1, 4.478071195708865]);

translate([12, 2, 0]) cube([1, 1, 4.4965791335192975]);

translate([13, 2, 0]) cube([1, 1, 4.457128036783891]);

translate([14, 2, 0]) cube([1, 1, 4.428896664374718]);

translate([15, 2, 0]) cube([1, 1, 4.391610010726368]);

translate([0, 3, 0]) cube([1, 1, 7.7]);

translate([1, 3, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([2, 3, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 3, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.1]);

color([0, 1, 0]) translate([6, 3, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 3, 0]) cube([1, 1, 6]);

translate([8, 3, 0]) cube([1, 1, 5.31]);

translate([9, 3, 0]) cube([1, 1, 4.599999999999998]);

translate([10, 3, 0]) cube([1, 1, 4.520998765799485]);

translate([11, 3, 0]) cube([1, 1, 4.546504808887339]);

translate([12, 3, 0]) cube([1, 1, 4.5815178170213855]);

translate([13, 3, 0]) cube([1, 1, 4.569694426903621]);

translate([14, 3, 0]) cube([1, 1, 4.553213363602575]);

translate([15, 3, 0]) cube([1, 1, 4.475144664782614]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.3]);

translate([2, 4, 0]) cube([1, 1, 6.8]);

color([0, 1, 0]) translate([3, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 4, 0]) cube([1, 1, 6]);

translate([8, 4, 0]) cube([1, 1, 5.42]);

translate([9, 4, 0]) cube([1, 1, 4.899999999999996]);

translate([10, 4, 0]) cube([1, 1, 4.588800247134196]);

translate([11, 4, 0]) cube([1, 1, 4.59529392045409]);

translate([12, 4, 0]) cube([1, 1, 4.6410153707836805]);

translate([13, 4, 0]) cube([1, 1, 4.734612491471739]);

translate([14, 4, 0]) cube([1, 1, 4.679687662686021]);

translate([15, 4, 0]) cube([1, 1, 4.586408730158707]);

translate([0, 5, 0]) cube([1, 1, 8.0]);

translate([1, 5, 0]) cube([1, 1, 7.1]);

translate([2, 5, 0]) cube([1, 1, 6.6]);

translate([3, 5, 0]) cube([1, 1, 6.8]);

translate([4, 5, 0]) cube([1, 1, 6.7]);

color([0, 1, 0]) translate([5, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 5, 0]) cube([1, 1, 6]);

translate([9, 5, 0]) cube([1, 1, 5.109999999999996]);

translate([10, 5, 0]) cube([1, 1, 4.606443542496456]);

translate([11, 5, 0]) cube([1, 1, 4.608210510666385]);

translate([12, 5, 0]) cube([1, 1, 4.6865047286661445]);

translate([13, 5, 0]) cube([1, 1, 4.8010635933836125]);

translate([14, 5, 0]) cube([1, 1, 4.74816247718396]);

translate([15, 5, 0]) cube([1, 1, 4.641333333333314]);

translate([0, 6, 0]) cube([1, 1, 8.2]);

translate([1, 6, 0]) cube([1, 1, 7.3]);

translate([2, 6, 0]) cube([1, 1, 7.3]);

translate([3, 6, 0]) cube([1, 1, 7.5]);

translate([4, 6, 0]) cube([1, 1, 6.9]);

translate([5, 6, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([6, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.1999999999999975]);

translate([10, 6, 0]) cube([1, 1, 4.275365117942327]);

translate([11, 6, 0]) cube([1, 1, 4.627826002397476]);

translate([12, 6, 0]) cube([1, 1, 4.724594886841073]);

translate([13, 6, 0]) cube([1, 1, 4.838186904761894]);

translate([14, 6, 0]) cube([1, 1, 4.999999999999998]);

translate([15, 6, 0]) cube([1, 1, 4.64133333294233]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.7]);

translate([2, 7, 0]) cube([1, 1, 7.6]);

translate([3, 7, 0]) cube([1, 1, 7.4]);

translate([4, 7, 0]) cube([1, 1, 7.0]);

translate([5, 7, 0]) cube([1, 1, 7.0]);

translate([6, 7, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([7, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 7, 0]) cube([1, 1, 6]);

translate([10, 7, 0]) cube([1, 1, 4.281324439308653]);

translate([11, 7, 0]) cube([1, 1, 4.4929062323115545]);

translate([12, 7, 0]) cube([1, 1, 4.704572466037705]);

translate([13, 7, 0]) cube([1, 1, 4.808156066515099]);

translate([14, 7, 0]) cube([1, 1, 5.449999999999999]);

color([0, 1, 0]) translate([15, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 7.7]);

translate([1, 8, 0]) cube([1, 1, 7.3]);

translate([2, 8, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([3, 8, 0]) cube([1, 1, 6]);

translate([4, 8, 0]) cube([1, 1, 6.6]);

translate([5, 8, 0]) cube([1, 1, 6.8]);

color([0, 1, 0]) translate([6, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 8, 0]) cube([1, 1, 6]);

translate([14, 8, 0]) cube([1, 1, 6.72]);

color([0, 1, 0]) translate([15, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 6.8]);

translate([1, 9, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([2, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 9, 0]) cube([1, 1, 6]);

translate([6, 9, 0]) cube([1, 1, 6.6]);

translate([7, 9, 0]) cube([1, 1, 6.9]);

color([0, 1, 0]) translate([8, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([1, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 10, 0]) cube([1, 1, 6]);

translate([3, 10, 0]) cube([1, 1, 5.4]);

translate([4, 10, 0]) cube([1, 1, 5.4]);

color([0, 1, 0]) translate([5, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 10, 0]) cube([1, 1, 6]);

translate([7, 10, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([8, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 7.1]);

color([0, 1, 0]) translate([1, 11, 0]) cube([1, 1, 6]);

translate([2, 11, 0]) cube([1, 1, 5.2]);

color([0, 1, 0]) translate([3, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.8]);

color([0, 1, 0]) translate([8, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 11, 0]) cube([1, 1, 6]);

translate([15, 11, 0]) cube([1, 1, 5.22]);

translate([0, 12, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([1, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 12, 0]) cube([1, 1, 6]);

translate([6, 12, 0]) cube([1, 1, 7.0]);

translate([7, 12, 0]) cube([1, 1, 7.1]);

color([0, 1, 0]) translate([8, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 12, 0]) cube([1, 1, 6]);

translate([14, 12, 0]) cube([1, 1, 5.3]);

translate([15, 12, 0]) cube([1, 1, 4.990550378596294]);

color([0, 1, 0]) translate([0, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([1, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 13, 0]) cube([1, 1, 6]);

translate([5, 13, 0]) cube([1, 1, 6.7]);

translate([6, 13, 0]) cube([1, 1, 7.0]);

translate([7, 13, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([8, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 13, 0]) cube([1, 1, 6]);

translate([13, 13, 0]) cube([1, 1, 5.4]);

translate([14, 13, 0]) cube([1, 1, 5.4]);

translate([15, 13, 0]) cube([1, 1, 5.0]);

color([0, 1, 0]) translate([0, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([1, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([0, 15, 0]) cube([1, 1, 6]);

translate([1, 15, 0]) cube([1, 1, 5.4]);

translate([2, 15, 0]) cube([1, 1, 5.3]);

translate([3, 15, 0]) cube([1, 1, 5.1]);

translate([4, 15, 0]) cube([1, 1, 5.4]);

color([0, 1, 0]) translate([5, 15, 0]) cube([1, 1, 6]);

translate([6, 15, 0]) cube([1, 1, 5.2]);

translate([7, 15, 0]) cube([1, 1, 5.4]);

color([0, 1, 0]) translate([8, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 15, 0]) cube([1, 1, 6]);

translate([11, 15, 0]) cube([1, 1, 5.3008730190223154]);

translate([12, 15, 0]) cube([1, 1, 5.4]);

translate([13, 15, 0]) cube([1, 1, 5.304366914807212]);

color([0, 1, 0]) translate([14, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 15, 0]) cube([1, 1, 6]);
