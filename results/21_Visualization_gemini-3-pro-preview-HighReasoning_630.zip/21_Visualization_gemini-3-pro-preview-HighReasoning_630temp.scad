
hull() {
    translate([150.09, 20.005, 249.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.71, 20.095000000000002, 249.81000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([151.89000000000001, 20.110000000000003, 249.79000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([153.51000000000002, 20.29, 249.60999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([153.69, 20.315, 249.58499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([155.31, 20.585000000000004, 249.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.49, 20.620000000000005, 249.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([157.10999999999999, 20.980000000000004, 249.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([157.285, 21.025000000000002, 248.98]) cube([0.4, 0.4, 0.1], center=true);
    translate([158.81500000000003, 21.475, 248.62]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([158.99, 21.53, 248.58]) cube([0.4, 0.4, 0.1], center=true);
    translate([160.60999999999999, 22.07, 248.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([160.785, 22.135, 248.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([162.315, 22.765, 247.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.48499999999999, 22.84, 247.775]) cube([0.4, 0.4, 0.1], center=true);
    translate([164.015, 23.560000000000002, 247.32500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([164.185, 23.645000000000003, 247.27500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([165.71500000000003, 24.455000000000002, 246.82500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.88500000000002, 24.55, 246.775]) cube([0.4, 0.4, 0.1], center=true);
    translate([167.415, 25.45, 246.32500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.58, 25.555, 246.27500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([169.02, 26.545, 245.82500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([169.18, 26.660000000000004, 245.77000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([170.62, 27.740000000000002, 245.23000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([170.78, 27.865000000000002, 245.17000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([172.22000000000003, 29.035000000000004, 244.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([172.37500000000003, 29.17, 244.57]) cube([0.4, 0.4, 0.1], center=true);
    translate([173.72500000000002, 30.43, 244.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([173.87500000000003, 30.57, 243.965]) cube([0.4, 0.4, 0.1], center=true);
    translate([175.22500000000002, 31.830000000000002, 243.33500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([175.375, 31.975, 243.26500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([176.725, 33.324999999999996, 242.635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.87, 33.48, 242.565]) cube([0.4, 0.4, 0.1], center=true);
    translate([178.13, 34.92, 241.935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([178.26999999999998, 35.085, 241.865]) cube([0.4, 0.4, 0.1], center=true);
    translate([179.52999999999997, 36.615, 241.23499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([179.665, 36.785000000000004, 241.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([180.835, 38.315000000000005, 240.44000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.965, 38.49, 240.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([182.135, 40.11000000000001, 239.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([182.265, 40.29500000000001, 239.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([183.435, 42.005, 238.84000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.56, 42.195, 238.76000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([184.64, 43.905, 238.04000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([184.755, 44.095, 237.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([185.74500000000003, 45.805, 237.14499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([185.85500000000002, 46.0, 237.05499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([186.845, 47.8, 236.24499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([186.95000000000002, 48.005, 236.15499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([187.85000000000002, 49.895, 235.34500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([187.95000000000002, 50.105000000000004, 235.25500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([188.85000000000002, 51.995000000000005, 234.44500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([188.94500000000002, 52.21, 234.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([189.75500000000002, 54.19, 233.54500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([189.84000000000003, 54.41, 233.45000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([190.56, 56.39, 232.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([190.64, 56.61, 232.45]) cube([0.4, 0.4, 0.1], center=true);
    translate([191.36, 58.59, 231.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([191.43500000000003, 58.815000000000005, 231.45]) cube([0.4, 0.4, 0.1], center=true);
    translate([192.065, 60.885, 230.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.13, 61.114999999999995, 230.45000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([192.67000000000002, 63.185, 229.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.73000000000002, 63.415, 229.44500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([193.27000000000004, 65.485, 228.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([193.32500000000005, 65.72, 228.345]) cube([0.4, 0.4, 0.1], center=true);
    translate([193.77500000000003, 67.88, 227.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([193.82000000000002, 68.12, 227.24500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([194.18, 70.28, 226.255]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.22, 70.52000000000001, 226.14499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([194.57999999999998, 72.67999999999999, 225.155]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.61499999999998, 72.925, 225.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([194.885, 75.175, 224.055]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.91, 75.425, 223.945]) cube([0.4, 0.4, 0.1], center=true);
    translate([195.09, 77.675, 222.955]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.10500000000002, 77.925, 222.84000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([195.195, 80.175, 221.76]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.205, 80.425, 221.64]) cube([0.4, 0.4, 0.1], center=true);
    translate([195.29500000000002, 82.675, 220.56]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.3, 82.925, 220.44000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([195.3, 85.175, 219.36]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.29500000000002, 85.42999999999999, 219.24]) cube([0.4, 0.4, 0.1], center=true);
    translate([195.205, 87.77000000000001, 218.16]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.19, 88.02500000000002, 218.04]) cube([0.4, 0.4, 0.1], center=true);
    translate([195.01, 90.27500000000002, 216.96]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.99, 90.53000000000002, 216.84]) cube([0.4, 0.4, 0.1], center=true);
    translate([194.81000000000003, 92.87, 215.76]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.78500000000003, 93.125, 215.64]) cube([0.4, 0.4, 0.1], center=true);
    translate([194.51500000000001, 95.375, 214.56]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.48000000000002, 95.63, 214.435]) cube([0.4, 0.4, 0.1], center=true);
    translate([194.12, 97.97, 213.265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.075, 98.225, 213.14]) cube([0.4, 0.4, 0.1], center=true);
    translate([193.625, 100.475, 212.06]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([193.57000000000002, 100.72999999999999, 211.94]) cube([0.4, 0.4, 0.1], center=true);
    translate([193.03000000000003, 103.07000000000001, 210.86]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.97000000000003, 103.32500000000002, 210.74000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([192.43, 105.57500000000002, 209.66]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.365, 105.83000000000001, 209.535]) cube([0.4, 0.4, 0.1], center=true);
    translate([191.735, 108.17, 208.36500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([191.66, 108.425, 208.24000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([190.94, 110.675, 207.16]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([190.855, 110.925, 207.04]) cube([0.4, 0.4, 0.1], center=true);
    translate([190.045, 113.175, 205.96]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([189.95, 113.425, 205.835]) cube([0.4, 0.4, 0.1], center=true);
    translate([189.04999999999998, 115.675, 204.665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([188.95, 115.925, 204.54]) cube([0.4, 0.4, 0.1], center=true);
    translate([188.05, 118.175, 203.46]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([187.94500000000002, 118.42, 203.34]) cube([0.4, 0.4, 0.1], center=true);
    translate([186.955, 120.58000000000001, 202.26]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([186.84, 120.82000000000001, 202.14]) cube([0.4, 0.4, 0.1], center=true);
    translate([185.76, 122.97999999999999, 201.06]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([185.635, 123.22, 200.94]) cube([0.4, 0.4, 0.1], center=true);
    translate([184.465, 125.38, 199.86]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([184.335, 125.62, 199.74]) cube([0.4, 0.4, 0.1], center=true);
    translate([183.165, 127.78000000000002, 198.66000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.03, 128.02, 198.54000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([181.77, 130.18, 197.46]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([181.625, 130.41500000000002, 197.34]) cube([0.4, 0.4, 0.1], center=true);
    translate([180.275, 132.485, 196.26]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.12, 132.715, 196.14]) cube([0.4, 0.4, 0.1], center=true);
    translate([178.68, 134.78500000000003, 195.06]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([178.52, 135.01000000000002, 194.94]) cube([0.4, 0.4, 0.1], center=true);
    translate([177.08, 136.99, 193.86]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.91500000000002, 137.21, 193.745]) cube([0.4, 0.4, 0.1], center=true);
    translate([175.38500000000002, 139.19000000000003, 192.755]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([175.215, 139.41000000000003, 192.64000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([173.685, 141.39000000000001, 191.56]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([173.51000000000002, 141.60500000000002, 191.445]) cube([0.4, 0.4, 0.1], center=true);
    translate([171.89000000000001, 143.495, 190.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([171.705, 143.705, 190.34500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([169.995, 145.595, 189.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([169.805, 145.79999999999998, 189.245]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.09500000000003, 147.6, 188.255]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.9, 147.8, 188.14499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([166.1, 149.6, 187.15499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.9, 149.79999999999998, 187.045]) cube([0.4, 0.4, 0.1], center=true);
    translate([164.1, 151.6, 186.055]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([163.89499999999998, 151.795, 185.945]) cube([0.4, 0.4, 0.1], center=true);
    translate([162.005, 153.505, 184.95499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([161.79500000000002, 153.69500000000002, 184.85]) cube([0.4, 0.4, 0.1], center=true);
    translate([159.90500000000003, 155.40500000000003, 183.95000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.69000000000003, 155.59000000000003, 183.85000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([157.71, 157.21000000000004, 182.95000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([157.485, 157.38500000000002, 182.85000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([155.41500000000002, 158.915, 181.95000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.185, 159.08499999999998, 181.85000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([153.115, 160.615, 180.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([152.88500000000002, 160.785, 180.85]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.815, 162.315, 179.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.57999999999998, 162.475, 179.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([148.42000000000002, 163.82500000000002, 179.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([148.18000000000004, 163.97500000000002, 178.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([146.02, 165.32500000000002, 178.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([145.78, 165.47500000000002, 177.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([143.62, 166.82500000000002, 177.14499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([143.375, 166.97, 177.05499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([141.125, 168.23000000000002, 176.24499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([140.875, 168.36500000000004, 176.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([138.625, 169.535, 175.44000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([138.375, 169.66, 175.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.125, 170.74000000000004, 174.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.87, 170.86, 174.55999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([133.53, 171.94, 173.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([133.27, 172.055, 173.76000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([130.93, 173.045, 173.04000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([130.67000000000002, 173.14999999999998, 172.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([128.32999999999998, 174.05, 172.23999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.07, 174.145, 172.165]) cube([0.4, 0.4, 0.1], center=true);
    translate([125.72999999999999, 174.955, 171.535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.47, 175.045, 171.465]) cube([0.4, 0.4, 0.1], center=true);
    translate([123.13, 175.855, 170.83500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.86500000000001, 175.935, 170.76500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.435, 176.565, 170.135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.17, 176.635, 170.065]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.83000000000001, 177.26500000000001, 169.435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.56500000000001, 177.33, 169.37]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.135, 177.87, 168.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.86500000000001, 177.925, 168.77]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.435, 178.375, 168.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([112.16499999999999, 178.425, 168.17]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.735, 178.87500000000003, 167.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([109.465, 178.91500000000002, 167.57]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.03500000000001, 179.185, 167.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.76500000000001, 179.215, 166.97500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.33500000000001, 179.485, 166.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.065, 179.50500000000002, 166.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([101.635, 179.595, 166.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.36500000000001, 179.605, 165.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.935, 179.695, 165.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.665, 179.7, 165.47500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.235, 179.7, 165.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.96499999999999, 179.695, 164.98]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.535, 179.605, 164.61999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.265, 179.58999999999997, 164.57999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.83500000000001, 179.41, 164.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.56500000000001, 179.38500000000002, 164.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.135, 179.115, 163.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.87, 179.085, 163.78000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.53000000000002, 178.81500000000003, 163.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.26500000000001, 178.775, 163.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.83500000000001, 178.32500000000002, 163.11499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.57000000000001, 178.27500000000003, 163.08499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.23, 177.82500000000002, 162.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.97, 177.76500000000001, 162.78500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.63, 177.135, 162.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.37, 177.065, 162.49]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.03000000000002, 176.43500000000003, 162.31000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.77000000000001, 176.36, 162.29000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.42999999999999, 175.64, 162.10999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.16999999999999, 175.55499999999998, 162.08999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.83, 174.74499999999998, 161.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.575, 174.64999999999998, 161.89000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.325, 173.74999999999997, 161.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.075, 173.64999999999998, 161.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.825, 172.75, 161.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.575, 172.645, 161.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.325, 171.655, 161.41000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.080000000000005, 171.54, 161.40000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.92, 170.46, 161.40000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.68, 170.335, 161.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.519999999999996, 169.165, 161.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.28, 169.035, 161.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.120000000000005, 167.865, 161.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.885, 167.73000000000002, 161.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.815000000000005, 166.47000000000003, 161.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.58500000000001, 166.33, 161.305]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.515, 165.07, 161.395]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.29, 164.925, 161.40000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.31, 163.57500000000002, 161.40000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.09, 163.425, 161.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.11, 162.07500000000002, 161.495]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.894999999999996, 161.92000000000002, 161.51]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.004999999999995, 160.48000000000002, 161.69]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.794999999999995, 160.31500000000003, 161.705]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.904999999999994, 158.785, 161.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.699999999999996, 158.61499999999998, 161.81]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.9, 157.085, 161.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.705, 156.91500000000002, 162.01500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.995, 155.38500000000002, 162.28500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.805, 155.21, 162.31000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.095, 153.59, 162.49]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.91, 153.41, 162.515]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.290000000000006, 151.79, 162.78500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.115, 151.605, 162.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.585, 149.895, 163.18]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.42, 149.705, 163.215]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.979999999999997, 147.995, 163.485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.82, 147.805, 163.52]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.380000000000003, 146.095, 163.88000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.225, 145.905, 163.925]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.875, 144.195, 164.375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.73, 144.0, 164.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.47, 142.2, 164.78000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.334999999999997, 142.0, 164.83]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.165000000000003, 140.2, 165.37]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.040000000000003, 140.0, 165.425]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.959999999999997, 138.2, 165.875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.845, 138.0, 165.93]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.855, 136.2, 166.47]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.745, 135.995, 166.53]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.755000000000003, 134.10500000000002, 167.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.655, 133.9, 167.13]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.845000000000002, 132.1, 167.67000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.76, 131.89499999999998, 167.735]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.04, 130.005, 168.365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.96, 129.79500000000002, 168.435]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.240000000000002, 127.905, 169.065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.17, 127.695, 169.14]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.630000000000003, 125.805, 169.85999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.575000000000003, 125.59500000000001, 169.935]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.125000000000004, 123.705, 170.565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.080000000000002, 123.49499999999999, 170.64]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.72, 121.605, 171.36]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.685, 121.39500000000001, 171.44500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.415, 119.50500000000001, 172.25500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.389999999999997, 119.29500000000002, 172.34000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.21, 117.405, 173.06]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.195, 117.195, 173.14499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.105000000000004, 115.305, 173.95499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.1, 115.09500000000001, 174.045]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.1, 113.205, 174.855]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.105000000000004, 112.99499999999999, 174.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.195, 111.105, 175.85]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.215, 110.89500000000001, 175.945]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.485, 109.00500000000001, 176.755]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.515, 108.795, 176.85]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.785, 106.905, 177.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.825, 106.69500000000001, 177.85000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.275000000000002, 104.805, 178.75000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.325000000000003, 104.595, 178.85000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.775000000000002, 102.70500000000001, 179.75000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.835, 102.5, 179.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.465, 100.69999999999999, 180.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.54, 100.5, 180.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.259999999999998, 98.69999999999999, 181.85000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.345, 98.5, 181.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.154999999999998, 96.7, 182.94500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.25, 96.5, 183.05]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.15, 94.7, 183.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.255, 94.5, 184.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.245, 92.7, 185.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.360000000000003, 92.50500000000001, 185.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.44, 90.79500000000002, 186.14499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.565, 90.605, 186.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.735000000000003, 88.895, 187.24500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.870000000000005, 88.705, 187.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.130000000000003, 86.995, 188.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.275, 86.81, 188.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.625, 85.19, 189.44500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.784999999999997, 85.01, 189.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.314999999999998, 83.39, 190.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.485, 83.215, 190.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.015, 81.685, 191.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.195, 81.515, 191.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.905, 79.98500000000001, 192.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.095, 79.82000000000001, 192.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.805, 78.38, 193.84500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.0, 78.22, 193.95000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.8, 76.78, 194.85]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.005, 76.625, 194.95499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.895, 75.275, 195.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.11, 75.13000000000001, 196.05]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.09, 73.87, 196.95000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.315000000000005, 73.73, 197.05]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.385000000000005, 72.47000000000001, 197.95000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.615, 72.33500000000001, 198.05]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.684999999999995, 71.16499999999999, 198.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.92, 71.03999999999999, 199.05]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.08, 69.96000000000001, 199.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.325, 69.84, 200.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.575, 68.76, 200.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.83, 68.65, 200.945]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.17, 67.75, 201.755]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.43, 67.65, 201.845]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.77, 66.75, 202.655]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.035000000000004, 66.655, 202.74]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.465, 65.845, 203.46]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.735, 65.76, 203.54000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.165, 65.04, 204.26]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.44, 64.965, 204.34]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.96, 64.335, 205.06]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.24, 64.27, 205.135]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.76, 63.730000000000004, 205.76500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.045, 63.675000000000004, 205.83500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.655, 63.225, 206.465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.945, 63.18000000000001, 206.53]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.55499999999999, 62.81999999999999, 207.07]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.845, 62.785, 207.125]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.455, 62.515, 207.575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.745, 62.49, 207.625]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.35499999999999, 62.31, 208.075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.64999999999999, 62.295, 208.12]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.35, 62.205000000000005, 208.48000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.645, 62.2, 208.52]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.25500000000001, 62.2, 208.88000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.55000000000001, 62.21000000000001, 208.91500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.25, 62.39, 209.185]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.545, 62.41, 209.21]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.155, 62.59, 209.39000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.45, 62.620000000000005, 209.41000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.15, 62.980000000000004, 209.58999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.44500000000001, 63.02, 209.605]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.055, 63.38, 209.695]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.35000000000001, 63.43000000000001, 209.7]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.05000000000001, 63.97, 209.7]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.34500000000001, 64.035, 209.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.955, 64.665, 209.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.24499999999999, 64.74000000000001, 209.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.855, 65.46000000000001, 209.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.14500000000001, 65.545, 209.49]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.75500000000001, 66.355, 209.31]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([109.04, 66.45, 209.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([111.56, 67.35000000000001, 209.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.84, 67.455, 208.98499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([114.36, 68.445, 208.71499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.64, 68.565, 208.67999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.16, 69.735, 208.32000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.435, 69.865, 208.27500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.86500000000001, 71.035, 207.82500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.135, 71.16999999999999, 207.77]) cube([0.4, 0.4, 0.1], center=true);
    translate([122.56500000000001, 72.43, 207.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.83500000000001, 72.575, 207.17]) cube([0.4, 0.4, 0.1], center=true);
    translate([125.26500000000001, 73.92500000000001, 206.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.53000000000002, 74.08500000000001, 206.565]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.87, 75.61500000000001, 205.935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.125, 75.78500000000001, 205.86]) cube([0.4, 0.4, 0.1], center=true);
    translate([130.375, 77.31500000000001, 205.14000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([130.625, 77.49000000000001, 205.06]) cube([0.4, 0.4, 0.1], center=true);
    translate([132.875, 79.11, 204.34]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([133.12, 79.295, 204.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.28, 81.005, 203.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.51500000000001, 81.19999999999999, 203.35]) cube([0.4, 0.4, 0.1], center=true);
    translate([137.58499999999998, 82.99999999999999, 202.45]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([137.815, 83.19999999999999, 202.35]) cube([0.4, 0.4, 0.1], center=true);
    translate([139.885, 85.0, 201.45000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([140.11, 85.205, 201.34500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([142.08999999999997, 87.095, 200.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([142.30499999999998, 87.31, 200.24]) cube([0.4, 0.4, 0.1], center=true);
    translate([144.195, 89.29, 199.16]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([144.405, 89.51500000000001, 199.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([146.29500000000002, 91.58500000000001, 198.055]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([146.49500000000003, 91.815, 197.935]) cube([0.4, 0.4, 0.1], center=true);
    translate([148.20500000000004, 93.885, 196.765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([148.39500000000004, 94.12, 196.635]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.10500000000002, 96.28, 195.46500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.29000000000002, 96.52000000000001, 195.335]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.91000000000003, 98.68, 194.165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([152.085, 98.925, 194.03]) cube([0.4, 0.4, 0.1], center=true);
    translate([153.61499999999998, 101.175, 192.77]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([153.785, 101.425, 192.625]) cube([0.4, 0.4, 0.1], center=true);
    translate([155.31500000000003, 103.675, 191.27499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.47500000000002, 103.93, 191.12499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([156.82500000000002, 106.27000000000001, 189.77499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([156.97500000000002, 106.53, 189.625]) cube([0.4, 0.4, 0.1], center=true);
    translate([158.325, 108.87, 188.275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([158.47, 109.135, 188.125]) cube([0.4, 0.4, 0.1], center=true);
    translate([159.73000000000002, 111.565, 186.775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.865, 111.83, 186.62]) cube([0.4, 0.4, 0.1], center=true);
    translate([161.035, 114.17, 185.18]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([161.16, 114.435, 185.02]) cube([0.4, 0.4, 0.1], center=true);
    translate([162.24, 116.865, 183.58]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.35500000000002, 117.14, 183.41500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([163.345, 119.66, 181.885]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([163.45, 119.935, 181.715]) cube([0.4, 0.4, 0.1], center=true);
    translate([164.35000000000002, 122.36500000000001, 180.185]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([164.44500000000002, 122.64, 180.01500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([165.25500000000002, 125.16, 178.485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.34, 125.435, 178.315]) cube([0.4, 0.4, 0.1], center=true);
    translate([166.06, 127.86500000000001, 176.785]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([166.13500000000002, 128.14000000000001, 176.61]) cube([0.4, 0.4, 0.1], center=true);
    translate([166.76500000000001, 130.66000000000003, 174.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([166.83, 130.94, 174.81]) cube([0.4, 0.4, 0.1], center=true);
    translate([167.37, 133.45999999999998, 173.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.425, 133.74, 173.01]) cube([0.4, 0.4, 0.1], center=true);
    translate([167.875, 136.26, 171.39000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.92000000000002, 136.54000000000002, 171.21]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.28000000000003, 139.06, 169.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.31500000000003, 139.33999999999997, 169.405]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.585, 141.85999999999999, 167.695]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.61, 142.14, 167.505]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.79000000000002, 144.66000000000003, 165.795]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.805, 144.94000000000003, 165.60999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.895, 147.46, 163.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.90000000000003, 147.74, 163.805]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.90000000000003, 150.26000000000002, 162.095]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.895, 150.54000000000002, 161.905]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.805, 153.06, 160.195]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.79000000000002, 153.34, 160.005]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.61, 155.86, 158.295]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.585, 156.135, 158.105]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.31500000000003, 158.565, 156.395]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.28000000000003, 158.83999999999997, 156.205]) cube([0.4, 0.4, 0.1], center=true);
    translate([167.92000000000002, 161.35999999999999, 154.495]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.87, 161.635, 154.305]) cube([0.4, 0.4, 0.1], center=true);
    translate([167.33, 164.065, 152.595]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.27, 164.335, 152.405]) cube([0.4, 0.4, 0.1], center=true);
    translate([166.73, 166.76500000000001, 150.695]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([166.66, 167.035, 150.505]) cube([0.4, 0.4, 0.1], center=true);
    translate([165.94, 169.46499999999997, 148.795]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.86, 169.73, 148.605]) cube([0.4, 0.4, 0.1], center=true);
    translate([165.14000000000001, 172.07, 146.895]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.05, 172.32999999999998, 146.71]) cube([0.4, 0.4, 0.1], center=true);
    translate([164.15, 174.67000000000002, 145.09]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([164.045, 174.93000000000004, 144.905]) cube([0.4, 0.4, 0.1], center=true);
    translate([163.055, 177.27, 143.195]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.94500000000002, 177.525, 143.005]) cube([0.4, 0.4, 0.1], center=true);
    translate([161.955, 179.775, 141.295]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([161.835, 180.025, 141.11]) cube([0.4, 0.4, 0.1], center=true);
    translate([160.665, 182.275, 139.49]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([160.535, 182.52, 139.305]) cube([0.4, 0.4, 0.1], center=true);
    translate([159.365, 184.68000000000004, 137.595]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.225, 184.92000000000002, 137.41]) cube([0.4, 0.4, 0.1], center=true);
    translate([157.875, 187.07999999999998, 135.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([157.72500000000002, 187.315, 135.60999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([156.37500000000003, 189.38500000000002, 133.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([156.215, 189.61, 133.81]) cube([0.4, 0.4, 0.1], center=true);
    translate([154.68499999999997, 191.59, 132.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([154.515, 191.81, 132.01]) cube([0.4, 0.4, 0.1], center=true);
    translate([152.985, 193.79000000000002, 130.39000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([152.81, 194.01000000000002, 130.21]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.19, 195.99, 128.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([151.005, 196.20000000000002, 128.41500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([149.295, 198.0, 126.885]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([149.1, 198.2, 126.71000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([147.29999999999998, 200.0, 125.09]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([147.1, 200.195, 124.915]) cube([0.4, 0.4, 0.1], center=true);
    translate([145.3, 201.90500000000003, 123.385]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([145.09, 202.09500000000003, 123.215]) cube([0.4, 0.4, 0.1], center=true);
    translate([143.11, 203.805, 121.685]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([142.89000000000001, 203.985, 121.515]) cube([0.4, 0.4, 0.1], center=true);
    translate([140.91000000000003, 205.515, 119.98500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([140.685, 205.685, 119.82000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([138.615, 207.21500000000003, 118.38]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([138.385, 207.38000000000002, 118.215]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.315, 208.82000000000002, 116.685]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([136.07999999999998, 208.97500000000002, 116.52]) cube([0.4, 0.4, 0.1], center=true);
    translate([133.92000000000002, 210.32500000000002, 115.08]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([133.675, 210.47000000000003, 114.92]) cube([0.4, 0.4, 0.1], center=true);
    translate([131.425, 211.73000000000002, 113.48]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([131.175, 211.865, 113.325]) cube([0.4, 0.4, 0.1], center=true);
    translate([128.925, 213.035, 111.97500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.67000000000002, 213.16, 111.82000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([126.33, 214.24, 110.38]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.07, 214.35500000000002, 110.225]) cube([0.4, 0.4, 0.1], center=true);
    translate([123.72999999999999, 215.34500000000003, 108.875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.465, 215.45000000000002, 108.725]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.035, 216.35000000000002, 107.375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.765, 216.44500000000002, 107.225]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.33500000000001, 217.25500000000002, 105.875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118.06000000000002, 217.34000000000003, 105.73]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.54000000000002, 218.06, 104.47000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([115.26000000000002, 218.135, 104.33000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.74000000000001, 218.76500000000001, 103.07000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([112.46000000000001, 218.83, 102.93]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.94, 219.37, 101.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([109.655, 219.425, 101.53]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.04500000000002, 219.875, 100.27000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.75500000000001, 219.92000000000002, 100.135]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.14500000000001, 220.28000000000003, 98.965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.855, 220.31, 98.83500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([101.24499999999999, 220.49, 97.665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.955, 220.51000000000002, 97.535]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.34500000000001, 220.69, 96.36500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.055, 220.7, 96.235]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.445, 220.7, 95.065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.155, 220.695, 94.94]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.54500000000002, 220.605, 93.86]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.25500000000001, 220.59, 93.735]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.645, 220.41000000000003, 92.565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.35499999999999, 220.38500000000002, 92.44]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.745, 220.115, 91.36]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.455, 220.08, 91.245]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.845, 219.72, 90.25500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.55499999999999, 219.67499999999998, 90.14]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.945, 219.225, 89.06]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.655, 219.17000000000002, 88.94500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.04500000000002, 218.63, 87.95500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.75500000000001, 218.56, 87.84500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.145, 217.84, 86.855]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.86, 217.76000000000002, 86.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.34, 217.04000000000002, 85.85]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.055, 216.95000000000002, 85.745]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.445, 216.05, 84.75500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.16, 215.95000000000002, 84.65]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.64, 215.05, 83.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.36500000000001, 214.94, 83.65]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.935, 213.86, 82.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.660000000000004, 213.74, 82.65]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.14, 212.66, 81.75]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.864999999999995, 212.53, 81.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.435, 211.26999999999998, 80.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.17, 211.13, 80.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.830000000000005, 209.87000000000003, 79.94500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.57000000000001, 209.72500000000002, 79.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.230000000000004, 208.37500000000003, 79.04500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.97, 208.22000000000003, 78.95500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.63, 206.78, 78.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.375, 206.62, 78.05499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.125, 205.18, 77.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.875, 205.01500000000001, 77.16000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.625, 203.485, 76.44000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.38, 203.31, 76.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.22, 201.69, 75.63999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.98, 201.505, 75.55999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.82, 199.795, 74.83999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.585, 199.605, 74.76499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.515, 197.895, 74.13499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.29, 197.705, 74.06]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.31, 195.995, 73.34]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.09, 195.8, 73.265]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.11, 194.00000000000003, 72.635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.895, 193.79500000000002, 72.565]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.005, 191.905, 71.935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.795, 191.695, 71.87]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.905, 189.80499999999998, 71.33]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.705000000000002, 189.58999999999997, 71.265]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.995, 187.61, 70.63499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.805, 187.39, 70.57]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.095000000000002, 185.41000000000003, 70.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.910000000000004, 185.19, 69.97]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.290000000000003, 183.20999999999998, 69.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.11, 182.98499999999999, 69.37]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.49, 180.91500000000002, 68.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.32, 180.68500000000003, 68.77]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.880000000000003, 178.615, 68.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.720000000000002, 178.385, 68.175]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.28, 176.315, 67.72500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.125, 176.07999999999998, 67.67500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.775, 173.92000000000002, 67.22500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.625, 173.68, 67.17500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.275, 171.52, 66.725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.135, 171.28000000000003, 66.675]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.965, 169.12, 66.22500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.84, 168.875, 66.18]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.76, 166.625, 65.82]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.64, 166.38, 65.78]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.56, 164.22, 65.42]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.45, 163.975, 65.38000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.55, 161.725, 65.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.45, 161.475, 64.98]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.55, 159.225, 64.61999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.455000000000002, 158.97, 64.58]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.645000000000001, 156.63, 64.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.56, 156.375, 64.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.84, 154.125, 63.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.765, 153.87, 63.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.135, 151.53000000000003, 63.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.07, 151.27500000000003, 63.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.53, 149.02500000000003, 63.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.475, 148.77, 63.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.025, 146.43, 63.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.9799999999999995, 146.17000000000002, 62.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.619999999999999, 143.82999999999998, 62.809999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.584999999999999, 143.57, 62.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.3149999999999995, 141.23, 62.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.29, 140.97, 62.49]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.11, 138.63, 62.31]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.095000000000001, 138.37, 62.29]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.005000000000001, 136.03, 62.11]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.0, 135.77, 62.09]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.0, 133.43, 61.910000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.005000000000001, 133.17000000000002, 61.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.095000000000001, 130.82999999999998, 61.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.115, 130.57, 61.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.385000000000001, 128.23, 61.61000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.415000000000001, 127.97, 61.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.6850000000000005, 125.63, 61.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.720000000000001, 125.37, 61.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.08, 123.03000000000002, 61.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.13, 122.77000000000001, 61.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.670000000000001, 120.42999999999999, 61.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.73, 120.175, 61.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.270000000000001, 117.925, 61.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.34, 117.67, 61.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.059999999999999, 115.33000000000001, 61.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.139999999999999, 115.075, 61.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.86, 112.825, 61.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.945, 112.57000000000001, 61.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.755, 110.23, 61.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.855, 109.97500000000001, 61.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.845, 107.72500000000001, 61.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.955000000000002, 107.47500000000001, 61.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.945, 105.22500000000001, 61.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.065000000000001, 104.98, 61.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.235000000000001, 102.82000000000001, 61.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.370000000000001, 102.575, 61.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.629999999999999, 100.325, 61.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.77, 100.08000000000001, 61.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.03, 97.92, 61.095]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.180000000000003, 97.67999999999999, 61.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.619999999999997, 95.52000000000001, 61.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.784999999999997, 95.28500000000001, 61.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.314999999999998, 93.21499999999999, 61.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.49, 92.98499999999999, 61.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.11, 90.91499999999999, 61.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.295, 90.685, 61.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.005000000000003, 88.61500000000001, 61.295]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.200000000000003, 88.385, 61.305]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.000000000000004, 86.315, 61.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.205000000000002, 86.09, 61.405]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.095, 84.11000000000001, 61.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.31, 83.89000000000001, 61.510000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.29, 81.91000000000001, 61.69]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.509999999999998, 81.69500000000001, 61.705]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.49, 79.805, 61.795]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.720000000000006, 79.595, 61.805]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.88, 77.705, 61.895]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.125, 77.495, 61.910000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.375, 75.605, 62.09]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.625, 75.4, 62.11]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.875, 73.60000000000001, 62.29]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.13, 73.405, 62.305]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.470000000000006, 71.695, 62.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.73500000000001, 71.505, 62.41]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.165, 69.795, 62.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.44, 69.605, 62.61000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.96, 67.895, 62.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.24, 67.71, 62.809999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.760000000000005, 66.09, 62.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.045, 65.91499999999999, 63.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.655, 64.38499999999999, 63.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.95, 64.215, 63.215]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.65, 62.685, 63.485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.949999999999996, 62.52, 63.51]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.65, 61.08, 63.690000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.955, 60.92, 63.715]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.745, 59.480000000000004, 63.985]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.06, 59.33, 64.01]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.94, 58.07000000000001, 64.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.25999999999999, 57.93000000000001, 64.215]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.14, 56.67, 64.485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.465, 56.53000000000001, 64.515]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.435, 55.27000000000001, 64.785]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.765, 55.14000000000001, 64.815]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.735, 54.06, 65.085]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.065, 53.94, 65.115]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.035, 52.86, 65.385]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.37, 52.745, 65.42]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.43, 51.755, 65.78]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.775, 51.645, 65.815]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.925, 50.655, 66.085]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.27, 50.555, 66.115]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.33, 49.745000000000005, 66.385]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.675, 49.655, 66.42]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.825, 48.845, 66.78]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.175, 48.760000000000005, 66.82]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.325, 48.040000000000006, 67.18]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.68, 47.965, 67.215]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.92, 47.335, 67.485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.28, 47.27, 67.52]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.52, 46.730000000000004, 67.88000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.88, 46.67, 67.92]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.11999999999999, 46.13, 68.28]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.47999999999999, 46.080000000000005, 68.32]) cube([0.4, 0.4, 0.1], center=true);
    translate([110.72, 45.720000000000006, 68.68]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.08, 45.68, 68.72]) cube([0.4, 0.4, 0.1], center=true);
    translate([114.32, 45.31999999999999, 69.08]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.685, 45.285, 69.12]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.01500000000001, 45.015, 69.48]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118.38000000000001, 44.99, 69.525]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.62, 44.81, 69.975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.98500000000001, 44.795, 70.02]) cube([0.4, 0.4, 0.1], center=true);
    translate([125.315, 44.705000000000005, 70.38000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.685, 44.7, 70.42]) cube([0.4, 0.4, 0.1], center=true);
    translate([129.015, 44.7, 70.78]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([129.385, 44.7, 70.825]) cube([0.4, 0.4, 0.1], center=true);
    translate([132.715, 44.7, 71.275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([133.085, 44.71, 71.32000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.415, 44.88999999999999, 71.68]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([136.785, 44.915, 71.72]) cube([0.4, 0.4, 0.1], center=true);
    translate([140.115, 45.18500000000001, 72.08]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([140.485, 45.215, 72.125]) cube([0.4, 0.4, 0.1], center=true);
    translate([143.815, 45.485, 72.575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([144.185, 45.525000000000006, 72.62]) cube([0.4, 0.4, 0.1], center=true);
    translate([147.51500000000001, 45.975, 72.98]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([147.88, 46.025, 73.025]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.12, 46.475, 73.47500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([151.485, 46.535000000000004, 73.52000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([154.815, 47.165000000000006, 73.88000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.185, 47.23500000000001, 73.92500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([158.515, 47.865, 74.37500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([158.88, 47.94, 74.42]) cube([0.4, 0.4, 0.1], center=true);
    translate([162.12000000000003, 48.660000000000004, 74.77999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.48000000000002, 48.75000000000001, 74.82499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([165.72, 49.650000000000006, 75.27499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([166.08, 49.75000000000001, 75.32]) cube([0.4, 0.4, 0.1], center=true);
    translate([169.32000000000002, 50.650000000000006, 75.68]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([169.68, 50.755, 75.72500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([172.92, 51.745, 76.175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([173.27499999999998, 51.86, 76.22]) cube([0.4, 0.4, 0.1], center=true);
    translate([176.425, 52.940000000000005, 76.58]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.78, 53.065000000000005, 76.62]) cube([0.4, 0.4, 0.1], center=true);
    translate([180.02, 54.235, 76.97999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.37, 54.37, 77.02499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([183.43, 55.63, 77.475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.775, 55.77, 77.52]) cube([0.4, 0.4, 0.1], center=true);
    translate([186.92499999999998, 57.03, 77.88000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([187.26999999999998, 57.18, 77.92500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([190.33, 58.620000000000005, 78.375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([190.66500000000002, 58.785000000000004, 78.42]) cube([0.4, 0.4, 0.1], center=true);
    translate([193.63500000000002, 60.315, 78.78]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([193.96500000000003, 60.485, 78.82000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([196.935, 62.015, 79.18]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([197.265, 62.19, 79.225]) cube([0.4, 0.4, 0.1], center=true);
    translate([200.235, 63.81, 79.67500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.56, 63.995, 79.72]) cube([0.4, 0.4, 0.1], center=true);
    translate([203.44, 65.705, 80.08]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([203.76000000000002, 65.9, 80.12]) cube([0.4, 0.4, 0.1], center=true);
    translate([206.64000000000001, 67.69999999999999, 80.48]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([206.955, 67.905, 80.525]) cube([0.4, 0.4, 0.1], center=true);
    translate([209.745, 69.795, 80.97500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([210.05, 70.00500000000001, 81.02000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([212.75, 71.895, 81.38000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([213.05, 72.11, 81.42]) cube([0.4, 0.4, 0.1], center=true);
    translate([215.75, 74.09, 81.78]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.04500000000002, 74.315, 81.82000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([218.65500000000003, 76.385, 82.18]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([218.94500000000002, 76.61500000000001, 82.22]) cube([0.4, 0.4, 0.1], center=true);
    translate([221.555, 78.685, 82.58]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([221.84, 78.925, 82.62]) cube([0.4, 0.4, 0.1], center=true);
    translate([224.36, 81.175, 82.98]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.63500000000002, 81.42, 83.02000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([227.065, 83.58, 83.38]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.32999999999998, 83.83, 83.42]) cube([0.4, 0.4, 0.1], center=true);
    translate([229.67000000000002, 86.17, 83.78]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([229.93000000000004, 86.43, 83.82000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([232.27, 88.77000000000001, 84.18]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([232.525, 89.03500000000001, 84.22]) cube([0.4, 0.4, 0.1], center=true);
    translate([234.775, 91.465, 84.58]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([235.02, 91.74, 84.62]) cube([0.4, 0.4, 0.1], center=true);
    translate([237.18000000000004, 94.26, 84.98]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([237.42000000000002, 94.54, 85.02]) cube([0.4, 0.4, 0.1], center=true);
    translate([239.57999999999998, 97.06, 85.38000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([239.81, 97.34, 85.42000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([241.79000000000002, 99.86, 85.78]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([242.01000000000002, 100.15, 85.82]) cube([0.4, 0.4, 0.1], center=true);
    translate([243.99, 102.85000000000001, 86.17999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([244.20499999999998, 103.14500000000001, 86.215]) cube([0.4, 0.4, 0.1], center=true);
    translate([246.09499999999997, 105.755, 86.48500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([246.29999999999998, 106.05000000000001, 86.52000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([248.1, 108.75, 86.88000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([248.295, 109.055, 86.92]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.005, 111.845, 87.27999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.19, 112.155, 87.315]) cube([0.4, 0.4, 0.1], center=true);
    translate([251.81, 114.94500000000001, 87.58500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([251.985, 115.26, 87.61500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([253.51500000000001, 118.14, 87.88500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([253.685, 118.46000000000001, 87.92000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([255.215, 121.34, 88.28]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([255.375, 121.66000000000001, 88.315]) cube([0.4, 0.4, 0.1], center=true);
    translate([256.725, 124.54, 88.585]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([256.875, 124.86000000000001, 88.615]) cube([0.4, 0.4, 0.1], center=true);
    translate([258.225, 127.74000000000001, 88.885]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([258.365, 128.06500000000003, 88.915]) cube([0.4, 0.4, 0.1], center=true);
    translate([259.535, 131.035, 89.185]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([259.665, 131.37, 89.215]) cube([0.4, 0.4, 0.1], center=true);
    translate([260.835, 134.43, 89.485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([260.96, 134.765, 89.515]) cube([0.4, 0.4, 0.1], center=true);
    translate([262.04, 137.735, 89.785]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([262.15000000000003, 138.07000000000002, 89.815]) cube([0.4, 0.4, 0.1], center=true);
    translate([263.05, 141.13000000000002, 90.08500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([263.15000000000003, 141.47000000000003, 90.11500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([264.05, 144.53, 90.38500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([264.14500000000004, 144.875, 90.41500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([264.955, 148.025, 90.68500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([265.035, 148.37, 90.715]) cube([0.4, 0.4, 0.1], center=true);
    translate([265.665, 151.43, 90.985]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([265.735, 151.775, 91.01]) cube([0.4, 0.4, 0.1], center=true);
    translate([266.365, 154.925, 91.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([266.43, 155.27, 91.215]) cube([0.4, 0.4, 0.1], center=true);
    translate([266.97, 158.33, 91.48500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([267.02500000000003, 158.675, 91.51]) cube([0.4, 0.4, 0.1], center=true);
    translate([267.475, 161.82500000000002, 91.69]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([267.52, 162.175, 91.715]) cube([0.4, 0.4, 0.1], center=true);
    translate([267.88, 165.32500000000002, 91.985]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([267.90999999999997, 165.675, 92.00999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([268.09000000000003, 168.825, 92.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([268.11, 169.17499999999998, 92.215]) cube([0.4, 0.4, 0.1], center=true);
    translate([268.29, 172.325, 92.485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([268.305, 172.675, 92.51]) cube([0.4, 0.4, 0.1], center=true);
    translate([268.395, 175.82500000000002, 92.69000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([268.395, 176.18, 92.71000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([268.305, 179.42, 92.89000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([268.295, 179.77499999999998, 92.91000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([268.205, 182.92499999999998, 93.08999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([268.185, 183.27499999999998, 93.10999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([267.91499999999996, 186.425, 93.28999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([267.88, 186.775, 93.315]) cube([0.4, 0.4, 0.1], center=true);
    translate([267.52, 189.925, 93.585]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([267.48, 190.275, 93.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([267.12, 193.425, 93.695]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([267.07, 193.775, 93.71]) cube([0.4, 0.4, 0.1], center=true);
    translate([266.53, 196.92499999999998, 93.89]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([266.465, 197.27499999999998, 93.91000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([265.83500000000004, 200.42499999999998, 94.09]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([265.76000000000005, 200.76999999999998, 94.11]) cube([0.4, 0.4, 0.1], center=true);
    translate([265.04, 203.82999999999998, 94.29]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([264.955, 204.175, 94.31]) cube([0.4, 0.4, 0.1], center=true);
    translate([264.14500000000004, 207.325, 94.49]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([264.05, 207.67000000000002, 94.505]) cube([0.4, 0.4, 0.1], center=true);
    translate([263.15000000000003, 210.73000000000002, 94.595]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([263.045, 211.07, 94.61]) cube([0.4, 0.4, 0.1], center=true);
    translate([262.055, 214.13, 94.78999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([261.94, 214.47, 94.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([260.86, 217.53, 94.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([260.735, 217.865, 94.91000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([259.565, 220.835, 95.09]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([259.43, 221.16500000000002, 95.105]) cube([0.4, 0.4, 0.1], center=true);
    translate([258.17, 224.135, 95.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([258.03000000000003, 224.465, 95.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([256.77, 227.435, 95.295]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([256.62, 227.76500000000001, 95.31]) cube([0.4, 0.4, 0.1], center=true);
    translate([255.18, 230.735, 95.49000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([255.02, 231.06, 95.505]) cube([0.4, 0.4, 0.1], center=true);
    translate([253.58, 233.94, 95.595]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([253.41, 234.255, 95.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([251.79, 237.045, 95.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([251.61, 237.35999999999999, 95.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([249.99, 240.24, 95.795]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([249.805, 240.555, 95.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([248.09500000000003, 243.345, 95.895]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([247.90000000000003, 243.65, 95.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([246.10000000000002, 246.35, 95.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([245.9, 246.65, 95.905]) cube([0.4, 0.4, 0.1], center=true);
    translate([244.1, 249.35000000000002, 95.995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([243.89, 249.645, 96.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([241.91, 252.255, 96.095]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([241.69, 252.54500000000002, 96.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([239.70999999999998, 255.15500000000003, 96.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([239.48499999999999, 255.44000000000003, 96.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([237.41500000000002, 257.96000000000004, 96.195]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([237.18500000000003, 258.24, 96.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([235.115, 260.76, 96.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([234.875, 261.03499999999997, 96.205]) cube([0.4, 0.4, 0.1], center=true);
    translate([232.625, 263.46500000000003, 96.295]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([232.38, 263.735, 96.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([230.22, 266.165, 96.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([229.97, 266.43, 96.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([227.63, 268.77, 96.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.37, 269.025, 96.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([225.03, 271.275, 96.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.765, 271.525, 96.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([222.33499999999998, 273.775, 96.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([222.065, 274.015, 96.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([219.63500000000002, 276.085, 96.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([219.36, 276.32, 96.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([216.84, 278.48, 96.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.56, 278.71000000000004, 96.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([214.04000000000002, 280.69000000000005, 96.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([213.75500000000002, 280.91, 96.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([211.145, 282.89, 96.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([210.85500000000002, 283.105, 96.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([208.245, 284.995, 96.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([207.95, 285.20000000000005, 96.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([205.25, 287.00000000000006, 96.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([204.95, 287.19500000000005, 96.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([202.25, 288.90500000000003, 96.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([201.945, 289.09000000000003, 95.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.155, 290.71000000000004, 95.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([198.845, 290.89000000000004, 95.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([196.055, 292.51000000000005, 95.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.745, 292.68, 95.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([192.955, 294.11999999999995, 95.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.64000000000001, 294.28, 95.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([189.76, 295.72, 95.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([189.44, 295.875, 95.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([186.56000000000003, 297.225, 95.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([186.235, 297.365, 95.49000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([183.265, 298.535, 95.31]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([182.94, 298.665, 95.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([180.06, 299.835, 95.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([179.73499999999999, 299.96, 95.19000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([176.765, 301.04, 95.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.435, 301.15000000000003, 94.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([173.46500000000003, 302.05000000000007, 94.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([173.13500000000002, 302.15000000000003, 94.89000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([170.165, 303.05, 94.71000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([169.835, 303.14500000000004, 94.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([166.865, 303.95500000000004, 94.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([166.53, 304.04, 94.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([163.47000000000003, 304.76, 94.41000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([163.13000000000002, 304.83, 94.39000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([160.07, 305.37, 94.21000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.73, 305.43, 94.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([156.67, 305.97, 94.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([156.33499999999998, 306.02000000000004, 93.99000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([153.365, 306.38, 93.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([153.03, 306.42, 93.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([149.97000000000003, 306.78000000000003, 93.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([149.63000000000002, 306.81, 93.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([146.57000000000002, 306.99, 93.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([146.23000000000002, 307.01, 93.28999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([143.17000000000002, 307.19, 93.10999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([142.83, 307.20000000000005, 93.08999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([139.77, 307.20000000000005, 92.91000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([139.43, 307.195, 92.88500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.37, 307.105, 92.61500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([136.03, 307.095, 92.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([132.97, 307.005, 92.41000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([132.63500000000002, 306.985, 92.39000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([129.665, 306.715, 92.21000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([129.32999999999998, 306.67999999999995, 92.185]) cube([0.4, 0.4, 0.1], center=true);
    translate([126.27, 306.32, 91.915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.935, 306.27500000000003, 91.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([122.965, 305.82500000000005, 91.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.63499999999999, 305.77000000000004, 91.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.66499999999999, 305.23, 91.315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.335, 305.17, 91.285]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.365, 304.63000000000005, 91.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.035, 304.56000000000006, 90.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([113.06500000000001, 303.84000000000003, 90.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([112.73500000000001, 303.755, 90.68500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.765, 302.945, 90.41500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([109.44, 302.85, 90.38500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.56, 301.95, 90.11500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.24000000000001, 301.84999999999997, 90.08500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.36000000000001, 300.95, 89.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.04, 300.84, 89.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.16, 299.76, 89.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.845, 299.64000000000004, 89.47999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.055, 298.56000000000006, 89.12]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.745, 298.43500000000006, 89.085]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.955, 297.26500000000004, 88.815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.645, 297.13, 88.78]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.855, 295.87, 88.42]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.55000000000001, 295.725, 88.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.85000000000001, 294.375, 88.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.55000000000001, 294.225, 88.08]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.85000000000001, 292.87500000000006, 87.72000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.555, 292.71500000000003, 87.68]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.94500000000001, 291.185, 87.32]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.655, 291.015, 87.27999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.045, 289.48499999999996, 86.92]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.75500000000001, 289.315, 86.88000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.14500000000001, 287.785, 86.52000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.86, 287.605, 86.48]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.34, 285.89500000000004, 86.11999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.06500000000001, 285.71000000000004, 86.08]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.635, 284.09, 85.72000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.36, 283.9, 85.68]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.84, 282.1, 85.32]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.57000000000001, 281.90000000000003, 85.27499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.22999999999999, 280.1, 84.82499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.97, 279.895, 84.77999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.63, 278.005, 84.42]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.370000000000005, 277.79499999999996, 84.37500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.03, 275.90500000000003, 83.92500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.775, 275.69000000000005, 83.875]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.525, 273.71000000000004, 83.425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.28, 273.49, 83.38]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.120000000000005, 271.51, 83.02000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.88, 271.28499999999997, 82.97500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.720000000000006, 269.21500000000003, 82.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.48500000000001, 268.985, 82.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.415, 266.915, 82.02499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.184999999999995, 266.68, 81.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.115, 264.52, 81.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.89, 264.28, 81.47500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.91, 262.12, 81.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.69, 261.88, 80.97500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.71, 259.72, 80.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.495000000000005, 259.475, 80.47500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.605000000000004, 257.225, 80.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.4, 256.975, 79.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.6, 254.725, 79.52499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.400000000000006, 254.47, 79.47]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.6, 252.13000000000002, 78.93]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.405, 251.875, 78.875]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.695, 249.625, 78.425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.505, 249.37, 78.375]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.795, 247.03, 77.92500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.61, 246.76500000000001, 77.87000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.990000000000002, 244.335, 77.33]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.815, 244.07, 77.27]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.285, 241.73, 76.73]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.115000000000002, 241.465, 76.675]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.585, 239.03500000000003, 76.225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.42, 238.76500000000001, 76.17]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.98, 236.33499999999998, 75.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.82, 236.06, 75.57]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.38, 233.54000000000002, 75.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.23, 233.26500000000001, 74.97]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.97, 230.835, 74.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.825, 230.56, 74.37]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.475, 228.04000000000002, 73.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.335, 227.76000000000002, 73.77]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.165000000000003, 225.24, 73.23]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.035000000000004, 224.96, 73.17000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.865000000000002, 222.44000000000003, 72.63000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.740000000000002, 222.16000000000003, 72.565]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.660000000000004, 219.64000000000001, 71.935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.540000000000003, 219.36, 71.87]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.459999999999997, 216.84, 71.33]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.349999999999998, 216.56, 71.27]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.45, 214.04000000000002, 70.73]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.35, 213.75500000000002, 70.665]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.450000000000001, 211.145, 70.035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.350000000000001, 210.86, 69.97]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.450000000000001, 208.34, 69.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.360000000000001, 208.055, 69.36500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.64, 205.44500000000002, 68.73500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.56, 205.16000000000003, 68.665]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.840000000000002, 202.64, 68.035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.765, 202.35500000000002, 67.97]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.135000000000002, 199.745, 67.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.07, 199.45999999999998, 67.36500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.53, 196.94, 66.735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.469999999999999, 196.655, 66.665]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.93, 194.04500000000002, 66.035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.88, 193.75500000000002, 65.97]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.520000000000001, 191.145, 65.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.48, 190.86, 65.36500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.12, 188.34, 64.735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.084999999999999, 188.055, 64.665]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.815, 185.44500000000002, 64.035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.790000000000001, 185.155, 63.965]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.610000000000001, 182.545, 63.335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.59, 182.26, 63.265]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.41, 179.73999999999998, 62.635000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.395000000000001, 179.45499999999998, 62.565000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.305000000000001, 176.845, 61.935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3, 176.56, 61.865]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3, 174.04000000000002, 61.23500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.305000000000001, 173.75500000000002, 61.165000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.395000000000001, 171.145, 60.535000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.41, 170.86, 60.465]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.59, 168.34, 59.835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.615, 168.055, 59.76]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.885, 165.44500000000002, 59.04]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.92, 165.16000000000003, 58.965]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.280000000000001, 162.64, 58.335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.325000000000001, 162.36, 58.265]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.775, 159.83999999999997, 57.635000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.825000000000001, 159.56, 57.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.275000000000002, 157.04000000000002, 56.839999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.335, 156.76000000000002, 56.765]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.965, 154.24, 56.135000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.035, 153.96, 56.065000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.665, 151.44000000000003, 55.435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.74, 151.16000000000003, 55.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.46, 148.64000000000001, 54.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.545, 148.36, 54.565]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.355, 145.84, 53.935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.450000000000001, 145.56, 53.86]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.350000000000001, 143.04000000000002, 53.14]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.450000000000001, 142.76500000000001, 53.065]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.35, 140.33499999999998, 52.434999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.46, 140.06, 52.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.540000000000003, 137.54000000000002, 51.64000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.660000000000004, 137.26500000000001, 51.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.740000000000002, 134.83499999999998, 50.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.87, 134.565, 50.765]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.13, 132.135, 50.135000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.27, 131.87, 50.06]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.53, 129.53, 49.339999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.675, 129.26500000000001, 49.265]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.025000000000002, 126.83500000000001, 48.635000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.180000000000003, 126.57000000000001, 48.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.62, 124.23, 47.839999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.785, 123.97, 47.76]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.314999999999998, 121.63000000000001, 47.040000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.485, 121.37, 46.96000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.015000000000004, 119.03, 46.24000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.195000000000004, 118.775, 46.160000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.905, 116.525, 45.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.095, 116.27000000000001, 45.365]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.805, 113.93, 44.73500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.0, 113.68, 44.660000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.8, 111.52000000000001, 43.94]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.004999999999995, 111.275, 43.86]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.894999999999996, 109.025, 43.14]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.105, 108.78, 43.06]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.995, 106.62, 42.34]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.21, 106.38000000000001, 42.26]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.19, 104.22, 41.54]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.415, 103.985, 41.465]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.48500000000001, 101.915, 40.835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.720000000000006, 101.685, 40.76]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.88, 99.615, 40.04]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.12, 99.38499999999999, 39.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.279999999999994, 97.315, 39.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.525, 97.08500000000001, 39.160000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.775, 95.01500000000001, 38.440000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.03, 94.79, 38.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.370000000000005, 92.81, 37.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.63, 92.59500000000001, 37.565000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.970000000000006, 90.705, 36.935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.23500000000001, 90.49499999999999, 36.86]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.665, 88.605, 36.14]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.94, 88.39500000000001, 36.06]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.46, 86.50500000000001, 35.34]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.74, 86.30000000000001, 35.26]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.260000000000005, 84.50000000000001, 34.54]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.545, 84.30000000000001, 34.46]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.155, 82.50000000000001, 33.74]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.44500000000001, 82.305, 33.660000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.055, 80.595, 32.94]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.35, 80.405, 32.865]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.05000000000001, 78.695, 32.23500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.35000000000001, 78.50999999999999, 32.160000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.05000000000001, 76.89, 31.439999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.355, 76.71000000000001, 31.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.145, 75.09, 30.640000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.455, 74.915, 30.560000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.245, 73.385, 29.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.56, 73.215, 29.765]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.44, 71.685, 29.135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.76, 71.52, 29.060000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.64, 70.08, 28.340000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.96499999999999, 69.92, 28.265000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.93499999999999, 68.48, 27.635000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.25999999999999, 68.32500000000002, 27.560000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.14, 66.97500000000001, 26.840000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.47, 66.825, 26.76]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.53, 65.47500000000001, 26.040000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.86500000000001, 65.33000000000001, 25.965000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.83500000000001, 64.07000000000001, 25.335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.17, 63.935, 25.259999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.23, 62.76500000000001, 24.54]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.57000000000001, 62.63000000000001, 24.465]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.63, 61.370000000000005, 23.835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.975, 61.24, 23.765]) cube([0.4, 0.4, 0.1], center=true);
    translate([111.125, 60.160000000000004, 23.135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.475, 60.040000000000006, 23.060000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([114.625, 58.96, 22.34]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.975, 58.845, 22.265]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.125, 57.855, 21.635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118.475, 57.745, 21.560000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.625, 56.755, 20.840000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.98, 56.650000000000006, 20.765000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([125.22000000000001, 55.75, 20.135000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.58000000000001, 55.650000000000006, 20.065000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([128.82000000000002, 54.75000000000001, 19.435000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([129.18, 54.655, 19.365000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([132.42000000000002, 53.845, 18.735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([132.78, 53.760000000000005, 18.665]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.01999999999998, 53.040000000000006, 18.035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([136.38, 52.96, 17.965]) cube([0.4, 0.4, 0.1], center=true);
    translate([139.62, 52.24, 17.335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([139.985, 52.165000000000006, 17.265]) cube([0.4, 0.4, 0.1], center=true);
    translate([143.315, 51.535000000000004, 16.635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([143.68, 51.465, 16.565]) cube([0.4, 0.4, 0.1], center=true);
    translate([146.92, 50.835, 15.935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([147.285, 50.769999999999996, 15.865]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.61500000000004, 50.230000000000004, 15.235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.985, 50.17500000000001, 15.165]) cube([0.4, 0.4, 0.1], center=true);
    translate([154.315, 49.72500000000001, 14.535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([154.685, 49.68000000000001, 14.47]) cube([0.4, 0.4, 0.1], center=true);
    translate([158.015, 49.32, 13.93]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([158.385, 49.28, 13.865]) cube([0.4, 0.4, 0.1], center=true);
    translate([161.715, 48.92, 13.235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.085, 48.885, 13.165]) cube([0.4, 0.4, 0.1], center=true);
    translate([165.415, 48.615, 12.535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.785, 48.585, 12.47]) cube([0.4, 0.4, 0.1], center=true);
    translate([169.115, 48.315, 11.930000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([169.485, 48.295, 11.865]) cube([0.4, 0.4, 0.1], center=true);
    translate([172.81500000000003, 48.205000000000005, 11.235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([173.185, 48.19500000000001, 11.17]) cube([0.4, 0.4, 0.1], center=true);
    translate([176.515, 48.105000000000004, 10.629999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.885, 48.1, 10.565]) cube([0.4, 0.4, 0.1], center=true);
    translate([180.215, 48.1, 9.935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.585, 48.105000000000004, 9.870000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([183.915, 48.19500000000001, 9.330000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([184.285, 48.205000000000005, 9.270000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([187.615, 48.295, 8.729999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([187.985, 48.31, 8.669999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([191.315, 48.489999999999995, 8.129999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([191.685, 48.515, 8.07]) cube([0.4, 0.4, 0.1], center=true);
    translate([195.01500000000001, 48.785000000000004, 7.53]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.38, 48.82, 7.47]) cube([0.4, 0.4, 0.1], center=true);
    translate([198.62, 49.18, 6.930000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([198.985, 49.225, 6.870000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([202.315, 49.675000000000004, 6.33]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([202.68, 49.730000000000004, 6.27]) cube([0.4, 0.4, 0.1], center=true);
    translate([205.92000000000002, 50.269999999999996, 5.73]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([206.28500000000003, 50.33, 5.675]) cube([0.4, 0.4, 0.1], center=true);
    translate([209.615, 50.870000000000005, 5.2250000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([209.98000000000002, 50.940000000000005, 5.170000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([213.22, 51.660000000000004, 4.63]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([213.58, 51.74, 4.574999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([216.82000000000002, 52.46, 4.125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([217.18, 52.545, 4.075]) cube([0.4, 0.4, 0.1], center=true);
    translate([220.42, 53.355000000000004, 3.625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([220.78, 53.45, 3.575]) cube([0.4, 0.4, 0.1], center=true);
    translate([224.02, 54.35, 3.125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.38, 54.455, 3.075]) cube([0.4, 0.4, 0.1], center=true);
    translate([227.62, 55.44500000000001, 2.6250000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.97500000000002, 55.56, 2.575]) cube([0.4, 0.4, 0.1], center=true);
    translate([231.12500000000003, 56.64, 2.125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([231.47500000000002, 56.765, 2.075]) cube([0.4, 0.4, 0.1], center=true);
    translate([234.62500000000003, 57.935, 1.6250000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([234.97500000000002, 58.07000000000001, 1.58]) cube([0.4, 0.4, 0.1], center=true);
    translate([238.12500000000003, 59.33, 1.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([238.47000000000003, 59.475, 1.1800000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([241.53, 60.825, 0.8200000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([241.875, 60.975, 0.7800000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([245.025, 62.324999999999996, 0.42000000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([245.37, 62.485, 0.38000000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([248.43, 64.015, 0.020000000000000004]) cube([0.4, 0.4, 0.1], center=true);
}

