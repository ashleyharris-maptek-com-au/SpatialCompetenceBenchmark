
hull() {
    translate([14.496500000000001, 7.55, 8.993]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4335, 8.450000000000001, 8.866999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4195, 8.5495, 8.8525]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.2305, 9.4405, 8.717500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.203, 9.5385, 8.703000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.897000000000002, 10.411500000000002, 8.577]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.856000000000002, 10.5065, 8.563]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.424000000000001, 11.3435, 8.437]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.370000000000001, 11.4335, 8.423]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.830000000000002, 12.2165, 8.296999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.764500000000002, 12.3, 8.282499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.1255, 13.020000000000001, 8.1475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.0495, 13.095000000000002, 8.133000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.3205, 13.725000000000001, 8.007]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.235, 13.7895, 7.993]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.425, 14.3205, 7.867000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.332, 14.373, 7.852500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.468, 14.787, 7.7175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3695, 14.819500000000001, 7.703]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.4605, 14.9905, 7.577000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.3645, 15.0, 7.563000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.5455000000000005, 15.0, 7.437]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.4495000000000005, 14.996500000000001, 7.423]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.5405, 14.933499999999999, 7.297]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.44, 14.919, 7.2825]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.540000000000001, 14.721, 7.1475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.4415000000000004, 14.691500000000001, 7.133]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.568499999999999, 14.358500000000001, 7.007]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.4735, 14.3145, 6.993]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6365, 13.855500000000001, 6.867000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.5469999999999997, 13.797500000000001, 6.852500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.7729999999999997, 13.2125, 6.717499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.691, 13.1415, 6.702999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9889999999999999, 12.448500000000001, 6.577]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.916, 12.366, 6.563000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.304, 11.573999999999998, 6.437]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.2425, 11.481499999999999, 6.423]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.7475, 10.608500000000001, 6.297000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.7090000000000001, 10.508500000000002, 6.282500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.511, 9.5815, 6.1475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.5, 9.477, 6.133]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.5, 8.523000000000001, 6.007000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.5065, 8.417000000000002, 5.993]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.6235, 7.463000000000001, 5.867]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.643, 7.3580000000000005, 5.8525]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.877, 6.422000000000001, 5.7175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.91, 6.32, 5.703]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.27, 5.42, 5.577000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.316, 5.323, 5.563000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.784, 4.476999999999999, 5.436999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8425, 4.387, 5.422999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.4274999999999998, 3.613, 5.297]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.4975, 3.531, 5.2825]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.1725000000000003, 2.829, 5.147499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.253, 2.7565, 5.132999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.027, 2.1535, 5.007]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.1165, 2.0925000000000002, 4.9945]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.9535, 1.5975000000000001, 4.8955]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0495, 1.5495, 4.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.9405, 1.1805, 4.795]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.0415, 1.147, 4.7844999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.9685, 0.913, 4.685499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.0729999999999995, 0.8945000000000001, 4.6745]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.027000000000001, 0.7955000000000001, 4.575500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.133000000000001, 0.7915000000000001, 4.564500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.087000000000002, 0.8185, 4.4655000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.192, 0.829, 4.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.128, 0.991, 4.365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.230500000000001, 1.0165, 4.354500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.1395, 1.3135000000000001, 4.2555000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.237, 1.3535000000000001, 4.2445]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.083000000000002, 1.7765000000000002, 4.1455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.173000000000002, 1.8305000000000002, 4.135]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.947000000000001, 2.3795, 4.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.0275, 2.4465, 4.0345]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.7025, 3.1035, 3.9355]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.771, 3.1815, 3.9245000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.329, 3.9285000000000005, 3.8255]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.3835, 4.016, 3.8145]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.8065, 4.843999999999999, 3.7155]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.8385, 4.9395, 3.705]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.9915, 5.8305, 3.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 5.931, 3.6045000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 6.849000000000001, 3.5055]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.993, 6.952000000000001, 3.4945]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.867, 7.888000000000001, 3.3955]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.845, 7.991500000000001, 3.3850000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.575000000000001, 8.9185, 3.2950000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.538, 9.0195, 3.2845000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.142, 9.9105, 3.1855]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.091000000000001, 10.0065, 3.1745]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.568999999999999, 10.8435, 3.0755]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.5045, 10.933, 3.0645]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.8655, 11.707, 2.9655]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.789000000000001, 11.788, 2.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.050999999999998, 12.472000000000001, 2.8649999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.963999999999999, 12.542, 2.8545]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.136, 13.118, 2.7555]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.04, 13.176000000000002, 2.7445]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.139999999999999, 13.644000000000002, 2.6455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0375, 13.689, 2.6350000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0925, 14.031000000000002, 2.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.985999999999999, 14.061500000000002, 2.5345]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.014, 14.2685, 2.4355]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.9055, 14.284, 2.4245]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.9245, 14.356, 2.3255]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.816, 14.3565, 2.3145000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.844, 14.293499999999998, 2.2155]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.737500000000001, 14.279, 2.205]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.7925, 14.081, 2.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.69, 14.0515, 2.1045]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.79, 13.7185, 2.0055]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6935000000000002, 13.6745, 1.9945]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.8565, 13.2155, 1.8954999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.768, 13.158000000000001, 1.8849999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.012, 12.582000000000003, 1.795]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.9335, 12.511500000000002, 1.7845]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.2765000000000002, 11.8185, 1.6855]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.2105000000000001, 11.736, 1.6745]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.6795000000000001, 10.944, 1.5755000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.6425000000000001, 10.851, 1.5645]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.5075000000000001, 9.969000000000001, 1.4655]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.5, 9.867500000000001, 1.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.5, 8.9225, 1.3650000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.507, 8.8155, 1.3545000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.6330000000000001, 7.8345, 1.2555]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.6535000000000001, 7.7255, 1.2445]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.8965000000000001, 6.7445, 1.1455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9305000000000001, 6.636500000000001, 1.135]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.2995, 5.6735, 1.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.3470000000000002, 5.569, 1.0345]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8330000000000002, 4.651, 0.9355000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8930000000000002, 4.552499999999999, 0.9245000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.487, 3.6975000000000002, 0.8255]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.5585000000000004, 3.6075, 0.8145]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.2515000000000005, 2.8425000000000002, 0.7155]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3335000000000004, 2.763, 0.705]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.1165, 2.097, 0.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.2075000000000005, 2.0295, 0.6045]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0625, 1.4805, 0.5055000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.1605, 1.427, 0.4945]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.0695, 1.013, 0.3955]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.172000000000001, 0.974, 0.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.1080000000000005, 0.6860000000000002, 0.295]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.2135, 0.6615000000000001, 0.28450000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.1765, 0.5085, 0.1855]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.2835, 0.4995, 0.17450000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.246500000000001, 0.4905, 0.07550000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.352500000000001, 0.497, 0.06650000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.2975, 0.6230000000000001, 0.0035000000000000005]) cube([0.4, 0.4, 0.1], center=true);
}

