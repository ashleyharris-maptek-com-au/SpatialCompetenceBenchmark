
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.4]);

translate([2, 0, 0]) cube([1, 1, 4.2]);

translate([3, 0, 0]) cube([1, 1, 4.1]);

translate([4, 0, 0]) cube([1, 1, 4.007383675908655]);

translate([5, 0, 0]) cube([1, 1, 3.9886041109038626]);

translate([6, 0, 0]) cube([1, 1, 4.0292143284014665]);

translate([7, 0, 0]) cube([1, 1, 4.03876429852044]);

translate([8, 0, 0]) cube([1, 1, 4.2]);

translate([9, 0, 0]) cube([1, 1, 4.4]);

translate([10, 0, 0]) cube([1, 1, 4.5]);

translate([11, 0, 0]) cube([1, 1, 4.3]);

translate([12, 0, 0]) cube([1, 1, 4.2]);

translate([13, 0, 0]) cube([1, 1, 4.2]);

translate([14, 0, 0]) cube([1, 1, 4.4]);

translate([15, 0, 0]) cube([1, 1, 4.8]);

translate([16, 0, 0]) cube([1, 1, 5.0]);

translate([17, 0, 0]) cube([1, 1, 4.089742546685247]);

translate([18, 0, 0]) cube([1, 1, 4.10586916811177]);

translate([19, 0, 0]) cube([1, 1, 4.204361111111112]);

translate([20, 0, 0]) cube([1, 1, 4.437410957130553]);

translate([21, 0, 0]) cube([1, 1, 3.797300917658731]);

translate([22, 0, 0]) cube([1, 1, 4.9]);

translate([23, 0, 0]) cube([1, 1, 4.6]);

translate([24, 0, 0]) cube([1, 1, 3.073089027567765]);

translate([25, 0, 0]) cube([1, 1, 4.3]);

translate([26, 0, 0]) cube([1, 1, 4.3]);

translate([27, 0, 0]) cube([1, 1, 4.3]);

translate([28, 0, 0]) cube([1, 1, 4.4]);

translate([29, 0, 0]) cube([1, 1, 4.6]);

translate([30, 0, 0]) cube([1, 1, 4.7]);

translate([31, 0, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.1]);

translate([2, 1, 0]) cube([1, 1, 4.7]);

translate([3, 1, 0]) cube([1, 1, 4.5]);

translate([4, 1, 0]) cube([1, 1, 4.2]);

translate([5, 1, 0]) cube([1, 1, 4.029534703634621]);

translate([6, 1, 0]) cube([1, 1, 4.003371462721173]);

translate([7, 1, 0]) cube([1, 1, 4.03876429852044]);

translate([8, 1, 0]) cube([1, 1, 4.1]);

translate([9, 1, 0]) cube([1, 1, 4.2]);

translate([10, 1, 0]) cube([1, 1, 4.2]);

translate([11, 1, 0]) cube([1, 1, 4.1812878198905095]);

translate([12, 1, 0]) cube([1, 1, 4.189485641964072]);

translate([13, 1, 0]) cube([1, 1, 4.18937975949418]);

translate([14, 1, 0]) cube([1, 1, 4.192789403835694]);

translate([15, 1, 0]) cube([1, 1, 4.3]);

translate([16, 1, 0]) cube([1, 1, 4.5]);

translate([17, 1, 0]) cube([1, 1, 4.094927366889938]);

translate([18, 1, 0]) cube([1, 1, 4.8]);

translate([19, 1, 0]) cube([1, 1, 4.9]);

translate([20, 1, 0]) cube([1, 1, 4.0425697278911565]);

translate([21, 1, 0]) cube([1, 1, 4.7]);

translate([22, 1, 0]) cube([1, 1, 4.5]);

translate([23, 1, 0]) cube([1, 1, 4.4]);

translate([24, 1, 0]) cube([1, 1, 4.2]);

translate([25, 1, 0]) cube([1, 1, 4.0]);

translate([26, 1, 0]) cube([1, 1, 3.8]);

translate([27, 1, 0]) cube([1, 1, 3.7]);

translate([28, 1, 0]) cube([1, 1, 3.9]);

translate([29, 1, 0]) cube([1, 1, 4.0]);

translate([30, 1, 0]) cube([1, 1, 4.2]);

translate([31, 1, 0]) cube([1, 1, 4.3]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

translate([2, 2, 0]) cube([1, 1, 5.4]);

translate([3, 2, 0]) cube([1, 1, 5.1]);

translate([4, 2, 0]) cube([1, 1, 4.8]);

translate([5, 2, 0]) cube([1, 1, 4.5]);

translate([6, 2, 0]) cube([1, 1, 4.4]);

translate([7, 2, 0]) cube([1, 1, 4.4]);

translate([8, 2, 0]) cube([1, 1, 4.3]);

translate([9, 2, 0]) cube([1, 1, 4.2]);

translate([10, 2, 0]) cube([1, 1, 4.195526917820586]);

translate([11, 2, 0]) cube([1, 1, 4.19887594638617]);

translate([12, 2, 0]) cube([1, 1, 4.195847189342865]);

translate([13, 2, 0]) cube([1, 1, 4.189156679709898]);

translate([14, 2, 0]) cube([1, 1, 4.197490583109064]);

translate([15, 2, 0]) cube([1, 1, 4.197252189581841]);

translate([16, 2, 0]) cube([1, 1, 4.2]);

translate([17, 2, 0]) cube([1, 1, 4.3]);

translate([18, 2, 0]) cube([1, 1, 4.4]);

translate([19, 2, 0]) cube([1, 1, 4.5]);

translate([20, 2, 0]) cube([1, 1, 4.4]);

translate([21, 2, 0]) cube([1, 1, 4.3]);

translate([22, 2, 0]) cube([1, 1, 4.2]);

translate([23, 2, 0]) cube([1, 1, 4.0]);

translate([24, 2, 0]) cube([1, 1, 4.0]);

translate([25, 2, 0]) cube([1, 1, 3.9]);

translate([26, 2, 0]) cube([1, 1, 3.6611941542746433]);

translate([27, 2, 0]) cube([1, 1, 3.6666238382539764]);

translate([28, 2, 0]) cube([1, 1, 3.6655072290423583]);

translate([29, 2, 0]) cube([1, 1, 3.8]);

translate([30, 2, 0]) cube([1, 1, 3.9]);

translate([31, 2, 0]) cube([1, 1, 3.8]);

translate([0, 3, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

translate([4, 3, 0]) cube([1, 1, 5.4]);

translate([5, 3, 0]) cube([1, 1, 5.1]);

translate([6, 3, 0]) cube([1, 1, 5.0]);

translate([7, 3, 0]) cube([1, 1, 4.9]);

translate([8, 3, 0]) cube([1, 1, 4.7]);

translate([9, 3, 0]) cube([1, 1, 4.4]);

translate([10, 3, 0]) cube([1, 1, 4.187283141493489]);

translate([11, 3, 0]) cube([1, 1, 4.190965301936257]);

translate([12, 3, 0]) cube([1, 1, 4.2]);

translate([13, 3, 0]) cube([1, 1, 4.3]);

translate([14, 3, 0]) cube([1, 1, 4.3]);

translate([15, 3, 0]) cube([1, 1, 4.2]);

translate([16, 3, 0]) cube([1, 1, 4.3]);

translate([17, 3, 0]) cube([1, 1, 4.4]);

translate([18, 3, 0]) cube([1, 1, 4.4]);

translate([19, 3, 0]) cube([1, 1, 4.3]);

translate([20, 3, 0]) cube([1, 1, 4.2]);

translate([21, 3, 0]) cube([1, 1, 4.1]);

translate([22, 3, 0]) cube([1, 1, 3.8]);

translate([23, 3, 0]) cube([1, 1, 3.6543676724693457]);

translate([24, 3, 0]) cube([1, 1, 3.661859118797079]);

translate([25, 3, 0]) cube([1, 1, 3.6684541776452724]);

translate([26, 3, 0]) cube([1, 1, 3.6754508824903387]);

translate([27, 3, 0]) cube([1, 1, 3.679399533764767]);

translate([28, 3, 0]) cube([1, 1, 3.67563329375044]);

translate([29, 3, 0]) cube([1, 1, 3.6713714955861825]);

translate([30, 3, 0]) cube([1, 1, 3.7]);

translate([31, 3, 0]) cube([1, 1, 3.6644473285194707]);

translate([0, 4, 0]) cube([1, 1, 7.2]);

translate([1, 4, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.4]);

translate([7, 4, 0]) cube([1, 1, 5.3]);

translate([8, 4, 0]) cube([1, 1, 5.0]);

translate([9, 4, 0]) cube([1, 1, 4.6]);

translate([10, 4, 0]) cube([1, 1, 4.4]);

translate([11, 4, 0]) cube([1, 1, 4.4]);

translate([12, 4, 0]) cube([1, 1, 4.6]);

translate([13, 4, 0]) cube([1, 1, 4.8]);

translate([14, 4, 0]) cube([1, 1, 4.8]);

translate([15, 4, 0]) cube([1, 1, 4.7]);

translate([16, 4, 0]) cube([1, 1, 4.7]);

translate([17, 4, 0]) cube([1, 1, 4.7]);

translate([18, 4, 0]) cube([1, 1, 4.4]);

translate([19, 4, 0]) cube([1, 1, 4.1]);

translate([20, 4, 0]) cube([1, 1, 4.0]);

translate([21, 4, 0]) cube([1, 1, 3.9]);

translate([22, 4, 0]) cube([1, 1, 3.6595309769894606]);

translate([23, 4, 0]) cube([1, 1, 3.671817873542937]);

translate([24, 4, 0]) cube([1, 1, 3.675958648294133]);

translate([25, 4, 0]) cube([1, 1, 3.6757307111877084]);

translate([26, 4, 0]) cube([1, 1, 3.678673101026193]);

translate([27, 4, 0]) cube([1, 1, 3.676539085030488]);

translate([28, 4, 0]) cube([1, 1, 3.682513859309445]);

translate([29, 4, 0]) cube([1, 1, 3.685992671628877]);

translate([30, 4, 0]) cube([1, 1, 3.684504116981735]);

translate([31, 4, 0]) cube([1, 1, 3.6777085731497974]);

translate([0, 5, 0]) cube([1, 1, 7.4]);

translate([1, 5, 0]) cube([1, 1, 6.9]);

translate([2, 5, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

translate([8, 5, 0]) cube([1, 1, 5.3]);

translate([9, 5, 0]) cube([1, 1, 4.9]);

translate([10, 5, 0]) cube([1, 1, 4.7]);

translate([11, 5, 0]) cube([1, 1, 4.9]);

translate([12, 5, 0]) cube([1, 1, 5.1]);

translate([13, 5, 0]) cube([1, 1, 4.372472617782213]);

translate([14, 5, 0]) cube([1, 1, 5.3]);

translate([15, 5, 0]) cube([1, 1, 5.1]);

translate([16, 5, 0]) cube([1, 1, 5.1]);

translate([17, 5, 0]) cube([1, 1, 4.9]);

translate([18, 5, 0]) cube([1, 1, 3.7766738841534297]);

translate([19, 5, 0]) cube([1, 1, 4.0]);

translate([20, 5, 0]) cube([1, 1, 3.8]);

translate([21, 5, 0]) cube([1, 1, 3.7]);

translate([22, 5, 0]) cube([1, 1, 3.6732629415831752]);

translate([23, 5, 0]) cube([1, 1, 3.678362919733279]);

translate([24, 5, 0]) cube([1, 1, 3.677131192805492]);

translate([25, 5, 0]) cube([1, 1, 3.6729374783529094]);

translate([26, 5, 0]) cube([1, 1, 3.6721738029079813]);

translate([27, 5, 0]) cube([1, 1, 3.6768146893668883]);

translate([28, 5, 0]) cube([1, 1, 3.675397225555293]);

translate([29, 5, 0]) cube([1, 1, 3.6786679940396403]);

translate([30, 5, 0]) cube([1, 1, 3.681204817775934]);

translate([31, 5, 0]) cube([1, 1, 3.67782790213188]);

translate([0, 6, 0]) cube([1, 1, 7.7]);

translate([1, 6, 0]) cube([1, 1, 7.2]);

translate([2, 6, 0]) cube([1, 1, 7.0]);

translate([3, 6, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([4, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.2]);

translate([10, 6, 0]) cube([1, 1, 5.1]);

translate([11, 6, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([16, 6, 0]) cube([1, 1, 5.3]);

translate([17, 6, 0]) cube([1, 1, 5.0]);

translate([18, 6, 0]) cube([1, 1, 4.5]);

translate([19, 6, 0]) cube([1, 1, 4.0]);

translate([20, 6, 0]) cube([1, 1, 3.7]);

translate([21, 6, 0]) cube([1, 1, 3.665317842560327]);

translate([22, 6, 0]) cube([1, 1, 3.674647827610095]);

translate([23, 6, 0]) cube([1, 1, 3.6721413808723575]);

translate([24, 6, 0]) cube([1, 1, 3.675438595543198]);

translate([25, 6, 0]) cube([1, 1, 3.7]);

translate([26, 6, 0]) cube([1, 1, 3.8]);

translate([27, 6, 0]) cube([1, 1, 3.9]);

translate([28, 6, 0]) cube([1, 1, 3.8]);

translate([29, 6, 0]) cube([1, 1, 3.8]);

translate([30, 6, 0]) cube([1, 1, 3.8]);

translate([31, 6, 0]) cube([1, 1, 3.7]);

translate([0, 7, 0]) cube([1, 1, 8.0]);

translate([1, 7, 0]) cube([1, 1, 7.5]);

translate([2, 7, 0]) cube([1, 1, 7.3]);

translate([3, 7, 0]) cube([1, 1, 7.0]);

translate([4, 7, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([5, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([16, 7, 0]) cube([1, 1, 5.4]);

translate([17, 7, 0]) cube([1, 1, 4.9]);

translate([18, 7, 0]) cube([1, 1, 4.6]);

translate([19, 7, 0]) cube([1, 1, 4.2]);

translate([20, 7, 0]) cube([1, 1, 3.8]);

translate([21, 7, 0]) cube([1, 1, 3.7]);

translate([22, 7, 0]) cube([1, 1, 3.8]);

translate([23, 7, 0]) cube([1, 1, 4.0]);

translate([24, 7, 0]) cube([1, 1, 4.0]);

translate([25, 7, 0]) cube([1, 1, 4.1]);

translate([26, 7, 0]) cube([1, 1, 4.3]);

translate([27, 7, 0]) cube([1, 1, 4.4]);

translate([28, 7, 0]) cube([1, 1, 4.3]);

translate([29, 7, 0]) cube([1, 1, 4.2]);

translate([30, 7, 0]) cube([1, 1, 4.1]);

translate([31, 7, 0]) cube([1, 1, 4.0]);

translate([0, 8, 0]) cube([1, 1, 7.9]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 7.3]);

translate([3, 8, 0]) cube([1, 1, 7.0]);

translate([4, 8, 0]) cube([1, 1, 6.8]);

translate([5, 8, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([6, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([16, 8, 0]) cube([1, 1, 5.4]);

translate([17, 8, 0]) cube([1, 1, 5.0]);

translate([18, 8, 0]) cube([1, 1, 4.7]);

translate([19, 8, 0]) cube([1, 1, 4.4]);

translate([20, 8, 0]) cube([1, 1, 4.1]);

translate([21, 8, 0]) cube([1, 1, 4.0]);

translate([22, 8, 0]) cube([1, 1, 4.2]);

translate([23, 8, 0]) cube([1, 1, 4.5]);

translate([24, 8, 0]) cube([1, 1, 4.6]);

translate([25, 8, 0]) cube([1, 1, 4.6]);

translate([26, 8, 0]) cube([1, 1, 4.6]);

translate([27, 8, 0]) cube([1, 1, 4.7]);

translate([28, 8, 0]) cube([1, 1, 4.6]);

translate([29, 8, 0]) cube([1, 1, 4.5]);

translate([30, 8, 0]) cube([1, 1, 4.5]);

translate([31, 8, 0]) cube([1, 1, 4.4]);

translate([0, 9, 0]) cube([1, 1, 7.9]);

translate([1, 9, 0]) cube([1, 1, 7.4]);

translate([2, 9, 0]) cube([1, 1, 7.1]);

translate([3, 9, 0]) cube([1, 1, 6.9]);

translate([4, 9, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([5, 9, 0]) cube([1, 1, 6]);

translate([6, 9, 0]) cube([1, 1, 6.6]);

translate([7, 9, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 5.1]);

translate([18, 9, 0]) cube([1, 1, 4.9]);

translate([19, 9, 0]) cube([1, 1, 4.7]);

translate([20, 9, 0]) cube([1, 1, 4.5]);

translate([21, 9, 0]) cube([1, 1, 4.4]);

translate([22, 9, 0]) cube([1, 1, 4.7]);

translate([23, 9, 0]) cube([1, 1, 5.0]);

translate([24, 9, 0]) cube([1, 1, 5.1]);

translate([25, 9, 0]) cube([1, 1, 5.1]);

translate([26, 9, 0]) cube([1, 1, 5.0]);

translate([27, 9, 0]) cube([1, 1, 4.9]);

translate([28, 9, 0]) cube([1, 1, 4.8]);

translate([29, 9, 0]) cube([1, 1, 4.8]);

translate([30, 9, 0]) cube([1, 1, 4.9]);

translate([31, 9, 0]) cube([1, 1, 4.9]);

translate([0, 10, 0]) cube([1, 1, 8.0]);

translate([1, 10, 0]) cube([1, 1, 7.5]);

translate([2, 10, 0]) cube([1, 1, 7.1]);

translate([3, 10, 0]) cube([1, 1, 6.7]);

translate([4, 10, 0]) cube([1, 1, 6.6]);

translate([5, 10, 0]) cube([1, 1, 6.6]);

translate([6, 10, 0]) cube([1, 1, 6.8]);

translate([7, 10, 0]) cube([1, 1, 6.9]);

translate([8, 10, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 5.1]);

translate([18, 10, 0]) cube([1, 1, 4.9]);

translate([19, 10, 0]) cube([1, 1, 4.8]);

translate([20, 10, 0]) cube([1, 1, 4.7]);

translate([21, 10, 0]) cube([1, 1, 4.7]);

translate([22, 10, 0]) cube([1, 1, 5.1]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 10, 0]) cube([1, 1, 6]);

translate([26, 10, 0]) cube([1, 1, 5.4]);

translate([27, 10, 0]) cube([1, 1, 5.2]);

translate([28, 10, 0]) cube([1, 1, 5.1]);

translate([29, 10, 0]) cube([1, 1, 5.1]);

translate([30, 10, 0]) cube([1, 1, 5.3]);

translate([31, 10, 0]) cube([1, 1, 5.4]);

translate([0, 11, 0]) cube([1, 1, 8.2]);

translate([1, 11, 0]) cube([1, 1, 7.7]);

translate([2, 11, 0]) cube([1, 1, 7.2]);

translate([3, 11, 0]) cube([1, 1, 6.9]);

translate([4, 11, 0]) cube([1, 1, 6.9]);

translate([5, 11, 0]) cube([1, 1, 7.0]);

translate([6, 11, 0]) cube([1, 1, 7.2]);

translate([7, 11, 0]) cube([1, 1, 7.1]);

translate([8, 11, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

translate([17, 11, 0]) cube([1, 1, 5.1]);

translate([18, 11, 0]) cube([1, 1, 5.0]);

translate([19, 11, 0]) cube([1, 1, 4.9]);

translate([20, 11, 0]) cube([1, 1, 4.8]);

translate([21, 11, 0]) cube([1, 1, 4.8]);

translate([22, 11, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 8.2]);

translate([1, 12, 0]) cube([1, 1, 7.7]);

translate([2, 12, 0]) cube([1, 1, 7.3]);

translate([3, 12, 0]) cube([1, 1, 7.2]);

translate([4, 12, 0]) cube([1, 1, 7.3]);

translate([5, 12, 0]) cube([1, 1, 7.4]);

translate([6, 12, 0]) cube([1, 1, 7.5]);

translate([7, 12, 0]) cube([1, 1, 7.2]);

translate([8, 12, 0]) cube([1, 1, 6.9]);

translate([9, 12, 0]) cube([1, 1, 6.6]);

translate([10, 12, 0]) cube([1, 1, 6.6]);

translate([11, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

translate([17, 12, 0]) cube([1, 1, 5.3]);

translate([18, 12, 0]) cube([1, 1, 5.1]);

translate([19, 12, 0]) cube([1, 1, 5.0]);

translate([20, 12, 0]) cube([1, 1, 4.9]);

translate([21, 12, 0]) cube([1, 1, 5.0]);

translate([22, 12, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 8.1]);

translate([1, 13, 0]) cube([1, 1, 7.7]);

translate([2, 13, 0]) cube([1, 1, 7.5]);

translate([3, 13, 0]) cube([1, 1, 7.5]);

translate([4, 13, 0]) cube([1, 1, 7.6]);

translate([5, 13, 0]) cube([1, 1, 7.6]);

translate([6, 13, 0]) cube([1, 1, 7.6]);

translate([7, 13, 0]) cube([1, 1, 7.3]);

translate([8, 13, 0]) cube([1, 1, 7.0]);

translate([9, 13, 0]) cube([1, 1, 6.8]);

translate([10, 13, 0]) cube([1, 1, 6.8]);

translate([11, 13, 0]) cube([1, 1, 6.8]);

translate([12, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

translate([18, 13, 0]) cube([1, 1, 5.4]);

translate([19, 13, 0]) cube([1, 1, 5.3]);

translate([20, 13, 0]) cube([1, 1, 5.2]);

translate([21, 13, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 13, 0]) cube([1, 1, 6]);

translate([27, 13, 0]) cube([1, 1, 6.6]);

translate([28, 13, 0]) cube([1, 1, 6.7]);

translate([29, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([30, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 8.2]);

translate([1, 14, 0]) cube([1, 1, 7.8]);

translate([2, 14, 0]) cube([1, 1, 7.7]);

translate([3, 14, 0]) cube([1, 1, 7.6]);

translate([4, 14, 0]) cube([1, 1, 7.6]);

translate([5, 14, 0]) cube([1, 1, 7.5]);

translate([6, 14, 0]) cube([1, 1, 7.4]);

translate([7, 14, 0]) cube([1, 1, 7.2]);

translate([8, 14, 0]) cube([1, 1, 7.0]);

translate([9, 14, 0]) cube([1, 1, 7.0]);

translate([10, 14, 0]) cube([1, 1, 7.0]);

translate([11, 14, 0]) cube([1, 1, 6.8]);

translate([12, 14, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 14, 0]) cube([1, 1, 6]);

translate([27, 14, 0]) cube([1, 1, 6.9]);

translate([28, 14, 0]) cube([1, 1, 7.0]);

translate([29, 14, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([30, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 8.1]);

translate([1, 15, 0]) cube([1, 1, 7.8]);

translate([2, 15, 0]) cube([1, 1, 7.7]);

translate([3, 15, 0]) cube([1, 1, 7.5]);

translate([4, 15, 0]) cube([1, 1, 7.3]);

translate([5, 15, 0]) cube([1, 1, 7.1]);

translate([6, 15, 0]) cube([1, 1, 6.9]);

translate([7, 15, 0]) cube([1, 1, 6.8]);

translate([8, 15, 0]) cube([1, 1, 6.9]);

translate([9, 15, 0]) cube([1, 1, 6.9]);

translate([10, 15, 0]) cube([1, 1, 6.9]);

translate([11, 15, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

translate([15, 15, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 15, 0]) cube([1, 1, 6]);

translate([27, 15, 0]) cube([1, 1, 6.8]);

translate([28, 15, 0]) cube([1, 1, 6.9]);

translate([29, 15, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([30, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 15, 0]) cube([1, 1, 6]);

translate([0, 16, 0]) cube([1, 1, 7.7]);

translate([1, 16, 0]) cube([1, 1, 7.4]);

translate([2, 16, 0]) cube([1, 1, 7.3]);

translate([3, 16, 0]) cube([1, 1, 7.2]);

translate([4, 16, 0]) cube([1, 1, 7.0]);

translate([5, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([6, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 16, 0]) cube([1, 1, 6]);

translate([8, 16, 0]) cube([1, 1, 6.6]);

translate([9, 16, 0]) cube([1, 1, 6.7]);

translate([10, 16, 0]) cube([1, 1, 6.8]);

translate([11, 16, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

translate([15, 16, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 16, 0]) cube([1, 1, 6]);

translate([28, 16, 0]) cube([1, 1, 6.7]);

translate([29, 16, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([30, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 16, 0]) cube([1, 1, 6]);

translate([0, 17, 0]) cube([1, 1, 7.1]);

translate([1, 17, 0]) cube([1, 1, 6.9]);

translate([2, 17, 0]) cube([1, 1, 6.9]);

translate([3, 17, 0]) cube([1, 1, 6.9]);

translate([4, 17, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 17, 0]) cube([1, 1, 6]);

translate([11, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

translate([13, 17, 0]) cube([1, 1, 6.6]);

translate([14, 17, 0]) cube([1, 1, 6.6]);

translate([15, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

translate([19, 17, 0]) cube([1, 1, 5.4]);

translate([20, 17, 0]) cube([1, 1, 5.4]);

translate([21, 17, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([22, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 17, 0]) cube([1, 1, 6]);

translate([0, 18, 0]) cube([1, 1, 6.8]);

translate([1, 18, 0]) cube([1, 1, 6.6]);

translate([2, 18, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

translate([12, 18, 0]) cube([1, 1, 6.6]);

translate([13, 18, 0]) cube([1, 1, 6.8]);

translate([14, 18, 0]) cube([1, 1, 6.9]);

translate([15, 18, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

translate([19, 18, 0]) cube([1, 1, 5.4]);

translate([20, 18, 0]) cube([1, 1, 5.2]);

translate([21, 18, 0]) cube([1, 1, 5.2]);

translate([22, 18, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([23, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 6.8]);

translate([1, 19, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

translate([7, 19, 0]) cube([1, 1, 5.4]);

translate([8, 19, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([9, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

translate([13, 19, 0]) cube([1, 1, 6.9]);

translate([14, 19, 0]) cube([1, 1, 7.1]);

translate([15, 19, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([16, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);

translate([20, 19, 0]) cube([1, 1, 5.4]);

translate([21, 19, 0]) cube([1, 1, 5.2]);

translate([22, 19, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([23, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 19, 0]) cube([1, 1, 6]);

translate([0, 20, 0]) cube([1, 1, 7.0]);

translate([1, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([2, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

translate([6, 20, 0]) cube([1, 1, 5.4]);

translate([7, 20, 0]) cube([1, 1, 5.2]);

translate([8, 20, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([9, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

translate([13, 20, 0]) cube([1, 1, 6.8]);

translate([14, 20, 0]) cube([1, 1, 7.0]);

translate([15, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

translate([21, 20, 0]) cube([1, 1, 5.3]);

translate([22, 20, 0]) cube([1, 1, 5.3]);

translate([23, 20, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([24, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 20, 0]) cube([1, 1, 6]);

translate([31, 20, 0]) cube([1, 1, 5.3]);

translate([0, 21, 0]) cube([1, 1, 7.1]);

translate([1, 21, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

translate([4, 21, 0]) cube([1, 1, 5.4]);

translate([5, 21, 0]) cube([1, 1, 5.3]);

translate([6, 21, 0]) cube([1, 1, 5.3]);

translate([7, 21, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([8, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

translate([13, 21, 0]) cube([1, 1, 6.7]);

translate([14, 21, 0]) cube([1, 1, 6.9]);

translate([15, 21, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

translate([22, 21, 0]) cube([1, 1, 5.3]);

translate([23, 21, 0]) cube([1, 1, 5.3]);

translate([24, 21, 0]) cube([1, 1, 5.3]);

translate([25, 21, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([26, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 21, 0]) cube([1, 1, 6]);

translate([30, 21, 0]) cube([1, 1, 5.4]);

translate([31, 21, 0]) cube([1, 1, 5.1]);

translate([0, 22, 0]) cube([1, 1, 7.1]);

translate([1, 22, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

translate([4, 22, 0]) cube([1, 1, 5.2]);

translate([5, 22, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

translate([13, 22, 0]) cube([1, 1, 6.7]);

translate([14, 22, 0]) cube([1, 1, 6.8]);

translate([15, 22, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

translate([24, 22, 0]) cube([1, 1, 5.4]);

translate([25, 22, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([26, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 22, 0]) cube([1, 1, 6]);

translate([30, 22, 0]) cube([1, 1, 5.2]);

translate([31, 22, 0]) cube([1, 1, 4.9]);

translate([0, 23, 0]) cube([1, 1, 6.9]);

translate([1, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 23, 0]) cube([1, 1, 6]);

translate([4, 23, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([5, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 23, 0]) cube([1, 1, 6]);

translate([12, 23, 0]) cube([1, 1, 6.7]);

translate([13, 23, 0]) cube([1, 1, 6.9]);

translate([14, 23, 0]) cube([1, 1, 7.0]);

translate([15, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([16, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 23, 0]) cube([1, 1, 6]);

translate([29, 23, 0]) cube([1, 1, 5.3]);

translate([30, 23, 0]) cube([1, 1, 5.0]);

translate([31, 23, 0]) cube([1, 1, 4.8]);

translate([0, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 24, 0]) cube([1, 1, 6]);

translate([11, 24, 0]) cube([1, 1, 6.7]);

translate([12, 24, 0]) cube([1, 1, 7.0]);

translate([13, 24, 0]) cube([1, 1, 7.1]);

translate([14, 24, 0]) cube([1, 1, 7.1]);

translate([15, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 24, 0]) cube([1, 1, 6]);

translate([27, 24, 0]) cube([1, 1, 5.4]);

translate([28, 24, 0]) cube([1, 1, 5.3]);

translate([29, 24, 0]) cube([1, 1, 5.0]);

translate([30, 24, 0]) cube([1, 1, 4.8]);

translate([31, 24, 0]) cube([1, 1, 4.6]);

color([0,1,0])
translate([0, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 25, 0]) cube([1, 1, 6]);

translate([11, 25, 0]) cube([1, 1, 6.9]);

translate([12, 25, 0]) cube([1, 1, 7.2]);

translate([13, 25, 0]) cube([1, 1, 7.2]);

translate([14, 25, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([15, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 25, 0]) cube([1, 1, 6]);

translate([25, 25, 0]) cube([1, 1, 5.4]);

translate([26, 25, 0]) cube([1, 1, 5.4]);

translate([27, 25, 0]) cube([1, 1, 5.4]);

translate([28, 25, 0]) cube([1, 1, 5.2]);

translate([29, 25, 0]) cube([1, 1, 5.0]);

translate([30, 25, 0]) cube([1, 1, 4.7]);

translate([31, 25, 0]) cube([1, 1, 4.5]);

color([0,1,0])
translate([0, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 26, 0]) cube([1, 1, 6]);

translate([10, 26, 0]) cube([1, 1, 6.7]);

translate([11, 26, 0]) cube([1, 1, 6.9]);

translate([12, 26, 0]) cube([1, 1, 7.0]);

translate([13, 26, 0]) cube([1, 1, 6.9]);

translate([14, 26, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([15, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 26, 0]) cube([1, 1, 6]);

translate([25, 26, 0]) cube([1, 1, 5.4]);

translate([26, 26, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([27, 26, 0]) cube([1, 1, 6]);

translate([28, 26, 0]) cube([1, 1, 5.4]);

translate([29, 26, 0]) cube([1, 1, 5.3]);

translate([30, 26, 0]) cube([1, 1, 5.0]);

translate([31, 26, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 27, 0]) cube([1, 1, 6]);

translate([9, 27, 0]) cube([1, 1, 6.6]);

translate([10, 27, 0]) cube([1, 1, 6.7]);

translate([11, 27, 0]) cube([1, 1, 6.7]);

translate([12, 27, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([13, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 27, 0]) cube([1, 1, 6]);

translate([31, 27, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([0, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 28, 0]) cube([1, 1, 6]);

translate([27, 28, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 29, 0]) cube([1, 1, 6]);

translate([26, 29, 0]) cube([1, 1, 5.4]);

translate([27, 29, 0]) cube([1, 1, 5.3]);

translate([28, 29, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([29, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 30, 0]) cube([1, 1, 6]);

translate([1, 30, 0]) cube([1, 1, 5.4]);

translate([2, 30, 0]) cube([1, 1, 5.4]);

translate([3, 30, 0]) cube([1, 1, 5.4]);

translate([4, 30, 0]) cube([1, 1, 5.3]);

translate([5, 30, 0]) cube([1, 1, 5.2]);

translate([6, 30, 0]) cube([1, 1, 5.1]);

translate([7, 30, 0]) cube([1, 1, 5.3]);

translate([8, 30, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([9, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 30, 0]) cube([1, 1, 6]);

translate([11, 30, 0]) cube([1, 1, 5.3]);

translate([12, 30, 0]) cube([1, 1, 5.2]);

translate([13, 30, 0]) cube([1, 1, 5.3]);

translate([14, 30, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([15, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 30, 0]) cube([1, 1, 6]);

translate([22, 30, 0]) cube([1, 1, 5.3]);

translate([23, 30, 0]) cube([1, 1, 5.3]);

translate([24, 30, 0]) cube([1, 1, 5.4]);

translate([25, 30, 0]) cube([1, 1, 5.4]);

translate([26, 30, 0]) cube([1, 1, 5.3]);

translate([27, 30, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([28, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 30, 0]) cube([1, 1, 6]);

translate([0, 31, 0]) cube([1, 1, 5.3]);

translate([1, 31, 0]) cube([1, 1, 5.2]);

translate([2, 31, 0]) cube([1, 1, 5.2]);

translate([3, 31, 0]) cube([1, 1, 5.3]);

translate([4, 31, 0]) cube([1, 1, 5.2]);

translate([5, 31, 0]) cube([1, 1, 5.0]);

translate([6, 31, 0]) cube([1, 1, 4.9]);

translate([7, 31, 0]) cube([1, 1, 5.0]);

translate([8, 31, 0]) cube([1, 1, 5.1]);

translate([9, 31, 0]) cube([1, 1, 5.1]);

translate([10, 31, 0]) cube([1, 1, 5.0]);

translate([11, 31, 0]) cube([1, 1, 4.8]);

translate([12, 31, 0]) cube([1, 1, 4.7]);

translate([13, 31, 0]) cube([1, 1, 4.8]);

translate([14, 31, 0]) cube([1, 1, 5.1]);

translate([15, 31, 0]) cube([1, 1, 5.3]);

translate([16, 31, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([17, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 31, 0]) cube([1, 1, 6]);

translate([22, 31, 0]) cube([1, 1, 5.2]);

translate([23, 31, 0]) cube([1, 1, 5.1]);

translate([24, 31, 0]) cube([1, 1, 5.2]);

translate([25, 31, 0]) cube([1, 1, 5.2]);

translate([26, 31, 0]) cube([1, 1, 5.3]);

translate([27, 31, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 31, 0]) cube([1, 1, 6]);
