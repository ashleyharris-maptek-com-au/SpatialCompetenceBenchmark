
hull() {
    translate([1.05, 1.05, 4.96875]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9500000000000002, 1.9500000000000002, 4.40625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.05, 2.05, 4.34375]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.95, 2.95, 3.78125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0500000000000003, 3.0500000000000003, 3.71875]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.95, 3.95, 3.15625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.05, 4.05, 3.09375]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.95, 4.95, 2.53125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.05, 5.05, 2.46875]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.95, 5.95, 1.90625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.050000000000001, 6.050000000000001, 1.84375]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.95, 6.95, 1.28125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.05, 7.05, 1.21875]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.95, 7.95, 0.65625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.05, 8.05, 0.59375]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.95, 8.95, 0.03125]) cube([0.4, 0.4, 0.1], center=true);
}

