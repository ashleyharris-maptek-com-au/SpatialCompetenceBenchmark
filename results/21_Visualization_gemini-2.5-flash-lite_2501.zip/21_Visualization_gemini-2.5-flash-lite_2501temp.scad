
hull() {
    translate([150.0, 150.0, 249.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 249.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 249.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 249.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 249.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 249.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 249.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 249.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 249.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 249.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 249.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 249.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 249.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 249.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 249.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 249.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 249.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 249.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 249.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 249.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 248.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 248.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 248.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 248.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 248.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 248.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 248.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 248.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 248.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 248.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 248.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 248.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 248.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 248.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 248.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 248.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 248.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 248.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 248.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 248.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 247.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 247.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 247.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 247.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 247.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 247.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 247.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 247.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 247.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 247.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 247.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 247.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 247.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 247.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 247.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 247.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 247.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 247.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 247.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 247.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 246.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 246.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 246.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 246.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 246.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 246.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 246.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 246.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 246.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 246.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 246.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 246.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 246.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 246.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 246.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 246.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 246.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 246.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 246.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 246.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 245.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 245.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 245.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 245.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 245.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 245.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 245.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 245.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 245.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 245.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 245.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 245.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 245.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 245.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 245.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 245.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 245.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 245.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 245.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 245.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 244.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 244.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 244.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 244.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 244.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 244.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 244.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 244.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 244.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 244.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 244.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 244.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 244.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 244.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 244.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 244.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 244.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 244.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 244.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 244.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 243.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 243.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 243.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 243.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 243.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 243.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 243.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 243.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 243.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 243.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 243.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 243.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 243.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 243.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 243.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 243.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 243.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 243.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 243.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 243.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 242.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 242.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 242.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 242.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 242.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 242.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 242.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 242.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 242.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 242.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 242.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 242.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 242.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 242.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 242.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 242.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 242.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 242.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 242.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 242.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 241.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 241.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 241.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 241.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 241.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 241.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 241.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 241.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 241.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 241.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 241.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 241.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 241.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 241.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 241.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 241.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 241.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 241.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 241.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 241.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 240.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 240.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 240.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 240.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 240.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 240.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 240.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 240.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 240.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 240.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 240.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 240.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 240.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 240.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 240.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 240.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 240.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 240.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 240.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 240.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 239.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 239.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 239.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 239.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 239.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 239.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 239.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 239.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 239.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 239.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 239.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 239.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 239.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 239.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 239.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 239.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 239.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 239.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 239.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 239.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 238.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 238.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 238.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 238.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 238.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 238.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 238.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 238.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 238.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 238.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 238.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 238.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 238.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 238.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 238.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 238.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 238.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 238.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 238.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 238.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 237.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 237.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 237.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 237.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 237.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 237.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 237.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 237.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 237.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 237.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 237.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 237.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 237.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 237.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 237.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 237.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 237.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 237.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 237.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 237.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 236.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 236.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 236.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 236.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 236.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 236.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 236.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 236.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 236.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 236.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 236.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 236.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 236.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 236.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 236.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 236.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 236.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 236.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 236.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 236.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 235.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 235.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 235.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 235.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 235.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 235.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 235.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 235.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 235.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 235.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 235.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 235.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 235.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 235.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 235.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 235.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 235.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 235.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 235.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 235.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 234.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 234.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 234.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 234.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 234.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 234.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 234.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 234.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 234.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 234.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 234.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 234.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 234.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 234.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 234.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 234.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 234.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 234.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 234.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 234.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 233.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 233.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 233.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 233.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 233.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 233.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 233.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 233.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 233.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 233.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 233.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 233.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 233.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 233.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 233.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 233.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 233.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 233.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 233.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 233.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 232.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 232.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 232.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 232.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 232.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 232.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 232.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 232.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 232.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 232.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 232.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 232.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 232.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 232.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 232.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 232.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 232.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 232.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 232.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 232.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 231.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 231.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 231.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 231.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 231.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 231.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 231.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 231.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 231.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 231.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 231.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 231.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 231.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 231.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 231.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 231.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 231.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 231.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 231.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 231.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 230.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 230.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 230.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 230.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 230.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 230.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 230.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 230.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 230.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 230.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 230.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 230.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 230.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 230.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 230.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 230.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 230.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 230.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 230.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 230.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 229.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 229.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 229.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 229.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 229.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 229.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 229.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 229.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 229.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 229.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 229.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 229.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 229.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 229.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 229.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 229.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 229.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 229.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 229.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 229.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 228.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 228.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 228.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 228.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 228.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 228.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 228.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 228.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 228.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 228.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 228.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 228.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 228.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 228.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 228.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 228.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 228.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 228.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 228.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 228.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 227.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 227.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 227.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 227.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 227.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 227.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 227.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 227.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 227.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 227.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 227.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 227.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 227.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 227.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 227.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 227.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 227.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 227.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 227.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 227.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 226.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 226.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 226.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 226.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 226.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 226.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 226.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 226.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 226.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 226.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 226.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 226.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 226.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 226.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 226.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 226.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 226.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 226.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 226.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 226.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 225.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 225.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 225.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 225.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 225.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 225.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 225.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 225.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 225.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 225.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 225.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 225.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 225.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 225.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 225.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 225.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 225.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 225.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 225.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 225.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 224.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 224.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 224.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 224.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 224.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 224.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 224.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 224.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 224.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 224.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 224.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 224.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 224.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 224.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 224.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 224.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 224.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 224.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 224.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 224.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 223.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 223.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 223.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 223.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 223.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 223.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 223.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 223.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 223.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 223.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 223.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 223.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 223.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 223.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 223.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 223.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 223.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 223.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 223.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 223.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 222.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 222.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 222.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 222.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 222.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 222.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 222.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 222.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 222.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 222.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 222.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 222.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 222.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 222.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 222.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 222.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 222.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 222.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 222.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 222.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 221.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 221.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 221.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 221.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 221.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 221.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 221.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 221.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 221.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 221.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 221.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 221.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 221.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 221.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 221.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 221.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 221.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 221.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 221.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 221.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 220.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 220.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 220.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 220.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 220.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 220.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 220.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 220.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 220.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 220.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 220.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 220.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 220.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 220.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 220.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 220.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 220.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 220.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 220.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 220.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 219.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 219.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 219.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 219.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 219.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 219.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 219.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 219.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 219.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 219.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 219.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 219.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 219.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 219.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 219.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 219.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 219.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 219.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 219.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 219.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 218.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 218.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 218.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 218.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 218.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 218.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 218.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 218.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 218.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 218.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 218.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 218.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 218.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 218.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 218.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 218.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 218.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 218.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 218.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 218.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 217.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 217.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 217.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 217.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 217.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 217.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 217.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 217.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 217.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 217.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 217.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 217.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 217.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 217.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 217.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 217.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 217.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 217.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 217.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 217.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 216.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 216.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 216.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 216.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 216.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 216.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 216.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 216.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 216.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 216.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 216.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 216.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 216.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 216.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 216.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 216.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 216.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 216.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 216.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 216.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 215.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 215.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 215.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 215.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 215.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 215.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 215.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 215.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 215.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 215.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 215.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 215.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 215.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 215.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 215.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 215.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 215.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 215.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 215.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 215.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 214.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 214.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 214.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 214.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 214.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 214.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 214.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 214.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 214.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 214.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 214.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 214.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 214.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 214.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 214.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 214.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 214.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 214.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 214.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 214.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 213.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 213.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 213.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 213.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 213.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 213.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 213.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 213.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 213.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 213.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 213.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 213.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 213.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 213.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 213.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 213.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 213.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 213.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 213.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 213.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 212.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 212.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 212.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 212.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 212.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 212.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 212.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 212.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 212.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 212.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 212.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 212.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 212.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 212.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 212.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 212.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 212.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 212.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 212.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 212.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 211.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 211.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 211.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 211.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 211.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 211.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 211.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 211.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 211.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 211.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 211.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 211.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 211.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 211.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 211.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 211.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 211.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 211.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 211.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 211.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 210.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 210.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 210.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 210.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 210.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 210.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 210.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 210.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 210.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 210.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 210.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 210.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 210.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 210.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 210.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 210.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 210.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 210.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 210.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 210.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 209.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 209.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 209.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 209.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 209.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 209.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 209.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 209.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 209.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 209.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 209.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 209.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 209.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 209.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 209.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 209.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 209.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 209.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 209.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 209.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 208.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 208.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 208.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 208.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 208.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 208.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 208.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 208.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 208.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 208.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 208.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 208.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 208.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 208.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 208.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 208.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 208.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 208.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 208.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 208.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 207.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 207.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 207.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 207.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 207.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 207.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 207.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 207.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 207.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 207.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 207.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 207.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 207.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 207.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 207.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 207.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 207.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 207.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 207.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 207.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 206.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 206.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 206.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 206.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 206.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 206.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 206.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 206.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 206.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 206.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 206.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 206.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 206.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 206.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 206.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 206.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 206.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 206.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 206.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 206.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 205.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 205.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 205.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 205.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 205.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 205.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 205.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 205.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 205.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 205.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 205.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 205.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 205.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 205.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 205.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 205.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 205.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 205.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 205.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 205.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 204.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 204.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 204.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 204.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 204.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 204.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 204.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 204.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 204.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 204.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 204.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 204.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 204.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 204.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 204.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 204.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 204.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 204.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 204.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 204.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 203.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 203.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 203.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 203.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 203.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 203.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 203.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 203.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 203.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 203.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 203.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 203.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 203.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 203.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 203.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 203.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 203.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 203.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 203.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 203.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 202.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 202.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 202.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 202.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 202.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 202.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 202.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 202.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 202.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 202.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 202.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 202.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 202.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 202.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 202.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 202.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 202.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 202.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 202.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 202.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 201.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 201.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 201.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 201.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 201.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 201.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 201.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 201.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 201.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 201.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 201.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 201.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 201.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 201.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 201.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 201.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 201.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 201.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 201.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 201.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 200.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 200.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 200.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 200.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 200.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 200.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 200.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 200.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 200.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 200.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 200.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 200.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 200.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 200.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 200.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 200.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 200.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 200.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 200.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 200.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 199.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 199.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 199.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 199.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 199.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 199.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 199.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 199.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 199.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 199.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 199.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 199.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 199.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 199.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 199.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 199.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 199.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 199.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 199.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 199.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 198.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 198.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 198.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 198.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 198.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 198.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 198.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 198.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 198.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 198.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 198.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 198.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 198.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 198.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 198.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 198.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 198.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 198.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 198.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 198.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 197.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 197.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 197.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 197.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 197.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 197.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 197.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 197.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 197.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 197.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 197.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 197.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 197.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 197.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 197.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 197.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 197.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 197.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 197.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 197.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 196.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 196.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 196.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 196.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 196.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 196.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 196.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 196.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 196.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 196.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 196.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 196.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 196.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 196.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 196.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 196.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 196.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 196.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 196.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 196.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 195.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 195.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 195.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 195.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 195.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 195.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 195.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 195.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 195.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 195.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 195.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 195.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 195.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 195.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 195.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 195.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 195.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 195.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 195.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 195.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 194.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 194.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 194.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 194.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 194.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 194.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 194.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 194.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 194.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 194.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 194.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 194.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 194.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 194.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 194.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 194.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 194.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 194.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 194.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 194.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 193.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 193.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 193.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 193.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 193.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 193.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 193.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 193.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 193.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 193.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 193.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 193.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 193.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 193.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 193.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 193.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 193.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 193.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 193.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 193.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 192.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 192.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 192.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 192.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 192.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 192.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 192.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 192.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 192.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 192.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 192.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 192.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 192.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 192.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 192.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 192.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 192.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 192.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 192.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 192.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 191.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 191.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 191.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 191.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 191.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 191.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 191.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 191.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 191.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 191.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 191.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 191.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 191.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 191.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 191.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 191.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 191.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 191.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 191.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 191.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 190.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 190.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 190.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 190.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 190.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 190.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 190.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 190.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 190.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 190.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 190.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 190.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 190.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 190.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 190.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 190.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 190.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 190.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 190.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 190.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 189.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 189.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 189.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 189.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 189.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 189.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 189.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 189.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 189.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 189.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 189.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 189.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 189.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 189.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 189.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 189.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 189.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 189.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 189.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 189.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 188.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 188.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 188.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 188.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 188.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 188.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 188.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 188.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 188.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 188.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 188.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 188.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 188.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 188.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 188.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 188.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 188.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 188.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 188.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 188.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 187.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 187.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 187.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 187.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 187.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 187.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 187.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 187.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 187.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 187.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 187.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 187.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 187.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 187.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 187.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 187.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 187.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 187.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 187.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 187.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 186.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 186.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 186.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 186.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 186.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 186.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 186.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 186.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 186.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 186.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 186.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 186.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 186.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 186.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 186.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 186.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 186.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 186.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 186.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 186.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 185.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 185.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 185.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 185.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 185.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 185.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 185.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 185.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 185.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 185.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 185.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 185.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 185.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 185.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 185.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 185.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 185.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 185.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 185.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 185.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 184.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 184.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 184.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 184.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 184.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 184.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 184.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 184.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 184.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 184.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 184.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 184.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 184.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 184.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 184.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 184.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 184.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 184.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 184.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 184.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 183.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 183.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 183.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 183.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 183.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 183.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 183.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 183.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 183.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 183.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 183.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 183.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 183.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 183.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 183.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 183.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 183.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 183.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 183.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 183.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 182.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 182.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 182.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 182.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 182.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 182.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 182.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 182.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 182.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 182.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 182.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 182.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 182.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 182.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 182.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 182.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 182.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 182.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 182.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 182.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 181.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 181.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 181.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 181.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 181.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 181.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 181.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 181.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 181.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 181.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 181.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 181.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 181.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 181.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 181.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 181.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 181.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 181.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 181.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 181.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 180.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 180.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 180.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 180.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 180.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 180.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 180.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 180.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 180.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 180.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 180.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 180.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 180.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 180.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 180.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 180.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 180.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 180.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 180.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 180.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 179.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 179.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 179.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 179.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 179.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 179.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 179.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 179.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 179.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 179.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 179.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 179.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 179.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 179.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 179.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 179.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 179.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 179.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 179.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 179.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 178.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 178.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 178.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 178.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 178.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 178.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 178.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 178.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 178.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 178.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 178.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 178.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 178.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 178.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 178.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 178.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 178.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 178.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 178.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 178.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 177.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 177.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 177.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 177.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 177.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 177.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 177.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 177.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 177.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 177.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 177.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 177.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 177.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 177.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 177.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 177.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 177.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 177.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 177.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 177.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 176.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 176.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 176.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 176.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 176.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 176.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 176.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 176.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 176.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 176.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 176.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 176.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 176.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 176.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 176.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 176.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 176.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 176.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 176.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 176.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 175.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 175.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 175.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 175.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 175.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 175.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 175.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 175.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 175.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 175.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 175.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 175.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 175.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 175.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 175.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 175.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 175.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 175.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 175.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 175.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 174.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 174.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 174.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 174.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 174.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 174.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 174.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 174.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 174.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 174.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 174.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 174.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 174.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 174.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 174.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 174.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 174.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 174.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 174.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 174.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 173.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 173.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 173.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 173.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 173.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 173.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 173.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 173.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 173.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 173.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 173.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 173.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 173.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 173.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 173.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 173.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 173.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 173.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 173.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 173.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 172.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 172.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 172.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 172.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 172.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 172.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 172.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 172.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 172.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 172.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 172.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 172.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 172.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 172.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 172.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 172.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 172.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 172.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 172.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 172.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 171.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 171.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 171.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 171.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 171.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 171.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 171.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 171.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 171.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 171.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 171.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 171.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 171.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 171.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 171.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 171.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 171.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 171.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 171.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 171.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 170.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 170.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 170.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 170.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 170.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 170.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 170.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 170.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 170.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 170.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 170.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 170.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 170.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 170.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 170.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 170.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 170.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 170.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 170.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 170.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 169.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 169.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 169.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 169.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 169.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 169.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 169.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 169.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 169.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 169.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 169.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 169.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 169.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 169.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 169.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 169.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 169.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 169.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 169.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 169.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 168.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 168.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 168.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 168.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 168.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 168.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 168.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 168.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 168.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 168.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 168.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 168.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 168.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 168.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 168.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 168.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 168.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 168.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 168.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 168.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 167.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 167.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 167.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 167.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 167.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 167.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 167.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 167.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 167.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 167.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 167.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 167.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 167.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 167.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 167.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 167.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 167.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 167.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 167.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 167.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 166.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 166.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 166.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 166.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 166.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 166.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 166.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 166.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 166.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 166.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 166.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 166.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 166.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 166.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 166.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 166.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 166.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 166.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 166.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 166.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 165.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 165.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 165.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 165.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 165.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 165.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 165.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 165.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 165.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 165.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 165.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 165.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 165.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 165.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 165.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 165.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 165.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 165.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 165.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 165.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 164.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 164.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 164.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 164.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 164.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 164.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 164.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 164.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 164.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 164.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 164.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 164.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 164.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 164.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 164.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 164.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 164.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 164.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 164.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 164.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 163.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 163.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 163.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 163.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 163.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 163.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 163.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 163.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 163.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 163.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 163.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 163.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 163.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 163.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 163.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 163.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 163.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 163.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 163.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 163.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 162.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 162.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 162.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 162.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 162.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 162.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 162.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 162.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 162.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 162.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 162.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 162.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 162.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 162.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 162.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 162.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 162.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 162.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 162.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 162.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 161.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 161.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 161.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 161.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 161.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 161.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 161.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 161.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 161.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 161.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 161.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 161.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 161.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 161.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 161.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 161.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 161.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 161.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 161.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 161.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 160.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 160.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 160.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 160.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 160.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 160.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 160.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 160.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 160.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 160.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 160.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 160.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 160.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 160.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 160.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 160.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 160.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 160.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 160.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 160.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 159.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 159.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 159.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 159.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 159.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 159.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 159.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 159.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 159.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 159.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 159.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 159.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 159.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 159.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 159.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 159.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 159.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 159.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 159.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 159.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 158.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 158.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 158.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 158.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 158.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 158.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 158.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 158.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 158.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 158.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 158.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 158.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 158.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 158.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 158.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 158.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 158.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 158.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 158.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 158.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 157.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 157.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 157.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 157.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 157.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 157.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 157.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 157.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 157.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 157.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 157.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 157.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 157.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 157.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 157.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 157.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 157.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 157.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 157.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 157.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 156.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 156.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 156.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 156.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 156.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 156.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 156.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 156.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 156.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 156.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 156.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 156.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 156.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 156.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 156.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 156.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 156.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 156.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 156.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 156.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 155.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 155.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 155.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 155.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 155.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 155.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 155.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 155.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 155.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 155.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 155.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 155.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 155.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 155.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 155.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 155.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 155.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 155.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 155.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 155.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 154.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 154.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 154.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 154.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 154.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 154.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 154.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 154.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 154.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 154.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 154.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 154.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 154.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 154.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 154.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 154.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 154.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 154.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 154.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 154.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 153.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 153.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 153.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 153.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 153.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 153.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 153.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 153.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 153.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 153.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 153.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 153.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 153.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 153.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 153.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 153.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 153.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 153.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 153.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 153.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 152.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 152.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 152.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 152.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 152.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 152.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 152.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 152.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 152.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 152.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 152.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 152.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 152.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 152.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 152.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 152.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 152.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 152.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 152.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 152.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 151.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 151.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 151.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 151.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 151.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 151.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 151.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 151.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 151.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 151.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 151.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 151.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 151.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 151.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 151.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 151.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 151.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 151.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 151.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 151.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 150.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 150.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 150.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 150.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 150.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 150.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 150.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 150.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 150.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 150.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 150.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 150.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 150.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 150.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 150.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 150.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 150.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 150.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 150.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 150.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 149.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 149.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 149.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 149.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 149.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 149.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 149.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 149.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 149.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 149.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 149.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 149.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 149.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 149.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 149.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 149.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 149.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 149.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 149.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 149.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 148.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 148.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 148.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 148.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 148.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 148.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 148.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 148.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 148.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 148.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 148.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 148.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 148.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 148.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 148.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 148.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 148.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 148.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 148.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 148.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 147.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 147.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 147.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 147.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 147.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 147.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 147.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 147.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 147.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 147.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 147.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 147.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 147.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 147.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 147.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 147.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 147.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 147.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 147.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 147.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 146.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 146.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 146.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 146.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 146.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 146.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 146.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 146.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 146.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 146.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 146.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 146.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 146.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 146.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 146.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 146.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 146.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 146.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 146.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 146.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 145.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 145.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 145.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 145.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 145.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 145.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 145.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 145.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 145.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 145.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 145.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 145.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 145.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 145.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 145.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 145.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 145.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 145.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 145.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 145.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 144.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 144.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 144.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 144.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 144.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 144.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 144.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 144.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 144.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 144.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 144.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 144.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 144.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 144.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 144.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 144.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 144.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 144.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 144.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 144.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 143.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 143.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 143.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 143.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 143.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 143.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 143.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 143.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 143.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 143.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 143.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 143.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 143.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 143.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 143.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 143.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 143.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 143.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 143.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 143.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 142.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 142.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 142.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 142.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 142.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 142.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 142.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 142.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 142.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 142.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 142.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 142.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 142.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 142.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 142.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 142.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 142.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 142.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 142.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 142.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 141.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 141.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 141.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 141.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 141.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 141.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 141.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 141.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 141.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 141.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 141.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 141.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 141.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 141.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 141.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 141.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 141.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 141.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 141.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 141.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 140.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 140.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 140.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 140.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 140.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 140.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 140.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 140.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 140.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 140.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 140.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 140.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 140.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 140.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 140.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 140.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 140.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 140.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 140.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 140.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 139.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 139.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 139.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 139.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 139.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 139.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 139.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 139.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 139.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 139.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 139.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 139.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 139.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 139.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 139.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 139.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 139.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 139.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 139.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 139.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 138.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 138.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 138.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 138.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 138.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 138.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 138.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 138.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 138.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 138.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 138.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 138.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 138.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 138.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 138.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 138.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 138.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 138.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 138.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 138.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 137.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 137.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 137.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 137.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 137.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 137.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 137.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 137.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 137.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 137.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 137.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 137.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 137.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 137.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 137.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 137.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 137.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 137.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 137.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 137.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 136.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 136.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 136.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 136.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 136.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 136.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 136.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 136.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 136.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 136.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 136.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 136.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 136.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 136.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 136.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 136.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 136.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 136.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 136.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 136.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 135.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 135.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 135.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 135.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 135.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 135.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 135.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 135.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 135.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 135.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 135.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 135.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 135.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 135.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 135.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 135.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 135.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 135.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 135.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 135.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 134.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 134.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 134.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 134.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 134.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 134.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 134.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 134.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 134.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 134.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 134.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 134.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 134.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 134.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 134.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 134.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 134.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 134.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 134.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 134.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 133.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 133.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 133.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 133.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 133.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 133.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 133.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 133.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 133.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 133.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 133.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 133.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 133.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 133.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 133.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 133.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 133.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 133.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 133.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 133.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 132.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 132.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 132.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 132.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 132.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 132.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 132.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 132.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 132.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 132.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 132.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 132.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 132.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 132.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 132.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 132.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 132.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 132.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 132.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 132.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 131.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 131.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 131.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 131.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 131.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 131.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 131.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 131.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 131.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 131.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 131.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 131.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 131.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 131.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 131.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 131.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 131.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 131.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 131.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 131.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 130.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 130.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 130.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 130.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 130.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 130.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 130.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 130.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 130.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 130.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 130.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 130.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 130.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 130.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 130.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 130.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 130.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 130.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 130.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 130.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 129.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 129.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 129.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 129.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 129.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 129.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 129.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 129.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 129.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 129.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 129.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 129.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 129.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 129.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 129.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 129.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 129.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 129.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 129.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 129.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 128.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 128.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 128.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 128.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 128.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 128.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 128.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 128.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 128.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 128.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 128.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 128.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 128.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 128.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 128.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 128.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 128.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 128.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 128.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 128.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 127.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 127.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 127.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 127.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 127.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 127.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 127.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 127.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 127.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 127.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 127.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 127.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 127.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 127.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 127.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 127.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 127.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 127.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 127.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 127.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 126.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 126.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 126.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 126.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 126.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 126.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 126.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 126.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 126.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 126.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 126.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 126.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 126.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 126.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 126.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 126.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 126.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 126.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 126.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 126.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 125.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 125.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 125.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 125.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 125.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 125.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 125.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 125.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 125.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 125.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 125.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 125.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 125.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 125.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 125.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 125.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 125.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 125.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 125.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 125.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 124.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 124.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 124.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 124.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 124.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 124.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 124.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 124.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 124.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 124.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 124.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 124.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 124.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 124.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 124.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 124.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 124.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 124.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 124.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 124.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 123.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 123.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 123.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 123.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 123.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 123.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 123.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 123.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 123.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 123.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 123.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 123.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 123.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 123.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 123.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 123.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 123.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 123.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 123.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 123.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 122.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 122.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 122.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 122.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 122.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 122.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 122.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 122.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 122.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 122.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 122.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 122.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 122.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 122.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 122.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 122.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 122.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 122.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 122.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 122.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 121.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 121.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 121.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 121.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 121.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 121.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 121.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 121.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 121.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 121.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 121.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 121.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 121.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 121.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 121.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 121.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 121.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 121.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 121.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 121.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 120.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 120.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 120.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 120.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 120.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 120.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 120.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 120.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 120.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 120.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 120.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 120.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 120.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 120.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 120.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 120.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 120.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 120.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 120.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 120.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 119.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 119.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 119.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 119.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 119.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 119.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 119.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 119.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 119.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 119.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 119.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 119.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 119.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 119.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 119.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 119.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 119.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 119.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 119.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 119.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 118.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 118.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 118.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 118.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 118.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 118.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 118.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 118.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 118.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 118.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 118.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 118.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 118.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 118.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 118.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 118.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 118.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 118.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 118.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 118.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 117.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 117.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 117.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 117.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 117.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 117.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 117.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 117.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 117.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 117.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 117.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 117.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 117.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 117.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 117.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 117.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 117.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 117.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 117.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 117.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 116.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 116.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 116.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 116.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 116.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 116.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 116.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 116.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 116.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 116.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 116.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 116.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 116.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 116.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 116.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 116.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 116.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 116.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 116.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 116.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 115.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 115.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 115.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 115.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 115.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 115.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 115.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 115.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 115.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 115.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 115.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 115.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 115.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 115.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 115.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 115.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 115.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 115.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 115.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 115.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 114.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 114.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 114.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 114.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 114.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 114.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 114.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 114.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 114.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 114.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 114.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 114.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 114.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 114.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 114.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 114.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 114.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 114.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 114.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 114.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 113.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 113.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 113.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 113.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 113.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 113.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 113.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 113.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 113.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 113.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 113.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 113.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 113.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 113.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 113.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 113.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 113.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 113.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 113.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 113.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 112.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 112.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 112.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 112.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 112.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 112.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 112.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 112.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 112.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 112.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 112.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 112.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 112.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 112.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 112.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 112.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 112.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 112.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 112.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 112.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 111.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 111.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 111.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 111.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 111.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 111.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 111.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 111.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 111.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 111.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 111.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 111.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 111.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 111.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 111.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 111.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 111.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 111.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 111.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 111.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 110.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 110.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 110.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 110.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 110.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 110.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 110.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 110.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 110.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 110.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 110.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 110.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 110.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 110.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 110.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 110.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 110.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 110.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 110.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 110.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 109.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 109.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 109.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 109.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 109.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 109.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 109.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 109.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 109.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 109.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 109.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 109.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 109.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 109.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 109.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 109.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 109.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 109.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 109.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 109.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 108.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 108.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 108.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 108.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 108.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 108.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 108.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 108.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 108.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 108.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 108.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 108.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 108.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 108.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 108.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 108.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 108.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 108.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 108.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 108.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 107.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 107.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 107.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 107.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 107.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 107.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 107.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 107.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 107.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 107.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 107.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 107.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 107.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 107.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 107.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 107.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 107.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 107.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 107.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 107.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 106.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 106.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 106.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 106.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 106.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 106.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 106.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 106.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 106.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 106.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 106.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 106.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 106.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 106.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 106.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 106.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 106.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 106.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 106.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 106.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 105.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 105.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 105.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 105.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 105.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 105.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 105.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 105.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 105.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 105.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 105.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 105.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 105.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 105.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 105.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 105.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 105.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 105.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 105.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 105.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 104.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 104.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 104.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 104.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 104.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 104.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 104.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 104.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 104.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 104.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 104.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 104.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 104.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 104.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 104.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 104.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 104.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 104.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 104.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 104.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 103.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 103.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 103.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 103.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 103.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 103.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 103.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 103.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 103.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 103.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 103.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 103.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 103.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 103.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 103.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 103.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 103.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 103.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 103.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 103.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 102.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 102.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 102.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 102.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 102.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 102.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 102.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 102.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 102.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 102.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 102.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 102.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 102.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 102.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 102.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 102.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 102.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 102.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 102.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 102.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 101.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 101.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 101.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 101.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 101.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 101.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 101.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 101.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 101.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 101.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 101.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 101.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 101.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 101.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 101.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 101.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 101.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 101.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 101.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 101.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 100.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 100.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 100.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 100.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 100.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 100.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 100.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 100.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 100.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 100.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 100.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 100.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 100.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 100.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 100.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 100.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 100.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 100.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 100.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 100.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 99.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 99.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 99.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 99.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 99.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 99.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 99.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 99.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 99.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 99.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 99.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 99.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 99.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 99.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 99.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 99.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 99.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 99.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 99.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 99.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 98.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 98.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 98.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 98.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 98.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 98.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 98.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 98.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 98.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 98.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 98.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 98.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 98.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 98.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 98.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 98.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 98.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 98.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 98.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 98.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 97.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 97.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 97.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 97.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 97.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 97.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 97.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 97.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 97.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 97.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 97.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 97.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 97.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 97.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 97.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 97.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 97.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 97.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 97.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 97.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 96.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 96.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 96.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 96.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 96.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 96.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 96.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 96.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 96.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 96.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 96.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 96.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 96.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 96.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 96.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 96.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 96.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 96.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 96.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 96.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 95.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 95.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 95.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 95.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 95.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 95.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 95.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 95.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 95.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 95.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 95.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 95.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 95.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 95.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 95.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 95.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 95.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 95.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 95.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 95.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 94.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 94.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 94.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 94.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 94.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 94.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 94.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 94.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 94.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 94.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 94.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 94.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 94.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 94.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 94.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 94.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 94.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 94.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 94.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 94.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 93.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 93.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 93.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 93.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 93.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 93.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 93.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 93.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 93.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 93.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 93.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 93.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 93.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 93.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 93.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 93.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 93.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 93.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 93.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 93.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 92.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 92.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 92.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 92.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 92.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 92.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 92.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 92.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 92.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 92.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 92.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 92.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 92.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 92.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 92.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 92.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 92.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 92.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 92.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 92.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 91.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 91.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 91.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 91.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 91.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 91.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 91.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 91.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 91.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 91.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 91.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 91.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 91.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 91.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 91.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 91.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 91.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 91.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 91.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 91.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 90.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 90.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 90.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 90.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 90.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 90.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 90.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 90.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 90.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 90.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 90.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 90.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 90.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 90.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 90.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 90.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 90.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 90.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 90.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 90.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 89.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 89.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 89.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 89.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 89.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 89.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 89.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 89.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 89.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 89.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 89.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 89.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 89.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 89.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 89.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 89.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 89.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 89.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 89.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 89.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 88.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 88.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 88.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 88.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 88.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 88.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 88.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 88.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 88.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 88.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 88.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 88.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 88.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 88.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 88.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 88.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 88.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 88.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 88.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 88.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 87.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 87.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 87.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 87.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 87.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 87.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 87.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 87.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 87.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 87.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 87.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 87.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 87.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 87.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 87.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 87.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 87.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 87.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 87.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 87.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 86.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 86.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 86.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 86.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 86.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 86.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 86.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 86.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 86.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 86.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 86.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 86.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 86.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 86.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 86.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 86.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 86.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 86.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 86.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 86.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 85.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 85.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 85.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 85.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 85.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 85.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 85.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 85.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 85.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 85.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 85.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 85.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 85.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 85.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 85.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 85.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 85.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 85.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 85.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 85.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 84.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 84.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 84.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 84.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 84.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 84.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 84.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 84.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 84.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 84.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 84.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 84.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 84.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 84.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 84.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 84.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 84.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 84.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 84.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 84.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 83.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 83.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 83.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 83.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 83.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 83.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 83.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 83.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 83.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 83.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 83.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 83.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 83.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 83.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 83.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 83.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 83.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 83.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 83.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 83.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 82.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 82.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 82.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 82.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 82.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 82.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 82.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 82.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 82.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 82.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 82.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 82.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 82.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 82.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 82.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 82.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 82.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 82.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 82.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 82.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 81.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 81.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 81.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 81.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 81.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 81.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 81.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 81.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 81.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 81.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 81.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 81.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 81.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 81.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 81.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 81.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 81.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 81.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 81.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 81.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 80.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 80.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 80.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 80.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 80.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 80.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 80.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 80.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 80.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 80.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 80.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 80.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 80.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 80.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 80.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 80.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 80.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 80.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 80.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 80.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 79.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 79.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 79.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 79.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 79.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 79.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 79.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 79.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 79.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 79.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 79.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 79.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 79.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 79.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 79.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 79.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 79.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 79.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 79.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 79.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 78.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 78.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 78.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 78.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 78.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 78.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 78.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 78.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 78.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 78.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 78.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 78.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 78.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 78.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 78.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 78.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 78.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 78.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 78.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 78.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 77.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 77.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 77.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 77.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 77.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 77.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 77.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 77.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 77.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 77.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 77.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 77.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 77.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 77.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 77.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 77.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 77.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 77.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 77.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 77.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 76.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 76.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 76.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 76.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 76.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 76.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 76.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 76.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 76.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 76.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 76.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 76.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 76.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 76.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 76.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 76.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 76.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 76.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 76.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 76.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 75.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 75.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 75.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 75.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 75.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 75.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 75.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 75.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 75.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 75.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 75.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 75.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 75.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 75.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 75.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 75.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 75.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 75.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 75.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 75.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 74.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 74.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 74.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 74.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 74.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 74.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 74.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 74.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 74.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 74.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 74.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 74.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 74.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 74.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 74.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 74.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 74.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 74.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 74.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 74.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 73.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 73.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 73.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 73.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 73.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 73.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 73.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 73.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 73.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 73.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 73.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 73.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 73.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 73.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 73.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 73.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 73.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 73.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 73.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 73.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 72.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 72.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 72.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 72.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 72.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 72.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 72.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 72.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 72.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 72.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 72.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 72.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 72.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 72.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 72.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 72.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 72.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 72.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 72.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 72.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 71.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 71.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 71.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 71.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 71.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 71.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 71.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 71.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 71.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 71.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 71.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 71.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 71.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 71.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 71.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 71.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 71.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 71.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 71.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 71.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 70.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 70.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 70.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 70.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 70.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 70.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 70.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 70.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 70.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 70.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 70.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 70.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 70.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 70.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 70.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 70.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 70.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 70.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 70.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 70.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 69.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 69.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 69.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 69.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 69.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 69.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 69.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 69.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 69.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 69.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 69.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 69.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 69.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 69.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 69.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 69.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 69.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 69.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 69.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 69.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 68.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 68.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 68.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 68.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 68.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 68.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 68.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 68.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 68.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 68.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 68.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 68.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 68.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 68.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 68.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 68.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 68.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 68.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 68.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 68.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 67.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 67.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 67.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 67.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 67.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 67.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 67.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 67.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 67.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 67.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 67.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 67.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 67.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 67.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 67.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 67.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 67.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 67.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 67.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 67.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 66.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 66.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 66.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 66.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 66.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 66.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 66.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 66.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 66.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 66.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 66.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 66.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 66.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 66.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 66.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 66.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 66.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 66.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 66.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 66.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 65.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 65.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 65.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 65.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 65.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 65.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 65.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 65.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 65.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 65.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 65.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 65.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 65.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 65.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 65.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 65.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 65.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 65.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 65.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 65.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 64.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 64.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 64.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 64.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 64.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 64.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 64.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 64.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 64.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 64.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 64.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 64.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 64.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 64.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 64.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 64.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 64.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 64.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 64.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 64.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 63.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 63.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 63.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 63.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 63.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 63.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 63.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 63.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 63.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 63.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 63.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 63.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 63.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 63.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 63.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 63.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 63.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 63.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 63.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 63.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 62.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 62.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 62.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 62.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 62.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 62.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 62.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 62.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 62.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 62.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 62.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 62.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 62.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 62.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 62.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 62.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 62.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 62.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 62.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 62.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 61.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 61.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 61.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 61.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 61.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 61.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 61.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 61.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 61.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 61.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 61.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 61.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 61.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 61.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 61.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 61.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 61.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 61.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 61.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 61.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 60.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 60.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 60.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 60.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 60.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 60.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 60.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 60.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 60.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 60.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 60.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 60.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 60.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 60.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 60.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 60.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 60.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 60.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 60.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 60.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 59.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 59.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 59.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 59.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 59.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 59.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 59.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 59.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 59.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 59.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 59.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 59.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 59.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 59.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 59.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 59.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 59.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 59.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 59.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 59.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 58.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 58.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 58.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 58.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 58.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 58.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 58.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 58.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 58.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 58.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 58.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 58.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 58.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 58.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 58.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 58.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 58.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 58.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 58.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 58.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 57.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 57.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 57.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 57.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 57.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 57.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 57.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 57.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 57.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 57.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 57.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 57.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 57.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 57.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 57.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 57.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 57.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 57.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 57.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 57.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 56.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 56.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 56.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 56.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 56.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 56.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 56.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 56.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 56.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 56.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 56.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 56.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 56.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 56.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 56.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 56.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 56.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 56.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 56.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 56.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 55.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 55.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 55.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 55.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 55.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 55.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 55.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 55.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 55.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 55.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 55.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 55.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 55.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 55.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 55.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 55.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 55.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 55.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 55.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 55.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 54.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 54.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 54.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 54.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 54.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 54.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 54.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 54.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 54.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 54.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 54.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 54.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 54.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 54.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 54.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 54.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 54.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 54.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 54.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 54.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 53.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 53.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 53.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 53.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 53.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 53.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 53.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 53.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 53.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 53.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 53.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 53.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 53.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 53.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 53.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 53.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 53.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 53.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 53.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 53.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 52.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 52.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 52.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 52.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 52.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 52.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 52.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 52.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 52.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 52.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 52.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 52.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 52.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 52.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 52.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 52.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 52.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 52.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 52.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 52.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 51.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 51.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 51.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 51.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 51.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 51.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 51.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 51.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 51.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 51.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 51.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 51.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 51.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 51.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 51.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 51.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 51.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 51.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 51.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 51.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 50.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 50.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 50.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 50.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 50.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 50.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 50.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 50.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 50.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 50.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 50.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 50.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 50.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 50.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 50.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 50.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 50.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 50.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 50.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 50.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 49.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 49.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 49.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 49.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 49.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 49.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 49.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 49.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 49.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 49.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 49.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 49.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 49.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 49.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 49.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 49.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 49.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 49.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 49.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 49.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 48.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 48.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 48.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 48.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 48.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 48.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 48.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 48.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 48.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 48.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 48.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 48.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 48.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 48.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 48.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 48.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 48.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 48.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 48.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 48.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 47.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 47.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 47.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 47.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 47.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 47.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 47.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 47.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 47.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 47.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 47.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 47.404999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 47.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 47.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 47.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 47.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 47.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 47.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 47.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 47.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 46.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 46.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 46.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 46.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 46.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 46.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 46.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 46.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 46.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 46.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 46.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 46.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 46.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 46.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 46.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 46.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 46.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 46.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 46.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 46.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 45.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 45.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 45.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 45.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 45.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 45.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 45.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 45.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 45.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 45.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 45.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 45.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 45.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 45.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 45.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 45.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 45.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 45.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 45.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 45.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 44.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 44.904999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 44.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 44.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 44.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 44.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 44.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 44.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 44.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 44.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 44.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 44.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 44.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 44.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 44.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 44.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 44.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 44.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 44.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 44.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 43.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 43.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 43.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 43.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 43.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 43.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 43.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 43.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 43.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 43.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 43.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 43.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 43.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 43.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 43.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 43.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 43.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 43.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 43.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 43.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 42.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 42.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 42.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 42.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 42.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 42.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 42.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 42.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 42.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 42.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 42.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 42.404999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 42.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 42.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 42.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 42.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 42.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 42.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 42.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 42.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 41.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 41.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 41.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 41.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 41.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 41.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 41.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 41.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 41.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 41.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 41.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 41.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 41.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 41.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 41.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 41.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 41.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 41.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 41.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 41.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 40.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 40.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 40.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 40.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 40.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 40.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 40.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 40.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 40.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 40.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 40.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 40.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 40.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 40.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 40.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 40.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 40.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 40.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 40.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 40.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 39.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 39.904999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 39.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 39.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 39.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 39.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 39.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 39.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 39.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 39.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 39.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 39.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 39.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 39.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 39.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 39.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 39.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 39.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 39.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 39.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 38.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 38.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 38.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 38.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 38.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 38.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 38.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 38.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 38.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 38.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 38.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 38.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 38.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 38.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 38.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 38.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 38.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 38.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 38.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 38.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 37.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 37.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 37.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 37.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 37.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 37.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 37.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 37.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 37.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 37.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 37.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 37.404999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 37.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 37.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 37.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 37.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 37.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 37.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 37.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 37.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 36.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 36.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 36.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 36.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 36.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 36.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 36.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 36.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 36.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 36.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 36.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 36.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 36.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 36.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 36.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 36.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 36.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 36.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 36.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 36.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 35.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 35.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 35.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 35.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 35.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 35.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 35.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 35.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 35.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 35.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 35.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 35.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 35.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 35.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 35.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 35.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 35.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 35.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 35.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 35.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 34.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 34.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 34.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 34.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 34.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 34.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 34.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 34.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 34.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 34.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 34.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 34.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 34.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 34.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 34.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 34.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 34.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 34.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 34.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 34.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 33.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 33.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 33.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 33.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 33.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 33.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 33.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 33.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 33.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 33.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 33.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 33.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 33.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 33.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 33.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 33.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 33.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 33.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 33.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 33.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 32.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 32.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 32.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 32.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 32.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 32.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 32.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 32.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 32.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 32.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 32.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 32.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 32.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 32.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 32.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 32.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 32.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 32.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 32.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 32.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 31.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 31.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 31.895000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 31.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 31.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 31.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 31.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 31.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 31.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 31.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 31.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 31.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 31.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 31.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 31.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 31.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 31.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 31.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 31.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 31.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 30.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 30.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 30.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 30.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 30.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 30.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 30.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 30.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 30.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 30.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 30.494999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 30.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 30.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 30.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 30.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 30.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 30.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 30.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 30.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 30.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 29.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 29.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 29.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 29.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 29.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 29.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 29.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 29.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 29.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 29.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 29.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 29.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 29.395000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 29.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 29.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 29.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 29.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 29.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 29.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 29.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 28.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 28.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 28.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 28.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 28.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 28.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 28.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 28.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 28.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 28.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 28.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 28.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 28.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 28.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 28.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 28.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 28.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 28.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 28.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 28.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 27.994999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 27.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 27.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 27.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 27.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 27.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 27.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 27.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 27.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 27.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 27.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 27.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 27.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 27.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 27.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 27.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 27.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 27.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 27.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 27.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 26.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 26.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 26.895000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 26.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 26.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 26.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 26.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 26.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 26.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 26.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 26.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 26.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 26.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 26.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 26.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 26.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 26.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 26.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 26.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 26.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 25.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 25.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 25.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 25.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 25.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 25.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 25.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 25.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 25.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 25.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 25.494999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 25.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 25.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 25.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 25.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 25.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 25.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 25.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 25.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 25.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 24.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 24.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 24.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 24.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 24.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 24.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 24.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 24.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 24.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 24.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 24.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 24.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 24.395000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 24.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 24.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 24.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 24.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 24.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 24.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 24.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 23.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 23.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 23.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 23.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 23.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 23.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 23.694999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 23.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 23.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 23.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 23.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 23.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 23.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 23.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 23.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 23.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 23.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 23.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 23.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 23.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 22.994999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 22.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 22.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 22.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 22.794999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 22.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 22.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 22.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 22.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 22.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 22.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 22.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 22.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 22.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 22.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 22.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 22.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 22.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 22.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 22.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 21.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 21.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 21.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 21.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 21.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 21.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 21.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 21.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 21.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 21.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 21.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 21.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 21.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 21.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 21.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 21.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 21.194999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 21.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 21.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 21.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 20.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 20.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 20.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 20.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 20.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 20.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 20.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 20.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 20.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 20.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 20.494999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 20.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 20.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 20.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 20.294999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 20.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 20.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 20.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 20.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 20.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 19.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 19.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 19.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 19.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 19.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 19.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 19.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 19.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 19.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 19.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 19.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 19.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 19.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 19.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 19.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 19.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 19.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 19.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 19.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 19.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 18.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 18.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 18.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 18.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 18.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 18.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 18.694999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 18.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 18.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 18.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 18.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 18.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 18.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 18.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 18.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 18.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 18.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 18.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 18.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 18.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 17.994999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 17.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 17.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 17.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 17.794999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 17.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 17.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 17.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 17.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 17.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 17.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 17.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 17.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 17.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 17.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 17.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 17.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 17.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 17.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 17.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 16.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 16.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 16.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 16.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 16.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 16.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 16.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 16.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 16.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 16.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 16.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 16.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 16.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 16.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 16.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 16.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 16.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 16.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 16.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 16.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 15.995000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 15.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 15.895000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 15.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 15.795000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 15.704999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 15.694999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 15.604999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 15.594999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 15.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 15.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 15.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 15.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 15.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 15.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 15.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 15.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 15.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 15.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 15.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 14.995000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 14.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 14.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 14.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 14.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 14.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 14.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 14.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 14.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 14.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 14.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 14.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 14.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 14.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 14.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 14.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 14.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 14.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 14.094999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 14.004999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 13.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 13.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 13.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 13.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 13.795000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 13.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 13.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 13.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 13.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 13.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 13.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 13.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 13.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 13.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 13.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 13.204999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 13.194999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 13.104999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 13.094999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 13.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 12.995000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 12.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 12.895000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 12.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 12.795000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 12.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 12.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 12.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 12.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 12.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 12.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 12.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 12.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 12.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 12.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 12.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 12.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 12.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 12.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 12.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 11.995000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 11.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 11.895000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 11.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 11.795000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 11.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 11.694999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 11.604999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 11.594999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 11.504999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 11.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 11.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 11.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 11.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 11.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 11.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 11.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 11.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 11.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 11.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 10.995000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 10.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 10.895000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 10.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 10.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 10.704999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 10.694999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 10.604999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 10.594999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 10.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 10.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 10.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 10.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 10.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 10.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 10.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 10.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 10.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 10.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 10.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 9.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 9.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 9.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 9.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 9.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 9.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 9.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 9.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 9.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 9.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 9.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 9.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 9.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 9.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 9.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 9.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 9.194999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 9.104999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 9.094999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 9.004999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 8.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 8.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 8.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 8.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 8.795000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 8.704999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 8.694999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 8.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 8.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 8.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 8.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 8.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 8.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 8.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 8.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 8.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 8.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 8.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 8.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 8.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 7.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 7.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 7.8950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 7.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 7.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 7.705000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 7.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 7.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 7.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 7.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 7.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 7.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 7.3950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 7.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 7.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 7.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 7.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 7.1049999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 7.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 7.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 6.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 6.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 6.895000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 6.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 6.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 6.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 6.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 6.6049999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 6.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 6.505000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 6.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 6.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 6.3950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 6.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 6.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 6.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 6.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 6.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 6.095000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 6.005000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 5.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 5.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 5.8950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 5.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 5.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 5.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 5.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 5.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 5.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 5.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 5.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 5.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 5.3950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 5.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 5.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 5.205000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 5.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 5.1049999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 5.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 5.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 4.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 4.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 4.8950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 4.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 4.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 4.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 4.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 4.6049999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 4.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 4.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 4.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 4.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 4.3950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 4.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 4.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 4.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 4.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 4.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 4.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 4.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 3.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 3.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 3.8949999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 3.8049999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 3.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 3.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 3.6950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 3.6050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 3.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 3.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 3.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 3.4050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 3.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 3.3049999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 3.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 3.2050000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 3.1950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 3.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 3.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 3.0050000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 2.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 2.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 2.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 2.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 2.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 2.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 2.6950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 2.6050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 2.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 2.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 2.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 2.4050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 2.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 2.3049999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 2.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 2.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 2.1950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 2.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 2.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 2.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 1.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 1.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 1.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 1.8050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 1.7950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 1.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 1.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 1.6050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 1.5950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 1.5050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 1.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 1.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 1.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 1.3050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 1.2950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 1.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 1.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 1.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 1.0950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 1.0050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 0.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 0.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 0.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 0.8050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 0.7950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 0.7050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 0.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 0.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 0.5950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 0.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 0.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 0.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 0.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 0.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 0.29500000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 0.20500000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 0.19500000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 0.10500000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.0, 150.0, 0.09500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.0, 150.0, 0.005000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}

