translate([0, 0, 0]) cube([1, 1, 3.852316544786512]);

translate([1, 0, 0]) cube([1, 1, 2.8737469718512902]);

translate([2, 0, 0]) cube([1, 1, 3.708441379584084]);

translate([3, 0, 0]) cube([1, 1, 2.7431357873168767]);

translate([4, 0, 0]) cube([1, 1, 2.7431357873168776]);

translate([5, 0, 0]) cube([1, 1, 2.991094175717687]);

translate([6, 0, 0]) cube([1, 1, 3.239052564118494]);

color([0, 1, 0]) translate([7, 0, 0]) cube([1, 1, 4]);

translate([8, 0, 0]) cube([1, 1, 2.991094175717688]);

translate([9, 0, 0]) cube([1, 1, 3.121705360252098]);

color([0, 1, 0]) translate([10, 0, 0]) cube([1, 1, 4]);

translate([11, 0, 0]) cube([1, 1, 3.2002749331873197]);

translate([12, 0, 0]) cube([1, 1, 3.382927729320924]);

translate([13, 0, 0]) cube([1, 1, 3.2002749331873206]);

translate([14, 0, 0]) cube([1, 1, 2.887010952519306]);

translate([15, 0, 0]) cube([1, 1, 3.056399767984896]);

translate([16, 0, 0]) cube([1, 1, 2.2737469718512924]);

translate([17, 0, 0]) cube([1, 1, 3.1737469718512923]);

translate([18, 0, 0]) cube([1, 1, 2.221705360252101]);

translate([19, 0, 0]) cube([1, 1, 2.4043581563857046]);

translate([0, 1, 0]) cube([1, 1, 3.044150098389747]);

translate([1, 1, 0]) cube([1, 1, 3.2002749331873153]);

translate([2, 1, 0]) cube([1, 1, 2.887010952519301]);

translate([3, 1, 0]) cube([1, 1, 2.5737469718512855]);

translate([4, 1, 0]) cube([1, 1, 2.6910941757176827]);

color([0, 1, 0]) translate([5, 1, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 1, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 1, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 1, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 1, 0]) cube([1, 1, 4]);

translate([10, 1, 0]) cube([1, 1, 2.873746971851288]);

translate([11, 1, 0]) cube([1, 1, 3.239052564118494]);

translate([12, 1, 0]) cube([1, 1, 3.4217053602520973]);

translate([13, 1, 0]) cube([1, 1, 2.6390525641184945]);

color([0, 1, 0]) translate([14, 1, 0]) cube([1, 1, 4]);

translate([15, 1, 0]) cube([1, 1, 3.408441379584085]);

translate([16, 1, 0]) cube([1, 1, 3.160482991183277]);

translate([17, 1, 0]) cube([1, 1, 2.9125246027824683]);

translate([18, 1, 0]) cube([1, 1, 2.860482991183277]);

translate([19, 1, 0]) cube([1, 1, 2.3257885834504837]);

translate([0, 2, 0]) cube([1, 1, 3.30537246745857]);

translate([1, 2, 0]) cube([1, 1, 3.46149730225614]);

color([0, 1, 0]) translate([2, 2, 0]) cube([1, 1, 4]);

translate([3, 2, 0]) cube([1, 1, 4.817622137053712]);

color([0, 1, 0]) translate([4, 2, 0]) cube([1, 1, 4]);

translate([5, 2, 0]) cube([1, 1, 3.4870109525192987]);

color([0, 1, 0]) translate([6, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([10, 2, 0]) cube([1, 1, 4]);

translate([11, 2, 0]) cube([1, 1, 3.3563997679848905]);

color([0, 1, 0]) translate([12, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([14, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([15, 2, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 2, 0]) cube([1, 1, 4]);

translate([17, 2, 0]) cube([1, 1, 2.8472190105152615]);

translate([18, 2, 0]) cube([1, 1, 3.212524602782468]);

translate([19, 2, 0]) cube([1, 1, 2.077830195049675]);

translate([0, 3, 0]) cube([1, 1, 2.235983651992983]);

color([0, 1, 0]) translate([1, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 3, 0]) cube([1, 1, 4]);

translate([8, 3, 0]) cube([1, 1, 4.517622137053711]);

color([0, 1, 0]) translate([9, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([10, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([11, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([14, 3, 0]) cube([1, 1, 4]);

translate([15, 3, 0]) cube([1, 1, 3.3298718066488604]);

color([0, 1, 0]) translate([16, 3, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([17, 3, 0]) cube([1, 1, 4]);

translate([18, 3, 0]) cube([1, 1, 3.3298718066488653]);

translate([19, 3, 0]) cube([1, 1, 2.195177398916072]);

color([0, 1, 0]) translate([0, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([1, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 4, 0]) cube([1, 1, 4]);

translate([3, 4, 0]) cube([1, 1, 4.609455690656948]);

color([0, 1, 0]) translate([4, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 4, 0]) cube([1, 1, 4]);

translate([6, 4, 0]) cube([1, 1, 4.700274933187313]);

translate([7, 4, 0]) cube([1, 1, 4.582927729320917]);

color([0, 1, 0]) translate([8, 4, 0]) cube([1, 1, 4]);

translate([9, 4, 0]) cube([1, 1, 4.596191709988933]);

color([0, 1, 0]) translate([10, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([11, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([14, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([15, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 4, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([17, 4, 0]) cube([1, 1, 4]);

translate([18, 4, 0]) cube([1, 1, 2.9257885834504824]);

translate([19, 4, 0]) cube([1, 1, 2.44313578731688]);

color([0, 1, 0]) translate([0, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([1, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 5, 0]) cube([1, 1, 4]);

translate([5, 5, 0]) cube([1, 1, 4.844150098389742]);

color([0, 1, 0]) translate([6, 5, 0]) cube([1, 1, 4]);

translate([7, 5, 0]) cube([1, 1, 4.713538913855328]);

color([0, 1, 0]) translate([8, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 5, 0]) cube([1, 1, 4]);

translate([10, 5, 0]) cube([1, 1, 4.582927729320917]);

color([0, 1, 0]) translate([11, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([14, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([15, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([17, 5, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([18, 5, 0]) cube([1, 1, 4]);

translate([19, 5, 0]) cube([1, 1, 1.4390525641184972]);

translate([0, 6, 0]) cube([1, 1, 2.8492476326609975]);

color([0, 1, 0]) translate([1, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 6, 0]) cube([1, 1, 4]);

translate([3, 6, 0]) cube([1, 1, 4.792108486790552]);

color([0, 1, 0]) translate([4, 6, 0]) cube([1, 1, 4]);

translate([5, 6, 0]) cube([1, 1, 4.674761282924153]);

translate([6, 6, 0]) cube([1, 1, 4.661497302256137]);

translate([7, 6, 0]) cube([1, 1, 4.8961917099889325]);

translate([8, 6, 0]) cube([1, 1, 4.661497302256137]);

translate([9, 6, 0]) cube([1, 1, 4.844150098389742]);

color([0, 1, 0]) translate([10, 6, 0]) cube([1, 1, 4]);

translate([11, 6, 0]) cube([1, 1, 4.752316544786504]);

color([0, 1, 0]) translate([12, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([14, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([15, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 6, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([17, 6, 0]) cube([1, 1, 4]);

translate([18, 6, 0]) cube([1, 1, 2.769663748652907]);

translate([19, 6, 0]) cube([1, 1, 3.017622137053718]);

color([0, 1, 0]) translate([0, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([1, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 7, 0]) cube([1, 1, 4]);

translate([4, 7, 0]) cube([1, 1, 4.570678059725773]);

translate([5, 7, 0]) cube([1, 1, 4.740066875191359]);

translate([6, 7, 0]) cube([1, 1, 4.609455690656948]);

translate([7, 7, 0]) cube([1, 1, 5.026802894523343]);

translate([8, 7, 0]) cube([1, 1, 4.778844506122535]);

color([0, 1, 0]) translate([9, 7, 0]) cube([1, 1, 4]);

translate([10, 7, 0]) cube([1, 1, 4.648233321588122]);

translate([11, 7, 0]) cube([1, 1, 4.752316544786504]);

translate([12, 7, 0]) cube([1, 1, 4.569663748652902]);

color([0, 1, 0]) translate([13, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([14, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([15, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 7, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([17, 7, 0]) cube([1, 1, 4]);

translate([18, 7, 0]) cube([1, 1, 3.330886117721729]);

translate([19, 7, 0]) cube([1, 1, 2.7308861177217327]);

color([0, 1, 0]) translate([0, 8, 0]) cube([1, 1, 4]);

translate([1, 8, 0]) cube([1, 1, 4.818636448126583]);

color([0, 1, 0]) translate([2, 8, 0]) cube([1, 1, 4]);

translate([3, 8, 0]) cube([1, 1, 4.7012892442601855]);

translate([4, 8, 0]) cube([1, 1, 4.818636448126582]);

translate([5, 8, 0]) cube([1, 1, 4.805372467458565]);

translate([6, 8, 0]) cube([1, 1, 4.740066875191359]);

translate([7, 8, 0]) cube([1, 1, 4.557414079057757]);

translate([8, 8, 0]) cube([1, 1, 4.609455690656948]);

translate([9, 8, 0]) cube([1, 1, 5.1441500983897415]);

color([0, 1, 0]) translate([10, 8, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([11, 8, 0]) cube([1, 1, 4]);

translate([12, 8, 0]) cube([1, 1, 4.517622137053711]);

translate([13, 8, 0]) cube([1, 1, 4.634969340920107]);

color([0, 1, 0]) translate([14, 8, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([15, 8, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 8, 0]) cube([1, 1, 4]);

translate([17, 8, 0]) cube([1, 1, 3.1747612829241536]);

translate([18, 8, 0]) cube([1, 1, 2.9921084867905545]);

translate([19, 8, 0]) cube([1, 1, 2.678844506122542]);

translate([0, 9, 0]) cube([1, 1, 3.214553224928202]);

color([0, 1, 0]) translate([1, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 9, 0]) cube([1, 1, 4]);

translate([3, 9, 0]) cube([1, 1, 4.635983651992979]);

translate([4, 9, 0]) cube([1, 1, 4.688025263592168]);

translate([5, 9, 0]) cube([1, 1, 4.805372467458565]);

translate([6, 9, 0]) cube([1, 1, 5.105372467458565]);

translate([7, 9, 0]) cube([1, 1, 4.857414079057757]);

translate([8, 9, 0]) cube([1, 1, 4.909455690656948]);

color([0, 1, 0]) translate([9, 9, 0]) cube([1, 1, 4]);

translate([10, 9, 0]) cube([1, 1, 4.726802894523344]);

translate([11, 9, 0]) cube([1, 1, 4.530886117721726]);

color([0, 1, 0]) translate([12, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([14, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([15, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 9, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([17, 9, 0]) cube([1, 1, 4]);

translate([18, 9, 0]) cube([1, 1, 3.422719671324966]);

translate([19, 9, 0]) cube([1, 1, 2.861497302256143]);

translate([0, 10, 0]) cube([1, 1, 4.58394204039379]);

color([0, 1, 0]) translate([1, 10, 0]) cube([1, 1, 4]);

translate([2, 10, 0]) cube([1, 1, 4.570678059725773]);

color([0, 1, 0]) translate([3, 10, 0]) cube([1, 1, 4]);

translate([4, 10, 0]) cube([1, 1, 5.09210848679055]);

translate([5, 10, 0]) cube([1, 1, 4.674761282924153]);

translate([6, 10, 0]) cube([1, 1, 4.740066875191359]);

translate([7, 10, 0]) cube([1, 1, 4.9747612829241525]);

translate([8, 10, 0]) cube([1, 1, 4.609455690656948]);

translate([9, 10, 0]) cube([1, 1, 4.9747612829241525]);

translate([10, 10, 0]) cube([1, 1, 4.726802894523344]);

translate([11, 10, 0]) cube([1, 1, 4.830886117721726]);

color([0, 1, 0]) translate([12, 10, 0]) cube([1, 1, 4]);

translate([13, 10, 0]) cube([1, 1, 4.648233321588122]);

color([0, 1, 0]) translate([14, 10, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([15, 10, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 10, 0]) cube([1, 1, 4]);

translate([17, 10, 0]) cube([1, 1, 3.1747612829241545]);

color([0, 1, 0]) translate([18, 10, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([19, 10, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([0, 11, 0]) cube([1, 1, 4]);

translate([1, 11, 0]) cube([1, 1, 4.857414079057757]);

translate([2, 11, 0]) cube([1, 1, 4.674761282924153]);

translate([3, 11, 0]) cube([1, 1, 4.609455690656948]);

translate([4, 11, 0]) cube([1, 1, 4.596191709988933]);

translate([5, 11, 0]) cube([1, 1, 4.8961917099889325]);

translate([6, 11, 0]) cube([1, 1, 4.844150098389742]);

translate([7, 11, 0]) cube([1, 1, 4.79210848679055]);

translate([8, 11, 0]) cube([1, 1, 4.857414079057757]);

translate([9, 11, 0]) cube([1, 1, 4.740066875191359]);

translate([10, 11, 0]) cube([1, 1, 4.609455690656948]);

translate([11, 11, 0]) cube([1, 1, 4.530886117721726]);

color([0, 1, 0]) translate([12, 11, 0]) cube([1, 1, 4]);

translate([13, 11, 0]) cube([1, 1, 4.517622137053711]);

color([0, 1, 0]) translate([14, 11, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([15, 11, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 11, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([17, 11, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([18, 11, 0]) cube([1, 1, 4]);

translate([19, 11, 0]) cube([1, 1, 3.2788445061225406]);

color([0, 1, 0]) translate([0, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([1, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 12, 0]) cube([1, 1, 4]);

translate([3, 12, 0]) cube([1, 1, 4.8961917099889325]);

translate([4, 12, 0]) cube([1, 1, 4.582927729320917]);

translate([5, 12, 0]) cube([1, 1, 4.582927729320917]);

translate([6, 12, 0]) cube([1, 1, 4.530886117721726]);

translate([7, 12, 0]) cube([1, 1, 4.661497302256137]);

translate([8, 12, 0]) cube([1, 1, 4.740066875191359]);

translate([9, 12, 0]) cube([1, 1, 4.688025263592168]);

color([0, 1, 0]) translate([10, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([11, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 12, 0]) cube([1, 1, 4]);

translate([13, 12, 0]) cube([1, 1, 4.517622137053711]);

color([0, 1, 0]) translate([14, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([15, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 12, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([17, 12, 0]) cube([1, 1, 4]);

translate([18, 12, 0]) cube([1, 1, 3.2135389138553307]);

color([0, 1, 0]) translate([19, 12, 0]) cube([1, 1, 4]);

translate([0, 13, 0]) cube([1, 1, 3.4880252635921716]);

translate([1, 13, 0]) cube([1, 1, 4.674761282924154]);

translate([2, 13, 0]) cube([1, 1, 4.648233321588122]);

color([0, 1, 0]) translate([3, 13, 0]) cube([1, 1, 4]);

translate([4, 13, 0]) cube([1, 1, 4.700274933187313]);

color([0, 1, 0]) translate([5, 13, 0]) cube([1, 1, 4]);

translate([6, 13, 0]) cube([1, 1, 4.713538913855328]);

translate([7, 13, 0]) cube([1, 1, 4.778844506122535]);

translate([8, 13, 0]) cube([1, 1, 4.674761282924153]);

color([0, 1, 0]) translate([9, 13, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([10, 13, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([11, 13, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 13, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 13, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([14, 13, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([15, 13, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 13, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([17, 13, 0]) cube([1, 1, 4]);

translate([18, 13, 0]) cube([1, 1, 3.3308861177217297]);

translate([19, 13, 0]) cube([1, 1, 3.200274933187319]);

translate([0, 14, 0]) cube([1, 1, 4.505372467458569]);

color([0, 1, 0]) translate([1, 14, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 14, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 14, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 14, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 14, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 14, 0]) cube([1, 1, 4]);

translate([7, 14, 0]) cube([1, 1, 4.544150098389742]);

color([0, 1, 0]) translate([8, 14, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 14, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([10, 14, 0]) cube([1, 1, 4]);

translate([11, 14, 0]) cube([1, 1, 5.130886117721727]);

translate([12, 14, 0]) cube([1, 1, 4.530886117721726]);

translate([13, 14, 0]) cube([1, 1, 3.4482333215881225]);

color([0, 1, 0]) translate([14, 14, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([15, 14, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 14, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([17, 14, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([18, 14, 0]) cube([1, 1, 4]);

translate([19, 14, 0]) cube([1, 1, 3.2523165447865114]);

color([0, 1, 0]) translate([0, 15, 0]) cube([1, 1, 4]);

translate([1, 15, 0]) cube([1, 1, 4.844150098389744]);

color([0, 1, 0]) translate([2, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([6, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([7, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 15, 0]) cube([1, 1, 4]);

translate([10, 15, 0]) cube([1, 1, 4.8441500983897425]);

color([0, 1, 0]) translate([11, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 15, 0]) cube([1, 1, 4]);

translate([14, 15, 0]) cube([1, 1, 4.596191709988934]);

color([0, 1, 0]) translate([15, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([17, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([18, 15, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([19, 15, 0]) cube([1, 1, 4]);

translate([0, 16, 0]) cube([1, 1, 1.3094556906569532]);

color([0, 1, 0]) translate([1, 16, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 16, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 16, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 16, 0]) cube([1, 1, 4]);

translate([5, 16, 0]) cube([1, 1, 4.544150098389743]);

color([0, 1, 0]) translate([6, 16, 0]) cube([1, 1, 4]);

translate([7, 16, 0]) cube([1, 1, 4.805372467458566]);

color([0, 1, 0]) translate([8, 16, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 16, 0]) cube([1, 1, 4]);

translate([10, 16, 0]) cube([1, 1, 4.596191709988934]);

color([0, 1, 0]) translate([11, 16, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 16, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 16, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([14, 16, 0]) cube([1, 1, 4]);

translate([15, 16, 0]) cube([1, 1, 3.2655805254545216]);

color([0, 1, 0]) translate([16, 16, 0]) cube([1, 1, 4]);

translate([17, 16, 0]) cube([1, 1, 4.582927729320922]);

color([0, 1, 0]) translate([18, 16, 0]) cube([1, 1, 4]);

translate([19, 16, 0]) cube([1, 1, 4.5043581563857025]);

translate([0, 17, 0]) cube([1, 1, 3.226802894523349]);

color([0, 1, 0]) translate([1, 17, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 17, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 17, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 17, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 17, 0]) cube([1, 1, 4]);

translate([6, 17, 0]) cube([1, 1, 4.557414079057759]);

color([0, 1, 0]) translate([7, 17, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([8, 17, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([9, 17, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([10, 17, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([11, 17, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 17, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 17, 0]) cube([1, 1, 4]);

translate([14, 17, 0]) cube([1, 1, 4.530886117721729]);

color([0, 1, 0]) translate([15, 17, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 17, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([17, 17, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([18, 17, 0]) cube([1, 1, 4]);

translate([19, 17, 0]) cube([1, 1, 2.965580525454527]);

color([0, 1, 0]) translate([0, 18, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([1, 18, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 18, 0]) cube([1, 1, 4]);

translate([3, 18, 0]) cube([1, 1, 3.448233321588125]);

color([0, 1, 0]) translate([4, 18, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([5, 18, 0]) cube([1, 1, 4]);

translate([6, 18, 0]) cube([1, 1, 4.5441500983897445]);

color([0, 1, 0]) translate([7, 18, 0]) cube([1, 1, 4]);

translate([8, 18, 0]) cube([1, 1, 4.596191709988936]);

color([0, 1, 0]) translate([9, 18, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([10, 18, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([11, 18, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([12, 18, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 18, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([14, 18, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([15, 18, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 18, 0]) cube([1, 1, 4]);

translate([17, 18, 0]) cube([1, 1, 3.200274933187318]);

translate([18, 18, 0]) cube([1, 1, 3.148233321588127]);

color([0, 1, 0]) translate([19, 18, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([0, 19, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([1, 19, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([2, 19, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([3, 19, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([4, 19, 0]) cube([1, 1, 4]);

translate([5, 19, 0]) cube([1, 1, 2.3002749331873193]);

translate([6, 19, 0]) cube([1, 1, 1.70027493318732]);

translate([7, 19, 0]) cube([1, 1, 2.35231654478651]);

translate([8, 19, 0]) cube([1, 1, 2.0523165447865113]);

translate([9, 19, 0]) cube([1, 1, 4.582927729320923]);

translate([10, 19, 0]) cube([1, 1, 3.448233321588127]);

translate([11, 19, 0]) cube([1, 1, 3.096191709988939]);

color([0, 1, 0]) translate([12, 19, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([13, 19, 0]) cube([1, 1, 4]);

translate([14, 19, 0]) cube([1, 1, 3.317622137053717]);

color([0, 1, 0]) translate([15, 19, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([16, 19, 0]) cube([1, 1, 4]);

translate([17, 19, 0]) cube([1, 1, 2.7829277293209245]);

color([0, 1, 0]) translate([18, 19, 0]) cube([1, 1, 4]);

color([0, 1, 0]) translate([19, 19, 0]) cube([1, 1, 4]);
