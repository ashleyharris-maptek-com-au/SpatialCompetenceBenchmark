
hull() {
    translate([0.05, 0.0, 9.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9500000000000001, 0.0, 9.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.05, 0.0, 8.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9500000000000002, 0.0, 8.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.05, 0.0, 8.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.95, 0.0, 8.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0500000000000003, 0.0, 7.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.95, 0.0, 7.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.05, 0.0, 6.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.95, 0.0, 6.050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.05, 0.0, 5.94]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.95, 0.0, 4.86]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.050000000000001, 0.0, 4.735]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.95, 0.0, 3.565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.05, 0.0, 3.435]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.95, 0.0, 2.265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.05, 0.0, 2.14]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.95, 0.0, 1.06]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.049999999999999, 0.0, 0.9500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.95, 0.0, 0.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.025, 0.025, 0.005000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.475000000000001, 0.47500000000000003, 0.09500000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.525, 0.525, 0.11000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.975, 0.9750000000000001, 0.29000000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.025, 1.025, 0.315]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.475, 1.475, 0.5850000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.525, 1.5250000000000001, 0.6200000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.975000000000001, 1.975, 0.98]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.025, 2.025, 1.025]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.475, 2.475, 1.475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.525, 2.525, 1.53]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.975000000000001, 2.975, 2.0700000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.025000000000002, 3.0250000000000004, 2.1350000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.475000000000001, 3.475, 2.765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.525, 3.525, 2.84]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.975, 3.975, 3.5600000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.025, 4.025, 3.6450000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.475000000000001, 4.475, 4.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.525, 4.5249999999999995, 4.55]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.975, 4.975, 5.45]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.99, 5.015, 5.515000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.81, 5.284999999999999, 5.785]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.775, 5.319999999999999, 5.81]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.325000000000001, 5.68, 5.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.270000000000001, 5.72, 6.005000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.73, 6.08, 6.095000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.665, 6.12, 6.095000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.035, 6.48, 6.005000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.96, 6.5200000000000005, 5.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.24, 6.880000000000001, 5.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.16, 6.920000000000001, 5.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.44, 7.28, 5.515000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.355, 7.32, 5.48]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.545000000000002, 7.680000000000001, 5.12]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.455000000000002, 7.720000000000001, 5.075]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.645000000000001, 8.08, 4.625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.555, 8.120000000000001, 4.569999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.745, 8.48, 4.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.655, 8.52, 3.965]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.845, 8.879999999999999, 3.335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.755, 8.92, 3.26]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.945000000000001, 9.280000000000001, 2.54]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.855, 9.32, 2.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.045, 9.68, 1.6450000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.955, 9.72, 1.5550000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.145, 10.08, 0.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.055, 10.12, 0.665]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.245, 10.48, 0.034999999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.165, 10.525, 0.005000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.535, 10.975, 0.09500000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.465, 11.025, 0.11000000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.835, 11.475, 0.29000000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.765, 11.525, 0.315]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1350000000000002, 11.975000000000001, 0.5850000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.065, 12.025, 0.6200000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.435, 12.475, 0.98]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.365, 12.525, 1.025]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.735, 12.975000000000001, 1.475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.665, 13.025000000000002, 1.53]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.034999999999999996, 13.475000000000001, 2.0700000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.010000000000000002, 13.525, 2.1350000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.19000000000000003, 13.975, 2.765]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.21500000000000002, 14.025, 2.84]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.485, 14.475000000000001, 3.5600000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.525, 14.525, 3.6450000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9750000000000001, 14.975, 4.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.025, 14.99, 4.5249999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.475, 14.81, 4.975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.53, 14.785, 5.02]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.0700000000000003, 14.515, 5.380000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1350000000000002, 14.48, 5.415]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.765, 14.12, 5.685]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.84, 14.08, 5.71]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.5600000000000005, 13.72, 5.890000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6450000000000005, 13.675, 5.905]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.455, 13.225, 5.995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.55, 13.174999999999999, 5.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.45, 12.725, 5.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.550000000000001, 12.675, 5.890000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.450000000000001, 12.225000000000001, 5.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.555000000000001, 12.175, 5.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.545, 11.725, 5.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.654999999999999, 11.674999999999999, 5.375]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.645, 11.225, 4.925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.76, 11.175, 4.87]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.84, 10.725, 4.33]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.96, 10.674999999999999, 4.265000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.040000000000001, 10.225, 3.6350000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.165000000000001, 10.174999999999999, 3.5600000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.335, 9.725, 2.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.465, 9.675, 2.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.635, 9.225, 1.9449999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.765, 9.174999999999999, 1.8499999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.935, 8.725, 0.9500000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.985, 8.68, 0.8900000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.715, 8.32, 0.71]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.68, 8.280000000000001, 0.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.32, 7.920000000000001, 0.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.280000000000001, 7.880000000000001, 0.5950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.92, 7.52, 0.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.875, 7.48, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.425, 7.119999999999999, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.375, 7.08, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.925, 6.720000000000001, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.875000000000002, 6.680000000000001, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.425, 6.32, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.375, 6.28, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.925, 5.920000000000001, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.875, 5.880000000000001, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.425, 5.5200000000000005, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.375, 5.48, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.925, 5.12, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.875, 5.08, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.425, 4.720000000000001, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.375000000000002, 4.680000000000001, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.925, 4.32, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.875, 4.28, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.425, 3.92, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.375, 3.88, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.925, 3.52, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.875, 3.48, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.425, 3.12, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.375, 3.08, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.925000000000001, 2.72, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.875, 2.68, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.425000000000001, 2.32, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.375, 2.28, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.925000000000001, 1.92, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.875000000000001, 1.88, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.425000000000001, 1.52, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.375000000000001, 1.48, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.925000000000001, 1.12, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.875000000000001, 1.08, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.425000000000001, 0.72, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.375, 0.68, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.925, 0.32, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.875, 0.28500000000000003, 0.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.425000000000001, 0.015, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}

