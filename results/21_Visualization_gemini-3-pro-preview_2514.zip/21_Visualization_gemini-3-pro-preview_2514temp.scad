
hull() {
    translate([50.075, 50.0, 249.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.425000000000004, 50.0, 249.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.575, 50.0, 249.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.925000000000004, 50.0, 249.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.075, 50.0, 249.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.425000000000004, 50.0, 249.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.575, 50.0, 249.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.925, 50.0, 249.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.075, 50.0, 249.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.425, 50.0, 249.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.575, 50.0, 249.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.925000000000004, 50.0, 249.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.075, 50.0, 249.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.425000000000004, 50.0, 249.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.575, 50.0, 249.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.925000000000004, 50.0, 249.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.075, 50.0, 249.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.425, 50.0, 249.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.575, 50.0, 249.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.925, 50.0, 249.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.075, 50.0, 248.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.425, 50.0, 248.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.575, 50.0, 248.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.925, 50.0, 248.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.075, 50.0, 248.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.42500000000001, 50.0, 248.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.575, 50.0, 248.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.925, 50.0, 248.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.075, 50.0, 248.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.425, 50.0, 248.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.575, 50.0, 248.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.92500000000001, 50.0, 248.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.075, 50.0, 248.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.425, 50.0, 248.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.575, 50.0, 248.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.925, 50.0, 248.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.075, 50.0, 248.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.42500000000001, 50.0, 248.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.575, 50.0, 248.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.925, 50.0, 248.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.075, 50.0, 247.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.42500000000001, 50.0, 247.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.575, 50.0, 247.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.925, 50.0, 247.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.075, 50.0, 247.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.425, 50.0, 247.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.575, 50.0, 247.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.92500000000001, 50.0, 247.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.075, 50.0, 247.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.425, 50.0, 247.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.575, 50.0, 247.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.92500000000001, 50.0, 247.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.075, 50.0, 247.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.425, 50.0, 247.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.575, 50.0, 247.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.925, 50.0, 247.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.075, 50.0, 247.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.42500000000001, 50.0, 247.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.575, 50.0, 247.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.925, 50.0, 247.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.075, 50.0, 246.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.42500000000001, 50.0, 246.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.57500000000002, 50.0, 246.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.92500000000001, 50.0, 246.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.075, 50.0, 246.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.425, 50.0, 246.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.575, 50.0, 246.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.92500000000001, 50.0, 246.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.075, 50.0, 246.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.425, 50.0, 246.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.575, 50.0, 246.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.92500000000001, 50.0, 246.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.07500000000002, 50.0, 246.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.42500000000001, 50.0, 246.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.575, 50.0, 246.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.925, 50.0, 246.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.075, 50.0, 246.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.42500000000001, 50.0, 246.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.575, 50.0, 246.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.925, 50.0, 246.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.075, 50.0, 245.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([111.42500000000001, 50.0, 245.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.57500000000002, 50.0, 245.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.92500000000001, 50.0, 245.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.075, 50.0, 245.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([114.425, 50.0, 245.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.575, 50.0, 245.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.92500000000001, 50.0, 245.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.075, 50.0, 245.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.425, 50.0, 245.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.575, 50.0, 245.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.92500000000001, 50.0, 245.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.07500000000002, 50.0, 245.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.42500000000001, 50.0, 245.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.575, 50.0, 245.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.925, 50.0, 245.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.075, 50.0, 245.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([123.42500000000001, 50.0, 245.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.575, 50.0, 245.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.925, 50.0, 245.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.075, 50.0, 244.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([126.42500000000001, 50.0, 244.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.57500000000002, 50.0, 244.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.92500000000001, 50.0, 244.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.075, 50.0, 244.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([129.425, 50.0, 244.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([129.575, 50.0, 244.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([130.925, 50.0, 244.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([131.07500000000002, 50.0, 244.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([132.425, 50.0, 244.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([132.575, 50.0, 244.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([133.925, 50.0, 244.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([134.07500000000002, 50.0, 244.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.425, 50.0, 244.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.575, 50.0, 244.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.925, 50.0, 244.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([137.075, 50.0, 244.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([138.425, 50.0, 244.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([138.57500000000002, 50.0, 244.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([139.925, 50.0, 244.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([140.075, 50.0, 243.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([141.425, 50.0, 243.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([141.57500000000002, 50.0, 243.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([142.925, 50.0, 243.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([143.07500000000002, 50.0, 243.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([144.425, 50.0, 243.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([144.57500000000002, 50.0, 243.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([145.925, 50.0, 243.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([146.07500000000002, 50.0, 243.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([147.425, 50.0, 243.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([147.575, 50.0, 243.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([148.92499999999998, 50.0, 243.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([149.075, 50.0, 243.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.425, 50.0, 243.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.57500000000002, 50.0, 243.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.925, 50.0, 243.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([152.07500000000002, 50.0, 243.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([153.425, 50.0, 243.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([153.57500000000002, 50.0, 243.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([154.925, 50.0, 243.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.075, 50.0, 242.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([156.42499999999998, 50.0, 242.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([156.575, 50.0, 242.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([157.925, 50.0, 242.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([158.07500000000002, 50.0, 242.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([159.425, 50.0, 242.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.57500000000002, 50.0, 242.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([160.925, 50.0, 242.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([161.07500000000002, 50.0, 242.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([162.425, 50.0, 242.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.575, 50.0, 242.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([163.92499999999998, 50.0, 242.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([164.075, 50.0, 242.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([165.425, 50.0, 242.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.57500000000002, 50.0, 242.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([166.925, 50.0, 242.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.07500000000002, 50.0, 242.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.425, 50.0, 242.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.57500000000002, 50.0, 242.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([169.925, 50.0, 242.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([170.075, 50.0, 241.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([171.42499999999998, 50.0, 241.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([171.575, 50.0, 241.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([172.925, 50.0, 241.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([173.07500000000002, 50.0, 241.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([174.425, 50.0, 241.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([174.57500000000002, 50.0, 241.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([175.925, 50.0, 241.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.07500000000002, 50.0, 241.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([177.425, 50.0, 241.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([177.575, 50.0, 241.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([178.92499999999998, 50.0, 241.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([179.075, 50.0, 241.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([180.425, 50.0, 241.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.57500000000002, 50.0, 241.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([181.925, 50.0, 241.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([182.07500000000002, 50.0, 241.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([183.425, 50.0, 241.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.57500000000002, 50.0, 241.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([184.925, 50.0, 241.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([185.075, 50.0, 240.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([186.42499999999998, 50.0, 240.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([186.575, 50.0, 240.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([187.925, 50.0, 240.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([188.07500000000002, 50.0, 240.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([189.425, 50.0, 240.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([189.57500000000002, 50.0, 240.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([190.925, 50.0, 240.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([191.07500000000002, 50.0, 240.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([192.425, 50.0, 240.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.575, 50.0, 240.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([193.925, 50.0, 240.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.075, 50.0, 240.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([195.425, 50.0, 240.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.57500000000002, 50.0, 240.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([196.925, 50.0, 240.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([197.07500000000002, 50.0, 240.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([198.425, 50.0, 240.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([198.57500000000002, 50.0, 240.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.925, 50.0, 240.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.075, 50.0, 239.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([201.425, 50.0, 239.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([201.575, 50.0, 239.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([202.925, 50.0, 239.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([203.07500000000002, 50.0, 239.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([204.425, 50.0, 239.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([204.57500000000002, 50.0, 239.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([205.925, 50.0, 239.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([206.07500000000002, 50.0, 239.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([207.425, 50.0, 239.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([207.575, 50.0, 239.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([208.925, 50.0, 239.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([209.075, 50.0, 239.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([210.425, 50.0, 239.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([210.57500000000002, 50.0, 239.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([211.925, 50.0, 239.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([212.07500000000002, 50.0, 239.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([213.425, 50.0, 239.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([213.57500000000002, 50.0, 239.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([214.925, 50.0, 239.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([215.075, 50.0, 238.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([216.425, 50.0, 238.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.575, 50.0, 238.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([217.925, 50.0, 238.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([218.07500000000002, 50.0, 238.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([219.425, 50.0, 238.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([219.57500000000002, 50.0, 238.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([220.925, 50.0, 238.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([221.07500000000002, 50.0, 238.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([222.425, 50.0, 238.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([222.575, 50.0, 238.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([223.925, 50.0, 238.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.075, 50.0, 238.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([225.425, 50.0, 238.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([225.57500000000002, 50.0, 238.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([226.925, 50.0, 238.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.07500000000002, 50.0, 238.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([228.425, 50.0, 238.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([228.57500000000002, 50.0, 238.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([229.925, 50.0, 238.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([230.075, 50.0, 237.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([231.425, 50.0, 237.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([231.575, 50.0, 237.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([232.925, 50.0, 237.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([233.07500000000002, 50.0, 237.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([234.425, 50.0, 237.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([234.57500000000002, 50.0, 237.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([235.925, 50.0, 237.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([236.07500000000002, 50.0, 237.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([237.425, 50.0, 237.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([237.575, 50.0, 237.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([238.925, 50.0, 237.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([239.075, 50.0, 237.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([240.425, 50.0, 237.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([240.57500000000002, 50.0, 237.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([241.925, 50.0, 237.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([242.07500000000002, 50.0, 237.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([243.425, 50.0, 237.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([243.57500000000002, 50.0, 237.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([244.925, 50.0, 237.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([245.075, 50.0, 236.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([246.425, 50.0, 236.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([246.575, 50.0, 236.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([247.925, 50.0, 236.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([248.07500000000002, 50.0, 236.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([249.425, 50.0, 236.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([249.525, 50.075, 236.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([249.975, 51.425000000000004, 236.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 51.575, 236.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 52.925000000000004, 236.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 53.075, 236.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 54.425000000000004, 236.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 54.575, 236.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 55.925, 236.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 56.075, 236.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 57.425, 236.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 57.575, 236.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 58.925000000000004, 236.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 59.075, 236.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 60.425000000000004, 236.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 60.575, 235.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 61.925000000000004, 235.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 62.075, 235.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 63.425, 235.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 63.575, 235.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 64.925, 235.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 65.075, 235.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 66.425, 235.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 66.575, 235.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 67.925, 235.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 68.075, 235.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 69.42500000000001, 235.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 69.575, 235.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 70.925, 235.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 71.075, 235.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 72.425, 235.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 72.575, 235.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 73.92500000000001, 235.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 74.075, 235.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 75.425, 235.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 75.575, 234.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 76.925, 234.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 77.075, 234.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 78.42500000000001, 234.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 78.575, 234.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 79.925, 234.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 80.075, 234.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 81.42500000000001, 234.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 81.575, 234.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 82.925, 234.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 83.075, 234.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 84.425, 234.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 84.575, 234.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 85.92500000000001, 234.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 86.075, 234.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 87.425, 234.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 87.575, 234.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 88.92500000000001, 234.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 89.075, 234.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 90.425, 234.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 90.575, 233.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 91.925, 233.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 92.075, 233.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 93.42500000000001, 233.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 93.575, 233.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 94.925, 233.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 95.075, 233.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 96.42500000000001, 233.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 96.57500000000002, 233.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 97.92500000000001, 233.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 98.075, 233.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 99.425, 233.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 99.575, 233.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 100.92500000000001, 233.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 101.075, 233.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 102.425, 233.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 102.575, 233.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 103.92500000000001, 233.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 104.07500000000002, 233.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 105.42500000000001, 233.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 105.575, 232.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 106.925, 232.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 107.075, 232.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 108.42500000000001, 232.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 108.575, 232.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 109.925, 232.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 110.075, 232.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 111.42500000000001, 232.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 111.57500000000002, 232.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 112.92500000000001, 232.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 113.075, 232.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 114.425, 232.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 114.575, 232.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 115.92500000000001, 232.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 116.075, 232.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 117.425, 232.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 117.575, 232.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 118.92500000000001, 232.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 119.07500000000002, 232.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 120.42500000000001, 232.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 120.575, 231.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 121.925, 231.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 122.075, 231.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 123.42500000000001, 231.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 123.575, 231.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 124.925, 231.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 125.075, 231.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 126.42500000000001, 231.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 126.57500000000002, 231.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 127.92500000000001, 231.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 128.075, 231.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 129.425, 231.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 129.575, 231.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 130.925, 231.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 131.07500000000002, 231.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 132.425, 231.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 132.575, 231.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 133.925, 231.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 134.07500000000002, 231.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 135.425, 231.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 135.575, 230.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 136.925, 230.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 137.075, 230.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 138.425, 230.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 138.57500000000002, 230.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 139.925, 230.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 140.075, 230.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 141.425, 230.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 141.57500000000002, 230.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 142.925, 230.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 143.07500000000002, 230.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 144.425, 230.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 144.57500000000002, 230.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 145.925, 230.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 146.07500000000002, 230.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 147.425, 230.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 147.575, 230.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 148.92499999999998, 230.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 149.075, 230.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 150.425, 230.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 150.57500000000002, 229.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 151.925, 229.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 152.07500000000002, 229.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 153.425, 229.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 153.57500000000002, 229.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 154.925, 229.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 155.075, 229.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 156.42499999999998, 229.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 156.575, 229.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 157.925, 229.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 158.07500000000002, 229.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 159.425, 229.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 159.57500000000002, 229.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 160.925, 229.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 161.07500000000002, 229.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 162.425, 229.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 162.575, 229.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 163.92499999999998, 229.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 164.075, 229.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 165.425, 229.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 165.57500000000002, 228.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 166.925, 228.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 167.07500000000002, 228.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 168.425, 228.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 168.57500000000002, 228.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 169.925, 228.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 170.075, 228.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 171.42499999999998, 228.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 171.575, 228.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 172.925, 228.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 173.07500000000002, 228.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 174.425, 228.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 174.57500000000002, 228.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 175.925, 228.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 176.07500000000002, 228.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 177.425, 228.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 177.575, 228.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 178.92499999999998, 228.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 179.075, 228.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 180.425, 228.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 180.57500000000002, 227.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 181.925, 227.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 182.07500000000002, 227.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 183.425, 227.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 183.57500000000002, 227.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 184.925, 227.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 185.075, 227.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 186.42499999999998, 227.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 186.575, 227.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 187.925, 227.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 188.07500000000002, 227.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 189.425, 227.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 189.57500000000002, 227.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 190.925, 227.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 191.07500000000002, 227.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 192.425, 227.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 192.575, 227.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 193.925, 227.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 194.075, 227.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 195.425, 227.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 195.57500000000002, 226.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 196.925, 226.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 197.07500000000002, 226.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 198.425, 226.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 198.57500000000002, 226.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 199.925, 226.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 200.075, 226.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 201.425, 226.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 201.575, 226.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 202.925, 226.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 203.07500000000002, 226.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 204.425, 226.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 204.57500000000002, 226.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 205.925, 226.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 206.07500000000002, 226.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 207.425, 226.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 207.575, 226.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 208.925, 226.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 209.075, 226.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 210.425, 226.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 210.57500000000002, 225.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 211.925, 225.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 212.07500000000002, 225.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 213.425, 225.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 213.57500000000002, 225.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 214.925, 225.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 215.075, 225.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 216.425, 225.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 216.575, 225.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 217.925, 225.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 218.07500000000002, 225.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 219.425, 225.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 219.57500000000002, 225.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 220.925, 225.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 221.07500000000002, 225.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 222.425, 225.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 222.575, 225.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 223.925, 225.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 224.075, 225.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 225.425, 225.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 225.57500000000002, 224.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 226.925, 224.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 227.07500000000002, 224.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 228.425, 224.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 228.57500000000002, 224.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 229.925, 224.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 230.075, 224.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 231.425, 224.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 231.575, 224.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 232.925, 224.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 233.07500000000002, 224.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 234.425, 224.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 234.57500000000002, 224.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 235.925, 224.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 236.07500000000002, 224.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 237.425, 224.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 237.575, 224.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 238.925, 224.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 239.075, 224.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 240.425, 224.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 240.57500000000002, 223.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 241.925, 223.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 242.07500000000002, 223.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 243.425, 223.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 243.57500000000002, 223.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 244.925, 223.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 245.075, 223.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 246.425, 223.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 246.575, 223.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 247.925, 223.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 248.07500000000002, 223.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 249.425, 223.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([249.925, 249.525, 223.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([248.57500000000002, 249.975, 223.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([248.425, 250.0, 223.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([247.07500000000002, 250.0, 223.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([246.925, 250.0, 223.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([245.57500000000002, 250.0, 223.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([245.425, 250.0, 223.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([244.075, 250.0, 223.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([243.925, 250.0, 222.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([242.575, 250.0, 222.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([242.425, 250.0, 222.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([241.07500000000002, 250.0, 222.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([240.925, 250.0, 222.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([239.57500000000002, 250.0, 222.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([239.425, 250.0, 222.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([238.07500000000002, 250.0, 222.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([237.925, 250.0, 222.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([236.575, 250.0, 222.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([236.425, 250.0, 222.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([235.075, 250.0, 222.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([234.925, 250.0, 222.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([233.57500000000002, 250.0, 222.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([233.425, 250.0, 222.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([232.07500000000002, 250.0, 222.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([231.925, 250.0, 222.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([230.57500000000002, 250.0, 222.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([230.425, 250.0, 222.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([229.075, 250.0, 222.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([228.925, 250.0, 221.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([227.575, 250.0, 221.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.425, 250.0, 221.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([226.07500000000002, 250.0, 221.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([225.925, 250.0, 221.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([224.57500000000002, 250.0, 221.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.425, 250.0, 221.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([223.07500000000002, 250.0, 221.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([222.925, 250.0, 221.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([221.575, 250.0, 221.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([221.425, 250.0, 221.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([220.075, 250.0, 221.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([219.925, 250.0, 221.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([218.57500000000002, 250.0, 221.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([218.425, 250.0, 221.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([217.07500000000002, 250.0, 221.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.925, 250.0, 221.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([215.57500000000002, 250.0, 221.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([215.425, 250.0, 221.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([214.075, 250.0, 221.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([213.925, 250.0, 220.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([212.575, 250.0, 220.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([212.425, 250.0, 220.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([211.07500000000002, 250.0, 220.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([210.925, 250.0, 220.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([209.57500000000002, 250.0, 220.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([209.425, 250.0, 220.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([208.07500000000002, 250.0, 220.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([207.925, 250.0, 220.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([206.575, 250.0, 220.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([206.425, 250.0, 220.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([205.075, 250.0, 220.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([204.925, 250.0, 220.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([203.57500000000002, 250.0, 220.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([203.425, 250.0, 220.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([202.07500000000002, 250.0, 220.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([201.925, 250.0, 220.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([200.57500000000002, 250.0, 220.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.425, 250.0, 220.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.075, 250.0, 220.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([198.925, 250.0, 219.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([197.575, 250.0, 219.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([197.425, 250.0, 219.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([196.07500000000002, 250.0, 219.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.925, 250.0, 219.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([194.57500000000002, 250.0, 219.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.425, 250.0, 219.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([193.07500000000002, 250.0, 219.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.925, 250.0, 219.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([191.575, 250.0, 219.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([191.42499999999998, 250.0, 219.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([190.075, 250.0, 219.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([189.925, 250.0, 219.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([188.57500000000002, 250.0, 219.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([188.425, 250.0, 219.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([187.07500000000002, 250.0, 219.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([186.925, 250.0, 219.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([185.57500000000002, 250.0, 219.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([185.425, 250.0, 219.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([184.075, 250.0, 219.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.92499999999998, 250.0, 218.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([182.575, 250.0, 218.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([182.425, 250.0, 218.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([181.07500000000002, 250.0, 218.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.925, 250.0, 218.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([179.57500000000002, 250.0, 218.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([179.425, 250.0, 218.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([178.07500000000002, 250.0, 218.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([177.925, 250.0, 218.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([176.575, 250.0, 218.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.42499999999998, 250.0, 218.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([175.075, 250.0, 218.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([174.925, 250.0, 218.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([173.57500000000002, 250.0, 218.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([173.425, 250.0, 218.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([172.07500000000002, 250.0, 218.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([171.925, 250.0, 218.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([170.57500000000002, 250.0, 218.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([170.425, 250.0, 218.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([169.075, 250.0, 218.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.92499999999998, 250.0, 217.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([167.575, 250.0, 217.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.425, 250.0, 217.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([166.07500000000002, 250.0, 217.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.925, 250.0, 217.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([164.57500000000002, 250.0, 217.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([164.425, 250.0, 217.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([163.07500000000002, 250.0, 217.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.925, 250.0, 217.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([161.575, 250.0, 217.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([161.42499999999998, 250.0, 217.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([160.075, 250.0, 217.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.925, 250.0, 217.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([158.57500000000002, 250.0, 217.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([158.425, 250.0, 217.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([157.07500000000002, 250.0, 217.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([156.925, 250.0, 217.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([155.57500000000002, 250.0, 217.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.425, 250.0, 217.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([154.075, 250.0, 217.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([153.92499999999998, 250.0, 216.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([152.575, 250.0, 216.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([152.425, 250.0, 216.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.07500000000002, 250.0, 216.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.925, 250.0, 216.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([149.57500000000002, 250.0, 216.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([149.425, 250.0, 216.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([148.07500000000002, 250.0, 216.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([147.925, 250.0, 216.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([146.575, 250.0, 216.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([146.42499999999998, 250.0, 216.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([145.075, 250.0, 216.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([144.925, 250.0, 216.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([143.57500000000002, 250.0, 216.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([143.425, 250.0, 216.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([142.075, 250.0, 216.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([141.925, 250.0, 216.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([140.575, 250.0, 216.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([140.425, 250.0, 216.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([139.07500000000002, 250.0, 216.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([138.925, 250.0, 215.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([137.575, 250.0, 215.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([137.425, 250.0, 215.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.07500000000002, 250.0, 215.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.925, 250.0, 215.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([134.575, 250.0, 215.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([134.425, 250.0, 215.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([133.075, 250.0, 215.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([132.925, 250.0, 215.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([131.57500000000002, 250.0, 215.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([131.425, 250.0, 215.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([130.075, 250.0, 215.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([129.925, 250.0, 215.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([128.57500000000002, 250.0, 215.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.425, 250.0, 215.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.075, 250.0, 215.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.925, 250.0, 215.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([125.575, 250.0, 215.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.42500000000001, 250.0, 215.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.07500000000002, 250.0, 215.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.92500000000001, 250.0, 214.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([122.575, 250.0, 214.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.425, 250.0, 214.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.075, 250.0, 214.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.92500000000001, 250.0, 214.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.575, 250.0, 214.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.425, 250.0, 214.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.075, 250.0, 214.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.92500000000001, 250.0, 214.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.57500000000002, 250.0, 214.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.42500000000001, 250.0, 214.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.075, 250.0, 214.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.925, 250.0, 214.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([113.575, 250.0, 214.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.42500000000001, 250.0, 214.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.075, 250.0, 214.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.925, 250.0, 214.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([110.575, 250.0, 214.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.42500000000001, 250.0, 214.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.07500000000002, 250.0, 214.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.92500000000001, 250.0, 213.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.575, 250.0, 213.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.425, 250.0, 213.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.075, 250.0, 213.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.92500000000001, 250.0, 213.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.575, 250.0, 213.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.425, 250.0, 213.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.075, 250.0, 213.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.92500000000001, 250.0, 213.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([101.57500000000002, 250.0, 213.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.42500000000001, 250.0, 213.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.075, 250.0, 213.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.925, 250.0, 213.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.575, 250.0, 213.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.42500000000001, 250.0, 213.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.075, 250.0, 213.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.925, 250.0, 213.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.575, 250.0, 213.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.425, 250.0, 213.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.075, 250.0, 213.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.92500000000001, 250.0, 212.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.575, 250.0, 212.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.425, 250.0, 212.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.075, 250.0, 212.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.92500000000001, 250.0, 212.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.575, 250.0, 212.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.425, 250.0, 212.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.075, 250.0, 212.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.925, 250.0, 212.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.575, 250.0, 212.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.42500000000001, 250.0, 212.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.075, 250.0, 212.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.925, 250.0, 212.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.575, 250.0, 212.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.42500000000001, 250.0, 212.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.075, 250.0, 212.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.925, 250.0, 212.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.575, 250.0, 212.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.425, 250.0, 212.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.075, 250.0, 212.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.92500000000001, 250.0, 211.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.575, 250.0, 211.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.425, 250.0, 211.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.075, 250.0, 211.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.92500000000001, 250.0, 211.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.575, 250.0, 211.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.425, 250.0, 211.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.075, 250.0, 211.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.925, 250.0, 211.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.575, 250.0, 211.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.42500000000001, 250.0, 211.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.075, 250.0, 211.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.925, 250.0, 211.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.575, 250.0, 211.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.425, 250.0, 211.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.075, 250.0, 211.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.92500000000001, 250.0, 211.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.575, 250.0, 211.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.425, 250.0, 211.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.075, 250.0, 211.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.925000000000004, 250.0, 210.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.575, 250.0, 210.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.425, 250.0, 210.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.075, 250.0, 210.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.925, 250.0, 210.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.575, 250.0, 210.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.425000000000004, 250.0, 210.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.075, 250.0, 210.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.925000000000004, 250.0, 210.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.575, 250.0, 210.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.425000000000004, 250.0, 210.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.075, 250.0, 210.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.925, 250.0, 210.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.575, 250.0, 210.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.425, 250.0, 210.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.075, 250.0, 210.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.925000000000004, 250.0, 210.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.575, 250.0, 210.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.475, 249.925, 210.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.025, 248.57500000000002, 210.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 248.425, 209.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 247.07500000000002, 209.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 246.925, 209.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 245.57500000000002, 209.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 245.425, 209.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 244.075, 209.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 243.925, 209.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 242.575, 209.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 242.425, 209.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 241.07500000000002, 209.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 240.925, 209.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 239.57500000000002, 209.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 239.425, 209.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 238.07500000000002, 209.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 237.925, 209.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 236.575, 209.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 236.425, 209.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 235.075, 209.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 234.925, 209.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 233.57500000000002, 209.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 233.425, 208.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 232.07500000000002, 208.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 231.925, 208.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 230.57500000000002, 208.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 230.425, 208.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 229.075, 208.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 228.925, 208.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 227.575, 208.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 227.425, 208.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 226.07500000000002, 208.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 225.925, 208.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 224.57500000000002, 208.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 224.425, 208.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 223.07500000000002, 208.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 222.925, 208.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 221.575, 208.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 221.425, 208.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 220.075, 208.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 219.925, 208.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 218.57500000000002, 208.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 218.425, 207.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 217.07500000000002, 207.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 216.925, 207.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 215.57500000000002, 207.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 215.425, 207.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 214.075, 207.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 213.925, 207.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 212.575, 207.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 212.425, 207.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 211.07500000000002, 207.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 210.925, 207.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 209.57500000000002, 207.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 209.425, 207.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 208.07500000000002, 207.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 207.925, 207.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 206.575, 207.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 206.425, 207.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 205.075, 207.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 204.925, 207.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 203.57500000000002, 207.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 203.425, 206.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 202.07500000000002, 206.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 201.925, 206.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 200.57500000000002, 206.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 200.425, 206.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 199.075, 206.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 198.925, 206.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 197.575, 206.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 197.425, 206.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 196.07500000000002, 206.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 195.925, 206.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 194.57500000000002, 206.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 194.425, 206.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 193.07500000000002, 206.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 192.925, 206.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 191.575, 206.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 191.42499999999998, 206.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 190.075, 206.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 189.925, 206.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 188.57500000000002, 206.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 188.425, 205.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 187.07500000000002, 205.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 186.925, 205.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 185.57500000000002, 205.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 185.425, 205.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 184.075, 205.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 183.92499999999998, 205.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 182.575, 205.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 182.425, 205.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 181.07500000000002, 205.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 180.925, 205.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 179.57500000000002, 205.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 179.425, 205.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 178.07500000000002, 205.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 177.925, 205.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 176.575, 205.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 176.42499999999998, 205.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 175.075, 205.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 174.925, 205.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 173.57500000000002, 205.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 173.425, 204.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 172.07500000000002, 204.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 171.925, 204.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 170.57500000000002, 204.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 170.425, 204.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 169.075, 204.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 168.92499999999998, 204.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 167.575, 204.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 167.425, 204.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 166.07500000000002, 204.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 165.925, 204.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 164.57500000000002, 204.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 164.425, 204.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 163.07500000000002, 204.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 162.925, 204.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 161.575, 204.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 161.42499999999998, 204.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 160.075, 204.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 159.925, 204.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 158.57500000000002, 204.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 158.425, 203.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 157.07500000000002, 203.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 156.925, 203.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 155.57500000000002, 203.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 155.425, 203.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 154.075, 203.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 153.92499999999998, 203.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 152.575, 203.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 152.425, 203.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 151.07500000000002, 203.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 150.925, 203.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 149.57500000000002, 203.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 149.425, 203.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 148.07500000000002, 203.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 147.925, 203.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 146.575, 203.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 146.42499999999998, 203.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 145.075, 203.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 144.925, 203.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 143.57500000000002, 203.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 143.425, 202.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 142.075, 202.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 141.925, 202.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 140.575, 202.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 140.425, 202.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 139.07500000000002, 202.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 138.925, 202.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 137.575, 202.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 137.425, 202.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 136.07500000000002, 202.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 135.925, 202.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 134.575, 202.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 134.425, 202.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 133.075, 202.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 132.925, 202.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 131.57500000000002, 202.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 131.425, 202.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 130.075, 202.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 129.925, 202.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 128.57500000000002, 202.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 128.425, 201.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 127.075, 201.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 126.925, 201.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 125.575, 201.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 125.42500000000001, 201.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 124.07500000000002, 201.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 123.92500000000001, 201.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 122.575, 201.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 122.425, 201.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 121.075, 201.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 120.92500000000001, 201.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 119.575, 201.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 119.425, 201.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 118.075, 201.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 117.92500000000001, 201.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 116.57500000000002, 201.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 116.42500000000001, 201.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 115.075, 201.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 114.925, 201.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 113.575, 201.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 113.42500000000001, 200.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 112.075, 200.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 111.925, 200.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 110.575, 200.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 110.42500000000001, 200.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 109.07500000000002, 200.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 108.92500000000001, 200.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 107.575, 200.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 107.425, 200.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 106.075, 200.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 105.92500000000001, 200.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 104.575, 200.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 104.425, 200.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 103.075, 200.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 102.92500000000001, 200.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 101.57500000000002, 200.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 101.42500000000001, 200.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 100.075, 200.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 99.925, 200.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 98.575, 200.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 98.42500000000001, 199.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 97.075, 199.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 96.925, 199.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 95.575, 199.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 95.425, 199.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 94.075, 199.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 93.92500000000001, 199.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 92.575, 199.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 92.425, 199.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 91.075, 199.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 90.92500000000001, 199.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 89.575, 199.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 89.425, 199.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 88.075, 199.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 87.925, 199.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 86.575, 199.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 86.42500000000001, 199.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 85.075, 199.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 84.925, 199.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 83.575, 199.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 83.42500000000001, 198.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 82.075, 198.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 81.925, 198.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 80.575, 198.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 80.425, 198.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 79.075, 198.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 78.92500000000001, 198.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 77.575, 198.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 77.425, 198.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 76.075, 198.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 75.92500000000001, 198.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 74.575, 198.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 74.425, 198.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 73.075, 198.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 72.925, 198.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 71.575, 198.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 71.42500000000001, 198.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 70.075, 198.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 69.925, 198.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 68.575, 198.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 68.425, 197.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 67.075, 197.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 66.92500000000001, 197.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 65.575, 197.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 65.425, 197.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 64.075, 197.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 63.925000000000004, 197.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 62.575, 197.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 62.425, 197.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 61.075, 197.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 60.925, 197.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 59.575, 197.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 59.425000000000004, 197.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 58.075, 197.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 57.925000000000004, 197.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 56.575, 197.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 56.425000000000004, 197.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 55.075, 197.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 54.925, 197.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 53.575, 197.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 53.425, 196.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 52.075, 196.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 51.925000000000004, 196.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.575, 196.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.075, 50.475, 196.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.425000000000004, 50.025, 196.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.575, 50.0, 196.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.925000000000004, 50.0, 196.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.075, 50.0, 196.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.425000000000004, 50.0, 196.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.575, 50.0, 196.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.925, 50.0, 196.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.075, 50.0, 196.39500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.425, 50.0, 196.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.575, 50.0, 196.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.925000000000004, 50.0, 196.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.075, 50.0, 196.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.425000000000004, 50.0, 196.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.575, 50.0, 196.09500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.925000000000004, 50.0, 196.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.075, 50.0, 195.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.425, 50.0, 195.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.575, 50.0, 195.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.925, 50.0, 195.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.075, 50.0, 195.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.425, 50.0, 195.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.575, 50.0, 195.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.925, 50.0, 195.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.075, 50.0, 195.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.42500000000001, 50.0, 195.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.575, 50.0, 195.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.925, 50.0, 195.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.075, 50.0, 195.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.425, 50.0, 195.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.575, 50.0, 195.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.92500000000001, 50.0, 195.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.075, 50.0, 195.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.425, 50.0, 195.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.575, 50.0, 195.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.925, 50.0, 195.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.075, 50.0, 194.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.42500000000001, 50.0, 194.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.575, 50.0, 194.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.925, 50.0, 194.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.075, 50.0, 194.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.42500000000001, 50.0, 194.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.575, 50.0, 194.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.925, 50.0, 194.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.075, 50.0, 194.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.425, 50.0, 194.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.575, 50.0, 194.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.92500000000001, 50.0, 194.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.075, 50.0, 194.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.425, 50.0, 194.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.575, 50.0, 194.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.92500000000001, 50.0, 194.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.075, 50.0, 194.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.425, 50.0, 194.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.575, 50.0, 194.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.925, 50.0, 194.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.075, 50.0, 193.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.42500000000001, 50.0, 193.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.575, 50.0, 193.89500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.925, 50.0, 193.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.075, 50.0, 193.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.42500000000001, 50.0, 193.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.57500000000002, 50.0, 193.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.92500000000001, 50.0, 193.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.075, 50.0, 193.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.425, 50.0, 193.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.575, 50.0, 193.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.92500000000001, 50.0, 193.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.075, 50.0, 193.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.425, 50.0, 193.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.575, 50.0, 193.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.92500000000001, 50.0, 193.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.07500000000002, 50.0, 193.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.42500000000001, 50.0, 193.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.575, 50.0, 193.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.925, 50.0, 193.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.075, 50.0, 192.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.42500000000001, 50.0, 192.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.575, 50.0, 192.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.925, 50.0, 192.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.075, 50.0, 192.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([111.42500000000001, 50.0, 192.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.57500000000002, 50.0, 192.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.92500000000001, 50.0, 192.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.075, 50.0, 192.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([114.425, 50.0, 192.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.575, 50.0, 192.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.92500000000001, 50.0, 192.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.075, 50.0, 192.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.425, 50.0, 192.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.575, 50.0, 192.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.92500000000001, 50.0, 192.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.07500000000002, 50.0, 192.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.42500000000001, 50.0, 192.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.575, 50.0, 192.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.925, 50.0, 192.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.075, 50.0, 191.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([123.42500000000001, 50.0, 191.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.575, 50.0, 191.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.925, 50.0, 191.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.075, 50.0, 191.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([126.42500000000001, 50.0, 191.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.57500000000002, 50.0, 191.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.92500000000001, 50.0, 191.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.075, 50.0, 191.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([129.425, 50.0, 191.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([129.575, 50.0, 191.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([130.925, 50.0, 191.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([131.07500000000002, 50.0, 191.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([132.425, 50.0, 191.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([132.575, 50.0, 191.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([133.925, 50.0, 191.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([134.07500000000002, 50.0, 191.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.425, 50.0, 191.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.575, 50.0, 191.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.925, 50.0, 191.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([137.075, 50.0, 190.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([138.425, 50.0, 190.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([138.57500000000002, 50.0, 190.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([139.925, 50.0, 190.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([140.075, 50.0, 190.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([141.425, 50.0, 190.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([141.57500000000002, 50.0, 190.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([142.925, 50.0, 190.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([143.07500000000002, 50.0, 190.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([144.425, 50.0, 190.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([144.57500000000002, 50.0, 190.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([145.925, 50.0, 190.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([146.07500000000002, 50.0, 190.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([147.425, 50.0, 190.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([147.575, 50.0, 190.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([148.92499999999998, 50.0, 190.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([149.075, 50.0, 190.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.425, 50.0, 190.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.57500000000002, 50.0, 190.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.925, 50.0, 190.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([152.07500000000002, 50.0, 190.04]) cube([0.4, 0.4, 0.1], center=true);
    translate([153.425, 50.0, 190.76000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([153.57500000000002, 50.0, 190.92500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([154.925, 50.0, 193.17500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.075, 50.0, 193.51000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([156.42499999999998, 50.0, 197.29]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([156.575, 50.0, 197.71]) cube([0.4, 0.4, 0.1], center=true);
    translate([157.925, 50.0, 201.49]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([158.07500000000002, 50.0, 201.905]) cube([0.4, 0.4, 0.1], center=true);
    translate([159.425, 50.0, 205.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.57500000000002, 50.0, 205.96000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([160.925, 50.0, 208.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([161.07500000000002, 50.0, 209.125]) cube([0.4, 0.4, 0.1], center=true);
    translate([162.425, 50.0, 211.375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.575, 50.0, 211.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([163.92499999999998, 50.0, 213.21000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([164.075, 50.0, 213.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([165.425, 50.0, 214.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.57500000000002, 50.0, 214.525]) cube([0.4, 0.4, 0.1], center=true);
    translate([166.925, 50.0, 214.975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.07500000000002, 50.0, 214.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.425, 50.0, 214.81000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.57500000000002, 50.0, 214.75500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([169.925, 50.0, 213.94500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([170.075, 50.0, 213.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([171.42499999999998, 50.0, 212.38000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([171.575, 50.0, 212.18500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([172.925, 50.0, 210.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([173.07500000000002, 50.0, 209.85]) cube([0.4, 0.4, 0.1], center=true);
    translate([174.425, 50.0, 207.15]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([174.57500000000002, 50.0, 206.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([175.925, 50.0, 203.58]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.07500000000002, 50.0, 203.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([177.425, 50.0, 199.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([177.575, 50.0, 198.965]) cube([0.4, 0.4, 0.1], center=true);
    translate([178.92499999999998, 50.0, 194.735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([179.075, 50.0, 194.235]) cube([0.4, 0.4, 0.1], center=true);
    translate([180.425, 50.0, 189.465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.57500000000002, 50.0, 188.925]) cube([0.4, 0.4, 0.1], center=true);
    translate([181.925, 50.0, 183.975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([182.07500000000002, 50.0, 183.93499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([183.425, 50.0, 188.165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.57500000000002, 50.0, 188.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([184.925, 50.0, 188.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([185.075, 50.0, 188.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([186.42499999999998, 50.0, 188.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([186.575, 50.0, 188.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([187.925, 50.0, 188.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([188.07500000000002, 50.0, 188.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([189.425, 50.0, 188.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([189.57500000000002, 50.0, 187.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([190.925, 50.0, 187.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([191.07500000000002, 50.0, 187.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([192.425, 50.0, 187.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.575, 50.0, 187.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([193.925, 50.0, 187.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.075, 50.0, 187.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([195.425, 50.0, 187.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.57500000000002, 50.0, 187.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([196.925, 50.0, 187.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([197.07500000000002, 50.0, 187.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([198.425, 50.0, 187.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([198.57500000000002, 50.0, 187.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.925, 50.0, 187.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.075, 50.0, 187.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([201.425, 50.0, 187.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([201.575, 50.0, 187.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([202.925, 50.0, 187.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([203.07500000000002, 50.0, 187.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([204.425, 50.0, 187.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([204.57500000000002, 50.0, 186.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([205.925, 50.0, 186.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([206.07500000000002, 50.0, 186.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([207.425, 50.0, 186.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([207.575, 50.0, 186.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([208.925, 50.0, 186.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([209.075, 50.0, 186.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([210.425, 50.0, 186.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([210.57500000000002, 50.0, 186.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([211.925, 50.0, 186.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([212.07500000000002, 50.0, 186.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([213.425, 50.0, 186.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([213.57500000000002, 50.0, 186.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([214.925, 50.0, 186.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([215.075, 50.0, 186.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([216.425, 50.0, 186.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.575, 50.0, 186.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([217.925, 50.0, 186.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([218.07500000000002, 50.0, 186.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([219.425, 50.0, 186.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([219.57500000000002, 50.0, 185.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([220.925, 50.0, 185.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([221.07500000000002, 50.0, 185.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([222.425, 50.0, 185.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([222.575, 50.0, 185.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([223.925, 50.0, 185.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.075, 50.0, 185.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([225.425, 50.0, 185.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([225.57500000000002, 50.0, 185.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([226.925, 50.0, 185.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.07500000000002, 50.0, 185.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([228.425, 50.0, 185.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([228.57500000000002, 50.0, 185.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([229.925, 50.0, 185.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([230.075, 50.0, 185.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([231.425, 50.0, 185.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([231.575, 50.0, 185.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([232.925, 50.0, 185.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([233.07500000000002, 50.0, 185.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([234.425, 50.0, 185.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([234.57500000000002, 50.0, 184.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([235.925, 50.0, 184.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([236.07500000000002, 50.0, 184.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([237.425, 50.0, 184.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([237.575, 50.0, 184.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([238.925, 50.0, 184.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([239.075, 50.0, 184.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([240.425, 50.0, 184.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([240.57500000000002, 50.0, 184.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([241.925, 50.0, 184.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([242.07500000000002, 50.0, 184.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([243.425, 50.0, 184.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([243.57500000000002, 50.0, 184.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([244.925, 50.0, 184.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([245.075, 50.0, 184.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([246.425, 50.0, 184.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([246.575, 50.0, 184.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([247.925, 50.0, 184.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([248.07500000000002, 50.0, 184.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([249.425, 50.0, 184.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([249.525, 50.075, 183.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([249.975, 51.425000000000004, 183.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 51.575, 183.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 52.925000000000004, 183.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 53.075, 183.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 54.425000000000004, 183.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 54.575, 183.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 55.925, 183.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 56.075, 183.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 57.425, 183.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 57.575, 183.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 58.925000000000004, 183.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 59.075, 183.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 60.425000000000004, 183.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 60.575, 183.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 61.925000000000004, 183.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 62.075, 183.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 63.425, 183.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 63.575, 183.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 64.925, 183.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 65.075, 182.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 66.425, 182.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 66.575, 182.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 67.925, 182.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 68.075, 182.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 69.42500000000001, 182.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 69.575, 182.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 70.925, 182.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 71.075, 182.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 72.425, 182.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 72.575, 182.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 73.92500000000001, 182.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 74.075, 182.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 75.425, 182.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 75.575, 182.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 76.925, 182.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 77.075, 182.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 78.42500000000001, 182.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 78.575, 182.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 79.925, 182.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 80.075, 181.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 81.42500000000001, 181.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 81.575, 181.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 82.925, 181.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 83.075, 181.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 84.425, 181.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 84.575, 181.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 85.92500000000001, 181.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 86.075, 181.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 87.425, 181.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 87.575, 181.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 88.92500000000001, 181.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 89.075, 181.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 90.425, 181.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 90.575, 181.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 91.925, 181.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 92.075, 181.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 93.42500000000001, 181.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 93.575, 181.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 94.925, 181.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 95.075, 180.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 96.42500000000001, 180.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 96.57500000000002, 180.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 97.92500000000001, 180.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 98.075, 180.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 99.425, 180.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 99.575, 180.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 100.92500000000001, 180.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 101.075, 180.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 102.425, 180.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 102.575, 180.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 103.92500000000001, 180.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 104.07500000000002, 180.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 105.42500000000001, 180.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 105.575, 180.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 106.925, 180.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 107.075, 180.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 108.42500000000001, 180.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 108.575, 180.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 109.925, 180.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 110.075, 179.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 111.42500000000001, 179.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 111.57500000000002, 179.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 112.92500000000001, 179.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 113.075, 179.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 114.425, 179.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 114.575, 179.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 115.92500000000001, 179.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 116.075, 179.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 117.425, 179.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 117.575, 179.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 118.92500000000001, 179.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 119.07500000000002, 179.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 120.42500000000001, 179.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 120.575, 179.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 121.925, 179.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 122.075, 179.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 123.42500000000001, 179.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 123.575, 179.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 124.925, 179.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 125.075, 178.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 126.42500000000001, 178.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 126.57500000000002, 178.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 127.92500000000001, 178.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 128.075, 178.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 129.425, 178.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 129.575, 178.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 130.925, 178.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 131.07500000000002, 178.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 132.425, 178.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 132.575, 178.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 133.925, 178.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 134.07500000000002, 178.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 135.425, 178.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 135.575, 178.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 136.925, 178.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 137.075, 178.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 138.425, 178.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 138.57500000000002, 178.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 139.925, 178.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 140.075, 177.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 141.425, 177.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 141.57500000000002, 177.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 142.925, 177.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 143.07500000000002, 177.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 144.425, 177.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 144.57500000000002, 177.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 145.925, 177.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 146.07500000000002, 177.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 147.425, 177.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 147.575, 177.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 148.92499999999998, 177.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 149.075, 177.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 150.425, 177.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 150.57500000000002, 177.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 151.925, 177.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 152.07500000000002, 177.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 153.425, 177.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 153.57500000000002, 177.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 154.925, 177.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 155.075, 176.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 156.42499999999998, 176.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 156.575, 176.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 157.925, 176.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 158.07500000000002, 176.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 159.425, 176.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 159.57500000000002, 176.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 160.925, 176.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 161.07500000000002, 176.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 162.425, 176.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 162.575, 176.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 163.92499999999998, 176.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 164.075, 176.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 165.425, 176.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 165.57500000000002, 176.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 166.925, 176.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 167.07500000000002, 176.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 168.425, 176.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 168.57500000000002, 176.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 169.925, 176.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 170.075, 175.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 171.42499999999998, 175.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 171.575, 175.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 172.925, 175.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 173.07500000000002, 175.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 174.425, 175.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 174.57500000000002, 175.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 175.925, 175.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 176.07500000000002, 175.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 177.425, 175.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 177.575, 175.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 178.92499999999998, 175.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 179.075, 175.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 180.425, 175.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 180.57500000000002, 175.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 181.925, 175.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 182.07500000000002, 175.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 183.425, 175.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 183.57500000000002, 175.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 184.925, 175.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 185.075, 175.04]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 186.42499999999998, 175.76000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 186.575, 175.92500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 187.925, 178.17500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 188.07500000000002, 178.51000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 189.425, 182.29]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 189.57500000000002, 182.71]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 190.925, 186.49]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 191.07500000000002, 186.905]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 192.425, 190.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 192.575, 190.96000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 193.925, 193.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 194.075, 194.125]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 195.425, 196.375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 195.57500000000002, 196.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 196.925, 198.21000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 197.07500000000002, 198.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 198.425, 199.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 198.57500000000002, 199.525]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 199.925, 199.975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 200.075, 199.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 201.425, 199.81000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 201.575, 199.75500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 202.925, 198.94500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 203.07500000000002, 198.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 204.425, 197.38000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 204.57500000000002, 197.18500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 205.925, 195.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 206.07500000000002, 194.85]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 207.425, 192.15]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 207.575, 191.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 208.925, 188.58]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 209.075, 188.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 210.425, 184.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 210.57500000000002, 183.965]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 211.925, 179.735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 212.07500000000002, 179.235]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 213.425, 174.465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 213.57500000000002, 174.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 214.925, 173.34500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 215.075, 173.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 216.425, 173.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 216.575, 173.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 217.925, 173.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 218.07500000000002, 173.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 219.425, 173.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 219.57500000000002, 172.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 220.925, 172.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 221.07500000000002, 172.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 222.425, 172.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 222.575, 172.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 223.925, 172.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 224.075, 172.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 225.425, 172.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 225.57500000000002, 172.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 226.925, 172.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 227.07500000000002, 172.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 228.425, 172.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 228.57500000000002, 172.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 229.925, 172.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 230.075, 172.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 231.425, 172.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 231.575, 172.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 232.925, 172.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 233.07500000000002, 172.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 234.425, 172.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 234.57500000000002, 171.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 235.925, 171.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 236.07500000000002, 171.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 237.425, 171.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 237.575, 171.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 238.925, 171.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 239.075, 171.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 240.425, 171.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 240.57500000000002, 171.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 241.925, 171.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 242.07500000000002, 171.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 243.425, 171.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 243.57500000000002, 171.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 244.925, 171.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 245.075, 171.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 246.425, 171.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 246.575, 171.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 247.925, 171.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 248.07500000000002, 171.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 249.425, 171.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([249.925, 249.525, 170.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([248.57500000000002, 249.975, 170.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([248.425, 250.0, 170.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([247.07500000000002, 250.0, 170.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([246.925, 250.0, 170.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([245.57500000000002, 250.0, 170.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([245.425, 250.0, 170.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([244.075, 250.0, 170.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([243.925, 250.0, 170.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([242.575, 250.0, 170.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([242.425, 250.0, 170.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([241.07500000000002, 250.0, 170.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([240.925, 250.0, 170.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([239.57500000000002, 250.0, 170.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([239.425, 250.0, 170.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([238.07500000000002, 250.0, 170.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([237.925, 250.0, 170.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([236.575, 250.0, 170.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([236.425, 250.0, 170.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([235.075, 250.0, 170.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([234.925, 250.0, 169.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([233.57500000000002, 250.0, 169.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([233.425, 250.0, 169.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([232.07500000000002, 250.0, 169.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([231.925, 250.0, 169.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([230.57500000000002, 250.0, 169.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([230.425, 250.0, 169.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([229.075, 250.0, 169.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([228.925, 250.0, 169.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([227.575, 250.0, 169.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.425, 250.0, 169.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([226.07500000000002, 250.0, 169.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([225.925, 250.0, 169.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([224.57500000000002, 250.0, 169.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.425, 250.0, 169.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([223.07500000000002, 250.0, 169.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([222.925, 250.0, 169.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([221.575, 250.0, 169.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([221.425, 250.0, 169.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([220.075, 250.0, 169.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([219.925, 250.0, 168.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([218.57500000000002, 250.0, 168.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([218.425, 250.0, 168.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([217.07500000000002, 250.0, 168.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.925, 250.0, 168.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([215.57500000000002, 250.0, 168.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([215.425, 250.0, 168.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([214.075, 250.0, 168.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([213.925, 250.0, 168.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([212.575, 250.0, 168.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([212.425, 250.0, 168.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([211.07500000000002, 250.0, 168.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([210.925, 250.0, 168.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([209.57500000000002, 250.0, 168.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([209.425, 250.0, 168.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([208.07500000000002, 250.0, 168.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([207.925, 250.0, 168.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([206.575, 250.0, 168.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([206.425, 250.0, 168.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([205.075, 250.0, 168.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([204.925, 250.0, 167.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([203.57500000000002, 250.0, 167.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([203.425, 250.0, 167.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([202.07500000000002, 250.0, 167.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([201.925, 250.0, 167.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([200.57500000000002, 250.0, 167.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.425, 250.0, 167.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.075, 250.0, 167.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([198.925, 250.0, 167.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([197.575, 250.0, 167.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([197.425, 250.0, 167.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([196.07500000000002, 250.0, 167.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.925, 250.0, 167.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([194.57500000000002, 250.0, 167.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.425, 250.0, 167.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([193.07500000000002, 250.0, 167.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.925, 250.0, 167.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([191.575, 250.0, 167.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([191.42499999999998, 250.0, 167.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([190.075, 250.0, 167.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([189.925, 250.0, 166.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([188.57500000000002, 250.0, 166.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([188.425, 250.0, 166.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([187.07500000000002, 250.0, 166.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([186.925, 250.0, 166.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([185.57500000000002, 250.0, 166.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([185.425, 250.0, 166.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([184.075, 250.0, 166.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.92499999999998, 250.0, 166.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([182.575, 250.0, 166.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([182.425, 250.0, 166.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([181.07500000000002, 250.0, 166.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.925, 250.0, 166.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([179.57500000000002, 250.0, 166.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([179.425, 250.0, 166.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([178.07500000000002, 250.0, 166.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([177.925, 250.0, 166.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([176.575, 250.0, 166.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.42499999999998, 250.0, 166.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([175.075, 250.0, 166.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([174.925, 250.0, 165.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([173.57500000000002, 250.0, 165.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([173.425, 250.0, 165.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([172.07500000000002, 250.0, 165.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([171.925, 250.0, 165.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([170.57500000000002, 250.0, 165.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([170.425, 250.0, 165.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([169.075, 250.0, 165.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.92499999999998, 250.0, 165.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([167.575, 250.0, 165.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.425, 250.0, 165.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([166.07500000000002, 250.0, 165.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.925, 250.0, 165.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([164.57500000000002, 250.0, 165.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([164.425, 250.0, 165.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([163.07500000000002, 250.0, 165.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.925, 250.0, 165.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([161.575, 250.0, 165.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([161.42499999999998, 250.0, 165.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([160.075, 250.0, 165.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.925, 250.0, 164.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([158.57500000000002, 250.0, 164.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([158.425, 250.0, 164.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([157.07500000000002, 250.0, 164.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([156.925, 250.0, 164.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([155.57500000000002, 250.0, 164.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.425, 250.0, 164.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([154.075, 250.0, 164.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([153.92499999999998, 250.0, 164.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([152.575, 250.0, 164.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([152.425, 250.0, 164.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.07500000000002, 250.0, 164.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.925, 250.0, 164.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([149.57500000000002, 250.0, 164.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([149.425, 250.0, 164.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([148.07500000000002, 250.0, 164.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([147.925, 250.0, 164.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([146.575, 250.0, 164.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([146.42499999999998, 250.0, 164.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([145.075, 250.0, 164.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([144.925, 250.0, 163.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([143.57500000000002, 250.0, 163.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([143.425, 250.0, 163.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([142.075, 250.0, 163.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([141.925, 250.0, 163.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([140.575, 250.0, 163.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([140.425, 250.0, 163.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([139.07500000000002, 250.0, 163.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([138.925, 250.0, 163.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([137.575, 250.0, 163.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([137.425, 250.0, 163.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.07500000000002, 250.0, 163.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.925, 250.0, 163.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([134.575, 250.0, 163.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([134.425, 250.0, 163.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([133.075, 250.0, 163.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([132.925, 250.0, 163.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([131.57500000000002, 250.0, 163.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([131.425, 250.0, 163.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([130.075, 250.0, 163.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([129.925, 250.0, 162.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([128.57500000000002, 250.0, 162.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.425, 250.0, 162.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.075, 250.0, 162.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.925, 250.0, 162.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([125.575, 250.0, 162.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.42500000000001, 250.0, 162.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.07500000000002, 250.0, 162.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.92500000000001, 250.0, 162.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([122.575, 250.0, 162.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.425, 250.0, 162.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.075, 250.0, 162.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.92500000000001, 250.0, 162.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.575, 250.0, 162.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.425, 250.0, 162.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.075, 250.0, 162.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.92500000000001, 250.0, 162.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.57500000000002, 250.0, 162.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.42500000000001, 250.0, 162.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.075, 250.0, 162.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.925, 250.0, 161.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([113.575, 250.0, 161.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.42500000000001, 250.0, 161.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.075, 250.0, 161.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.925, 250.0, 161.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([110.575, 250.0, 161.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.42500000000001, 250.0, 161.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.07500000000002, 250.0, 161.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.92500000000001, 250.0, 161.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.575, 250.0, 161.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.425, 250.0, 161.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.075, 250.0, 161.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.92500000000001, 250.0, 161.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.575, 250.0, 161.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.425, 250.0, 161.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.075, 250.0, 161.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.92500000000001, 250.0, 161.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([101.57500000000002, 250.0, 161.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.42500000000001, 250.0, 161.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.075, 250.0, 161.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.925, 250.0, 160.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.575, 250.0, 160.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.42500000000001, 250.0, 160.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.075, 250.0, 160.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.925, 250.0, 160.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.575, 250.0, 160.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.425, 250.0, 160.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.075, 250.0, 160.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.92500000000001, 250.0, 160.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.575, 250.0, 160.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.425, 250.0, 160.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.075, 250.0, 160.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.92500000000001, 250.0, 160.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.575, 250.0, 160.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.425, 250.0, 160.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.075, 250.0, 160.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.925, 250.0, 160.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.575, 250.0, 160.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.42500000000001, 250.0, 160.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.075, 250.0, 160.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.925, 250.0, 160.04]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.575, 250.0, 160.76000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.42500000000001, 250.0, 160.92500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.075, 250.0, 163.17500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.925, 250.0, 163.51000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.575, 250.0, 167.29]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.425, 250.0, 167.71]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.075, 250.0, 171.49]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.92500000000001, 250.0, 171.905]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.575, 250.0, 175.59500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.425, 250.0, 175.96000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.075, 250.0, 178.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.92500000000001, 250.0, 179.125]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.575, 250.0, 181.375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.425, 250.0, 181.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.075, 250.0, 183.21000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.925, 250.0, 183.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.575, 250.0, 184.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.42500000000001, 250.0, 184.525]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.075, 250.0, 184.975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.925, 250.0, 184.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.575, 250.0, 184.81000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.425, 250.0, 184.75500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.075, 250.0, 183.94500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.92500000000001, 250.0, 183.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.575, 250.0, 182.38000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.425, 250.0, 182.18500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.075, 250.0, 180.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.925000000000004, 250.0, 179.85]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.575, 250.0, 177.15]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.425, 250.0, 176.82000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.075, 250.0, 173.58]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.925, 250.0, 173.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.575, 250.0, 169.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.425000000000004, 250.0, 168.965]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.075, 250.0, 164.735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.925000000000004, 250.0, 164.235]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.575, 250.0, 159.465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.425000000000004, 250.0, 158.925]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.075, 250.0, 153.975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.925, 250.0, 153.93499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.575, 250.0, 158.165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.425, 250.0, 158.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.075, 250.0, 158.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.925000000000004, 250.0, 158.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.575, 250.0, 158.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.475, 249.925, 158.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.025, 248.57500000000002, 158.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 248.425, 158.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 247.07500000000002, 158.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 246.925, 157.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 245.57500000000002, 157.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 245.425, 157.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 244.075, 157.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 243.925, 157.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 242.575, 157.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 242.425, 157.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 241.07500000000002, 157.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 240.925, 157.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 239.57500000000002, 157.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 239.425, 157.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 238.07500000000002, 157.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 237.925, 157.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 236.575, 157.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 236.425, 157.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 235.075, 157.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 234.925, 157.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 233.57500000000002, 157.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 233.425, 157.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 232.07500000000002, 157.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 231.925, 156.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 230.57500000000002, 156.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 230.425, 156.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 229.075, 156.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 228.925, 156.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 227.575, 156.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 227.425, 156.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 226.07500000000002, 156.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 225.925, 156.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 224.57500000000002, 156.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 224.425, 156.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 223.07500000000002, 156.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 222.925, 156.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 221.575, 156.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 221.425, 156.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 220.075, 156.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 219.925, 156.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 218.57500000000002, 156.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 218.425, 156.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 217.07500000000002, 156.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 216.925, 155.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 215.57500000000002, 155.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 215.425, 155.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 214.075, 155.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 213.925, 155.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 212.575, 155.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 212.425, 155.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 211.07500000000002, 155.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 210.925, 155.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 209.57500000000002, 155.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 209.425, 155.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 208.07500000000002, 155.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 207.925, 155.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 206.575, 155.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 206.425, 155.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 205.075, 155.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 204.925, 155.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 203.57500000000002, 155.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 203.425, 155.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 202.07500000000002, 155.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 201.925, 154.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 200.57500000000002, 154.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 200.425, 154.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 199.075, 154.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 198.925, 154.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 197.575, 154.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 197.425, 154.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 196.07500000000002, 154.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 195.925, 154.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 194.57500000000002, 154.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 194.425, 154.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 193.07500000000002, 154.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 192.925, 154.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 191.575, 154.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 191.42499999999998, 154.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 190.075, 154.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 189.925, 154.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 188.57500000000002, 154.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 188.425, 154.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 187.07500000000002, 154.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 186.925, 153.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 185.57500000000002, 153.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 185.425, 153.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 184.075, 153.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 183.92499999999998, 153.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 182.575, 153.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 182.425, 153.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 181.07500000000002, 153.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 180.925, 153.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 179.57500000000002, 153.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 179.425, 153.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 178.07500000000002, 153.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 177.925, 153.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 176.575, 153.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 176.42499999999998, 153.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 175.075, 153.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 174.925, 153.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 173.57500000000002, 153.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 173.425, 153.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 172.07500000000002, 153.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 171.925, 152.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 170.57500000000002, 152.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 170.425, 152.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 169.075, 152.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 168.92499999999998, 152.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 167.575, 152.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 167.425, 152.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 166.07500000000002, 152.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 165.925, 152.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 164.57500000000002, 152.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 164.425, 152.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 163.07500000000002, 152.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 162.925, 152.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 161.575, 152.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 161.42499999999998, 152.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 160.075, 152.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 159.925, 152.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 158.57500000000002, 152.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 158.425, 152.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 157.07500000000002, 152.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 156.925, 151.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 155.57500000000002, 151.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 155.425, 151.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 154.075, 151.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 153.92499999999998, 151.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 152.575, 151.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 152.425, 151.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 151.07500000000002, 151.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 150.925, 151.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 149.57500000000002, 151.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 149.425, 151.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 148.07500000000002, 151.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 147.925, 151.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 146.575, 151.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 146.42499999999998, 151.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 145.075, 151.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 144.925, 151.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 143.57500000000002, 151.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 143.425, 151.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 142.075, 151.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 141.925, 150.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 140.575, 150.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 140.425, 150.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 139.07500000000002, 150.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 138.925, 150.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 137.575, 150.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 137.425, 150.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 136.07500000000002, 150.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 135.925, 150.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 134.575, 150.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 134.425, 150.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 133.075, 150.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 132.925, 150.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 131.57500000000002, 150.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 131.425, 150.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 130.075, 150.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 129.925, 150.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 128.57500000000002, 150.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 128.425, 150.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 127.075, 150.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 126.925, 149.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 125.575, 149.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 125.42500000000001, 149.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 124.07500000000002, 149.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 123.92500000000001, 149.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 122.575, 149.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 122.425, 149.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 121.075, 149.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 120.92500000000001, 149.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 119.575, 149.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 119.425, 149.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 118.075, 149.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 117.92500000000001, 149.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 116.57500000000002, 149.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 116.42500000000001, 149.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 115.075, 149.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 114.925, 149.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 113.575, 149.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 113.42500000000001, 149.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 112.075, 149.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 111.925, 148.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 110.575, 148.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 110.42500000000001, 148.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 109.07500000000002, 148.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 108.92500000000001, 148.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 107.575, 148.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 107.425, 148.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 106.075, 148.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 105.92500000000001, 148.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 104.575, 148.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 104.425, 148.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 103.075, 148.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 102.92500000000001, 148.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 101.57500000000002, 148.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 101.42500000000001, 148.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 100.075, 148.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 99.925, 148.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 98.575, 148.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 98.42500000000001, 148.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 97.075, 148.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 96.925, 147.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 95.575, 147.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 95.425, 147.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 94.075, 147.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 93.92500000000001, 147.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 92.575, 147.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 92.425, 147.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 91.075, 147.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 90.92500000000001, 147.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 89.575, 147.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 89.425, 147.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 88.075, 147.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 87.925, 147.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 86.575, 147.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 86.42500000000001, 147.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 85.075, 147.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 84.925, 147.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 83.575, 147.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 83.42500000000001, 147.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 82.075, 147.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 81.925, 146.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 80.575, 146.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 80.425, 146.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 79.075, 146.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 78.92500000000001, 146.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 77.575, 146.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 77.425, 146.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 76.075, 146.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 75.92500000000001, 146.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 74.575, 146.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 74.425, 146.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 73.075, 146.40500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 72.925, 146.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 71.575, 146.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 71.42500000000001, 146.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 70.075, 146.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 69.925, 146.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 68.575, 146.10500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 68.425, 146.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 67.075, 146.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 66.92500000000001, 145.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 65.575, 145.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 65.425, 145.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 64.075, 145.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 63.925000000000004, 145.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 62.575, 145.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 62.425, 145.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 61.075, 145.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 60.925, 145.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 59.575, 145.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 59.425000000000004, 145.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 58.075, 145.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 57.925000000000004, 145.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 56.575, 145.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 56.425000000000004, 145.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 55.075, 145.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 54.925, 145.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 53.575, 145.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 53.425, 145.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 52.075, 145.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 51.925000000000004, 144.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.575, 144.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.075, 50.475, 144.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.425000000000004, 50.025, 144.80500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.575, 50.0, 144.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.925000000000004, 50.0, 144.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.075, 50.0, 144.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.425000000000004, 50.0, 144.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.575, 50.0, 144.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.925, 50.0, 144.50500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.075, 50.0, 144.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.425, 50.0, 144.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.575, 50.0, 144.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.925000000000004, 50.0, 144.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.075, 50.0, 144.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.425000000000004, 50.0, 144.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.575, 50.0, 144.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.925000000000004, 50.0, 144.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.075, 50.0, 144.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.425, 50.0, 144.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.575, 50.0, 143.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.925, 50.0, 143.90500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.075, 50.0, 143.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.425, 50.0, 143.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.575, 50.0, 143.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.925, 50.0, 143.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.075, 50.0, 143.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.42500000000001, 50.0, 143.60500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.575, 50.0, 143.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.925, 50.0, 143.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.075, 50.0, 143.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.425, 50.0, 143.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.575, 50.0, 143.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.92500000000001, 50.0, 143.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.075, 50.0, 143.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.425, 50.0, 143.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.575, 50.0, 143.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.925, 50.0, 143.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.075, 50.0, 143.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.42500000000001, 50.0, 143.00500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.575, 50.0, 142.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.925, 50.0, 142.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.075, 50.0, 142.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.42500000000001, 50.0, 142.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.575, 50.0, 142.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.925, 50.0, 142.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.075, 50.0, 142.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.425, 50.0, 142.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.575, 50.0, 142.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.92500000000001, 50.0, 142.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.075, 50.0, 142.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.425, 50.0, 142.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.575, 50.0, 142.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.92500000000001, 50.0, 142.30500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.075, 50.0, 142.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.425, 50.0, 142.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.575, 50.0, 142.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.925, 50.0, 142.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.075, 50.0, 142.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.42500000000001, 50.0, 142.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.575, 50.0, 141.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.925, 50.0, 141.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.075, 50.0, 141.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.42500000000001, 50.0, 141.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.57500000000002, 50.0, 141.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.92500000000001, 50.0, 141.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.075, 50.0, 141.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.425, 50.0, 141.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.575, 50.0, 141.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.92500000000001, 50.0, 141.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.075, 50.0, 141.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.425, 50.0, 141.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.575, 50.0, 141.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.92500000000001, 50.0, 141.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.07500000000002, 50.0, 141.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.42500000000001, 50.0, 141.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.575, 50.0, 141.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.925, 50.0, 141.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.075, 50.0, 141.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.42500000000001, 50.0, 141.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.575, 50.0, 140.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.925, 50.0, 140.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.075, 50.0, 140.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([111.42500000000001, 50.0, 140.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.57500000000002, 50.0, 140.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.92500000000001, 50.0, 140.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.075, 50.0, 140.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([114.425, 50.0, 140.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.575, 50.0, 140.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.92500000000001, 50.0, 140.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.075, 50.0, 140.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.425, 50.0, 140.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.575, 50.0, 140.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.92500000000001, 50.0, 140.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.07500000000002, 50.0, 140.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.42500000000001, 50.0, 140.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.575, 50.0, 140.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.925, 50.0, 140.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.075, 50.0, 140.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([123.42500000000001, 50.0, 140.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.575, 50.0, 139.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.925, 50.0, 139.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.075, 50.0, 139.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([126.42500000000001, 50.0, 139.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.57500000000002, 50.0, 139.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.92500000000001, 50.0, 139.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.075, 50.0, 139.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([129.425, 50.0, 139.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([129.575, 50.0, 139.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([130.925, 50.0, 139.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([131.07500000000002, 50.0, 139.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([132.425, 50.0, 139.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([132.575, 50.0, 139.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([133.925, 50.0, 139.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([134.07500000000002, 50.0, 139.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.425, 50.0, 139.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.575, 50.0, 139.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.925, 50.0, 139.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([137.075, 50.0, 139.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([138.425, 50.0, 139.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([138.57500000000002, 50.0, 138.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([139.925, 50.0, 138.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([140.075, 50.0, 138.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([141.425, 50.0, 138.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([141.57500000000002, 50.0, 138.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([142.925, 50.0, 138.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([143.07500000000002, 50.0, 138.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([144.425, 50.0, 138.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([144.57500000000002, 50.0, 138.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([145.925, 50.0, 138.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([146.07500000000002, 50.0, 138.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([147.425, 50.0, 138.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([147.575, 50.0, 138.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([148.92499999999998, 50.0, 138.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([149.075, 50.0, 138.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.425, 50.0, 138.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.57500000000002, 50.0, 138.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.925, 50.0, 138.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([152.07500000000002, 50.0, 138.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([153.425, 50.0, 138.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([153.57500000000002, 50.0, 137.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([154.925, 50.0, 137.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.075, 50.0, 137.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([156.42499999999998, 50.0, 137.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([156.575, 50.0, 137.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([157.925, 50.0, 137.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([158.07500000000002, 50.0, 137.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([159.425, 50.0, 137.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.57500000000002, 50.0, 137.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([160.925, 50.0, 137.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([161.07500000000002, 50.0, 137.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([162.425, 50.0, 137.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.575, 50.0, 137.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([163.92499999999998, 50.0, 137.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([164.075, 50.0, 137.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([165.425, 50.0, 137.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.57500000000002, 50.0, 137.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([166.925, 50.0, 137.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.07500000000002, 50.0, 137.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.425, 50.0, 137.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.57500000000002, 50.0, 136.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([169.925, 50.0, 136.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([170.075, 50.0, 136.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([171.42499999999998, 50.0, 136.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([171.575, 50.0, 136.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([172.925, 50.0, 136.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([173.07500000000002, 50.0, 136.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([174.425, 50.0, 136.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([174.57500000000002, 50.0, 136.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([175.925, 50.0, 136.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.07500000000002, 50.0, 136.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([177.425, 50.0, 136.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([177.575, 50.0, 136.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([178.92499999999998, 50.0, 136.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([179.075, 50.0, 136.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([180.425, 50.0, 136.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.57500000000002, 50.0, 136.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([181.925, 50.0, 136.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([182.07500000000002, 50.0, 136.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([183.425, 50.0, 136.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.57500000000002, 50.0, 135.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([184.925, 50.0, 135.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([185.075, 50.0, 135.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([186.42499999999998, 50.0, 135.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([186.575, 50.0, 135.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([187.925, 50.0, 135.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([188.07500000000002, 50.0, 135.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([189.425, 50.0, 135.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([189.57500000000002, 50.0, 135.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([190.925, 50.0, 135.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([191.07500000000002, 50.0, 135.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([192.425, 50.0, 135.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.575, 50.0, 135.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([193.925, 50.0, 135.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.075, 50.0, 135.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([195.425, 50.0, 135.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.57500000000002, 50.0, 135.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([196.925, 50.0, 135.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([197.07500000000002, 50.0, 135.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([198.425, 50.0, 135.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([198.57500000000002, 50.0, 134.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.925, 50.0, 134.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.075, 50.0, 134.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([201.425, 50.0, 134.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([201.575, 50.0, 134.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([202.925, 50.0, 134.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([203.07500000000002, 50.0, 134.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([204.425, 50.0, 134.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([204.57500000000002, 50.0, 134.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([205.925, 50.0, 134.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([206.07500000000002, 50.0, 134.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([207.425, 50.0, 134.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([207.575, 50.0, 134.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([208.925, 50.0, 134.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([209.075, 50.0, 134.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([210.425, 50.0, 134.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([210.57500000000002, 50.0, 134.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([211.925, 50.0, 134.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([212.07500000000002, 50.0, 134.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([213.425, 50.0, 134.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([213.57500000000002, 50.0, 133.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([214.925, 50.0, 133.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([215.075, 50.0, 133.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([216.425, 50.0, 133.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.575, 50.0, 133.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([217.925, 50.0, 133.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([218.07500000000002, 50.0, 133.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([219.425, 50.0, 133.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([219.57500000000002, 50.0, 133.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([220.925, 50.0, 133.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([221.07500000000002, 50.0, 133.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([222.425, 50.0, 133.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([222.575, 50.0, 133.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([223.925, 50.0, 133.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.075, 50.0, 133.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([225.425, 50.0, 133.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([225.57500000000002, 50.0, 133.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([226.925, 50.0, 133.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.07500000000002, 50.0, 133.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([228.425, 50.0, 133.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([228.57500000000002, 50.0, 132.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([229.925, 50.0, 132.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([230.075, 50.0, 132.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([231.425, 50.0, 132.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([231.575, 50.0, 132.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([232.925, 50.0, 132.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([233.07500000000002, 50.0, 132.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([234.425, 50.0, 132.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([234.57500000000002, 50.0, 132.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([235.925, 50.0, 132.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([236.07500000000002, 50.0, 132.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([237.425, 50.0, 132.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([237.575, 50.0, 132.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([238.925, 50.0, 132.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([239.075, 50.0, 132.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([240.425, 50.0, 132.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([240.57500000000002, 50.0, 132.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([241.925, 50.0, 132.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([242.07500000000002, 50.0, 132.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([243.425, 50.0, 132.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([243.57500000000002, 50.0, 131.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([244.925, 50.0, 131.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([245.075, 50.0, 131.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([246.425, 50.0, 131.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([246.575, 50.0, 131.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([247.925, 50.0, 131.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([248.07500000000002, 50.0, 131.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([249.425, 50.0, 131.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([249.525, 50.075, 131.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([249.975, 51.425000000000004, 131.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 51.575, 131.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 52.925000000000004, 131.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 53.075, 131.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 54.425000000000004, 131.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 54.575, 131.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 55.925, 131.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 56.075, 131.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 57.425, 131.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 57.575, 131.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 58.925000000000004, 131.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 59.075, 130.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 60.425000000000004, 130.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 60.575, 130.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 61.925000000000004, 130.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 62.075, 130.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 63.425, 130.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 63.575, 130.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 64.925, 130.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 65.075, 130.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 66.425, 130.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 66.575, 130.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 67.925, 130.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 68.075, 130.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 69.42500000000001, 130.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 69.575, 130.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 70.925, 130.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 71.075, 130.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 72.425, 130.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 72.575, 130.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 73.92500000000001, 130.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 74.075, 129.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 75.425, 129.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 75.575, 129.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 76.925, 129.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 77.075, 129.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 78.42500000000001, 129.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 78.575, 129.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 79.925, 129.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 80.075, 129.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 81.42500000000001, 129.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 81.575, 129.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 82.925, 129.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 83.075, 129.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 84.425, 129.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 84.575, 129.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 85.92500000000001, 129.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 86.075, 129.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 87.425, 129.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 87.575, 129.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 88.92500000000001, 129.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 89.075, 128.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 90.425, 128.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 90.575, 128.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 91.925, 128.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 92.075, 128.79500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 93.42500000000001, 128.70499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 93.575, 128.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 94.925, 128.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 95.075, 128.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 96.42500000000001, 128.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 96.57500000000002, 128.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 97.92500000000001, 128.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 98.075, 128.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 99.425, 128.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 99.575, 128.29500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 100.92500000000001, 128.20499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 101.075, 128.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 102.425, 128.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 102.575, 128.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 103.92500000000001, 128.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 104.07500000000002, 127.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 105.42500000000001, 127.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 105.575, 127.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 106.925, 127.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 107.075, 127.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 108.42500000000001, 127.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 108.575, 127.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 109.925, 127.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 110.075, 127.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 111.42500000000001, 127.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 111.57500000000002, 127.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 112.92500000000001, 127.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 113.075, 127.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 114.425, 127.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 114.575, 127.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 115.92500000000001, 127.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 116.075, 127.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 117.425, 127.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 117.575, 127.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 118.92500000000001, 127.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 119.07500000000002, 126.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 120.42500000000001, 126.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 120.575, 126.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 121.925, 126.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 122.075, 126.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 123.42500000000001, 126.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 123.575, 126.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 124.925, 126.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 125.075, 126.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 126.42500000000001, 126.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 126.57500000000002, 126.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 127.92500000000001, 126.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 128.075, 126.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 129.425, 126.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 129.575, 126.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 130.925, 126.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 131.07500000000002, 126.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 132.425, 126.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 132.575, 126.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 133.925, 126.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 134.07500000000002, 125.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 135.425, 125.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 135.575, 125.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 136.925, 125.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 137.075, 125.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 138.425, 125.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 138.57500000000002, 125.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 139.925, 125.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 140.075, 125.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 141.425, 125.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 141.57500000000002, 125.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 142.925, 125.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 143.07500000000002, 125.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 144.425, 125.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 144.57500000000002, 125.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 145.925, 125.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 146.07500000000002, 125.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 147.425, 125.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 147.575, 125.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 148.92499999999998, 125.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 149.075, 124.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 150.425, 124.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 150.57500000000002, 124.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 151.925, 124.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 152.07500000000002, 124.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 153.425, 124.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 153.57500000000002, 124.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 154.925, 124.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 155.075, 124.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 156.42499999999998, 124.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 156.575, 124.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 157.925, 124.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 158.07500000000002, 124.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 159.425, 124.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 159.57500000000002, 124.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 160.925, 124.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 161.07500000000002, 124.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 162.425, 124.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 162.575, 124.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 163.92499999999998, 124.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 164.075, 123.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 165.425, 123.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 165.57500000000002, 123.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 166.925, 123.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 167.07500000000002, 123.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 168.425, 123.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 168.57500000000002, 123.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 169.925, 123.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 170.075, 123.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 171.42499999999998, 123.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 171.575, 123.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 172.925, 123.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 173.07500000000002, 123.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 174.425, 123.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 174.57500000000002, 123.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 175.925, 123.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 176.07500000000002, 123.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 177.425, 123.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 177.575, 123.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 178.92499999999998, 123.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 179.075, 122.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 180.425, 122.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 180.57500000000002, 122.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 181.925, 122.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 182.07500000000002, 122.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 183.425, 122.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 183.57500000000002, 122.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 184.925, 122.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 185.075, 122.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 186.42499999999998, 122.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 186.575, 122.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 187.925, 122.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 188.07500000000002, 122.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 189.425, 122.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 189.57500000000002, 122.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 190.925, 122.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 191.07500000000002, 122.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 192.425, 122.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 192.575, 122.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 193.925, 122.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 194.075, 121.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 195.425, 121.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 195.57500000000002, 121.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 196.925, 121.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 197.07500000000002, 121.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 198.425, 121.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 198.57500000000002, 121.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 199.925, 121.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 200.075, 121.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 201.425, 121.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 201.575, 121.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 202.925, 121.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 203.07500000000002, 121.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 204.425, 121.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 204.57500000000002, 121.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 205.925, 121.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 206.07500000000002, 121.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 207.425, 121.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 207.575, 121.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 208.925, 121.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 209.075, 120.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 210.425, 120.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 210.57500000000002, 120.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 211.925, 120.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 212.07500000000002, 120.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 213.425, 120.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 213.57500000000002, 120.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 214.925, 120.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 215.075, 120.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 216.425, 120.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 216.575, 120.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 217.925, 120.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 218.07500000000002, 120.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 219.425, 120.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 219.57500000000002, 120.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 220.925, 120.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 221.07500000000002, 120.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 222.425, 120.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 222.575, 120.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 223.925, 120.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 224.075, 119.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 225.425, 119.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 225.57500000000002, 119.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 226.925, 119.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 227.07500000000002, 119.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 228.425, 119.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 228.57500000000002, 119.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 229.925, 119.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 230.075, 119.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 231.425, 119.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 231.575, 119.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 232.925, 119.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 233.07500000000002, 119.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 234.425, 119.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 234.57500000000002, 119.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 235.925, 119.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 236.07500000000002, 119.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 237.425, 119.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 237.575, 119.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 238.925, 119.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 239.075, 118.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 240.425, 118.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 240.57500000000002, 118.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 241.925, 118.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 242.07500000000002, 118.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 243.425, 118.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 243.57500000000002, 118.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 244.925, 118.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 245.075, 118.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 246.425, 118.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 246.575, 118.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 247.925, 118.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 248.07500000000002, 118.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 249.425, 118.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([249.925, 249.525, 118.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([248.57500000000002, 249.975, 118.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([248.425, 250.0, 118.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([247.07500000000002, 250.0, 118.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([246.925, 250.0, 118.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([245.57500000000002, 250.0, 118.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([245.425, 250.0, 117.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([244.075, 250.0, 117.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([243.925, 250.0, 117.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([242.575, 250.0, 117.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([242.425, 250.0, 117.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([241.07500000000002, 250.0, 117.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([240.925, 250.0, 117.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([239.57500000000002, 250.0, 117.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([239.425, 250.0, 117.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([238.07500000000002, 250.0, 117.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([237.925, 250.0, 117.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([236.575, 250.0, 117.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([236.425, 250.0, 117.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([235.075, 250.0, 117.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([234.925, 250.0, 117.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([233.57500000000002, 250.0, 117.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([233.425, 250.0, 117.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([232.07500000000002, 250.0, 117.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([231.925, 250.0, 117.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([230.57500000000002, 250.0, 117.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([230.425, 250.0, 116.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([229.075, 250.0, 116.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([228.925, 250.0, 116.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([227.575, 250.0, 116.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.425, 250.0, 116.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([226.07500000000002, 250.0, 116.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([225.925, 250.0, 116.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([224.57500000000002, 250.0, 116.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.425, 250.0, 116.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([223.07500000000002, 250.0, 116.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([222.925, 250.0, 116.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([221.575, 250.0, 116.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([221.425, 250.0, 116.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([220.075, 250.0, 116.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([219.925, 250.0, 116.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([218.57500000000002, 250.0, 116.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([218.425, 250.0, 116.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([217.07500000000002, 250.0, 116.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.925, 250.0, 116.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([215.57500000000002, 250.0, 116.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([215.425, 250.0, 115.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([214.075, 250.0, 115.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([213.925, 250.0, 115.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([212.575, 250.0, 115.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([212.425, 250.0, 115.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([211.07500000000002, 250.0, 115.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([210.925, 250.0, 115.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([209.57500000000002, 250.0, 115.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([209.425, 250.0, 115.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([208.07500000000002, 250.0, 115.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([207.925, 250.0, 115.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([206.575, 250.0, 115.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([206.425, 250.0, 115.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([205.075, 250.0, 115.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([204.925, 250.0, 115.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([203.57500000000002, 250.0, 115.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([203.425, 250.0, 115.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([202.07500000000002, 250.0, 115.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([201.925, 250.0, 115.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([200.57500000000002, 250.0, 115.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.425, 250.0, 114.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.075, 250.0, 114.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([198.925, 250.0, 114.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([197.575, 250.0, 114.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([197.425, 250.0, 114.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([196.07500000000002, 250.0, 114.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.925, 250.0, 114.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([194.57500000000002, 250.0, 114.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.425, 250.0, 114.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([193.07500000000002, 250.0, 114.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.925, 250.0, 114.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([191.575, 250.0, 114.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([191.42499999999998, 250.0, 114.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([190.075, 250.0, 114.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([189.925, 250.0, 114.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([188.57500000000002, 250.0, 114.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([188.425, 250.0, 114.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([187.07500000000002, 250.0, 114.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([186.925, 250.0, 114.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([185.57500000000002, 250.0, 114.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([185.425, 250.0, 113.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([184.075, 250.0, 113.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.92499999999998, 250.0, 113.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([182.575, 250.0, 113.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([182.425, 250.0, 113.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([181.07500000000002, 250.0, 113.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.925, 250.0, 113.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([179.57500000000002, 250.0, 113.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([179.425, 250.0, 113.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([178.07500000000002, 250.0, 113.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([177.925, 250.0, 113.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([176.575, 250.0, 113.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.42499999999998, 250.0, 113.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([175.075, 250.0, 113.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([174.925, 250.0, 113.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([173.57500000000002, 250.0, 113.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([173.425, 250.0, 113.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([172.07500000000002, 250.0, 113.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([171.925, 250.0, 113.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([170.57500000000002, 250.0, 113.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([170.425, 250.0, 112.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([169.075, 250.0, 112.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.92499999999998, 250.0, 112.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([167.575, 250.0, 112.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.425, 250.0, 112.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([166.07500000000002, 250.0, 112.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.925, 250.0, 112.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([164.57500000000002, 250.0, 112.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([164.425, 250.0, 112.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([163.07500000000002, 250.0, 112.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.925, 250.0, 112.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([161.575, 250.0, 112.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([161.42499999999998, 250.0, 112.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([160.075, 250.0, 112.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.925, 250.0, 112.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([158.57500000000002, 250.0, 112.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([158.425, 250.0, 112.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([157.07500000000002, 250.0, 112.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([156.925, 250.0, 112.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([155.57500000000002, 250.0, 112.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.425, 250.0, 111.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([154.075, 250.0, 111.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([153.92499999999998, 250.0, 111.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([152.575, 250.0, 111.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([152.425, 250.0, 111.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.07500000000002, 250.0, 111.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.925, 250.0, 111.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([149.57500000000002, 250.0, 111.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([149.425, 250.0, 111.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([148.07500000000002, 250.0, 111.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([147.925, 250.0, 111.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([146.575, 250.0, 111.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([146.42499999999998, 250.0, 111.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([145.075, 250.0, 111.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([144.925, 250.0, 111.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([143.57500000000002, 250.0, 111.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([143.425, 250.0, 111.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([142.075, 250.0, 111.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([141.925, 250.0, 111.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([140.575, 250.0, 111.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([140.425, 250.0, 110.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([139.07500000000002, 250.0, 110.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([138.925, 250.0, 110.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([137.575, 250.0, 110.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([137.425, 250.0, 110.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.07500000000002, 250.0, 110.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.925, 250.0, 110.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([134.575, 250.0, 110.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([134.425, 250.0, 110.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([133.075, 250.0, 110.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([132.925, 250.0, 110.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([131.57500000000002, 250.0, 110.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([131.425, 250.0, 110.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([130.075, 250.0, 110.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([129.925, 250.0, 110.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([128.57500000000002, 250.0, 110.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.425, 250.0, 110.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.075, 250.0, 110.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.925, 250.0, 110.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([125.575, 250.0, 110.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.42500000000001, 250.0, 109.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.07500000000002, 250.0, 109.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.92500000000001, 250.0, 109.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([122.575, 250.0, 109.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.425, 250.0, 109.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.075, 250.0, 109.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.92500000000001, 250.0, 109.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.575, 250.0, 109.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.425, 250.0, 109.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.075, 250.0, 109.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.92500000000001, 250.0, 109.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.57500000000002, 250.0, 109.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.42500000000001, 250.0, 109.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.075, 250.0, 109.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.925, 250.0, 109.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([113.575, 250.0, 109.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.42500000000001, 250.0, 109.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.075, 250.0, 109.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.925, 250.0, 109.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([110.575, 250.0, 109.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.42500000000001, 250.0, 108.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.07500000000002, 250.0, 108.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.92500000000001, 250.0, 108.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.575, 250.0, 108.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.425, 250.0, 108.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.075, 250.0, 108.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.92500000000001, 250.0, 108.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.575, 250.0, 108.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.425, 250.0, 108.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.075, 250.0, 108.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.92500000000001, 250.0, 108.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([101.57500000000002, 250.0, 108.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.42500000000001, 250.0, 108.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.075, 250.0, 108.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.925, 250.0, 108.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.575, 250.0, 108.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.42500000000001, 250.0, 108.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.075, 250.0, 108.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.925, 250.0, 108.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.575, 250.0, 108.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.425, 250.0, 107.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.075, 250.0, 107.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.92500000000001, 250.0, 107.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.575, 250.0, 107.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.425, 250.0, 107.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.075, 250.0, 107.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.92500000000001, 250.0, 107.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.575, 250.0, 107.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.425, 250.0, 107.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.075, 250.0, 107.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.925, 250.0, 107.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.575, 250.0, 107.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.42500000000001, 250.0, 107.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.075, 250.0, 107.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.925, 250.0, 107.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.575, 250.0, 107.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.42500000000001, 250.0, 107.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.075, 250.0, 107.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.925, 250.0, 107.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.575, 250.0, 107.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.425, 250.0, 106.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.075, 250.0, 106.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.92500000000001, 250.0, 106.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.575, 250.0, 106.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.425, 250.0, 106.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.075, 250.0, 106.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.92500000000001, 250.0, 106.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.575, 250.0, 106.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.425, 250.0, 106.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.075, 250.0, 106.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.925, 250.0, 106.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.575, 250.0, 106.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.42500000000001, 250.0, 106.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.075, 250.0, 106.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.925, 250.0, 106.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.575, 250.0, 106.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.425, 250.0, 106.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.075, 250.0, 106.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.92500000000001, 250.0, 106.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.575, 250.0, 106.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.425, 250.0, 105.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.075, 250.0, 105.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.925000000000004, 250.0, 105.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.575, 250.0, 105.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.425, 250.0, 105.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.075, 250.0, 105.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.925, 250.0, 105.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.575, 250.0, 105.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.425000000000004, 250.0, 105.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.075, 250.0, 105.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.925000000000004, 250.0, 105.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.575, 250.0, 105.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.425000000000004, 250.0, 105.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.075, 250.0, 105.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.925, 250.0, 105.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.575, 250.0, 105.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.425, 250.0, 105.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.075, 250.0, 105.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.925000000000004, 250.0, 105.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.575, 250.0, 105.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.475, 249.925, 104.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.025, 248.57500000000002, 104.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 248.425, 104.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 247.07500000000002, 104.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 246.925, 104.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 245.57500000000002, 104.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 245.425, 104.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 244.075, 104.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 243.925, 104.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 242.575, 104.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 242.425, 104.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 241.07500000000002, 104.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 240.925, 104.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 239.57500000000002, 104.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 239.425, 104.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 238.07500000000002, 104.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 237.925, 104.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 236.575, 104.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 236.425, 104.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 235.075, 104.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 234.925, 103.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 233.57500000000002, 103.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 233.425, 103.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 232.07500000000002, 103.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 231.925, 103.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 230.57500000000002, 103.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 230.425, 103.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 229.075, 103.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 228.925, 103.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 227.575, 103.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 227.425, 103.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 226.07500000000002, 103.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 225.925, 103.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 224.57500000000002, 103.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 224.425, 103.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 223.07500000000002, 103.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 222.925, 103.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 221.575, 103.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 221.425, 103.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 220.075, 103.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 219.925, 102.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 218.57500000000002, 102.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 218.425, 102.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 217.07500000000002, 102.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 216.925, 102.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 215.57500000000002, 102.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 215.425, 102.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 214.075, 102.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 213.925, 102.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 212.575, 102.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 212.425, 102.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 211.07500000000002, 102.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 210.925, 102.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 209.57500000000002, 102.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 209.425, 102.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 208.07500000000002, 102.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 207.925, 102.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 206.575, 102.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 206.425, 102.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 205.075, 102.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 204.925, 101.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 203.57500000000002, 101.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 203.425, 101.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 202.07500000000002, 101.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 201.925, 101.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 200.57500000000002, 101.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 200.425, 101.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 199.075, 101.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 198.925, 101.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 197.575, 101.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 197.425, 101.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 196.07500000000002, 101.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 195.925, 101.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 194.57500000000002, 101.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 194.425, 101.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 193.07500000000002, 101.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 192.925, 101.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 191.575, 101.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 191.42499999999998, 101.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 190.075, 101.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 189.925, 100.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 188.57500000000002, 100.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 188.425, 100.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 187.07500000000002, 100.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 186.925, 100.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 185.57500000000002, 100.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 185.425, 100.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 184.075, 100.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 183.92499999999998, 100.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 182.575, 100.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 182.425, 100.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 181.07500000000002, 100.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 180.925, 100.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 179.57500000000002, 100.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 179.425, 100.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 178.07500000000002, 100.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 177.925, 100.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 176.575, 100.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 176.42499999999998, 100.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 175.075, 100.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 174.925, 99.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 173.57500000000002, 99.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 173.425, 99.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 172.07500000000002, 99.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 171.925, 99.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 170.57500000000002, 99.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 170.425, 99.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 169.075, 99.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 168.92499999999998, 99.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 167.575, 99.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 167.425, 99.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 166.07500000000002, 99.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 165.925, 99.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 164.57500000000002, 99.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 164.425, 99.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 163.07500000000002, 99.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 162.925, 99.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 161.575, 99.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 161.42499999999998, 99.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 160.075, 99.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 159.925, 98.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 158.57500000000002, 98.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 158.425, 98.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 157.07500000000002, 98.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 156.925, 98.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 155.57500000000002, 98.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 155.425, 98.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 154.075, 98.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 153.92499999999998, 98.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 152.575, 98.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 152.425, 98.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 151.07500000000002, 98.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 150.925, 98.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 149.57500000000002, 98.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 149.425, 98.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 148.07500000000002, 98.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 147.925, 98.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 146.575, 98.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 146.42499999999998, 98.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 145.075, 98.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 144.925, 97.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 143.57500000000002, 97.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 143.425, 97.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 142.075, 97.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 141.925, 97.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 140.575, 97.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 140.425, 97.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 139.07500000000002, 97.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 138.925, 97.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 137.575, 97.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 137.425, 97.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 136.07500000000002, 97.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 135.925, 97.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 134.575, 97.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 134.425, 97.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 133.075, 97.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 132.925, 97.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 131.57500000000002, 97.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 131.425, 97.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 130.075, 97.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 129.925, 96.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 128.57500000000002, 96.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 128.425, 96.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 127.075, 96.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 126.925, 96.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 125.575, 96.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 125.42500000000001, 96.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 124.07500000000002, 96.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 123.92500000000001, 96.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 122.575, 96.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 122.425, 96.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 121.075, 96.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 120.92500000000001, 96.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 119.575, 96.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 119.425, 96.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 118.075, 96.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 117.92500000000001, 96.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 116.57500000000002, 96.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 116.42500000000001, 96.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 115.075, 96.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 114.925, 95.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 113.575, 95.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 113.42500000000001, 95.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 112.075, 95.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 111.925, 95.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 110.575, 95.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 110.42500000000001, 95.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 109.07500000000002, 95.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 108.92500000000001, 95.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 107.575, 95.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 107.425, 95.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 106.075, 95.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 105.92500000000001, 95.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 104.575, 95.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 104.425, 95.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 103.075, 95.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 102.92500000000001, 95.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 101.57500000000002, 95.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 101.42500000000001, 95.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 100.075, 95.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 99.925, 94.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 98.575, 94.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 98.42500000000001, 94.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 97.075, 94.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 96.925, 94.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 95.575, 94.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 95.425, 94.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 94.075, 94.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 93.92500000000001, 94.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 92.575, 94.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 92.425, 94.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 91.075, 94.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 90.92500000000001, 94.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 89.575, 94.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 89.425, 94.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 88.075, 94.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 87.925, 94.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 86.575, 94.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 86.42500000000001, 94.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 85.075, 94.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 84.925, 93.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 83.575, 93.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 83.42500000000001, 93.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 82.075, 93.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 81.925, 93.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 80.575, 93.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 80.425, 93.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 79.075, 93.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 78.92500000000001, 93.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 77.575, 93.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 77.425, 93.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 76.075, 93.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 75.92500000000001, 93.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 74.575, 93.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 74.425, 93.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 73.075, 93.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 72.925, 93.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 71.575, 93.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 71.42500000000001, 93.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 70.075, 93.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 69.925, 92.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 68.575, 92.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 68.425, 92.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 67.075, 92.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 66.92500000000001, 92.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 65.575, 92.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 65.425, 92.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 64.075, 92.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 63.925000000000004, 92.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 62.575, 92.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 62.425, 92.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 61.075, 92.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 60.925, 92.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 59.575, 92.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 59.425000000000004, 92.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 58.075, 92.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 57.925000000000004, 92.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 56.575, 92.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 56.425000000000004, 92.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 55.075, 92.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 54.925, 91.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 53.575, 91.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 53.425, 91.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 52.075, 91.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 51.925000000000004, 91.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.575, 91.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.075, 50.475, 91.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.425000000000004, 50.025, 91.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.575, 50.0, 91.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.925000000000004, 50.0, 91.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.075, 50.0, 91.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.425000000000004, 50.0, 91.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.575, 50.0, 91.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.925, 50.0, 91.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.075, 50.0, 91.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.425, 50.0, 91.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.575, 50.0, 91.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.925000000000004, 50.0, 91.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.075, 50.0, 91.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.425000000000004, 50.0, 91.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.575, 50.0, 90.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.925000000000004, 50.0, 90.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.075, 50.0, 90.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.425, 50.0, 90.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.575, 50.0, 90.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.925, 50.0, 90.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.075, 50.0, 90.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.425, 50.0, 90.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.575, 50.0, 90.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.925, 50.0, 90.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.075, 50.0, 90.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.42500000000001, 50.0, 90.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.575, 50.0, 90.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.925, 50.0, 90.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.075, 50.0, 90.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.425, 50.0, 90.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.575, 50.0, 90.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.92500000000001, 50.0, 90.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.075, 50.0, 90.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.425, 50.0, 90.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.575, 50.0, 89.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.925, 50.0, 89.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.075, 50.0, 89.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.42500000000001, 50.0, 89.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.575, 50.0, 89.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.925, 50.0, 89.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.075, 50.0, 89.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.42500000000001, 50.0, 89.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.575, 50.0, 89.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.925, 50.0, 89.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.075, 50.0, 89.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.425, 50.0, 89.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.575, 50.0, 89.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.92500000000001, 50.0, 89.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.075, 50.0, 89.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.425, 50.0, 89.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.575, 50.0, 89.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.92500000000001, 50.0, 89.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.075, 50.0, 89.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.425, 50.0, 89.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.575, 50.0, 88.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.925, 50.0, 88.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.075, 50.0, 88.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.42500000000001, 50.0, 88.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.575, 50.0, 88.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.925, 50.0, 88.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.075, 50.0, 88.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.42500000000001, 50.0, 88.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.57500000000002, 50.0, 88.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.92500000000001, 50.0, 88.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.075, 50.0, 88.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.425, 50.0, 88.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.575, 50.0, 88.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.92500000000001, 50.0, 88.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.075, 50.0, 88.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.425, 50.0, 88.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.575, 50.0, 88.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.92500000000001, 50.0, 88.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.07500000000002, 50.0, 88.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.42500000000001, 50.0, 88.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.575, 50.0, 87.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.925, 50.0, 87.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.075, 50.0, 87.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.42500000000001, 50.0, 87.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.575, 50.0, 87.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.925, 50.0, 87.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.075, 50.0, 87.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([111.42500000000001, 50.0, 87.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.57500000000002, 50.0, 87.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.92500000000001, 50.0, 87.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.075, 50.0, 87.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([114.425, 50.0, 87.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.575, 50.0, 87.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.92500000000001, 50.0, 87.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.075, 50.0, 87.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.425, 50.0, 87.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.575, 50.0, 87.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.92500000000001, 50.0, 87.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.07500000000002, 50.0, 87.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.42500000000001, 50.0, 87.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.575, 50.0, 86.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.925, 50.0, 86.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.075, 50.0, 86.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([123.42500000000001, 50.0, 86.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.575, 50.0, 86.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.925, 50.0, 86.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.075, 50.0, 86.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([126.42500000000001, 50.0, 86.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.57500000000002, 50.0, 86.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.92500000000001, 50.0, 86.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.075, 50.0, 86.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([129.425, 50.0, 86.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([129.575, 50.0, 86.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([130.925, 50.0, 86.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([131.07500000000002, 50.0, 86.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([132.425, 50.0, 86.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([132.575, 50.0, 86.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([133.925, 50.0, 86.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([134.07500000000002, 50.0, 86.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.425, 50.0, 86.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.575, 50.0, 85.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.925, 50.0, 85.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([137.075, 50.0, 85.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([138.425, 50.0, 85.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([138.57500000000002, 50.0, 85.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([139.925, 50.0, 85.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([140.075, 50.0, 85.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([141.425, 50.0, 85.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([141.57500000000002, 50.0, 85.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([142.925, 50.0, 85.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([143.07500000000002, 50.0, 85.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([144.425, 50.0, 85.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([144.57500000000002, 50.0, 85.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([145.925, 50.0, 85.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([146.07500000000002, 50.0, 85.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([147.425, 50.0, 85.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([147.575, 50.0, 85.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([148.92499999999998, 50.0, 85.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([149.075, 50.0, 85.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.425, 50.0, 85.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.57500000000002, 50.0, 84.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.925, 50.0, 84.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([152.07500000000002, 50.0, 84.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([153.425, 50.0, 84.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([153.57500000000002, 50.0, 84.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([154.925, 50.0, 84.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.075, 50.0, 84.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([156.42499999999998, 50.0, 84.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([156.575, 50.0, 84.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([157.925, 50.0, 84.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([158.07500000000002, 50.0, 84.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([159.425, 50.0, 84.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.57500000000002, 50.0, 84.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([160.925, 50.0, 84.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([161.07500000000002, 50.0, 84.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([162.425, 50.0, 84.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.575, 50.0, 84.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([163.92499999999998, 50.0, 84.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([164.075, 50.0, 84.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([165.425, 50.0, 84.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.57500000000002, 50.0, 83.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([166.925, 50.0, 83.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.07500000000002, 50.0, 83.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.425, 50.0, 83.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.57500000000002, 50.0, 83.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([169.925, 50.0, 83.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([170.075, 50.0, 83.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([171.42499999999998, 50.0, 83.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([171.575, 50.0, 83.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([172.925, 50.0, 83.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([173.07500000000002, 50.0, 83.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([174.425, 50.0, 83.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([174.57500000000002, 50.0, 83.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([175.925, 50.0, 83.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.07500000000002, 50.0, 83.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([177.425, 50.0, 83.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([177.575, 50.0, 83.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([178.92499999999998, 50.0, 83.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([179.075, 50.0, 83.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([180.425, 50.0, 83.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.57500000000002, 50.0, 82.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([181.925, 50.0, 82.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([182.07500000000002, 50.0, 82.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([183.425, 50.0, 82.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.57500000000002, 50.0, 82.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([184.925, 50.0, 82.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([185.075, 50.0, 82.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([186.42499999999998, 50.0, 82.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([186.575, 50.0, 82.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([187.925, 50.0, 82.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([188.07500000000002, 50.0, 82.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([189.425, 50.0, 82.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([189.57500000000002, 50.0, 82.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([190.925, 50.0, 82.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([191.07500000000002, 50.0, 82.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([192.425, 50.0, 82.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.575, 50.0, 82.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([193.925, 50.0, 82.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.075, 50.0, 82.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([195.425, 50.0, 82.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.57500000000002, 50.0, 81.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([196.925, 50.0, 81.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([197.07500000000002, 50.0, 81.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([198.425, 50.0, 81.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([198.57500000000002, 50.0, 81.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.925, 50.0, 81.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.075, 50.0, 81.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([201.425, 50.0, 81.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([201.575, 50.0, 81.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([202.925, 50.0, 81.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([203.07500000000002, 50.0, 81.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([204.425, 50.0, 81.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([204.57500000000002, 50.0, 81.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([205.925, 50.0, 81.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([206.07500000000002, 50.0, 81.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([207.425, 50.0, 81.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([207.575, 50.0, 81.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([208.925, 50.0, 81.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([209.075, 50.0, 81.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([210.425, 50.0, 81.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([210.57500000000002, 50.0, 80.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([211.925, 50.0, 80.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([212.07500000000002, 50.0, 80.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([213.425, 50.0, 80.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([213.57500000000002, 50.0, 80.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([214.925, 50.0, 80.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([215.075, 50.0, 80.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([216.425, 50.0, 80.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.575, 50.0, 80.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([217.925, 50.0, 80.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([218.07500000000002, 50.0, 80.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([219.425, 50.0, 80.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([219.57500000000002, 50.0, 80.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([220.925, 50.0, 80.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([221.07500000000002, 50.0, 80.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([222.425, 50.0, 80.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([222.575, 50.0, 80.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([223.925, 50.0, 80.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.075, 50.0, 80.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([225.425, 50.0, 80.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([225.57500000000002, 50.0, 79.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([226.925, 50.0, 79.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.07500000000002, 50.0, 79.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([228.425, 50.0, 79.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([228.57500000000002, 50.0, 79.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([229.925, 50.0, 79.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([230.075, 50.0, 79.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([231.425, 50.0, 79.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([231.575, 50.0, 79.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([232.925, 50.0, 79.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([233.07500000000002, 50.0, 79.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([234.425, 50.0, 79.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([234.57500000000002, 50.0, 79.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([235.925, 50.0, 79.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([236.07500000000002, 50.0, 79.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([237.425, 50.0, 79.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([237.575, 50.0, 79.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([238.925, 50.0, 79.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([239.075, 50.0, 79.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([240.425, 50.0, 79.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([240.57500000000002, 50.0, 78.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([241.925, 50.0, 78.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([242.07500000000002, 50.0, 78.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([243.425, 50.0, 78.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([243.57500000000002, 50.0, 78.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([244.925, 50.0, 78.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([245.075, 50.0, 78.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([246.425, 50.0, 78.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([246.575, 50.0, 78.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([247.925, 50.0, 78.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([248.07500000000002, 50.0, 78.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([249.425, 50.0, 78.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([249.525, 50.075, 78.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([249.975, 51.425000000000004, 78.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 51.575, 78.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 52.925000000000004, 78.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 53.075, 78.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 54.425000000000004, 78.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 54.575, 78.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 55.925, 78.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 56.075, 77.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 57.425, 77.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 57.575, 77.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 58.925000000000004, 77.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 59.075, 77.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 60.425000000000004, 77.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 60.575, 77.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 61.925000000000004, 77.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 62.075, 77.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 63.425, 77.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 63.575, 77.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 64.925, 77.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 65.075, 77.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 66.425, 77.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 66.575, 77.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 67.925, 77.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 68.075, 77.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 69.42500000000001, 77.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 69.575, 77.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 70.925, 77.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 71.075, 76.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 72.425, 76.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 72.575, 76.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 73.92500000000001, 76.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 74.075, 76.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 75.425, 76.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 75.575, 76.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 76.925, 76.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 77.075, 76.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 78.42500000000001, 76.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 78.575, 76.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 79.925, 76.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 80.075, 76.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 81.42500000000001, 76.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 81.575, 76.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 82.925, 76.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 83.075, 76.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 84.425, 76.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 84.575, 76.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 85.92500000000001, 76.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 86.075, 75.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 87.425, 75.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 87.575, 75.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 88.92500000000001, 75.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 89.075, 75.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 90.425, 75.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 90.575, 75.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 91.925, 75.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 92.075, 75.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 93.42500000000001, 75.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 93.575, 75.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 94.925, 75.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 95.075, 75.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 96.42500000000001, 75.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 96.57500000000002, 75.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 97.92500000000001, 75.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 98.075, 75.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 99.425, 75.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 99.575, 75.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 100.92500000000001, 75.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 101.075, 74.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 102.425, 74.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 102.575, 74.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 103.92500000000001, 74.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 104.07500000000002, 74.79499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 105.42500000000001, 74.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 105.575, 74.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 106.925, 74.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 107.075, 74.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 108.42500000000001, 74.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 108.575, 74.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 109.925, 74.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 110.075, 74.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 111.42500000000001, 74.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 111.57500000000002, 74.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 112.92500000000001, 74.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 113.075, 74.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 114.425, 74.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 114.575, 74.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 115.92500000000001, 74.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 116.075, 73.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 117.425, 73.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 117.575, 73.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 118.92500000000001, 73.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 119.07500000000002, 73.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 120.42500000000001, 73.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 120.575, 73.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 121.925, 73.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 122.075, 73.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 123.42500000000001, 73.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 123.575, 73.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 124.925, 73.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 125.075, 73.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 126.42500000000001, 73.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 126.57500000000002, 73.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 127.92500000000001, 73.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 128.075, 73.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 129.425, 73.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 129.575, 73.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 130.925, 73.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 131.07500000000002, 72.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 132.425, 72.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 132.575, 72.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 133.925, 72.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 134.07500000000002, 72.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 135.425, 72.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 135.575, 72.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 136.925, 72.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 137.075, 72.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 138.425, 72.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 138.57500000000002, 72.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 139.925, 72.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 140.075, 72.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 141.425, 72.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 141.57500000000002, 72.29499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 142.925, 72.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 143.07500000000002, 72.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 144.425, 72.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 144.57500000000002, 72.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 145.925, 72.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 146.07500000000002, 71.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 147.425, 71.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 147.575, 71.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 148.92499999999998, 71.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 149.075, 71.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 150.425, 71.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 150.57500000000002, 71.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 151.925, 71.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 152.07500000000002, 71.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 153.425, 71.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 153.57500000000002, 71.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 154.925, 71.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 155.075, 71.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 156.42499999999998, 71.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 156.575, 71.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 157.925, 71.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 158.07500000000002, 71.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 159.425, 71.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 159.57500000000002, 71.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 160.925, 71.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 161.07500000000002, 70.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 162.425, 70.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 162.575, 70.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 163.92499999999998, 70.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 164.075, 70.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 165.425, 70.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 165.57500000000002, 70.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 166.925, 70.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 167.07500000000002, 70.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 168.425, 70.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 168.57500000000002, 70.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 169.925, 70.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 170.075, 70.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 171.42499999999998, 70.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 171.575, 70.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 172.925, 70.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 173.07500000000002, 70.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 174.425, 70.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 174.57500000000002, 70.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 175.925, 70.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 176.07500000000002, 69.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 177.425, 69.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 177.575, 69.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 178.92499999999998, 69.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 179.075, 69.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 180.425, 69.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 180.57500000000002, 69.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 181.925, 69.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 182.07500000000002, 69.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 183.425, 69.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 183.57500000000002, 69.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 184.925, 69.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 185.075, 69.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 186.42499999999998, 69.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 186.575, 69.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 187.925, 69.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 188.07500000000002, 69.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 189.425, 69.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 189.57500000000002, 69.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 190.925, 69.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 191.07500000000002, 68.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 192.425, 68.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 192.575, 68.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 193.925, 68.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 194.075, 68.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 195.425, 68.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 195.57500000000002, 68.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 196.925, 68.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 197.07500000000002, 68.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 198.425, 68.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 198.57500000000002, 68.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 199.925, 68.40500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 200.075, 68.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 201.425, 68.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 201.575, 68.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 202.925, 68.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 203.07500000000002, 68.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 204.425, 68.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 204.57500000000002, 68.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 205.925, 68.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 206.07500000000002, 67.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 207.425, 67.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 207.575, 67.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 208.925, 67.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 209.075, 67.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 210.425, 67.70500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 210.57500000000002, 67.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 211.925, 67.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 212.07500000000002, 67.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 213.425, 67.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 213.57500000000002, 67.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 214.925, 67.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 215.075, 67.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 216.425, 67.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 216.575, 67.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 217.925, 67.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 218.07500000000002, 67.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 219.425, 67.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 219.57500000000002, 67.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 220.925, 67.00500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 221.07500000000002, 66.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 222.425, 66.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 222.575, 66.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 223.925, 66.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 224.075, 66.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 225.425, 66.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 225.57500000000002, 66.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 226.925, 66.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 227.07500000000002, 66.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 228.425, 66.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 228.57500000000002, 66.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 229.925, 66.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 230.075, 66.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 231.425, 66.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 231.575, 66.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 232.925, 66.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 233.07500000000002, 66.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 234.425, 66.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 234.57500000000002, 66.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 235.925, 66.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 236.07500000000002, 65.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 237.425, 65.90500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 237.575, 65.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 238.925, 65.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 239.075, 65.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 240.425, 65.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 240.57500000000002, 65.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 241.925, 65.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 242.07500000000002, 65.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 243.425, 65.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 243.57500000000002, 65.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 244.925, 65.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 245.075, 65.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 246.425, 65.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 246.575, 65.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 247.925, 65.20500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 248.07500000000002, 65.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 249.425, 65.10499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([249.925, 249.525, 65.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([248.57500000000002, 249.975, 65.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([248.425, 250.0, 64.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([247.07500000000002, 250.0, 64.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([246.925, 250.0, 64.89500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([245.57500000000002, 250.0, 64.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([245.425, 250.0, 64.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([244.075, 250.0, 64.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([243.925, 250.0, 64.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([242.575, 250.0, 64.60499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([242.425, 250.0, 64.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([241.07500000000002, 250.0, 64.50500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([240.925, 250.0, 64.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([239.57500000000002, 250.0, 64.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([239.425, 250.0, 64.39500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([238.07500000000002, 250.0, 64.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([237.925, 250.0, 64.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([236.575, 250.0, 64.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([236.425, 250.0, 64.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([235.075, 250.0, 64.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([234.925, 250.0, 64.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([233.57500000000002, 250.0, 64.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([233.425, 250.0, 63.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([232.07500000000002, 250.0, 63.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([231.925, 250.0, 63.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([230.57500000000002, 250.0, 63.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([230.425, 250.0, 63.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([229.075, 250.0, 63.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([228.925, 250.0, 63.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([227.575, 250.0, 63.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.425, 250.0, 63.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([226.07500000000002, 250.0, 63.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([225.925, 250.0, 63.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([224.57500000000002, 250.0, 63.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.425, 250.0, 63.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([223.07500000000002, 250.0, 63.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([222.925, 250.0, 63.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([221.575, 250.0, 63.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([221.425, 250.0, 63.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([220.075, 250.0, 63.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([219.925, 250.0, 63.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([218.57500000000002, 250.0, 63.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([218.425, 250.0, 62.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([217.07500000000002, 250.0, 62.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.925, 250.0, 62.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([215.57500000000002, 250.0, 62.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([215.425, 250.0, 62.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([214.075, 250.0, 62.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([213.925, 250.0, 62.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([212.575, 250.0, 62.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([212.425, 250.0, 62.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([211.07500000000002, 250.0, 62.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([210.925, 250.0, 62.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([209.57500000000002, 250.0, 62.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([209.425, 250.0, 62.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([208.07500000000002, 250.0, 62.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([207.925, 250.0, 62.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([206.575, 250.0, 62.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([206.425, 250.0, 62.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([205.075, 250.0, 62.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([204.925, 250.0, 62.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([203.57500000000002, 250.0, 62.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([203.425, 250.0, 61.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([202.07500000000002, 250.0, 61.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([201.925, 250.0, 61.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([200.57500000000002, 250.0, 61.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.425, 250.0, 61.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.075, 250.0, 61.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([198.925, 250.0, 61.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([197.575, 250.0, 61.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([197.425, 250.0, 61.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([196.07500000000002, 250.0, 61.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.925, 250.0, 61.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([194.57500000000002, 250.0, 61.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.425, 250.0, 61.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([193.07500000000002, 250.0, 61.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.925, 250.0, 61.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([191.575, 250.0, 61.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([191.42499999999998, 250.0, 61.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([190.075, 250.0, 61.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([189.925, 250.0, 61.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([188.57500000000002, 250.0, 61.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([188.425, 250.0, 60.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([187.07500000000002, 250.0, 60.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([186.925, 250.0, 60.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([185.57500000000002, 250.0, 60.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([185.425, 250.0, 60.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([184.075, 250.0, 60.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.92499999999998, 250.0, 60.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([182.575, 250.0, 60.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([182.425, 250.0, 60.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([181.07500000000002, 250.0, 60.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.925, 250.0, 60.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([179.57500000000002, 250.0, 60.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([179.425, 250.0, 60.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([178.07500000000002, 250.0, 60.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([177.925, 250.0, 60.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([176.575, 250.0, 60.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.42499999999998, 250.0, 60.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([175.075, 250.0, 60.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([174.925, 250.0, 60.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([173.57500000000002, 250.0, 60.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([173.425, 250.0, 59.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([172.07500000000002, 250.0, 59.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([171.925, 250.0, 59.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([170.57500000000002, 250.0, 59.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([170.425, 250.0, 59.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([169.075, 250.0, 59.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.92499999999998, 250.0, 59.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([167.575, 250.0, 59.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.425, 250.0, 59.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([166.07500000000002, 250.0, 59.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.925, 250.0, 59.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([164.57500000000002, 250.0, 59.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([164.425, 250.0, 59.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([163.07500000000002, 250.0, 59.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.925, 250.0, 59.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([161.575, 250.0, 59.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([161.42499999999998, 250.0, 59.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([160.075, 250.0, 59.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.925, 250.0, 59.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([158.57500000000002, 250.0, 59.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([158.425, 250.0, 58.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([157.07500000000002, 250.0, 58.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([156.925, 250.0, 58.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([155.57500000000002, 250.0, 58.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.425, 250.0, 58.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([154.075, 250.0, 58.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([153.92499999999998, 250.0, 58.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([152.575, 250.0, 58.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([152.425, 250.0, 58.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.07500000000002, 250.0, 58.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.925, 250.0, 58.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([149.57500000000002, 250.0, 58.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([149.425, 250.0, 58.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([148.07500000000002, 250.0, 58.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([147.925, 250.0, 58.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([146.575, 250.0, 58.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([146.42499999999998, 250.0, 58.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([145.075, 250.0, 58.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([144.925, 250.0, 58.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([143.57500000000002, 250.0, 58.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([143.425, 250.0, 57.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([142.075, 250.0, 57.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([141.925, 250.0, 57.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([140.575, 250.0, 57.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([140.425, 250.0, 57.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([139.07500000000002, 250.0, 57.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([138.925, 250.0, 57.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([137.575, 250.0, 57.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([137.425, 250.0, 57.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.07500000000002, 250.0, 57.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.925, 250.0, 57.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([134.575, 250.0, 57.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([134.425, 250.0, 57.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([133.075, 250.0, 57.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([132.925, 250.0, 57.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([131.57500000000002, 250.0, 57.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([131.425, 250.0, 57.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([130.075, 250.0, 57.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([129.925, 250.0, 57.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([128.57500000000002, 250.0, 57.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.425, 250.0, 56.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.075, 250.0, 56.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.925, 250.0, 56.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([125.575, 250.0, 56.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.42500000000001, 250.0, 56.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.07500000000002, 250.0, 56.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.92500000000001, 250.0, 56.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([122.575, 250.0, 56.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.425, 250.0, 56.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.075, 250.0, 56.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.92500000000001, 250.0, 56.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.575, 250.0, 56.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.425, 250.0, 56.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.075, 250.0, 56.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.92500000000001, 250.0, 56.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.57500000000002, 250.0, 56.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.42500000000001, 250.0, 56.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.075, 250.0, 56.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.925, 250.0, 56.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([113.575, 250.0, 56.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.42500000000001, 250.0, 55.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.075, 250.0, 55.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.925, 250.0, 55.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([110.575, 250.0, 55.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.42500000000001, 250.0, 55.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.07500000000002, 250.0, 55.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.92500000000001, 250.0, 55.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.575, 250.0, 55.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.425, 250.0, 55.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.075, 250.0, 55.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.92500000000001, 250.0, 55.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.575, 250.0, 55.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.425, 250.0, 55.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.075, 250.0, 55.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.92500000000001, 250.0, 55.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([101.57500000000002, 250.0, 55.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.42500000000001, 250.0, 55.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.075, 250.0, 55.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.925, 250.0, 55.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.575, 250.0, 55.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.42500000000001, 250.0, 54.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.075, 250.0, 54.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.925, 250.0, 54.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.575, 250.0, 54.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.425, 250.0, 54.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.075, 250.0, 54.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.92500000000001, 250.0, 54.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.575, 250.0, 54.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.425, 250.0, 54.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.075, 250.0, 54.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.92500000000001, 250.0, 54.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.575, 250.0, 54.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.425, 250.0, 54.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.075, 250.0, 54.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.925, 250.0, 54.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.575, 250.0, 54.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.42500000000001, 250.0, 54.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.075, 250.0, 54.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.925, 250.0, 54.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.575, 250.0, 54.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.42500000000001, 250.0, 53.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.075, 250.0, 53.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.925, 250.0, 53.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.575, 250.0, 53.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.425, 250.0, 53.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.075, 250.0, 53.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.92500000000001, 250.0, 53.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.575, 250.0, 53.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.425, 250.0, 53.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.075, 250.0, 53.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.92500000000001, 250.0, 53.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.575, 250.0, 53.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.425, 250.0, 53.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.075, 250.0, 53.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.925, 250.0, 53.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.575, 250.0, 53.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.42500000000001, 250.0, 53.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.075, 250.0, 53.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.925, 250.0, 53.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.575, 250.0, 53.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.425, 250.0, 52.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.075, 250.0, 52.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.92500000000001, 250.0, 52.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.575, 250.0, 52.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.425, 250.0, 52.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.075, 250.0, 52.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.925000000000004, 250.0, 52.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.575, 250.0, 52.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.425, 250.0, 52.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.075, 250.0, 52.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.925, 250.0, 52.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.575, 250.0, 52.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.425000000000004, 250.0, 52.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.075, 250.0, 52.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.925000000000004, 250.0, 52.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.575, 250.0, 52.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.425000000000004, 250.0, 52.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.075, 250.0, 52.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.925, 250.0, 52.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.575, 250.0, 52.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.425, 250.0, 51.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.075, 250.0, 51.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.925000000000004, 250.0, 51.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.575, 250.0, 51.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.475, 249.925, 51.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.025, 248.57500000000002, 51.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 248.425, 51.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 247.07500000000002, 51.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 246.925, 51.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 245.57500000000002, 51.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 245.425, 51.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 244.075, 51.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 243.925, 51.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 242.575, 51.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 242.425, 51.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 241.07500000000002, 51.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 240.925, 51.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 239.57500000000002, 51.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 239.425, 51.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 238.07500000000002, 51.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 237.925, 50.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 236.575, 50.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 236.425, 50.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 235.075, 50.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 234.925, 50.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 233.57500000000002, 50.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 233.425, 50.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 232.07500000000002, 50.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 231.925, 50.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 230.57500000000002, 50.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 230.425, 50.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 229.075, 50.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 228.925, 50.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 227.575, 50.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 227.425, 50.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 226.07500000000002, 50.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 225.925, 50.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 224.57500000000002, 50.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 224.425, 50.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 223.07500000000002, 50.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 222.925, 49.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 221.575, 49.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 221.425, 49.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 220.075, 49.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 219.925, 49.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 218.57500000000002, 49.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 218.425, 49.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 217.07500000000002, 49.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 216.925, 49.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 215.57500000000002, 49.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 215.425, 49.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 214.075, 49.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 213.925, 49.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 212.575, 49.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 212.425, 49.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 211.07500000000002, 49.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 210.925, 49.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 209.57500000000002, 49.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 209.425, 49.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 208.07500000000002, 49.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 207.925, 48.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 206.575, 48.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 206.425, 48.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 205.075, 48.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 204.925, 48.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 203.57500000000002, 48.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 203.425, 48.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 202.07500000000002, 48.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 201.925, 48.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 200.57500000000002, 48.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 200.425, 48.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 199.075, 48.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 198.925, 48.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 197.575, 48.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 197.425, 48.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 196.07500000000002, 48.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 195.925, 48.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 194.57500000000002, 48.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 194.425, 48.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 193.07500000000002, 48.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 192.925, 47.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 191.575, 47.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 191.42499999999998, 47.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 190.075, 47.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 189.925, 47.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 188.57500000000002, 47.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 188.425, 47.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 187.07500000000002, 47.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 186.925, 47.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 185.57500000000002, 47.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 185.425, 47.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 184.075, 47.404999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 183.92499999999998, 47.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 182.575, 47.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 182.425, 47.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 181.07500000000002, 47.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 180.925, 47.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 179.57500000000002, 47.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 179.425, 47.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 178.07500000000002, 47.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 177.925, 46.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 176.575, 46.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 176.42499999999998, 46.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 175.075, 46.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 174.925, 46.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 173.57500000000002, 46.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 173.425, 46.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 172.07500000000002, 46.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 171.925, 46.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 170.57500000000002, 46.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 170.425, 46.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 169.075, 46.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 168.92499999999998, 46.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 167.575, 46.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 167.425, 46.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 166.07500000000002, 46.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 165.925, 46.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 164.57500000000002, 46.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 164.425, 46.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 163.07500000000002, 46.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 162.925, 45.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 161.575, 45.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 161.42499999999998, 45.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 160.075, 45.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 159.925, 45.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 158.57500000000002, 45.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 158.425, 45.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 157.07500000000002, 45.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 156.925, 45.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 155.57500000000002, 45.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 155.425, 45.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 154.075, 45.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 153.92499999999998, 45.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 152.575, 45.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 152.425, 45.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 151.07500000000002, 45.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 150.925, 45.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 149.57500000000002, 45.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 149.425, 45.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 148.07500000000002, 45.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 147.925, 44.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 146.575, 44.904999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 146.42499999999998, 44.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 145.075, 44.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 144.925, 44.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 143.57500000000002, 44.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 143.425, 44.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 142.075, 44.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 141.925, 44.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 140.575, 44.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 140.425, 44.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 139.07500000000002, 44.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 138.925, 44.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 137.575, 44.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 137.425, 44.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 136.07500000000002, 44.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 135.925, 44.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 134.575, 44.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 134.425, 44.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 133.075, 44.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 132.925, 43.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 131.57500000000002, 43.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 131.425, 43.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 130.075, 43.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 129.925, 43.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 128.57500000000002, 43.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 128.425, 43.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 127.075, 43.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 126.925, 43.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 125.575, 43.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 125.42500000000001, 43.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 124.07500000000002, 43.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 123.92500000000001, 43.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 122.575, 43.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 122.425, 43.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 121.075, 43.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 120.92500000000001, 43.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 119.575, 43.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 119.425, 43.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 118.075, 43.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 117.92500000000001, 42.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 116.57500000000002, 42.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 116.42500000000001, 42.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 115.075, 42.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 114.925, 42.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 113.575, 42.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 113.42500000000001, 42.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 112.075, 42.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 111.925, 42.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 110.575, 42.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 110.42500000000001, 42.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 109.07500000000002, 42.404999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 108.92500000000001, 42.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 107.575, 42.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 107.425, 42.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 106.075, 42.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 105.92500000000001, 42.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 104.575, 42.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 104.425, 42.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 103.075, 42.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 102.92500000000001, 41.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 101.57500000000002, 41.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 101.42500000000001, 41.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 100.075, 41.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 99.925, 41.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 98.575, 41.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 98.42500000000001, 41.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 97.075, 41.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 96.925, 41.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 95.575, 41.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 95.425, 41.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 94.075, 41.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 93.92500000000001, 41.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 92.575, 41.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 92.425, 41.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 91.075, 41.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 90.92500000000001, 41.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 89.575, 41.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 89.425, 41.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 88.075, 41.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 87.925, 40.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 86.575, 40.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 86.42500000000001, 40.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 85.075, 40.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 84.925, 40.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 83.575, 40.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 83.42500000000001, 40.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 82.075, 40.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 81.925, 40.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 80.575, 40.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 80.425, 40.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 79.075, 40.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 78.92500000000001, 40.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 77.575, 40.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 77.425, 40.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 76.075, 40.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 75.92500000000001, 40.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 74.575, 40.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 74.425, 40.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 73.075, 40.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 72.925, 39.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 71.575, 39.904999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 71.42500000000001, 39.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 70.075, 39.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 69.925, 39.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 68.575, 39.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 68.425, 39.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 67.075, 39.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 66.92500000000001, 39.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 65.575, 39.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 65.425, 39.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 64.075, 39.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 63.925000000000004, 39.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 62.575, 39.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 62.425, 39.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 61.075, 39.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 60.925, 39.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 59.575, 39.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 59.425000000000004, 39.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 58.075, 39.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 57.925000000000004, 38.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 56.575, 38.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 56.425000000000004, 38.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 55.075, 38.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 54.925, 38.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 53.575, 38.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 53.425, 38.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 52.075, 38.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 51.925000000000004, 38.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 50.575, 38.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.075, 50.475, 38.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.425000000000004, 50.025, 38.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.575, 50.0, 38.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.925000000000004, 50.0, 38.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.075, 50.0, 38.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.425000000000004, 50.0, 38.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.575, 50.0, 38.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.925, 50.0, 38.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.075, 50.0, 38.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.425, 50.0, 38.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.575, 50.0, 37.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.925000000000004, 50.0, 37.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.075, 50.0, 37.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.425000000000004, 50.0, 37.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.575, 50.0, 37.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.925000000000004, 50.0, 37.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.075, 50.0, 37.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.425, 50.0, 37.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.575, 50.0, 37.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.925, 50.0, 37.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.075, 50.0, 37.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.425, 50.0, 37.404999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.575, 50.0, 37.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.925, 50.0, 37.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.075, 50.0, 37.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.42500000000001, 50.0, 37.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.575, 50.0, 37.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.925, 50.0, 37.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.075, 50.0, 37.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.425, 50.0, 37.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.575, 50.0, 36.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.92500000000001, 50.0, 36.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.075, 50.0, 36.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.425, 50.0, 36.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.575, 50.0, 36.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.925, 50.0, 36.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.075, 50.0, 36.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.42500000000001, 50.0, 36.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.575, 50.0, 36.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.925, 50.0, 36.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.075, 50.0, 36.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.42500000000001, 50.0, 36.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.575, 50.0, 36.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.925, 50.0, 36.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.075, 50.0, 36.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.425, 50.0, 36.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.575, 50.0, 36.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.92500000000001, 50.0, 36.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.075, 50.0, 36.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.425, 50.0, 36.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.575, 50.0, 35.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.92500000000001, 50.0, 35.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.075, 50.0, 35.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.425, 50.0, 35.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.575, 50.0, 35.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.925, 50.0, 35.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.075, 50.0, 35.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.42500000000001, 50.0, 35.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.575, 50.0, 35.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.925, 50.0, 35.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.075, 50.0, 35.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.42500000000001, 50.0, 35.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.57500000000002, 50.0, 35.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.92500000000001, 50.0, 35.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.075, 50.0, 35.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.425, 50.0, 35.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.575, 50.0, 35.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.92500000000001, 50.0, 35.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.075, 50.0, 35.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.425, 50.0, 35.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.575, 50.0, 34.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.92500000000001, 50.0, 34.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.07500000000002, 50.0, 34.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.42500000000001, 50.0, 34.80499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.575, 50.0, 34.794999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.925, 50.0, 34.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.075, 50.0, 34.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.42500000000001, 50.0, 34.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.575, 50.0, 34.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.925, 50.0, 34.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.075, 50.0, 34.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([111.42500000000001, 50.0, 34.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.57500000000002, 50.0, 34.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.92500000000001, 50.0, 34.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.075, 50.0, 34.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([114.425, 50.0, 34.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.575, 50.0, 34.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.92500000000001, 50.0, 34.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.075, 50.0, 34.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.425, 50.0, 34.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.575, 50.0, 33.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.92500000000001, 50.0, 33.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.07500000000002, 50.0, 33.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.42500000000001, 50.0, 33.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.575, 50.0, 33.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.925, 50.0, 33.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.075, 50.0, 33.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([123.42500000000001, 50.0, 33.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.575, 50.0, 33.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.925, 50.0, 33.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.075, 50.0, 33.495000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([126.42500000000001, 50.0, 33.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.57500000000002, 50.0, 33.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.92500000000001, 50.0, 33.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.075, 50.0, 33.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([129.425, 50.0, 33.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([129.575, 50.0, 33.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([130.925, 50.0, 33.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([131.07500000000002, 50.0, 33.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([132.425, 50.0, 33.004999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([132.575, 50.0, 32.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([133.925, 50.0, 32.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([134.07500000000002, 50.0, 32.894999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.425, 50.0, 32.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.575, 50.0, 32.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.925, 50.0, 32.705000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([137.075, 50.0, 32.69500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([138.425, 50.0, 32.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([138.57500000000002, 50.0, 32.595000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([139.925, 50.0, 32.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([140.075, 50.0, 32.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([141.425, 50.0, 32.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([141.57500000000002, 50.0, 32.394999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([142.925, 50.0, 32.30499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([143.07500000000002, 50.0, 32.294999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([144.425, 50.0, 32.205000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([144.57500000000002, 50.0, 32.19500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([145.925, 50.0, 32.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([146.07500000000002, 50.0, 32.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([147.425, 50.0, 32.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([147.575, 50.0, 31.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([148.92499999999998, 50.0, 31.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([149.075, 50.0, 31.895000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([150.425, 50.0, 31.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.57500000000002, 50.0, 31.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.925, 50.0, 31.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([152.07500000000002, 50.0, 31.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([153.425, 50.0, 31.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([153.57500000000002, 50.0, 31.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([154.925, 50.0, 31.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.075, 50.0, 31.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([156.42499999999998, 50.0, 31.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([156.575, 50.0, 31.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([157.925, 50.0, 31.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([158.07500000000002, 50.0, 31.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([159.425, 50.0, 31.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.57500000000002, 50.0, 31.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([160.925, 50.0, 31.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([161.07500000000002, 50.0, 31.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([162.425, 50.0, 31.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.575, 50.0, 30.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([163.92499999999998, 50.0, 30.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([164.075, 50.0, 30.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([165.425, 50.0, 30.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.57500000000002, 50.0, 30.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([166.925, 50.0, 30.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.07500000000002, 50.0, 30.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([168.425, 50.0, 30.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.57500000000002, 50.0, 30.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([169.925, 50.0, 30.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([170.075, 50.0, 30.494999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([171.42499999999998, 50.0, 30.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([171.575, 50.0, 30.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([172.925, 50.0, 30.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([173.07500000000002, 50.0, 30.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([174.425, 50.0, 30.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([174.57500000000002, 50.0, 30.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([175.925, 50.0, 30.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.07500000000002, 50.0, 30.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([177.425, 50.0, 30.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([177.575, 50.0, 29.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([178.92499999999998, 50.0, 29.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([179.075, 50.0, 29.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([180.425, 50.0, 29.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.57500000000002, 50.0, 29.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([181.925, 50.0, 29.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([182.07500000000002, 50.0, 29.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([183.425, 50.0, 29.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.57500000000002, 50.0, 29.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([184.925, 50.0, 29.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([185.075, 50.0, 29.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([186.42499999999998, 50.0, 29.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([186.575, 50.0, 29.395000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([187.925, 50.0, 29.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([188.07500000000002, 50.0, 29.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([189.425, 50.0, 29.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([189.57500000000002, 50.0, 29.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([190.925, 50.0, 29.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([191.07500000000002, 50.0, 29.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([192.425, 50.0, 29.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.575, 50.0, 28.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([193.925, 50.0, 28.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.075, 50.0, 28.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([195.425, 50.0, 28.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.57500000000002, 50.0, 28.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([196.925, 50.0, 28.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([197.07500000000002, 50.0, 28.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([198.425, 50.0, 28.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([198.57500000000002, 50.0, 28.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.925, 50.0, 28.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.075, 50.0, 28.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([201.425, 50.0, 28.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([201.575, 50.0, 28.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([202.925, 50.0, 28.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([203.07500000000002, 50.0, 28.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([204.425, 50.0, 28.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([204.57500000000002, 50.0, 28.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([205.925, 50.0, 28.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([206.07500000000002, 50.0, 28.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([207.425, 50.0, 28.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([207.575, 50.0, 27.994999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([208.925, 50.0, 27.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([209.075, 50.0, 27.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([210.425, 50.0, 27.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([210.57500000000002, 50.0, 27.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([211.925, 50.0, 27.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([212.07500000000002, 50.0, 27.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([213.425, 50.0, 27.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([213.57500000000002, 50.0, 27.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([214.925, 50.0, 27.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([215.075, 50.0, 27.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([216.425, 50.0, 27.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.575, 50.0, 27.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([217.925, 50.0, 27.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([218.07500000000002, 50.0, 27.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([219.425, 50.0, 27.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([219.57500000000002, 50.0, 27.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([220.925, 50.0, 27.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([221.07500000000002, 50.0, 27.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([222.425, 50.0, 27.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([222.575, 50.0, 26.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([223.925, 50.0, 26.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.075, 50.0, 26.895000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([225.425, 50.0, 26.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([225.57500000000002, 50.0, 26.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([226.925, 50.0, 26.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.07500000000002, 50.0, 26.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([228.425, 50.0, 26.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([228.57500000000002, 50.0, 26.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([229.925, 50.0, 26.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([230.075, 50.0, 26.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([231.425, 50.0, 26.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([231.575, 50.0, 26.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([232.925, 50.0, 26.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([233.07500000000002, 50.0, 26.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([234.425, 50.0, 26.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([234.57500000000002, 50.0, 26.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([235.925, 50.0, 26.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([236.07500000000002, 50.0, 26.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([237.425, 50.0, 26.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([237.575, 50.0, 25.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([238.925, 50.0, 25.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([239.075, 50.0, 25.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([240.425, 50.0, 25.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([240.57500000000002, 50.0, 25.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([241.925, 50.0, 25.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([242.07500000000002, 50.0, 25.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([243.425, 50.0, 25.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([243.57500000000002, 50.0, 25.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([244.925, 50.0, 25.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([245.075, 50.0, 25.494999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([246.425, 50.0, 25.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([246.575, 50.0, 25.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([247.925, 50.0, 25.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([248.07500000000002, 50.0, 25.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([249.425, 50.0, 25.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([249.525, 50.075, 25.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([249.975, 51.425000000000004, 25.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 51.575, 25.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 52.925000000000004, 25.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 53.075, 24.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 54.425000000000004, 24.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 54.575, 24.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 55.925, 24.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 56.075, 24.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 57.425, 24.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 57.575, 24.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 58.925000000000004, 24.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 59.075, 24.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 60.425000000000004, 24.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 60.575, 24.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 61.925000000000004, 24.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 62.075, 24.395000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 63.425, 24.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 63.575, 24.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 64.925, 24.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 65.075, 24.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 66.425, 24.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 66.575, 24.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 67.925, 24.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 68.075, 23.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 69.42500000000001, 23.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 69.575, 23.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 70.925, 23.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 71.075, 23.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 72.425, 23.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 72.575, 23.694999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 73.92500000000001, 23.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 74.075, 23.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 75.425, 23.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 75.575, 23.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 76.925, 23.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 77.075, 23.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 78.42500000000001, 23.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 78.575, 23.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 79.925, 23.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 80.075, 23.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 81.42500000000001, 23.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 81.575, 23.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 82.925, 23.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 83.075, 22.994999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 84.425, 22.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 84.575, 22.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 85.92500000000001, 22.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 86.075, 22.794999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 87.425, 22.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 87.575, 22.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 88.92500000000001, 22.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 89.075, 22.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 90.425, 22.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 90.575, 22.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 91.925, 22.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 92.075, 22.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 93.42500000000001, 22.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 93.575, 22.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 94.925, 22.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 95.075, 22.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 96.42500000000001, 22.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 96.57500000000002, 22.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 97.92500000000001, 22.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 98.075, 21.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 99.425, 21.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 99.575, 21.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 100.92500000000001, 21.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 101.075, 21.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 102.425, 21.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 102.575, 21.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 103.92500000000001, 21.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 104.07500000000002, 21.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 105.42500000000001, 21.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 105.575, 21.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 106.925, 21.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 107.075, 21.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 108.42500000000001, 21.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 108.575, 21.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 109.925, 21.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 110.075, 21.194999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 111.42500000000001, 21.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 111.57500000000002, 21.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 112.92500000000001, 21.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 113.075, 20.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 114.425, 20.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 114.575, 20.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 115.92500000000001, 20.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 116.075, 20.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 117.425, 20.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 117.575, 20.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 118.92500000000001, 20.605000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 119.07500000000002, 20.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 120.42500000000001, 20.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 120.575, 20.494999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 121.925, 20.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 122.075, 20.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 123.42500000000001, 20.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 123.575, 20.294999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 124.925, 20.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 125.075, 20.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 126.42500000000001, 20.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 126.57500000000002, 20.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 127.92500000000001, 20.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 128.075, 19.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 129.425, 19.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 129.575, 19.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 130.925, 19.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 131.07500000000002, 19.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 132.425, 19.705000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 132.575, 19.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 133.925, 19.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 134.07500000000002, 19.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 135.425, 19.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 135.575, 19.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 136.925, 19.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 137.075, 19.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 138.425, 19.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 138.57500000000002, 19.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 139.925, 19.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 140.075, 19.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 141.425, 19.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 141.57500000000002, 19.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 142.925, 19.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 143.07500000000002, 18.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 144.425, 18.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 144.57500000000002, 18.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 145.925, 18.805000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 146.07500000000002, 18.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 147.425, 18.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 147.575, 18.694999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 148.92499999999998, 18.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 149.075, 18.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 150.425, 18.505000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 150.57500000000002, 18.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 151.925, 18.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 152.07500000000002, 18.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 153.425, 18.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 153.57500000000002, 18.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 154.925, 18.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 155.075, 18.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 156.42499999999998, 18.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 156.575, 18.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 157.925, 18.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 158.07500000000002, 17.994999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 159.425, 17.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 159.57500000000002, 17.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 160.925, 17.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 161.07500000000002, 17.794999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 162.425, 17.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 162.575, 17.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 163.92499999999998, 17.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 164.075, 17.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 165.425, 17.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 165.57500000000002, 17.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 166.925, 17.404999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 167.07500000000002, 17.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 168.425, 17.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 168.57500000000002, 17.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 169.925, 17.205000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 170.075, 17.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 171.42499999999998, 17.105000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 171.575, 17.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 172.925, 17.005000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 173.07500000000002, 16.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 174.425, 16.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 174.57500000000002, 16.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 175.925, 16.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 176.07500000000002, 16.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 177.425, 16.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 177.575, 16.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 178.92499999999998, 16.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 179.075, 16.595000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 180.425, 16.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 180.57500000000002, 16.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 181.925, 16.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 182.07500000000002, 16.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 183.425, 16.305000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 183.57500000000002, 16.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 184.925, 16.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 185.075, 16.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 186.42499999999998, 16.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 186.575, 16.095000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 187.925, 16.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 188.07500000000002, 15.995000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 189.425, 15.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 189.57500000000002, 15.895000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 190.925, 15.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 191.07500000000002, 15.795000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 192.425, 15.704999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 192.575, 15.694999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 193.925, 15.604999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 194.075, 15.594999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 195.425, 15.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 195.57500000000002, 15.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 196.925, 15.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 197.07500000000002, 15.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 198.425, 15.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 198.57500000000002, 15.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 199.925, 15.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 200.075, 15.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 201.425, 15.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 201.575, 15.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 202.925, 15.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 203.07500000000002, 14.995000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 204.425, 14.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 204.57500000000002, 14.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 205.925, 14.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 206.07500000000002, 14.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 207.425, 14.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 207.575, 14.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 208.925, 14.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 209.075, 14.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 210.425, 14.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 210.57500000000002, 14.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 211.925, 14.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 212.07500000000002, 14.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 213.425, 14.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 213.57500000000002, 14.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 214.925, 14.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 215.075, 14.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 216.425, 14.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 216.575, 14.094999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 217.925, 14.004999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 218.07500000000002, 13.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 219.425, 13.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 219.57500000000002, 13.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 220.925, 13.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 221.07500000000002, 13.795000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 222.425, 13.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 222.575, 13.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 223.925, 13.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 224.075, 13.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 225.425, 13.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 225.57500000000002, 13.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 226.925, 13.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 227.07500000000002, 13.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 228.425, 13.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 228.57500000000002, 13.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 229.925, 13.204999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 230.075, 13.194999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 231.425, 13.104999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 231.575, 13.094999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 232.925, 13.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 233.07500000000002, 12.995000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 234.425, 12.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 234.57500000000002, 12.895000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 235.925, 12.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 236.07500000000002, 12.795000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 237.425, 12.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 237.575, 12.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 238.925, 12.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 239.075, 12.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 240.425, 12.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 240.57500000000002, 12.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 241.925, 12.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 242.07500000000002, 12.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 243.425, 12.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([250.0, 243.57500000000002, 12.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([250.0, 244.925, 12.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([249.925, 245.25, 12.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([248.57500000000002, 249.75, 12.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([248.425, 250.0, 12.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([247.07500000000002, 250.0, 12.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([246.925, 250.0, 11.995000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([245.57500000000002, 250.0, 11.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([245.425, 250.0, 11.895000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([244.075, 250.0, 11.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([243.925, 250.0, 11.795000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([242.575, 250.0, 11.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([242.425, 250.0, 11.694999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([241.07500000000002, 250.0, 11.604999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([240.925, 250.0, 11.594999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([239.57500000000002, 250.0, 11.504999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([239.425, 250.0, 11.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([238.07500000000002, 250.0, 11.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([237.925, 250.0, 11.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([236.575, 250.0, 11.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([236.425, 250.0, 11.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([235.075, 250.0, 11.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([234.925, 250.0, 11.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([233.57500000000002, 250.0, 11.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([233.425, 250.0, 11.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([232.07500000000002, 250.0, 11.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([231.925, 250.0, 10.995000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([230.57500000000002, 250.0, 10.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([230.425, 250.0, 10.895000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([229.075, 250.0, 10.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([228.925, 250.0, 10.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([227.575, 250.0, 10.704999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.425, 250.0, 10.694999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([226.07500000000002, 250.0, 10.604999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([225.925, 250.0, 10.594999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([224.57500000000002, 250.0, 10.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([224.425, 250.0, 10.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([223.07500000000002, 250.0, 10.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([222.925, 250.0, 10.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([221.575, 250.0, 10.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([221.425, 250.0, 10.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([220.075, 250.0, 10.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([219.925, 250.0, 10.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([218.57500000000002, 250.0, 10.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([218.425, 250.0, 10.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([217.07500000000002, 250.0, 10.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([216.925, 250.0, 9.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([215.57500000000002, 250.0, 9.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([215.425, 250.0, 9.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([214.075, 250.0, 9.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([213.925, 250.0, 9.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([212.575, 250.0, 9.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([212.425, 250.0, 9.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([211.07500000000002, 250.0, 9.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([210.925, 250.0, 9.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([209.57500000000002, 250.0, 9.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([209.425, 250.0, 9.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([208.07500000000002, 250.0, 9.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([207.925, 250.0, 9.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([206.575, 250.0, 9.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([206.425, 250.0, 9.295000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([205.075, 250.0, 9.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([204.925, 250.0, 9.194999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([203.57500000000002, 250.0, 9.104999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([203.425, 250.0, 9.094999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([202.07500000000002, 250.0, 9.004999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([201.925, 250.0, 8.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([200.57500000000002, 250.0, 8.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.425, 250.0, 8.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.075, 250.0, 8.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([198.925, 250.0, 8.795000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([197.575, 250.0, 8.704999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([197.425, 250.0, 8.694999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([196.07500000000002, 250.0, 8.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([195.925, 250.0, 8.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([194.57500000000002, 250.0, 8.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([194.425, 250.0, 8.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([193.07500000000002, 250.0, 8.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([192.925, 250.0, 8.395000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([191.575, 250.0, 8.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([191.42499999999998, 250.0, 8.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([190.075, 250.0, 8.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([189.925, 250.0, 8.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([188.57500000000002, 250.0, 8.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([188.425, 250.0, 8.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([187.07500000000002, 250.0, 8.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([186.925, 250.0, 7.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([185.57500000000002, 250.0, 7.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([185.425, 250.0, 7.8950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([184.075, 250.0, 7.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([183.92499999999998, 250.0, 7.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([182.575, 250.0, 7.705000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([182.425, 250.0, 7.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([181.07500000000002, 250.0, 7.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([180.925, 250.0, 7.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([179.57500000000002, 250.0, 7.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([179.425, 250.0, 7.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([178.07500000000002, 250.0, 7.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([177.925, 250.0, 7.3950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([176.575, 250.0, 7.305000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([176.42499999999998, 250.0, 7.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([175.075, 250.0, 7.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([174.925, 250.0, 7.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([173.57500000000002, 250.0, 7.1049999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([173.425, 250.0, 7.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([172.07500000000002, 250.0, 7.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([171.925, 250.0, 6.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([170.57500000000002, 250.0, 6.905000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([170.425, 250.0, 6.895000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([169.075, 250.0, 6.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([168.92499999999998, 250.0, 6.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([167.575, 250.0, 6.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([167.425, 250.0, 6.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([166.07500000000002, 250.0, 6.6049999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([165.925, 250.0, 6.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([164.57500000000002, 250.0, 6.505000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([164.425, 250.0, 6.495000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([163.07500000000002, 250.0, 6.405000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([162.925, 250.0, 6.3950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([161.575, 250.0, 6.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([161.42499999999998, 250.0, 6.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([160.075, 250.0, 6.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([159.925, 250.0, 6.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([158.57500000000002, 250.0, 6.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([158.425, 250.0, 6.095000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([157.07500000000002, 250.0, 6.005000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([156.925, 250.0, 5.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([155.57500000000002, 250.0, 5.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([155.425, 250.0, 5.8950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([154.075, 250.0, 5.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([153.92499999999998, 250.0, 5.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([152.575, 250.0, 5.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([152.425, 250.0, 5.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.07500000000002, 250.0, 5.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([150.925, 250.0, 5.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([149.57500000000002, 250.0, 5.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([149.425, 250.0, 5.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([148.07500000000002, 250.0, 5.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([147.925, 250.0, 5.3950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([146.575, 250.0, 5.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([146.42499999999998, 250.0, 5.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([145.075, 250.0, 5.205000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([144.925, 250.0, 5.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([143.57500000000002, 250.0, 5.1049999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([143.425, 250.0, 5.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([142.075, 250.0, 5.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([141.925, 250.0, 4.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([140.575, 250.0, 4.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([140.425, 250.0, 4.8950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([139.07500000000002, 250.0, 4.805000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([138.925, 250.0, 4.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([137.575, 250.0, 4.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([137.425, 250.0, 4.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([136.07500000000002, 250.0, 4.6049999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.925, 250.0, 4.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([134.575, 250.0, 4.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([134.425, 250.0, 4.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([133.075, 250.0, 4.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([132.925, 250.0, 4.3950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([131.57500000000002, 250.0, 4.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([131.425, 250.0, 4.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([130.075, 250.0, 4.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([129.925, 250.0, 4.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([128.57500000000002, 250.0, 4.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.425, 250.0, 4.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.075, 250.0, 4.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.925, 250.0, 3.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([125.575, 250.0, 3.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.42500000000001, 250.0, 3.8949999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.07500000000002, 250.0, 3.8049999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.92500000000001, 250.0, 3.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([122.575, 250.0, 3.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.425, 250.0, 3.6950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.075, 250.0, 3.6050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.92500000000001, 250.0, 3.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.575, 250.0, 3.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.425, 250.0, 3.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.075, 250.0, 3.4050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.92500000000001, 250.0, 3.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.57500000000002, 250.0, 3.3049999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.42500000000001, 250.0, 3.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.075, 250.0, 3.2050000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.925, 250.0, 3.1950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([113.575, 250.0, 3.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.42500000000001, 250.0, 3.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.075, 250.0, 3.0050000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.925, 250.0, 2.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([110.575, 250.0, 2.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.42500000000001, 250.0, 2.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.07500000000002, 250.0, 2.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.92500000000001, 250.0, 2.795]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.575, 250.0, 2.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.425, 250.0, 2.6950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.075, 250.0, 2.6050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.92500000000001, 250.0, 2.595]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.575, 250.0, 2.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.425, 250.0, 2.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.075, 250.0, 2.4050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.92500000000001, 250.0, 2.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([101.57500000000002, 250.0, 2.3049999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.42500000000001, 250.0, 2.295]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.075, 250.0, 2.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.925, 250.0, 2.1950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.575, 250.0, 2.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.42500000000001, 250.0, 2.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.075, 250.0, 2.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.925, 250.0, 1.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.575, 250.0, 1.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.425, 250.0, 1.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.075, 250.0, 1.8050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.92500000000001, 250.0, 1.7950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.575, 250.0, 1.705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.425, 250.0, 1.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.075, 250.0, 1.6050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.92500000000001, 250.0, 1.5950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.575, 250.0, 1.5050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.425, 250.0, 1.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.075, 250.0, 1.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.925, 250.0, 1.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.575, 250.0, 1.3050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.42500000000001, 250.0, 1.2950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.075, 250.0, 1.205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.925, 250.0, 1.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.575, 250.0, 1.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.42500000000001, 250.0, 1.0950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.075, 250.0, 1.0050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.925, 250.0, 0.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.575, 250.0, 0.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.425, 250.0, 0.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.075, 250.0, 0.8050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.92500000000001, 250.0, 0.7950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.575, 250.0, 0.7050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.425, 250.0, 0.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.075, 250.0, 0.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.92500000000001, 250.0, 0.5950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.575, 250.0, 0.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.425, 250.0, 0.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.075, 250.0, 0.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.925, 250.0, 0.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.575, 250.0, 0.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.42500000000001, 250.0, 0.29500000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.075, 250.0, 0.20500000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.925, 250.0, 0.19500000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.575, 250.0, 0.10500000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.425, 250.0, 0.09500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.075, 250.0, 0.005000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}

