
hull() {
    translate([12.5, 14.5, 246.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.5, 95.5, 174.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 101.75, 170.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 133.25, 170.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([139.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([141.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([159.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([161.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([179.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([181.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([201.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([219.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([221.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([239.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([241.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([259.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([261.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([279.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([281.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([299.0, 135.0, 170.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([288.0, 133.25, 169.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.0, 101.75, 154.79999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 100.0, 153.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 100.0, 138.8]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 100.0, 137.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 100.0, 122.8]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 100.0, 121.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 100.0, 106.80000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 100.0, 105.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 100.0, 90.8]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 100.0, 89.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 100.0, 74.80000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 100.0, 73.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 100.0, 58.800000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 100.0, 57.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 100.0, 42.800000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 100.0, 41.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 100.0, 26.800000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 100.0, 25.200000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 100.0, 10.8]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 100.0, 9.5]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 100.0, 0.5]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 100.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 100.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}

