color([1, 0, 1]) hull()
{
  translate([5.0, 4.96, 4.9925]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.0, 4.24, 4.8575]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.0, 4.16, 4.827500000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.0, 3.44, 4.4225]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.0, 3.3600000000000003, 4.362500000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.0, 2.6400000000000006, 3.6875]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.0, 2.5600000000000005, 3.5975]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.0, 1.84, 2.6525000000000003]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.0, 1.76, 2.5325]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.0, 1.04, 1.3175]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.0, 0.9750000000000001, 1.2075]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.0, 0.525, 0.44250000000000006]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.01, 0.485, 0.38000000000000006]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.19, 0.21500000000000002, 0.020000000000000004]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.24, 0.19000000000000003, 0.0]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.96, 0.010000000000000002, 0.0]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([6.040000000000001, 0.0, 0.010000000000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([6.76, 0.0, 0.19000000000000003]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([6.84, 0.010000000000000002, 0.22000000000000003]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.56, 0.19000000000000003, 0.5800000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.63, 0.22000000000000003, 0.63]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.17, 0.5800000000000001, 1.1700000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.219999999999999, 0.63, 1.235]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.58, 1.1700000000000002, 1.865]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.61, 1.2400000000000002, 1.94]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.790000000000001, 1.96, 2.66]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.8, 2.04, 2.74]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.8, 2.76, 3.46]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.790000000000001, 2.84, 3.535]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.61, 3.5600000000000005, 4.165]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.58, 3.6350000000000002, 4.23]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.219999999999999, 4.265000000000001, 4.7700000000000005]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.17, 4.325, 4.82]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.63, 4.775, 5.180000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.5649999999999995, 4.815, 5.210000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([6.9350000000000005, 5.085, 5.390000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([6.860000000000001, 5.1049999999999995, 5.4]) cube([0.4, 0.4, 0.1], center = true);
  translate([6.140000000000001, 5.195, 5.4]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([6.0600000000000005, 5.195, 5.390000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.34, 5.1049999999999995, 5.210000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.265, 5.085, 5.180000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([4.635, 4.815, 4.82]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.574999999999999, 4.775, 4.7700000000000005]) cube([0.4, 0.4, 0.1], center = true);
  translate([4.125, 4.325, 4.23]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.085, 4.265000000000001, 4.165]) cube([0.4, 0.4, 0.1], center = true);
  translate([3.815, 3.6350000000000002, 3.535]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([3.79, 3.5600000000000005, 3.46]) cube([0.4, 0.4, 0.1], center = true);
  translate([3.6100000000000003, 2.84, 2.74]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([3.6, 2.76, 2.66]) cube([0.4, 0.4, 0.1], center = true);
  translate([3.6, 2.04, 1.94]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([3.6100000000000003, 1.96, 1.865]) cube([0.4, 0.4, 0.1], center = true);
  translate([3.79, 1.2400000000000002, 1.235]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([3.82, 1.1700000000000002, 1.1700000000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([4.180000000000001, 0.63, 0.63]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.23, 0.5800000000000001, 0.5800000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([4.7700000000000005, 0.22000000000000003, 0.22000000000000003]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.84, 0.19000000000000003, 0.19000000000000003]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.56, 0.010000000000000002, 0.010000000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.640000000000001, 0.0, 0.0]) cube([0.4, 0.4, 0.1], center = true);
  translate([6.360000000000001, 0.0, 0.0]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([6.440000000000001, 0.010000000000000002, 0.010000000000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.16, 0.19000000000000003, 0.19000000000000003]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.235, 0.22000000000000003, 0.22000000000000003]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.865, 0.5800000000000001, 0.5800000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.925000000000001, 0.63, 0.63]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.375, 1.1700000000000002, 1.1700000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.415000000000001, 1.2400000000000002, 1.235]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.684999999999999, 1.96, 1.865]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.704999999999998, 2.04, 1.94]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.795000000000002, 2.76, 2.66]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.795000000000002, 2.84, 2.74]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.704999999999998, 3.5600000000000005, 3.46]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.684999999999999, 3.6350000000000002, 3.535]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.415000000000001, 4.265000000000001, 4.165]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.375, 4.325, 4.23]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.925000000000001, 4.775, 4.7700000000000005]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.865, 4.815, 4.82]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.235, 5.085, 5.180000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.16, 5.1049999999999995, 5.210000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([6.440000000000001, 5.195, 5.390000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([6.360000000000001, 5.195, 5.4]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.640000000000001, 5.1049999999999995, 5.4]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.565, 5.085, 5.390000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([4.9350000000000005, 4.815, 5.210000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.87, 4.775, 5.180000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([4.33, 4.325, 4.82]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.285, 4.265000000000001, 4.7700000000000005]) cube([0.4, 0.4, 0.1], center = true);
  translate([4.015000000000001, 3.6350000000000002, 4.23]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([3.99, 3.5600000000000005, 4.165]) cube([0.4, 0.4, 0.1], center = true);
  translate([3.81, 2.84, 3.535]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([3.8, 2.76, 3.46]) cube([0.4, 0.4, 0.1], center = true);
  translate([3.8, 2.04, 2.74]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([3.81, 1.96, 2.66]) cube([0.4, 0.4, 0.1], center = true);
  translate([3.99, 1.2400000000000002, 1.94]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.015000000000001, 1.1700000000000002, 1.865]) cube([0.4, 0.4, 0.1], center = true);
  translate([4.285, 0.63, 1.235]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.33, 0.5800000000000001, 1.1700000000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([4.87, 0.22000000000000003, 0.63]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.9350000000000005, 0.19000000000000003, 0.5800000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.565, 0.010000000000000002, 0.22000000000000003]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.640000000000001, 0.0, 0.19000000000000003]) cube([0.4, 0.4, 0.1], center = true);
  translate([6.360000000000001, 0.0, 0.010000000000000002]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([6.440000000000001, 0.0, 0.0]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.16, 0.0, 0.0]) cube([0.4, 0.4, 0.1], center = true);
}
