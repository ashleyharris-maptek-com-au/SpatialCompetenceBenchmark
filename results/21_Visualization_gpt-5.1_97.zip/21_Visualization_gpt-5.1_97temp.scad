
hull() {
    translate([5.045, 5.0, 47.980000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.855, 5.0, 47.620000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.945, 5.0, 47.580000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.755, 5.0, 47.220000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.845000000000001, 5.0, 47.175000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.655000000000001, 5.0, 46.725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.745000000000001, 5.0, 46.675000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.555, 5.0, 46.22500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.645, 5.0, 46.175000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.455, 5.0, 45.725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.545, 5.0, 45.675000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.355, 5.0, 45.22500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.445000000000002, 5.0, 45.175000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.255000000000003, 5.0, 44.725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.345000000000002, 5.0, 44.67]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.155000000000001, 5.0, 44.13]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.245000000000001, 5.0, 44.07000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.055, 5.0, 43.53]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.145, 5.0, 43.47]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.955, 5.0, 42.93]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.045, 5.0, 42.87]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.855, 5.0, 42.33]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.945, 5.0, 42.265]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.755, 5.0, 41.635000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.845, 5.0, 41.565000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.655, 5.0, 40.935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.744999999999997, 5.0, 40.865]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.555, 5.0, 40.23500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.645000000000003, 5.0, 40.165000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.455000000000002, 5.0, 39.535000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.545, 5.0, 39.465]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.355, 5.0, 38.835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.445, 5.0, 38.760000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.255, 5.0, 38.040000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.345, 5.0, 37.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.154999999999998, 5.0, 37.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.244999999999997, 5.0, 37.160000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.055, 5.0, 36.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.145, 5.0, 36.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.955, 5.0, 35.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.044999999999998, 5.0, 35.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.854999999999997, 5.0, 34.745000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.945, 5.0, 34.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.755000000000003, 5.0, 33.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.845, 5.0, 33.754999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.655, 5.0, 32.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.744999999999997, 5.0, 32.85]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.555, 5.0, 31.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.645000000000003, 5.0, 31.85]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.455, 5.0, 30.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.545, 5.0, 30.849999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.354999999999997, 5.0, 29.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.445, 5.0, 29.845]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.255000000000003, 5.0, 28.855000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.345000000000002, 5.0, 28.745]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.155, 5.0, 27.755]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.245, 5.0, 27.645]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.055000000000003, 5.0, 26.655]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.145000000000003, 5.0, 26.540000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.955000000000002, 5.0, 25.46]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.045, 5.0, 25.34]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.855, 5.0, 24.26]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.945, 5.0, 24.135]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.754999999999995, 5.0, 22.965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.845, 5.0, 22.835]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.655, 5.0, 21.665000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.745000000000005, 5.0, 21.53]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.555, 5.0, 20.27]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.644999999999996, 5.0, 20.13]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.455, 5.0, 18.87]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.545, 5.0, 18.725]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.355, 5.0, 17.375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.44499999999999, 5.0, 17.225]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.254999999999995, 5.0, 15.875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.345, 5.0, 15.72]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.155, 5.0, 14.28]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.245000000000005, 5.0, 14.114999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.05500000000001, 5.0, 12.585]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.145, 5.0, 12.415]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.955, 5.0, 10.885000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.045, 5.0, 10.71]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.855000000000004, 5.0, 9.09]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.945, 5.0, 8.91]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.754999999999995, 5.0, 7.290000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.845, 5.0, 7.105]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.65500000000001, 5.0, 5.395]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.745000000000005, 5.0, 5.199999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.555, 5.0, 3.4]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.645, 5.0, 3.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.455000000000005, 5.0, 1.3050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.545, 5.0, 1.1400000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.355, 5.0, 0.06]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.394999999999996, 5.045, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.305, 5.855, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.295, 5.945, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.205000000000005, 6.755, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.19500000000001, 6.845000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.105000000000004, 7.655000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.095, 7.745000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.004999999999995, 8.555, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.995, 8.645, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.905, 9.455, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.895, 9.545, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.805, 10.355, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.795, 10.445000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.705000000000005, 11.255000000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.695, 11.345000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.605, 12.155000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.595, 12.245000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.505, 13.055, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.495000000000005, 13.145, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.405, 13.955, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.394999999999996, 14.045, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.30499999999999, 14.855, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.294999999999995, 14.945, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.205000000000005, 15.755, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.19500000000001, 15.845, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.105000000000004, 16.655, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.095000000000006, 16.744999999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.005, 17.555, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.995, 17.645000000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.904999999999994, 18.455000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.894999999999996, 18.545, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.805, 19.355, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.795, 19.445, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.705000000000005, 20.255, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.69500000000001, 20.345, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.605000000000004, 21.154999999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.595, 21.244999999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.505, 22.055, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.495000000000005, 22.145, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.405, 22.955, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.395, 23.044999999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.305, 23.854999999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.294999999999995, 23.945, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.205, 24.755000000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.195, 24.845, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.105000000000004, 25.655, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.095000000000006, 25.744999999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.005, 26.555, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.995000000000005, 26.645000000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.905, 27.455, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.894999999999996, 27.545, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.805, 28.354999999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.795, 28.445, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.705000000000005, 29.255000000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.69500000000001, 29.345000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.605000000000004, 30.155, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.595, 30.245, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.504999999999995, 31.055000000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.495, 31.145000000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.405, 31.955000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.395, 32.045, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.305, 32.855, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.295, 32.945, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.205000000000005, 33.754999999999995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.195, 33.845, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.105, 34.655, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.095, 34.745000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.005, 35.555, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.995000000000005, 35.644999999999996, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.905, 36.455, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.894999999999996, 36.545, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.80499999999999, 37.355, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.794999999999995, 37.44499999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.705000000000005, 38.254999999999995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.69500000000001, 38.345, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.605000000000004, 39.155, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.595000000000006, 39.245000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.505, 40.05500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.495, 40.145, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.404999999999994, 40.955, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.394999999999996, 41.045, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.305, 41.855000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.295, 41.945, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.205000000000005, 42.754999999999995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.19500000000001, 42.845, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.105000000000004, 43.65500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.095, 43.745000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.005, 44.555, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.995000000000005, 44.645, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.905, 45.455000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.895, 45.545, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.805, 46.355, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.794999999999995, 46.445, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.705, 47.255, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.695, 47.345, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.605000000000004, 48.155, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.595000000000006, 48.245000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.505, 49.05500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.495000000000005, 49.145, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.405, 49.955, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}

