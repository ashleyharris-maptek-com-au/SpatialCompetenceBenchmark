
hull() {
    translate([1.04, 1.04, 4.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.76, 1.76, 4.5249999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.84, 1.84, 4.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.5600000000000005, 2.5600000000000005, 4.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.6400000000000006, 2.6400000000000006, 3.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.3600000000000003, 3.3600000000000003, 3.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.44, 3.44, 3.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.16, 4.16, 3.0250000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.24, 4.24, 2.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.96, 4.96, 2.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.04, 5.04, 2.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.76, 5.76, 2.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.84, 5.84, 1.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.56, 6.56, 1.5250000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.64, 6.64, 1.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.36, 7.36, 1.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.44, 7.44, 0.9750000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.16, 8.16, 0.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.24, 8.24, 0.47500000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.959999999999999, 8.959999999999999, 0.025]) cube([0.4, 0.4, 0.1], center=true);
}

