
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.470293538807065]);

translate([2, 0, 0]) cube([1, 1, 4.4739600876991705]);

translate([3, 0, 0]) cube([1, 1, 4.4731433372448315]);

translate([4, 0, 0]) cube([1, 1, 4.473805767082637]);

translate([5, 0, 0]) cube([1, 1, 4.47283059605894]);

translate([6, 0, 0]) cube([1, 1, 4.5]);

translate([7, 0, 0]) cube([1, 1, 4.4731120682079215]);

translate([8, 0, 0]) cube([1, 1, 4.4722427173001655]);

translate([9, 0, 0]) cube([1, 1, 4.6]);

translate([10, 0, 0]) cube([1, 1, 5.0]);

translate([11, 0, 0]) cube([1, 1, 5.3]);

translate([12, 0, 0]) cube([1, 1, 4.4737548264323745]);

translate([13, 0, 0]) cube([1, 1, 4.474593170578727]);

translate([14, 0, 0]) cube([1, 1, 4.47461233449987]);

translate([15, 0, 0]) cube([1, 1, 4.47454078151741]);

translate([16, 0, 0]) cube([1, 1, 4.474265742215341]);

translate([17, 0, 0]) cube([1, 1, 4.474291023719063]);

translate([18, 0, 0]) cube([1, 1, 4.475045795082487]);

translate([19, 0, 0]) cube([1, 1, 4.47400658637103]);

translate([0, 1, 0]) cube([1, 1, 6.2]);

translate([1, 1, 0]) cube([1, 1, 5.3]);

translate([2, 1, 0]) cube([1, 1, 4.8]);

translate([3, 1, 0]) cube([1, 1, 4.472477906174648]);

translate([4, 1, 0]) cube([1, 1, 4.473200925635201]);

translate([5, 1, 0]) cube([1, 1, 4.473707858728716]);

translate([6, 1, 0]) cube([1, 1, 4.475385393305601]);

translate([7, 1, 0]) cube([1, 1, 4.475888259109674]);

translate([8, 1, 0]) cube([1, 1, 4.476069537556102]);

translate([9, 1, 0]) cube([1, 1, 4.474571150769928]);

translate([10, 1, 0]) cube([1, 1, 4.474421089693024]);

translate([11, 1, 0]) cube([1, 1, 4.475037056180357]);

translate([12, 1, 0]) cube([1, 1, 4.476117581819365]);

translate([13, 1, 0]) cube([1, 1, 4.476688927170238]);

translate([14, 1, 0]) cube([1, 1, 4.477114948968482]);

translate([15, 1, 0]) cube([1, 1, 4.477069967929812]);

translate([16, 1, 0]) cube([1, 1, 4.477419136463115]);

translate([17, 1, 0]) cube([1, 1, 4.4775782404585565]);

translate([18, 1, 0]) cube([1, 1, 4.477335821396204]);

translate([19, 1, 0]) cube([1, 1, 4.4762439969982415]);

translate([0, 2, 0]) cube([1, 1, 7.0]);

translate([1, 2, 0]) cube([1, 1, 6.1]);

translate([2, 2, 0]) cube([1, 1, 5.7]);

translate([3, 2, 0]) cube([1, 1, 5.2]);

translate([4, 2, 0]) cube([1, 1, 5.1]);

translate([5, 2, 0]) cube([1, 1, 4.8]);

translate([6, 2, 0]) cube([1, 1, 4.474231466808985]);

translate([7, 2, 0]) cube([1, 1, 4.476260170016051]);

translate([8, 2, 0]) cube([1, 1, 4.476231243321833]);

translate([9, 2, 0]) cube([1, 1, 4.475937451878335]);

translate([10, 2, 0]) cube([1, 1, 4.474609236844849]);

translate([11, 2, 0]) cube([1, 1, 4.475035904519901]);

translate([12, 2, 0]) cube([1, 1, 4.476235373419995]);

translate([13, 2, 0]) cube([1, 1, 4.477280310574203]);

translate([14, 2, 0]) cube([1, 1, 4.477466025137639]);

translate([15, 2, 0]) cube([1, 1, 4.477436683920757]);

translate([16, 2, 0]) cube([1, 1, 4.477539169657235]);

translate([17, 2, 0]) cube([1, 1, 4.477949586426355]);

translate([18, 2, 0]) cube([1, 1, 4.478883218314007]);

translate([19, 2, 0]) cube([1, 1, 4.476561619552299]);

translate([0, 3, 0]) cube([1, 1, 7.4]);

translate([1, 3, 0]) cube([1, 1, 6.6]);

translate([2, 3, 0]) cube([1, 1, 6.3]);

translate([3, 3, 0]) cube([1, 1, 5.8]);

translate([4, 3, 0]) cube([1, 1, 5.6]);

translate([5, 3, 0]) cube([1, 1, 5.2]);

translate([6, 3, 0]) cube([1, 1, 4.7]);

translate([7, 3, 0]) cube([1, 1, 4.8]);

translate([8, 3, 0]) cube([1, 1, 4.476856237868837]);

translate([9, 3, 0]) cube([1, 1, 4.474592777907765]);

translate([10, 3, 0]) cube([1, 1, 5.0]);

translate([11, 3, 0]) cube([1, 1, 4.7]);

translate([12, 3, 0]) cube([1, 1, 4.475733827104429]);

translate([13, 3, 0]) cube([1, 1, 4.477563104238055]);

translate([14, 3, 0]) cube([1, 1, 4.477422490208356]);

translate([15, 3, 0]) cube([1, 1, 4.477158341674332]);

translate([16, 3, 0]) cube([1, 1, 4.4783075822147485]);

translate([17, 3, 0]) cube([1, 1, 4.478543162149026]);

translate([18, 3, 0]) cube([1, 1, 4.478325704896253]);

translate([19, 3, 0]) cube([1, 1, 4.477983640841681]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.2]);

translate([2, 4, 0]) cube([1, 1, 6.9]);

translate([3, 4, 0]) cube([1, 1, 6.4]);

translate([4, 4, 0]) cube([1, 1, 6.1]);

translate([5, 4, 0]) cube([1, 1, 5.7]);

translate([6, 4, 0]) cube([1, 1, 5.3]);

translate([7, 4, 0]) cube([1, 1, 5.4]);

translate([8, 4, 0]) cube([1, 1, 5.8]);

translate([9, 4, 0]) cube([1, 1, 4.9]);

translate([10, 4, 0]) cube([1, 1, 5.3]);

translate([11, 4, 0]) cube([1, 1, 4.7]);

translate([12, 4, 0]) cube([1, 1, 4.475794359497151]);

translate([13, 4, 0]) cube([1, 1, 4.4768619145709385]);

translate([14, 4, 0]) cube([1, 1, 4.477076135740568]);

translate([15, 4, 0]) cube([1, 1, 4.477117349717401]);

translate([16, 4, 0]) cube([1, 1, 4.476883399671686]);

translate([17, 4, 0]) cube([1, 1, 4.477416167228133]);

translate([18, 4, 0]) cube([1, 1, 4.478579615980302]);

translate([19, 4, 0]) cube([1, 1, 4.477689569355805]);

translate([0, 5, 0]) cube([1, 1, 7.9]);

translate([1, 5, 0]) cube([1, 1, 7.4]);

translate([2, 5, 0]) cube([1, 1, 7.0]);

translate([3, 5, 0]) cube([1, 1, 6.1]);

translate([4, 5, 0]) cube([1, 1, 6.5]);

translate([5, 5, 0]) cube([1, 1, 6.2]);

translate([6, 5, 0]) cube([1, 1, 5.282496351896077]);

translate([7, 5, 0]) cube([1, 1, 5.3]);

translate([8, 5, 0]) cube([1, 1, 6.1]);

translate([9, 5, 0]) cube([1, 1, 5.7]);

translate([10, 5, 0]) cube([1, 1, 4.473396206358491]);

translate([11, 5, 0]) cube([1, 1, 4.476444775220054]);

translate([12, 5, 0]) cube([1, 1, 4.476145572107077]);

translate([13, 5, 0]) cube([1, 1, 4.476061766172062]);

translate([14, 5, 0]) cube([1, 1, 4.477980935063791]);

translate([15, 5, 0]) cube([1, 1, 4.6]);

translate([16, 5, 0]) cube([1, 1, 4.6]);

translate([17, 5, 0]) cube([1, 1, 4.7]);

translate([18, 5, 0]) cube([1, 1, 4.5]);

translate([19, 5, 0]) cube([1, 1, 4.5]);

translate([0, 6, 0]) cube([1, 1, 5.772480478759548]);

translate([1, 6, 0]) cube([1, 1, 5.87073551630757]);

translate([2, 6, 0]) cube([1, 1, 6.494001435252907]);

translate([3, 6, 0]) cube([1, 1, 6.5]);

translate([4, 6, 0]) cube([1, 1, 6.8]);

translate([5, 6, 0]) cube([1, 1, 6.6]);

translate([6, 6, 0]) cube([1, 1, 6.1]);

translate([7, 6, 0]) cube([1, 1, 5.200007164899115]);

translate([8, 6, 0]) cube([1, 1, 5.199999999610824]);

translate([9, 6, 0]) cube([1, 1, 5.2]);

translate([10, 6, 0]) cube([1, 1, 4.475540222064713]);

translate([11, 6, 0]) cube([1, 1, 4.47696164575903]);

translate([12, 6, 0]) cube([1, 1, 4.476706186345591]);

translate([13, 6, 0]) cube([1, 1, 4.475829873498942]);

translate([14, 6, 0]) cube([1, 1, 4.6]);

translate([15, 6, 0]) cube([1, 1, 5.4]);

translate([16, 6, 0]) cube([1, 1, 5.3]);

translate([17, 6, 0]) cube([1, 1, 5.1]);

translate([18, 6, 0]) cube([1, 1, 4.9]);

translate([19, 6, 0]) cube([1, 1, 5.2]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.4]);

translate([2, 7, 0]) cube([1, 1, 6.9]);

translate([3, 7, 0]) cube([1, 1, 7.1]);

translate([4, 7, 0]) cube([1, 1, 7.2]);

translate([5, 7, 0]) cube([1, 1, 6.8]);

translate([6, 7, 0]) cube([1, 1, 6.4]);

translate([7, 7, 0]) cube([1, 1, 5.253115641679394]);

translate([8, 7, 0]) cube([1, 1, 5.1999999987039525]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

translate([10, 7, 0]) cube([1, 1, 4.474628635217193]);

translate([11, 7, 0]) cube([1, 1, 4.476751635118853]);

translate([12, 7, 0]) cube([1, 1, 4.9]);

translate([13, 7, 0]) cube([1, 1, 4.8]);

translate([14, 7, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 7, 0]) cube([1, 1, 6]);

translate([17, 7, 0]) cube([1, 1, 4.9]);

color([0,1,0])
translate([18, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 8.1]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 6.9]);

translate([3, 8, 0]) cube([1, 1, 7.6]);

translate([4, 8, 0]) cube([1, 1, 7.5]);

translate([5, 8, 0]) cube([1, 1, 7.0]);

translate([6, 8, 0]) cube([1, 1, 6.8]);

translate([7, 8, 0]) cube([1, 1, 6.7]);

translate([8, 8, 0]) cube([1, 1, 5.142462069159462]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

translate([10, 8, 0]) cube([1, 1, 4.47560885346971]);

translate([11, 8, 0]) cube([1, 1, 5.3]);

translate([12, 8, 0]) cube([1, 1, 5.2]);

translate([13, 8, 0]) cube([1, 1, 5.1]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 8, 0]) cube([1, 1, 6]);

translate([17, 8, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([18, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 8.1]);

translate([1, 9, 0]) cube([1, 1, 7.8]);

color([0,1,0])
translate([2, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 9, 0]) cube([1, 1, 6]);

translate([5, 9, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([6, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 9, 0]) cube([1, 1, 6]);

translate([8, 9, 0]) cube([1, 1, 5.143188044426051]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

translate([11, 9, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 6.9]);

translate([18, 9, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.7]);

color([0,1,0])
translate([1, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 10, 0]) cube([1, 1, 6]);

translate([3, 10, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([4, 10, 0]) cube([1, 1, 6]);

translate([5, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([6, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

translate([9, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

translate([12, 10, 0]) cube([1, 1, 4.739792320963452]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 6.6]);

translate([18, 10, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 6.9]);

translate([1, 11, 0]) cube([1, 1, 6.7]);

translate([2, 11, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 11, 0]) cube([1, 1, 6]);

translate([8, 11, 0]) cube([1, 1, 6.7]);

translate([9, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

translate([12, 11, 0]) cube([1, 1, 5.4999749829452735]);

translate([13, 11, 0]) cube([1, 1, 5.499972058439003]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([1, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 12, 0]) cube([1, 1, 6]);

translate([8, 12, 0]) cube([1, 1, 4.902433440353854]);

translate([9, 12, 0]) cube([1, 1, 5.182485662423813]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

translate([13, 12, 0]) cube([1, 1, 5.499992224914352]);

translate([14, 12, 0]) cube([1, 1, 5.499986003881883]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 7.1]);

translate([1, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

translate([8, 13, 0]) cube([1, 1, 6.6]);

translate([9, 13, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

translate([14, 13, 0]) cube([1, 1, 5.499982520650372]);

translate([15, 13, 0]) cube([1, 1, 5.499987130241867]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

translate([19, 13, 0]) cube([1, 1, 5.379256246658637]);

translate([0, 14, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

translate([8, 14, 0]) cube([1, 1, 6.7]);

translate([9, 14, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

translate([13, 14, 0]) cube([1, 1, 5.309719393005202]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

translate([19, 14, 0]) cube([1, 1, 5.374767396319941]);

translate([0, 15, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 15, 0]) cube([1, 1, 6]);

translate([7, 15, 0]) cube([1, 1, 6.8]);

translate([8, 15, 0]) cube([1, 1, 7.1]);

translate([9, 15, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

translate([17, 15, 0]) cube([1, 1, 5.489535093995564]);

translate([18, 15, 0]) cube([1, 1, 5.493968000755611]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 16, 0]) cube([1, 1, 6]);

translate([7, 16, 0]) cube([1, 1, 7.0]);

translate([8, 16, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([9, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

translate([16, 16, 0]) cube([1, 1, 5.488128413176384]);

translate([17, 16, 0]) cube([1, 1, 5.489797104342542]);

translate([18, 16, 0]) cube([1, 1, 5.488911142680119]);

translate([19, 16, 0]) cube([1, 1, 5.488621304869585]);

color([0,1,0])
translate([0, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

translate([6, 17, 0]) cube([1, 1, 6.7]);

translate([7, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

translate([16, 18, 0]) cube([1, 1, 5.4]);

translate([17, 18, 0]) cube([1, 1, 5.316636206635552]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 5.483075496613174]);

translate([1, 19, 0]) cube([1, 1, 5.489536094632642]);

translate([2, 19, 0]) cube([1, 1, 5.496832476529536]);

translate([3, 19, 0]) cube([1, 1, 5.497591727127717]);

translate([4, 19, 0]) cube([1, 1, 5.497567176765532]);

translate([5, 19, 0]) cube([1, 1, 5.496870755226154]);

translate([6, 19, 0]) cube([1, 1, 5.490460836702226]);

translate([7, 19, 0]) cube([1, 1, 5.489673155098061]);

translate([8, 19, 0]) cube([1, 1, 5.490624482514668]);

translate([9, 19, 0]) cube([1, 1, 5.488297696943401]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

translate([14, 19, 0]) cube([1, 1, 5.316637994053403]);

translate([15, 19, 0]) cube([1, 1, 5.316741412822943]);

translate([16, 19, 0]) cube([1, 1, 5.316746406722595]);

translate([17, 19, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);
