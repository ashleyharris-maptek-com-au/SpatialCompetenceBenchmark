
translate([0, 0, 0]) cube([1, 1, 5.006195334826209]);

translate([1, 0, 0]) cube([1, 1, 4.321645289982149]);

translate([2, 0, 0]) cube([1, 1, 4.237679526599926]);

translate([3, 0, 0]) cube([1, 1, 4.238694572693566]);

translate([4, 0, 0]) cube([1, 1, 4.243625355150703]);

translate([5, 0, 0]) cube([1, 1, 4.347067607917925]);

translate([6, 0, 0]) cube([1, 1, 4.506944444444445]);

translate([7, 0, 0]) cube([1, 1, 4.389677294206285]);

translate([8, 0, 0]) cube([1, 1, 4.375059392672464]);

translate([9, 0, 0]) cube([1, 1, 4.660816326530611]);

translate([10, 0, 0]) cube([1, 1, 5.016666666666667]);

translate([11, 0, 0]) cube([1, 1, 5.383333333333333]);

translate([12, 0, 0]) cube([1, 1, 4.268419375263203]);

translate([13, 0, 0]) cube([1, 1, 4.2941656719318]);

translate([14, 0, 0]) cube([1, 1, 4.157751711776941]);

translate([15, 0, 0]) cube([1, 1, 4.055231345545125]);

translate([16, 0, 0]) cube([1, 1, 4.046199741651034]);

translate([17, 0, 0]) cube([1, 1, 4.04568946917592]);

translate([18, 0, 0]) cube([1, 1, 3.9034208927214435]);

translate([19, 0, 0]) cube([1, 1, 3.903405921166154]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.312257337723117]);

translate([2, 1, 0]) cube([1, 1, 4.824704577392128]);

translate([3, 1, 0]) cube([1, 1, 4.340726338288173]);

translate([4, 1, 0]) cube([1, 1, 4.3460006765434125]);

translate([5, 1, 0]) cube([1, 1, 4.375439713387608]);

translate([6, 1, 0]) cube([1, 1, 4.4241960668442175]);

translate([7, 1, 0]) cube([1, 1, 4.380144382159966]);

translate([8, 1, 0]) cube([1, 1, 4.375656008487189]);

translate([9, 1, 0]) cube([1, 1, 4.356497082217906]);

translate([10, 1, 0]) cube([1, 1, 4.646450498266186]);

translate([11, 1, 0]) cube([1, 1, 4.240960235694904]);

translate([12, 1, 0]) cube([1, 1, 4.1728240124600715]);

translate([13, 1, 0]) cube([1, 1, 4.1506066824692525]);

translate([14, 1, 0]) cube([1, 1, 4.063709409430646]);

translate([15, 1, 0]) cube([1, 1, 4.054677527612958]);

translate([16, 1, 0]) cube([1, 1, 4.047495863036946]);

translate([17, 1, 0]) cube([1, 1, 4.0455905059132125]);

translate([18, 1, 0]) cube([1, 1, 4.08157874051124]);

translate([19, 1, 0]) cube([1, 1, 4.189108465608466]);

translate([0, 2, 0]) cube([1, 1, 7.000666666600514]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.25077886041721]);

translate([4, 2, 0]) cube([1, 1, 5.167387944970096]);

translate([5, 2, 0]) cube([1, 1, 4.8767120423184345]);

translate([6, 2, 0]) cube([1, 1, 4.519293111759978]);

translate([7, 2, 0]) cube([1, 1, 4.55558281597518]);

translate([8, 2, 0]) cube([1, 1, 4.5980330502362285]);

translate([9, 2, 0]) cube([1, 1, 4.406286019704592]);

translate([10, 2, 0]) cube([1, 1, 3.993695269324083]);

translate([11, 2, 0]) cube([1, 1, 3.9453538135922495]);

translate([12, 2, 0]) cube([1, 1, 3.9453509816413788]);

translate([13, 2, 0]) cube([1, 1, 4.419215412920636]);

translate([14, 2, 0]) cube([1, 1, 4.127096050352227]);

translate([15, 2, 0]) cube([1, 1, 4.075460172464155]);

translate([16, 2, 0]) cube([1, 1, 4.066893272080154]);

translate([17, 2, 0]) cube([1, 1, 3.632866848812669]);

translate([18, 2, 0]) cube([1, 1, 4.046942855565305]);

translate([19, 2, 0]) cube([1, 1, 4.046959261422097]);

translate([0, 3, 0]) cube([1, 1, 7.4033333332782085]);

translate([1, 3, 0]) cube([1, 1, 6.634404770006096]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.324227249760271]);

translate([6, 3, 0]) cube([1, 1, 4.942841465664234]);

translate([7, 3, 0]) cube([1, 1, 4.9478452910674715]);

translate([8, 3, 0]) cube([1, 1, 4.037814503195722]);

translate([9, 3, 0]) cube([1, 1, 4.027019574301683]);

translate([10, 3, 0]) cube([1, 1, 5.103179063907474]);

translate([11, 3, 0]) cube([1, 1, 4.780797685570773]);

translate([12, 3, 0]) cube([1, 1, 4.475379677215266]);

translate([13, 3, 0]) cube([1, 1, 4.1986706526036865]);

translate([14, 3, 0]) cube([1, 1, 4.132414026025336]);

translate([15, 3, 0]) cube([1, 1, 4.100650846243798]);

translate([16, 3, 0]) cube([1, 1, 4.081152690236997]);

translate([17, 3, 0]) cube([1, 1, 4.061395292871434]);

translate([18, 3, 0]) cube([1, 1, 4.047069338196614]);

translate([19, 3, 0]) cube([1, 1, 4.04706805511195]);

translate([0, 4, 0]) cube([1, 1, 7.916666666620729]);

translate([1, 4, 0]) cube([1, 1, 7.248807256190675]);

translate([2, 4, 0]) cube([1, 1, 6.968145158267491]);

translate([3, 4, 0]) cube([1, 1, 6.522699614856303]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 4, 0]) cube([1, 1, 6]);

translate([9, 4, 0]) cube([1, 1, 5.0975414888651125]);

translate([10, 4, 0]) cube([1, 1, 5.408667118644229]);

translate([11, 4, 0]) cube([1, 1, 4.889863694930365]);

translate([12, 4, 0]) cube([1, 1, 4.526905242565382]);

translate([13, 4, 0]) cube([1, 1, 4.421858238457455]);

translate([14, 4, 0]) cube([1, 1, 3.9461369873047403]);

translate([15, 4, 0]) cube([1, 1, 4.127051139396053]);

translate([16, 4, 0]) cube([1, 1, 4.096680236368077]);

translate([17, 4, 0]) cube([1, 1, 4.115278945037431]);

translate([18, 4, 0]) cube([1, 1, 4.049189194236289]);

translate([19, 4, 0]) cube([1, 1, 4.047735965771645]);

translate([0, 5, 0]) cube([1, 1, 7.916666666620729]);

translate([1, 5, 0]) cube([1, 1, 7.512925169989273]);

translate([2, 5, 0]) cube([1, 1, 7.151900428828725]);

color([0,1,0])
translate([3, 5, 0]) cube([1, 1, 6]);

translate([4, 5, 0]) cube([1, 1, 6.626865350488691]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 5, 0]) cube([1, 1, 6]);

translate([10, 5, 0]) cube([1, 1, 4.854717888025201]);

translate([11, 5, 0]) cube([1, 1, 4.859988507058029]);

translate([12, 5, 0]) cube([1, 1, 4.795848669625924]);

translate([13, 5, 0]) cube([1, 1, 4.58254069192765]);

translate([14, 5, 0]) cube([1, 1, 4.569412507453427]);

translate([15, 5, 0]) cube([1, 1, 4.632087385457345]);

translate([16, 5, 0]) cube([1, 1, 4.628342750524601]);

translate([17, 5, 0]) cube([1, 1, 4.725652783233785]);

translate([18, 5, 0]) cube([1, 1, 4.537678136466202]);

translate([19, 5, 0]) cube([1, 1, 4.531392591109797]);

color([0,1,0])
translate([0, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 6, 0]) cube([1, 1, 6]);

translate([3, 6, 0]) cube([1, 1, 6.840446422430247]);

translate([4, 6, 0]) cube([1, 1, 6.862066593920701]);

translate([5, 6, 0]) cube([1, 1, 6.637964380117562]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 6, 0]) cube([1, 1, 6]);

translate([10, 6, 0]) cube([1, 1, 5.08727680938981]);

translate([11, 6, 0]) cube([1, 1, 4.795390987839555]);

translate([12, 6, 0]) cube([1, 1, 4.717085173261724]);

translate([13, 6, 0]) cube([1, 1, 4.609102840556831]);

translate([14, 6, 0]) cube([1, 1, 4.738767416994997]);

translate([15, 6, 0]) cube([1, 1, 5.408279533291492]);

translate([16, 6, 0]) cube([1, 1, 5.330003052394898]);

translate([17, 6, 0]) cube([1, 1, 5.147108275987862]);

translate([18, 6, 0]) cube([1, 1, 4.976805371019937]);

translate([19, 6, 0]) cube([1, 1, 5.20925925925926]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.567517928051402]);

translate([2, 7, 0]) cube([1, 1, 7.221990134196235]);

translate([3, 7, 0]) cube([1, 1, 7.206088318253667]);

translate([4, 7, 0]) cube([1, 1, 7.230697869425548]);

translate([5, 7, 0]) cube([1, 1, 6.852561814839592]);

translate([6, 7, 0]) cube([1, 1, 6.501284826459105]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

translate([10, 7, 0]) cube([1, 1, 5.078679034439601]);

translate([11, 7, 0]) cube([1, 1, 5.068117798536421]);

translate([12, 7, 0]) cube([1, 1, 5.243755190164403]);

translate([13, 7, 0]) cube([1, 1, 5.127101110809755]);

translate([14, 7, 0]) cube([1, 1, 5.407003514401794]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 7, 0]) cube([1, 1, 6]);

translate([17, 7, 0]) cube([1, 1, 5.113816911795583]);

color([0,1,0])
translate([18, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 8.11875]);

translate([1, 8, 0]) cube([1, 1, 7.626375850340136]);

translate([2, 8, 0]) cube([1, 1, 7.148841440096762]);

translate([3, 8, 0]) cube([1, 1, 7.618650793650793]);

translate([4, 8, 0]) cube([1, 1, 7.509957837301587]);

translate([5, 8, 0]) cube([1, 1, 7.054152476278904]);

translate([6, 8, 0]) cube([1, 1, 6.912604788640724]);

translate([7, 8, 0]) cube([1, 1, 6.847855845959633]);

translate([8, 8, 0]) cube([1, 1, 4.10666987803351]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

translate([10, 8, 0]) cube([1, 1, 4.922822472383237]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

translate([12, 8, 0]) cube([1, 1, 5.416966920541872]);

translate([13, 8, 0]) cube([1, 1, 5.27669155963147]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 8, 0]) cube([1, 1, 6]);

translate([17, 8, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([18, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 8.10375]);

translate([1, 9, 0]) cube([1, 1, 7.813418367346939]);

translate([2, 9, 0]) cube([1, 1, 6.457172243716616]);

translate([3, 9, 0]) cube([1, 1, 6.697149967562348]);

translate([4, 9, 0]) cube([1, 1, 6.656373895918914]);

translate([5, 9, 0]) cube([1, 1, 7.05914858616699]);

color([0,1,0])
translate([6, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 9, 0]) cube([1, 1, 6]);

translate([8, 9, 0]) cube([1, 1, 5.172678463683367]);

translate([9, 9, 0]) cube([1, 1, 6.694465820538192]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 6.9]);

translate([18, 9, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.704292091836735]);

translate([1, 10, 0]) cube([1, 1, 6.6176397246824905]);

translate([2, 10, 0]) cube([1, 1, 6.588590644549005]);

translate([3, 10, 0]) cube([1, 1, 6.974716599668038]);

translate([4, 10, 0]) cube([1, 1, 6.671526829317704]);

translate([5, 10, 0]) cube([1, 1, 6.741260465872047]);

color([0,1,0])
translate([6, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

translate([9, 10, 0]) cube([1, 1, 6.702293629768191]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

translate([12, 10, 0]) cube([1, 1, 4.239193598568234]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 6.6]);

translate([18, 10, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 6.969429846938776]);

translate([1, 11, 0]) cube([1, 1, 6.836048772761258]);

translate([2, 11, 0]) cube([1, 1, 6.738125043122642]);

translate([3, 11, 0]) cube([1, 1, 6.556553955075712]);

color([0,1,0])
translate([4, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.70467429168403]);

translate([8, 11, 0]) cube([1, 1, 6.841066296076832]);

translate([9, 11, 0]) cube([1, 1, 6.879595908722769]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 6.8479606970764495]);

translate([1, 12, 0]) cube([1, 1, 6.611722187280471]);

color([0,1,0])
translate([2, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 12, 0]) cube([1, 1, 6]);

translate([8, 12, 0]) cube([1, 1, 4.92324025567536]);

translate([9, 12, 0]) cube([1, 1, 5.218422202627565]);

translate([10, 12, 0]) cube([1, 1, 6.573462946238333]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 7.1]);

translate([1, 13, 0]) cube([1, 1, 6.620871699026831]);

color([0,1,0])
translate([2, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

translate([8, 13, 0]) cube([1, 1, 6.72115771782877]);

translate([9, 13, 0]) cube([1, 1, 6.896548099829085]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

translate([19, 13, 0]) cube([1, 1, 5.3]);

translate([0, 14, 0]) cube([1, 1, 7.0]);

translate([1, 14, 0]) cube([1, 1, 6.504174339805367]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

translate([8, 14, 0]) cube([1, 1, 6.753033098545191]);

translate([9, 14, 0]) cube([1, 1, 6.827444965428722]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

translate([13, 14, 0]) cube([1, 1, 4.063530402782362]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

translate([19, 14, 0]) cube([1, 1, 5.014634214180304]);

translate([0, 15, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 15, 0]) cube([1, 1, 6]);

translate([7, 15, 0]) cube([1, 1, 6.802777777777778]);

translate([8, 15, 0]) cube([1, 1, 7.1]);

translate([9, 15, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

translate([17, 15, 0]) cube([1, 1, 5.447766638176165]);

translate([18, 15, 0]) cube([1, 1, 5.129268433800117]);

translate([19, 15, 0]) cube([1, 1, 4.760158848465126]);

color([0,1,0])
translate([0, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 16, 0]) cube([1, 1, 6]);

translate([6, 16, 0]) cube([1, 1, 6.500555555555556]);

translate([7, 16, 0]) cube([1, 1, 7.0]);

translate([8, 16, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([9, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

translate([16, 16, 0]) cube([1, 1, 5.450692056682286]);

translate([17, 16, 0]) cube([1, 1, 5.445731866234253]);

translate([18, 16, 0]) cube([1, 1, 5.223575233763023]);

translate([19, 16, 0]) cube([1, 1, 4.76016269560782]);

color([0,1,0])
translate([0, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

translate([6, 17, 0]) cube([1, 1, 6.7]);

translate([7, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

translate([16, 18, 0]) cube([1, 1, 5.401490246100924]);

translate([17, 18, 0]) cube([1, 1, 5.304228321374018]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 5.40006928793339]);

translate([1, 19, 0]) cube([1, 1, 5.300546494591465]);

translate([2, 19, 0]) cube([1, 1, 5.300534799567369]);

translate([3, 19, 0]) cube([1, 1, 5.101182299098968]);

translate([4, 19, 0]) cube([1, 1, 5.003057977133869]);

translate([5, 19, 0]) cube([1, 1, 5.300275700429711]);

translate([6, 19, 0]) cube([1, 1, 5.300153501609721]);

translate([7, 19, 0]) cube([1, 1, 5.0000867832733435]);

translate([8, 19, 0]) cube([1, 1, 5.0000867856297555]);

translate([9, 19, 0]) cube([1, 1, 5.4000003637566145]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

translate([14, 19, 0]) cube([1, 1, 5.204977189463653]);

translate([15, 19, 0]) cube([1, 1, 5.302994852226281]);

translate([16, 19, 0]) cube([1, 1, 5.303921755443098]);

translate([17, 19, 0]) cube([1, 1, 5.400496747322402]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);
