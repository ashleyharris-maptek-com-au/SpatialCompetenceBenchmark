
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.20005483944629]);

translate([2, 0, 0]) cube([1, 1, 4.000372328908015]);

translate([3, 0, 0]) cube([1, 1, 3.9044507904100048]);

translate([4, 0, 0]) cube([1, 1, 4.200992195015167]);

translate([5, 0, 0]) cube([1, 1, 4.5]);

translate([6, 0, 0]) cube([1, 1, 4.2223126922334755]);

translate([7, 0, 0]) cube([1, 1, 4.447584102267246]);

translate([8, 0, 0]) cube([1, 1, 5.038888888888889]);

translate([9, 0, 0]) cube([1, 1, 4.5251097613273705]);

translate([10, 0, 0]) cube([1, 1, 4.623187830687831]);

translate([11, 0, 0]) cube([1, 1, 4.172992143691275]);

translate([12, 0, 0]) cube([1, 1, 4.009849901947153]);

translate([13, 0, 0]) cube([1, 1, 4.338133333333333]);

translate([14, 0, 0]) cube([1, 1, 4.407333333333334]);

translate([15, 0, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.4]);

translate([2, 1, 0]) cube([1, 1, 4.8001096802465675]);

translate([3, 1, 0]) cube([1, 1, 4.4005801385465535]);

translate([4, 1, 0]) cube([1, 1, 4.302396447693704]);

translate([5, 1, 0]) cube([1, 1, 4.109000566467366]);

translate([6, 1, 0]) cube([1, 1, 4.1090009454564]);

translate([7, 1, 0]) cube([1, 1, 4.173983746531152]);

translate([8, 1, 0]) cube([1, 1, 4.5135704574687985]);

translate([9, 1, 0]) cube([1, 1, 4.109730010611118]);

translate([10, 1, 0]) cube([1, 1, 4.0588797592901535]);

translate([11, 1, 0]) cube([1, 1, 4.000918433601362]);

translate([12, 1, 0]) cube([1, 1, 3.9642696956155916]);

translate([13, 1, 0]) cube([1, 1, 3.93894389254283]);

translate([14, 1, 0]) cube([1, 1, 3.9389028064116935]);

translate([15, 1, 0]) cube([1, 1, 3.9389028388246126]);

translate([0, 2, 0]) cube([1, 1, 7.2]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.400548401232833]);

translate([4, 2, 0]) cube([1, 1, 5.002242611253357]);

translate([5, 2, 0]) cube([1, 1, 4.406214639742076]);

translate([6, 2, 0]) cube([1, 1, 4.606884346486795]);

translate([7, 2, 0]) cube([1, 1, 4.81997905223844]);

translate([8, 2, 0]) cube([1, 1, 4.1299432058453585]);

translate([9, 2, 0]) cube([1, 1, 4.102128617517326]);

translate([10, 2, 0]) cube([1, 1, 4.050717627303828]);

translate([11, 2, 0]) cube([1, 1, 4.003793092456396]);

translate([12, 2, 0]) cube([1, 1, 3.9760400921061128]);

translate([13, 2, 0]) cube([1, 1, 3.9390408140933384]);

translate([14, 2, 0]) cube([1, 1, 3.938902975966913]);

translate([15, 2, 0]) cube([1, 1, 3.938907546040908]);

translate([0, 3, 0]) cube([1, 1, 7.7]);

translate([1, 3, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.107922648575202]);

color([0,1,0])
translate([6, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 3, 0]) cube([1, 1, 6]);

translate([8, 3, 0]) cube([1, 1, 4.6579493766339235]);

translate([9, 3, 0]) cube([1, 1, 4.0345402968927955]);

translate([10, 3, 0]) cube([1, 1, 4.022560935857688]);

translate([11, 3, 0]) cube([1, 1, 4.007940370838308]);

translate([12, 3, 0]) cube([1, 1, 3.984913772705702]);

translate([13, 3, 0]) cube([1, 1, 3.9395883724721217]);

translate([14, 3, 0]) cube([1, 1, 3.9389527620331806]);

translate([15, 3, 0]) cube([1, 1, 3.9389812954130523]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.3]);

translate([2, 4, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 4, 0]) cube([1, 1, 6]);

translate([8, 4, 0]) cube([1, 1, 5.41286339676277]);

translate([9, 4, 0]) cube([1, 1, 4.7641686379159705]);

translate([10, 4, 0]) cube([1, 1, 4.03673109351928]);

translate([11, 4, 0]) cube([1, 1, 4.219555849170309]);

translate([12, 4, 0]) cube([1, 1, 4.600049502257234]);

translate([13, 4, 0]) cube([1, 1, 4.600009900252896]);

translate([14, 4, 0]) cube([1, 1, 4.600001979610493]);

translate([15, 4, 0]) cube([1, 1, 4.5000006595416755]);

translate([0, 5, 0]) cube([1, 1, 8.0]);

translate([1, 5, 0]) cube([1, 1, 7.1]);

translate([2, 5, 0]) cube([1, 1, 6.6]);

translate([3, 5, 0]) cube([1, 1, 6.8]);

translate([4, 5, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 5, 0]) cube([1, 1, 6]);

translate([9, 5, 0]) cube([1, 1, 4.516405778698968]);

translate([10, 5, 0]) cube([1, 1, 4.764099397393608]);

translate([11, 5, 0]) cube([1, 1, 5.100297014096484]);

color([0,1,0])
translate([12, 5, 0]) cube([1, 1, 6]);

translate([13, 5, 0]) cube([1, 1, 5.4]);

translate([14, 5, 0]) cube([1, 1, 5.1]);

translate([15, 5, 0]) cube([1, 1, 5.3]);

translate([0, 6, 0]) cube([1, 1, 8.2]);

translate([1, 6, 0]) cube([1, 1, 7.3]);

translate([2, 6, 0]) cube([1, 1, 7.3]);

translate([3, 6, 0]) cube([1, 1, 7.5]);

translate([4, 6, 0]) cube([1, 1, 6.9]);

translate([5, 6, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.136840862147436]);

translate([10, 6, 0]) cube([1, 1, 4.919988700036022]);

translate([11, 6, 0]) cube([1, 1, 5.301782084578904]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.7]);

translate([2, 7, 0]) cube([1, 1, 7.6]);

translate([3, 7, 0]) cube([1, 1, 7.4]);

translate([4, 7, 0]) cube([1, 1, 7.0]);

translate([5, 7, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

translate([7, 7, 0]) cube([1, 1, 6.526625684996221]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

translate([14, 7, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 7.7]);

translate([1, 8, 0]) cube([1, 1, 7.3]);

translate([2, 8, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([3, 8, 0]) cube([1, 1, 6]);

translate([4, 8, 0]) cube([1, 1, 6.6]);

translate([5, 8, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([6, 8, 0]) cube([1, 1, 6]);

translate([7, 8, 0]) cube([1, 1, 6.531679894179894]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

translate([14, 8, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 6.8]);

translate([1, 9, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 9, 0]) cube([1, 1, 6]);

translate([6, 9, 0]) cube([1, 1, 6.602083333333333]);

translate([7, 9, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

translate([10, 9, 0]) cube([1, 1, 5.23330448415949]);

translate([11, 9, 0]) cube([1, 1, 5.303415063866166]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 10, 0]) cube([1, 1, 6]);

translate([3, 10, 0]) cube([1, 1, 5.424133722669814]);

translate([4, 10, 0]) cube([1, 1, 5.435734895299002]);

color([0,1,0])
translate([5, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 10, 0]) cube([1, 1, 6]);

translate([7, 10, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

translate([11, 10, 0]) cube([1, 1, 5.302973462739657]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([1, 11, 0]) cube([1, 1, 6]);

translate([2, 11, 0]) cube([1, 1, 5.224153572987386]);

color([0,1,0])
translate([3, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([8, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

translate([12, 11, 0]) cube([1, 1, 5.400269525921405]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

translate([15, 11, 0]) cube([1, 1, 5.2]);

translate([0, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 12, 0]) cube([1, 1, 6]);

translate([6, 12, 0]) cube([1, 1, 7.0]);

translate([7, 12, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([8, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

translate([14, 12, 0]) cube([1, 1, 5.3]);

translate([15, 12, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

translate([5, 13, 0]) cube([1, 1, 6.7]);

translate([6, 13, 0]) cube([1, 1, 7.0]);

translate([7, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

translate([13, 13, 0]) cube([1, 1, 5.4]);

translate([14, 13, 0]) cube([1, 1, 5.4]);

translate([15, 13, 0]) cube([1, 1, 5.0]);

color([0,1,0])
translate([0, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 15, 0]) cube([1, 1, 6]);

translate([1, 15, 0]) cube([1, 1, 5.40000070367494]);

translate([2, 15, 0]) cube([1, 1, 5.300002153615782]);

translate([3, 15, 0]) cube([1, 1, 5.100006617578319]);

translate([4, 15, 0]) cube([1, 1, 5.400001178133145]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

translate([6, 15, 0]) cube([1, 1, 5.20000185845973]);

translate([7, 15, 0]) cube([1, 1, 5.400001520540859]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

translate([11, 15, 0]) cube([1, 1, 5.3]);

translate([12, 15, 0]) cube([1, 1, 5.4]);

translate([13, 15, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);
