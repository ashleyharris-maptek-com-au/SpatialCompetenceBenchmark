
hull() {
    translate([10.005, 10.0, 18.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.095, 10.0, 18.904999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.11, 10.0, 18.889999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.290000000000001, 10.0, 18.709999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.315000000000001, 10.0, 18.685]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.584999999999999, 10.0, 18.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.62, 10.0, 18.38]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.98, 10.0, 18.02]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.025, 10.0, 17.974999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.475, 10.0, 17.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.53, 10.0, 17.47]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.07, 10.0, 16.93]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.135000000000002, 10.0, 16.865]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.765, 10.0, 16.235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.840000000000002, 10.0, 16.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.56, 10.0, 15.440000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.645, 10.0, 15.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.455000000000002, 10.0, 14.545000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.55, 10.0, 14.450000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.450000000000001, 10.0, 13.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.555000000000001, 10.0, 13.445]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.545, 10.0, 12.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.66, 10.0, 12.34]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.74, 10.0, 11.26]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.86, 10.0, 11.135]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.94, 10.0, 9.965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.025000000000002, 10.025, 9.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.475, 10.475000000000001, 9.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.515, 10.535, 8.959999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.785, 11.165, 8.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.805, 11.24, 8.165]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.895, 11.96, 7.535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.89, 12.045000000000002, 7.47]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.71, 12.855, 6.930000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.675, 12.945000000000002, 6.875000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.225, 13.755000000000003, 6.425000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.165000000000003, 13.840000000000002, 6.380000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.535000000000004, 14.56, 6.0200000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.455000000000002, 14.635000000000002, 5.985]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.645000000000003, 15.265, 5.715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.55, 15.330000000000002, 5.6899999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.650000000000002, 15.870000000000001, 5.51]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.545, 15.925, 5.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.555000000000001, 16.375, 5.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.440000000000001, 16.42, 5.3950000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.360000000000001, 16.78, 5.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.235000000000001, 16.815, 5.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.065000000000001, 17.085, 5.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.930000000000001, 17.110000000000003, 5.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.67, 17.29, 5.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.53, 17.305, 5.305]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.27, 17.395, 5.3950000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.125, 17.4, 5.405]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.774999999999999, 17.4, 5.495]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.625, 17.395, 5.51]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.275, 17.305, 5.6899999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.125, 17.285, 5.715]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.775, 17.015, 5.985]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.625, 16.975, 6.0200000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.275, 16.525, 6.380000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.135, 16.465, 6.425000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.965, 15.835, 6.875000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8449999999999998, 15.755, 6.930000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8550000000000002, 14.945, 7.47]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.76, 14.85, 7.535]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.04, 13.95, 8.165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9750000000000001, 13.84, 8.24]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.525, 12.76, 8.959999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.49, 12.629999999999999, 9.045]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.31000000000000005, 11.370000000000001, 9.855]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.31000000000000005, 11.225000000000001, 9.945]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.49, 9.875, 10.755]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.525, 9.72, 10.845]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9750000000000001, 8.28, 11.655]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.04, 8.12, 11.745]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.76, 6.68, 12.555]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.86, 6.52, 12.645]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.9400000000000004, 5.08, 13.455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.075, 4.925, 13.545]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.425, 3.575, 14.355]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.59, 3.435, 14.445]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.21, 2.265, 15.255000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.405, 2.1500000000000004, 15.345000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.295, 1.25, 16.155]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.515, 1.165, 16.245]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.584999999999999, 0.535, 17.055000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.825, 0.49, 17.14]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.075, 0.31000000000000005, 17.86]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.334999999999999, 0.31000000000000005, 17.935]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.765, 0.49, 18.565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.035, 0.53, 18.62]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.465000000000003, 1.07, 18.98]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.665000000000003, 1.1550000000000002, 19.01]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.835, 2.1450000000000005, 19.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.895, 2.285, 19.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.805, 3.815, 19.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.77, 3.98, 19.09]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.23, 5.42, 18.909999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.155, 5.575, 18.884999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.345000000000002, 6.925, 18.615000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.240000000000002, 7.07, 18.580000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.160000000000004, 8.33, 18.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.03, 8.46, 18.174999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.77, 9.540000000000001, 17.725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.62, 9.655000000000001, 17.669999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.18, 10.645, 17.130000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.015, 10.745, 17.065]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.485, 11.555, 16.435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.31, 11.64, 16.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.69, 12.36, 15.639999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.504999999999999, 12.43, 15.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.794999999999998, 12.97, 14.745000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.604999999999999, 13.025000000000002, 14.655000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.8950000000000005, 13.475000000000001, 13.845000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.705, 13.515, 13.750000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.995, 13.785000000000002, 12.850000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.805, 13.805000000000001, 12.750000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.095, 13.895, 11.850000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.915, 13.895, 11.745000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.3850000000000002, 13.805000000000001, 10.754999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.2400000000000002, 13.780000000000001, 10.645]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.16000000000000003, 13.420000000000002, 9.655000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.09500000000000001, 13.33, 9.540000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.005000000000000001, 12.07, 8.46]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.015, 11.925, 8.34]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.28500000000000003, 10.575000000000001, 7.260000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.335, 10.425, 7.140000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9650000000000001, 9.075, 6.0600000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.05, 8.92, 5.94]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9500000000000002, 7.48, 4.86]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.065, 7.32, 4.74]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.235, 5.88, 3.66]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.385, 5.72, 3.54]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.915, 4.28, 2.46]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.095, 4.13, 2.3400000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.805000000000001, 2.87, 1.26]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.005000000000001, 2.74, 1.1500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.895, 1.6600000000000001, 0.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.11, 1.5600000000000003, 0.19000000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.09, 0.8400000000000001, 0.010000000000000002]) cube([0.4, 0.4, 0.1], center=true);
}

