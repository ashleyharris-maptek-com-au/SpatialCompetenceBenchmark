color([1, 0, 1]) hull()
{
  translate([0.05, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.9500000000000001, 0.0, 5.0]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([1.05, 0.0, 4.995]) cube([0.4, 0.4, 0.1], center = true);
  translate([1.9500000000000002, 0.0, 4.905]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([2.05, 0.0, 4.890000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([2.95, 0.0, 4.710000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([3.0500000000000003, 0.0, 4.6850000000000005]) cube([0.4, 0.4, 0.1], center = true);
  translate([3.95, 0.0, 4.415000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.05, 0.0, 4.380000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([4.95, 0.0, 4.0200000000000005]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.05, 0.0, 3.975]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.95, 0.0, 3.525]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([6.050000000000001, 0.0, 3.475]) cube([0.4, 0.4, 0.1], center = true);
  translate([6.95, 0.0, 3.0250000000000004]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.05, 0.0, 2.975]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.95, 0.0, 2.525]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.05, 0.0, 2.475]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.95, 0.0, 2.025]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([9.049999999999999, 0.0, 1.975]) cube([0.4, 0.4, 0.1], center = true);
  translate([9.95, 0.0, 1.5250000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 0.05, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 0.9500000000000001, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 1.05, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 1.9500000000000002, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 2.05, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 2.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 3.0500000000000003, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 3.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 4.05, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 4.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 5.05, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 5.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 6.050000000000001, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 6.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 7.05, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 7.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([10.0, 8.05, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([10.0, 8.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([9.95, 9.049999999999999, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([9.049999999999999, 9.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.95, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.05, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.95, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.05, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([6.95, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([6.050000000000001, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.95, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.05, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([4.95, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([4.05, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([3.95, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([3.0500000000000003, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([2.95, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([2.05, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([1.9500000000000002, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([1.05, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.9500000000000001, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.05, 10.0, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 9.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 9.049999999999999, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 8.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 8.05, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 7.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 7.05, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 6.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 6.050000000000001, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 5.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 5.05, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 4.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 4.05, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 3.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 3.0500000000000003, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 2.95, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 2.05, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 1.9500000000000002, 1.5]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 1.05, 1.5]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([0.0, 0.9500000000000001, 1.425]) cube([0.4, 0.4, 0.1], center = true);
  translate([0.0, 0.05, 0.07500000000000001]) cube([0.4, 0.4, 0.1], center = true);
}
