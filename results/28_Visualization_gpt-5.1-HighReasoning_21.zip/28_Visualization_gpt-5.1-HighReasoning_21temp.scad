
translate([0, 0, 0]) cube([1, 1, 5.0003167721954584]);

translate([1, 0, 0]) cube([1, 1, 4.301319880789765]);

translate([2, 0, 0]) cube([1, 1, 4.203615324020302]);

translate([3, 0, 0]) cube([1, 1, 4.008649698321279]);

translate([4, 0, 0]) cube([1, 1, 3.943455145186497]);

translate([5, 0, 0]) cube([1, 1, 4.013604277669629]);

translate([6, 0, 0]) cube([1, 1, 4.203734074923596]);

translate([7, 0, 0]) cube([1, 1, 4.5]);

translate([8, 0, 0]) cube([1, 1, 4.4]);

translate([9, 0, 0]) cube([1, 1, 4.2]);

translate([10, 0, 0]) cube([1, 1, 4.3]);

translate([11, 0, 0]) cube([1, 1, 4.7]);

translate([12, 0, 0]) cube([1, 1, 5.0]);

translate([13, 0, 0]) cube([1, 1, 5.2]);

translate([14, 0, 0]) cube([1, 1, 5.4]);

translate([15, 0, 0]) cube([1, 1, 5.4]);

translate([16, 0, 0]) cube([1, 1, 5.1]);

translate([17, 0, 0]) cube([1, 1, 4.7]);

translate([18, 0, 0]) cube([1, 1, 4.4]);

translate([19, 0, 0]) cube([1, 1, 4.3]);

translate([20, 0, 0]) cube([1, 1, 4.3]);

translate([21, 0, 0]) cube([1, 1, 4.4]);

translate([22, 0, 0]) cube([1, 1, 4.6]);

translate([23, 0, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.200519190721367]);

translate([2, 1, 0]) cube([1, 1, 4.701689447496122]);

translate([3, 1, 0]) cube([1, 1, 4.403702133833168]);

translate([4, 1, 0]) cube([1, 1, 4.1082924956300255]);

translate([5, 1, 0]) cube([1, 1, 4.109206541478821]);

translate([6, 1, 0]) cube([1, 1, 4.205975445638257]);

translate([7, 1, 0]) cube([1, 1, 4.205584804732805]);

translate([8, 1, 0]) cube([1, 1, 4.006320986042948]);

translate([9, 1, 0]) cube([1, 1, 3.858406079408568]);

translate([10, 1, 0]) cube([1, 1, 3.9043005164550806]);

translate([11, 1, 0]) cube([1, 1, 4.100731447988625]);

translate([12, 1, 0]) cube([1, 1, 4.400004992999935]);

translate([13, 1, 0]) cube([1, 1, 4.5]);

translate([14, 1, 0]) cube([1, 1, 4.7]);

translate([15, 1, 0]) cube([1, 1, 4.7]);

translate([16, 1, 0]) cube([1, 1, 4.5]);

translate([17, 1, 0]) cube([1, 1, 4.3]);

translate([18, 1, 0]) cube([1, 1, 4.1]);

translate([19, 1, 0]) cube([1, 1, 3.9]);

translate([20, 1, 0]) cube([1, 1, 3.600000052321803]);

translate([21, 1, 0]) cube([1, 1, 3.7]);

translate([22, 1, 0]) cube([1, 1, 4.0]);

translate([23, 1, 0]) cube([1, 1, 4.1]);

translate([0, 2, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.205446452577372]);

translate([4, 2, 0]) cube([1, 1, 4.809350599462096]);

translate([5, 2, 0]) cube([1, 1, 4.808760505082991]);

translate([6, 2, 0]) cube([1, 1, 4.6057093011443095]);

translate([7, 2, 0]) cube([1, 1, 4.213233837933496]);

translate([8, 2, 0]) cube([1, 1, 3.94065208068498]);

translate([9, 2, 0]) cube([1, 1, 4.006293388973711]);

translate([10, 2, 0]) cube([1, 1, 4.200839109938155]);

translate([11, 2, 0]) cube([1, 1, 4.1007370894238155]);

translate([12, 2, 0]) cube([1, 1, 4.200130484098587]);

translate([13, 2, 0]) cube([1, 1, 4.400019978625705]);

translate([14, 2, 0]) cube([1, 1, 4.30000993112815]);

translate([15, 2, 0]) cube([1, 1, 4.300001985097952]);

translate([16, 2, 0]) cube([1, 1, 4.100000395605077]);

translate([17, 2, 0]) cube([1, 1, 3.8000053721984983]);

translate([18, 2, 0]) cube([1, 1, 3.700001072598971]);

translate([19, 2, 0]) cube([1, 1, 3.6000001768169687]);

translate([20, 2, 0]) cube([1, 1, 3.400000138245309]);

translate([21, 2, 0]) cube([1, 1, 3.4000000668701054]);

translate([22, 2, 0]) cube([1, 1, 3.7]);

translate([23, 2, 0]) cube([1, 1, 3.7]);

translate([0, 3, 0]) cube([1, 1, 7.2]);

translate([1, 3, 0]) cube([1, 1, 6.500127057859882]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

translate([4, 3, 0]) cube([1, 1, 5.415671712709306]);

translate([5, 3, 0]) cube([1, 1, 5.411543447061353]);

translate([6, 3, 0]) cube([1, 1, 5.013951856354993]);

translate([7, 3, 0]) cube([1, 1, 4.526033553136212]);

translate([8, 3, 0]) cube([1, 1, 4.419710686678024]);

translate([9, 3, 0]) cube([1, 1, 4.604126905313895]);

translate([10, 3, 0]) cube([1, 1, 4.800641176141103]);

translate([11, 3, 0]) cube([1, 1, 4.700266583174828]);

translate([12, 3, 0]) cube([1, 1, 4.700080147261093]);

translate([13, 3, 0]) cube([1, 1, 4.600019751256638]);

translate([14, 3, 0]) cube([1, 1, 4.2000315987852925]);

translate([15, 3, 0]) cube([1, 1, 4.000019941801696]);

translate([16, 3, 0]) cube([1, 1, 3.800021099543888]);

translate([17, 3, 0]) cube([1, 1, 3.4000498629331566]);

translate([18, 3, 0]) cube([1, 1, 3.400036222365087]);

translate([19, 3, 0]) cube([1, 1, 3.5000003397644894]);

translate([20, 3, 0]) cube([1, 1, 3.300001214800072]);

translate([21, 3, 0]) cube([1, 1, 3.300001214639115]);

translate([22, 3, 0]) cube([1, 1, 3.500000019873764]);

translate([23, 3, 0]) cube([1, 1, 3.6]);

translate([0, 4, 0]) cube([1, 1, 7.5]);

translate([1, 4, 0]) cube([1, 1, 6.9]);

translate([2, 4, 0]) cube([1, 1, 6.600508231439529]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.338967291576]);

translate([7, 4, 0]) cube([1, 1, 4.929263683586542]);

translate([8, 4, 0]) cube([1, 1, 4.916242082647746]);

translate([9, 4, 0]) cube([1, 1, 5.2031765244314006]);

color([0,1,0])
translate([10, 4, 0]) cube([1, 1, 6]);

translate([11, 4, 0]) cube([1, 1, 5.400095790335513]);

translate([12, 4, 0]) cube([1, 1, 5.200021207308558]);

translate([13, 4, 0]) cube([1, 1, 4.800017156667252]);

translate([14, 4, 0]) cube([1, 1, 4.200035857669584]);

translate([15, 4, 0]) cube([1, 1, 3.800083178049833]);

translate([16, 4, 0]) cube([1, 1, 3.600171515385211]);

translate([17, 4, 0]) cube([1, 1, 3.300582318297387]);

translate([18, 4, 0]) cube([1, 1, 3.400036230631441]);

translate([19, 4, 0]) cube([1, 1, 3.6000007992749476]);

translate([20, 4, 0]) cube([1, 1, 3.5000002817417255]);

translate([21, 4, 0]) cube([1, 1, 3.5000000666179796]);

translate([22, 4, 0]) cube([1, 1, 3.6]);

translate([23, 4, 0]) cube([1, 1, 3.7]);

translate([0, 5, 0]) cube([1, 1, 7.9]);

translate([1, 5, 0]) cube([1, 1, 7.4]);

translate([2, 5, 0]) cube([1, 1, 7.1]);

translate([3, 5, 0]) cube([1, 1, 6.702541158120331]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

translate([7, 5, 0]) cube([1, 1, 5.4172202460222865]);

translate([8, 5, 0]) cube([1, 1, 5.41185939786428]);

color([0,1,0])
translate([9, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 5, 0]) cube([1, 1, 6]);

translate([12, 5, 0]) cube([1, 1, 5.400031459126846]);

translate([13, 5, 0]) cube([1, 1, 4.800053657057539]);

translate([14, 5, 0]) cube([1, 1, 4.2000881770930905]);

translate([15, 5, 0]) cube([1, 1, 3.8001734386825774]);

translate([16, 5, 0]) cube([1, 1, 3.6002310995527336]);

translate([17, 5, 0]) cube([1, 1, 3.700031482920781]);

translate([18, 5, 0]) cube([1, 1, 3.9000048049650906]);

translate([19, 5, 0]) cube([1, 1, 4.0]);

translate([20, 5, 0]) cube([1, 1, 4.2]);

translate([21, 5, 0]) cube([1, 1, 4.2]);

translate([22, 5, 0]) cube([1, 1, 4.1]);

translate([23, 5, 0]) cube([1, 1, 3.9]);

translate([0, 6, 0]) cube([1, 1, 7.9]);

translate([1, 6, 0]) cube([1, 1, 7.4]);

translate([2, 6, 0]) cube([1, 1, 7.1]);

translate([3, 6, 0]) cube([1, 1, 6.81524694872198]);

translate([4, 6, 0]) cube([1, 1, 6.64205877913733]);

translate([5, 6, 0]) cube([1, 1, 6.580851862839665]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 6, 0]) cube([1, 1, 6]);

translate([12, 6, 0]) cube([1, 1, 5.40006942291099]);

translate([13, 6, 0]) cube([1, 1, 4.900142820937042]);

translate([14, 6, 0]) cube([1, 1, 4.5002179492546395]);

translate([15, 6, 0]) cube([1, 1, 4.100206893227676]);

translate([16, 6, 0]) cube([1, 1, 4.1001285849217695]);

translate([17, 6, 0]) cube([1, 1, 4.400024029307159]);

translate([18, 6, 0]) cube([1, 1, 4.6]);

translate([19, 6, 0]) cube([1, 1, 4.6]);

translate([20, 6, 0]) cube([1, 1, 4.7]);

translate([21, 6, 0]) cube([1, 1, 4.6]);

translate([22, 6, 0]) cube([1, 1, 4.5]);

translate([23, 6, 0]) cube([1, 1, 4.4]);

translate([0, 7, 0]) cube([1, 1, 7.9]);

translate([1, 7, 0]) cube([1, 1, 7.3]);

translate([2, 7, 0]) cube([1, 1, 6.789715819316008]);

translate([3, 7, 0]) cube([1, 1, 6.699211155996291]);

translate([4, 7, 0]) cube([1, 1, 6.734982207031601]);

translate([5, 7, 0]) cube([1, 1, 6.737360848974956]);

translate([6, 7, 0]) cube([1, 1, 6.613090670006023]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

translate([13, 7, 0]) cube([1, 1, 5.000274022597894]);

translate([14, 7, 0]) cube([1, 1, 4.800238030898704]);

translate([15, 7, 0]) cube([1, 1, 4.600163269084957]);

translate([16, 7, 0]) cube([1, 1, 4.6001201497198805]);

translate([17, 7, 0]) cube([1, 1, 5.1]);

translate([18, 7, 0]) cube([1, 1, 5.3]);

translate([19, 7, 0]) cube([1, 1, 5.2]);

translate([20, 7, 0]) cube([1, 1, 5.1]);

translate([21, 7, 0]) cube([1, 1, 4.9]);

translate([22, 7, 0]) cube([1, 1, 4.9]);

translate([23, 7, 0]) cube([1, 1, 5.1]);

translate([0, 8, 0]) cube([1, 1, 8.1]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 6.802772007422764]);

translate([3, 8, 0]) cube([1, 1, 6.782586643089835]);

translate([4, 8, 0]) cube([1, 1, 6.7598875047633555]);

translate([5, 8, 0]) cube([1, 1, 7.122225765132976]);

translate([6, 8, 0]) cube([1, 1, 6.7189574064284505]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

translate([13, 8, 0]) cube([1, 1, 5.000512324619356]);

translate([14, 8, 0]) cube([1, 1, 4.900260988354781]);

translate([15, 8, 0]) cube([1, 1, 4.700276596385799]);

translate([16, 8, 0]) cube([1, 1, 4.900040735118836]);

color([0,1,0])
translate([17, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 8.2]);

translate([1, 9, 0]) cube([1, 1, 7.6]);

translate([2, 9, 0]) cube([1, 1, 7.237568027210885]);

translate([3, 9, 0]) cube([1, 1, 6.9487057384180515]);

translate([4, 9, 0]) cube([1, 1, 7.003788633869025]);

translate([5, 9, 0]) cube([1, 1, 7.430867346769664]);

translate([6, 9, 0]) cube([1, 1, 6.92046885710827]);

translate([7, 9, 0]) cube([1, 1, 6.616721999928768]);

translate([8, 9, 0]) cube([1, 1, 6.604751196358617]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

translate([13, 9, 0]) cube([1, 1, 5.200391504304064]);

translate([14, 9, 0]) cube([1, 1, 5.1001270924107]);

translate([15, 9, 0]) cube([1, 1, 4.900156664435514]);

translate([16, 9, 0]) cube([1, 1, 5.100006280182267]);

color([0,1,0])
translate([17, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 8.1]);

translate([1, 10, 0]) cube([1, 1, 7.7]);

translate([2, 10, 0]) cube([1, 1, 7.505]);

translate([3, 10, 0]) cube([1, 1, 7.426224489795918]);

translate([4, 10, 0]) cube([1, 1, 7.03726297507735]);

translate([5, 10, 0]) cube([1, 1, 7.430867346769664]);

translate([6, 10, 0]) cube([1, 1, 7.015676556958891]);

translate([7, 10, 0]) cube([1, 1, 6.90982219765266]);

translate([8, 10, 0]) cube([1, 1, 6.901962981762795]);

translate([9, 10, 0]) cube([1, 1, 6.601596613085363]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

translate([14, 10, 0]) cube([1, 1, 5.400050511395933]);

translate([15, 10, 0]) cube([1, 1, 5.300023611937089]);

translate([16, 10, 0]) cube([1, 1, 5.400001513232649]);

color([0,1,0])
translate([17, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

translate([20, 10, 0]) cube([1, 1, 6.6]);

translate([21, 10, 0]) cube([1, 1, 6.8]);

translate([22, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 8.1]);

translate([1, 11, 0]) cube([1, 1, 7.8]);

translate([2, 11, 0]) cube([1, 1, 7.6]);

translate([3, 11, 0]) cube([1, 1, 7.421275510204082]);

translate([4, 11, 0]) cube([1, 1, 7.064367913564847]);

translate([5, 11, 0]) cube([1, 1, 7.035930303084297]);

translate([6, 11, 0]) cube([1, 1, 7.011754169959069]);

translate([7, 11, 0]) cube([1, 1, 7.003918675139178]);

translate([8, 11, 0]) cube([1, 1, 6.802865501789826]);

translate([9, 11, 0]) cube([1, 1, 6.501707439539336]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

translate([11, 11, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

translate([20, 11, 0]) cube([1, 1, 6.7]);

translate([21, 11, 0]) cube([1, 1, 7.0]);

translate([22, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 7.7]);

translate([1, 12, 0]) cube([1, 1, 7.4]);

translate([2, 12, 0]) cube([1, 1, 7.204255102040816]);

translate([3, 12, 0]) cube([1, 1, 7.017979705084512]);

translate([4, 12, 0]) cube([1, 1, 6.62856148003834]);

translate([5, 12, 0]) cube([1, 1, 6.537875700317373]);

translate([6, 12, 0]) cube([1, 1, 6.610888935769702]);

translate([7, 12, 0]) cube([1, 1, 6.802841531610355]);

translate([8, 12, 0]) cube([1, 1, 6.701604284566661]);

translate([9, 12, 0]) cube([1, 1, 6.50150345494297]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

translate([11, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 12, 0]) cube([1, 1, 6]);

translate([21, 12, 0]) cube([1, 1, 6.7]);

translate([22, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 7.0]);

translate([1, 13, 0]) cube([1, 1, 6.80178189232977]);

translate([2, 13, 0]) cube([1, 1, 6.803872467686981]);

translate([3, 13, 0]) cube([1, 1, 6.610282957193082]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

translate([8, 13, 0]) cube([1, 1, 6.5012279230935945]);

translate([9, 13, 0]) cube([1, 1, 6.600267380535057]);

translate([10, 13, 0]) cube([1, 1, 6.7]);

translate([11, 13, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

translate([14, 13, 0]) cube([1, 1, 5.400016690734213]);

translate([15, 13, 0]) cube([1, 1, 5.30002026412187]);

translate([16, 13, 0]) cube([1, 1, 5.400004100285371]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 6.70059396375033]);

translate([1, 14, 0]) cube([1, 1, 6.502122371974789]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

translate([9, 14, 0]) cube([1, 1, 6.500373825031624]);

translate([10, 14, 0]) cube([1, 1, 7.0]);

translate([11, 14, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

translate([15, 14, 0]) cube([1, 1, 5.300013843741678]);

translate([16, 14, 0]) cube([1, 1, 5.100045260745381]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 7.0]);

translate([1, 15, 0]) cube([1, 1, 6.60011879259326]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

translate([5, 15, 0]) cube([1, 1, 5.33768101077013]);

translate([6, 15, 0]) cube([1, 1, 5.414108922595165]);

color([0,1,0])
translate([7, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

translate([10, 15, 0]) cube([1, 1, 6.9]);

translate([11, 15, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

translate([16, 15, 0]) cube([1, 1, 5.30000697301874]);

translate([17, 15, 0]) cube([1, 1, 5.400000004193557]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

translate([23, 15, 0]) cube([1, 1, 5.4]);

translate([0, 16, 0]) cube([1, 1, 7.2]);

translate([1, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

translate([3, 16, 0]) cube([1, 1, 5.327189589629833]);

translate([4, 16, 0]) cube([1, 1, 5.327201643565957]);

translate([5, 16, 0]) cube([1, 1, 5.407536277931281]);

color([0,1,0])
translate([6, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 16, 0]) cube([1, 1, 6]);

translate([10, 16, 0]) cube([1, 1, 6.8]);

translate([11, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

translate([17, 16, 0]) cube([1, 1, 5.400000005289297]);

translate([18, 16, 0]) cube([1, 1, 5.300000004811141]);

translate([19, 16, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

translate([23, 16, 0]) cube([1, 1, 5.1]);

translate([0, 17, 0]) cube([1, 1, 7.0]);

translate([1, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

translate([3, 17, 0]) cube([1, 1, 5.327245686479003]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

translate([9, 17, 0]) cube([1, 1, 6.6]);

translate([10, 17, 0]) cube([1, 1, 6.9]);

translate([11, 17, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 17, 0]) cube([1, 1, 6]);

translate([22, 17, 0]) cube([1, 1, 5.3]);

translate([23, 17, 0]) cube([1, 1, 4.9]);

translate([0, 18, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

translate([8, 18, 0]) cube([1, 1, 6.6]);

translate([9, 18, 0]) cube([1, 1, 7.0]);

translate([10, 18, 0]) cube([1, 1, 7.1]);

translate([11, 18, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([20, 18, 0]) cube([1, 1, 5.4]);

translate([21, 18, 0]) cube([1, 1, 5.3]);

translate([22, 18, 0]) cube([1, 1, 4.9]);

translate([23, 18, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 19, 0]) cube([1, 1, 6]);

translate([8, 19, 0]) cube([1, 1, 6.8]);

translate([9, 19, 0]) cube([1, 1, 7.2]);

translate([10, 19, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

translate([19, 19, 0]) cube([1, 1, 5.4]);

translate([20, 19, 0]) cube([1, 1, 5.4]);

translate([21, 19, 0]) cube([1, 1, 5.3]);

translate([22, 19, 0]) cube([1, 1, 5.0]);

translate([23, 19, 0]) cube([1, 1, 4.6]);

color([0,1,0])
translate([0, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 20, 0]) cube([1, 1, 6]);

translate([7, 20, 0]) cube([1, 1, 6.6]);

translate([8, 20, 0]) cube([1, 1, 6.8]);

translate([9, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 20, 0]) cube([1, 1, 6]);

translate([23, 20, 0]) cube([1, 1, 5.1]);

color([0,1,0])
translate([0, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

translate([20, 21, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

translate([4, 22, 0]) cube([1, 1, 5.300000021304249]);

color([0,1,0])
translate([5, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

translate([17, 22, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

translate([19, 22, 0]) cube([1, 1, 5.4]);

translate([20, 22, 0]) cube([1, 1, 5.3]);

translate([21, 22, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

translate([0, 23, 0]) cube([1, 1, 5.3]);

translate([1, 23, 0]) cube([1, 1, 5.3]);

translate([2, 23, 0]) cube([1, 1, 5.30000000085592]);

translate([3, 23, 0]) cube([1, 1, 5.200000014950299]);

translate([4, 23, 0]) cube([1, 1, 5.000000046723747]);

translate([5, 23, 0]) cube([1, 1, 5.0000000478126845]);

translate([6, 23, 0]) cube([1, 1, 5.200000004497735]);

translate([7, 23, 0]) cube([1, 1, 5.200000001151144]);

translate([8, 23, 0]) cube([1, 1, 5.0]);

translate([9, 23, 0]) cube([1, 1, 4.8]);

translate([10, 23, 0]) cube([1, 1, 5.0]);

translate([11, 23, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([12, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 23, 0]) cube([1, 1, 6]);

translate([16, 23, 0]) cube([1, 1, 5.4]);

translate([17, 23, 0]) cube([1, 1, 5.2]);

translate([18, 23, 0]) cube([1, 1, 5.2]);

translate([19, 23, 0]) cube([1, 1, 5.3]);

translate([20, 23, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);
