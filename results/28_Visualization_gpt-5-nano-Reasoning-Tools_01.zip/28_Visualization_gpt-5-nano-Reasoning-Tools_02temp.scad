translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.2]);

translate([2, 0, 0]) cube([1, 1, 4.0]);

translate([3, 0, 0]) cube([1, 1, 3.9]);

translate([4, 0, 0]) cube([1, 1, 4.2]);

translate([5, 0, 0]) cube([1, 1, 4.5]);

translate([6, 0, 0]) cube([1, 1, 4.2]);

translate([7, 0, 0]) cube([1, 1, 4.4]);

translate([8, 0, 0]) cube([1, 1, 5.0]);

translate([9, 0, 0]) cube([1, 1, 5.3]);

translate([10, 0, 0]) cube([1, 1, 5.4]);

translate([11, 0, 0]) cube([1, 1, 4.9]);

translate([12, 0, 0]) cube([1, 1, 4.4]);

translate([13, 0, 0]) cube([1, 1, 4.3]);

translate([14, 0, 0]) cube([1, 1, 4.4]);

translate([15, 0, 0]) cube([1, 1, 4.7]);

translate([0, 1, 0]) cube([1, 1, 6.4]);

translate([1, 1, 0]) cube([1, 1, 5.4]);

translate([2, 1, 0]) cube([1, 1, 4.8]);

translate([3, 1, 0]) cube([1, 1, 4.4]);

translate([4, 1, 0]) cube([1, 1, 4.3]);

translate([5, 1, 0]) cube([1, 1, 4.0]);

translate([6, 1, 0]) cube([1, 1, 3.8]);

translate([7, 1, 0]) cube([1, 1, 3.9]);

translate([8, 1, 0]) cube([1, 1, 4.2]);

translate([9, 1, 0]) cube([1, 1, 4.4]);

translate([10, 1, 0]) cube([1, 1, 4.4]);

translate([11, 1, 0]) cube([1, 1, 4.2]);

translate([12, 1, 0]) cube([1, 1, 4.0]);

translate([13, 1, 0]) cube([1, 1, 3.6]);

translate([14, 1, 0]) cube([1, 1, 3.5]);

translate([15, 1, 0]) cube([1, 1, 3.9]);

translate([0, 2, 0]) cube([1, 1, 7.2]);

translate([1, 2, 0]) cube([1, 1, 6.3]);

translate([2, 2, 0]) cube([1, 1, 5.8]);

translate([3, 2, 0]) cube([1, 1, 5.4]);

translate([4, 2, 0]) cube([1, 1, 5.0]);

translate([5, 2, 0]) cube([1, 1, 4.4]);

translate([6, 2, 0]) cube([1, 1, 4.6]);

translate([7, 2, 0]) cube([1, 1, 4.8]);

translate([8, 2, 0]) cube([1, 1, 4.7]);

translate([9, 2, 0]) cube([1, 1, 4.4]);

translate([10, 2, 0]) cube([1, 1, 4.0]);

translate([11, 2, 0]) cube([1, 1, 3.6]);

translate([12, 2, 0]) cube([1, 1, 3.4]);

translate([13, 2, 0]) cube([1, 1, 3.4]);

translate([14, 2, 0]) cube([1, 1, 3.3]);

translate([15, 2, 0]) cube([1, 1, 3.6]);

translate([0, 3, 0]) cube([1, 1, 7.7]);

translate([1, 3, 0]) cube([1, 1, 7.0]);

translate([2, 3, 0]) cube([1, 1, 6.5]);

translate([3, 3, 0]) cube([1, 1, 6.0]);

translate([4, 3, 0]) cube([1, 1, 5.5]);

translate([5, 3, 0]) cube([1, 1, 5.1]);

translate([6, 3, 0]) cube([1, 1, 5.5]);

translate([7, 3, 0]) cube([1, 1, 5.8]);

translate([8, 3, 0]) cube([1, 1, 5.3]);

translate([9, 3, 0]) cube([1, 1, 4.5]);

translate([10, 3, 0]) cube([1, 1, 3.7]);

translate([11, 3, 0]) cube([1, 1, 3.5]);

translate([12, 3, 0]) cube([1, 1, 3.6]);

translate([13, 3, 0]) cube([1, 1, 3.8]);

translate([14, 3, 0]) cube([1, 1, 3.8]);

translate([15, 3, 0]) cube([1, 1, 3.8]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.3]);

translate([2, 4, 0]) cube([1, 1, 6.8]);

translate([3, 4, 0]) cube([1, 1, 6.5]);

translate([4, 4, 0]) cube([1, 1, 6.2]);

translate([5, 4, 0]) cube([1, 1, 5.7]);

translate([6, 4, 0]) cube([1, 1, 5.9]);

translate([7, 4, 0]) cube([1, 1, 6.2]);

translate([8, 4, 0]) cube([1, 1, 5.4]);

translate([9, 4, 0]) cube([1, 1, 4.7]);

translate([10, 4, 0]) cube([1, 1, 4.1]);

translate([11, 4, 0]) cube([1, 1, 4.2]);

translate([12, 4, 0]) cube([1, 1, 4.6]);

translate([13, 4, 0]) cube([1, 1, 4.6]);

translate([14, 4, 0]) cube([1, 1, 4.6]);

translate([15, 4, 0]) cube([1, 1, 4.5]);

translate([0, 5, 0]) cube([1, 1, 8.0]);

translate([1, 5, 0]) cube([1, 1, 7.1]);

translate([2, 5, 0]) cube([1, 1, 6.6]);

translate([3, 5, 0]) cube([1, 1, 6.8]);

translate([4, 5, 0]) cube([1, 1, 6.7]);

translate([5, 5, 0]) cube([1, 1, 6.1]);

translate([6, 5, 0]) cube([1, 1, 6.0]);

translate([7, 5, 0]) cube([1, 1, 6.1]);

translate([8, 5, 0]) cube([1, 1, 5.5]);

translate([9, 5, 0]) cube([1, 1, 4.9]);

translate([10, 5, 0]) cube([1, 1, 4.7]);

translate([11, 5, 0]) cube([1, 1, 5.1]);

translate([12, 5, 0]) cube([1, 1, 5.6]);

translate([13, 5, 0]) cube([1, 1, 5.4]);

translate([14, 5, 0]) cube([1, 1, 5.1]);

translate([15, 5, 0]) cube([1, 1, 5.3]);

translate([0, 6, 0]) cube([1, 1, 8.2]);

translate([1, 6, 0]) cube([1, 1, 7.3]);

translate([2, 6, 0]) cube([1, 1, 7.3]);

translate([3, 6, 0]) cube([1, 1, 7.5]);

translate([4, 6, 0]) cube([1, 1, 6.9]);

translate([5, 6, 0]) cube([1, 1, 6.6]);

translate([6, 6, 0]) cube([1, 1, 6.4]);

translate([7, 6, 0]) cube([1, 1, 6.1]);

translate([8, 6, 0]) cube([1, 1, 5.6]);

translate([9, 6, 0]) cube([1, 1, 5.1]);

translate([10, 6, 0]) cube([1, 1, 4.9]);

translate([11, 6, 0]) cube([1, 1, 5.3]);

translate([12, 6, 0]) cube([1, 1, 5.8]);

translate([13, 6, 0]) cube([1, 1, 6.0]);

translate([14, 6, 0]) cube([1, 1, 6.3]);

translate([15, 6, 0]) cube([1, 1, 6.0]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.7]);

translate([2, 7, 0]) cube([1, 1, 7.6]);

translate([3, 7, 0]) cube([1, 1, 7.4]);

translate([4, 7, 0]) cube([1, 1, 7.0]);

translate([5, 7, 0]) cube([1, 1, 7.0]);

translate([6, 7, 0]) cube([1, 1, 6.6]);

translate([7, 7, 0]) cube([1, 1, 6.5]);

translate([8, 7, 0]) cube([1, 1, 6.2]);

translate([9, 7, 0]) cube([1, 1, 5.6]);

translate([10, 7, 0]) cube([1, 1, 5.5]);

translate([11, 7, 0]) cube([1, 1, 5.8]);

translate([12, 7, 0]) cube([1, 1, 6.1]);

translate([13, 7, 0]) cube([1, 1, 6.5]);

translate([14, 7, 0]) cube([1, 1, 7.0]);

translate([15, 7, 0]) cube([1, 1, 6.4]);

translate([0, 8, 0]) cube([1, 1, 7.7]);

translate([1, 8, 0]) cube([1, 1, 7.3]);

translate([2, 8, 0]) cube([1, 1, 7.0]);

translate([3, 8, 0]) cube([1, 1, 6.5]);

translate([4, 8, 0]) cube([1, 1, 6.6]);

translate([5, 8, 0]) cube([1, 1, 6.8]);

translate([6, 8, 0]) cube([1, 1, 6.5]);

translate([7, 8, 0]) cube([1, 1, 6.5]);

translate([8, 8, 0]) cube([1, 1, 6.3]);

translate([9, 8, 0]) cube([1, 1, 5.6]);

translate([10, 8, 0]) cube([1, 1, 5.5]);

translate([11, 8, 0]) cube([1, 1, 5.8]);

translate([12, 8, 0]) cube([1, 1, 6.1]);

translate([13, 8, 0]) cube([1, 1, 6.4]);

translate([14, 8, 0]) cube([1, 1, 6.7]);

translate([15, 8, 0]) cube([1, 1, 6.4]);

translate([0, 9, 0]) cube([1, 1, 6.8]);

translate([1, 9, 0]) cube([1, 1, 6.6]);

translate([2, 9, 0]) cube([1, 1, 6.4]);

translate([3, 9, 0]) cube([1, 1, 5.9]);

translate([4, 9, 0]) cube([1, 1, 5.7]);

translate([5, 9, 0]) cube([1, 1, 6.1]);

translate([6, 9, 0]) cube([1, 1, 6.6]);

translate([7, 9, 0]) cube([1, 1, 6.9]);

translate([8, 9, 0]) cube([1, 1, 6.4]);

translate([9, 9, 0]) cube([1, 1, 5.7]);

translate([10, 9, 0]) cube([1, 1, 5.2]);

translate([11, 9, 0]) cube([1, 1, 5.3]);

translate([12, 9, 0]) cube([1, 1, 5.9]);

translate([13, 9, 0]) cube([1, 1, 6.1]);

translate([14, 9, 0]) cube([1, 1, 6.1]);

translate([15, 9, 0]) cube([1, 1, 6.0]);

translate([0, 10, 0]) cube([1, 1, 7.0]);

translate([1, 10, 0]) cube([1, 1, 6.3]);

translate([2, 10, 0]) cube([1, 1, 5.7]);

translate([3, 10, 0]) cube([1, 1, 5.4]);

translate([4, 10, 0]) cube([1, 1, 5.4]);

translate([5, 10, 0]) cube([1, 1, 5.7]);

translate([6, 10, 0]) cube([1, 1, 6.4]);

translate([7, 10, 0]) cube([1, 1, 7.0]);

translate([8, 10, 0]) cube([1, 1, 6.4]);

translate([9, 10, 0]) cube([1, 1, 5.9]);

translate([10, 10, 0]) cube([1, 1, 5.6]);

translate([11, 10, 0]) cube([1, 1, 5.3]);

translate([12, 10, 0]) cube([1, 1, 5.5]);

translate([13, 10, 0]) cube([1, 1, 5.8]);

translate([14, 10, 0]) cube([1, 1, 5.9]);

translate([15, 10, 0]) cube([1, 1, 5.6]);

translate([0, 11, 0]) cube([1, 1, 7.1]);

translate([1, 11, 0]) cube([1, 1, 6.2]);

translate([2, 11, 0]) cube([1, 1, 5.2]);

translate([3, 11, 0]) cube([1, 1, 5.5]);

translate([4, 11, 0]) cube([1, 1, 6.0]);

translate([5, 11, 0]) cube([1, 1, 6.0]);

translate([6, 11, 0]) cube([1, 1, 6.4]);

translate([7, 11, 0]) cube([1, 1, 6.8]);

translate([8, 11, 0]) cube([1, 1, 6.2]);

translate([9, 11, 0]) cube([1, 1, 5.7]);

translate([10, 11, 0]) cube([1, 1, 5.7]);

translate([11, 11, 0]) cube([1, 1, 5.5]);

translate([12, 11, 0]) cube([1, 1, 5.4]);

translate([13, 11, 0]) cube([1, 1, 5.6]);

translate([14, 11, 0]) cube([1, 1, 5.7]);

translate([15, 11, 0]) cube([1, 1, 5.2]);

translate([0, 12, 0]) cube([1, 1, 6.6]);

translate([1, 12, 0]) cube([1, 1, 6.1]);

translate([2, 12, 0]) cube([1, 1, 5.6]);

translate([3, 12, 0]) cube([1, 1, 6.0]);

translate([4, 12, 0]) cube([1, 1, 6.1]);

translate([5, 12, 0]) cube([1, 1, 6.3]);

translate([6, 12, 0]) cube([1, 1, 7.0]);

translate([7, 12, 0]) cube([1, 1, 7.1]);

translate([8, 12, 0]) cube([1, 1, 6.2]);

translate([9, 12, 0]) cube([1, 1, 5.7]);

translate([10, 12, 0]) cube([1, 1, 5.9]);

translate([11, 12, 0]) cube([1, 1, 6.0]);

translate([12, 12, 0]) cube([1, 1, 5.6]);

translate([13, 12, 0]) cube([1, 1, 5.5]);

translate([14, 12, 0]) cube([1, 1, 5.3]);

translate([15, 12, 0]) cube([1, 1, 4.8]);

translate([0, 13, 0]) cube([1, 1, 6.4]);

translate([1, 13, 0]) cube([1, 1, 6.2]);

translate([2, 13, 0]) cube([1, 1, 6.0]);

translate([3, 13, 0]) cube([1, 1, 6.0]);

translate([4, 13, 0]) cube([1, 1, 6.2]);

translate([5, 13, 0]) cube([1, 1, 6.7]);

translate([6, 13, 0]) cube([1, 1, 7.0]);

translate([7, 13, 0]) cube([1, 1, 6.6]);

translate([8, 13, 0]) cube([1, 1, 5.9]);

translate([9, 13, 0]) cube([1, 1, 6.1]);

translate([10, 13, 0]) cube([1, 1, 6.5]);

translate([11, 13, 0]) cube([1, 1, 6.0]);

translate([12, 13, 0]) cube([1, 1, 5.5]);

translate([13, 13, 0]) cube([1, 1, 5.4]);

translate([14, 13, 0]) cube([1, 1, 5.4]);

translate([15, 13, 0]) cube([1, 1, 5.0]);

translate([0, 14, 0]) cube([1, 1, 6.1]);

translate([1, 14, 0]) cube([1, 1, 6.0]);

translate([2, 14, 0]) cube([1, 1, 5.8]);

translate([3, 14, 0]) cube([1, 1, 5.7]);

translate([4, 14, 0]) cube([1, 1, 6.3]);

translate([5, 14, 0]) cube([1, 1, 6.5]);

translate([6, 14, 0]) cube([1, 1, 6.3]);

translate([7, 14, 0]) cube([1, 1, 6.0]);

translate([8, 14, 0]) cube([1, 1, 6.0]);

translate([9, 14, 0]) cube([1, 1, 6.4]);

translate([10, 14, 0]) cube([1, 1, 6.2]);

translate([11, 14, 0]) cube([1, 1, 5.7]);

translate([12, 14, 0]) cube([1, 1, 5.6]);

translate([13, 14, 0]) cube([1, 1, 5.5]);

translate([14, 14, 0]) cube([1, 1, 5.5]);

translate([15, 14, 0]) cube([1, 1, 5.8]);

translate([0, 15, 0]) cube([1, 1, 5.5]);

translate([1, 15, 0]) cube([1, 1, 5.4]);

translate([2, 15, 0]) cube([1, 1, 5.3]);

translate([3, 15, 0]) cube([1, 1, 5.1]);

translate([4, 15, 0]) cube([1, 1, 5.4]);

translate([5, 15, 0]) cube([1, 1, 5.5]);

translate([6, 15, 0]) cube([1, 1, 5.2]);

translate([7, 15, 0]) cube([1, 1, 5.4]);

translate([8, 15, 0]) cube([1, 1, 5.8]);

translate([9, 15, 0]) cube([1, 1, 6.1]);

translate([10, 15, 0]) cube([1, 1, 5.8]);

translate([11, 15, 0]) cube([1, 1, 5.3]);

translate([12, 15, 0]) cube([1, 1, 5.4]);

translate([13, 15, 0]) cube([1, 1, 5.3]);

translate([14, 15, 0]) cube([1, 1, 5.5]);

translate([15, 15, 0]) cube([1, 1, 5.9]);

color([1, 0, 0]) translate([0.15, 0.15, 0]) cube([0.15, 0.15, 10]);

color([1, 0, 0]) translate([0.15, 4.15, 0]) cube([0.15, 0.15, 10]);

color([1, 0, 0]) translate([0.15, 8.15, 0]) cube([0.15, 0.15, 10]);

color([1, 0, 0]) translate([0.15, 12.15, 0]) cube([0.15, 0.15, 10]);

color([1, 0, 0]) translate([4.15, 0.15, 0]) cube([0.15, 0.15, 10]);

color([1, 0, 0]) translate([4.15, 4.15, 0]) cube([0.15, 0.15, 10]);

color([1, 0, 0]) translate([4.15, 8.15, 0]) cube([0.15, 0.15, 10]);

color([1, 0, 0]) translate([4.15, 12.15, 0]) cube([0.15, 0.15, 10]);

color([1, 0, 0]) translate([8.15, 0.15, 0]) cube([0.15, 0.15, 10]);

color([1, 0, 0]) translate([8.15, 4.15, 0]) cube([0.15, 0.15, 10]);

color([1, 0, 0]) translate([8.15, 8.15, 0]) cube([0.15, 0.15, 10]);

color([1, 0, 0]) translate([8.15, 12.15, 0]) cube([0.15, 0.15, 10]);

color([1, 0, 0]) translate([12.15, 0.15, 0]) cube([0.15, 0.15, 10]);

color([1, 0, 0]) translate([12.15, 4.15, 0]) cube([0.15, 0.15, 10]);

color([1, 0, 0]) translate([12.15, 8.15, 0]) cube([0.15, 0.15, 10]);

color([1, 0, 0]) translate([12.15, 12.15, 0]) cube([0.15, 0.15, 10]);
