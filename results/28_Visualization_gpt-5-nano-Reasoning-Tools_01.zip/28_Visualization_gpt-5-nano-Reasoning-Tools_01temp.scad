translate([0, 0, 0]) cube([1, 1, 4.440696504436417]);

translate([1, 0, 0]) cube([1, 1, 4.440822749681246]);

translate([2, 0, 0]) cube([1, 1, 4.316905943827861]);

translate([3, 0, 0]) cube([1, 1, 4.315631490447934]);

translate([4, 0, 0]) cube([1, 1, 3.7429059080223146]);

translate([5, 0, 0]) cube([1, 1, 4.512698412698413]);

translate([6, 0, 0]) cube([1, 1, 4.2377777777777785]);

translate([7, 0, 0]) cube([1, 1, 4.4622222222222225]);

translate([8, 0, 0]) cube([1, 1, 4.205982181443739]);

translate([9, 0, 0]) cube([1, 1, 5.3]);

translate([10, 0, 0]) cube([1, 1, 5.4]);

translate([11, 0, 0]) cube([1, 1, 4.9]);

translate([12, 0, 0]) cube([1, 1, 3.4019798057602477]);

translate([13, 0, 0]) cube([1, 1, 4.355466666666667]);

translate([14, 0, 0]) cube([1, 1, 4.410666666666667]);

translate([15, 0, 0]) cube([1, 1, 4.7]);

color([0, 1, 0]) translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.422089278850469]);

translate([2, 1, 0]) cube([1, 1, 4.870239638936474]);

translate([3, 1, 0]) cube([1, 1, 4.469376965404212]);

translate([4, 1, 0]) cube([1, 1, 4.398690357218621]);

translate([5, 1, 0]) cube([1, 1, 4.206508682253138]);

translate([6, 1, 0]) cube([1, 1, 4.2070068132734795]);

translate([7, 1, 0]) cube([1, 1, 4.2062181305324575]);

translate([8, 1, 0]) cube([1, 1, 4.338731905896834]);

translate([9, 1, 0]) cube([1, 1, 4.467624739720222]);

translate([10, 1, 0]) cube([1, 1, 4.43622581493376]);

translate([11, 1, 0]) cube([1, 1, 4.2600555895337004]);

translate([12, 1, 0]) cube([1, 1, 4.065104918957224]);

translate([13, 1, 0]) cube([1, 1, 3.7064462110658134]);

translate([14, 1, 0]) cube([1, 1, 3.7065586206721]);

translate([15, 1, 0]) cube([1, 1, 3.9026666666666667]);

translate([0, 2, 0]) cube([1, 1, 7.219809523809524]);

color([0, 1, 0]) translate([1, 2, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.442433950753016]);

translate([4, 2, 0]) cube([1, 1, 5.054831603986202]);

translate([5, 2, 0]) cube([1, 1, 4.493515734542766]);

translate([6, 2, 0]) cube([1, 1, 4.626144623321472]);

translate([7, 2, 0]) cube([1, 1, 4.811797985531957]);

translate([8, 2, 0]) cube([1, 1, 4.724584418560022]);

translate([9, 2, 0]) cube([1, 1, 4.4547282582378855]);

translate([10, 2, 0]) cube([1, 1, 4.071483116143783]);

translate([11, 2, 0]) cube([1, 1, 3.7787394572812265]);

translate([12, 2, 0]) cube([1, 1, 3.7407404895060044]);

translate([13, 2, 0]) cube([1, 1, 3.7070063144759486]);

translate([14, 2, 0]) cube([1, 1, 3.7067026515931896]);

translate([15, 2, 0]) cube([1, 1, 3.7069188655049032]);

translate([0, 3, 0]) cube([1, 1, 7.753333333333334]);

translate([1, 3, 0]) cube([1, 1, 7.0678820861678]);

translate([2, 3, 0]) cube([1, 1, 6.532765910142573]);

color([0, 1, 0]) translate([3, 3, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.194557002217175]);

color([0, 1, 0]) translate([6, 3, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 3, 0]) cube([1, 1, 6]);

translate([8, 3, 0]) cube([1, 1, 5.346419785740111]);

translate([9, 3, 0]) cube([1, 1, 4.567298062636644]);

translate([10, 3, 0]) cube([1, 1, 3.876003034193869]);

translate([11, 3, 0]) cube([1, 1, 3.7887739372629636]);

translate([12, 3, 0]) cube([1, 1, 3.767883624618437]);

translate([13, 3, 0]) cube([1, 1, 3.8568555415818295]);

translate([14, 3, 0]) cube([1, 1, 3.8203220837736347]);

translate([15, 3, 0]) cube([1, 1, 3.811191343881414]);

translate([0, 4, 0]) cube([1, 1, 6.869532676091271]);

translate([1, 4, 0]) cube([1, 1, 7.359863945578231]);

translate([2, 4, 0]) cube([1, 1, 6.832699890459657]);

translate([3, 4, 0]) cube([1, 1, 6.535556706528518]);

translate([4, 4, 0]) cube([1, 1, 5.1928852122096165]);

color([0, 1, 0]) translate([5, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 4, 0]) cube([1, 1, 6]);

translate([8, 4, 0]) cube([1, 1, 4.413140113376207]);

translate([9, 4, 0]) cube([1, 1, 4.789971272543391]);

translate([10, 4, 0]) cube([1, 1, 4.2254222349458725]);

translate([11, 4, 0]) cube([1, 1, 4.2746617168203445]);

translate([12, 4, 0]) cube([1, 1, 3.6484218050983186]);

translate([13, 4, 0]) cube([1, 1, 4.645259543356558]);

translate([14, 4, 0]) cube([1, 1, 4.609720916108587]);

translate([15, 4, 0]) cube([1, 1, 4.5035310329103035]);

translate([0, 5, 0]) cube([1, 1, 8.0]);

translate([1, 5, 0]) cube([1, 1, 7.168453311011905]);

translate([2, 5, 0]) cube([1, 1, 6.7013555942764]);

translate([3, 5, 0]) cube([1, 1, 6.80970902874791]);

translate([4, 5, 0]) cube([1, 1, 6.701845941137286]);

color([0, 1, 0]) translate([5, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 5, 0]) cube([1, 1, 6]);

translate([9, 5, 0]) cube([1, 1, 4.983213350291737]);

translate([10, 5, 0]) cube([1, 1, 4.803835961556299]);

translate([11, 5, 0]) cube([1, 1, 5.107048246941665]);

color([0, 1, 0]) translate([12, 5, 0]) cube([1, 1, 6]);

translate([13, 5, 0]) cube([1, 1, 5.402472857473408]);

translate([14, 5, 0]) cube([1, 1, 5.100872182622319]);

translate([15, 5, 0]) cube([1, 1, 5.3]);

translate([0, 6, 0]) cube([1, 1, 8.2]);

translate([1, 6, 0]) cube([1, 1, 7.316613520408164]);

translate([2, 6, 0]) cube([1, 1, 7.314478635204082]);

translate([3, 6, 0]) cube([1, 1, 7.5008928571428575]);

translate([4, 6, 0]) cube([1, 1, 6.900473760932944]);

translate([5, 6, 0]) cube([1, 1, 6.600529538081683]);

color([0, 1, 0]) translate([6, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.159255544251971]);

translate([10, 6, 0]) cube([1, 1, 5.029033268551314]);

translate([11, 6, 0]) cube([1, 1, 5.33094106838007]);

color([0, 1, 0]) translate([12, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 6, 0]) cube([1, 1, 6]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.7]);

translate([2, 7, 0]) cube([1, 1, 7.607142857142857]);

translate([3, 7, 0]) cube([1, 1, 7.401147959183674]);

translate([4, 7, 0]) cube([1, 1, 7.000291545189504]);

translate([5, 7, 0]) cube([1, 1, 7.000036443148688]);

translate([6, 7, 0]) cube([1, 1, 6.6001021394512085]);

translate([7, 7, 0]) cube([1, 1, 6.50571628139298]);

color([0, 1, 0]) translate([8, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 7, 0]) cube([1, 1, 6]);

translate([14, 7, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([15, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 6.69435544217687]);

translate([1, 8, 0]) cube([1, 1, 7.358333333333333]);

translate([2, 8, 0]) cube([1, 1, 7.013324829931973]);

translate([3, 8, 0]) cube([1, 1, 6.57471166817067]);

color([0, 1, 0]) translate([4, 8, 0]) cube([1, 1, 6]);

translate([5, 8, 0]) cube([1, 1, 6.800046855476885]);

translate([6, 8, 0]) cube([1, 1, 6.503957909548623]);

translate([7, 8, 0]) cube([1, 1, 6.507325734565415]);

translate([8, 8, 0]) cube([1, 1, 5.2608720507109625]);

color([0, 1, 0]) translate([9, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 8, 0]) cube([1, 1, 6]);

translate([12, 8, 0]) cube([1, 1, 5.162526587817305]);

color([0, 1, 0]) translate([13, 8, 0]) cube([1, 1, 6]);

translate([14, 8, 0]) cube([1, 1, 6.7]);

color([0, 1, 0]) translate([15, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 6.910297619047619]);

translate([1, 9, 0]) cube([1, 1, 6.72762925170068]);

color([0, 1, 0]) translate([2, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 9, 0]) cube([1, 1, 6]);

translate([6, 9, 0]) cube([1, 1, 6.600007809246147]);

translate([7, 9, 0]) cube([1, 1, 6.9]);

color([0, 1, 0]) translate([8, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.020952380952381]);

color([0, 1, 0]) translate([1, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 10, 0]) cube([1, 1, 6]);

translate([7, 10, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([8, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 7.1]);

color([0, 1, 0]) translate([1, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.8]);

color([0, 1, 0]) translate([8, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 11, 0]) cube([1, 1, 6]);

translate([15, 11, 0]) cube([1, 1, 5.2316144211255144]);

color([0, 1, 0]) translate([0, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([1, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 12, 0]) cube([1, 1, 6]);

translate([4, 12, 0]) cube([1, 1, 5.090436708838859]);

color([0, 1, 0]) translate([5, 12, 0]) cube([1, 1, 6]);

translate([6, 12, 0]) cube([1, 1, 7.0]);

translate([7, 12, 0]) cube([1, 1, 7.1]);

translate([8, 12, 0]) cube([1, 1, 5.263489779264141]);

color([0, 1, 0]) translate([9, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 12, 0]) cube([1, 1, 6]);

translate([12, 12, 0]) cube([1, 1, 4.585912481731663]);

color([0, 1, 0]) translate([13, 12, 0]) cube([1, 1, 6]);

translate([14, 12, 0]) cube([1, 1, 5.351709956601533]);

translate([15, 12, 0]) cube([1, 1, 4.981505973249466]);

color([0, 1, 0]) translate([0, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([1, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 13, 0]) cube([1, 1, 6]);

translate([5, 13, 0]) cube([1, 1, 6.7]);

translate([6, 13, 0]) cube([1, 1, 7.0]);

translate([7, 13, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([8, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 13, 0]) cube([1, 1, 6]);

translate([13, 13, 0]) cube([1, 1, 5.471636074670371]);

translate([14, 13, 0]) cube([1, 1, 5.440778816212295]);

translate([15, 13, 0]) cube([1, 1, 5.051437807924741]);

color([0, 1, 0]) translate([0, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([1, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([0, 15, 0]) cube([1, 1, 6]);

translate([1, 15, 0]) cube([1, 1, 5.461757389978653]);

translate([2, 15, 0]) cube([1, 1, 5.379127376129214]);

translate([3, 15, 0]) cube([1, 1, 5.261056433123074]);

translate([4, 15, 0]) cube([1, 1, 5.416226103025812]);

color([0, 1, 0]) translate([5, 15, 0]) cube([1, 1, 6]);

translate([6, 15, 0]) cube([1, 1, 5.257165749021164]);

translate([7, 15, 0]) cube([1, 1, 5.438382528386244]);

color([0, 1, 0]) translate([8, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 15, 0]) cube([1, 1, 6]);

translate([11, 15, 0]) cube([1, 1, 5.348382907235067]);

translate([12, 15, 0]) cube([1, 1, 5.4132901093341355]);

translate([13, 15, 0]) cube([1, 1, 5.362784562325622]);

color([0, 1, 0]) translate([14, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 15, 0]) cube([1, 1, 6]);
