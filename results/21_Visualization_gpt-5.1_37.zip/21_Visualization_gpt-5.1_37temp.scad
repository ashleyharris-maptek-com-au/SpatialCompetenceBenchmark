
hull() {
    translate([1.04, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.76, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.84, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.5600000000000005, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.6400000000000006, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.3600000000000003, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.44, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.16, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.24, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.96, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.04, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.76, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.84, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.56, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.64, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.36, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.44, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.16, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.24, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.959999999999999, 1.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 1.04, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 1.76, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 1.84, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 2.5600000000000005, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 2.6400000000000006, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 3.3600000000000003, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 3.44, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 4.16, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 4.24, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 4.96, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 5.04, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 5.76, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 5.84, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 6.56, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 6.64, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 7.36, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 7.44, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 8.16, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 8.24, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0, 8.959999999999999, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.959999999999999, 9.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.24, 9.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.16, 9.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.44, 9.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.36, 9.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.64, 9.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.56, 9.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.84, 9.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.76, 9.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.04, 9.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.96, 9.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.24, 9.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.16, 9.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.44, 9.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4, 8.959999999999999, 4.97]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4, 8.24, 4.430000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4, 8.16, 4.37]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4, 7.44, 3.83]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4, 7.36, 3.77]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4, 6.64, 3.2300000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4, 6.56, 3.1700000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4, 5.84, 2.6300000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4, 5.76, 2.5700000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4, 5.04, 2.0300000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4, 4.96, 1.97]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4, 4.24, 1.43]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4, 4.16, 1.37]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4, 3.44, 0.8300000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4, 3.3600000000000003, 0.7700000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4, 2.6400000000000006, 0.23000000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4, 2.5600000000000005, 0.19000000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4, 1.84, 0.010000000000000002]) cube([0.4, 0.4, 0.1], center=true);
}

