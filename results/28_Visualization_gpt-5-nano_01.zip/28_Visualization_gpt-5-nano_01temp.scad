translate([0, 0, 0]) cube([1, 1, 5.0008888888888885]);

translate([1, 0, 0]) cube([1, 1, 4.20470451965284]);

translate([2, 0, 0]) cube([1, 1, 4.015289700385619]);

translate([3, 0, 0]) cube([1, 1, 3.9987002043774282]);

translate([4, 0, 0]) cube([1, 1, 4.219167032360723]);

translate([5, 0, 0]) cube([1, 1, 4.5]);

translate([6, 0, 0]) cube([1, 1, 4.2]);

translate([7, 0, 0]) cube([1, 1, 4.4]);

translate([8, 0, 0]) cube([1, 1, 5.0]);

translate([9, 0, 0]) cube([1, 1, 5.3]);

translate([10, 0, 0]) cube([1, 1, 5.4]);

translate([11, 0, 0]) cube([1, 1, 4.9]);

translate([12, 0, 0]) cube([1, 1, 4.4]);

translate([13, 0, 0]) cube([1, 1, 4.3]);

translate([14, 0, 0]) cube([1, 1, 4.4]);

translate([15, 0, 0]) cube([1, 1, 4.7]);

color([0, 1, 0]) translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.401777777777778]);

translate([2, 1, 0]) cube([1, 1, 4.80674237322751]);

translate([3, 1, 0]) cube([1, 1, 4.417354731467648]);

translate([4, 1, 0]) cube([1, 1, 4.340146366935929]);

translate([5, 1, 0]) cube([1, 1, 4.106107916438863]);

translate([6, 1, 0]) cube([1, 1, 3.9881089855667358]);

translate([7, 1, 0]) cube([1, 1, 3.988389241849965]);

translate([8, 1, 0]) cube([1, 1, 4.211261967124333]);

translate([9, 1, 0]) cube([1, 1, 4.402823536429484]);

translate([10, 1, 0]) cube([1, 1, 4.402079214527965]);

translate([11, 1, 0]) cube([1, 1, 4.200415842267375]);

translate([12, 1, 0]) cube([1, 1, 4.000083168411876]);

translate([13, 1, 0]) cube([1, 1, 3.6550898798586218]);

translate([14, 1, 0]) cube([1, 1, 3.6700833635040278]);

translate([15, 1, 0]) cube([1, 1, 3.937037037037037]);

translate([0, 2, 0]) cube([1, 1, 7.2]);

color([0, 1, 0]) translate([1, 2, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.423045200118769]);

translate([4, 2, 0]) cube([1, 1, 5.04809719510307]);

translate([5, 2, 0]) cube([1, 1, 4.472088341054231]);

translate([6, 2, 0]) cube([1, 1, 4.6327168974237765]);

translate([7, 2, 0]) cube([1, 1, 4.808641063478715]);

translate([8, 2, 0]) cube([1, 1, 4.704324084002372]);

translate([9, 2, 0]) cube([1, 1, 4.406735250338093]);

translate([10, 2, 0]) cube([1, 1, 4.0257818814033595]);

translate([11, 2, 0]) cube([1, 1, 3.697752438414492]);

translate([12, 2, 0]) cube([1, 1, 3.6353767768547565]);

translate([13, 2, 0]) cube([1, 1, 2.9187213228822166]);

translate([14, 2, 0]) cube([1, 1, 3.6507909979542332]);

translate([15, 2, 0]) cube([1, 1, 3.700362676244555]);

translate([0, 3, 0]) cube([1, 1, 7.7]);

translate([1, 3, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([2, 3, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 3, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.2111036637240185]);

color([0, 1, 0]) translate([6, 3, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 3, 0]) cube([1, 1, 6]);

translate([8, 3, 0]) cube([1, 1, 5.308006621013995]);

translate([9, 3, 0]) cube([1, 1, 4.527073682258536]);

translate([10, 3, 0]) cube([1, 1, 3.86284343224024]);

translate([11, 3, 0]) cube([1, 1, 3.6987411359122655]);

translate([12, 3, 0]) cube([1, 1, 3.6980736842398243]);

translate([13, 3, 0]) cube([1, 1, 3.820597405588895]);

translate([14, 3, 0]) cube([1, 1, 3.817203131444012]);

translate([15, 3, 0]) cube([1, 1, 3.819265967631721]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.3]);

translate([2, 4, 0]) cube([1, 1, 6.8]);

color([0, 1, 0]) translate([3, 4, 0]) cube([1, 1, 6]);

translate([4, 4, 0]) cube([1, 1, 5.218259401807223]);

color([0, 1, 0]) translate([5, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 4, 0]) cube([1, 1, 6]);

translate([8, 4, 0]) cube([1, 1, 5.429712924224547]);

translate([9, 4, 0]) cube([1, 1, 4.7933247826831105]);

translate([10, 4, 0]) cube([1, 1, 4.28912480133951]);

translate([11, 4, 0]) cube([1, 1, 3.700893443756256]);

translate([12, 4, 0]) cube([1, 1, 4.6035679223414485]);

translate([13, 4, 0]) cube([1, 1, 4.600817993500866]);

translate([14, 4, 0]) cube([1, 1, 4.600233204586444]);

translate([15, 4, 0]) cube([1, 1, 4.5001009365538485]);

translate([0, 5, 0]) cube([1, 1, 8.0]);

translate([1, 5, 0]) cube([1, 1, 7.1]);

translate([2, 5, 0]) cube([1, 1, 6.6]);

translate([3, 5, 0]) cube([1, 1, 6.8]);

translate([4, 5, 0]) cube([1, 1, 6.7]);

color([0, 1, 0]) translate([5, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 5, 0]) cube([1, 1, 6]);

translate([9, 5, 0]) cube([1, 1, 5.042166541429732]);

translate([10, 5, 0]) cube([1, 1, 4.852979104760451]);

translate([11, 5, 0]) cube([1, 1, 5.120955095707927]);

color([0, 1, 0]) translate([12, 5, 0]) cube([1, 1, 6]);

translate([13, 5, 0]) cube([1, 1, 5.400278424456202]);

translate([14, 5, 0]) cube([1, 1, 5.100069606114051]);

translate([15, 5, 0]) cube([1, 1, 5.3]);

translate([0, 6, 0]) cube([1, 1, 8.2]);

translate([1, 6, 0]) cube([1, 1, 7.3]);

translate([2, 6, 0]) cube([1, 1, 7.3]);

translate([3, 6, 0]) cube([1, 1, 7.5]);

translate([4, 6, 0]) cube([1, 1, 6.9]);

translate([5, 6, 0]) cube([1, 1, 6.609705215419501]);

color([0, 1, 0]) translate([6, 6, 0]) cube([1, 1, 6]);

translate([7, 6, 0]) cube([1, 1, 5.408288513916593]);

color([0, 1, 0]) translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.270392207591025]);

translate([10, 6, 0]) cube([1, 1, 5.119954587328544]);

translate([11, 6, 0]) cube([1, 1, 5.320073024022102]);

color([0, 1, 0]) translate([12, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 6, 0]) cube([1, 1, 6]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.7]);

translate([2, 7, 0]) cube([1, 1, 7.6]);

translate([3, 7, 0]) cube([1, 1, 7.4]);

translate([4, 7, 0]) cube([1, 1, 7.0]);

translate([5, 7, 0]) cube([1, 1, 7.0]);

translate([6, 7, 0]) cube([1, 1, 6.613106575963718]);

translate([7, 7, 0]) cube([1, 1, 5.401533129691458]);

color([0, 1, 0]) translate([8, 7, 0]) cube([1, 1, 6]);

translate([9, 7, 0]) cube([1, 1, 5.230071164398696]);

color([0, 1, 0]) translate([10, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 7, 0]) cube([1, 1, 6]);

translate([14, 7, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([15, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 7.7]);

translate([1, 8, 0]) cube([1, 1, 7.3]);

translate([2, 8, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([3, 8, 0]) cube([1, 1, 6]);

translate([4, 8, 0]) cube([1, 1, 6.6]);

translate([5, 8, 0]) cube([1, 1, 6.8]);

translate([6, 8, 0]) cube([1, 1, 6.54761104169559]);

translate([7, 8, 0]) cube([1, 1, 6.541283277029632]);

translate([8, 8, 0]) cube([1, 1, 5.405935454315996]);

color([0, 1, 0]) translate([9, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 8, 0]) cube([1, 1, 6]);

translate([14, 8, 0]) cube([1, 1, 6.7]);

color([0, 1, 0]) translate([15, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 6.8]);

translate([1, 9, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([2, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 9, 0]) cube([1, 1, 6]);

translate([6, 9, 0]) cube([1, 1, 6.635827664399092]);

color([0, 1, 0]) translate([7, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([1, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 10, 0]) cube([1, 1, 6]);

translate([7, 10, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([8, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 7.1]);

color([0, 1, 0]) translate([1, 11, 0]) cube([1, 1, 6]);

translate([2, 11, 0]) cube([1, 1, 5.481536695097988]);

color([0, 1, 0]) translate([3, 11, 0]) cube([1, 1, 6]);

translate([4, 11, 0]) cube([1, 1, 5.282044010028974]);

color([0, 1, 0]) translate([5, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.8]);

color([0, 1, 0]) translate([8, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 11, 0]) cube([1, 1, 6]);

translate([11, 11, 0]) cube([1, 1, 4.895543685157732]);

color([0, 1, 0]) translate([12, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 11, 0]) cube([1, 1, 6]);

translate([15, 11, 0]) cube([1, 1, 5.2580224704877505]);

translate([0, 12, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([1, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 12, 0]) cube([1, 1, 6]);

translate([6, 12, 0]) cube([1, 1, 7.0]);

translate([7, 12, 0]) cube([1, 1, 7.1]);

color([0, 1, 0]) translate([8, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 12, 0]) cube([1, 1, 6]);

translate([14, 12, 0]) cube([1, 1, 5.400489385419945]);

translate([15, 12, 0]) cube([1, 1, 5.134611225154575]);

color([0, 1, 0]) translate([0, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([1, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 13, 0]) cube([1, 1, 6]);

translate([5, 13, 0]) cube([1, 1, 6.7]);

translate([6, 13, 0]) cube([1, 1, 7.0]);

translate([7, 13, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([8, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 13, 0]) cube([1, 1, 6]);

translate([13, 13, 0]) cube([1, 1, 4.5751099606477785]);

translate([14, 13, 0]) cube([1, 1, 5.487332250917176]);

translate([15, 13, 0]) cube([1, 1, 5.137232726795317]);

color([0, 1, 0]) translate([0, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([1, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([0, 15, 0]) cube([1, 1, 6]);

translate([1, 15, 0]) cube([1, 1, 5.40002895813687]);

translate([2, 15, 0]) cube([1, 1, 5.300121403829079]);

translate([3, 15, 0]) cube([1, 1, 5.100405918866753]);

translate([4, 15, 0]) cube([1, 1, 5.400080399746347]);

color([0, 1, 0]) translate([5, 15, 0]) cube([1, 1, 6]);

translate([6, 15, 0]) cube([1, 1, 5.200060437024139]);

translate([7, 15, 0]) cube([1, 1, 5.400049449223025]);

color([0, 1, 0]) translate([8, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 15, 0]) cube([1, 1, 6]);

translate([11, 15, 0]) cube([1, 1, 5.304911889142442]);

translate([12, 15, 0]) cube([1, 1, 5.404911889142443]);

translate([13, 15, 0]) cube([1, 1, 5.350395300780668]);

color([0, 1, 0]) translate([14, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 15, 0]) cube([1, 1, 6]);
