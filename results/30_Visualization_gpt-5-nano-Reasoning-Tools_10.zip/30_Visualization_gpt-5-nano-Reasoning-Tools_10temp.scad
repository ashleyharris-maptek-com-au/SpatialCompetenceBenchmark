translate([0,0,0])translate([5,0,10]) rotate([90,0,90]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,21.5])translate([5,0,10]) rotate([90,0,90]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,43.0])translate([5,0,10]) rotate([90,0,90]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,64.5]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([-5,5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,66.0]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,67.5]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,69.0]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,70.5]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([0,0,0]) cube([10,1,1], center=true);translate([0,10,0]) cube([10,1,1], center=true);translate([-5,-5,0]) cube([1,10,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,72.0]) union(){
translate([0,-10,0]) cube([10,1,1], center=true);translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


translate([0,0,73.5]) union(){
translate([5,-5,0]) cube([1,10,1], center=true);translate([5,5,0]) cube([1,10,1], center=true);}


