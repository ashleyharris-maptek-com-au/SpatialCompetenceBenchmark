translate([0, 0, 0]) cube([1, 1, 5.000439196034545]);

translate([1, 0, 0]) cube([1, 1, 4.20225217710382]);

translate([2, 0, 0]) cube([1, 1, 4.043320096058579]);

translate([3, 0, 0]) cube([1, 1, 4.044273110908109]);

translate([4, 0, 0]) cube([1, 1, 4.300303453402057]);

translate([5, 0, 0]) cube([1, 1, 4.5]);

translate([6, 0, 0]) cube([1, 1, 4.360129167788205]);

translate([7, 0, 0]) cube([1, 1, 4.407431547619049]);

translate([8, 0, 0]) cube([1, 1, 5.0]);

translate([9, 0, 0]) cube([1, 1, 5.3]);

translate([10, 0, 0]) cube([1, 1, 5.4]);

translate([11, 0, 0]) cube([1, 1, 4.9]);

translate([12, 0, 0]) cube([1, 1, 4.4]);

translate([13, 0, 0]) cube([1, 1, 4.3]);

translate([14, 0, 0]) cube([1, 1, 4.4]);

translate([15, 0, 0]) cube([1, 1, 4.7]);

color([0, 1, 0]) translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.400878392069088]);

translate([2, 1, 0]) cube([1, 1, 4.803186768912169]);

translate([3, 1, 0]) cube([1, 1, 4.411470558858069]);

translate([4, 1, 0]) cube([1, 1, 4.354844542836424]);

translate([5, 1, 0]) cube([1, 1, 4.354986705727042]);

translate([6, 1, 0]) cube([1, 1, 4.366427264448292]);

translate([7, 1, 0]) cube([1, 1, 4.379791847729224]);

translate([8, 1, 0]) cube([1, 1, 4.39902395156297]);

translate([9, 1, 0]) cube([1, 1, 4.449650452760022]);

translate([10, 1, 0]) cube([1, 1, 4.431415023301836]);

translate([11, 1, 0]) cube([1, 1, 4.206283001730892]);

translate([12, 1, 0]) cube([1, 1, 4.001256598338653]);

translate([13, 1, 0]) cube([1, 1, 3.6357483408347933]);

translate([14, 1, 0]) cube([1, 1, 3.6228987240964012]);

translate([15, 1, 0]) cube([1, 1, 3.9]);

translate([0, 2, 0]) cube([1, 1, 7.2]);

color([0, 1, 0]) translate([1, 2, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.410663492560742]);

translate([4, 2, 0]) cube([1, 1, 5.0404667408755675]);

translate([5, 2, 0]) cube([1, 1, 4.54639168992098]);

translate([6, 2, 0]) cube([1, 1, 4.75239809837914]);

translate([7, 2, 0]) cube([1, 1, 4.4023935797743015]);

translate([8, 2, 0]) cube([1, 1, 4.803163676282574]);

translate([9, 2, 0]) cube([1, 1, 4.4801995367676195]);

translate([10, 2, 0]) cube([1, 1, 4.088973990289882]);

translate([11, 2, 0]) cube([1, 1, 3.837120264384443]);

translate([12, 2, 0]) cube([1, 1, 3.739150764013986]);

translate([13, 2, 0]) cube([1, 1, 3.633755268233994]);

translate([14, 2, 0]) cube([1, 1, 3.6229227398081294]);

translate([15, 2, 0]) cube([1, 1, 3.6230150585569376]);

translate([0, 3, 0]) cube([1, 1, 7.7]);

translate([1, 3, 0]) cube([1, 1, 7.0]);

translate([2, 3, 0]) cube([1, 1, 6.505424661263683]);

color([0, 1, 0]) translate([3, 3, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.246813205205343]);

translate([6, 3, 0]) cube([1, 1, 5.109429862207723]);

translate([7, 3, 0]) cube([1, 1, 5.258298115441695]);

translate([8, 3, 0]) cube([1, 1, 4.900233634172848]);

translate([9, 3, 0]) cube([1, 1, 4.662181971291273]);

translate([10, 3, 0]) cube([1, 1, 4.092869026821885]);

translate([11, 3, 0]) cube([1, 1, 3.8515759683104824]);

translate([12, 3, 0]) cube([1, 1, 3.814771699071004]);

translate([13, 3, 0]) cube([1, 1, 3.8090307832108334]);

translate([14, 3, 0]) cube([1, 1, 3.804923023796474]);

translate([15, 3, 0]) cube([1, 1, 3.803668546563046]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.3]);

translate([2, 4, 0]) cube([1, 1, 6.806974783740658]);

translate([3, 4, 0]) cube([1, 1, 6.520677623106857]);

color([0, 1, 0]) translate([4, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 4, 0]) cube([1, 1, 6]);

translate([7, 4, 0]) cube([1, 1, 5.21368510014325]);

translate([8, 4, 0]) cube([1, 1, 5.055989850308213]);

translate([9, 4, 0]) cube([1, 1, 4.951522701296271]);

translate([10, 4, 0]) cube([1, 1, 4.549102842875317]);

translate([11, 4, 0]) cube([1, 1, 4.372792034334252]);

translate([12, 4, 0]) cube([1, 1, 4.615408359961447]);

translate([13, 4, 0]) cube([1, 1, 4.607702482302171]);

translate([14, 4, 0]) cube([1, 1, 4.604492246034937]);

translate([15, 4, 0]) cube([1, 1, 4.504195824860789]);

translate([0, 5, 0]) cube([1, 1, 8.0]);

translate([1, 5, 0]) cube([1, 1, 7.122868480725623]);

translate([2, 5, 0]) cube([1, 1, 6.663079805996474]);

translate([3, 5, 0]) cube([1, 1, 6.816599794238682]);

translate([4, 5, 0]) cube([1, 1, 6.716204631029366]);

color([0, 1, 0]) translate([5, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 5, 0]) cube([1, 1, 6]);

translate([9, 5, 0]) cube([1, 1, 4.988038332035153]);

translate([10, 5, 0]) cube([1, 1, 4.986540155934376]);

translate([11, 5, 0]) cube([1, 1, 5.170947898567651]);

color([0, 1, 0]) translate([12, 5, 0]) cube([1, 1, 6]);

translate([13, 5, 0]) cube([1, 1, 5.410158730158731]);

translate([14, 5, 0]) cube([1, 1, 5.108095238095237]);

translate([15, 5, 0]) cube([1, 1, 5.3]);

translate([0, 6, 0]) cube([1, 1, 8.2]);

translate([1, 6, 0]) cube([1, 1, 7.330419501133786]);

translate([2, 6, 0]) cube([1, 1, 7.338185941043084]);

translate([3, 6, 0]) cube([1, 1, 7.511111111111111]);

translate([4, 6, 0]) cube([1, 1, 6.9457073570168815]);

translate([5, 6, 0]) cube([1, 1, 6.651194869322898]);

color([0, 1, 0]) translate([6, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 6, 0]) cube([1, 1, 6]);

translate([8, 6, 0]) cube([1, 1, 5.456811216918195]);

translate([9, 6, 0]) cube([1, 1, 5.381957735366034]);

translate([10, 6, 0]) cube([1, 1, 5.313146158697288]);

translate([11, 6, 0]) cube([1, 1, 5.407607703218668]);

color([0, 1, 0]) translate([12, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 6, 0]) cube([1, 1, 6]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.7]);

translate([2, 7, 0]) cube([1, 1, 6.929217687074829]);

translate([3, 7, 0]) cube([1, 1, 6.780350056689344]);

translate([4, 7, 0]) cube([1, 1, 6.480821379518152]);

translate([5, 7, 0]) cube([1, 1, 6.65466882851024]);

color([0, 1, 0]) translate([6, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 7, 0]) cube([1, 1, 6]);

translate([9, 7, 0]) cube([1, 1, 5.4105685394936724]);

translate([10, 7, 0]) cube([1, 1, 5.160757029201425]);

translate([11, 7, 0]) cube([1, 1, 5.370514298550207]);

translate([12, 7, 0]) cube([1, 1, 5.462679516250945]);

color([0, 1, 0]) translate([13, 7, 0]) cube([1, 1, 6]);

translate([14, 7, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([15, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 7.7]);

translate([1, 8, 0]) cube([1, 1, 7.316666666666666]);

translate([2, 8, 0]) cube([1, 1, 7.035714285714286]);

translate([3, 8, 0]) cube([1, 1, 6.653852463554559]);

translate([4, 8, 0]) cube([1, 1, 6.680256024367418]);

translate([5, 8, 0]) cube([1, 1, 6.826300705467371]);

color([0, 1, 0]) translate([6, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 8, 0]) cube([1, 1, 6]);

translate([14, 8, 0]) cube([1, 1, 6.7]);

color([0, 1, 0]) translate([15, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 6.805555555555555]);

translate([1, 9, 0]) cube([1, 1, 6.614484126984127]);

color([0, 1, 0]) translate([2, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 9, 0]) cube([1, 1, 6]);

translate([6, 9, 0]) cube([1, 1, 6.633698034769464]);

color([0, 1, 0]) translate([7, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([1, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 10, 0]) cube([1, 1, 6]);

translate([7, 10, 0]) cube([1, 1, 6.645061728395061]);

color([0, 1, 0]) translate([8, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 7.1]);

color([0, 1, 0]) translate([1, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 11, 0]) cube([1, 1, 6]);

translate([15, 11, 0]) cube([1, 1, 5.204681568539104]);

translate([0, 12, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([1, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 12, 0]) cube([1, 1, 6]);

translate([6, 12, 0]) cube([1, 1, 7.011111111082432]);

color([0, 1, 0]) translate([7, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 12, 0]) cube([1, 1, 6]);

translate([14, 12, 0]) cube([1, 1, 5.309244095404523]);

translate([15, 12, 0]) cube([1, 1, 4.829972548950815]);

color([0, 1, 0]) translate([0, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([1, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 13, 0]) cube([1, 1, 6]);

translate([5, 13, 0]) cube([1, 1, 6.703174603100855]);

translate([6, 13, 0]) cube([1, 1, 7.011111111082432]);

translate([7, 13, 0]) cube([1, 1, 6.615873015799267]);

color([0, 1, 0]) translate([8, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 13, 0]) cube([1, 1, 6]);

translate([13, 13, 0]) cube([1, 1, 5.409433571935323]);

translate([14, 13, 0]) cube([1, 1, 5.407481141056169]);

translate([15, 13, 0]) cube([1, 1, 5.008486380150752]);

color([0, 1, 0]) translate([0, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([1, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 14, 0]) cube([1, 1, 6]);

translate([5, 14, 0]) cube([1, 1, 6.502040816194837]);

color([0, 1, 0]) translate([6, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([0, 15, 0]) cube([1, 1, 6]);

translate([1, 15, 0]) cube([1, 1, 5.401125384462476]);

translate([2, 15, 0]) cube([1, 1, 5.3036854816605565]);

translate([3, 15, 0]) cube([1, 1, 5.115243012715666]);

translate([4, 15, 0]) cube([1, 1, 5.405048329821499]);

color([0, 1, 0]) translate([5, 15, 0]) cube([1, 1, 6]);

translate([6, 15, 0]) cube([1, 1, 5.242262417349689]);

translate([7, 15, 0]) cube([1, 1, 5.420219100177444]);

color([0, 1, 0]) translate([8, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 15, 0]) cube([1, 1, 6]);

translate([11, 15, 0]) cube([1, 1, 5.3003157747042255]);

translate([12, 15, 0]) cube([1, 1, 5.400315779192697]);

translate([13, 15, 0]) cube([1, 1, 5.30183916439541]);

color([0, 1, 0]) translate([14, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 15, 0]) cube([1, 1, 6]);
