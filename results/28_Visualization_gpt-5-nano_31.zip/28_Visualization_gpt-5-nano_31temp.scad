
translate([0, 0, 0]) cube([1, 1, 4.269342581548393]);

translate([1, 0, 0]) cube([1, 1, 4.629338312008828]);

translate([2, 0, 0]) cube([1, 1, 4.363488796974729]);

translate([3, 0, 0]) cube([1, 1, 4.185412829896277]);

translate([4, 0, 0]) cube([1, 1, 4.036690786409586]);

translate([5, 0, 0]) cube([1, 1, 3.9304985631936633]);

translate([6, 0, 0]) cube([1, 1, 3.930512521651574]);

translate([7, 0, 0]) cube([1, 1, 4.000081918223399]);

translate([8, 0, 0]) cube([1, 1, 4.2000093932127776]);

translate([9, 0, 0]) cube([1, 1, 4.4]);

translate([10, 0, 0]) cube([1, 1, 4.5]);

translate([11, 0, 0]) cube([1, 1, 4.3]);

translate([12, 0, 0]) cube([1, 1, 4.208147321428572]);

translate([13, 0, 0]) cube([1, 1, 4.232589285714285]);

translate([14, 0, 0]) cube([1, 1, 4.507390873015873]);

translate([15, 0, 0]) cube([1, 1, 3.2077688477444752]);

translate([16, 0, 0]) cube([1, 1, 5.0]);

translate([17, 0, 0]) cube([1, 1, 5.2]);

translate([18, 0, 0]) cube([1, 1, 5.3]);

translate([19, 0, 0]) cube([1, 1, 5.4]);

translate([20, 0, 0]) cube([1, 1, 5.4]);

translate([21, 0, 0]) cube([1, 1, 5.2]);

translate([22, 0, 0]) cube([1, 1, 4.9]);

translate([23, 0, 0]) cube([1, 1, 4.6]);

translate([24, 0, 0]) cube([1, 1, 4.4]);

translate([25, 0, 0]) cube([1, 1, 4.3000638888888885]);

translate([26, 0, 0]) cube([1, 1, 4.300255555555555]);

translate([27, 0, 0]) cube([1, 1, 4.301277777777777]);

translate([28, 0, 0]) cube([1, 1, 4.406388888888889]);

translate([29, 0, 0]) cube([1, 1, 4.631944444444445]);

translate([30, 0, 0]) cube([1, 1, 4.7972222222222225]);

translate([31, 0, 0]) cube([1, 1, 3.6173280423280416]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.140003405411206]);

translate([2, 1, 0]) cube([1, 1, 4.74801066713279]);

translate([3, 1, 0]) cube([1, 1, 4.509625209907606]);

translate([4, 1, 0]) cube([1, 1, 4.2150343194248725]);

translate([5, 1, 0]) cube([1, 1, 4.013016486230774]);

translate([6, 1, 0]) cube([1, 1, 3.9306004419957707]);

translate([7, 1, 0]) cube([1, 1, 4.00014089255049]);

translate([8, 1, 0]) cube([1, 1, 4.10012188548183]);

translate([9, 1, 0]) cube([1, 1, 4.200037574740517]);

translate([10, 1, 0]) cube([1, 1, 4.20002457203518]);

translate([11, 1, 0]) cube([1, 1, 4.003778100088805]);

translate([12, 1, 0]) cube([1, 1, 4.001684005884228]);

translate([13, 1, 0]) cube([1, 1, 4.014859067097734]);

translate([14, 1, 0]) cube([1, 1, 4.118398259858312]);

translate([15, 1, 0]) cube([1, 1, 4.395335254472159]);

translate([16, 1, 0]) cube([1, 1, 4.586644463340892]);

translate([17, 1, 0]) cube([1, 1, 4.617230725623582]);

translate([18, 1, 0]) cube([1, 1, 4.8]);

translate([19, 1, 0]) cube([1, 1, 4.9]);

translate([20, 1, 0]) cube([1, 1, 4.8]);

translate([21, 1, 0]) cube([1, 1, 4.7]);

translate([22, 1, 0]) cube([1, 1, 4.5]);

translate([23, 1, 0]) cube([1, 1, 4.4]);

translate([24, 1, 0]) cube([1, 1, 4.200012777777777]);

translate([25, 1, 0]) cube([1, 1, 4.000066444444444]);

translate([26, 1, 0]) cube([1, 1, 3.8004197947530862]);

translate([27, 1, 0]) cube([1, 1, 3.7064222767306]);

translate([28, 1, 0]) cube([1, 1, 3.91734708994709]);

translate([29, 1, 0]) cube([1, 1, 4.047124338624339]);

translate([30, 1, 0]) cube([1, 1, 4.300066137566137]);

translate([31, 1, 0]) cube([1, 1, 4.420039682539683]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

translate([2, 2, 0]) cube([1, 1, 5.400012706541544]);

translate([3, 2, 0]) cube([1, 1, 5.100033767284898]);

translate([4, 2, 0]) cube([1, 1, 4.800068908785052]);

translate([5, 2, 0]) cube([1, 1, 4.5001103805696765]);

translate([6, 2, 0]) cube([1, 1, 4.400161551692851]);

translate([7, 2, 0]) cube([1, 1, 4.400119411097634]);

translate([8, 2, 0]) cube([1, 1, 4.300124913095802]);

translate([9, 2, 0]) cube([1, 1, 4.200074364814062]);

translate([10, 2, 0]) cube([1, 1, 4.002205541849956]);

translate([11, 2, 0]) cube([1, 1, 4.001684048123295]);

translate([12, 2, 0]) cube([1, 1, 4.001684161168837]);

translate([13, 2, 0]) cube([1, 1, 4.013860717492954]);

translate([14, 2, 0]) cube([1, 1, 4.074102702808462]);

translate([15, 2, 0]) cube([1, 1, 4.13749708593918]);

translate([16, 2, 0]) cube([1, 1, 4.265690016527189]);

translate([17, 2, 0]) cube([1, 1, 4.347494888239288]);

translate([18, 2, 0]) cube([1, 1, 4.403446145124717]);

translate([19, 2, 0]) cube([1, 1, 4.5]);

translate([20, 2, 0]) cube([1, 1, 4.4]);

translate([21, 2, 0]) cube([1, 1, 4.3]);

translate([22, 2, 0]) cube([1, 1, 4.2]);

translate([23, 2, 0]) cube([1, 1, 4.000005685185185]);

translate([24, 2, 0]) cube([1, 1, 4.000013851851852]);

translate([25, 2, 0]) cube([1, 1, 3.900015512345679]);

translate([26, 2, 0]) cube([1, 1, 3.601384805577602]);

translate([27, 2, 0]) cube([1, 1, 3.4211614198740916]);

translate([28, 2, 0]) cube([1, 1, 3.5335660355922465]);

translate([29, 2, 0]) cube([1, 1, 3.8418151851851854]);

translate([30, 2, 0]) cube([1, 1, 3.9445383597883596]);

translate([31, 2, 0]) cube([1, 1, 3.8882147266313933]);

translate([0, 3, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

translate([4, 3, 0]) cube([1, 1, 5.400099530574327]);

translate([5, 3, 0]) cube([1, 1, 5.100168454104926]);

translate([6, 3, 0]) cube([1, 1, 5.000215011515593]);

translate([7, 3, 0]) cube([1, 1, 4.900208933088926]);

translate([8, 3, 0]) cube([1, 1, 4.700116540356294]);

translate([9, 3, 0]) cube([1, 1, 4.400179682087122]);

translate([10, 3, 0]) cube([1, 1, 4.100295213085721]);

translate([11, 3, 0]) cube([1, 1, 4.002230956457745]);

translate([12, 3, 0]) cube([1, 1, 4.200043129324834]);

translate([13, 3, 0]) cube([1, 1, 4.3000034515781165]);

translate([14, 3, 0]) cube([1, 1, 4.300001799549236]);

translate([15, 3, 0]) cube([1, 1, 4.2290900047027025]);

translate([16, 3, 0]) cube([1, 1, 4.321575188425402]);

translate([17, 3, 0]) cube([1, 1, 4.400689332193713]);

translate([18, 3, 0]) cube([1, 1, 4.400689279159791]);

translate([19, 3, 0]) cube([1, 1, 4.301121044338192]);

translate([20, 3, 0]) cube([1, 1, 4.200224208197963]);

translate([21, 3, 0]) cube([1, 1, 4.100044841425517]);

translate([22, 3, 0]) cube([1, 1, 3.800041684570845]);

translate([23, 3, 0]) cube([1, 1, 3.6000794578102395]);

translate([24, 3, 0]) cube([1, 1, 3.6000650569895476]);

translate([25, 3, 0]) cube([1, 1, 3.6002356949625227]);

translate([26, 3, 0]) cube([1, 1, 3.4057231328298347]);

translate([27, 3, 0]) cube([1, 1, 3.3424769572407147]);

translate([28, 3, 0]) cube([1, 1, 3.4268204576851207]);

translate([29, 3, 0]) cube([1, 1, 3.621555252267574]);

translate([30, 3, 0]) cube([1, 1, 3.729094711934156]);

translate([31, 3, 0]) cube([1, 1, 3.6539492661179698]);

translate([0, 4, 0]) cube([1, 1, 7.2]);

translate([1, 4, 0]) cube([1, 1, 6.600001427005514]);

color([0,1,0])
translate([2, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.400339345144503]);

translate([7, 4, 0]) cube([1, 1, 5.300299884312587]);

translate([8, 4, 0]) cube([1, 1, 5.000190425658305]);

translate([9, 4, 0]) cube([1, 1, 4.600419503244128]);

translate([10, 4, 0]) cube([1, 1, 4.4003140876776365]);

translate([11, 4, 0]) cube([1, 1, 4.400193214743309]);

translate([12, 4, 0]) cube([1, 1, 4.600016020534966]);

translate([13, 4, 0]) cube([1, 1, 4.800002961147371]);

translate([14, 4, 0]) cube([1, 1, 4.800001728399039]);

translate([15, 4, 0]) cube([1, 1, 4.700000857326788]);

translate([16, 4, 0]) cube([1, 1, 4.700000424126897]);

translate([17, 4, 0]) cube([1, 1, 4.700000173358585]);

translate([18, 4, 0]) cube([1, 1, 4.400348755360746]);

translate([19, 4, 0]) cube([1, 1, 4.10059978636115]);

translate([20, 4, 0]) cube([1, 1, 4.0004282292320905]);

translate([21, 4, 0]) cube([1, 1, 3.900116212847005]);

translate([22, 4, 0]) cube([1, 1, 3.600204901366258]);

translate([23, 4, 0]) cube([1, 1, 3.4010349480888404]);

translate([24, 4, 0]) cube([1, 1, 3.4009684593313314]);

translate([25, 4, 0]) cube([1, 1, 3.5000951003915075]);

translate([26, 4, 0]) cube([1, 1, 3.402420863792687]);

translate([27, 4, 0]) cube([1, 1, 3.3360434082435164]);

translate([28, 4, 0]) cube([1, 1, 3.347244835241334]);

translate([29, 4, 0]) cube([1, 1, 3.514689615381919]);

translate([30, 4, 0]) cube([1, 1, 3.615119328936993]);

translate([31, 4, 0]) cube([1, 1, 3.608048331247563]);

translate([0, 5, 0]) cube([1, 1, 7.4]);

translate([1, 5, 0]) cube([1, 1, 6.900001508424612]);

translate([2, 5, 0]) cube([1, 1, 6.60000477466774]);

color([0,1,0])
translate([3, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

translate([8, 5, 0]) cube([1, 1, 5.300423333407966]);

translate([9, 5, 0]) cube([1, 1, 4.900578718148243]);

translate([10, 5, 0]) cube([1, 1, 4.700368996576479]);

translate([11, 5, 0]) cube([1, 1, 4.90006107455673]);

translate([12, 5, 0]) cube([1, 1, 5.100012680265553]);

translate([13, 5, 0]) cube([1, 1, 5.300003386705177]);

translate([14, 5, 0]) cube([1, 1, 5.300001700397596]);

translate([15, 5, 0]) cube([1, 1, 5.100000594355623]);

translate([16, 5, 0]) cube([1, 1, 5.100000265229057]);

translate([17, 5, 0]) cube([1, 1, 4.9000003783817565]);

translate([18, 5, 0]) cube([1, 1, 4.500015860303429]);

translate([19, 5, 0]) cube([1, 1, 4.000399744333443]);

translate([20, 5, 0]) cube([1, 1, 3.8004931917052494]);

translate([21, 5, 0]) cube([1, 1, 3.7007835180030852]);

translate([22, 5, 0]) cube([1, 1, 3.502153682002566]);

translate([23, 5, 0]) cube([1, 1, 3.3113619853454237]);

translate([24, 5, 0]) cube([1, 1, 3.4010721923646887]);

translate([25, 5, 0]) cube([1, 1, 3.500160284596816]);

translate([26, 5, 0]) cube([1, 1, 3.5001799729789154]);

translate([27, 5, 0]) cube([1, 1, 3.4031231326723996]);

translate([28, 5, 0]) cube([1, 1, 3.408054056322013]);

translate([29, 5, 0]) cube([1, 1, 3.514124357555574]);

translate([30, 5, 0]) cube([1, 1, 3.607678783770875]);

translate([31, 5, 0]) cube([1, 1, 3.6088917164012444]);

translate([0, 6, 0]) cube([1, 1, 7.7]);

translate([1, 6, 0]) cube([1, 1, 7.200000601502822]);

translate([2, 6, 0]) cube([1, 1, 7.000005432820715]);

translate([3, 6, 0]) cube([1, 1, 6.800015756427337]);

translate([4, 6, 0]) cube([1, 1, 6.500251213374478]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.200558825311487]);

translate([10, 6, 0]) cube([1, 1, 5.100237570490432]);

translate([11, 6, 0]) cube([1, 1, 5.300039797799039]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([16, 6, 0]) cube([1, 1, 5.300000963545035]);

translate([17, 6, 0]) cube([1, 1, 5.000001044214082]);

translate([18, 6, 0]) cube([1, 1, 4.500078923577887]);

translate([19, 6, 0]) cube([1, 1, 4.000428798775971]);

translate([20, 6, 0]) cube([1, 1, 3.703109039065387]);

translate([21, 6, 0]) cube([1, 1, 3.5048744720581615]);

translate([22, 6, 0]) cube([1, 1, 3.503407914379432]);

translate([23, 6, 0]) cube([1, 1, 3.502344758109133]);

translate([24, 6, 0]) cube([1, 1, 3.6001751316808055]);

translate([25, 6, 0]) cube([1, 1, 3.700195556623486]);

translate([26, 6, 0]) cube([1, 1, 3.800285934648907]);

translate([27, 6, 0]) cube([1, 1, 3.900397671952208]);

translate([28, 6, 0]) cube([1, 1, 3.8013201712507114]);

translate([29, 6, 0]) cube([1, 1, 3.801684409147638]);

translate([30, 6, 0]) cube([1, 1, 3.8018807644389407]);

translate([31, 6, 0]) cube([1, 1, 3.7030642484232845]);

translate([0, 7, 0]) cube([1, 1, 8.0]);

translate([1, 7, 0]) cube([1, 1, 7.5]);

translate([2, 7, 0]) cube([1, 1, 7.300002406684236]);

translate([3, 7, 0]) cube([1, 1, 7.000025219983211]);

translate([4, 7, 0]) cube([1, 1, 6.800051907129358]);

translate([5, 7, 0]) cube([1, 1, 6.501172137078883]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([16, 7, 0]) cube([1, 1, 5.400005038545038]);

translate([17, 7, 0]) cube([1, 1, 4.900033102113953]);

translate([18, 7, 0]) cube([1, 1, 4.600358882713751]);

translate([19, 7, 0]) cube([1, 1, 4.201140483095943]);

translate([20, 7, 0]) cube([1, 1, 3.8038959627536975]);

translate([21, 7, 0]) cube([1, 1, 3.704842473626881]);

translate([22, 7, 0]) cube([1, 1, 3.8014368722838614]);

translate([23, 7, 0]) cube([1, 1, 4.0003255215143625]);

translate([24, 7, 0]) cube([1, 1, 4.000194027430621]);

translate([25, 7, 0]) cube([1, 1, 4.100160557971517]);

translate([26, 7, 0]) cube([1, 1, 4.300337265571112]);

translate([27, 7, 0]) cube([1, 1, 4.40053417869959]);

translate([28, 7, 0]) cube([1, 1, 4.30151458744255]);

translate([29, 7, 0]) cube([1, 1, 4.202329623731986]);

translate([30, 7, 0]) cube([1, 1, 4.103160267028892]);

translate([31, 7, 0]) cube([1, 1, 4.004151714179581]);

translate([0, 8, 0]) cube([1, 1, 7.9]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 7.300014440105416]);

translate([3, 8, 0]) cube([1, 1, 7.00013863448393]);

translate([4, 8, 0]) cube([1, 1, 6.800161765347599]);

translate([5, 8, 0]) cube([1, 1, 6.601640301705205]);

translate([6, 8, 0]) cube([1, 1, 6.5041640269041]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([16, 8, 0]) cube([1, 1, 5.400021643389695]);

translate([17, 8, 0]) cube([1, 1, 5.000103720987416]);

translate([18, 8, 0]) cube([1, 1, 4.70165654880152]);

translate([19, 8, 0]) cube([1, 1, 4.4036080624557625]);

translate([20, 8, 0]) cube([1, 1, 4.1053587935808675]);

translate([21, 8, 0]) cube([1, 1, 4.005047713106246]);

translate([22, 8, 0]) cube([1, 1, 4.201527939180218]);

translate([23, 8, 0]) cube([1, 1, 4.500283190717299]);

translate([24, 8, 0]) cube([1, 1, 4.600026470796216]);

translate([25, 8, 0]) cube([1, 1, 4.600095905331166]);

translate([26, 8, 0]) cube([1, 1, 4.600343148953171]);

translate([27, 8, 0]) cube([1, 1, 4.700713095048532]);

translate([28, 8, 0]) cube([1, 1, 4.6021488281958325]);

translate([29, 8, 0]) cube([1, 1, 4.5041768354457]);

translate([30, 8, 0]) cube([1, 1, 4.503807868154476]);

translate([31, 8, 0]) cube([1, 1, 4.405487007812303]);

translate([0, 9, 0]) cube([1, 1, 7.9]);

translate([1, 9, 0]) cube([1, 1, 7.400086641000836]);

translate([2, 9, 0]) cube([1, 1, 7.100809735246209]);

translate([3, 9, 0]) cube([1, 1, 6.90078637677505]);

translate([4, 9, 0]) cube([1, 1, 6.607618313974854]);

translate([5, 9, 0]) cube([1, 1, 6.516773449948208]);

translate([6, 9, 0]) cube([1, 1, 6.602207478357605]);

translate([7, 9, 0]) cube([1, 1, 6.700032635291534]);

translate([8, 9, 0]) cube([1, 1, 6.500010034007648]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 5.100407766574926]);

translate([18, 9, 0]) cube([1, 1, 4.901708313234918]);

translate([19, 9, 0]) cube([1, 1, 4.704756867029242]);

translate([20, 9, 0]) cube([1, 1, 4.505951639032849]);

translate([21, 9, 0]) cube([1, 1, 4.405978122709671]);

translate([22, 9, 0]) cube([1, 1, 4.701374359619259]);

translate([23, 9, 0]) cube([1, 1, 5.000004024616525]);

translate([24, 9, 0]) cube([1, 1, 5.100011100963948]);

translate([25, 9, 0]) cube([1, 1, 5.10002922589402]);

translate([26, 9, 0]) cube([1, 1, 5.000135990835706]);

translate([27, 9, 0]) cube([1, 1, 4.900789592073595]);

translate([28, 9, 0]) cube([1, 1, 4.803352987381886]);

translate([29, 9, 0]) cube([1, 1, 4.805888466671186]);

translate([30, 9, 0]) cube([1, 1, 4.905814779659549]);

translate([31, 9, 0]) cube([1, 1, 4.906838375622884]);

translate([0, 10, 0]) cube([1, 1, 8.0]);

translate([1, 10, 0]) cube([1, 1, 7.5003465640033475]);

translate([2, 10, 0]) cube([1, 1, 7.102969074258812]);

translate([3, 10, 0]) cube([1, 1, 6.715372342411019]);

translate([4, 10, 0]) cube([1, 1, 6.612764455186925]);

translate([5, 10, 0]) cube([1, 1, 6.608938353662971]);

translate([6, 10, 0]) cube([1, 1, 6.800216232332318]);

translate([7, 10, 0]) cube([1, 1, 6.900012214708419]);

translate([8, 10, 0]) cube([1, 1, 6.700015354045929]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 5.101686732088763]);

translate([18, 10, 0]) cube([1, 1, 4.906566943027461]);

translate([19, 10, 0]) cube([1, 1, 4.808416916344359]);

translate([20, 10, 0]) cube([1, 1, 4.709718819678387]);

translate([21, 10, 0]) cube([1, 1, 4.7068655931485015]);

translate([22, 10, 0]) cube([1, 1, 5.100002080115107]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 10, 0]) cube([1, 1, 6]);

translate([26, 10, 0]) cube([1, 1, 5.400135556642545]);

translate([27, 10, 0]) cube([1, 1, 5.2004882440781675]);

translate([28, 10, 0]) cube([1, 1, 5.103188169182546]);

translate([29, 10, 0]) cube([1, 1, 5.105958024669485]);

translate([30, 10, 0]) cube([1, 1, 5.311580813041524]);

translate([31, 10, 0]) cube([1, 1, 5.4102346872069305]);

translate([0, 11, 0]) cube([1, 1, 8.2]);

translate([1, 11, 0]) cube([1, 1, 7.7017328200167405]);

translate([2, 11, 0]) cube([1, 1, 7.212501568846129]);

translate([3, 11, 0]) cube([1, 1, 6.917762187989199]);

translate([4, 11, 0]) cube([1, 1, 6.911288084117662]);

translate([5, 11, 0]) cube([1, 1, 7.000983444618515]);

translate([6, 11, 0]) cube([1, 1, 7.2000595982808635]);

translate([7, 11, 0]) cube([1, 1, 7.100025904992168]);

translate([8, 11, 0]) cube([1, 1, 6.700024825780776]);

translate([9, 11, 0]) cube([1, 1, 6.500025109255081]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

translate([17, 11, 0]) cube([1, 1, 5.107539489152706]);

translate([18, 11, 0]) cube([1, 1, 5.011013125743476]);

translate([19, 11, 0]) cube([1, 1, 4.910595911472625]);

translate([20, 11, 0]) cube([1, 1, 4.811612712427932]);

translate([21, 11, 0]) cube([1, 1, 4.810538698339654]);

translate([22, 11, 0]) cube([1, 1, 5.200008133869268]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 8.2]);

translate([1, 12, 0]) cube([1, 1, 7.708664100083695]);

translate([2, 12, 0]) cube([1, 1, 7.324257934918105]);

translate([3, 12, 0]) cube([1, 1, 7.224242077640027]);

translate([4, 12, 0]) cube([1, 1, 7.304440436630488]);

translate([5, 12, 0]) cube([1, 1, 7.40036185021222]);

translate([6, 12, 0]) cube([1, 1, 7.500055337969012]);

translate([7, 12, 0]) cube([1, 1, 7.200040493703134]);

translate([8, 12, 0]) cube([1, 1, 6.900026705716756]);

translate([9, 12, 0]) cube([1, 1, 6.600024104628776]);

translate([10, 12, 0]) cube([1, 1, 6.600009447298089]);

translate([11, 12, 0]) cube([1, 1, 6.600002402805235]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

translate([17, 12, 0]) cube([1, 1, 5.3138956872331615]);

translate([18, 12, 0]) cube([1, 1, 5.116632973719128]);

translate([19, 12, 0]) cube([1, 1, 5.015907345971067]);

translate([20, 12, 0]) cube([1, 1, 4.91733934532646]);

translate([21, 12, 0]) cube([1, 1, 5.00450562875305]);

translate([22, 12, 0]) cube([1, 1, 5.300034187325748]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 8.118518518518519]);

translate([1, 13, 0]) cube([1, 1, 7.728968648566621]);

translate([2, 13, 0]) cube([1, 1, 7.53753671071093]);

translate([3, 13, 0]) cube([1, 1, 7.520129460733768]);

translate([4, 13, 0]) cube([1, 1, 7.601366546806926]);

translate([5, 13, 0]) cube([1, 1, 7.600344325614706]);

translate([6, 13, 0]) cube([1, 1, 7.6000430406704576]);

translate([7, 13, 0]) cube([1, 1, 7.300044492454012]);

translate([8, 13, 0]) cube([1, 1, 7.000022638268244]);

translate([9, 13, 0]) cube([1, 1, 6.8000181618783335]);

translate([10, 13, 0]) cube([1, 1, 6.800004087180441]);

translate([11, 13, 0]) cube([1, 1, 6.800000882802896]);

translate([12, 13, 0]) cube([1, 1, 6.600000822178587]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

translate([18, 13, 0]) cube([1, 1, 5.4230105368017645]);

translate([19, 13, 0]) cube([1, 1, 5.318016227174682]);

translate([20, 13, 0]) cube([1, 1, 5.2102672684341655]);

translate([21, 13, 0]) cube([1, 1, 5.207548830873063]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 13, 0]) cube([1, 1, 6]);

translate([27, 13, 0]) cube([1, 1, 6.6]);

translate([28, 13, 0]) cube([1, 1, 6.7]);

translate([29, 13, 0]) cube([1, 1, 6.604960317460317]);

color([0,1,0])
translate([30, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 8.218518518518518]);

translate([1, 14, 0]) cube([1, 1, 7.872266055583112]);

translate([2, 14, 0]) cube([1, 1, 7.730843617238607]);

translate([3, 14, 0]) cube([1, 1, 7.609404421371684]);

translate([4, 14, 0]) cube([1, 1, 7.601366546806926]);

translate([5, 14, 0]) cube([1, 1, 7.500624091879385]);

translate([6, 14, 0]) cube([1, 1, 7.400168576360757]);

translate([7, 14, 0]) cube([1, 1, 7.200042684783901]);

translate([8, 14, 0]) cube([1, 1, 7.000016942719676]);

translate([9, 14, 0]) cube([1, 1, 7.000005654426846]);

translate([10, 14, 0]) cube([1, 1, 7.000000706777479]);

translate([11, 14, 0]) cube([1, 1, 6.800001297838682]);

translate([12, 14, 0]) cube([1, 1, 6.600000750304385]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

translate([14, 14, 0]) cube([1, 1, 6.500509810405643]);

translate([15, 14, 0]) cube([1, 1, 6.502976190476191]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 14, 0]) cube([1, 1, 6]);

translate([27, 14, 0]) cube([1, 1, 6.9]);

translate([28, 14, 0]) cube([1, 1, 7.0]);

translate([29, 14, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([30, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 6.477990665264896]);

translate([1, 15, 0]) cube([1, 1, 7.879757402092781]);

translate([2, 15, 0]) cube([1, 1, 7.734987332363181]);

translate([3, 15, 0]) cube([1, 1, 7.515320383380348]);

translate([4, 15, 0]) cube([1, 1, 7.305343088687667]);

translate([5, 15, 0]) cube([1, 1, 7.101500460645525]);

translate([6, 15, 0]) cube([1, 1, 6.900467162733914]);

translate([7, 15, 0]) cube([1, 1, 6.800176561619762]);

translate([8, 15, 0]) cube([1, 1, 6.900010880287237]);

translate([9, 15, 0]) cube([1, 1, 6.900006836681826]);

translate([10, 15, 0]) cube([1, 1, 6.900002199647693]);

translate([11, 15, 0]) cube([1, 1, 6.7000010990255685]);

translate([12, 15, 0]) cube([1, 1, 6.500000804163422]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

translate([14, 15, 0]) cube([1, 1, 6.500578703703703]);

translate([15, 15, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 15, 0]) cube([1, 1, 6]);

translate([27, 15, 0]) cube([1, 1, 6.8]);

translate([28, 15, 0]) cube([1, 1, 6.9]);

translate([29, 15, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([30, 15, 0]) cube([1, 1, 6]);

translate([31, 15, 0]) cube([1, 1, 4.799777379873416]);

translate([0, 16, 0]) cube([1, 1, 7.8078496285667045]);

translate([1, 16, 0]) cube([1, 1, 7.499599060503777]);

translate([2, 16, 0]) cube([1, 1, 7.345932835668017]);

translate([3, 16, 0]) cube([1, 1, 7.220316727973649]);

translate([4, 16, 0]) cube([1, 1, 7.008496132137437]);

translate([5, 16, 0]) cube([1, 1, 6.705441637356426]);

translate([6, 16, 0]) cube([1, 1, 6.5015171644711245]);

translate([7, 16, 0]) cube([1, 1, 6.500552868218159]);

translate([8, 16, 0]) cube([1, 1, 6.600039703988611]);

translate([9, 16, 0]) cube([1, 1, 6.700004241354239]);

translate([10, 16, 0]) cube([1, 1, 6.800001290863988]);

translate([11, 16, 0]) cube([1, 1, 6.600000764877481]);

translate([12, 16, 0]) cube([1, 1, 6.500000715022835]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

translate([14, 16, 0]) cube([1, 1, 6.5001929031653765]);

translate([15, 16, 0]) cube([1, 1, 6.6]);

translate([16, 16, 0]) cube([1, 1, 4.455380158730158]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 16, 0]) cube([1, 1, 6]);

translate([28, 16, 0]) cube([1, 1, 6.7]);

translate([29, 16, 0]) cube([1, 1, 6.604960317460317]);

color([0,1,0])
translate([30, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 16, 0]) cube([1, 1, 6]);

translate([0, 17, 0]) cube([1, 1, 7.15186217226762]);

translate([1, 17, 0]) cube([1, 1, 6.9653672652121275]);

translate([2, 17, 0]) cube([1, 1, 6.9419246519009485]);

translate([3, 17, 0]) cube([1, 1, 6.923334069460738]);

translate([4, 17, 0]) cube([1, 1, 6.709237444826138]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

translate([10, 17, 0]) cube([1, 1, 6.500001318004478]);

translate([11, 17, 0]) cube([1, 1, 6.600000293623954]);

translate([12, 17, 0]) cube([1, 1, 6.5000006098428225]);

translate([13, 17, 0]) cube([1, 1, 6.600000007962519]);

translate([14, 17, 0]) cube([1, 1, 6.600000001138185]);

translate([15, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

translate([19, 17, 0]) cube([1, 1, 5.474932075717733]);

translate([20, 17, 0]) cube([1, 1, 5.442422906549611]);

translate([21, 17, 0]) cube([1, 1, 5.415438732447563]);

color([0,1,0])
translate([22, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 17, 0]) cube([1, 1, 6]);

translate([0, 18, 0]) cube([1, 1, 6.829307359257469]);

translate([1, 18, 0]) cube([1, 1, 6.654591632847634]);

translate([2, 18, 0]) cube([1, 1, 6.63673664864051]);

translate([3, 18, 0]) cube([1, 1, 6.522246562873691]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

translate([12, 18, 0]) cube([1, 1, 6.600000048883411]);

translate([13, 18, 0]) cube([1, 1, 6.8]);

translate([14, 18, 0]) cube([1, 1, 6.9]);

translate([15, 18, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

translate([19, 18, 0]) cube([1, 1, 5.460164693483821]);

translate([20, 18, 0]) cube([1, 1, 5.298002894493968]);

translate([21, 18, 0]) cube([1, 1, 5.2980038100265565]);

translate([22, 18, 0]) cube([1, 1, 5.307339823575838]);

color([0,1,0])
translate([23, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 6.807326839589431]);

translate([1, 19, 0]) cube([1, 1, 6.636127993689662]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

translate([7, 19, 0]) cube([1, 1, 5.403361650159673]);

translate([8, 19, 0]) cube([1, 1, 5.402373950159694]);

color([0,1,0])
translate([9, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

translate([13, 19, 0]) cube([1, 1, 6.9]);

translate([14, 19, 0]) cube([1, 1, 7.1]);

translate([15, 19, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([16, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);

translate([20, 19, 0]) cube([1, 1, 5.414283522198068]);

translate([21, 19, 0]) cube([1, 1, 5.299957157571279]);

translate([22, 19, 0]) cube([1, 1, 5.305889043901459]);

color([0,1,0])
translate([23, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 19, 0]) cube([1, 1, 6]);

translate([0, 20, 0]) cube([1, 1, 7.0]);

translate([1, 20, 0]) cube([1, 1, 6.801465367917885]);

color([0,1,0])
translate([2, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

translate([6, 20, 0]) cube([1, 1, 5.403350510429748]);

translate([7, 20, 0]) cube([1, 1, 5.2252177284341546]);

translate([8, 20, 0]) cube([1, 1, 5.402074218299987]);

color([0,1,0])
translate([9, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

translate([13, 20, 0]) cube([1, 1, 6.8]);

translate([14, 20, 0]) cube([1, 1, 7.0]);

translate([15, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

translate([21, 20, 0]) cube([1, 1, 5.306740812975094]);

translate([22, 20, 0]) cube([1, 1, 5.305462169173605]);

translate([23, 20, 0]) cube([1, 1, 5.400010925698342]);

color([0,1,0])
translate([24, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 20, 0]) cube([1, 1, 6]);

translate([31, 20, 0]) cube([1, 1, 5.303057599657119]);

translate([0, 21, 0]) cube([1, 1, 7.1]);

translate([1, 21, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

translate([4, 21, 0]) cube([1, 1, 5.416317554878632]);

translate([5, 21, 0]) cube([1, 1, 5.310297958173121]);

translate([6, 21, 0]) cube([1, 1, 5.307210479132808]);

translate([7, 21, 0]) cube([1, 1, 5.401771484496218]);

color([0,1,0])
translate([8, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

translate([13, 21, 0]) cube([1, 1, 6.7]);

translate([14, 21, 0]) cube([1, 1, 6.9]);

translate([15, 21, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

translate([22, 21, 0]) cube([1, 1, 5.30574967551425]);

translate([23, 21, 0]) cube([1, 1, 5.30547571491833]);

translate([24, 21, 0]) cube([1, 1, 5.302890896943534]);

translate([25, 21, 0]) cube([1, 1, 5.302891330267214]);

color([0,1,0])
translate([26, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 21, 0]) cube([1, 1, 6]);

translate([30, 21, 0]) cube([1, 1, 5.400224403898009]);

translate([31, 21, 0]) cube([1, 1, 5.101853797937091]);

translate([0, 22, 0]) cube([1, 1, 7.1]);

translate([1, 22, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

translate([4, 22, 0]) cube([1, 1, 5.240962808069578]);

translate([5, 22, 0]) cube([1, 1, 5.2416814637779305]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

translate([13, 22, 0]) cube([1, 1, 6.7]);

translate([14, 22, 0]) cube([1, 1, 6.8]);

translate([15, 22, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

translate([24, 22, 0]) cube([1, 1, 5.400017967853117]);

translate([25, 22, 0]) cube([1, 1, 5.4000286152950085]);

color([0,1,0])
translate([26, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 22, 0]) cube([1, 1, 6]);

translate([30, 22, 0]) cube([1, 1, 5.20010749153308]);

translate([31, 22, 0]) cube([1, 1, 4.901107413655697]);

translate([0, 23, 0]) cube([1, 1, 6.9]);

translate([1, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 23, 0]) cube([1, 1, 6]);

translate([4, 23, 0]) cube([1, 1, 5.401636406581566]);

color([0,1,0])
translate([5, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 23, 0]) cube([1, 1, 6]);

translate([12, 23, 0]) cube([1, 1, 6.7]);

translate([13, 23, 0]) cube([1, 1, 6.9]);

translate([14, 23, 0]) cube([1, 1, 7.0]);

translate([15, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([16, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 23, 0]) cube([1, 1, 6]);

translate([29, 23, 0]) cube([1, 1, 5.300015463942861]);

translate([30, 23, 0]) cube([1, 1, 5.000029133943217]);

translate([31, 23, 0]) cube([1, 1, 4.800414679710664]);

translate([0, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 24, 0]) cube([1, 1, 6]);

translate([11, 24, 0]) cube([1, 1, 6.7]);

translate([12, 24, 0]) cube([1, 1, 7.0]);

translate([13, 24, 0]) cube([1, 1, 7.1]);

translate([14, 24, 0]) cube([1, 1, 7.1]);

translate([15, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 24, 0]) cube([1, 1, 6]);

translate([27, 24, 0]) cube([1, 1, 5.400008681516732]);

translate([28, 24, 0]) cube([1, 1, 5.300013591196272]);

translate([29, 24, 0]) cube([1, 1, 5.000021766778341]);

translate([30, 24, 0]) cube([1, 1, 4.800123150653216]);

translate([31, 24, 0]) cube([1, 1, 4.600303439432115]);

color([0,1,0])
translate([0, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 25, 0]) cube([1, 1, 6]);

translate([11, 25, 0]) cube([1, 1, 6.9]);

translate([12, 25, 0]) cube([1, 1, 7.2]);

translate([13, 25, 0]) cube([1, 1, 7.2]);

translate([14, 25, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([15, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 25, 0]) cube([1, 1, 6]);

translate([25, 25, 0]) cube([1, 1, 5.400005816999172]);

translate([26, 25, 0]) cube([1, 1, 5.40000572779029]);

translate([27, 25, 0]) cube([1, 1, 5.400004707386078]);

translate([28, 25, 0]) cube([1, 1, 5.200009464083141]);

translate([29, 25, 0]) cube([1, 1, 5.000011558552024]);

translate([30, 25, 0]) cube([1, 1, 4.700039914918202]);

translate([31, 25, 0]) cube([1, 1, 4.500490884860199]);

color([0,1,0])
translate([0, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 26, 0]) cube([1, 1, 6]);

translate([10, 26, 0]) cube([1, 1, 6.7]);

translate([11, 26, 0]) cube([1, 1, 6.9]);

translate([12, 26, 0]) cube([1, 1, 7.0]);

translate([13, 26, 0]) cube([1, 1, 6.9]);

translate([14, 26, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([15, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 26, 0]) cube([1, 1, 6]);

translate([25, 26, 0]) cube([1, 1, 5.400006104130776]);

translate([26, 26, 0]) cube([1, 1, 5.400005972358937]);

color([0,1,0])
translate([27, 26, 0]) cube([1, 1, 6]);

translate([28, 26, 0]) cube([1, 1, 5.400001176846518]);

translate([29, 26, 0]) cube([1, 1, 5.300000235303827]);

translate([30, 26, 0]) cube([1, 1, 5.0000029483854025]);

translate([31, 26, 0]) cube([1, 1, 4.700021431471266]);

color([0,1,0])
translate([0, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 27, 0]) cube([1, 1, 6]);

translate([9, 27, 0]) cube([1, 1, 6.6]);

translate([10, 27, 0]) cube([1, 1, 6.7]);

translate([11, 27, 0]) cube([1, 1, 6.7]);

translate([12, 27, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([13, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 27, 0]) cube([1, 1, 6]);

translate([31, 27, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([0, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 28, 0]) cube([1, 1, 6]);

translate([27, 28, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 29, 0]) cube([1, 1, 6]);

translate([26, 29, 0]) cube([1, 1, 5.4]);

translate([27, 29, 0]) cube([1, 1, 5.3]);

translate([28, 29, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([29, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 30, 0]) cube([1, 1, 6]);

translate([1, 30, 0]) cube([1, 1, 5.44898148384317]);

translate([2, 30, 0]) cube([1, 1, 5.439425933762691]);

translate([3, 30, 0]) cube([1, 1, 5.412329647166274]);

translate([4, 30, 0]) cube([1, 1, 5.316666155022057]);

translate([5, 30, 0]) cube([1, 1, 5.2105706768833455]);

translate([6, 30, 0]) cube([1, 1, 5.102642706448123]);

translate([7, 30, 0]) cube([1, 1, 5.3000000148684]);

translate([8, 30, 0]) cube([1, 1, 5.400000002786194]);

color([0,1,0])
translate([9, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 30, 0]) cube([1, 1, 6]);

translate([11, 30, 0]) cube([1, 1, 5.3]);

translate([12, 30, 0]) cube([1, 1, 5.2134185763888885]);

translate([13, 30, 0]) cube([1, 1, 5.353674305555557]);

translate([14, 30, 0]) cube([1, 1, 5.457740740740743]);

color([0,1,0])
translate([15, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 30, 0]) cube([1, 1, 6]);

translate([22, 30, 0]) cube([1, 1, 5.3]);

translate([23, 30, 0]) cube([1, 1, 5.3]);

translate([24, 30, 0]) cube([1, 1, 5.4]);

translate([25, 30, 0]) cube([1, 1, 5.4]);

translate([26, 30, 0]) cube([1, 1, 5.3]);

translate([27, 30, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([28, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 30, 0]) cube([1, 1, 6]);

translate([0, 31, 0]) cube([1, 1, 4.596969140612548]);

translate([1, 31, 0]) cube([1, 1, 5.3993765466669785]);

translate([2, 31, 0]) cube([1, 1, 5.366642453641001]);

translate([3, 31, 0]) cube([1, 1, 5.3543348386838145]);

translate([4, 31, 0]) cube([1, 1, 5.2288571272042965]);

translate([5, 31, 0]) cube([1, 1, 5.029368332646082]);

translate([6, 31, 0]) cube([1, 1, 4.9439030954523036]);

translate([7, 31, 0]) cube([1, 1, 5.001321364606348]);

translate([8, 31, 0]) cube([1, 1, 5.100000005375636]);

translate([9, 31, 0]) cube([1, 1, 5.100000003235109]);

translate([10, 31, 0]) cube([1, 1, 5.0]);

translate([11, 31, 0]) cube([1, 1, 4.881775139853396]);

translate([12, 31, 0]) cube([1, 1, 4.884285382908951]);

translate([13, 31, 0]) cube([1, 1, 4.985549064429013]);

translate([14, 31, 0]) cube([1, 1, 5.34626450617284]);

translate([15, 31, 0]) cube([1, 1, 4.405463580246913]);

translate([16, 31, 0]) cube([1, 1, 5.418055555555556]);

color([0,1,0])
translate([17, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 31, 0]) cube([1, 1, 6]);

translate([22, 31, 0]) cube([1, 1, 5.2]);

translate([23, 31, 0]) cube([1, 1, 5.1]);

translate([24, 31, 0]) cube([1, 1, 5.2]);

translate([25, 31, 0]) cube([1, 1, 5.2]);

translate([26, 31, 0]) cube([1, 1, 5.3]);

translate([27, 31, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 31, 0]) cube([1, 1, 6]);
