
hull() {
    translate([0.05, 0.0, 4.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9500000000000001, 0.0, 4.8100000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.05, 0.0, 4.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9500000000000002, 0.0, 4.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.05, 0.0, 4.4799999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.95, 0.0, 4.12]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0500000000000003, 0.0, 4.075]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.95, 0.0, 3.625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.05, 0.0, 3.5650000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.95, 0.0, 2.935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.05, 0.0, 2.86]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.95, 0.0, 2.14]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.050000000000001, 0.0, 2.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.95, 0.0, 1.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.05, 0.0, 1.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.95, 0.0, 0.34500000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.05, 0.0, 0.28500000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.95, 0.0, 0.015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.049999999999999, 0.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.95, 0.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}

