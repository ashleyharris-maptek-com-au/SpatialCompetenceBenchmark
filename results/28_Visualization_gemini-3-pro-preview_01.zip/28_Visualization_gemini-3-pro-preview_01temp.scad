translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.2]);

translate([2, 0, 0]) cube([1, 1, 4.030660498514058]);

translate([3, 0, 0]) cube([1, 1, 4.033834421509036]);

translate([4, 0, 0]) cube([1, 1, 4.2799999999999985]);

translate([5, 0, 0]) cube([1, 1, 4.51]);

translate([6, 0, 0]) cube([1, 1, 4.359999999999997]);

translate([7, 0, 0]) cube([1, 1, 4.005301146749295]);

translate([8, 0, 0]) cube([1, 1, 4.266550388742698]);

translate([9, 0, 0]) cube([1, 1, 4.277766790998393]);

translate([10, 0, 0]) cube([1, 1, 4.296246880466466]);

translate([11, 0, 0]) cube([1, 1, 3.8485000356366106]);

translate([12, 0, 0]) cube([1, 1, 3.87496378036736]);

translate([13, 0, 0]) cube([1, 1, 3.4860179958070034]);

translate([14, 0, 0]) cube([1, 1, 4.42]);

translate([15, 0, 0]) cube([1, 1, 4.7]);

color([0, 1, 0]) translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.4]);

translate([2, 1, 0]) cube([1, 1, 4.8]);

translate([3, 1, 0]) cube([1, 1, 4.4]);

translate([4, 1, 0]) cube([1, 1, 4.329999999999999]);

translate([5, 1, 0]) cube([1, 1, 4.318042254345132]);

translate([6, 1, 0]) cube([1, 1, 4.352975668669891]);

translate([7, 1, 0]) cube([1, 1, 4.36999999999999]);

translate([8, 1, 0]) cube([1, 1, 4.010753031698781]);

translate([9, 1, 0]) cube([1, 1, 4.6299999999999955]);

translate([10, 1, 0]) cube([1, 1, 4.6299999999999955]);

translate([11, 1, 0]) cube([1, 1, 3.8494302901385407]);

translate([12, 1, 0]) cube([1, 1, 4.149999999999997]);

translate([13, 1, 0]) cube([1, 1, 3.9599999999999924]);

translate([14, 1, 0]) cube([1, 1, 3.9699980778074018]);

translate([15, 1, 0]) cube([1, 1, 3.9628091184796763]);

translate([0, 2, 0]) cube([1, 1, 7.2]);

color([0, 1, 0]) translate([1, 2, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.4]);

translate([4, 2, 0]) cube([1, 1, 5.0]);

translate([5, 2, 0]) cube([1, 1, 4.42]);

translate([6, 2, 0]) cube([1, 1, 4.629999999999999]);

translate([7, 2, 0]) cube([1, 1, 4.819999999999999]);

translate([8, 2, 0]) cube([1, 1, 4.013942005224791]);

translate([9, 2, 0]) cube([1, 1, 4.5799999999999965]);

translate([10, 2, 0]) cube([1, 1, 4.219999999999995]);

translate([11, 2, 0]) cube([1, 1, 4.059999999999991]);

translate([12, 2, 0]) cube([1, 1, 4.03090127280824]);

translate([13, 2, 0]) cube([1, 1, 3.986182702467849]);

translate([14, 2, 0]) cube([1, 1, 3.9799736548506406]);

translate([15, 2, 0]) cube([1, 1, 3.9759033701211455]);

translate([0, 3, 0]) cube([1, 1, 7.7]);

translate([1, 3, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([2, 3, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 3, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.1]);

color([0, 1, 0]) translate([6, 3, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 3, 0]) cube([1, 1, 6]);

translate([8, 3, 0]) cube([1, 1, 4.019999999999998]);

translate([9, 3, 0]) cube([1, 1, 4.062380833278197]);

translate([10, 3, 0]) cube([1, 1, 4.061156589115235]);

translate([11, 3, 0]) cube([1, 1, 4.041189510438278]);

translate([12, 3, 0]) cube([1, 1, 4.021614396492349]);

translate([13, 3, 0]) cube([1, 1, 3.9899999999999958]);

translate([14, 3, 0]) cube([1, 1, 3.975844176141013]);

translate([15, 3, 0]) cube([1, 1, 3.9770610701867053]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.3]);

translate([2, 4, 0]) cube([1, 1, 6.8]);

color([0, 1, 0]) translate([3, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 4, 0]) cube([1, 1, 6]);

translate([8, 4, 0]) cube([1, 1, 5.4]);

translate([9, 4, 0]) cube([1, 1, 4.7299999999999995]);

translate([10, 4, 0]) cube([1, 1, 4.189999999999998]);

translate([11, 4, 0]) cube([1, 1, 4.249999999999999]);

translate([12, 4, 0]) cube([1, 1, 4.6]);

translate([13, 4, 0]) cube([1, 1, 4.6]);

translate([14, 4, 0]) cube([1, 1, 4.6]);

translate([15, 4, 0]) cube([1, 1, 4.5]);

translate([0, 5, 0]) cube([1, 1, 8.0]);

translate([1, 5, 0]) cube([1, 1, 7.1]);

translate([2, 5, 0]) cube([1, 1, 6.6]);

translate([3, 5, 0]) cube([1, 1, 6.8]);

translate([4, 5, 0]) cube([1, 1, 6.7]);

color([0, 1, 0]) translate([5, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 5, 0]) cube([1, 1, 6]);

translate([9, 5, 0]) cube([1, 1, 4.91]);

translate([10, 5, 0]) cube([1, 1, 4.7299999999999995]);

translate([11, 5, 0]) cube([1, 1, 5.1]);

color([0, 1, 0]) translate([12, 5, 0]) cube([1, 1, 6]);

translate([13, 5, 0]) cube([1, 1, 5.4]);

translate([14, 5, 0]) cube([1, 1, 5.1]);

translate([15, 5, 0]) cube([1, 1, 5.3]);

translate([0, 6, 0]) cube([1, 1, 8.2]);

translate([1, 6, 0]) cube([1, 1, 7.3]);

translate([2, 6, 0]) cube([1, 1, 7.3]);

translate([3, 6, 0]) cube([1, 1, 7.5]);

translate([4, 6, 0]) cube([1, 1, 6.9]);

translate([5, 6, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([6, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.1]);

translate([10, 6, 0]) cube([1, 1, 4.9]);

translate([11, 6, 0]) cube([1, 1, 5.3]);

color([0, 1, 0]) translate([12, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 6, 0]) cube([1, 1, 6]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.7]);

translate([2, 7, 0]) cube([1, 1, 7.6]);

translate([3, 7, 0]) cube([1, 1, 7.4]);

translate([4, 7, 0]) cube([1, 1, 7.0]);

translate([5, 7, 0]) cube([1, 1, 7.0]);

translate([6, 7, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([7, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 7, 0]) cube([1, 1, 6]);

translate([14, 7, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([15, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 7.7]);

translate([1, 8, 0]) cube([1, 1, 7.3]);

translate([2, 8, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([3, 8, 0]) cube([1, 1, 6]);

translate([4, 8, 0]) cube([1, 1, 6.6]);

translate([5, 8, 0]) cube([1, 1, 6.8]);

color([0, 1, 0]) translate([6, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 8, 0]) cube([1, 1, 6]);

translate([14, 8, 0]) cube([1, 1, 6.7]);

color([0, 1, 0]) translate([15, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 6.8]);

translate([1, 9, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([2, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 9, 0]) cube([1, 1, 6]);

translate([6, 9, 0]) cube([1, 1, 6.6]);

translate([7, 9, 0]) cube([1, 1, 6.9]);

color([0, 1, 0]) translate([8, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 9, 0]) cube([1, 1, 6]);

translate([10, 9, 0]) cube([1, 1, 5.2]);

translate([11, 9, 0]) cube([1, 1, 5.3]);

color([0, 1, 0]) translate([12, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([1, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 10, 0]) cube([1, 1, 6]);

translate([3, 10, 0]) cube([1, 1, 5.4]);

translate([4, 10, 0]) cube([1, 1, 5.4]);

color([0, 1, 0]) translate([5, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 10, 0]) cube([1, 1, 6]);

translate([7, 10, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([8, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 10, 0]) cube([1, 1, 6]);

translate([11, 10, 0]) cube([1, 1, 5.3]);

color([0, 1, 0]) translate([12, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 7.1]);

color([0, 1, 0]) translate([1, 11, 0]) cube([1, 1, 6]);

translate([2, 11, 0]) cube([1, 1, 5.2]);

color([0, 1, 0]) translate([3, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.8]);

color([0, 1, 0]) translate([8, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 11, 0]) cube([1, 1, 6]);

translate([12, 11, 0]) cube([1, 1, 5.4]);

color([0, 1, 0]) translate([13, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 11, 0]) cube([1, 1, 6]);

translate([15, 11, 0]) cube([1, 1, 5.2]);

translate([0, 12, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([1, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 12, 0]) cube([1, 1, 6]);

translate([6, 12, 0]) cube([1, 1, 7.0]);

translate([7, 12, 0]) cube([1, 1, 7.1]);

color([0, 1, 0]) translate([8, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 12, 0]) cube([1, 1, 6]);

translate([14, 12, 0]) cube([1, 1, 5.3]);

translate([15, 12, 0]) cube([1, 1, 4.8]);

color([0, 1, 0]) translate([0, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([1, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 13, 0]) cube([1, 1, 6]);

translate([5, 13, 0]) cube([1, 1, 6.7]);

translate([6, 13, 0]) cube([1, 1, 7.0]);

translate([7, 13, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([8, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 13, 0]) cube([1, 1, 6]);

translate([13, 13, 0]) cube([1, 1, 5.4]);

translate([14, 13, 0]) cube([1, 1, 5.4]);

translate([15, 13, 0]) cube([1, 1, 5.0]);

color([0, 1, 0]) translate([0, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([1, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([0, 15, 0]) cube([1, 1, 6]);

translate([1, 15, 0]) cube([1, 1, 5.4]);

translate([2, 15, 0]) cube([1, 1, 5.3]);

translate([3, 15, 0]) cube([1, 1, 5.1]);

translate([4, 15, 0]) cube([1, 1, 5.4]);

color([0, 1, 0]) translate([5, 15, 0]) cube([1, 1, 6]);

translate([6, 15, 0]) cube([1, 1, 5.2]);

translate([7, 15, 0]) cube([1, 1, 5.4]);

color([0, 1, 0]) translate([8, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 15, 0]) cube([1, 1, 6]);

translate([11, 15, 0]) cube([1, 1, 5.3]);

translate([12, 15, 0]) cube([1, 1, 5.4]);

translate([13, 15, 0]) cube([1, 1, 5.3]);

color([0, 1, 0]) translate([14, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 15, 0]) cube([1, 1, 6]);
