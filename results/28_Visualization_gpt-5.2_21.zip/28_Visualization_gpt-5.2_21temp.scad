
translate([0, 0, 0]) cube([1, 1, 5.000000131620571]);

translate([1, 0, 0]) cube([1, 1, 4.30000370890631]);

translate([2, 0, 0]) cube([1, 1, 4.200024602818686]);

translate([3, 0, 0]) cube([1, 1, 4.000245541872786]);

translate([4, 0, 0]) cube([1, 1, 3.9046800887070097]);

translate([5, 0, 0]) cube([1, 1, 4.002794401410086]);

translate([6, 0, 0]) cube([1, 1, 4.2014963931729294]);

translate([7, 0, 0]) cube([1, 1, 4.5]);

translate([8, 0, 0]) cube([1, 1, 4.4]);

translate([9, 0, 0]) cube([1, 1, 4.2]);

translate([10, 0, 0]) cube([1, 1, 4.3]);

translate([11, 0, 0]) cube([1, 1, 4.7]);

translate([12, 0, 0]) cube([1, 1, 5.0]);

translate([13, 0, 0]) cube([1, 1, 5.2]);

translate([14, 0, 0]) cube([1, 1, 5.4]);

translate([15, 0, 0]) cube([1, 1, 5.4]);

translate([16, 0, 0]) cube([1, 1, 5.1]);

translate([17, 0, 0]) cube([1, 1, 4.7]);

translate([18, 0, 0]) cube([1, 1, 4.4]);

translate([19, 0, 0]) cube([1, 1, 4.3]);

translate([20, 0, 0]) cube([1, 1, 4.3]);

translate([21, 0, 0]) cube([1, 1, 4.4]);

translate([22, 0, 0]) cube([1, 1, 4.6]);

translate([23, 0, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.2000002647900105]);

translate([2, 1, 0]) cube([1, 1, 4.700007024432363]);

translate([3, 1, 0]) cube([1, 1, 4.400038215251966]);

translate([4, 1, 0]) cube([1, 1, 4.100421246299266]);

translate([5, 1, 0]) cube([1, 1, 4.101180684793106]);

translate([6, 1, 0]) cube([1, 1, 4.202490482760867]);

translate([7, 1, 0]) cube([1, 1, 4.202473653844962]);

translate([8, 1, 0]) cube([1, 1, 4.007501300546599]);

translate([9, 1, 0]) cube([1, 1, 3.889972320230279]);

translate([10, 1, 0]) cube([1, 1, 3.920689288193019]);

translate([11, 1, 0]) cube([1, 1, 4.110811373942671]);

translate([12, 1, 0]) cube([1, 1, 4.400473612606942]);

translate([13, 1, 0]) cube([1, 1, 4.5]);

translate([14, 1, 0]) cube([1, 1, 4.7]);

translate([15, 1, 0]) cube([1, 1, 4.7]);

translate([16, 1, 0]) cube([1, 1, 4.5]);

translate([17, 1, 0]) cube([1, 1, 4.3]);

translate([18, 1, 0]) cube([1, 1, 4.1]);

translate([19, 1, 0]) cube([1, 1, 3.9]);

translate([20, 1, 0]) cube([1, 1, 3.6050014800533523]);

translate([21, 1, 0]) cube([1, 1, 3.7]);

translate([22, 1, 0]) cube([1, 1, 4.0]);

translate([23, 1, 0]) cube([1, 1, 4.1]);

translate([0, 2, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.200033532677613]);

translate([4, 2, 0]) cube([1, 1, 4.800149199462465]);

translate([5, 2, 0]) cube([1, 1, 4.8002836789248855]);

translate([6, 2, 0]) cube([1, 1, 4.600302666801045]);

translate([7, 2, 0]) cube([1, 1, 4.209246897042691]);

translate([8, 2, 0]) cube([1, 1, 3.9450280870011083]);

translate([9, 2, 0]) cube([1, 1, 4.011375472355268]);

translate([10, 2, 0]) cube([1, 1, 4.205378173516835]);

translate([11, 2, 0]) cube([1, 1, 4.11381356005133]);

translate([12, 2, 0]) cube([1, 1, 4.207017658815821]);

translate([13, 2, 0]) cube([1, 1, 4.401894456341002]);

translate([14, 2, 0]) cube([1, 1, 4.301296882523733]);

translate([15, 2, 0]) cube([1, 1, 4.3002593746748365]);

translate([16, 2, 0]) cube([1, 1, 4.100051873294707]);

translate([17, 2, 0]) cube([1, 1, 3.8025145515212477]);

translate([18, 2, 0]) cube([1, 1, 3.7064288343614407]);

translate([19, 2, 0]) cube([1, 1, 3.6150044514815227]);

translate([20, 2, 0]) cube([1, 1, 3.4834757400136382]);

translate([21, 2, 0]) cube([1, 1, 3.4834757425023444]);

translate([22, 2, 0]) cube([1, 1, 3.7]);

translate([23, 2, 0]) cube([1, 1, 3.7]);

translate([0, 3, 0]) cube([1, 1, 7.2]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

translate([4, 3, 0]) cube([1, 1, 5.400159706899798]);

translate([5, 3, 0]) cube([1, 1, 5.4001232978103895]);

translate([6, 3, 0]) cube([1, 1, 5.001409026588858]);

translate([7, 3, 0]) cube([1, 1, 4.516670930056109]);

translate([8, 3, 0]) cube([1, 1, 4.427850661611748]);

translate([9, 3, 0]) cube([1, 1, 4.6149372622688505]);

translate([10, 3, 0]) cube([1, 1, 4.808119154060822]);

translate([11, 3, 0]) cube([1, 1, 4.709212627652345]);

translate([12, 3, 0]) cube([1, 1, 4.706179207606124]);

translate([13, 3, 0]) cube([1, 1, 4.603293079083317]);

translate([14, 3, 0]) cube([1, 1, 4.207576044892817]);

translate([15, 3, 0]) cube([1, 1, 4.005104761429001]);

translate([16, 3, 0]) cube([1, 1, 3.810006339525701]);

translate([17, 3, 0]) cube([1, 1, 3.626268923320572]);

translate([18, 3, 0]) cube([1, 1, 3.6028166620428954]);

translate([19, 3, 0]) cube([1, 1, 3.58132442963603]);

translate([20, 3, 0]) cube([1, 1, 3.483477887503832]);

translate([21, 3, 0]) cube([1, 1, 3.4834760643322253]);

translate([22, 3, 0]) cube([1, 1, 3.510064787444274]);

translate([23, 3, 0]) cube([1, 1, 3.601287685937692]);

translate([0, 4, 0]) cube([1, 1, 7.5]);

translate([1, 4, 0]) cube([1, 1, 6.9]);

translate([2, 4, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.307678033440402]);

translate([7, 4, 0]) cube([1, 1, 4.927630854019208]);

translate([8, 4, 0]) cube([1, 1, 4.929663144826985]);

translate([9, 4, 0]) cube([1, 1, 5.222500456222412]);

color([0,1,0])
translate([10, 4, 0]) cube([1, 1, 6]);

translate([11, 4, 0]) cube([1, 1, 5.411810909797796]);

translate([12, 4, 0]) cube([1, 1, 5.208022747187723]);

translate([13, 4, 0]) cube([1, 1, 4.805556525845003]);

translate([14, 4, 0]) cube([1, 1, 4.211234874983932]);

translate([15, 4, 0]) cube([1, 1, 3.844615693296279]);

translate([16, 4, 0]) cube([1, 1, 3.7684120305542197]);

translate([17, 4, 0]) cube([1, 1, 3.646538360834535]);

translate([18, 4, 0]) cube([1, 1, 3.602830121659183]);

translate([19, 4, 0]) cube([1, 1, 3.5303074633273055]);

translate([20, 4, 0]) cube([1, 1, 3.570105725509668]);

translate([21, 4, 0]) cube([1, 1, 3.5256989890604933]);

translate([22, 4, 0]) cube([1, 1, 3.6019568169930776]);

translate([23, 4, 0]) cube([1, 1, 3.7012508824979586]);

translate([0, 5, 0]) cube([1, 1, 7.9]);

translate([1, 5, 0]) cube([1, 1, 7.4]);

translate([2, 5, 0]) cube([1, 1, 7.1]);

translate([3, 5, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

translate([7, 5, 0]) cube([1, 1, 5.4267050191958415]);

translate([8, 5, 0]) cube([1, 1, 5.434692633406193]);

color([0,1,0])
translate([9, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 5, 0]) cube([1, 1, 6]);

translate([12, 5, 0]) cube([1, 1, 5.413310303981263]);

translate([13, 5, 0]) cube([1, 1, 4.814802478525975]);

translate([14, 5, 0]) cube([1, 1, 4.23171524253922]);

translate([15, 5, 0]) cube([1, 1, 3.8991175677464227]);

translate([16, 5, 0]) cube([1, 1, 3.842472737518639]);

translate([17, 5, 0]) cube([1, 1, 3.8325274133738554]);

translate([18, 5, 0]) cube([1, 1, 3.541204250888581]);

translate([19, 5, 0]) cube([1, 1, 4.005105471073384]);

translate([20, 5, 0]) cube([1, 1, 4.2036918121486195]);

translate([21, 5, 0]) cube([1, 1, 4.202897344800866]);

translate([22, 5, 0]) cube([1, 1, 4.102556966447178]);

translate([23, 5, 0]) cube([1, 1, 3.9024465647163917]);

translate([0, 6, 0]) cube([1, 1, 7.9]);

translate([1, 6, 0]) cube([1, 1, 7.4]);

translate([2, 6, 0]) cube([1, 1, 7.1]);

translate([3, 6, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([4, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 6, 0]) cube([1, 1, 6]);

translate([12, 6, 0]) cube([1, 1, 5.426228218030083]);

translate([13, 6, 0]) cube([1, 1, 4.923654762310595]);

translate([14, 6, 0]) cube([1, 1, 4.551894726993764]);

translate([15, 6, 0]) cube([1, 1, 4.2341432424071295]);

translate([16, 6, 0]) cube([1, 1, 4.222625046201114]);

translate([17, 6, 0]) cube([1, 1, 3.8481662734733924]);

translate([18, 6, 0]) cube([1, 1, 4.607214540594509]);

translate([19, 6, 0]) cube([1, 1, 4.6093739732871795]);

translate([20, 6, 0]) cube([1, 1, 4.705247030602783]);

translate([21, 6, 0]) cube([1, 1, 4.605104760251301]);

translate([22, 6, 0]) cube([1, 1, 4.502868230587999]);

translate([23, 6, 0]) cube([1, 1, 4.401914497113996]);

translate([0, 7, 0]) cube([1, 1, 7.9]);

translate([1, 7, 0]) cube([1, 1, 7.3]);

translate([2, 7, 0]) cube([1, 1, 6.9]);

translate([3, 7, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([4, 7, 0]) cube([1, 1, 6]);

translate([5, 7, 0]) cube([1, 1, 6.7]);

translate([6, 7, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

translate([13, 7, 0]) cube([1, 1, 5.042812316519533]);

translate([14, 7, 0]) cube([1, 1, 4.853546270762593]);

translate([15, 7, 0]) cube([1, 1, 4.672763084259005]);

translate([16, 7, 0]) cube([1, 1, 4.2672957540070255]);

translate([17, 7, 0]) cube([1, 1, 5.108423317172324]);

translate([18, 7, 0]) cube([1, 1, 5.310451059937518]);

translate([19, 7, 0]) cube([1, 1, 5.213875076792758]);

translate([20, 7, 0]) cube([1, 1, 5.111245976483128]);

translate([21, 7, 0]) cube([1, 1, 4.906361130340807]);

translate([22, 7, 0]) cube([1, 1, 4.902669665585864]);

translate([23, 7, 0]) cube([1, 1, 5.100205596762029]);

translate([0, 8, 0]) cube([1, 1, 8.1]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 6.9]);

translate([3, 8, 0]) cube([1, 1, 6.8]);

translate([4, 8, 0]) cube([1, 1, 7.0]);

translate([5, 8, 0]) cube([1, 1, 7.1]);

translate([6, 8, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

translate([13, 8, 0]) cube([1, 1, 5.084574858914081]);

translate([14, 8, 0]) cube([1, 1, 4.973832277733455]);

translate([15, 8, 0]) cube([1, 1, 4.628235196867311]);

translate([16, 8, 0]) cube([1, 1, 4.952057102874373]);

color([0,1,0])
translate([17, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 8.2]);

translate([1, 9, 0]) cube([1, 1, 7.6]);

translate([2, 9, 0]) cube([1, 1, 7.2]);

translate([3, 9, 0]) cube([1, 1, 7.3]);

translate([4, 9, 0]) cube([1, 1, 7.5]);

translate([5, 9, 0]) cube([1, 1, 7.4]);

translate([6, 9, 0]) cube([1, 1, 6.9]);

translate([7, 9, 0]) cube([1, 1, 6.6]);

translate([8, 9, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

translate([13, 9, 0]) cube([1, 1, 5.2869179115015275]);

translate([14, 9, 0]) cube([1, 1, 4.869716131979242]);

translate([15, 9, 0]) cube([1, 1, 4.9788247578658105]);

translate([16, 9, 0]) cube([1, 1, 5.155730772274722]);

color([0,1,0])
translate([17, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 8.1]);

translate([1, 10, 0]) cube([1, 1, 7.7]);

translate([2, 10, 0]) cube([1, 1, 7.5]);

translate([3, 10, 0]) cube([1, 1, 7.6]);

translate([4, 10, 0]) cube([1, 1, 7.6]);

translate([5, 10, 0]) cube([1, 1, 7.4]);

translate([6, 10, 0]) cube([1, 1, 7.0]);

translate([7, 10, 0]) cube([1, 1, 6.9]);

translate([8, 10, 0]) cube([1, 1, 6.9]);

translate([9, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

translate([13, 10, 0]) cube([1, 1, 5.309234589307035]);

translate([14, 10, 0]) cube([1, 1, 5.445396000825761]);

translate([15, 10, 0]) cube([1, 1, 5.340651873126894]);

translate([16, 10, 0]) cube([1, 1, 5.448376692524273]);

color([0,1,0])
translate([17, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

translate([20, 10, 0]) cube([1, 1, 6.6]);

translate([21, 10, 0]) cube([1, 1, 6.8]);

translate([22, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 8.1]);

translate([1, 11, 0]) cube([1, 1, 7.8]);

translate([2, 11, 0]) cube([1, 1, 7.6]);

translate([3, 11, 0]) cube([1, 1, 7.4]);

translate([4, 11, 0]) cube([1, 1, 7.2]);

translate([5, 11, 0]) cube([1, 1, 7.0]);

translate([6, 11, 0]) cube([1, 1, 7.0]);

translate([7, 11, 0]) cube([1, 1, 7.0]);

translate([8, 11, 0]) cube([1, 1, 6.8]);

translate([9, 11, 0]) cube([1, 1, 6.512552002957818]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

translate([11, 11, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

translate([20, 11, 0]) cube([1, 1, 6.7]);

translate([21, 11, 0]) cube([1, 1, 7.0]);

translate([22, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 7.7]);

translate([1, 12, 0]) cube([1, 1, 7.4]);

translate([2, 12, 0]) cube([1, 1, 7.2]);

translate([3, 12, 0]) cube([1, 1, 7.0]);

translate([4, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([5, 12, 0]) cube([1, 1, 6]);

translate([6, 12, 0]) cube([1, 1, 6.6]);

translate([7, 12, 0]) cube([1, 1, 6.8]);

translate([8, 12, 0]) cube([1, 1, 6.702083333333333]);

translate([9, 12, 0]) cube([1, 1, 6.538124678497944]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

translate([17, 12, 0]) cube([1, 1, 5.364224031937624]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 12, 0]) cube([1, 1, 6]);

translate([21, 12, 0]) cube([1, 1, 6.7]);

translate([22, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 7.0]);

translate([1, 13, 0]) cube([1, 1, 6.8]);

translate([2, 13, 0]) cube([1, 1, 6.8]);

translate([3, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

translate([8, 13, 0]) cube([1, 1, 6.53278504372428]);

translate([9, 13, 0]) cube([1, 1, 6.629427083333333]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

translate([11, 13, 0]) cube([1, 1, 6.714236111111111]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

translate([15, 13, 0]) cube([1, 1, 5.486457588218416]);

translate([16, 13, 0]) cube([1, 1, 5.364933228765327]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

translate([11, 14, 0]) cube([1, 1, 7.001388888888889]);

translate([12, 14, 0]) cube([1, 1, 6.505579194568453]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

translate([15, 14, 0]) cube([1, 1, 5.41595873965158]);

translate([16, 14, 0]) cube([1, 1, 5.490015124958294]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 7.0]);

translate([1, 15, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

translate([11, 15, 0]) cube([1, 1, 6.917850167410714]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

translate([17, 15, 0]) cube([1, 1, 5.4997826105021295]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

translate([23, 15, 0]) cube([1, 1, 5.400175506243852]);

translate([0, 16, 0]) cube([1, 1, 7.2]);

translate([1, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 16, 0]) cube([1, 1, 6]);

translate([10, 16, 0]) cube([1, 1, 6.823939827348173]);

translate([11, 16, 0]) cube([1, 1, 6.734269649493397]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

translate([18, 16, 0]) cube([1, 1, 5.462815193126049]);

translate([19, 16, 0]) cube([1, 1, 5.4628153419056]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

translate([23, 16, 0]) cube([1, 1, 5.100231255584488]);

translate([0, 17, 0]) cube([1, 1, 7.0]);

translate([1, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

translate([9, 17, 0]) cube([1, 1, 6.611384296859333]);

translate([10, 17, 0]) cube([1, 1, 6.905247813411079]);

translate([11, 17, 0]) cube([1, 1, 6.807400594402538]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 17, 0]) cube([1, 1, 6]);

translate([22, 17, 0]) cube([1, 1, 5.300080954959667]);

translate([23, 17, 0]) cube([1, 1, 4.9002097130834095]);

translate([0, 18, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

translate([5, 18, 0]) cube([1, 1, 5.491550810276098]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

translate([8, 18, 0]) cube([1, 1, 6.606496398973423]);

translate([9, 18, 0]) cube([1, 1, 7.01999362244898]);

translate([10, 18, 0]) cube([1, 1, 7.102455357142857]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([20, 18, 0]) cube([1, 1, 5.400406548747008]);

translate([21, 18, 0]) cube([1, 1, 5.300245248314806]);

translate([22, 18, 0]) cube([1, 1, 4.900242247804926]);

translate([23, 18, 0]) cube([1, 1, 4.700330081256625]);

color([0,1,0])
translate([0, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

translate([4, 19, 0]) cube([1, 1, 5.435676650905677]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 19, 0]) cube([1, 1, 6]);

translate([8, 19, 0]) cube([1, 1, 6.806388939504373]);

translate([9, 19, 0]) cube([1, 1, 7.2]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

translate([11, 19, 0]) cube([1, 1, 6.5520288584183675]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

translate([19, 19, 0]) cube([1, 1, 5.400602357541611]);

translate([20, 19, 0]) cube([1, 1, 5.400408234420973]);

translate([21, 19, 0]) cube([1, 1, 5.300260292984809]);

translate([22, 19, 0]) cube([1, 1, 5.00012724805101]);

translate([23, 19, 0]) cube([1, 1, 4.60070079988122]);

color([0,1,0])
translate([0, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 20, 0]) cube([1, 1, 6]);

translate([3, 20, 0]) cube([1, 1, 5.361031306076462]);

color([0,1,0])
translate([4, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 20, 0]) cube([1, 1, 6]);

translate([7, 20, 0]) cube([1, 1, 6.601463311727751]);

translate([8, 20, 0]) cube([1, 1, 6.8038542425898925]);

translate([9, 20, 0]) cube([1, 1, 6.820344387755102]);

translate([10, 20, 0]) cube([1, 1, 6.534528194090136]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 20, 0]) cube([1, 1, 6]);

translate([23, 20, 0]) cube([1, 1, 5.100000304479983]);

color([0,1,0])
translate([0, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 21, 0]) cube([1, 1, 6]);

translate([2, 21, 0]) cube([1, 1, 5.266522198689894]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 21, 0]) cube([1, 1, 6]);

translate([7, 21, 0]) cube([1, 1, 6.501478457206295]);

translate([8, 21, 0]) cube([1, 1, 6.504421750630525]);

color([0,1,0])
translate([9, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

translate([20, 21, 0]) cube([1, 1, 5.400026477816487]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 22, 0]) cube([1, 1, 6]);

translate([1, 22, 0]) cube([1, 1, 4.956851187507598]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

translate([4, 22, 0]) cube([1, 1, 5.386438958443586]);

color([0,1,0])
translate([5, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

translate([17, 22, 0]) cube([1, 1, 5.400001007906568]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

translate([19, 22, 0]) cube([1, 1, 5.400010952089792]);

translate([20, 22, 0]) cube([1, 1, 5.3000274656413255]);

translate([21, 22, 0]) cube([1, 1, 5.400009617886678]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 23, 0]) cube([1, 1, 6]);

translate([3, 23, 0]) cube([1, 1, 5.399149648096568]);

translate([4, 23, 0]) cube([1, 1, 5.246917483712328]);

translate([5, 23, 0]) cube([1, 1, 5.237657388917161]);

translate([6, 23, 0]) cube([1, 1, 5.226879122539948]);

translate([7, 23, 0]) cube([1, 1, 5.2185635488726145]);

translate([8, 23, 0]) cube([1, 1, 5.019491553648957]);

translate([9, 23, 0]) cube([1, 1, 4.909668638226931]);

translate([10, 23, 0]) cube([1, 1, 5.045340230795981]);

translate([11, 23, 0]) cube([1, 1, 5.429639877719988]);

color([0,1,0])
translate([12, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 23, 0]) cube([1, 1, 6]);

translate([16, 23, 0]) cube([1, 1, 5.400000500676974]);

translate([17, 23, 0]) cube([1, 1, 5.200024351224834]);

translate([18, 23, 0]) cube([1, 1, 5.200024373443309]);

translate([19, 23, 0]) cube([1, 1, 5.300027196907596]);

translate([20, 23, 0]) cube([1, 1, 5.3000273742859365]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);
