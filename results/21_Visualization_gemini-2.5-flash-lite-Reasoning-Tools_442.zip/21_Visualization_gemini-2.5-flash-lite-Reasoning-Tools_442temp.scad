
hull() {
    translate([25.0095, 25.0095, 47.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.180500000000002, 25.180500000000002, 47.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.199500000000004, 25.199500000000004, 46.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.3705, 25.3705, 46.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.389499999999998, 25.389499999999998, 45.949999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.5605, 25.5605, 45.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.579500000000003, 25.579500000000003, 44.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.750500000000002, 25.750500000000002, 44.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.7695, 25.7695, 43.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.9405, 25.9405, 43.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.959500000000002, 25.959500000000002, 42.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.1305, 26.1305, 42.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.1495, 26.1495, 41.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.3205, 26.3205, 41.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.3395, 26.3395, 40.949999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.5105, 26.5105, 40.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.5295, 26.5295, 39.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.7005, 26.7005, 39.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.719500000000004, 26.719500000000004, 38.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.890500000000003, 26.890500000000003, 38.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.9095, 26.9095, 37.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.0805, 27.0805, 37.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.0995, 27.0995, 36.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.270500000000006, 27.270500000000006, 36.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.289500000000004, 27.289500000000004, 35.949999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.4605, 27.4605, 35.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.479499999999998, 27.479499999999998, 34.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.6505, 27.6505, 34.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.669500000000003, 27.669500000000003, 33.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.840500000000002, 27.840500000000002, 33.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.8595, 27.8595, 32.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.0305, 28.0305, 32.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.049500000000002, 28.049500000000002, 31.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.2205, 28.2205, 31.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.2395, 28.2395, 30.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.410500000000003, 28.410500000000003, 30.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.429500000000004, 28.429500000000004, 29.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.6005, 28.6005, 29.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.6195, 28.6195, 28.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.7905, 28.7905, 28.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.8095, 28.8095, 27.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.9805, 28.9805, 27.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.999499999999998, 28.999499999999998, 26.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.1705, 29.1705, 26.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.189500000000002, 29.189500000000002, 25.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.360500000000002, 29.360500000000002, 25.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.3795, 29.3795, 24.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.5505, 29.5505, 24.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.569499999999998, 29.569499999999998, 23.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.740500000000004, 29.740500000000004, 23.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.759500000000003, 29.759500000000003, 22.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.930500000000002, 29.930500000000002, 22.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.9495, 29.9495, 21.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.1205, 30.1205, 21.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.1395, 30.1395, 20.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.3105, 30.3105, 20.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.3295, 30.3295, 19.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.500500000000002, 30.500500000000002, 19.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.519500000000004, 30.519500000000004, 18.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.6905, 30.6905, 18.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.7095, 30.7095, 17.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.8805, 30.8805, 17.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.899500000000003, 30.899500000000003, 16.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.0705, 31.0705, 16.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.089499999999997, 31.089499999999997, 15.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.2605, 31.2605, 15.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.279500000000002, 31.279500000000002, 14.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.4505, 31.4505, 14.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.4695, 31.4695, 13.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.6405, 31.6405, 13.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.6595, 31.6595, 12.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.8305, 31.8305, 12.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.8495, 31.8495, 11.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.0205, 32.0205, 11.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.039500000000004, 32.039500000000004, 10.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.2105, 32.2105, 10.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.2295, 32.2295, 9.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.400499999999994, 32.400499999999994, 9.049999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.4195, 32.4195, 8.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.590500000000006, 32.590500000000006, 8.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.620000000000005, 32.620000000000005, 8.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.98, 32.98, 8.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.0175, 33.0175, 8.012]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.3325, 33.3325, 8.228]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.3675, 33.3675, 8.252]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.682500000000005, 33.682500000000005, 8.468]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.7175, 33.7175, 8.492]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.0325, 34.0325, 8.708]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.067499999999995, 34.067499999999995, 8.732000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.3825, 34.3825, 8.948000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.417500000000004, 34.417500000000004, 8.972000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.7325, 34.7325, 9.187999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.7675, 34.7675, 9.212]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.0825, 35.0825, 9.428]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.11750000000001, 35.11750000000001, 9.452]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.432500000000005, 35.432500000000005, 9.668]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.4675, 35.4675, 9.692]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.7825, 35.7825, 9.908000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.817499999999995, 35.817499999999995, 9.932]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.13249999999999, 36.13249999999999, 10.148]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.1675, 36.1675, 10.172]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.4825, 36.4825, 10.388000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.5175, 36.5175, 10.412]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.832499999999996, 36.832499999999996, 10.628]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.8675, 36.8675, 10.652000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.182500000000005, 37.182500000000005, 10.868000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.2175, 37.2175, 10.892000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.5325, 37.5325, 11.107999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.5675, 37.5675, 11.132]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.8825, 37.8825, 11.348]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.9175, 37.9175, 11.372]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.2325, 38.2325, 11.588]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.267500000000005, 38.267500000000005, 11.612]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.5825, 38.5825, 11.828000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.6175, 38.6175, 11.852]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.932500000000005, 38.932500000000005, 12.068]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.96750000000001, 38.96750000000001, 12.092]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.2825, 39.2825, 12.308000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.317499999999995, 39.317499999999995, 12.332]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.6325, 39.6325, 12.548]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.667500000000004, 39.667500000000004, 12.572000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.9825, 39.9825, 12.788000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.0175, 40.0175, 12.812000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.3325, 40.3325, 13.027999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.36750000000001, 40.36750000000001, 13.052]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.682500000000005, 40.682500000000005, 13.268]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.7175, 40.7175, 13.292]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.0325, 41.0325, 13.508]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.0675, 41.0675, 13.532]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.3825, 41.3825, 13.748000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.4175, 41.4175, 13.772]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.7325, 41.7325, 13.988]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.767500000000005, 41.767500000000005, 14.012]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.0825, 42.0825, 14.228000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.1175, 42.1175, 14.252]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.432500000000005, 42.432500000000005, 14.468]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.46750000000001, 42.46750000000001, 14.492]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.7825, 42.7825, 14.708000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.817499999999995, 42.817499999999995, 14.732000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.1325, 43.1325, 14.948]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.167500000000004, 43.167500000000004, 14.972000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.4825, 43.4825, 15.187999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.5175, 43.5175, 15.212]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.8325, 43.8325, 15.427999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.86750000000001, 43.86750000000001, 15.451999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.182500000000005, 44.182500000000005, 15.668]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.2175, 44.2175, 15.692]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.5325, 44.5325, 15.908]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.567499999999995, 44.567499999999995, 15.931999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.88249999999999, 44.88249999999999, 16.148]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.904999999999994, 44.904999999999994, 15.952]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.995, 44.995, 12.208]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.015, 44.9865, 12.0065]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.285, 44.7435, 12.123500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.315, 44.716499999999996, 12.136500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.585, 44.4735, 12.2535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.615, 44.4465, 12.2665]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.885000000000005, 44.2035, 12.383500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.915, 44.176500000000004, 12.396500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.185, 43.93350000000001, 12.5135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.215, 43.90650000000001, 12.5265]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.485, 43.6635, 12.6435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.515, 43.6365, 12.6565]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.785, 43.3935, 12.773499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.815, 43.3665, 12.786499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.085, 43.1235, 12.9035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.115, 43.0965, 12.9165]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.385, 42.853500000000004, 13.033499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.415, 42.8265, 13.046499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.68500000000001, 42.5835, 13.163499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.715, 42.5565, 13.1765]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.985, 42.3135, 13.293500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.0, 42.27, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.0, 41.730000000000004, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.0, 41.67, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.0, 41.13, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.0, 41.07, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.0, 40.53, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.0, 40.475, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.0, 40.025, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.985, 39.9935, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.715, 39.87649999999999, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.68500000000001, 39.863499999999995, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.415, 39.746500000000005, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.385, 39.73350000000001, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.115, 39.6165, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.085, 39.603500000000004, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.815, 39.4865, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.785, 39.473499999999994, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.515, 39.3565, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.485, 39.3435, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.215, 39.2265, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.185, 39.2135, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.915, 39.096500000000006, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.885000000000005, 39.08350000000001, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.615, 38.9665, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.585, 38.9535, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.315, 38.8365, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.285, 38.8235, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.015, 38.706500000000005, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.985, 38.69350000000001, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.715, 38.5765, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.685, 38.5635, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.415, 38.44649999999999, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.385, 38.433499999999995, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.115, 38.316500000000005, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.08500000000001, 38.30350000000001, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.815000000000005, 38.1865, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.785000000000004, 38.173500000000004, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.515, 38.0565, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.485, 38.043499999999995, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.215, 37.9265, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.185, 37.9135, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.915, 37.7965, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.885, 37.783500000000004, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.615, 37.6665, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.585, 37.6535, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.315, 37.536500000000004, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.285, 37.5235, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.015, 37.406499999999994, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.98500000000001, 37.393499999999996, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.715, 37.276500000000006, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.685, 37.26350000000001, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.415, 37.1465, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.385, 37.133500000000005, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.115, 37.0165, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.085, 37.003499999999995, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.815, 36.8865, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.785, 36.8735, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.515, 36.7565, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.485, 36.743500000000004, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.215, 36.6265, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.190000000000005, 36.614, 13.3]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.01, 36.506, 13.3]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.984, 36.4685, 13.243]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.696000000000005, 35.9015, 12.217]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.664, 35.8385, 12.103000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.376, 35.2715, 11.077]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.344, 35.2085, 10.963]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.056000000000004, 34.6415, 9.937000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.024, 34.5785, 9.823]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.736, 34.0115, 8.797]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.704, 33.948499999999996, 8.683]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.416000000000004, 33.3815, 7.657]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.384, 33.3185, 7.543]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.096, 32.7515, 6.517]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.064, 32.6885, 6.4030000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.776, 32.121500000000005, 5.377000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.744, 32.0585, 5.263]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.455999999999996, 31.491500000000002, 4.237]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.424, 31.4285, 4.123]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.136, 30.8615, 3.0970000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.104, 30.7985, 2.983]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.815999999999995, 30.2315, 1.9569999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.784, 30.1685, 1.843]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.496, 29.6015, 0.8170000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.156, 29.8415, 1.222]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.323999999999998, 34.7285, 9.538]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.987000000000002, 34.9855, 9.986]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.753, 34.7245, 9.734000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.726999999999997, 34.6955, 9.706000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.493000000000002, 34.4345, 9.454]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.467, 34.4055, 9.426]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.232999999999997, 34.1445, 9.174]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.206999999999997, 34.115500000000004, 9.145999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.973, 33.8545, 8.894]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.947, 33.825500000000005, 8.866000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.712999999999997, 33.564499999999995, 8.614]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.686999999999998, 33.5355, 8.586]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.453, 33.274499999999996, 8.334]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.427, 33.2455, 8.306000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.193, 32.9845, 8.054]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.167, 32.9555, 8.026]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.933000000000003, 32.6945, 7.774]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.907000000000004, 32.6655, 7.746]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.673000000000002, 32.4045, 7.494]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.647000000000002, 32.3755, 7.466]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.413, 32.1145, 7.214]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.387, 32.0855, 7.186000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.153000000000002, 31.824499999999997, 6.934]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.127000000000002, 31.795499999999997, 6.906]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.893, 31.534499999999998, 6.654]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.867, 31.505499999999998, 6.626]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.633000000000003, 31.2445, 6.3740000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.607000000000003, 31.2155, 6.346]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.373, 30.9545, 6.094]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.347, 30.9255, 6.066000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.113000000000003, 30.6645, 5.814]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.087000000000003, 30.6355, 5.786]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.853, 30.3745, 5.534]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.827, 30.3455, 5.506]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.593, 30.084500000000002, 5.2540000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.567, 30.055500000000002, 5.226]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.333, 29.794500000000003, 4.974]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.307000000000002, 29.765500000000003, 4.946000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.073, 29.5045, 4.694]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.046999999999997, 29.4755, 4.6659999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.813000000000002, 29.2145, 4.414000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.787, 29.1855, 4.386]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.552999999999997, 28.924500000000002, 4.134]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.526999999999997, 28.895500000000002, 4.106]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.293, 28.634500000000003, 3.854]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.267, 28.605500000000003, 3.826]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.032999999999998, 28.3445, 3.5740000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.006999999999998, 28.3155, 3.5460000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.773, 28.0545, 3.294]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.747, 28.0255, 3.266]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.513, 27.7645, 3.0140000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.487000000000002, 27.735500000000002, 2.986]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.253, 27.474500000000003, 2.7340000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.227, 27.445500000000003, 2.7060000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.993000000000002, 27.184500000000003, 2.454]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.967000000000002, 27.155500000000004, 2.426]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.733, 26.8945, 2.1740000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.707, 26.8655, 2.1460000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.473000000000003, 26.6045, 1.894]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.447000000000003, 26.5755, 1.8659999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.213, 26.314500000000002, 1.614]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.187, 26.285500000000003, 1.586]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.953000000000003, 26.024500000000003, 1.334]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.927000000000003, 25.995500000000003, 1.3060000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.693, 25.7345, 1.054]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.667, 25.7055, 1.026]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.433000000000003, 25.4445, 0.774]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.407000000000004, 25.4155, 0.746]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.173000000000002, 25.154500000000002, 0.494]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.147000000000002, 25.125500000000002, 0.46599999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.913, 24.864500000000003, 0.21400000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.604999999999997, 24.8575, 0.3400000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.295, 24.9925, 2.8600000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.9885, 24.996000000000002, 2.9955000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.7815, 24.924, 2.9145000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.7585, 24.916, 2.9055000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5515, 24.844, 2.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.528500000000001, 24.836000000000002, 2.8154999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.321500000000002, 24.764000000000003, 2.7344999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.2985, 24.756000000000004, 2.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.0915, 24.684, 2.6445000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.0685, 24.676000000000002, 2.6355000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.8615, 24.604, 2.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.8385, 24.596, 2.5455]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.631499999999999, 24.524, 2.4645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.6085, 24.516000000000002, 2.4555]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.4015, 24.444000000000003, 2.3745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.3785, 24.436000000000003, 2.3655]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.171500000000002, 24.364, 2.2845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.148500000000002, 24.356, 2.2755]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.941500000000001, 24.284, 2.1945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.9185, 24.276, 2.1855]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.7115, 24.204, 2.1045000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.6885, 24.196, 2.0955]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.4815, 24.124000000000002, 2.0145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.4585, 24.116000000000003, 2.0055]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.2515, 24.044, 1.9245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.2285, 24.036, 1.9155]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.0215, 23.964, 1.8345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.9985, 23.956, 1.8255000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.791500000000001, 23.884, 1.7445000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.7685, 23.876, 1.7355]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.5615, 23.804000000000002, 1.6544999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.5385, 23.796000000000003, 1.6455]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.3315, 23.724, 1.5645000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.3085, 23.715999999999998, 1.5555]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.1015, 23.644, 1.4745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.0785, 23.636, 1.4655]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.8715, 23.564, 1.3845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.8485, 23.556, 1.3755]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.6415, 23.484, 1.2945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.618500000000001, 23.476000000000003, 1.2855]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.411500000000002, 23.404, 1.2045000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.3885, 23.395999999999997, 1.1955]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.1815, 23.323999999999998, 1.1145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.1585, 23.316, 1.1055000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.9515, 23.244, 1.0245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.9285, 23.236, 1.0155]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7215, 23.164, 0.9345000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.698500000000001, 23.156000000000002, 0.9255000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.4915, 23.084, 0.8445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.4685, 23.075999999999997, 0.8355]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.261500000000002, 23.003999999999998, 0.7545000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.238500000000002, 22.996, 0.7455]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.031500000000001, 22.924000000000003, 0.6645000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0085, 22.916000000000004, 0.6555000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.801499999999999, 22.844, 0.5745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.7785, 22.836000000000002, 0.5655]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.5715, 22.764000000000003, 0.4845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.5485, 22.756, 0.4755]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.3415, 22.683999999999997, 0.3945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.3185, 22.676, 0.3855]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.1115, 22.604000000000003, 0.3045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.0885, 22.596000000000004, 0.29550000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.8815, 22.524, 0.2145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.8585, 22.516000000000002, 0.2055]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.6514999999999995, 22.444000000000003, 0.1245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.6285, 22.436, 0.11549999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.421500000000001, 22.363999999999997, 0.0345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.3985, 22.355999999999998, 0.0255]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.1915, 22.284000000000002, -0.0555]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.1785, 22.279500000000002, -0.057]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.1515, 22.2705, -0.003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.1485, 22.2695, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.1215, 22.260500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.118500000000001, 22.259500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.0915, 22.250500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.0885, 22.2495, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.0615000000000006, 22.240499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.0585, 22.2395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.0315, 22.230500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.0285, 22.2295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.0015, 22.2205, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.9985, 22.2195, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.9715, 22.2105, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.9685, 22.209500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.9415000000000004, 22.2005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.9385, 22.1995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.9115, 22.1905, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.9085, 22.1895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.8815, 22.1805, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.878500000000001, 22.1795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.8515, 22.170500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.8485, 22.169500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.8215, 22.1605, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.818500000000001, 22.159499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.7915, 22.150499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.7885, 22.1495, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.7615, 22.140500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.7585, 22.1395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.7315000000000005, 22.130499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.7285, 22.129499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.7015, 22.1205, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.6985, 22.119500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.6715, 22.110500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.6685, 22.1095, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.6415, 22.1005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.6385000000000005, 22.0995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.611500000000001, 22.0905, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.608500000000001, 22.0895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.581500000000001, 22.0805, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.578500000000001, 22.0795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.5515, 22.0705, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.5485, 22.069499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.5215, 22.060499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.5184999999999995, 22.0595, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.4915, 22.050500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.4885, 22.049500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.4615, 22.040499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.4585, 22.039499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.4315, 22.030500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.4285, 22.029500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.4015, 22.020500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.3985, 22.0195, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.371500000000001, 22.0105, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.368500000000001, 22.009500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.341500000000001, 22.000500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.338500000000001, 21.9995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.3115, 21.9905, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.3084999999999996, 21.9895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.2815, 21.9805, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.2785, 21.9795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.2515, 21.9705, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.2485, 21.9695, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.2215, 21.960500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.2185, 21.959500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.1915000000000004, 21.950499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.188500000000001, 21.9495, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.1615, 21.940500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.1585, 21.939500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.131500000000001, 21.930500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.128500000000001, 21.9295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.101500000000001, 21.9205, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.0985000000000005, 21.919500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.0715, 21.910500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.0685, 21.9095, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.0415, 21.9005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.0385, 21.8995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.0115, 21.8905, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.0085, 21.8895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.9815000000000005, 21.8805, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.9785, 21.8795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.9515, 21.8705, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.9485, 21.8695, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.9215, 21.8605, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.9185, 21.8595, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.8915, 21.850500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.8885000000000005, 21.849500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.8615, 21.8405, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.8585, 21.839499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.8315, 21.830499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.8285, 21.8295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.8015, 21.820500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.7985, 21.8195, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.7715, 21.810499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.7684999999999995, 21.809499999999996, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.7415, 21.8005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.7385, 21.799500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.7115, 21.7905, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.7085, 21.7895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.6815, 21.7805, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.6785, 21.7795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.6515, 21.7705, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.648500000000001, 21.7695, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.6215, 21.760500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.6185, 21.759500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.5915, 21.7505, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.5885, 21.749499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.5615, 21.740499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.5584999999999996, 21.7395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.5315, 21.730500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.5285, 21.7295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.5015, 21.720499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.4985, 21.719499999999996, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.4715, 21.710500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.4685, 21.709500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.4415000000000004, 21.7005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.438500000000001, 21.6995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.411500000000001, 21.6905, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.408500000000001, 21.689500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.3815, 21.680500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.3785, 21.6795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.3515, 21.670500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.3485, 21.669500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.3215, 21.6605, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.3185, 21.6595, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2915, 21.6505, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2885, 21.6495, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2615, 21.640500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2585, 21.6395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2315000000000005, 21.630499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2285, 21.6295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2015, 21.620500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.198500000000001, 21.619500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.171500000000001, 21.610500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.168500000000001, 21.6095, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.1415, 21.6005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.1385, 21.599500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.1115, 21.590500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.1085, 21.5895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0815, 21.5805, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0785, 21.5795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0515, 21.5705, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0485, 21.5695, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0215, 21.5605, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0184999999999995, 21.5595, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.9915, 21.5505, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.9885, 21.5495, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.9615, 21.540499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.958500000000001, 21.5395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.931500000000001, 21.530500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.9285000000000005, 21.529500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.9015, 21.5205, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.8985, 21.519499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.8715, 21.5105, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.8685, 21.509500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.8415, 21.500500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.8385, 21.4995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.8115, 21.490499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.8084999999999996, 21.489499999999996, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.7815, 21.4805, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.7785, 21.4795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.7515, 21.4705, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.7485, 21.4695, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.7215, 21.4605, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.718500000000001, 21.4595, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.6915000000000004, 21.450499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.6885, 21.4495, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.6615, 21.440500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.6585, 21.439500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.6315, 21.4305, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.6285, 21.429499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.6015, 21.420500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.5985, 21.419500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.5715, 21.410500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.5685, 21.4095, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.5415, 21.400499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.5385, 21.399499999999996, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.5115, 21.390500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.5085, 21.3895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.4815000000000005, 21.3805, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.478500000000001, 21.3795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.4515, 21.3705, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.4485, 21.369500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.4215, 21.360500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.4185, 21.3595, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.3915, 21.350500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.3885, 21.349500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.3615, 21.3405, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.3585, 21.3395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.3315, 21.3305, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.3285, 21.3295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.3015, 21.320500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.2985, 21.3195, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.2715, 21.310499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.2684999999999995, 21.3095, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.2415, 21.300500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.2385, 21.299500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.2115, 21.2905, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.2085, 21.2895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.1815, 21.2805, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.1785, 21.279500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.1515, 21.270500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.1485, 21.2695, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.1215, 21.2605, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.1185, 21.2595, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.0915, 21.2505, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.0885, 21.2495, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.0615, 21.2405, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.0584999999999996, 21.2395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.0315, 21.2305, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.0285, 21.229499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.0015, 21.220499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.9985, 21.2195, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.9715000000000007, 21.210500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.9685000000000006, 21.209500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.9415, 21.200499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.9385, 21.199499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.9115, 21.1905, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.9085, 21.189500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.8815, 21.180500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.8785, 21.1795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.8515000000000006, 21.1705, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.8485000000000005, 21.1695, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.8215, 21.1605, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.8185, 21.1595, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.7915, 21.1505, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.7885, 21.1495, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.7615, 21.1405, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.7584999999999997, 21.139499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.7315000000000005, 21.130499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.7285000000000004, 21.1295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.7015000000000002, 21.120500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6985, 21.119500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6715, 21.1105, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6685, 21.109499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6415, 21.100500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6385000000000005, 21.099500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6115000000000004, 21.090500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6085000000000003, 21.0895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.5815, 21.080499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.5785, 21.079499999999996, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.5515, 21.070500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.5484999999999998, 21.0695, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.5215, 21.0605, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.5185000000000004, 21.0595, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4915000000000003, 21.0505, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4885000000000006, 21.049500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4615, 21.0405, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4585, 21.0395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4315, 21.030500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4285, 21.029500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4015, 21.0205, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3985000000000003, 21.0195, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.3715, 21.010500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3685000000000005, 21.009500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.3415, 21.000500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3385, 20.9995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.3115, 20.990499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3085, 20.9895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.2815, 20.980500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.2785, 20.9795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.2515, 20.9705, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.2485000000000004, 20.9695, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.2215000000000003, 20.9605, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.2185, 20.959500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.1915, 20.9505, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.1885, 20.9495, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.1615, 20.9405, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.1585, 20.9395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.1315, 20.9305, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.1285000000000003, 20.9295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.1015, 20.920500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0985, 20.919500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.0715, 20.9105, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0685, 20.909499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.0415, 20.900499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0385, 20.8995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.0115, 20.890500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0085, 20.8895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.9815, 20.880499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.9785, 20.879499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.9515000000000002, 20.8705, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.9485, 20.869500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.9215, 20.860500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.9185000000000003, 20.8595, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.8915, 20.8505, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8885, 20.8495, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.8615, 20.8405, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8585, 20.8395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.8315, 20.8305, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8285, 20.8295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.8015, 20.8205, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.7985, 20.819499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.7715, 20.810499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.7685, 20.8095, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.7415000000000003, 20.800500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.7385, 20.799500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.7115, 20.790499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.7085, 20.789499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6815, 20.780500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.6785000000000005, 20.779500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6515, 20.770500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.6485, 20.7695, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6215, 20.7605, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.6185, 20.759500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.5915, 20.750500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.5885, 20.7495, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.5615, 20.7405, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.5585000000000004, 20.7395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.5315, 20.7305, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.5284999999999997, 20.7295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.5015, 20.7205, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.4985, 20.7195, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.4715000000000003, 20.710500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.4685, 20.709500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.4415, 20.700499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.4385000000000003, 20.6995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.4115, 20.690500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.4085, 20.689500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3815, 20.680500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3785, 20.6795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3515, 20.6705, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3485, 20.669500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3215, 20.660500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3185000000000002, 20.6595, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.2915, 20.6505, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.2885, 20.6495, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.2615, 20.6405, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.2584999999999997, 20.6395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.2315, 20.6305, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.2285, 20.6295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.2015000000000002, 20.6205, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1985, 20.6195, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1715, 20.6105, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1685, 20.6095, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1415, 20.600500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1385, 20.599500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1115, 20.5905, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1085, 20.589499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.0815, 20.580499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.0785, 20.5795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.0515, 20.570500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.0484999999999998, 20.5695, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.0215, 20.560499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.0185, 20.559499999999996, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9914999999999998, 20.5505, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.9885, 20.549500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9615, 20.5405, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.9585, 20.5395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9314999999999998, 20.5305, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.9284999999999999, 20.5295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9015, 20.5205, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8984999999999999, 20.5195, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8715000000000002, 20.510500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8685, 20.509500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8415000000000001, 20.5005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8385000000000002, 20.499499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8115, 20.490499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8085, 20.4895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7815, 20.480500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.7785000000000002, 20.4795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7515, 20.470499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.7485, 20.469499999999996, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7215, 20.460500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.7185000000000001, 20.459500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6915, 20.4505, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.6885, 20.4495, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6615, 20.4405, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.6585, 20.439500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6315, 20.430500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.6284999999999998, 20.4295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6015000000000001, 20.420500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5985000000000003, 20.419500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.5715000000000001, 20.4105, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5685, 20.4095, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.5415, 20.4005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5385000000000002, 20.3995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.5115, 20.390500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5085, 20.3895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.4815, 20.380499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.4785000000000001, 20.3795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.4515, 20.370500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.4485, 20.369500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.4215, 20.360500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.4185, 20.3595, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.3915, 20.3505, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.3884999999999998, 20.349500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.3615000000000002, 20.340500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.3585000000000003, 20.3395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.3315000000000001, 20.3305, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.3285, 20.3295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.3015, 20.3205, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.2985000000000002, 20.3195, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.2715, 20.3105, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.2685, 20.3095, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.2415, 20.3005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.2385000000000002, 20.2995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.2115, 20.290499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.2085, 20.2895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.1815, 20.280500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1785, 20.279500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.1515, 20.2705, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1484999999999999, 20.269499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.1215000000000002, 20.2605, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1185000000000003, 20.259500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0915000000000001, 20.250500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0885, 20.2495, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0615, 20.240499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0585, 20.239499999999996, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0315, 20.2305, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0285, 20.2295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0015, 20.2205, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9985, 20.2195, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9715, 20.2105, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9685, 20.2095, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9415, 20.200499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9385, 20.1995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9115000000000001, 20.190500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9085000000000001, 20.189500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.8815000000000001, 20.1805, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.8785000000000001, 20.179499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.8515, 20.170500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.8485, 20.169500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.8215, 20.160500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.8185, 20.1595, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.7915000000000001, 20.150499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.7885000000000001, 20.149499999999996, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.7615000000000001, 20.140500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.7585000000000001, 20.1395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.7315, 20.1305, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.7285, 20.1295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.7015, 20.1205, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.6985, 20.119500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.6715000000000001, 20.110500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.6685000000000001, 20.1095, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.6415000000000001, 20.100500000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.6385000000000001, 20.099500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.6115, 20.0905, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.6085, 20.0895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.5815, 20.0805, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.5785, 20.0795, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.5515000000000001, 20.070500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.5485000000000001, 20.0695, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.5215000000000001, 20.060499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.5185000000000001, 20.0595, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.4915, 20.050500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.4885, 20.049500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.4615, 20.0405, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.4585, 20.0395, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.4315, 20.0305, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.4285, 20.029500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.4015000000000001, 20.020500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.3985000000000001, 20.0195, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.37150000000000005, 20.0105, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.3685, 20.0095, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.3415, 20.0005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.3385, 19.9995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.3115, 19.9905, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.30850000000000005, 19.9895, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.2815000000000001, 19.9805, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.2785000000000001, 19.979499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.2515, 19.970499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.2485, 19.9695, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.2215, 19.960500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.21850000000000003, 19.959500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1915, 19.950499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1885, 19.949499999999997, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1615, 19.9405, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.15850000000000003, 19.939500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1315, 19.930500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1285, 19.9295, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1015, 19.9205, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0985, 19.9195, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.07150000000000001, 19.9105, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.06850000000000002, 19.9095, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.04150000000000001, 19.9005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.038500000000000006, 19.8995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.011500000000000002, 19.8905, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.009500000000000001, 19.889499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0005, 19.880499999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 18.886, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.994, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.25, 1.25, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.75, 23.75, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}

