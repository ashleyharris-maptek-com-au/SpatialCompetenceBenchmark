
hull() {
    translate([25.0, 25.0, 47.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.0, 25.0, 47.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.990000000000002, 25.0, 46.950500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.810000000000002, 25.0, 46.0595]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.79, 25.0, 45.966499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.61, 25.0, 45.1835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.59, 25.0, 45.097500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.41, 25.0, 44.332499999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.39, 25.0, 44.2485]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.21, 25.0, 43.50150000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.19, 25.0, 43.419500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.01, 25.0, 42.6905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.990000000000002, 25.0, 42.610499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.810000000000002, 25.0, 41.899499999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.790000000000003, 25.0, 41.8215]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.610000000000003, 25.0, 41.1285]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.590000000000003, 25.0, 41.0525]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.41, 25.0, 40.377500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.389999999999997, 25.0, 40.30350000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.209999999999997, 25.0, 39.6465]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.189999999999998, 25.0, 39.5745]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.009999999999998, 25.0, 38.9355]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.99, 25.0, 38.8655]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.81, 25.0, 38.2445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.79, 25.0, 38.176500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.610000000000003, 25.0, 37.5735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.590000000000003, 25.0, 37.5075]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.41, 25.0, 36.9225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.39, 25.0, 36.8585]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.21, 25.0, 36.2915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.19, 25.0, 36.2295]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.01, 25.0, 35.6805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.990000000000002, 25.0, 35.6205]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.810000000000002, 25.0, 35.0895]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.790000000000003, 25.0, 35.0315]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.610000000000003, 25.0, 34.5185]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.59, 25.0, 34.462500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.409999999999997, 25.0, 33.9675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.389999999999997, 25.0, 33.9135]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.209999999999997, 25.0, 33.436499999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.189999999999998, 25.0, 33.3845]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.01, 25.0, 32.9255]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.990000000000002, 25.0, 32.8755]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.810000000000002, 25.0, 32.4345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.790000000000003, 25.0, 32.3865]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.610000000000003, 25.0, 31.963500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.590000000000003, 25.0, 31.917500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.41, 25.0, 31.512499999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.39, 25.0, 31.4685]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.21, 25.0, 31.081500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.19, 25.0, 31.0395]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.01, 25.0, 30.6705]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.99, 25.0, 30.6305]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.81, 25.0, 30.279500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.79, 25.0, 30.241500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.61, 25.0, 29.9085]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.59, 25.0, 29.8725]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.41, 25.0, 29.557499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.39, 25.0, 29.5235]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.21, 25.0, 29.2265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.19, 25.0, 29.1945]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.01, 25.0, 28.915499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.990000000000002, 25.0, 28.885499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.810000000000002, 25.0, 28.624499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.790000000000003, 25.0, 28.5965]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.610000000000003, 25.0, 28.3535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.590000000000003, 25.0, 28.3275]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.41, 25.0, 28.1025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.389999999999997, 25.0, 28.0785]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.209999999999997, 25.0, 27.8715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.189999999999998, 25.0, 27.849500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.009999999999998, 25.0, 27.6605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.99, 25.0, 27.6405]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.81, 25.0, 27.469500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.79, 25.0, 27.451500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.610000000000003, 25.0, 27.2985]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.590000000000003, 25.0, 27.2825]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.409999999999997, 25.0, 27.1475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.389999999999997, 25.0, 27.1335]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.21, 25.0, 27.0165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.19, 25.0, 27.0045]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.01, 25.0, 26.9055]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.990000000000002, 25.0, 26.895500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.810000000000002, 25.0, 26.8145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.790000000000003, 25.0, 26.8065]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.610000000000003, 25.0, 26.743499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.59, 25.0, 26.737499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.41, 25.0, 26.692500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.39, 25.0, 26.6885]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.21, 25.0, 26.6615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.19, 25.0, 26.6595]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.01, 25.0, 26.6505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.99, 25.0, 26.6505]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.81, 25.0, 26.6595]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.790000000000001, 25.0, 26.6615]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.61, 25.0, 26.6885]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.59, 25.0, 26.692500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.410000000000002, 25.0, 26.737499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.39, 25.0, 26.743499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.21, 25.0, 26.8065]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.19, 25.0, 26.8145]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.01, 25.0, 26.895500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.99, 25.0, 26.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.81, 25.0, 27.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.790000000000001, 25.0, 27.0165]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.610000000000001, 25.0, 27.1335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.59, 25.0, 27.1475]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.41, 25.0, 27.2825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.39, 25.0, 27.2985]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.209999999999999, 25.0, 27.451500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.19, 25.0, 27.469500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.01, 25.0, 27.6405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.99, 25.0, 27.6605]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.810000000000002, 25.0, 27.849500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.790000000000003, 25.0, 27.8715]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.61, 25.0, 28.0785]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.59, 25.0, 28.1025]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.41, 25.0, 28.3275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.39, 25.0, 28.3535]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.209999999999999, 25.0, 28.5965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.19, 25.0, 28.624499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.010000000000002, 25.0, 28.885499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.990000000000002, 25.0, 28.915499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.810000000000002, 25.0, 29.1945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.790000000000001, 25.0, 29.2265]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.61, 25.0, 29.5235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.59, 25.0, 29.557499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.41, 25.0, 29.8725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.39, 25.0, 29.9085]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.21, 25.0, 30.241500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.190000000000001, 25.0, 30.279500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.010000000000002, 25.0, 30.6305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.99, 25.0, 30.6705]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.81, 25.0, 31.0395]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.790000000000001, 25.0, 31.081500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.61, 25.0, 31.4685]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.59, 25.0, 31.512499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.41, 25.0, 31.917500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.39, 25.0, 31.963500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.21, 25.0, 32.3865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.19, 25.0, 32.4345]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.01, 25.0, 32.8755]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.99, 25.0, 32.9255]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.81, 25.0, 33.3845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.790000000000001, 25.0, 33.436499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.61, 25.0, 33.9135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.59, 25.0, 33.9675]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.410000000000002, 25.0, 34.462500000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.39, 25.0, 34.5185]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.209999999999999, 25.0, 35.0315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.19, 25.0, 35.0895]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.01, 25.0, 35.6205]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.99, 25.0, 35.6805]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.81, 25.0, 36.2295]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.790000000000001, 25.0, 36.2915]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.610000000000001, 25.0, 36.8585]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.59, 25.0, 36.9225]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.41, 25.0, 37.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.39, 25.0, 37.5735]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.209999999999999, 25.0, 38.176500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.19, 25.0, 38.2445]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.01, 25.0, 38.8655]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.99, 25.0, 38.9355]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.81, 25.0, 39.5745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.790000000000001, 25.0, 39.6465]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.61, 25.0, 40.30350000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.59, 25.0, 40.377500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.41, 25.0, 41.0525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.39, 25.0, 41.1285]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.21, 25.0, 41.8215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.19, 25.0, 41.899499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.01, 25.0, 42.610499999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.99, 25.0, 42.6905]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.81, 25.0, 43.419500000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.789999999999999, 25.0, 43.50150000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.609999999999999, 25.0, 44.2485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.59, 25.0, 44.332499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.41, 25.0, 45.097500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.390000000000001, 25.0, 45.1835]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.210000000000001, 25.0, 45.966499999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.19, 25.0, 46.0595]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.01, 25.0, 46.950500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.99, 25.0, 47.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.8100000000000005, 25.0, 47.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.79, 25.0, 48.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.609999999999999, 25.0, 48.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.59, 25.0, 49.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.410000000000001, 25.0, 49.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.390000000000001, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.21, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.19, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.010000000000001, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.99, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.81, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.79, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.61, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.59, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.41, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.390000000000001, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.210000000000001, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.19, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.01, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.99, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.8100000000000005, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.79, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.609999999999999, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.59, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.41, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.390000000000001, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.21, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.19, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.01, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.99, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.81, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.79, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6100000000000003, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.5900000000000003, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.41, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.39, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.2100000000000004, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.1900000000000004, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.0100000000000002, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.99, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.81, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.79, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6100000000000003, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.5900000000000003, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.41, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.39, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.21, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1900000000000004, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.0100000000000002, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.99, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.81, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.79, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6100000000000003, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5900000000000003, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.4100000000000001, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.39, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.21, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1900000000000002, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.01, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.99, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.81, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.79, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.61, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.5900000000000001, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.41000000000000003, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.39000000000000007, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.21000000000000002, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.19000000000000003, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.010000000000000002, 25.0, 50.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 49.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 49.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 48.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 48.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 47.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 47.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 46.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 46.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 45.949999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 45.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 44.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 44.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 43.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 43.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 42.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 42.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 41.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 41.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 40.949999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 40.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 39.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 39.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 38.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 38.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 37.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 37.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 36.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 36.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 35.949999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 35.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 34.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 34.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 33.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 33.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 32.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 32.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 31.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 31.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 30.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 30.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 29.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 29.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 28.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 28.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 27.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 27.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 26.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 26.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 25.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 25.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 24.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 24.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 23.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 23.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 22.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 22.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 21.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 21.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 20.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 20.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 19.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 19.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 18.950000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 18.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 17.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 17.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 16.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 16.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 15.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 15.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 14.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 14.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 13.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 13.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 12.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 12.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 11.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 11.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 10.950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 10.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 9.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 9.049999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 8.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 8.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 7.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 7.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 6.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 6.050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.0, 5.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.0, 5.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.75, 25.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.25, 25.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.5, 25.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.5, 25.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.5, 25.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.5, 25.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.5, 25.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.5, 25.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.2, 25.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.800000000000004, 25.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.050000000000004, 25.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.95, 25.0, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 25.0, 4.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 25.0, 4.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 25.0, 3.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 25.0, 3.0500000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 25.0, 2.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 25.0, 2.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 25.0, 1.9500000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 25.0, 1.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 25.0, 0.9500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 25.0, 0.05]) cube([0.4, 0.4, 0.1], center=true);
}

