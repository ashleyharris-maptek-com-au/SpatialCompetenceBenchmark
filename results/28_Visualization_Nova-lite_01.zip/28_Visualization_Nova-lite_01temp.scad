
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.2]);

translate([2, 0, 0]) cube([1, 1, 4.0]);

translate([3, 0, 0]) cube([1, 1, 3.9800867000603732]);

translate([4, 0, 0]) cube([1, 1, 4.2]);

translate([5, 0, 0]) cube([1, 1, 4.5]);

translate([6, 0, 0]) cube([1, 1, 4.2]);

translate([7, 0, 0]) cube([1, 1, 4.4]);

translate([8, 0, 0]) cube([1, 1, 5.0]);

translate([9, 0, 0]) cube([1, 1, 5.3]);

translate([10, 0, 0]) cube([1, 1, 5.4]);

translate([11, 0, 0]) cube([1, 1, 4.9]);

translate([12, 0, 0]) cube([1, 1, 4.4]);

translate([13, 0, 0]) cube([1, 1, 4.3]);

translate([14, 0, 0]) cube([1, 1, 4.4]);

translate([15, 0, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.4]);

translate([2, 1, 0]) cube([1, 1, 4.8]);

translate([3, 1, 0]) cube([1, 1, 4.4]);

translate([4, 1, 0]) cube([1, 1, 4.3]);

translate([5, 1, 0]) cube([1, 1, 4.01]);

translate([6, 1, 0]) cube([1, 1, 3.895538946943679]);

translate([7, 1, 0]) cube([1, 1, 3.9099999999999997]);

translate([8, 1, 0]) cube([1, 1, 4.22]);

translate([9, 1, 0]) cube([1, 1, 4.42]);

translate([10, 1, 0]) cube([1, 1, 4.42]);

translate([11, 1, 0]) cube([1, 1, 4.21]);

translate([12, 1, 0]) cube([1, 1, 4.01]);

translate([13, 1, 0]) cube([1, 1, 3.6699999999999986]);

translate([14, 1, 0]) cube([1, 1, 3.6199999999999974]);

translate([15, 1, 0]) cube([1, 1, 3.9]);

translate([0, 2, 0]) cube([1, 1, 7.2]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.4399999999999995]);

translate([4, 2, 0]) cube([1, 1, 5.039999999999999]);

translate([5, 2, 0]) cube([1, 1, 4.42]);

translate([6, 2, 0]) cube([1, 1, 4.6]);

translate([7, 2, 0]) cube([1, 1, 4.8]);

translate([8, 2, 0]) cube([1, 1, 4.7]);

translate([9, 2, 0]) cube([1, 1, 4.43]);

translate([10, 2, 0]) cube([1, 1, 4.029999999999999]);

translate([11, 2, 0]) cube([1, 1, 3.689999999999998]);

translate([12, 2, 0]) cube([1, 1, 3.6099999999999954]);

translate([13, 2, 0]) cube([1, 1, 3.5967081236270304]);

translate([14, 2, 0]) cube([1, 1, 3.6349428731264446]);

translate([15, 2, 0]) cube([1, 1, 3.67231532439236]);

translate([0, 3, 0]) cube([1, 1, 7.7]);

translate([1, 3, 0]) cube([1, 1, 7.0]);

translate([2, 3, 0]) cube([1, 1, 6.549999999999999]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.129999999999999]);

color([0,1,0])
translate([6, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 3, 0]) cube([1, 1, 6]);

translate([8, 3, 0]) cube([1, 1, 5.3]);

translate([9, 3, 0]) cube([1, 1, 4.52]);

translate([10, 3, 0]) cube([1, 1, 3.7799999999999985]);

translate([11, 3, 0]) cube([1, 1, 3.6199999999999974]);

translate([12, 3, 0]) cube([1, 1, 3.689999999999998]);

translate([13, 3, 0]) cube([1, 1, 3.829999999999999]);

translate([14, 3, 0]) cube([1, 1, 3.8199999999999994]);

translate([15, 3, 0]) cube([1, 1, 3.8]);

translate([0, 4, 0]) cube([1, 1, 7.91]);

translate([1, 4, 0]) cube([1, 1, 7.31]);

translate([2, 4, 0]) cube([1, 1, 6.839999999999999]);

translate([3, 4, 0]) cube([1, 1, 6.559999999999999]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 4, 0]) cube([1, 1, 6]);

translate([8, 4, 0]) cube([1, 1, 5.4]);

translate([9, 4, 0]) cube([1, 1, 4.72]);

translate([10, 4, 0]) cube([1, 1, 2.4158440461790027]);

translate([11, 4, 0]) cube([1, 1, 4.2299999999999995]);

translate([12, 4, 0]) cube([1, 1, 4.609999999999999]);

translate([13, 4, 0]) cube([1, 1, 4.609999999999999]);

translate([14, 4, 0]) cube([1, 1, 4.6]);

translate([15, 4, 0]) cube([1, 1, 4.5]);

translate([0, 5, 0]) cube([1, 1, 8.02]);

translate([1, 5, 0]) cube([1, 1, 7.139999999999999]);

translate([2, 5, 0]) cube([1, 1, 6.649999999999999]);

translate([3, 5, 0]) cube([1, 1, 6.829999999999999]);

translate([4, 5, 0]) cube([1, 1, 6.72]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 5, 0]) cube([1, 1, 6]);

translate([9, 5, 0]) cube([1, 1, 4.9]);

translate([10, 5, 0]) cube([1, 1, 4.71]);

translate([11, 5, 0]) cube([1, 1, 5.1]);

color([0,1,0])
translate([12, 5, 0]) cube([1, 1, 6]);

translate([13, 5, 0]) cube([1, 1, 5.4]);

translate([14, 5, 0]) cube([1, 1, 5.1]);

translate([15, 5, 0]) cube([1, 1, 5.3]);

translate([0, 6, 0]) cube([1, 1, 8.209999999999999]);

translate([1, 6, 0]) cube([1, 1, 7.349999999999999]);

translate([2, 6, 0]) cube([1, 1, 7.339999999999999]);

translate([3, 6, 0]) cube([1, 1, 7.51]);

translate([4, 6, 0]) cube([1, 1, 6.91]);

translate([5, 6, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.1]);

translate([10, 6, 0]) cube([1, 1, 4.9]);

translate([11, 6, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([0, 7, 0]) cube([1, 1, 5.525818157557055]);

translate([1, 7, 0]) cube([1, 1, 7.7299999999999995]);

translate([2, 7, 0]) cube([1, 1, 7.629999999999999]);

translate([3, 7, 0]) cube([1, 1, 7.42]);

translate([4, 7, 0]) cube([1, 1, 7.01]);

translate([5, 7, 0]) cube([1, 1, 7.0]);

translate([6, 7, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

translate([14, 7, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 7.739999999999999]);

translate([1, 8, 0]) cube([1, 1, 7.339999999999999]);

translate([2, 8, 0]) cube([1, 1, 7.049999999999999]);

translate([3, 8, 0]) cube([1, 1, 5.256558403329119]);

translate([4, 8, 0]) cube([1, 1, 6.619999999999999]);

translate([5, 8, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([6, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

translate([14, 8, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 6.839999999999999]);

translate([1, 9, 0]) cube([1, 1, 6.689999999999998]);

color([0,1,0])
translate([2, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 9, 0]) cube([1, 1, 6]);

translate([6, 9, 0]) cube([1, 1, 6.6]);

translate([7, 9, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

translate([10, 9, 0]) cube([1, 1, 5.389001976467527]);

translate([11, 9, 0]) cube([1, 1, 5.387297894138781]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.029999999999999]);

translate([1, 10, 0]) cube([1, 1, 4.0043620295793625]);

color([0,1,0])
translate([2, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 10, 0]) cube([1, 1, 6]);

translate([7, 10, 0]) cube([1, 1, 7.01]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

translate([11, 10, 0]) cube([1, 1, 5.389999999999998]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 7.119999999999999]);

color([0,1,0])
translate([1, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.829999999999999]);

color([0,1,0])
translate([8, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

translate([12, 11, 0]) cube([1, 1, 5.41]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

translate([15, 11, 0]) cube([1, 1, 5.2]);

translate([0, 12, 0]) cube([1, 1, 6.619999999999999]);

color([0,1,0])
translate([1, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 12, 0]) cube([1, 1, 6]);

translate([6, 12, 0]) cube([1, 1, 7.02]);

translate([7, 12, 0]) cube([1, 1, 4.7827233707435655]);

color([0,1,0])
translate([8, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

translate([14, 12, 0]) cube([1, 1, 5.3]);

translate([15, 12, 0]) cube([1, 1, 4.803094322145357]);

color([0,1,0])
translate([0, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

translate([5, 13, 0]) cube([1, 1, 6.72]);

translate([6, 13, 0]) cube([1, 1, 7.029999999999999]);

translate([7, 13, 0]) cube([1, 1, 6.629999999999999]);

color([0,1,0])
translate([8, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

translate([13, 13, 0]) cube([1, 1, 5.4]);

translate([14, 13, 0]) cube([1, 1, 5.4]);

translate([15, 13, 0]) cube([1, 1, 5.0]);

color([0,1,0])
translate([0, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

translate([5, 14, 0]) cube([1, 1, 6.52]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 15, 0]) cube([1, 1, 6]);

translate([1, 15, 0]) cube([1, 1, 5.43]);

translate([2, 15, 0]) cube([1, 1, 5.365827007634499]);

translate([3, 15, 0]) cube([1, 1, 5.365490290798073]);

translate([4, 15, 0]) cube([1, 1, 5.449999999999999]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

translate([6, 15, 0]) cube([1, 1, 5.459985096326422]);

translate([7, 15, 0]) cube([1, 1, 5.469999999999999]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

translate([11, 15, 0]) cube([1, 1, 5.311689636436542]);

translate([12, 15, 0]) cube([1, 1, 5.4]);

translate([13, 15, 0]) cube([1, 1, 5.302252666036148]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);
