
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.6]);

translate([2, 0, 0]) cube([1, 1, 4.3]);

translate([3, 0, 0]) cube([1, 1, 4.2]);

translate([4, 0, 0]) cube([1, 1, 4.2]);

translate([5, 0, 0]) cube([1, 1, 4.1]);

translate([6, 0, 0]) cube([1, 1, 4.0]);

translate([7, 0, 0]) cube([1, 1, 3.9000003657681805]);

translate([8, 0, 0]) cube([1, 1, 3.9000003667619962]);

translate([9, 0, 0]) cube([1, 1, 3.900000370495756]);

translate([10, 0, 0]) cube([1, 1, 4.000000148655274]);

translate([11, 0, 0]) cube([1, 1, 4.100000104660031]);

translate([12, 0, 0]) cube([1, 1, 4.200000049570215]);

translate([13, 0, 0]) cube([1, 1, 4.3]);

translate([14, 0, 0]) cube([1, 1, 4.5]);

translate([15, 0, 0]) cube([1, 1, 4.5]);

translate([16, 0, 0]) cube([1, 1, 4.4]);

translate([17, 0, 0]) cube([1, 1, 4.3]);

translate([18, 0, 0]) cube([1, 1, 4.2]);

translate([19, 0, 0]) cube([1, 1, 4.2]);

translate([20, 0, 0]) cube([1, 1, 4.3]);

translate([21, 0, 0]) cube([1, 1, 4.4]);

translate([22, 0, 0]) cube([1, 1, 4.7]);

translate([23, 0, 0]) cube([1, 1, 4.9]);

translate([24, 0, 0]) cube([1, 1, 5.0]);

translate([25, 0, 0]) cube([1, 1, 5.1]);

translate([26, 0, 0]) cube([1, 1, 5.2]);

translate([27, 0, 0]) cube([1, 1, 5.3]);

translate([28, 0, 0]) cube([1, 1, 5.4]);

translate([29, 0, 0]) cube([1, 1, 5.4]);

translate([30, 0, 0]) cube([1, 1, 5.4]);

translate([31, 0, 0]) cube([1, 1, 5.3]);

translate([32, 0, 0]) cube([1, 1, 5.1]);

translate([33, 0, 0]) cube([1, 1, 4.9]);

translate([34, 0, 0]) cube([1, 1, 4.7]);

translate([35, 0, 0]) cube([1, 1, 4.6]);

translate([36, 0, 0]) cube([1, 1, 4.4]);

translate([37, 0, 0]) cube([1, 1, 4.4]);

translate([38, 0, 0]) cube([1, 1, 4.3]);

translate([39, 0, 0]) cube([1, 1, 4.3]);

translate([40, 0, 0]) cube([1, 1, 4.3]);

translate([41, 0, 0]) cube([1, 1, 4.3]);

translate([42, 0, 0]) cube([1, 1, 4.4]);

translate([43, 0, 0]) cube([1, 1, 4.6]);

translate([44, 0, 0]) cube([1, 1, 4.6]);

translate([45, 0, 0]) cube([1, 1, 4.7]);

translate([46, 0, 0]) cube([1, 1, 4.8]);

translate([47, 0, 0]) cube([1, 1, 4.9]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.0]);

translate([2, 1, 0]) cube([1, 1, 4.7]);

translate([3, 1, 0]) cube([1, 1, 4.5]);

translate([4, 1, 0]) cube([1, 1, 4.4]);

translate([5, 1, 0]) cube([1, 1, 4.3]);

translate([6, 1, 0]) cube([1, 1, 4.1]);

translate([7, 1, 0]) cube([1, 1, 4.000000001082616]);

translate([8, 1, 0]) cube([1, 1, 3.900000367342992]);

translate([9, 1, 0]) cube([1, 1, 3.9000003746930605]);

translate([10, 1, 0]) cube([1, 1, 3.9000005092236747]);

translate([11, 1, 0]) cube([1, 1, 4.000000503055881]);

translate([12, 1, 0]) cube([1, 1, 4.100000386120985]);

translate([13, 1, 0]) cube([1, 1, 4.200000222665172]);

translate([14, 1, 0]) cube([1, 1, 4.3]);

translate([15, 1, 0]) cube([1, 1, 4.3]);

translate([16, 1, 0]) cube([1, 1, 4.2]);

translate([17, 1, 0]) cube([1, 1, 4.000002649336253]);

translate([18, 1, 0]) cube([1, 1, 3.900008633311757]);

translate([19, 1, 0]) cube([1, 1, 3.9000058578812924]);

translate([20, 1, 0]) cube([1, 1, 4.000000023102111]);

translate([21, 1, 0]) cube([1, 1, 4.100000134960966]);

translate([22, 1, 0]) cube([1, 1, 4.4]);

translate([23, 1, 0]) cube([1, 1, 4.5]);

translate([24, 1, 0]) cube([1, 1, 4.7]);

translate([25, 1, 0]) cube([1, 1, 4.8]);

translate([26, 1, 0]) cube([1, 1, 4.9]);

translate([27, 1, 0]) cube([1, 1, 5.0]);

translate([28, 1, 0]) cube([1, 1, 5.0]);

translate([29, 1, 0]) cube([1, 1, 5.1]);

translate([30, 1, 0]) cube([1, 1, 5.0]);

translate([31, 1, 0]) cube([1, 1, 4.9]);

translate([32, 1, 0]) cube([1, 1, 4.8]);

translate([33, 1, 0]) cube([1, 1, 4.6]);

translate([34, 1, 0]) cube([1, 1, 4.5]);

translate([35, 1, 0]) cube([1, 1, 4.4]);

translate([36, 1, 0]) cube([1, 1, 4.3]);

translate([37, 1, 0]) cube([1, 1, 4.2]);

translate([38, 1, 0]) cube([1, 1, 4.1]);

translate([39, 1, 0]) cube([1, 1, 4.0]);

translate([40, 1, 0]) cube([1, 1, 3.9]);

translate([41, 1, 0]) cube([1, 1, 3.9]);

translate([42, 1, 0]) cube([1, 1, 4.0]);

translate([43, 1, 0]) cube([1, 1, 4.1]);

translate([44, 1, 0]) cube([1, 1, 4.2]);

translate([45, 1, 0]) cube([1, 1, 4.3]);

translate([46, 1, 0]) cube([1, 1, 4.4]);

translate([47, 1, 0]) cube([1, 1, 4.5]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

translate([2, 2, 0]) cube([1, 1, 5.2]);

translate([3, 2, 0]) cube([1, 1, 4.9]);

translate([4, 2, 0]) cube([1, 1, 4.7]);

translate([5, 2, 0]) cube([1, 1, 4.6]);

translate([6, 2, 0]) cube([1, 1, 4.4]);

translate([7, 2, 0]) cube([1, 1, 4.2000000021179655]);

translate([8, 2, 0]) cube([1, 1, 4.100000020253281]);

translate([9, 2, 0]) cube([1, 1, 4.00000015103734]);

translate([10, 2, 0]) cube([1, 1, 4.100000227544279]);

translate([11, 2, 0]) cube([1, 1, 4.100000402896015]);

translate([12, 2, 0]) cube([1, 1, 4.200000345679099]);

translate([13, 2, 0]) cube([1, 1, 4.2000003150743614]);

translate([14, 2, 0]) cube([1, 1, 4.200000224980449]);

translate([15, 2, 0]) cube([1, 1, 4.100003821431514]);

translate([16, 2, 0]) cube([1, 1, 4.000010611012841]);

translate([17, 2, 0]) cube([1, 1, 3.9000318978624313]);

translate([18, 2, 0]) cube([1, 1, 3.8001868702014847]);

translate([19, 2, 0]) cube([1, 1, 3.8001868703430874]);

translate([20, 2, 0]) cube([1, 1, 3.9000089570133167]);

translate([21, 2, 0]) cube([1, 1, 3.9000093552328594]);

translate([22, 2, 0]) cube([1, 1, 4.10000056485712]);

translate([23, 2, 0]) cube([1, 1, 4.200000259148185]);

translate([24, 2, 0]) cube([1, 1, 4.4]);

translate([25, 2, 0]) cube([1, 1, 4.400000018525149]);

translate([26, 2, 0]) cube([1, 1, 4.5]);

translate([27, 2, 0]) cube([1, 1, 4.6]);

translate([28, 2, 0]) cube([1, 1, 4.7]);

translate([29, 2, 0]) cube([1, 1, 4.7]);

translate([30, 2, 0]) cube([1, 1, 4.7]);

translate([31, 2, 0]) cube([1, 1, 4.6]);

translate([32, 2, 0]) cube([1, 1, 4.5]);

translate([33, 2, 0]) cube([1, 1, 4.4]);

translate([34, 2, 0]) cube([1, 1, 4.3]);

translate([35, 2, 0]) cube([1, 1, 4.2]);

translate([36, 2, 0]) cube([1, 1, 4.1]);

translate([37, 2, 0]) cube([1, 1, 4.0]);

translate([38, 2, 0]) cube([1, 1, 3.9]);

translate([39, 2, 0]) cube([1, 1, 3.8]);

translate([40, 2, 0]) cube([1, 1, 3.6]);

translate([41, 2, 0]) cube([1, 1, 3.6]);

translate([42, 2, 0]) cube([1, 1, 3.7]);

translate([43, 2, 0]) cube([1, 1, 3.9]);

translate([44, 2, 0]) cube([1, 1, 4.0]);

translate([45, 2, 0]) cube([1, 1, 4.0]);

translate([46, 2, 0]) cube([1, 1, 4.1]);

translate([47, 2, 0]) cube([1, 1, 4.2]);

color([0,1,0])
translate([0, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

translate([3, 3, 0]) cube([1, 1, 5.4]);

translate([4, 3, 0]) cube([1, 1, 5.2]);

translate([5, 3, 0]) cube([1, 1, 5.0]);

translate([6, 3, 0]) cube([1, 1, 4.8]);

translate([7, 3, 0]) cube([1, 1, 4.6]);

translate([8, 3, 0]) cube([1, 1, 4.400000032211649]);

translate([9, 3, 0]) cube([1, 1, 4.400000077779988]);

translate([10, 3, 0]) cube([1, 1, 4.4000002618492005]);

translate([11, 3, 0]) cube([1, 1, 4.400000408547226]);

translate([12, 3, 0]) cube([1, 1, 4.3000008376532275]);

translate([13, 3, 0]) cube([1, 1, 4.3000006196280305]);

translate([14, 3, 0]) cube([1, 1, 4.100015075048027]);

translate([15, 3, 0]) cube([1, 1, 4.000049242672725]);

translate([16, 3, 0]) cube([1, 1, 3.900146235575711]);

translate([17, 3, 0]) cube([1, 1, 3.800187535110409]);

translate([18, 3, 0]) cube([1, 1, 3.800186871769696]);

translate([19, 3, 0]) cube([1, 1, 3.900011047380294]);

translate([20, 3, 0]) cube([1, 1, 3.90000949456516]);

translate([21, 3, 0]) cube([1, 1, 3.9000094852923763]);

translate([22, 3, 0]) cube([1, 1, 4.000004227980951]);

translate([23, 3, 0]) cube([1, 1, 4.1000025764719705]);

translate([24, 3, 0]) cube([1, 1, 4.2000010554661715]);

translate([25, 3, 0]) cube([1, 1, 4.300000249091768]);

translate([26, 3, 0]) cube([1, 1, 4.400000095284872]);

translate([27, 3, 0]) cube([1, 1, 4.400000108878127]);

translate([28, 3, 0]) cube([1, 1, 4.5]);

translate([29, 3, 0]) cube([1, 1, 4.5]);

translate([30, 3, 0]) cube([1, 1, 4.4]);

translate([31, 3, 0]) cube([1, 1, 4.300000001290496]);

translate([32, 3, 0]) cube([1, 1, 4.3]);

translate([33, 3, 0]) cube([1, 1, 4.2]);

translate([34, 3, 0]) cube([1, 1, 4.1]);

translate([35, 3, 0]) cube([1, 1, 4.0]);

translate([36, 3, 0]) cube([1, 1, 4.0]);

translate([37, 3, 0]) cube([1, 1, 3.9]);

translate([38, 3, 0]) cube([1, 1, 3.8]);

translate([39, 3, 0]) cube([1, 1, 3.6]);

translate([40, 3, 0]) cube([1, 1, 3.5000000002698917]);

translate([41, 3, 0]) cube([1, 1, 3.400000004406493]);

translate([42, 3, 0]) cube([1, 1, 3.5]);

translate([43, 3, 0]) cube([1, 1, 3.7]);

translate([44, 3, 0]) cube([1, 1, 3.8]);

translate([45, 3, 0]) cube([1, 1, 3.9]);

translate([46, 3, 0]) cube([1, 1, 3.8]);

translate([47, 3, 0]) cube([1, 1, 3.8]);

translate([0, 4, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([1, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

translate([5, 4, 0]) cube([1, 1, 5.4]);

translate([6, 4, 0]) cube([1, 1, 5.2]);

translate([7, 4, 0]) cube([1, 1, 5.0]);

translate([8, 4, 0]) cube([1, 1, 4.800000014909481]);

translate([9, 4, 0]) cube([1, 1, 4.8000000490573616]);

translate([10, 4, 0]) cube([1, 1, 4.800000082532917]);

translate([11, 4, 0]) cube([1, 1, 4.700000800975324]);

translate([12, 4, 0]) cube([1, 1, 4.600001562948263]);

translate([13, 4, 0]) cube([1, 1, 4.400001375518212]);

translate([14, 4, 0]) cube([1, 1, 4.200057774667439]);

translate([15, 4, 0]) cube([1, 1, 4.000120090308544]);

translate([16, 4, 0]) cube([1, 1, 3.900204090584946]);

translate([17, 4, 0]) cube([1, 1, 4.000051358160997]);

translate([18, 4, 0]) cube([1, 1, 4.000046267841382]);

translate([19, 4, 0]) cube([1, 1, 4.1000130298765445]);

translate([20, 4, 0]) cube([1, 1, 4.2000048361075635]);

translate([21, 4, 0]) cube([1, 1, 4.100004114733555]);

translate([22, 4, 0]) cube([1, 1, 4.10000392741464]);

translate([23, 4, 0]) cube([1, 1, 4.200001248337983]);

translate([24, 4, 0]) cube([1, 1, 4.2000012600408025]);

translate([25, 4, 0]) cube([1, 1, 4.300000480672615]);

translate([26, 4, 0]) cube([1, 1, 4.400000169355032]);

translate([27, 4, 0]) cube([1, 1, 4.400000153292385]);

translate([28, 4, 0]) cube([1, 1, 4.3000003666717905]);

translate([29, 4, 0]) cube([1, 1, 4.300000191950491]);

translate([30, 4, 0]) cube([1, 1, 4.300000027077896]);

translate([31, 4, 0]) cube([1, 1, 4.200000001473314]);

translate([32, 4, 0]) cube([1, 1, 4.1000001256739935]);

translate([33, 4, 0]) cube([1, 1, 3.9000011758990625]);

translate([34, 4, 0]) cube([1, 1, 3.800000229841831]);

translate([35, 4, 0]) cube([1, 1, 3.7000000401641078]);

translate([36, 4, 0]) cube([1, 1, 3.7000000027991313]);

translate([37, 4, 0]) cube([1, 1, 3.7]);

translate([38, 4, 0]) cube([1, 1, 3.6]);

translate([39, 4, 0]) cube([1, 1, 3.500000026173888]);

translate([40, 4, 0]) cube([1, 1, 3.4000000400232815]);

translate([41, 4, 0]) cube([1, 1, 3.3000001653391258]);

translate([42, 4, 0]) cube([1, 1, 3.4]);

translate([43, 4, 0]) cube([1, 1, 3.6]);

translate([44, 4, 0]) cube([1, 1, 3.7]);

translate([45, 4, 0]) cube([1, 1, 3.8]);

translate([46, 4, 0]) cube([1, 1, 3.7]);

translate([47, 4, 0]) cube([1, 1, 3.6]);

translate([0, 5, 0]) cube([1, 1, 7.0]);

translate([1, 5, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

translate([7, 5, 0]) cube([1, 1, 5.3]);

translate([8, 5, 0]) cube([1, 1, 5.200000010270271]);

translate([9, 5, 0]) cube([1, 1, 5.200000012252179]);

translate([10, 5, 0]) cube([1, 1, 5.100000162199342]);

translate([11, 5, 0]) cube([1, 1, 5.000000335751497]);

translate([12, 5, 0]) cube([1, 1, 4.800003439559006]);

translate([13, 5, 0]) cube([1, 1, 4.600003258983331]);

translate([14, 5, 0]) cube([1, 1, 4.300094577881761]);

translate([15, 5, 0]) cube([1, 1, 4.200131431825861]);

translate([16, 5, 0]) cube([1, 1, 4.1001814921593995]);

translate([17, 5, 0]) cube([1, 1, 4.2000781563007]);

translate([18, 5, 0]) cube([1, 1, 4.300037012816368]);

translate([19, 5, 0]) cube([1, 1, 4.400017013751334]);

translate([20, 5, 0]) cube([1, 1, 4.500006292539976]);

translate([21, 5, 0]) cube([1, 1, 4.400005717361245]);

translate([22, 5, 0]) cube([1, 1, 4.400003353567483]);

translate([23, 5, 0]) cube([1, 1, 4.400001648023917]);

translate([24, 5, 0]) cube([1, 1, 4.400001133337134]);

translate([25, 5, 0]) cube([1, 1, 4.500000308417421]);

translate([26, 5, 0]) cube([1, 1, 4.500000228031797]);

translate([27, 5, 0]) cube([1, 1, 4.400000437961662]);

translate([28, 5, 0]) cube([1, 1, 4.300000421134144]);

translate([29, 5, 0]) cube([1, 1, 4.200002954748083]);

translate([30, 5, 0]) cube([1, 1, 4.100003160689945]);

translate([31, 5, 0]) cube([1, 1, 4.1000005274058315]);

translate([32, 5, 0]) cube([1, 1, 3.900004600470587]);

translate([33, 5, 0]) cube([1, 1, 3.7000071872235303]);

translate([34, 5, 0]) cube([1, 1, 3.6000098456910172]);

translate([35, 5, 0]) cube([1, 1, 3.5000020199043433]);

translate([36, 5, 0]) cube([1, 1, 3.5000005235269986]);

translate([37, 5, 0]) cube([1, 1, 3.6]);

translate([38, 5, 0]) cube([1, 1, 3.5000001561262852]);

translate([39, 5, 0]) cube([1, 1, 3.40000018925459]);

translate([40, 5, 0]) cube([1, 1, 3.300000187360874]);

translate([41, 5, 0]) cube([1, 1, 3.300000162739884]);

translate([42, 5, 0]) cube([1, 1, 3.4]);

translate([43, 5, 0]) cube([1, 1, 3.5]);

translate([44, 5, 0]) cube([1, 1, 3.6]);

translate([45, 5, 0]) cube([1, 1, 3.7]);

translate([46, 5, 0]) cube([1, 1, 3.6]);

translate([47, 5, 0]) cube([1, 1, 3.5]);

translate([0, 6, 0]) cube([1, 1, 7.2]);

translate([1, 6, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([2, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

translate([8, 6, 0]) cube([1, 1, 5.4000000177758585]);

translate([9, 6, 0]) cube([1, 1, 5.400000027236208]);

translate([10, 6, 0]) cube([1, 1, 5.400000032942389]);

translate([11, 6, 0]) cube([1, 1, 5.200000758400986]);

translate([12, 6, 0]) cube([1, 1, 5.000000741401767]);

translate([13, 6, 0]) cube([1, 1, 4.8000153731862945]);

translate([14, 6, 0]) cube([1, 1, 4.500147806744906]);

translate([15, 6, 0]) cube([1, 1, 4.400210500563969]);

translate([16, 6, 0]) cube([1, 1, 4.400204117011791]);

translate([17, 6, 0]) cube([1, 1, 4.500101767068101]);

translate([18, 6, 0]) cube([1, 1, 4.600047889512877]);

translate([19, 6, 0]) cube([1, 1, 4.800018400025698]);

translate([20, 6, 0]) cube([1, 1, 4.8000124912013105]);

translate([21, 6, 0]) cube([1, 1, 4.800006868757252]);

translate([22, 6, 0]) cube([1, 1, 4.700002938525935]);

translate([23, 6, 0]) cube([1, 1, 4.700001249163722]);

translate([24, 6, 0]) cube([1, 1, 4.700000702400745]);

translate([25, 6, 0]) cube([1, 1, 4.70000064703929]);

translate([26, 6, 0]) cube([1, 1, 4.600000469544303]);

translate([27, 6, 0]) cube([1, 1, 4.400001942482529]);

translate([28, 6, 0]) cube([1, 1, 4.200010824890175]);

translate([29, 6, 0]) cube([1, 1, 4.100009477666423]);

translate([30, 6, 0]) cube([1, 1, 4.000013205953595]);

translate([31, 6, 0]) cube([1, 1, 3.9000223626180976]);

translate([32, 6, 0]) cube([1, 1, 3.8000226305027827]);

translate([33, 6, 0]) cube([1, 1, 3.600030761949007]);

translate([34, 6, 0]) cube([1, 1, 3.400064177476789]);

translate([35, 6, 0]) cube([1, 1, 3.40002183444557]);

translate([36, 6, 0]) cube([1, 1, 3.4000218172041845]);

translate([37, 6, 0]) cube([1, 1, 3.5000003558697657]);

translate([38, 6, 0]) cube([1, 1, 3.500000304578923]);

translate([39, 6, 0]) cube([1, 1, 3.4000003001517825]);

translate([40, 6, 0]) cube([1, 1, 3.300000227556606]);

translate([41, 6, 0]) cube([1, 1, 3.2000011703080493]);

translate([42, 6, 0]) cube([1, 1, 3.30000010455045]);

translate([43, 6, 0]) cube([1, 1, 3.4]);

translate([44, 6, 0]) cube([1, 1, 3.5]);

translate([45, 6, 0]) cube([1, 1, 3.6]);

translate([46, 6, 0]) cube([1, 1, 3.6]);

translate([47, 6, 0]) cube([1, 1, 3.5]);

translate([0, 7, 0]) cube([1, 1, 7.4]);

translate([1, 7, 0]) cube([1, 1, 7.0]);

translate([2, 7, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

translate([11, 7, 0]) cube([1, 1, 5.400000080587214]);

translate([12, 7, 0]) cube([1, 1, 5.20000362004866]);

translate([13, 7, 0]) cube([1, 1, 4.9000878851970855]);

translate([14, 7, 0]) cube([1, 1, 4.700215259324646]);

translate([15, 7, 0]) cube([1, 1, 4.6002694525494245]);

translate([16, 7, 0]) cube([1, 1, 4.6002644271722835]);

translate([17, 7, 0]) cube([1, 1, 4.800125884825633]);

translate([18, 7, 0]) cube([1, 1, 4.900070639409015]);

translate([19, 7, 0]) cube([1, 1, 5.100024527769096]);

translate([20, 7, 0]) cube([1, 1, 5.100014761554766]);

translate([21, 7, 0]) cube([1, 1, 5.1000052517517105]);

translate([22, 7, 0]) cube([1, 1, 5.000001851491461]);

translate([23, 7, 0]) cube([1, 1, 5.000000726488815]);

translate([24, 7, 0]) cube([1, 1, 4.900000724486045]);

translate([25, 7, 0]) cube([1, 1, 4.900000488549735]);

translate([26, 7, 0]) cube([1, 1, 4.700001694408041]);

translate([27, 7, 0]) cube([1, 1, 4.500007334504069]);

translate([28, 7, 0]) cube([1, 1, 4.200033193971527]);

translate([29, 7, 0]) cube([1, 1, 4.000036710175946]);

translate([30, 7, 0]) cube([1, 1, 3.9000949281322193]);

translate([31, 7, 0]) cube([1, 1, 3.800085667877828]);

translate([32, 7, 0]) cube([1, 1, 3.7001193989227987]);

translate([33, 7, 0]) cube([1, 1, 3.5002069027802296]);

translate([34, 7, 0]) cube([1, 1, 3.303477074094336]);

translate([35, 7, 0]) cube([1, 1, 3.3034770720104225]);

translate([36, 7, 0]) cube([1, 1, 3.400022252173124]);

translate([37, 7, 0]) cube([1, 1, 3.5000006102350514]);

translate([38, 7, 0]) cube([1, 1, 3.500000674795118]);

translate([39, 7, 0]) cube([1, 1, 3.400000416510849]);

translate([40, 7, 0]) cube([1, 1, 3.300000265248376]);

translate([41, 7, 0]) cube([1, 1, 3.3000001341134686]);

translate([42, 7, 0]) cube([1, 1, 3.3000001050327734]);

translate([43, 7, 0]) cube([1, 1, 3.4]);

translate([44, 7, 0]) cube([1, 1, 3.5]);

translate([45, 7, 0]) cube([1, 1, 3.6]);

translate([46, 7, 0]) cube([1, 1, 3.6]);

translate([47, 7, 0]) cube([1, 1, 3.5]);

translate([0, 8, 0]) cube([1, 1, 7.5]);

translate([1, 8, 0]) cube([1, 1, 7.2]);

translate([2, 8, 0]) cube([1, 1, 6.9]);

translate([3, 8, 0]) cube([1, 1, 6.7]);

translate([4, 8, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([5, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

translate([12, 8, 0]) cube([1, 1, 5.300021438347339]);

translate([13, 8, 0]) cube([1, 1, 5.100122731257669]);

translate([14, 8, 0]) cube([1, 1, 4.9002031945789115]);

translate([15, 8, 0]) cube([1, 1, 4.800431854691857]);

translate([16, 8, 0]) cube([1, 1, 4.900268853249689]);

translate([17, 8, 0]) cube([1, 1, 5.100189776072811]);

translate([18, 8, 0]) cube([1, 1, 5.200100157885282]);

translate([19, 8, 0]) cube([1, 1, 5.400038739906626]);

color([0,1,0])
translate([20, 8, 0]) cube([1, 1, 6]);

translate([21, 8, 0]) cube([1, 1, 5.400002654799559]);

translate([22, 8, 0]) cube([1, 1, 5.400000771406108]);

translate([23, 8, 0]) cube([1, 1, 5.300000588223877]);

translate([24, 8, 0]) cube([1, 1, 5.200000436677136]);

translate([25, 8, 0]) cube([1, 1, 5.100001836708505]);

translate([26, 8, 0]) cube([1, 1, 4.80000784940193]);

translate([27, 8, 0]) cube([1, 1, 4.5000266926733]);

translate([28, 8, 0]) cube([1, 1, 4.200130059498366]);

translate([29, 8, 0]) cube([1, 1, 3.9004152549176907]);

translate([30, 8, 0]) cube([1, 1, 3.800297848253747]);

translate([31, 8, 0]) cube([1, 1, 3.700466340034547]);

translate([32, 8, 0]) cube([1, 1, 3.6008617325385566]);

translate([33, 8, 0]) cube([1, 1, 3.403537798256379]);

translate([34, 8, 0]) cube([1, 1, 3.3034771340655307]);

translate([35, 8, 0]) cube([1, 1, 3.3034771226059285]);

translate([36, 8, 0]) cube([1, 1, 3.4000918661798836]);

translate([37, 8, 0]) cube([1, 1, 3.5000030290139907]);

translate([38, 8, 0]) cube([1, 1, 3.600000358587694]);

translate([39, 8, 0]) cube([1, 1, 3.600000256192493]);

translate([40, 8, 0]) cube([1, 1, 3.500000055560936]);

translate([41, 8, 0]) cube([1, 1, 3.5000000075848035]);

translate([42, 8, 0]) cube([1, 1, 3.5]);

translate([43, 8, 0]) cube([1, 1, 3.5]);

translate([44, 8, 0]) cube([1, 1, 3.6]);

translate([45, 8, 0]) cube([1, 1, 3.7]);

translate([46, 8, 0]) cube([1, 1, 3.7]);

translate([47, 8, 0]) cube([1, 1, 3.6]);

translate([0, 9, 0]) cube([1, 1, 7.7]);

translate([1, 9, 0]) cube([1, 1, 7.4]);

translate([2, 9, 0]) cube([1, 1, 7.1]);

translate([3, 9, 0]) cube([1, 1, 7.0]);

translate([4, 9, 0]) cube([1, 1, 6.8]);

translate([5, 9, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([6, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

translate([13, 9, 0]) cube([1, 1, 5.30006779734958]);

translate([14, 9, 0]) cube([1, 1, 5.100381535068925]);

translate([15, 9, 0]) cube([1, 1, 5.100443728567241]);

translate([16, 9, 0]) cube([1, 1, 5.200430111862383]);

translate([17, 9, 0]) cube([1, 1, 5.300280653832593]);

color([0,1,0])
translate([18, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 9, 0]) cube([1, 1, 6]);

translate([24, 9, 0]) cube([1, 1, 5.300001812227521]);

translate([25, 9, 0]) cube([1, 1, 5.100008780836536]);

translate([26, 9, 0]) cube([1, 1, 4.800028156465095]);

translate([27, 9, 0]) cube([1, 1, 4.500095849827276]);

translate([28, 9, 0]) cube([1, 1, 4.200520652048065]);

translate([29, 9, 0]) cube([1, 1, 3.900942353486691]);

translate([30, 9, 0]) cube([1, 1, 3.7018532622421922]);

translate([31, 9, 0]) cube([1, 1, 3.603637259455441]);

translate([32, 9, 0]) cube([1, 1, 3.5052752222162558]);

translate([33, 9, 0]) cube([1, 1, 3.5030467286377314]);

translate([34, 9, 0]) cube([1, 1, 3.501103413779985]);

translate([35, 9, 0]) cube([1, 1, 3.500349954401854]);

translate([36, 9, 0]) cube([1, 1, 3.6000127099725874]);

translate([37, 9, 0]) cube([1, 1, 3.700001169055557]);

translate([38, 9, 0]) cube([1, 1, 3.7000009325288303]);

translate([39, 9, 0]) cube([1, 1, 3.8000000392819384]);

translate([40, 9, 0]) cube([1, 1, 3.9]);

translate([41, 9, 0]) cube([1, 1, 3.9]);

translate([42, 9, 0]) cube([1, 1, 3.8]);

translate([43, 9, 0]) cube([1, 1, 3.8]);

translate([44, 9, 0]) cube([1, 1, 3.8]);

translate([45, 9, 0]) cube([1, 1, 3.8]);

translate([46, 9, 0]) cube([1, 1, 3.8]);

translate([47, 9, 0]) cube([1, 1, 3.7]);

translate([0, 10, 0]) cube([1, 1, 7.9]);

translate([1, 10, 0]) cube([1, 1, 7.6]);

translate([2, 10, 0]) cube([1, 1, 7.4]);

translate([3, 10, 0]) cube([1, 1, 7.2]);

translate([4, 10, 0]) cube([1, 1, 7.1]);

translate([5, 10, 0]) cube([1, 1, 6.9]);

translate([6, 10, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([7, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

translate([14, 10, 0]) cube([1, 1, 5.400257321233202]);

translate([15, 10, 0]) cube([1, 1, 5.300792259715587]);

translate([16, 10, 0]) cube([1, 1, 5.400644287929326]);

color([0,1,0])
translate([17, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

translate([24, 10, 0]) cube([1, 1, 5.40000934464967]);

translate([25, 10, 0]) cube([1, 1, 5.100032349135136]);

translate([26, 10, 0]) cube([1, 1, 4.800097848640112]);

translate([27, 10, 0]) cube([1, 1, 4.500345400130473]);

translate([28, 10, 0]) cube([1, 1, 4.202136284962299]);

translate([29, 10, 0]) cube([1, 1, 4.0019228291859665]);

translate([30, 10, 0]) cube([1, 1, 3.80383476804571]);

translate([31, 10, 0]) cube([1, 1, 3.605034123882829]);

translate([32, 10, 0]) cube([1, 1, 3.603635317411354]);

translate([33, 10, 0]) cube([1, 1, 3.602190897181424]);

translate([34, 10, 0]) cube([1, 1, 3.700223749318063]);

translate([35, 10, 0]) cube([1, 1, 3.8000556995327286]);

translate([36, 10, 0]) cube([1, 1, 3.900004255849594]);

translate([37, 10, 0]) cube([1, 1, 3.900002442037493]);

translate([38, 10, 0]) cube([1, 1, 4.00000021412932]);

translate([39, 10, 0]) cube([1, 1, 4.1]);

translate([40, 10, 0]) cube([1, 1, 4.2]);

translate([41, 10, 0]) cube([1, 1, 4.3]);

translate([42, 10, 0]) cube([1, 1, 4.2]);

translate([43, 10, 0]) cube([1, 1, 4.1]);

translate([44, 10, 0]) cube([1, 1, 4.1]);

translate([45, 10, 0]) cube([1, 1, 4.0]);

translate([46, 10, 0]) cube([1, 1, 3.9]);

translate([47, 10, 0]) cube([1, 1, 3.8]);

translate([0, 11, 0]) cube([1, 1, 8.0]);

translate([1, 11, 0]) cube([1, 1, 7.7]);

translate([2, 11, 0]) cube([1, 1, 7.5]);

translate([3, 11, 0]) cube([1, 1, 7.3]);

translate([4, 11, 0]) cube([1, 1, 7.2]);

translate([5, 11, 0]) cube([1, 1, 7.0]);

translate([6, 11, 0]) cube([1, 1, 6.8]);

translate([7, 11, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([8, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

translate([24, 11, 0]) cube([1, 1, 5.400038833171382]);

translate([25, 11, 0]) cube([1, 1, 5.100111870629246]);

translate([26, 11, 0]) cube([1, 1, 4.8003363520372835]);

translate([27, 11, 0]) cube([1, 1, 4.601264553962636]);

translate([28, 11, 0]) cube([1, 1, 4.404283016177839]);

translate([29, 11, 0]) cube([1, 1, 4.202674197947055]);

translate([30, 11, 0]) cube([1, 1, 3.9058399406698405]);

translate([31, 11, 0]) cube([1, 1, 3.8045123333863913]);

translate([32, 11, 0]) cube([1, 1, 3.803861714053214]);

translate([33, 11, 0]) cube([1, 1, 3.9007930216710127]);

translate([34, 11, 0]) cube([1, 1, 4.100249794116774]);

translate([35, 11, 0]) cube([1, 1, 4.2000202403772535]);

translate([36, 11, 0]) cube([1, 1, 4.200004219557146]);

translate([37, 11, 0]) cube([1, 1, 4.200001093187667]);

translate([38, 11, 0]) cube([1, 1, 4.300000002568254]);

translate([39, 11, 0]) cube([1, 1, 4.4]);

translate([40, 11, 0]) cube([1, 1, 4.5]);

translate([41, 11, 0]) cube([1, 1, 4.5]);

translate([42, 11, 0]) cube([1, 1, 4.5]);

translate([43, 11, 0]) cube([1, 1, 4.4]);

translate([44, 11, 0]) cube([1, 1, 4.3]);

translate([45, 11, 0]) cube([1, 1, 4.2]);

translate([46, 11, 0]) cube([1, 1, 4.1]);

translate([47, 11, 0]) cube([1, 1, 4.0]);

translate([0, 12, 0]) cube([1, 1, 7.9]);

translate([1, 12, 0]) cube([1, 1, 7.6]);

translate([2, 12, 0]) cube([1, 1, 7.4]);

translate([3, 12, 0]) cube([1, 1, 7.3]);

translate([4, 12, 0]) cube([1, 1, 7.1]);

translate([5, 12, 0]) cube([1, 1, 7.0]);

translate([6, 12, 0]) cube([1, 1, 6.8]);

translate([7, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

translate([24, 12, 0]) cube([1, 1, 5.400154674517415]);

translate([25, 12, 0]) cube([1, 1, 5.100356951926064]);

translate([26, 12, 0]) cube([1, 1, 4.901180464924157]);

translate([27, 12, 0]) cube([1, 1, 4.704708109865828]);

translate([28, 12, 0]) cube([1, 1, 4.5063830054480585]);

translate([29, 12, 0]) cube([1, 1, 4.405260046708147]);

translate([30, 12, 0]) cube([1, 1, 4.106776736983032]);

translate([31, 12, 0]) cube([1, 1, 4.006725954962051]);

translate([32, 12, 0]) cube([1, 1, 4.10248729273217]);

translate([33, 12, 0]) cube([1, 1, 4.2011074256407355]);

translate([34, 12, 0]) cube([1, 1, 4.400120602794885]);

translate([35, 12, 0]) cube([1, 1, 4.600000713036848]);

translate([36, 12, 0]) cube([1, 1, 4.6000001427082235]);

translate([37, 12, 0]) cube([1, 1, 4.600000025935299]);

translate([38, 12, 0]) cube([1, 1, 4.600000001882161]);

translate([39, 12, 0]) cube([1, 1, 4.6]);

translate([40, 12, 0]) cube([1, 1, 4.7]);

translate([41, 12, 0]) cube([1, 1, 4.7]);

translate([42, 12, 0]) cube([1, 1, 4.6]);

translate([43, 12, 0]) cube([1, 1, 4.5]);

translate([44, 12, 0]) cube([1, 1, 4.5]);

translate([45, 12, 0]) cube([1, 1, 4.5]);

translate([46, 12, 0]) cube([1, 1, 4.4]);

translate([47, 12, 0]) cube([1, 1, 4.3]);

translate([0, 13, 0]) cube([1, 1, 7.9]);

translate([1, 13, 0]) cube([1, 1, 7.6]);

translate([2, 13, 0]) cube([1, 1, 7.3]);

translate([3, 13, 0]) cube([1, 1, 7.2]);

translate([4, 13, 0]) cube([1, 1, 7.0]);

translate([5, 13, 0]) cube([1, 1, 6.9]);

translate([6, 13, 0]) cube([1, 1, 6.7]);

translate([7, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 13, 0]) cube([1, 1, 6]);

translate([10, 13, 0]) cube([1, 1, 6.6]);

translate([11, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 13, 0]) cube([1, 1, 6]);

translate([25, 13, 0]) cube([1, 1, 5.2010150306011145]);

translate([26, 13, 0]) cube([1, 1, 4.904420741551644]);

translate([27, 13, 0]) cube([1, 1, 4.806833619328524]);

translate([28, 13, 0]) cube([1, 1, 4.706378598276367]);

translate([29, 13, 0]) cube([1, 1, 4.606347144356378]);

translate([30, 13, 0]) cube([1, 1, 4.406908769761713]);

translate([31, 13, 0]) cube([1, 1, 4.305916792710948]);

translate([32, 13, 0]) cube([1, 1, 4.304814232199311]);

translate([33, 13, 0]) cube([1, 1, 4.500598016584932]);

translate([34, 13, 0]) cube([1, 1, 4.80000428463632]);

translate([35, 13, 0]) cube([1, 1, 4.900000010832481]);

translate([36, 13, 0]) cube([1, 1, 4.900000002813692]);

translate([37, 13, 0]) cube([1, 1, 4.900000000200242]);

translate([38, 13, 0]) cube([1, 1, 4.9]);

translate([39, 13, 0]) cube([1, 1, 4.9]);

translate([40, 13, 0]) cube([1, 1, 4.9]);

translate([41, 13, 0]) cube([1, 1, 4.8]);

translate([42, 13, 0]) cube([1, 1, 4.8]);

translate([43, 13, 0]) cube([1, 1, 4.7]);

translate([44, 13, 0]) cube([1, 1, 4.7]);

translate([45, 13, 0]) cube([1, 1, 4.7]);

translate([46, 13, 0]) cube([1, 1, 4.8]);

translate([47, 13, 0]) cube([1, 1, 4.7]);

translate([0, 14, 0]) cube([1, 1, 7.9]);

translate([1, 14, 0]) cube([1, 1, 7.6]);

translate([2, 14, 0]) cube([1, 1, 7.3]);

translate([3, 14, 0]) cube([1, 1, 7.1]);

translate([4, 14, 0]) cube([1, 1, 6.9]);

translate([5, 14, 0]) cube([1, 1, 6.7]);

translate([6, 14, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

translate([9, 14, 0]) cube([1, 1, 6.6]);

translate([10, 14, 0]) cube([1, 1, 6.7]);

translate([11, 14, 0]) cube([1, 1, 6.7]);

translate([12, 14, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 14, 0]) cube([1, 1, 6]);

translate([25, 14, 0]) cube([1, 1, 5.202460938827062]);

translate([26, 14, 0]) cube([1, 1, 5.004861880099022]);

translate([27, 14, 0]) cube([1, 1, 4.909063751618373]);

translate([28, 14, 0]) cube([1, 1, 4.808474759384643]);

translate([29, 14, 0]) cube([1, 1, 4.7083623477062115]);

translate([30, 14, 0]) cube([1, 1, 4.609108870918461]);

translate([31, 14, 0]) cube([1, 1, 4.510179164492922]);

translate([32, 14, 0]) cube([1, 1, 4.6029643842700185]);

translate([33, 14, 0]) cube([1, 1, 4.800021352150125]);

translate([34, 14, 0]) cube([1, 1, 5.100000071162963]);

translate([35, 14, 0]) cube([1, 1, 5.300000006728378]);

translate([36, 14, 0]) cube([1, 1, 5.30000000370187]);

translate([37, 14, 0]) cube([1, 1, 5.3]);

translate([38, 14, 0]) cube([1, 1, 5.2]);

translate([39, 14, 0]) cube([1, 1, 5.1]);

translate([40, 14, 0]) cube([1, 1, 5.1]);

translate([41, 14, 0]) cube([1, 1, 5.0]);

translate([42, 14, 0]) cube([1, 1, 4.9]);

translate([43, 14, 0]) cube([1, 1, 4.8]);

translate([44, 14, 0]) cube([1, 1, 4.9]);

translate([45, 14, 0]) cube([1, 1, 5.0]);

translate([46, 14, 0]) cube([1, 1, 5.1]);

translate([47, 14, 0]) cube([1, 1, 5.1]);

translate([0, 15, 0]) cube([1, 1, 8.0]);

translate([1, 15, 0]) cube([1, 1, 7.7]);

translate([2, 15, 0]) cube([1, 1, 7.4]);

translate([3, 15, 0]) cube([1, 1, 7.1]);

translate([4, 15, 0]) cube([1, 1, 6.8]);

translate([5, 15, 0]) cube([1, 1, 6.7]);

translate([6, 15, 0]) cube([1, 1, 6.6]);

translate([7, 15, 0]) cube([1, 1, 6.6]);

translate([8, 15, 0]) cube([1, 1, 6.7]);

translate([9, 15, 0]) cube([1, 1, 6.8]);

translate([10, 15, 0]) cube([1, 1, 6.9]);

translate([11, 15, 0]) cube([1, 1, 6.8]);

translate([12, 15, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 15, 0]) cube([1, 1, 6]);

translate([25, 15, 0]) cube([1, 1, 5.205338266643073]);

translate([26, 15, 0]) cube([1, 1, 5.015514389987384]);

translate([27, 15, 0]) cube([1, 1, 4.919008357870864]);

translate([28, 15, 0]) cube([1, 1, 4.91017314052907]);

translate([29, 15, 0]) cube([1, 1, 4.809069213901809]);

translate([30, 15, 0]) cube([1, 1, 4.7138431331342785]);

translate([31, 15, 0]) cube([1, 1, 4.6146938931729595]);

translate([32, 15, 0]) cube([1, 1, 4.800106378308668]);

translate([33, 15, 0]) cube([1, 1, 5.10000030381638]);

translate([34, 15, 0]) cube([1, 1, 5.400000025951347]);

color([0,1,0])
translate([35, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 15, 0]) cube([1, 1, 6]);

translate([39, 15, 0]) cube([1, 1, 5.4]);

translate([40, 15, 0]) cube([1, 1, 5.3]);

translate([41, 15, 0]) cube([1, 1, 5.2]);

translate([42, 15, 0]) cube([1, 1, 5.1]);

translate([43, 15, 0]) cube([1, 1, 5.1]);

translate([44, 15, 0]) cube([1, 1, 5.1]);

translate([45, 15, 0]) cube([1, 1, 5.3]);

translate([46, 15, 0]) cube([1, 1, 5.4]);

translate([47, 15, 0]) cube([1, 1, 5.4]);

translate([0, 16, 0]) cube([1, 1, 8.1]);

translate([1, 16, 0]) cube([1, 1, 7.8]);

translate([2, 16, 0]) cube([1, 1, 7.5]);

translate([3, 16, 0]) cube([1, 1, 7.1]);

translate([4, 16, 0]) cube([1, 1, 6.9]);

translate([5, 16, 0]) cube([1, 1, 6.8]);

translate([6, 16, 0]) cube([1, 1, 6.8]);

translate([7, 16, 0]) cube([1, 1, 6.8]);

translate([8, 16, 0]) cube([1, 1, 7.0]);

translate([9, 16, 0]) cube([1, 1, 7.1]);

translate([10, 16, 0]) cube([1, 1, 7.1]);

translate([11, 16, 0]) cube([1, 1, 6.9]);

translate([12, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 16, 0]) cube([1, 1, 6]);

translate([25, 16, 0]) cube([1, 1, 5.210866990138416]);

translate([26, 16, 0]) cube([1, 1, 5.029756279765862]);

translate([27, 16, 0]) cube([1, 1, 5.019131482319278]);

translate([28, 16, 0]) cube([1, 1, 4.9197024723539515]);

translate([29, 16, 0]) cube([1, 1, 4.819280644372854]);

translate([30, 16, 0]) cube([1, 1, 4.722085800873341]);

translate([31, 16, 0]) cube([1, 1, 4.7210908700805225]);

translate([32, 16, 0]) cube([1, 1, 4.900636312634743]);

translate([33, 16, 0]) cube([1, 1, 5.200001665679933]);

color([0,1,0])
translate([34, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 16, 0]) cube([1, 1, 6]);

translate([43, 16, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([44, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 16, 0]) cube([1, 1, 6]);

translate([0, 17, 0]) cube([1, 1, 8.2]);

translate([1, 17, 0]) cube([1, 1, 7.9]);

translate([2, 17, 0]) cube([1, 1, 7.5]);

translate([3, 17, 0]) cube([1, 1, 7.2]);

translate([4, 17, 0]) cube([1, 1, 7.0]);

translate([5, 17, 0]) cube([1, 1, 7.0]);

translate([6, 17, 0]) cube([1, 1, 7.0]);

translate([7, 17, 0]) cube([1, 1, 7.1]);

translate([8, 17, 0]) cube([1, 1, 7.3]);

translate([9, 17, 0]) cube([1, 1, 7.3]);

translate([10, 17, 0]) cube([1, 1, 7.2]);

translate([11, 17, 0]) cube([1, 1, 7.0]);

translate([12, 17, 0]) cube([1, 1, 6.8]);

translate([13, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 17, 0]) cube([1, 1, 6]);

translate([25, 17, 0]) cube([1, 1, 5.321610860593712]);

translate([26, 17, 0]) cube([1, 1, 5.143714756076371]);

translate([27, 17, 0]) cube([1, 1, 5.0402117393157235]);

translate([28, 17, 0]) cube([1, 1, 4.939122067004685]);

translate([29, 17, 0]) cube([1, 1, 4.919605929547664]);

translate([30, 17, 0]) cube([1, 1, 4.819255600963764]);

translate([31, 17, 0]) cube([1, 1, 4.817964960844174]);

translate([32, 17, 0]) cube([1, 1, 4.90317224512162]);

translate([33, 17, 0]) cube([1, 1, 5.20000735915436]);

color([0,1,0])
translate([34, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 17, 0]) cube([1, 1, 6]);

translate([0, 18, 0]) cube([1, 1, 8.2]);

translate([1, 18, 0]) cube([1, 1, 7.9]);

translate([2, 18, 0]) cube([1, 1, 7.6]);

translate([3, 18, 0]) cube([1, 1, 7.3]);

translate([4, 18, 0]) cube([1, 1, 7.2]);

translate([5, 18, 0]) cube([1, 1, 7.2]);

translate([6, 18, 0]) cube([1, 1, 7.3]);

translate([7, 18, 0]) cube([1, 1, 7.4]);

translate([8, 18, 0]) cube([1, 1, 7.5]);

translate([9, 18, 0]) cube([1, 1, 7.5]);

translate([10, 18, 0]) cube([1, 1, 7.4]);

translate([11, 18, 0]) cube([1, 1, 7.1]);

translate([12, 18, 0]) cube([1, 1, 6.9]);

translate([13, 18, 0]) cube([1, 1, 6.7]);

translate([14, 18, 0]) cube([1, 1, 6.6]);

translate([15, 18, 0]) cube([1, 1, 6.6]);

translate([16, 18, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 18, 0]) cube([1, 1, 6]);

translate([25, 18, 0]) cube([1, 1, 5.442187513709044]);

translate([26, 18, 0]) cube([1, 1, 5.271398749019082]);

translate([27, 18, 0]) cube([1, 1, 5.150389749767671]);

translate([28, 18, 0]) cube([1, 1, 5.128428462993505]);

translate([29, 18, 0]) cube([1, 1, 5.017175051606041]);

translate([30, 18, 0]) cube([1, 1, 4.918182513741251]);

translate([31, 18, 0]) cube([1, 1, 4.910229137828996]);

translate([32, 18, 0]) cube([1, 1, 5.102419075474705]);

translate([33, 18, 0]) cube([1, 1, 5.300031752194408]);

color([0,1,0])
translate([34, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 8.1]);

translate([1, 19, 0]) cube([1, 1, 7.9]);

translate([2, 19, 0]) cube([1, 1, 7.6]);

translate([3, 19, 0]) cube([1, 1, 7.4]);

translate([4, 19, 0]) cube([1, 1, 7.4]);

translate([5, 19, 0]) cube([1, 1, 7.4]);

translate([6, 19, 0]) cube([1, 1, 7.5]);

translate([7, 19, 0]) cube([1, 1, 7.6]);

translate([8, 19, 0]) cube([1, 1, 7.6]);

translate([9, 19, 0]) cube([1, 1, 7.6]);

translate([10, 19, 0]) cube([1, 1, 7.4]);

translate([11, 19, 0]) cube([1, 1, 7.2]);

translate([12, 19, 0]) cube([1, 1, 7.0]);

translate([13, 19, 0]) cube([1, 1, 6.8]);

translate([14, 19, 0]) cube([1, 1, 6.7]);

translate([15, 19, 0]) cube([1, 1, 6.8]);

translate([16, 19, 0]) cube([1, 1, 6.8]);

translate([17, 19, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 19, 0]) cube([1, 1, 6]);

translate([26, 19, 0]) cube([1, 1, 5.385127042806822]);

translate([27, 19, 0]) cube([1, 1, 5.345116884194895]);

translate([28, 19, 0]) cube([1, 1, 5.228711241038671]);

translate([29, 19, 0]) cube([1, 1, 5.217924444812975]);

translate([30, 19, 0]) cube([1, 1, 5.110811112725087]);

translate([31, 19, 0]) cube([1, 1, 5.107663074631631]);

translate([32, 19, 0]) cube([1, 1, 5.201840782635539]);

translate([33, 19, 0]) cube([1, 1, 5.400133342602241]);

color([0,1,0])
translate([34, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 19, 0]) cube([1, 1, 6]);

translate([41, 19, 0]) cube([1, 1, 6.6]);

translate([42, 19, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([43, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 19, 0]) cube([1, 1, 6]);

translate([0, 20, 0]) cube([1, 1, 8.1]);

translate([1, 20, 0]) cube([1, 1, 7.9]);

translate([2, 20, 0]) cube([1, 1, 7.7]);

translate([3, 20, 0]) cube([1, 1, 7.6]);

translate([4, 20, 0]) cube([1, 1, 7.5]);

translate([5, 20, 0]) cube([1, 1, 7.6]);

translate([6, 20, 0]) cube([1, 1, 7.6]);

translate([7, 20, 0]) cube([1, 1, 7.6]);

translate([8, 20, 0]) cube([1, 1, 7.6]);

translate([9, 20, 0]) cube([1, 1, 7.6]);

translate([10, 20, 0]) cube([1, 1, 7.4]);

translate([11, 20, 0]) cube([1, 1, 7.2]);

translate([12, 20, 0]) cube([1, 1, 7.0]);

translate([13, 20, 0]) cube([1, 1, 6.9]);

translate([14, 20, 0]) cube([1, 1, 6.9]);

translate([15, 20, 0]) cube([1, 1, 6.9]);

translate([16, 20, 0]) cube([1, 1, 6.9]);

translate([17, 20, 0]) cube([1, 1, 6.8]);

translate([18, 20, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 20, 0]) cube([1, 1, 6]);

translate([28, 20, 0]) cube([1, 1, 5.4314691417654295]);

translate([29, 20, 0]) cube([1, 1, 5.418557428083057]);

translate([30, 20, 0]) cube([1, 1, 5.31088441815339]);

translate([31, 20, 0]) cube([1, 1, 5.306689276339266]);

translate([32, 20, 0]) cube([1, 1, 5.400426713005001]);

color([0,1,0])
translate([33, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 20, 0]) cube([1, 1, 6]);

translate([40, 20, 0]) cube([1, 1, 6.6]);

translate([41, 20, 0]) cube([1, 1, 6.8]);

translate([42, 20, 0]) cube([1, 1, 6.8]);

translate([43, 20, 0]) cube([1, 1, 6.8]);

translate([44, 20, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([45, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 20, 0]) cube([1, 1, 6]);

translate([47, 20, 0]) cube([1, 1, 5.4]);

translate([0, 21, 0]) cube([1, 1, 8.2]);

translate([1, 21, 0]) cube([1, 1, 7.9]);

translate([2, 21, 0]) cube([1, 1, 7.8]);

translate([3, 21, 0]) cube([1, 1, 7.7]);

translate([4, 21, 0]) cube([1, 1, 7.6]);

translate([5, 21, 0]) cube([1, 1, 7.6]);

translate([6, 21, 0]) cube([1, 1, 7.6]);

translate([7, 21, 0]) cube([1, 1, 7.5]);

translate([8, 21, 0]) cube([1, 1, 7.5]);

translate([9, 21, 0]) cube([1, 1, 7.4]);

translate([10, 21, 0]) cube([1, 1, 7.2]);

translate([11, 21, 0]) cube([1, 1, 7.1]);

translate([12, 21, 0]) cube([1, 1, 7.0]);

translate([13, 21, 0]) cube([1, 1, 7.0]);

translate([14, 21, 0]) cube([1, 1, 7.0]);

translate([15, 21, 0]) cube([1, 1, 7.0]);

translate([16, 21, 0]) cube([1, 1, 6.9]);

translate([17, 21, 0]) cube([1, 1, 6.7]);

translate([18, 21, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 21, 0]) cube([1, 1, 6]);

translate([21, 21, 0]) cube([1, 1, 6.565736075969481]);

translate([22, 21, 0]) cube([1, 1, 6.58276314912382]);

color([0,1,0])
translate([23, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 21, 0]) cube([1, 1, 6]);

translate([40, 21, 0]) cube([1, 1, 6.8]);

translate([41, 21, 0]) cube([1, 1, 6.9]);

translate([42, 21, 0]) cube([1, 1, 7.0]);

translate([43, 21, 0]) cube([1, 1, 6.9]);

translate([44, 21, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([45, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 21, 0]) cube([1, 1, 6]);

translate([47, 21, 0]) cube([1, 1, 5.4]);

translate([0, 22, 0]) cube([1, 1, 8.1]);

translate([1, 22, 0]) cube([1, 1, 7.9]);

translate([2, 22, 0]) cube([1, 1, 7.8]);

translate([3, 22, 0]) cube([1, 1, 7.7]);

translate([4, 22, 0]) cube([1, 1, 7.6]);

translate([5, 22, 0]) cube([1, 1, 7.5]);

translate([6, 22, 0]) cube([1, 1, 7.4]);

translate([7, 22, 0]) cube([1, 1, 7.3]);

translate([8, 22, 0]) cube([1, 1, 7.2]);

translate([9, 22, 0]) cube([1, 1, 7.0]);

translate([10, 22, 0]) cube([1, 1, 7.0]);

translate([11, 22, 0]) cube([1, 1, 7.0]);

translate([12, 22, 0]) cube([1, 1, 7.0]);

translate([13, 22, 0]) cube([1, 1, 7.0]);

translate([14, 22, 0]) cube([1, 1, 7.0]);

translate([15, 22, 0]) cube([1, 1, 7.0]);

translate([16, 22, 0]) cube([1, 1, 6.8]);

translate([17, 22, 0]) cube([1, 1, 6.6]);

translate([18, 22, 0]) cube([1, 1, 6.511226933114711]);

translate([19, 22, 0]) cube([1, 1, 6.507805932766974]);

translate([20, 22, 0]) cube([1, 1, 6.515464162409945]);

translate([21, 22, 0]) cube([1, 1, 6.617317339552354]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 22, 0]) cube([1, 1, 6]);

translate([39, 22, 0]) cube([1, 1, 6.6]);

translate([40, 22, 0]) cube([1, 1, 6.7]);

translate([41, 22, 0]) cube([1, 1, 6.9]);

translate([42, 22, 0]) cube([1, 1, 7.0]);

translate([43, 22, 0]) cube([1, 1, 6.9]);

translate([44, 22, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([45, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 22, 0]) cube([1, 1, 6]);

translate([47, 22, 0]) cube([1, 1, 5.4]);

translate([0, 23, 0]) cube([1, 1, 8.0]);

translate([1, 23, 0]) cube([1, 1, 7.8]);

translate([2, 23, 0]) cube([1, 1, 7.6]);

translate([3, 23, 0]) cube([1, 1, 7.6]);

translate([4, 23, 0]) cube([1, 1, 7.5]);

translate([5, 23, 0]) cube([1, 1, 7.4]);

translate([6, 23, 0]) cube([1, 1, 7.2]);

translate([7, 23, 0]) cube([1, 1, 7.1]);

translate([8, 23, 0]) cube([1, 1, 6.9]);

translate([9, 23, 0]) cube([1, 1, 6.7]);

translate([10, 23, 0]) cube([1, 1, 6.7]);

translate([11, 23, 0]) cube([1, 1, 6.8]);

translate([12, 23, 0]) cube([1, 1, 6.8]);

translate([13, 23, 0]) cube([1, 1, 6.9]);

translate([14, 23, 0]) cube([1, 1, 6.9]);

translate([15, 23, 0]) cube([1, 1, 6.9]);

translate([16, 23, 0]) cube([1, 1, 6.8]);

translate([17, 23, 0]) cube([1, 1, 6.6]);

translate([18, 23, 0]) cube([1, 1, 6.511241590119173]);

translate([19, 23, 0]) cube([1, 1, 6.513336694659562]);

translate([20, 23, 0]) cube([1, 1, 6.5289860892422285]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 23, 0]) cube([1, 1, 6]);

translate([40, 23, 0]) cube([1, 1, 6.6]);

translate([41, 23, 0]) cube([1, 1, 6.8]);

translate([42, 23, 0]) cube([1, 1, 6.8]);

translate([43, 23, 0]) cube([1, 1, 6.8]);

translate([44, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([45, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 23, 0]) cube([1, 1, 6]);

translate([0, 24, 0]) cube([1, 1, 7.7]);

translate([1, 24, 0]) cube([1, 1, 7.5]);

translate([2, 24, 0]) cube([1, 1, 7.4]);

translate([3, 24, 0]) cube([1, 1, 7.3]);

translate([4, 24, 0]) cube([1, 1, 7.2]);

translate([5, 24, 0]) cube([1, 1, 7.1]);

translate([6, 24, 0]) cube([1, 1, 7.0]);

translate([7, 24, 0]) cube([1, 1, 6.8]);

translate([8, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([9, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 24, 0]) cube([1, 1, 6]);

translate([11, 24, 0]) cube([1, 1, 6.6]);

translate([12, 24, 0]) cube([1, 1, 6.6]);

translate([13, 24, 0]) cube([1, 1, 6.7]);

translate([14, 24, 0]) cube([1, 1, 6.8]);

translate([15, 24, 0]) cube([1, 1, 6.8]);

translate([16, 24, 0]) cube([1, 1, 6.7]);

translate([17, 24, 0]) cube([1, 1, 6.6]);

translate([18, 24, 0]) cube([1, 1, 6.518974503960474]);

translate([19, 24, 0]) cube([1, 1, 6.520876022843752]);

translate([20, 24, 0]) cube([1, 1, 6.536251186067538]);

translate([21, 24, 0]) cube([1, 1, 6.609015068456006]);

color([0,1,0])
translate([22, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 24, 0]) cube([1, 1, 6]);

translate([41, 24, 0]) cube([1, 1, 6.6]);

translate([42, 24, 0]) cube([1, 1, 6.7]);

translate([43, 24, 0]) cube([1, 1, 6.7]);

translate([44, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([45, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 24, 0]) cube([1, 1, 6]);

translate([0, 25, 0]) cube([1, 1, 7.3]);

translate([1, 25, 0]) cube([1, 1, 7.1]);

translate([2, 25, 0]) cube([1, 1, 7.1]);

translate([3, 25, 0]) cube([1, 1, 7.0]);

translate([4, 25, 0]) cube([1, 1, 7.0]);

translate([5, 25, 0]) cube([1, 1, 6.9]);

translate([6, 25, 0]) cube([1, 1, 6.8]);

translate([7, 25, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 25, 0]) cube([1, 1, 6]);

translate([14, 25, 0]) cube([1, 1, 6.6]);

translate([15, 25, 0]) cube([1, 1, 6.6]);

translate([16, 25, 0]) cube([1, 1, 6.6]);

translate([17, 25, 0]) cube([1, 1, 6.513169812925464]);

translate([18, 25, 0]) cube([1, 1, 6.520312967618326]);

translate([19, 25, 0]) cube([1, 1, 6.5323158538856685]);

translate([20, 25, 0]) cube([1, 1, 6.559663459046345]);

translate([21, 25, 0]) cube([1, 1, 6.664456435054792]);

translate([22, 25, 0]) cube([1, 1, 6.67046550942867]);

color([0,1,0])
translate([23, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 25, 0]) cube([1, 1, 6]);

translate([29, 25, 0]) cube([1, 1, 5.486903593514867]);

translate([30, 25, 0]) cube([1, 1, 5.436421434513118]);

color([0,1,0])
translate([31, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 25, 0]) cube([1, 1, 6]);

translate([0, 26, 0]) cube([1, 1, 7.0]);

translate([1, 26, 0]) cube([1, 1, 6.8]);

translate([2, 26, 0]) cube([1, 1, 6.8]);

translate([3, 26, 0]) cube([1, 1, 6.8]);

translate([4, 26, 0]) cube([1, 1, 6.8]);

translate([5, 26, 0]) cube([1, 1, 6.7]);

translate([6, 26, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([7, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 26, 0]) cube([1, 1, 6]);

translate([16, 26, 0]) cube([1, 1, 6.504336784382572]);

translate([17, 26, 0]) cube([1, 1, 6.508514110684164]);

translate([18, 26, 0]) cube([1, 1, 6.6002689108228045]);

translate([19, 26, 0]) cube([1, 1, 6.600857513240634]);

translate([20, 26, 0]) cube([1, 1, 6.704166404216007]);

translate([21, 26, 0]) cube([1, 1, 6.710007243638195]);

translate([22, 26, 0]) cube([1, 1, 6.716967435122197]);

translate([23, 26, 0]) cube([1, 1, 6.600779092585654]);

color([0,1,0])
translate([24, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 26, 0]) cube([1, 1, 6]);

translate([28, 26, 0]) cube([1, 1, 5.498394772989362]);

translate([29, 26, 0]) cube([1, 1, 5.389775529534549]);

translate([30, 26, 0]) cube([1, 1, 5.362252095117016]);

translate([31, 26, 0]) cube([1, 1, 5.32592027764828]);

translate([32, 26, 0]) cube([1, 1, 5.400863182218917]);

color([0,1,0])
translate([33, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 26, 0]) cube([1, 1, 6]);

translate([0, 27, 0]) cube([1, 1, 6.8]);

translate([1, 27, 0]) cube([1, 1, 6.6]);

translate([2, 27, 0]) cube([1, 1, 6.6]);

translate([3, 27, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([4, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 27, 0]) cube([1, 1, 6]);

translate([18, 27, 0]) cube([1, 1, 6.60032454576925]);

translate([19, 27, 0]) cube([1, 1, 6.700833280843202]);

translate([20, 27, 0]) cube([1, 1, 6.9]);

translate([21, 27, 0]) cube([1, 1, 6.9]);

translate([22, 27, 0]) cube([1, 1, 6.9]);

translate([23, 27, 0]) cube([1, 1, 6.708453010833962]);

color([0,1,0])
translate([24, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 27, 0]) cube([1, 1, 6]);

translate([29, 27, 0]) cube([1, 1, 5.364868783438785]);

translate([30, 27, 0]) cube([1, 1, 5.288433617878712]);

translate([31, 27, 0]) cube([1, 1, 5.2486373798678745]);

translate([32, 27, 0]) cube([1, 1, 5.247899932117101]);

translate([33, 27, 0]) cube([1, 1, 5.300251140351005]);

color([0,1,0])
translate([34, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 27, 0]) cube([1, 1, 6]);

translate([0, 28, 0]) cube([1, 1, 6.7]);

translate([1, 28, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 28, 0]) cube([1, 1, 6]);

translate([11, 28, 0]) cube([1, 1, 5.400388945912417]);

color([0,1,0])
translate([12, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 28, 0]) cube([1, 1, 6]);

translate([18, 28, 0]) cube([1, 1, 6.500231565322491]);

translate([19, 28, 0]) cube([1, 1, 6.8]);

translate([20, 28, 0]) cube([1, 1, 7.0]);

translate([21, 28, 0]) cube([1, 1, 7.1]);

translate([22, 28, 0]) cube([1, 1, 7.0]);

translate([23, 28, 0]) cube([1, 1, 6.8]);

translate([24, 28, 0]) cube([1, 1, 6.501408835138994]);

color([0,1,0])
translate([25, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 28, 0]) cube([1, 1, 6]);

translate([30, 28, 0]) cube([1, 1, 5.3153084610329335]);

translate([31, 28, 0]) cube([1, 1, 5.247911120311599]);

translate([32, 28, 0]) cube([1, 1, 5.2479007021796376]);

translate([33, 28, 0]) cube([1, 1, 5.300148804651648]);

color([0,1,0])
translate([34, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 28, 0]) cube([1, 1, 6]);

translate([0, 29, 0]) cube([1, 1, 6.9]);

translate([1, 29, 0]) cube([1, 1, 6.7]);

translate([2, 29, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 29, 0]) cube([1, 1, 6]);

translate([10, 29, 0]) cube([1, 1, 5.300620853538268]);

translate([11, 29, 0]) cube([1, 1, 5.3006700327545975]);

translate([12, 29, 0]) cube([1, 1, 5.400646845894004]);

color([0,1,0])
translate([13, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 29, 0]) cube([1, 1, 6]);

translate([19, 29, 0]) cube([1, 1, 6.7]);

translate([20, 29, 0]) cube([1, 1, 7.0]);

translate([21, 29, 0]) cube([1, 1, 7.1]);

translate([22, 29, 0]) cube([1, 1, 7.0]);

translate([23, 29, 0]) cube([1, 1, 6.8]);

translate([24, 29, 0]) cube([1, 1, 6.500281767027798]);

color([0,1,0])
translate([25, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 29, 0]) cube([1, 1, 6]);

translate([30, 29, 0]) cube([1, 1, 5.402131221770957]);

translate([31, 29, 0]) cube([1, 1, 5.303739885795666]);

translate([32, 29, 0]) cube([1, 1, 5.247990355079585]);

translate([33, 29, 0]) cube([1, 1, 5.300324770327939]);

translate([34, 29, 0]) cube([1, 1, 5.400001085339616]);

color([0,1,0])
translate([35, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 29, 0]) cube([1, 1, 6]);

translate([47, 29, 0]) cube([1, 1, 5.3]);

translate([0, 30, 0]) cube([1, 1, 7.0]);

translate([1, 30, 0]) cube([1, 1, 6.9]);

translate([2, 30, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 30, 0]) cube([1, 1, 6]);

translate([9, 30, 0]) cube([1, 1, 5.4000001630446715]);

translate([10, 30, 0]) cube([1, 1, 5.300595142453171]);

translate([11, 30, 0]) cube([1, 1, 5.300636431034245]);

translate([12, 30, 0]) cube([1, 1, 5.400627340863546]);

color([0,1,0])
translate([13, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 30, 0]) cube([1, 1, 6]);

translate([19, 30, 0]) cube([1, 1, 6.6]);

translate([20, 30, 0]) cube([1, 1, 6.9]);

translate([21, 30, 0]) cube([1, 1, 7.0]);

translate([22, 30, 0]) cube([1, 1, 6.9]);

translate([23, 30, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([24, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 30, 0]) cube([1, 1, 6]);

translate([31, 30, 0]) cube([1, 1, 5.400619245817471]);

translate([32, 30, 0]) cube([1, 1, 5.300946733175578]);

translate([33, 30, 0]) cube([1, 1, 5.30043339475755]);

translate([34, 30, 0]) cube([1, 1, 5.400000179761704]);

color([0,1,0])
translate([35, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 30, 0]) cube([1, 1, 6]);

translate([46, 30, 0]) cube([1, 1, 5.4]);

translate([47, 30, 0]) cube([1, 1, 5.1]);

translate([0, 31, 0]) cube([1, 1, 7.1]);

translate([1, 31, 0]) cube([1, 1, 7.0]);

translate([2, 31, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 31, 0]) cube([1, 1, 6]);

translate([7, 31, 0]) cube([1, 1, 5.400000037435002]);

translate([8, 31, 0]) cube([1, 1, 5.300165127996299]);

translate([9, 31, 0]) cube([1, 1, 5.300277848418924]);

translate([10, 31, 0]) cube([1, 1, 5.300476419797564]);

translate([11, 31, 0]) cube([1, 1, 5.400158021323514]);

color([0,1,0])
translate([12, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 31, 0]) cube([1, 1, 6]);

translate([19, 31, 0]) cube([1, 1, 6.6]);

translate([20, 31, 0]) cube([1, 1, 6.8]);

translate([21, 31, 0]) cube([1, 1, 6.9]);

translate([22, 31, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([23, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 31, 0]) cube([1, 1, 6]);

translate([32, 31, 0]) cube([1, 1, 5.400187134783089]);

translate([33, 31, 0]) cube([1, 1, 5.300490998310557]);

translate([34, 31, 0]) cube([1, 1, 5.300433250099581]);

translate([35, 31, 0]) cube([1, 1, 5.300153947675469]);

translate([36, 31, 0]) cube([1, 1, 5.300107681658761]);

translate([37, 31, 0]) cube([1, 1, 5.400000024908418]);

color([0,1,0])
translate([38, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 31, 0]) cube([1, 1, 6]);

translate([46, 31, 0]) cube([1, 1, 5.3]);

translate([47, 31, 0]) cube([1, 1, 5.0]);

translate([0, 32, 0]) cube([1, 1, 7.2]);

translate([1, 32, 0]) cube([1, 1, 7.0]);

translate([2, 32, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 32, 0]) cube([1, 1, 6]);

translate([6, 32, 0]) cube([1, 1, 5.30000000949046]);

translate([7, 32, 0]) cube([1, 1, 5.200233514649659]);

translate([8, 32, 0]) cube([1, 1, 5.300147373765871]);

translate([9, 32, 0]) cube([1, 1, 5.300215069756952]);

translate([10, 32, 0]) cube([1, 1, 5.400039504163575]);

color([0,1,0])
translate([11, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 32, 0]) cube([1, 1, 6]);

translate([19, 32, 0]) cube([1, 1, 6.6]);

translate([20, 32, 0]) cube([1, 1, 6.8]);

translate([21, 32, 0]) cube([1, 1, 6.8]);

translate([22, 32, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([23, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 32, 0]) cube([1, 1, 6]);

translate([33, 32, 0]) cube([1, 1, 5.400082038008923]);

translate([34, 32, 0]) cube([1, 1, 5.400023368166959]);

translate([35, 32, 0]) cube([1, 1, 5.400005046470003]);

translate([36, 32, 0]) cube([1, 1, 5.300107690467837]);

translate([37, 32, 0]) cube([1, 1, 5.3001078463123426]);

translate([38, 32, 0]) cube([1, 1, 5.400000114932045]);

color([0,1,0])
translate([39, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 32, 0]) cube([1, 1, 6]);

translate([45, 32, 0]) cube([1, 1, 5.4]);

translate([46, 32, 0]) cube([1, 1, 5.1]);

translate([47, 32, 0]) cube([1, 1, 4.9]);

translate([0, 33, 0]) cube([1, 1, 7.1]);

translate([1, 33, 0]) cube([1, 1, 7.0]);

translate([2, 33, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 33, 0]) cube([1, 1, 6]);

translate([5, 33, 0]) cube([1, 1, 5.4]);

translate([6, 33, 0]) cube([1, 1, 5.200233785801537]);

translate([7, 33, 0]) cube([1, 1, 5.200234259726181]);

translate([8, 33, 0]) cube([1, 1, 5.300090609995918]);

color([0,1,0])
translate([9, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 33, 0]) cube([1, 1, 6]);

translate([19, 33, 0]) cube([1, 1, 6.6]);

translate([20, 33, 0]) cube([1, 1, 6.8]);

translate([21, 33, 0]) cube([1, 1, 6.8]);

translate([22, 33, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([23, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 33, 0]) cube([1, 1, 6]);

translate([36, 33, 0]) cube([1, 1, 5.400001559471388]);

translate([37, 33, 0]) cube([1, 1, 5.400000310524119]);

translate([38, 33, 0]) cube([1, 1, 5.4000001266573525]);

color([0,1,0])
translate([39, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 33, 0]) cube([1, 1, 6]);

translate([44, 33, 0]) cube([1, 1, 5.4]);

translate([45, 33, 0]) cube([1, 1, 5.2]);

translate([46, 33, 0]) cube([1, 1, 5.0]);

translate([47, 33, 0]) cube([1, 1, 4.8]);

translate([0, 34, 0]) cube([1, 1, 7.0]);

translate([1, 34, 0]) cube([1, 1, 6.9]);

translate([2, 34, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 34, 0]) cube([1, 1, 6]);

translate([5, 34, 0]) cube([1, 1, 5.4]);

translate([6, 34, 0]) cube([1, 1, 5.3000075483003135]);

translate([7, 34, 0]) cube([1, 1, 5.300022651588308]);

color([0,1,0])
translate([8, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 34, 0]) cube([1, 1, 6]);

translate([18, 34, 0]) cube([1, 1, 6.6]);

translate([19, 34, 0]) cube([1, 1, 6.7]);

translate([20, 34, 0]) cube([1, 1, 6.9]);

translate([21, 34, 0]) cube([1, 1, 6.9]);

translate([22, 34, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([23, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 34, 0]) cube([1, 1, 6]);

translate([43, 34, 0]) cube([1, 1, 5.4]);

translate([44, 34, 0]) cube([1, 1, 5.3]);

translate([45, 34, 0]) cube([1, 1, 5.1]);

translate([46, 34, 0]) cube([1, 1, 4.9]);

translate([47, 34, 0]) cube([1, 1, 4.8]);

translate([0, 35, 0]) cube([1, 1, 6.8]);

translate([1, 35, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 35, 0]) cube([1, 1, 6]);

translate([17, 35, 0]) cube([1, 1, 6.6]);

translate([18, 35, 0]) cube([1, 1, 6.8]);

translate([19, 35, 0]) cube([1, 1, 6.9]);

translate([20, 35, 0]) cube([1, 1, 7.0]);

translate([21, 35, 0]) cube([1, 1, 7.0]);

translate([22, 35, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([23, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 35, 0]) cube([1, 1, 6]);

translate([42, 35, 0]) cube([1, 1, 5.4]);

translate([43, 35, 0]) cube([1, 1, 5.3]);

translate([44, 35, 0]) cube([1, 1, 5.1]);

translate([45, 35, 0]) cube([1, 1, 4.9]);

translate([46, 35, 0]) cube([1, 1, 4.8]);

translate([47, 35, 0]) cube([1, 1, 4.7]);

translate([0, 36, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 36, 0]) cube([1, 1, 6]);

translate([16, 36, 0]) cube([1, 1, 6.6]);

translate([17, 36, 0]) cube([1, 1, 6.8]);

translate([18, 36, 0]) cube([1, 1, 7.0]);

translate([19, 36, 0]) cube([1, 1, 7.1]);

translate([20, 36, 0]) cube([1, 1, 7.1]);

translate([21, 36, 0]) cube([1, 1, 7.1]);

translate([22, 36, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([23, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 36, 0]) cube([1, 1, 6]);

translate([40, 36, 0]) cube([1, 1, 5.4]);

translate([41, 36, 0]) cube([1, 1, 5.4]);

translate([42, 36, 0]) cube([1, 1, 5.3]);

translate([43, 36, 0]) cube([1, 1, 5.1]);

translate([44, 36, 0]) cube([1, 1, 4.9]);

translate([45, 36, 0]) cube([1, 1, 4.8]);

translate([46, 36, 0]) cube([1, 1, 4.7]);

translate([47, 36, 0]) cube([1, 1, 4.6]);

color([0,1,0])
translate([0, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 37, 0]) cube([1, 1, 6]);

translate([16, 37, 0]) cube([1, 1, 6.7]);

translate([17, 37, 0]) cube([1, 1, 7.0]);

translate([18, 37, 0]) cube([1, 1, 7.2]);

translate([19, 37, 0]) cube([1, 1, 7.2]);

translate([20, 37, 0]) cube([1, 1, 7.2]);

translate([21, 37, 0]) cube([1, 1, 7.0]);

translate([22, 37, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([23, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 37, 0]) cube([1, 1, 6]);

translate([38, 37, 0]) cube([1, 1, 5.4]);

translate([39, 37, 0]) cube([1, 1, 5.4]);

translate([40, 37, 0]) cube([1, 1, 5.4]);

translate([41, 37, 0]) cube([1, 1, 5.3]);

translate([42, 37, 0]) cube([1, 1, 5.2]);

translate([43, 37, 0]) cube([1, 1, 5.1]);

translate([44, 37, 0]) cube([1, 1, 4.9]);

translate([45, 37, 0]) cube([1, 1, 4.7]);

translate([46, 37, 0]) cube([1, 1, 4.6]);

translate([47, 37, 0]) cube([1, 1, 4.5]);

color([0,1,0])
translate([0, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 38, 0]) cube([1, 1, 6]);

translate([15, 38, 0]) cube([1, 1, 6.6]);

translate([16, 38, 0]) cube([1, 1, 6.8]);

translate([17, 38, 0]) cube([1, 1, 7.0]);

translate([18, 38, 0]) cube([1, 1, 7.2]);

translate([19, 38, 0]) cube([1, 1, 7.2]);

translate([20, 38, 0]) cube([1, 1, 7.1]);

translate([21, 38, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([22, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 38, 0]) cube([1, 1, 6]);

translate([37, 38, 0]) cube([1, 1, 5.4]);

translate([38, 38, 0]) cube([1, 1, 5.4]);

translate([39, 38, 0]) cube([1, 1, 5.4]);

translate([40, 38, 0]) cube([1, 1, 5.4]);

translate([41, 38, 0]) cube([1, 1, 5.4]);

translate([42, 38, 0]) cube([1, 1, 5.3]);

translate([43, 38, 0]) cube([1, 1, 5.1]);

translate([44, 38, 0]) cube([1, 1, 5.0]);

translate([45, 38, 0]) cube([1, 1, 4.8]);

translate([46, 38, 0]) cube([1, 1, 4.6]);

translate([47, 38, 0]) cube([1, 1, 4.5]);

color([0,1,0])
translate([0, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 39, 0]) cube([1, 1, 6]);

translate([15, 39, 0]) cube([1, 1, 6.7]);

translate([16, 39, 0]) cube([1, 1, 6.8]);

translate([17, 39, 0]) cube([1, 1, 6.9]);

translate([18, 39, 0]) cube([1, 1, 7.0]);

translate([19, 39, 0]) cube([1, 1, 7.0]);

translate([20, 39, 0]) cube([1, 1, 6.8]);

translate([21, 39, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([22, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 39, 0]) cube([1, 1, 6]);

translate([37, 39, 0]) cube([1, 1, 5.4]);

translate([38, 39, 0]) cube([1, 1, 5.4]);

translate([39, 39, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([40, 39, 0]) cube([1, 1, 6]);

translate([41, 39, 0]) cube([1, 1, 5.4]);

translate([42, 39, 0]) cube([1, 1, 5.4]);

translate([43, 39, 0]) cube([1, 1, 5.3]);

translate([44, 39, 0]) cube([1, 1, 5.2]);

translate([45, 39, 0]) cube([1, 1, 5.0]);

translate([46, 39, 0]) cube([1, 1, 4.8]);

translate([47, 39, 0]) cube([1, 1, 4.6]);

color([0,1,0])
translate([0, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 40, 0]) cube([1, 1, 6]);

translate([14, 40, 0]) cube([1, 1, 6.6]);

translate([15, 40, 0]) cube([1, 1, 6.7]);

translate([16, 40, 0]) cube([1, 1, 6.8]);

translate([17, 40, 0]) cube([1, 1, 6.8]);

translate([18, 40, 0]) cube([1, 1, 6.8]);

translate([19, 40, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([20, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 40, 0]) cube([1, 1, 6]);

translate([45, 40, 0]) cube([1, 1, 5.3]);

translate([46, 40, 0]) cube([1, 1, 5.1]);

translate([47, 40, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 41, 0]) cube([1, 1, 6]);

translate([14, 41, 0]) cube([1, 1, 6.7]);

translate([15, 41, 0]) cube([1, 1, 6.7]);

translate([16, 41, 0]) cube([1, 1, 6.6]);

translate([17, 41, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([18, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 41, 0]) cube([1, 1, 6]);

translate([47, 41, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([0, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 42, 0]) cube([1, 1, 6]);

translate([40, 42, 0]) cube([1, 1, 5.4]);

translate([41, 42, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([42, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 42, 0]) cube([1, 1, 6]);

translate([47, 42, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([0, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 43, 0]) cube([1, 1, 6]);

translate([39, 43, 0]) cube([1, 1, 5.4]);

translate([40, 43, 0]) cube([1, 1, 5.3]);

translate([41, 43, 0]) cube([1, 1, 5.3]);

translate([42, 43, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([43, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 44, 0]) cube([1, 1, 6]);

translate([7, 44, 0]) cube([1, 1, 5.4]);

translate([8, 44, 0]) cube([1, 1, 5.3]);

translate([9, 44, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([10, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 44, 0]) cube([1, 1, 6]);

translate([33, 44, 0]) cube([1, 1, 5.4]);

translate([34, 44, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([35, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 44, 0]) cube([1, 1, 6]);

translate([38, 44, 0]) cube([1, 1, 5.4]);

translate([39, 44, 0]) cube([1, 1, 5.4]);

translate([40, 44, 0]) cube([1, 1, 5.3]);

translate([41, 44, 0]) cube([1, 1, 5.3]);

translate([42, 44, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([43, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 45, 0]) cube([1, 1, 6]);

translate([1, 45, 0]) cube([1, 1, 5.4]);

translate([2, 45, 0]) cube([1, 1, 5.4]);

translate([3, 45, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([4, 45, 0]) cube([1, 1, 6]);

translate([5, 45, 0]) cube([1, 1, 5.4]);

translate([6, 45, 0]) cube([1, 1, 5.3]);

translate([7, 45, 0]) cube([1, 1, 5.2]);

translate([8, 45, 0]) cube([1, 1, 5.1]);

translate([9, 45, 0]) cube([1, 1, 5.1]);

translate([10, 45, 0]) cube([1, 1, 5.2]);

translate([11, 45, 0]) cube([1, 1, 5.3]);

translate([12, 45, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([13, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 45, 0]) cube([1, 1, 6]);

translate([16, 45, 0]) cube([1, 1, 5.4]);

translate([17, 45, 0]) cube([1, 1, 5.3]);

translate([18, 45, 0]) cube([1, 1, 5.2]);

translate([19, 45, 0]) cube([1, 1, 5.2]);

translate([20, 45, 0]) cube([1, 1, 5.3]);

translate([21, 45, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([22, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 45, 0]) cube([1, 1, 6]);

translate([32, 45, 0]) cube([1, 1, 5.4]);

translate([33, 45, 0]) cube([1, 1, 5.3]);

translate([34, 45, 0]) cube([1, 1, 5.3]);

translate([35, 45, 0]) cube([1, 1, 5.4]);

translate([36, 45, 0]) cube([1, 1, 5.4]);

translate([37, 45, 0]) cube([1, 1, 5.4]);

translate([38, 45, 0]) cube([1, 1, 5.4]);

translate([39, 45, 0]) cube([1, 1, 5.3]);

translate([40, 45, 0]) cube([1, 1, 5.3]);

translate([41, 45, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([42, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 45, 0]) cube([1, 1, 6]);

translate([0, 46, 0]) cube([1, 1, 5.3]);

translate([1, 46, 0]) cube([1, 1, 5.3]);

translate([2, 46, 0]) cube([1, 1, 5.3]);

translate([3, 46, 0]) cube([1, 1, 5.3]);

translate([4, 46, 0]) cube([1, 1, 5.3]);

translate([5, 46, 0]) cube([1, 1, 5.3]);

translate([6, 46, 0]) cube([1, 1, 5.2]);

translate([7, 46, 0]) cube([1, 1, 5.1]);

translate([8, 46, 0]) cube([1, 1, 5.0]);

translate([9, 46, 0]) cube([1, 1, 4.9]);

translate([10, 46, 0]) cube([1, 1, 5.0]);

translate([11, 46, 0]) cube([1, 1, 5.1]);

translate([12, 46, 0]) cube([1, 1, 5.2]);

translate([13, 46, 0]) cube([1, 1, 5.2]);

translate([14, 46, 0]) cube([1, 1, 5.2]);

translate([15, 46, 0]) cube([1, 1, 5.1]);

translate([16, 46, 0]) cube([1, 1, 5.0]);

translate([17, 46, 0]) cube([1, 1, 4.9]);

translate([18, 46, 0]) cube([1, 1, 4.8]);

translate([19, 46, 0]) cube([1, 1, 4.9]);

translate([20, 46, 0]) cube([1, 1, 5.0]);

translate([21, 46, 0]) cube([1, 1, 5.2]);

translate([22, 46, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([23, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 46, 0]) cube([1, 1, 6]);

translate([32, 46, 0]) cube([1, 1, 5.4]);

translate([33, 46, 0]) cube([1, 1, 5.2]);

translate([34, 46, 0]) cube([1, 1, 5.2]);

translate([35, 46, 0]) cube([1, 1, 5.2]);

translate([36, 46, 0]) cube([1, 1, 5.2]);

translate([37, 46, 0]) cube([1, 1, 5.3]);

translate([38, 46, 0]) cube([1, 1, 5.3]);

translate([39, 46, 0]) cube([1, 1, 5.3]);

translate([40, 46, 0]) cube([1, 1, 5.3]);

translate([41, 46, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([42, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 46, 0]) cube([1, 1, 6]);

translate([0, 47, 0]) cube([1, 1, 5.2]);

translate([1, 47, 0]) cube([1, 1, 5.1]);

translate([2, 47, 0]) cube([1, 1, 5.1]);

translate([3, 47, 0]) cube([1, 1, 5.2]);

translate([4, 47, 0]) cube([1, 1, 5.2]);

translate([5, 47, 0]) cube([1, 1, 5.2]);

translate([6, 47, 0]) cube([1, 1, 5.1]);

translate([7, 47, 0]) cube([1, 1, 5.0]);

translate([8, 47, 0]) cube([1, 1, 4.9]);

translate([9, 47, 0]) cube([1, 1, 4.8]);

translate([10, 47, 0]) cube([1, 1, 4.8]);

translate([11, 47, 0]) cube([1, 1, 4.9]);

translate([12, 47, 0]) cube([1, 1, 5.0]);

translate([13, 47, 0]) cube([1, 1, 5.0]);

translate([14, 47, 0]) cube([1, 1, 5.0]);

translate([15, 47, 0]) cube([1, 1, 4.9]);

translate([16, 47, 0]) cube([1, 1, 4.7]);

translate([17, 47, 0]) cube([1, 1, 4.6]);

translate([18, 47, 0]) cube([1, 1, 4.5]);

translate([19, 47, 0]) cube([1, 1, 4.6]);

translate([20, 47, 0]) cube([1, 1, 4.8]);

translate([21, 47, 0]) cube([1, 1, 5.0]);

translate([22, 47, 0]) cube([1, 1, 5.2]);

translate([23, 47, 0]) cube([1, 1, 5.2]);

translate([24, 47, 0]) cube([1, 1, 5.2]);

translate([25, 47, 0]) cube([1, 1, 5.3]);

translate([26, 47, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([27, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 47, 0]) cube([1, 1, 6]);

translate([32, 47, 0]) cube([1, 1, 5.3]);

translate([33, 47, 0]) cube([1, 1, 5.1]);

translate([34, 47, 0]) cube([1, 1, 5.1]);

translate([35, 47, 0]) cube([1, 1, 5.1]);

translate([36, 47, 0]) cube([1, 1, 5.1]);

translate([37, 47, 0]) cube([1, 1, 5.2]);

translate([38, 47, 0]) cube([1, 1, 5.2]);

translate([39, 47, 0]) cube([1, 1, 5.3]);

translate([40, 47, 0]) cube([1, 1, 5.3]);

translate([41, 47, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([42, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 47, 0]) cube([1, 1, 6]);

translate([46, 47, 0]) cube([1, 1, 5.4]);

translate([47, 47, 0]) cube([1, 1, 5.3]);
