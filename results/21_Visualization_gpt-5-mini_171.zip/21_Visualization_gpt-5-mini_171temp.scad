
hull() {
    translate([84.9823, 50.0493, 94.98485]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.66369999999999, 50.9367, 94.71215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.6289, 51.03525, 94.6819]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.32110000000002, 51.921749999999996, 94.4101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.28750000000001, 52.020199999999996, 94.37995]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.9905, 52.9058, 94.10905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.9581, 53.00415, 94.07895]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.67190000000001, 53.888850000000005, 93.80805000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.64070000000001, 53.98705, 93.778]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.3653, 54.869949999999996, 93.508]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.3353, 54.967949999999995, 93.478]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.0707, 55.849050000000005, 93.208]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.04195, 55.94690000000001, 93.17805]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.78905, 56.8271, 92.90895]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.76155, 56.92475, 92.87910000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.51945, 57.80225, 92.61090000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.49315000000001, 57.89965, 92.5811]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.26185000000001, 58.77535, 92.3129]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.2368, 58.872550000000004, 92.28315]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.0172, 59.74645, 92.01585000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.99340000000001, 59.843450000000004, 91.98615000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.7846, 60.71555000000001, 91.71884999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.76204999999999, 60.81230000000001, 91.6892]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.56495, 61.68169999999999, 91.4228]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.54365, 61.7782, 91.39320000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.35735, 62.64580000000001, 91.1268]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.33725, 62.742050000000006, 91.09725]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.16175, 63.606950000000005, 90.83175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.1429, 63.70290000000001, 90.80229999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.9791, 64.5651, 90.53769999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.9615, 64.66075, 90.50835]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.8085, 65.52025, 90.24465000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.7921, 65.6156, 90.21535]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.6499, 66.4724, 89.95165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.63475, 66.56739999999999, 89.9224]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.50425, 67.42060000000001, 89.6596]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.49034999999999, 67.51525000000001, 89.63045]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.37065, 68.36575, 89.36855]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.358, 68.4601, 89.33945]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.25, 69.3079, 89.07755]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.2386, 69.40190000000001, 89.04855]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.1414, 70.24610000000001, 88.78845000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.13125, 70.33970000000001, 88.75955]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.04575, 71.18030000000002, 88.49945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.03685, 71.27350000000001, 88.4706]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.96215, 72.1105, 88.21140000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.95445, 72.2033, 88.18265000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.89055, 73.0367, 87.92435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.88405, 73.12915, 87.8957]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.83095, 73.95985, 87.6383]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.82565000000001, 74.0519, 87.60969999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.78335000000001, 74.8781, 87.35229999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.7793, 74.9697, 87.32374999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.7487, 75.7923, 87.06725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.74585, 75.8835, 87.03880000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.72515000000001, 76.7025, 86.78320000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.72345000000001, 76.79325, 86.7548]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.71355, 77.60775000000001, 86.4992]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.71305, 77.69805000000001, 86.47085]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.71395, 78.50895, 86.21615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.71464999999999, 78.59885, 86.1879]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.72635, 79.40615, 85.9341]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.72825, 79.4956, 85.90595]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.75075, 80.2984, 85.65305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.75385, 80.3874, 85.62495]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.78715000000001, 81.1866, 85.37205000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.79140000000001, 81.27515, 85.34405000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.83460000000001, 82.06985, 85.09295]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.84, 82.15790000000001, 85.06505]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.894, 82.94810000000001, 84.81394999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.90060000000001, 83.0357, 84.78609999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.9654, 83.8223, 84.5359]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.97319999999999, 83.90944999999999, 84.50815]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.0488, 84.69154999999999, 84.25885000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.05775, 84.7782, 84.23115000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.14325, 85.5558, 83.98185000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.15335, 85.64195000000001, 83.95425]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.24965, 86.41505000000001, 83.70675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.2609, 86.50070000000001, 83.67925]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.36710000000001, 87.2693, 83.43175000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.37950000000001, 87.3544, 83.40430000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.49650000000001, 88.1176, 83.15770000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.51010000000001, 88.20214999999999, 83.13030000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.6379, 88.96085, 82.88370000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.65265, 89.0448, 82.85640000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.79035, 89.7972, 82.6116]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.80625, 89.88055000000001, 82.5844]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.95474999999999, 90.62845000000002, 82.3396]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.97179999999999, 90.71130000000001, 82.31245]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.13019999999999, 91.4547, 82.06855]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.14835, 91.53695, 82.04150000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.31665, 92.27405, 81.79849999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.33595, 92.35565, 81.77154999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.51505, 93.08735, 81.52945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.5355, 93.1683, 81.50255]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.72449999999999, 93.8937, 81.26044999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.7461, 93.974, 81.23365]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.9459, 94.694, 80.99335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.96865, 94.7736, 80.96665]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.17835000000001, 95.4864, 80.72635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.20225, 95.5653, 80.6997]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.42275000000001, 96.2727, 80.46030000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.4478, 96.35090000000001, 80.43375000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.6782, 97.0511, 80.19525000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.7044, 97.1286, 80.1688]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.9456, 97.8234, 79.9312]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.97295, 97.90015, 79.90480000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.22405, 98.58685, 79.6672]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.25255000000001, 98.6628, 79.64089999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.51445000000001, 99.34320000000001, 79.40509999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.5441, 99.41195, 79.3789]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.8159, 99.96905, 79.1431]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.831, 100.0, 79.0735]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.831, 100.0, 78.0565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.82645000000001, 99.9574, 77.949]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.74455, 99.19059999999999, 77.031]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.73145, 99.10145, 76.93]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.57755, 98.26355000000001, 76.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.55655, 98.17160000000001, 75.93100000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.33245, 97.35440000000001, 75.049]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.30365, 97.26480000000001, 74.952]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.00935, 96.4692, 74.08800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.97269999999999, 96.3822, 73.99300000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.6073, 95.6118, 73.14699999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.56285, 95.52770000000001, 73.05399999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.12815, 94.7843, 72.226]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.07600000000001, 94.70339999999999, 72.135]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.572, 93.9906, 71.325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.5122, 93.91324999999999, 71.236]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.9398, 93.23375, 70.444]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.8724, 93.16025, 70.357]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.2316, 92.51675, 69.583]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.15665, 92.4475, 69.498]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.44835, 91.84450000000001, 68.742]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.36590000000001, 91.77980000000001, 68.659]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.5901, 91.2182, 67.92099999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.5002, 91.15825, 67.84]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.65780000000001, 90.64075, 67.12]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.56055, 90.5859, 67.041]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.65245, 90.1161, 66.339]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.5479, 90.06655, 66.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.5741, 89.64445, 65.578]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.46235, 89.60040000000001, 65.503]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.42465, 89.2296, 64.837]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.30585, 89.1914, 64.764]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.20515000000002, 88.8746, 64.116]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.07930000000002, 88.8425, 64.045]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.9147, 88.58149999999999, 63.415000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.7819, 88.55574999999999, 63.346000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.5561, 88.35325, 62.73400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.4166, 88.33415000000001, 62.66700000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.1314, 88.19285, 62.073]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.98535000000001, 88.18075, 62.007999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.64165, 88.10425, 61.432]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.48925, 88.09944999999999, 61.369]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.08975000000001, 88.08955, 60.81100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.9312, 88.09225, 60.75000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.4768, 88.15075, 60.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.31230000000001, 88.1611, 60.150999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.8057, 88.28890000000001, 59.629000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.63555, 88.307, 59.572]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.07945, 88.505, 59.068000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.904, 88.53095, 59.013000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.302, 88.80005, 58.527]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.12155, 88.8339, 58.474]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.47545, 89.17410000000001, 58.00599999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.290350000000004, 89.21585, 57.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.60465000000001, 89.62715, 57.504999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.415350000000004, 89.6769, 57.456]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.69365, 90.1611, 57.024]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.5005, 90.21895, 56.977000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.74550000000001, 90.77605000000001, 56.563]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.548950000000005, 90.84205000000001, 56.518]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.76605000000001, 91.47295, 56.122]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.56655000000001, 91.54719999999999, 56.079]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.75845, 92.25280000000001, 55.701]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.556400000000004, 92.3353, 55.660000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.7276, 93.1147, 55.300000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.52355, 93.2055, 55.261]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.679449999999996, 94.0605, 54.919]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.474, 94.15965000000001, 54.882]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.620000000000005, 95.08935000000001, 54.558]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.41375000000001, 95.19685000000001, 54.522999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.55525, 96.20215, 54.217]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.3488, 96.318, 54.184000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.4912, 97.398, 53.89600000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.2851, 97.52215, 53.86500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.432900000000004, 98.67685, 53.595]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.2277, 98.80395, 53.566]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.3863, 99.93705, 53.314]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.2198, 99.95, 53.235]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.0642, 99.05000000000001, 52.065000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.025, 98.92500000000001, 51.925000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.475, 97.575, 50.575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.535, 97.425, 50.425000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.165000000000006, 96.075, 49.075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.245000000000005, 95.92500000000001, 48.93]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.055, 94.575, 47.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.155, 94.425, 47.535000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.145, 93.075, 46.365]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.265, 92.925, 46.24]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.435, 91.575, 45.160000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.575, 91.42500000000001, 45.045]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.925000000000004, 90.075, 44.055]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.085, 89.925, 43.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.615, 88.575, 43.050000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.795, 88.42500000000001, 42.955000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.505, 87.075, 42.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.705000000000005, 86.925, 42.06]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.595000000000006, 85.575, 41.34]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.815000000000005, 85.425, 41.265]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.885, 84.075, 40.635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.125, 83.92500000000001, 40.57]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.375, 82.575, 40.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.575, 82.425, 39.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.925, 81.075, 39.525000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.075, 80.92500000000001, 39.48500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.425000000000004, 79.575, 39.215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.575, 79.425, 39.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.925000000000004, 78.075, 39.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.075, 77.925, 38.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.425000000000004, 76.575, 38.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.575, 76.42500000000001, 38.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.925, 75.075, 38.9]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.075, 74.925, 38.905]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.425, 73.575, 38.995000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.575, 73.42500000000001, 39.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.925000000000004, 72.075, 39.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.075, 71.925, 39.215]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.425000000000004, 70.575, 39.48500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.575, 70.425, 39.52]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.925000000000004, 69.075, 39.879999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.075, 68.925, 39.925]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.425, 67.575, 40.375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.575, 67.425, 40.43]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.925, 66.075, 40.97]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.05, 65.925, 41.035]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.95, 64.575, 41.665]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.03999999999999, 64.42500000000001, 41.74]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.75999999999999, 63.075, 42.46]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.83, 62.925000000000004, 42.54]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.37, 61.575, 43.26]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.42, 61.425000000000004, 43.345]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.78, 60.075, 44.155]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.81, 59.925, 44.245000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.99000000000001, 58.575, 45.05500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.0, 58.425, 45.145]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.0, 57.075, 45.955]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.99000000000001, 56.925000000000004, 46.045]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.81, 55.575, 46.855000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.78, 55.425000000000004, 46.945]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.42, 54.075, 47.754999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.37, 53.925000000000004, 47.839999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.83, 52.575, 48.56]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.75999999999999, 52.425, 48.635000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.03999999999999, 51.075, 49.265]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.95, 50.925, 49.334999999999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.05, 49.575, 49.965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.94, 49.425000000000004, 50.03]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.86, 48.075, 50.57]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.730000000000004, 47.925000000000004, 50.625]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.47, 46.575, 51.075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.31999999999999, 46.425000000000004, 51.120000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.879999999999995, 45.075, 51.480000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.71, 44.925, 51.515]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.09, 43.574999999999996, 51.785]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.900000000000006, 43.425, 51.809999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.10000000000001, 42.075, 51.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.89, 41.925000000000004, 52.005]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.91, 40.575, 52.095]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.68, 40.425000000000004, 52.1]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.519999999999996, 39.075, 52.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.28, 38.925000000000004, 52.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.120000000000005, 37.575, 52.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.88, 37.425, 51.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.720000000000006, 36.074999999999996, 51.809999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.480000000000004, 35.925, 51.785]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.32000000000001, 34.575, 51.515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.08500000000001, 34.425, 51.480000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.015, 33.075, 51.120000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.79, 32.925, 51.075]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.81, 31.575000000000003, 50.625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.605000000000004, 31.425, 50.57]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.895, 30.075, 50.03]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.72, 29.925, 49.965]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.28, 28.575000000000003, 49.334999999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.135000000000005, 28.425000000000004, 49.26]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.965, 27.075000000000003, 48.54]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.85, 26.925, 48.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.95, 25.575, 47.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.865, 25.425, 47.550000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.23500000000001, 24.075000000000003, 46.650000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.18000000000001, 23.925, 46.545]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.82, 22.575, 45.555]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.795, 22.425, 45.440000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.705, 21.075000000000003, 44.36]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.71, 20.925, 44.235]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.89, 19.575, 43.065000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.925, 19.425, 42.93]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.375, 18.075, 41.67]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.44, 17.925, 41.525000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.160000000000004, 16.575, 40.175000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.255, 16.425, 40.02]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.245000000000005, 15.075, 38.58]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.365, 14.925, 38.415]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.535000000000004, 13.575000000000001, 36.885]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.675000000000004, 13.425, 36.709999999999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.025000000000006, 12.075000000000001, 35.09]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.185, 11.925, 34.905]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.714999999999996, 10.575000000000001, 33.195]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.894999999999996, 10.425, 33.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.605000000000004, 9.075, 31.200000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.80500000000001, 8.924999999999999, 30.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.695, 7.575, 29.105]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.915, 7.425, 28.89]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.985, 6.075, 26.91]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.225, 5.925000000000001, 26.685000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.475, 4.575, 24.615000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.735, 4.425, 24.380000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.165, 3.075, 22.22]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.445, 2.9250000000000003, 21.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.05500000000001, 1.5750000000000002, 19.725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.355000000000004, 1.425, 19.47]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.144999999999996, 0.07500000000000001, 17.130000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.385, 0.0, 16.650000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.915, 0.0, 10.35]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0, 0.0, 9.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.0, 0.0, 5.25]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.975, 0.025, 4.875]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.525000000000006, 0.47500000000000003, 2.625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.47500000000001, 0.525, 2.425]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.025000000000006, 0.9750000000000001, 1.075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.975, 1.025, 0.9750000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.525, 1.475, 0.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.475, 1.5250000000000001, 0.485]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.025000000000006, 1.975, 0.21500000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.975, 2.025, 0.19500000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.525, 2.475, 0.10500000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.475, 2.525, 0.09500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.025000000000006, 2.975, 0.005000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}

