
hull() {
    translate([10.0, 10.06, 94.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 11.14, 94.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 11.26, 94.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 12.34, 93.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 12.46, 93.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 13.540000000000001, 92.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 13.66, 92.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 14.74, 91.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 14.86, 91.76]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 15.940000000000001, 91.04]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 16.060000000000002, 90.96000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 17.14, 90.24000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 17.26, 90.16000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 18.34, 89.44000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 18.459999999999997, 89.36000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 19.54, 88.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 19.66, 88.55999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 20.740000000000002, 87.83999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 20.860000000000003, 87.75999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 21.94, 87.03999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 22.060000000000002, 86.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 23.14, 86.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 23.259999999999998, 86.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 24.34, 85.44000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 24.46, 85.36000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 25.540000000000003, 84.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 25.660000000000004, 84.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 26.740000000000002, 83.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 26.86, 83.76]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 27.939999999999998, 83.04]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 28.06, 82.96000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 29.14, 82.24000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 29.26, 82.16000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 30.34, 81.44000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 30.46, 81.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 31.540000000000003, 80.63999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 31.660000000000004, 80.55999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 32.74, 79.83999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 32.86, 79.75999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 33.94, 79.04]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 34.06, 78.96000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 35.14, 78.24000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 35.260000000000005, 78.16000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 36.339999999999996, 77.44000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 36.46, 77.36000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 37.540000000000006, 76.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 37.660000000000004, 76.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 38.74, 75.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 38.86, 75.76]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 39.94, 75.04]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 40.06, 74.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 41.14000000000001, 74.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 41.260000000000005, 74.16]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 42.339999999999996, 73.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 42.459999999999994, 73.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 43.54, 72.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 43.660000000000004, 72.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 44.74, 71.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 44.86, 71.76]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 45.94, 71.03999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 46.06, 70.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 47.14, 70.24000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 47.260000000000005, 70.16000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 48.34, 69.44000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 48.46, 69.36000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 49.54, 68.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 49.660000000000004, 68.55999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 50.74, 67.83999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 50.86, 67.75999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 51.940000000000005, 67.04]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 52.06, 66.96000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 53.14, 66.24000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 53.260000000000005, 66.16000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 54.34, 65.44000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 54.46, 65.36000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 55.54, 64.63999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 55.66, 64.55999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 56.739999999999995, 63.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 56.86, 63.760000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 57.940000000000005, 63.040000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 58.06, 62.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 59.14, 62.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 59.260000000000005, 62.160000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 60.34, 61.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 60.46, 61.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 61.540000000000006, 60.64]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 61.660000000000004, 60.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 62.739999999999995, 59.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 62.86, 59.76]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 63.94, 59.04]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 64.06, 58.96]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 65.14, 58.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 65.26, 58.160000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 66.34, 57.44]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 66.46000000000001, 57.36]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 67.53999999999999, 56.64000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 67.66, 56.56]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 68.74, 55.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 68.86, 55.76]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 69.94, 55.04]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.005, 70.075, 55.005]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.095, 71.42500000000001, 55.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.105, 71.57000000000001, 55.115]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.195, 72.83000000000001, 55.385]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.205, 72.97000000000001, 55.435]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.295000000000002, 74.23, 56.065000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.305000000000001, 74.36500000000001, 56.150000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.395000000000001, 75.535, 57.05]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.405000000000001, 75.66, 57.160000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.495000000000001, 76.74000000000001, 58.24]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.505, 76.855, 58.375]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.594999999999999, 77.84500000000001, 59.725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.604999999999999, 77.94500000000001, 59.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.694999999999999, 78.755, 61.415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.704999999999998, 78.83500000000001, 61.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.795, 79.465, 63.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.805000000000001, 79.52499999999999, 63.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.895000000000001, 79.975, 65.00999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.905000000000001, 80.01, 65.195]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.995000000000001, 80.19000000000001, 66.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.005, 80.19000000000001, 67.095]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.095, 80.01, 68.805]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.105, 79.975, 68.99000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.195, 79.52499999999999, 70.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.205, 79.465, 70.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.295000000000002, 78.83500000000001, 72.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.305000000000001, 78.755, 72.585]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.395, 77.94500000000001, 74.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.405, 77.84500000000001, 74.275]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.495, 76.855, 75.62500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.504999999999999, 76.74000000000001, 75.76]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.594999999999999, 75.66, 76.84]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.604999999999999, 75.535, 76.95]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.694999999999999, 74.36500000000001, 77.85000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.705, 74.23, 77.93500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.795000000000002, 72.97000000000001, 78.565]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.805000000000001, 72.83000000000001, 78.615]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.895000000000001, 71.57000000000001, 78.885]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.905000000000001, 71.42500000000001, 78.905]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.995000000000001, 70.075, 78.995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.005, 69.925, 78.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.095, 68.575, 78.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.105, 68.42999999999999, 78.885]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.195, 67.16999999999999, 78.615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.205, 67.03, 78.565]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.295, 65.77000000000001, 77.93500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.305, 65.635, 77.85000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.395, 64.465, 76.95]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.405000000000001, 64.34, 76.84]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.495000000000001, 63.260000000000005, 75.76]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.505, 63.145, 75.62500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.595, 62.155, 74.275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.605, 62.055, 74.115]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.695, 61.245000000000005, 72.585]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.705, 61.165000000000006, 72.41]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.795000000000002, 60.535000000000004, 70.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.805000000000001, 60.475, 70.61]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.895000000000001, 60.025, 68.99000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.905000000000001, 59.99, 68.805]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.995000000000001, 59.81, 67.095]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.005, 59.81, 66.905]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.094999999999999, 59.99, 65.195]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.104999999999999, 60.025, 65.00999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.194999999999999, 60.475, 63.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.204999999999998, 60.535000000000004, 63.21]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.295000000000002, 61.165000000000006, 61.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.305000000000001, 61.245000000000005, 61.415]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.395000000000001, 62.055, 59.885]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.405000000000001, 62.155, 59.725]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.495000000000001, 63.145, 58.375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.505, 63.260000000000005, 58.24]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.595, 64.34, 57.160000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.605, 64.465, 57.05]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.695, 65.635, 56.150000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.705, 65.77000000000001, 56.065000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.795000000000002, 67.03, 55.435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.805000000000001, 67.16999999999999, 55.385]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.895, 68.42999999999999, 55.115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.905, 68.575, 55.095000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.995, 69.925, 55.005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.075, 69.99, 54.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.425, 69.81, 54.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.575000000000001, 69.785, 54.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.925, 69.515, 54.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.075, 69.47500000000001, 54.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.425, 69.025, 54.410000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.575000000000003, 68.965, 54.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.925, 68.335, 54.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.075, 68.26, 54.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.425, 67.54, 54.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.575000000000003, 67.45, 53.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.925, 66.55, 53.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.075, 66.44, 53.790000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.425, 65.36, 53.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.575000000000003, 65.235, 53.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.925000000000004, 64.065, 53.410000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.075000000000003, 63.925000000000004, 53.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.425, 62.575, 53.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.575, 62.42, 53.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.925, 60.980000000000004, 53.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.075000000000003, 60.815000000000005, 52.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.425, 59.285000000000004, 52.809999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.575, 59.11, 52.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.925, 57.489999999999995, 52.61000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.075, 57.305, 52.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.425000000000004, 55.595000000000006, 52.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.575, 55.400000000000006, 52.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.925, 53.6, 52.21000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.075, 53.4, 52.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.425000000000004, 51.6, 52.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.575, 51.395, 51.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.925000000000004, 49.505, 51.809999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.075, 49.295, 51.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.425000000000004, 47.405, 51.61000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.575, 47.19, 51.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.925, 45.21, 51.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.074999999999996, 44.99, 51.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.425, 43.01, 51.21000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.575, 42.79, 51.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.925000000000004, 40.81, 51.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.075, 40.59, 50.989999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.425000000000004, 38.61, 50.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.575, 38.39, 50.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.925000000000004, 36.410000000000004, 50.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.075, 36.190000000000005, 50.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.425, 34.21, 50.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.575, 33.995000000000005, 50.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.925, 32.105000000000004, 50.21000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.075, 31.900000000000002, 50.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.425000000000004, 30.1, 50.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.575, 29.9, 49.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.925000000000004, 28.1, 49.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.075, 27.905, 49.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.425000000000004, 26.195, 49.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.575, 26.01, 49.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.925, 24.39, 49.410000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.075, 24.215, 49.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.425, 22.685000000000002, 49.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.575, 22.520000000000003, 49.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.925000000000004, 21.080000000000002, 49.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.075, 20.925, 48.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.425000000000004, 19.575, 48.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.575, 19.435000000000002, 48.790000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.925000000000004, 18.265, 48.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.075, 18.14, 48.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.425, 17.060000000000002, 48.410000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.575, 16.95, 48.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.925, 16.05, 48.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.075, 15.955, 48.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.425, 15.145, 48.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.575, 15.065, 47.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.925, 14.435, 47.809999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.075, 14.375, 47.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.42500000000001, 13.925, 47.61000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.575, 13.885, 47.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.925, 13.615, 47.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.075, 13.595, 47.38999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.425, 13.505, 47.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.575, 13.505, 47.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.92500000000001, 13.595, 47.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.075, 13.615, 46.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.425, 13.885, 46.809999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.575, 13.925, 46.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.925, 14.375, 46.61000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.075, 14.435, 46.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.42500000000001, 15.065, 46.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.575, 15.145, 46.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.925, 15.955, 46.21000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.075, 16.055, 46.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.42500000000001, 17.045, 46.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.575, 17.165000000000003, 45.989999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.925, 18.334999999999997, 45.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.075, 18.474999999999998, 45.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.425, 19.825, 45.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.575, 19.985, 45.589999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.92500000000001, 21.515, 45.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.075, 21.695, 45.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.425, 23.405, 45.21000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.575, 23.605000000000004, 45.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.92500000000001, 25.495000000000005, 45.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.06500000000001, 25.660000000000004, 44.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.235, 26.740000000000002, 44.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.36, 26.865000000000002, 44.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.44000000000001, 28.035000000000004, 44.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.555, 28.17, 44.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.545, 29.43, 44.410000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.65, 29.57, 44.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.55, 30.83, 44.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.645, 30.974999999999998, 44.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.455, 32.325, 44.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.53999999999999, 32.475, 43.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.25999999999999, 33.824999999999996, 43.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.335, 33.98, 43.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.965, 35.42, 43.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.03, 35.58, 43.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.57, 37.02, 43.410000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.625, 37.18, 43.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.075, 38.620000000000005, 43.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.12, 38.785000000000004, 43.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.48, 40.315, 43.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.515, 40.485, 42.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.785, 42.015, 42.809999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.81, 42.185, 42.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.99000000000001, 43.715, 42.61000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.005, 43.885000000000005, 42.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.095, 45.415000000000006, 42.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.1, 45.585, 42.38999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.1, 47.115, 42.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.095, 47.285000000000004, 42.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.005, 48.815, 42.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.99000000000001, 48.985, 41.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.81, 50.515, 41.809999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.785, 50.685, 41.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.515, 52.215, 41.61000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.48, 52.385, 41.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.12, 53.915, 41.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.075, 54.085, 41.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.625, 55.615, 41.21000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.57, 55.78, 41.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.03, 57.22, 41.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.965, 57.38, 40.989999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.335, 58.82, 40.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.25999999999999, 58.98, 40.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.53999999999999, 60.42, 40.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.455, 60.580000000000005, 40.589999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.645, 62.02, 40.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.55, 62.175, 40.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.65, 63.525000000000006, 40.21000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.545, 63.675000000000004, 40.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.555, 65.02499999999999, 40.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.44000000000001, 65.17, 39.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.36, 66.43, 39.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.235, 66.57000000000001, 39.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.06500000000001, 67.83000000000001, 39.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.935, 67.965, 39.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.765, 69.135, 39.410000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.63000000000001, 69.265, 39.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.37, 70.435, 39.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.225, 70.56, 39.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.875, 71.64, 39.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.725, 71.755, 38.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.375, 72.74499999999999, 38.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.22, 72.85499999999999, 38.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.78, 73.845, 38.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.62, 73.95, 38.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.18, 74.85000000000001, 38.410000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.015, 74.94500000000001, 38.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.485, 75.755, 38.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.315, 75.84, 38.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.785, 76.56, 38.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.615, 76.63499999999999, 37.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.085, 77.26499999999999, 37.809999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.91, 77.335, 37.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.29, 77.965, 37.61000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.11000000000001, 78.03, 37.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.49000000000001, 78.57, 37.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.31, 78.625, 37.38999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.69, 79.075, 37.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.50999999999999, 79.12, 37.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.89, 79.47999999999999, 37.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.71, 79.515, 36.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.09, 79.785, 36.809999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.91, 79.80999999999999, 36.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.29, 79.99, 36.61000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.11, 80.005, 36.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.489999999999995, 80.095, 36.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.309999999999995, 80.10000000000001, 36.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.69, 80.10000000000001, 36.21000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.51, 80.095, 36.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.89, 80.005, 36.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.71, 79.99, 35.989999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.09, 79.80999999999999, 35.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.910000000000004, 79.785, 35.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.290000000000006, 79.515, 35.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.11000000000001, 79.47999999999999, 35.589999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.49, 79.12, 35.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.31, 79.075, 35.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.690000000000005, 78.625, 35.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.510000000000005, 78.57, 35.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.89, 78.03, 35.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.71, 77.965, 34.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.09, 77.335, 34.809999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.915000000000006, 77.26499999999999, 34.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.385000000000005, 76.63499999999999, 34.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.215, 76.56, 34.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.685, 75.84, 34.410000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.515, 75.755, 34.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.985, 74.94500000000001, 34.21000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.82, 74.85000000000001, 34.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.38, 73.95, 34.010000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.22, 73.845, 33.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.78, 72.85499999999999, 33.809999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.62500000000001, 72.74499999999999, 33.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.275000000000006, 71.755, 33.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.125, 71.64, 33.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.775, 70.56, 33.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.63, 70.435, 33.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.37, 69.265, 33.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.23, 69.135, 33.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.97, 67.965, 33.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.835, 67.83000000000001, 32.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.665000000000006, 66.57000000000001, 32.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.540000000000006, 66.43, 32.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.459999999999997, 65.17, 32.61000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.339999999999996, 65.02499999999999, 32.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.259999999999998, 63.675000000000004, 32.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.145, 63.525000000000006, 32.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.155, 62.175, 32.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.05, 62.02, 32.190000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.150000000000002, 60.580000000000005, 32.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.055000000000003, 60.42, 31.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.245, 58.98, 31.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.16, 58.82, 31.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.439999999999998, 57.38, 31.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.365, 57.22, 31.590000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.735, 55.78, 31.409999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.669999999999998, 55.615, 31.389999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.130000000000003, 54.085, 31.209999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.075000000000003, 53.915, 31.189999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.625, 52.385, 31.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.580000000000002, 52.215, 30.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.220000000000002, 50.685, 30.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.185000000000002, 50.515, 30.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.915, 48.985, 30.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.889999999999997, 48.815, 30.590000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.709999999999997, 47.285000000000004, 30.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.694999999999997, 47.115, 30.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.605, 45.585, 30.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.6, 45.415000000000006, 30.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.6, 43.885000000000005, 30.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.605, 43.715, 29.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.694999999999997, 42.185, 29.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.709999999999997, 42.015, 29.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.889999999999997, 40.485, 29.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.915, 40.315, 29.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.185000000000002, 38.785000000000004, 29.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.220000000000002, 38.620000000000005, 29.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.580000000000002, 37.18, 29.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.625, 37.02, 29.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.075000000000003, 35.58, 29.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.130000000000003, 35.42, 28.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.669999999999998, 33.98, 28.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.735, 33.824999999999996, 28.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.365, 32.475, 28.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.439999999999998, 32.325, 28.590000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.16, 30.974999999999998, 28.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.245, 30.83, 28.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.055000000000003, 29.57, 28.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.150000000000002, 29.43, 28.189999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.05, 28.17, 28.009999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.155, 28.035000000000004, 27.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.145, 26.865000000000002, 27.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.259999999999998, 26.740000000000002, 27.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.339999999999996, 25.660000000000004, 27.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.459999999999997, 25.540000000000003, 27.590000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.540000000000006, 24.46, 27.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.665000000000006, 24.345000000000002, 27.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.835, 23.355000000000004, 27.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.97, 23.250000000000004, 27.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.23, 22.35, 27.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.37, 22.255, 26.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.63, 21.444999999999997, 26.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.775, 21.36, 26.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.125, 20.640000000000004, 26.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.275000000000006, 20.565, 26.590000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.62500000000001, 19.935, 26.409999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.78, 19.87, 26.389999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.22, 19.330000000000002, 26.209999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.38, 19.275000000000002, 26.189999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.82, 18.825000000000003, 26.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.985, 18.78, 25.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.515, 18.419999999999998, 25.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.685, 18.384999999999998, 25.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.215, 18.115000000000002, 25.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.385000000000005, 18.090000000000003, 25.590000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.915000000000006, 17.91, 25.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.09, 17.895, 25.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.71, 17.805, 25.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.89, 17.8, 25.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.510000000000005, 17.8, 25.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.690000000000005, 17.805, 24.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.31, 17.895, 24.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.49, 17.91, 24.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.11000000000001, 18.090000000000003, 24.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.290000000000006, 18.115000000000002, 24.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.910000000000004, 18.384999999999998, 24.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.09, 18.419999999999998, 24.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.71, 18.78, 24.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.89, 18.825000000000003, 24.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.51, 19.275000000000002, 24.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.69, 19.330000000000002, 23.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.309999999999995, 19.87, 23.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.489999999999995, 19.935, 23.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.11, 20.565, 23.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.29, 20.640000000000004, 23.590000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.91, 21.36, 23.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.09, 21.444999999999997, 23.389999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.71, 22.255, 23.209999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.89, 22.35, 23.189999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.50999999999999, 23.250000000000004, 23.009999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.69, 23.355000000000004, 22.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.31, 24.345000000000002, 22.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.49000000000001, 24.46, 22.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.11000000000001, 25.540000000000003, 22.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.29, 25.660000000000004, 22.590000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.91, 26.740000000000002, 22.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.085, 26.865000000000002, 22.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.615, 28.035000000000004, 22.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.785, 28.17, 22.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.315, 29.43, 22.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.485, 29.57, 21.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.015, 30.83, 21.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.18, 30.974999999999998, 21.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.62, 32.325, 21.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.78, 32.475, 21.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.22, 33.824999999999996, 21.409999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.375, 33.98, 21.389999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.725, 35.42, 21.209999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.875, 35.58, 21.189999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.225, 37.02, 21.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.37, 37.18, 20.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.63000000000001, 38.620000000000005, 20.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.765, 38.785000000000004, 20.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.935, 40.315, 20.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.06500000000001, 40.485, 20.590000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.235, 42.015, 20.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.36, 42.185, 20.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.44000000000001, 43.715, 20.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.555, 43.885000000000005, 20.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.545, 45.415000000000006, 20.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.65, 45.585, 19.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.55, 47.115, 19.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.645, 47.285000000000004, 19.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.455, 48.815, 19.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.53999999999999, 48.985, 19.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.25999999999999, 50.515, 19.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.335, 50.685, 19.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.965, 52.215, 19.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.03, 52.385, 19.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.57, 53.915, 19.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.625, 54.085, 18.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.075, 55.615, 18.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.12, 55.78, 18.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.48, 57.22, 18.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.515, 57.38, 18.590000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.785, 58.82, 18.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.81, 58.98, 18.389999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.99000000000001, 60.42, 18.209999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.005, 60.580000000000005, 18.189999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.095, 62.02, 18.009999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.1, 62.175, 17.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.1, 63.525000000000006, 17.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.095, 63.675000000000004, 17.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.005, 65.02499999999999, 17.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.99000000000001, 65.17, 17.590000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.81, 66.43, 17.409999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.785, 66.57000000000001, 17.389999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.515, 67.83000000000001, 17.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.48, 67.965, 17.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.12, 69.135, 17.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.075, 69.265, 16.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.625, 70.435, 16.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.57, 70.56, 16.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.03, 71.64, 16.610000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.965, 71.755, 16.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.335, 72.74499999999999, 16.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.25999999999999, 72.85499999999999, 16.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.53999999999999, 73.845, 16.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.455, 73.95, 16.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.645, 74.85000000000001, 16.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.55, 74.94500000000001, 15.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.65, 75.755, 15.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.545, 75.84, 15.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.555, 76.56, 15.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.44000000000001, 76.63499999999999, 15.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.36, 77.26499999999999, 15.410000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.235, 77.335, 15.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.06500000000001, 77.965, 15.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.935, 78.03, 15.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.765, 78.57, 15.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.63000000000001, 78.625, 14.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.37, 79.075, 14.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.225, 79.12, 14.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.875, 79.47999999999999, 14.610000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.725, 79.515, 14.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.375, 79.785, 14.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.22, 79.80999999999999, 14.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.78, 79.99, 14.209999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.62, 80.005, 14.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.18, 80.095, 14.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.015, 80.10000000000001, 13.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.485, 80.10000000000001, 13.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.315, 80.095, 13.790000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.785, 80.005, 13.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.615, 79.99, 13.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.085, 79.80999999999999, 13.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.91, 79.785, 13.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.29, 79.515, 13.209999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.11000000000001, 79.47999999999999, 13.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.49000000000001, 79.12, 13.010000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.31, 79.075, 12.990000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.69, 78.625, 12.810000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.50999999999999, 78.57, 12.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.89, 78.03, 12.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.71, 77.965, 12.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.09, 77.335, 12.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.91, 77.26499999999999, 12.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.29, 76.63499999999999, 12.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.11, 76.56, 12.190000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.489999999999995, 75.84, 12.010000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.309999999999995, 75.755, 11.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.69, 74.94500000000001, 11.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.51, 74.85000000000001, 11.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.89, 73.95, 11.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.71, 73.845, 11.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.09, 72.85499999999999, 11.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.910000000000004, 72.74499999999999, 11.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.290000000000006, 71.755, 11.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.11000000000001, 71.64, 11.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.49, 70.56, 11.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.31, 70.435, 10.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.690000000000005, 69.265, 10.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.510000000000005, 69.135, 10.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.89, 67.965, 10.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.71, 67.83000000000001, 10.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.09, 66.57000000000001, 10.410000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.915000000000006, 66.43, 10.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.385000000000005, 65.17, 10.209999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.215, 65.02499999999999, 10.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.685, 63.675000000000004, 10.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.515, 63.525000000000006, 9.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.985, 62.175, 9.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.82, 62.02, 9.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.38, 60.580000000000005, 9.610000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.22, 60.42, 9.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.78, 58.98, 9.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.62500000000001, 58.82, 9.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.275000000000006, 57.38, 9.209999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.125, 57.22, 9.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.775, 55.78, 9.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.63, 55.615, 8.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.37, 54.085, 8.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.23, 53.915, 8.790000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.97, 52.385, 8.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.835, 52.215, 8.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.665000000000006, 50.685, 8.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.540000000000006, 50.515, 8.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.459999999999997, 48.985, 8.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.339999999999996, 48.815, 8.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.259999999999998, 47.285000000000004, 8.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.145, 47.115, 7.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.155, 45.585, 7.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.05, 45.415000000000006, 7.789999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.150000000000002, 43.885000000000005, 7.609999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.055000000000003, 43.715, 7.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.245, 42.185, 7.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.16, 42.015, 7.390000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.439999999999998, 40.485, 7.210000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.365, 40.315, 7.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.735, 38.785000000000004, 7.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.669999999999998, 38.620000000000005, 6.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.130000000000003, 37.18, 6.8100000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.075000000000003, 37.02, 6.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.625, 35.58, 6.609999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.580000000000002, 35.42, 6.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.220000000000002, 33.98, 6.410000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.185000000000002, 33.824999999999996, 6.390000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.915, 32.475, 6.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.889999999999997, 32.325, 6.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.709999999999997, 30.974999999999998, 6.010000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.694999999999997, 30.83, 5.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.605, 29.57, 5.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.6, 29.43, 5.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.6, 28.17, 5.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.605, 28.035000000000004, 5.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.694999999999997, 26.865000000000002, 5.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.709999999999997, 26.740000000000002, 5.390000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.889999999999997, 25.660000000000004, 5.210000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.915, 25.540000000000003, 5.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.185000000000002, 24.46, 5.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.220000000000002, 24.345000000000002, 4.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.580000000000002, 23.355000000000004, 4.8100000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.625, 23.250000000000004, 4.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.075000000000003, 22.35, 4.609999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.130000000000003, 22.255, 4.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.669999999999998, 21.444999999999997, 4.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.735, 21.36, 4.390000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.365, 20.640000000000004, 4.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.439999999999998, 20.565, 4.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.16, 19.935, 4.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.245, 19.87, 3.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.055000000000003, 19.330000000000002, 3.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.150000000000002, 19.275000000000002, 3.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.05, 18.825000000000003, 3.6100000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.155, 18.78, 3.5900000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.145, 18.419999999999998, 3.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.259999999999998, 18.384999999999998, 3.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.339999999999996, 18.115000000000002, 3.2100000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.459999999999997, 18.090000000000003, 3.1900000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.540000000000006, 17.91, 3.0100000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.665000000000006, 17.895, 2.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.835, 17.805, 2.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.97, 17.8, 2.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.23, 17.8, 2.6100000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.37, 17.805, 2.5900000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.63, 17.895, 2.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.775, 17.91, 2.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.125, 18.090000000000003, 2.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.275000000000006, 18.115000000000002, 2.1900000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.62500000000001, 18.384999999999998, 2.0100000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.78, 18.419999999999998, 1.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.22, 18.78, 1.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.38, 18.825000000000003, 1.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.82, 19.275000000000002, 1.6100000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.985, 19.330000000000002, 1.5900000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.515, 19.87, 1.4100000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.685, 19.935, 1.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.215, 20.565, 1.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.385000000000005, 20.640000000000004, 1.1900000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.915000000000006, 21.36, 1.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.09, 21.444999999999997, 0.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.71, 22.255, 0.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.89, 22.35, 0.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.510000000000005, 23.250000000000004, 0.61]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.690000000000005, 23.355000000000004, 0.5900000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.31, 24.345000000000002, 0.41000000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.49, 24.46, 0.39000000000000007]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.11000000000001, 25.540000000000003, 0.21000000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.290000000000006, 25.660000000000004, 0.19000000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.910000000000004, 26.740000000000002, 0.010000000000000002]) cube([0.4, 0.4, 0.1], center=true);
}

