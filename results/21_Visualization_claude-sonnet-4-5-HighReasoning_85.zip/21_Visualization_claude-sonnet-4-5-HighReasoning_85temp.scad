
hull() {
    translate([14.494850000000001, 7.5595, 8.9946]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.40215, 8.6305, 8.897400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.372, 8.7469, 8.88655]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.922, 9.7711, 8.78845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.853850000000001, 9.87925, 8.7776]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.077150000000001, 10.80175, 8.6804]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.97465, 10.896049999999999, 8.6696]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.90635, 11.67095, 8.5724]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.7741, 11.74675, 8.56155]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.4619, 12.33625, 8.46345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.30555, 12.389949999999999, 8.4526]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.803450000000002, 12.76705, 8.3554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.6292, 12.796050000000001, 8.3446]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.994800000000001, 12.94095, 8.2474]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.809200000000001, 12.9437, 8.236550000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.1028, 12.8483, 8.138449999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.9127, 12.824300000000001, 8.1276]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.1973, 12.4877, 8.0304]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0096499999999997, 12.437449999999998, 8.0196]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.34735, 11.86955, 7.9224000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.21725, 11.794649999999999, 7.91155]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.53775, 11.01435, 7.81345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.5, 10.91745, 7.8026]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.5, 9.95355, 7.705400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.53775, 9.8381, 7.6946]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.21725, 8.7239, 7.5973999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.34735, 8.605450000000001, 7.58655]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.0096499999999997, 7.58755, 7.48845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.1973, 7.4823, 7.477600000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.9127, 6.605700000000001, 7.3804]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.1028, 6.517600000000001, 7.3696]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.809200000000001, 5.8084, 7.2724]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.994800000000001, 5.73995, 7.261550000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.6292, 5.21705, 7.163450000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.803450000000002, 5.17015, 7.1526000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.30555, 4.8488500000000005, 7.0554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.4619, 4.8246, 7.0446]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.7741, 4.7094000000000005, 6.947400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.90635, 4.708, 6.93655]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.97465, 4.798, 6.83845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.077150000000001, 4.81895, 6.8276]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.853850000000001, 5.10605, 6.7304]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.922, 5.14795, 6.7196]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.372, 5.61505, 6.622400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.40215, 5.6754, 6.61155]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.494850000000001, 6.294599999999999, 6.51345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.484750000000002, 6.3698, 6.5026]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.210250000000002, 7.1042, 6.405400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.160150000000002, 7.18995, 6.3946000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.53285, 7.99905, 6.2974]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.44545, 8.0907, 6.28655]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.49955, 8.9313, 6.1884500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.379349999999999, 9.024, 6.1776]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.16165, 9.852, 6.0804]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.01415, 9.940900000000001, 6.0696]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.57685, 10.7131, 5.9723999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.40825, 10.7933, 5.961549999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.8107500000000005, 11.4647, 5.863449999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.6279, 11.5317, 5.8526]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.934100000000001, 12.0663, 5.7554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.7442, 12.11635, 5.7446]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.0198, 12.482650000000001, 5.647400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.8303000000000003, 12.5127, 5.636550000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1437, 12.687299999999999, 5.53845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.96215, 12.69525, 5.5276000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.38085, 12.663750000000002, 5.430400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.30335, 12.64845, 5.4196]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.48965000000000003, 12.40455, 5.3224]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.5616, 12.3657, 5.31155]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6703999999999999, 11.9103, 5.213450000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8268499999999999, 11.84855, 5.2026]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.5341500000000003, 11.192450000000001, 5.1053999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.7349500000000004, 11.1096, 5.0946]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.64205, 10.2744, 4.9974]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.86045, 10.1732, 4.98655]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.884550000000001, 9.1868, 4.888450000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.11135, 9.07065, 4.8776]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.16965, 7.96635, 4.7804]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.395500000000002, 7.83905, 4.7696000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.4025, 6.65195, 4.6724000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.613299999999999, 6.5178, 4.66155]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4007, 5.2902000000000005, 4.56345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 5.154000000000001, 4.5526]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 3.93, 4.4554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 3.7966, 4.444599999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 2.6194, 4.3474]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4007, 2.49365, 4.33655]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.613299999999999, 1.4073499999999999, 4.23845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.4025, 1.29375, 4.2276]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.395500000000002, 0.33525, 4.1304]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.16965, 0.2929, 4.1196]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.11135, 0.48910000000000003, 4.0224]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.884550000000001, 0.52775, 4.011550000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.86045, 1.02725, 3.91345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.64205, 1.1053, 3.9026]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.7349500000000004, 2.0107, 3.8054]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.5341500000000003, 2.13205, 3.7946]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8268499999999999, 3.4109500000000006, 3.6974000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.66005, 3.5713500000000007, 3.6865500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.36495, 5.1796500000000005, 3.5884500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.30335, 5.3736500000000005, 3.5776000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.48965000000000003, 7.25735, 3.4804]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.5616, 7.47835, 3.4696]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6703999999999999, 9.572650000000001, 3.3724]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8268499999999999, 9.81345, 3.3615500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.5341500000000003, 12.053550000000001, 3.2634499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.7349500000000004, 12.3068, 3.2526]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.64205, 14.6252, 3.1554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.86045, 14.741299999999999, 3.1446]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.884550000000001, 14.5127, 3.0474]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.11135, 14.5, 3.03655]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.16965, 14.5, 2.93845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.395500000000002, 14.5, 2.9276]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.4025, 14.5, 2.8304000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.613299999999999, 14.435550000000001, 2.8196000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4007, 13.275450000000001, 2.7224]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 13.109350000000001, 2.71155]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 11.279650000000002, 2.61345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 11.066100000000002, 2.6026]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 9.0519, 2.5054]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4007, 8.822299999999998, 2.4946]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.613299999999999, 6.7037, 2.3974]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.4025, 6.4708000000000006, 2.38655]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.395500000000002, 4.3972, 2.28845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.16965, 4.1745, 2.2776]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.11135, 2.2395, 2.1803999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.884550000000001, 2.0368, 2.1696]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.86045, 0.32320000000000004, 2.0724000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.64205, 0.24160000000000004, 2.0615500000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.7349500000000004, 0.4864, 1.96345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.5341500000000003, 0.5778, 1.9526]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8268499999999999, 1.9782, 1.8554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.66005, 2.1706000000000003, 1.8446]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.36495, 4.2334, 1.7474]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.30335, 4.48775, 1.73655]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.48965000000000003, 7.00325, 1.63845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.5616, 7.2993500000000004, 1.6276]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6703999999999999, 10.11365, 1.5304]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8268499999999999, 10.4342, 1.5196]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.5341500000000003, 13.389800000000001, 1.4224]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.7349500000000004, 13.601300000000002, 1.41155]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.64205, 14.4527, 1.31345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.86045, 14.5, 1.3026]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.884550000000001, 14.5, 1.2054]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.11135, 14.5, 1.1946]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.16965, 14.5, 1.0974000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.395500000000002, 14.38555, 1.0865500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.4025, 12.32545, 0.98845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.613299999999999, 12.05935, 0.9776]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4007, 9.32965, 0.8804]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5, 9.016100000000002, 0.8695999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5, 6.1019000000000005, 0.7724]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4007, 5.7723, 0.7615500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.613299999999999, 2.7537, 0.6634500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.4025, 2.4817, 0.6526000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.395500000000002, 0.6043000000000001, 0.5554000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.16965, 0.5, 0.5446000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.11135, 0.5, 0.4474]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.884550000000001, 0.5864, 0.43655]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.86045, 2.1416000000000004, 0.33845000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.64205, 2.3694000000000006, 0.3276]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.7349500000000004, 4.9146, 0.23040000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.5341500000000003, 5.2206, 0.21960000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8268499999999999, 8.1834, 0.12240000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.6703999999999999, 8.53775, 0.11155000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.5616, 11.95325, 0.01345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.50815, 12.260850000000001, 0.007600000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.65485, 14.382150000000001, 0.0004]) cube([0.4, 0.4, 0.1], center=true);
}

