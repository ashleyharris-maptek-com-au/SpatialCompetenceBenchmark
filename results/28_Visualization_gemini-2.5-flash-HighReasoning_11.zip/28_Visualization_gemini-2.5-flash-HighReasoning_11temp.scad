
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.319999999999999]);

translate([2, 0, 0]) cube([1, 1, 4.259142749796513]);

translate([3, 0, 0]) cube([1, 1, 4.260278324666873]);

translate([4, 0, 0]) cube([1, 1, 4.259656044360573]);

translate([5, 0, 0]) cube([1, 1, 4.27620194092301]);

translate([6, 0, 0]) cube([1, 1, 4.27779996230157]);

translate([7, 0, 0]) cube([1, 1, 4.429725651187331]);

translate([8, 0, 0]) cube([1, 1, 4.4171125855562225]);

translate([9, 0, 0]) cube([1, 1, 4.417375198911824]);

translate([10, 0, 0]) cube([1, 1, 5.0]);

translate([11, 0, 0]) cube([1, 1, 5.3]);

translate([12, 0, 0]) cube([1, 1, 5.4]);

translate([13, 0, 0]) cube([1, 1, 5.3]);

translate([14, 0, 0]) cube([1, 1, 4.8]);

translate([15, 0, 0]) cube([1, 1, 4.4]);

translate([16, 0, 0]) cube([1, 1, 4.3]);

translate([17, 0, 0]) cube([1, 1, 4.3]);

translate([18, 0, 0]) cube([1, 1, 4.6]);

translate([19, 0, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.3]);

translate([2, 1, 0]) cube([1, 1, 4.819999999999999]);

translate([3, 1, 0]) cube([1, 1, 4.4099999999999975]);

translate([4, 1, 0]) cube([1, 1, 4.409999999999996]);

translate([5, 1, 0]) cube([1, 1, 4.286201985095945]);

translate([6, 1, 0]) cube([1, 1, 4.609999999999989]);

translate([7, 1, 0]) cube([1, 1, 4.41773791807688]);

translate([8, 1, 0]) cube([1, 1, 4.433071211835301]);

translate([9, 1, 0]) cube([1, 1, 4.417876196821436]);

translate([10, 1, 0]) cube([1, 1, 4.529999999999995]);

translate([11, 1, 0]) cube([1, 1, 4.5699999999999985]);

translate([12, 1, 0]) cube([1, 1, 4.6]);

translate([13, 1, 0]) cube([1, 1, 4.5]);

translate([14, 1, 0]) cube([1, 1, 4.3]);

translate([15, 1, 0]) cube([1, 1, 4.1]);

translate([16, 1, 0]) cube([1, 1, 3.8]);

translate([17, 1, 0]) cube([1, 1, 3.6507539281801193]);

translate([18, 1, 0]) cube([1, 1, 3.8]);

translate([19, 1, 0]) cube([1, 1, 4.0]);

translate([0, 2, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.22]);

translate([4, 2, 0]) cube([1, 1, 5.139999999999999]);

translate([5, 2, 0]) cube([1, 1, 4.889999999999998]);

translate([6, 2, 0]) cube([1, 1, 4.639999999999991]);

translate([7, 2, 0]) cube([1, 1, 4.689999999999987]);

translate([8, 2, 0]) cube([1, 1, 4.439337535422705]);

translate([9, 2, 0]) cube([1, 1, 4.551953809363658]);

translate([10, 2, 0]) cube([1, 1, 4.569999999999997]);

translate([11, 2, 0]) cube([1, 1, 4.539999999999997]);

translate([12, 2, 0]) cube([1, 1, 4.259999999999999]);

translate([13, 2, 0]) cube([1, 1, 4.1]);

translate([14, 2, 0]) cube([1, 1, 3.7]);

translate([15, 2, 0]) cube([1, 1, 3.6492167417289947]);

translate([16, 2, 0]) cube([1, 1, 3.653083313338261]);

translate([17, 2, 0]) cube([1, 1, 3.6541407698979045]);

translate([18, 2, 0]) cube([1, 1, 3.653306814739572]);

translate([19, 2, 0]) cube([1, 1, 3.7]);

translate([0, 3, 0]) cube([1, 1, 7.4]);

translate([1, 3, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.299999999999998]);

translate([6, 3, 0]) cube([1, 1, 4.538309448386915]);

translate([7, 3, 0]) cube([1, 1, 4.919999999999997]);

translate([8, 3, 0]) cube([1, 1, 4.654391798365186]);

translate([9, 3, 0]) cube([1, 1, 4.439328514710801]);

translate([10, 3, 0]) cube([1, 1, 5.0699999999999985]);

translate([11, 3, 0]) cube([1, 1, 4.759999999999999]);

translate([12, 3, 0]) cube([1, 1, 4.0699999999999985]);

translate([13, 3, 0]) cube([1, 1, 3.829999999999999]);

translate([14, 3, 0]) cube([1, 1, 3.6530513812067515]);

translate([15, 3, 0]) cube([1, 1, 3.6536749274369322]);

translate([16, 3, 0]) cube([1, 1, 3.6517502758789826]);

translate([17, 3, 0]) cube([1, 1, 3.6531426542930805]);

translate([18, 3, 0]) cube([1, 1, 3.6529741801506628]);

translate([19, 3, 0]) cube([1, 1, 3.651120847399269]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.2]);

translate([2, 4, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

translate([4, 4, 0]) cube([1, 1, 5.288691451817513]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 4.868460442428821]);

translate([7, 4, 0]) cube([1, 1, 5.499999999999998]);

translate([8, 4, 0]) cube([1, 1, 4.649999999999992]);

translate([9, 4, 0]) cube([1, 1, 4.759999999999997]);

translate([10, 4, 0]) cube([1, 1, 5.399999999999998]);

translate([11, 4, 0]) cube([1, 1, 4.799999999999998]);

translate([12, 4, 0]) cube([1, 1, 4.099999999999998]);

translate([13, 4, 0]) cube([1, 1, 3.7299999999999973]);

translate([14, 4, 0]) cube([1, 1, 3.689999999999998]);

translate([15, 4, 0]) cube([1, 1, 3.759999999999999]);

translate([16, 4, 0]) cube([1, 1, 3.9699999999999984]);

translate([17, 4, 0]) cube([1, 1, 4.159999999999998]);

translate([18, 4, 0]) cube([1, 1, 4.079999999999998]);

translate([19, 4, 0]) cube([1, 1, 3.979999999999998]);

translate([0, 5, 0]) cube([1, 1, 7.9]);

translate([1, 5, 0]) cube([1, 1, 7.4]);

translate([2, 5, 0]) cube([1, 1, 7.0]);

translate([3, 5, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

translate([6, 5, 0]) cube([1, 1, 5.459999999999998]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

translate([8, 5, 0]) cube([1, 1, 5.379999999999998]);

translate([9, 5, 0]) cube([1, 1, 5.319999999999998]);

translate([10, 5, 0]) cube([1, 1, 5.459999999999999]);

translate([11, 5, 0]) cube([1, 1, 4.9099999999999975]);

translate([12, 5, 0]) cube([1, 1, 4.529999999999998]);

translate([13, 5, 0]) cube([1, 1, 4.169999999999996]);

translate([14, 5, 0]) cube([1, 1, 4.509999999999998]);

translate([15, 5, 0]) cube([1, 1, 4.689999999999998]);

translate([16, 5, 0]) cube([1, 1, 4.719999999999997]);

translate([17, 5, 0]) cube([1, 1, 4.799999999999998]);

translate([18, 5, 0]) cube([1, 1, 4.649999999999997]);

translate([19, 5, 0]) cube([1, 1, 4.549999999999999]);

translate([0, 6, 0]) cube([1, 1, 7.9]);

translate([1, 6, 0]) cube([1, 1, 7.2]);

translate([2, 6, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 6, 0]) cube([1, 1, 6]);

translate([4, 6, 0]) cube([1, 1, 6.8]);

translate([5, 6, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.325609893476265]);

color([0,1,0])
translate([10, 6, 0]) cube([1, 1, 6]);

translate([11, 6, 0]) cube([1, 1, 4.9099999999999975]);

translate([12, 6, 0]) cube([1, 1, 4.969999999999996]);

translate([13, 6, 0]) cube([1, 1, 4.849999999999994]);

translate([14, 6, 0]) cube([1, 1, 5.1999999999999975]);

translate([15, 6, 0]) cube([1, 1, 5.469999999999999]);

translate([16, 6, 0]) cube([1, 1, 5.429999999999997]);

translate([17, 6, 0]) cube([1, 1, 4.759268565297062]);

translate([18, 6, 0]) cube([1, 1, 4.959999999999999]);

translate([19, 6, 0]) cube([1, 1, 5.2]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.4]);

translate([2, 7, 0]) cube([1, 1, 6.9]);

translate([3, 7, 0]) cube([1, 1, 7.1]);

translate([4, 7, 0]) cube([1, 1, 7.2]);

translate([5, 7, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

translate([11, 7, 0]) cube([1, 1, 5.119999999999997]);

translate([12, 7, 0]) cube([1, 1, 5.109999999999996]);

translate([13, 7, 0]) cube([1, 1, 5.089999999999994]);

color([0,1,0])
translate([14, 7, 0]) cube([1, 1, 6]);

translate([15, 7, 0]) cube([1, 1, 5.269999999999999]);

translate([16, 7, 0]) cube([1, 1, 5.459690550485122]);

color([0,1,0])
translate([17, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 8.1]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 7.4]);

translate([3, 8, 0]) cube([1, 1, 7.6]);

translate([4, 8, 0]) cube([1, 1, 7.5]);

translate([5, 8, 0]) cube([1, 1, 7.0]);

translate([6, 8, 0]) cube([1, 1, 6.71]);

translate([7, 8, 0]) cube([1, 1, 6.71]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

translate([11, 8, 0]) cube([1, 1, 5.319999999999999]);

translate([12, 8, 0]) cube([1, 1, 5.1018417692597415]);

translate([13, 8, 0]) cube([1, 1, 5.111969498633521]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

translate([15, 8, 0]) cube([1, 1, 5.490226957305832]);

translate([16, 8, 0]) cube([1, 1, 5.499999999999993]);

translate([17, 8, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([18, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 8.1]);

translate([1, 9, 0]) cube([1, 1, 7.8]);

translate([2, 9, 0]) cube([1, 1, 7.6]);

translate([3, 9, 0]) cube([1, 1, 7.4]);

translate([4, 9, 0]) cube([1, 1, 7.1]);

translate([5, 9, 0]) cube([1, 1, 7.0]);

translate([6, 9, 0]) cube([1, 1, 7.0]);

translate([7, 9, 0]) cube([1, 1, 6.71]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

translate([12, 9, 0]) cube([1, 1, 5.104591006067104]);

translate([13, 9, 0]) cube([1, 1, 5.1114731481481455]);

translate([14, 9, 0]) cube([1, 1, 5.199999999999998]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 6.9]);

translate([18, 9, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.7]);

translate([1, 10, 0]) cube([1, 1, 7.3]);

translate([2, 10, 0]) cube([1, 1, 7.2]);

translate([3, 10, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([4, 10, 0]) cube([1, 1, 6]);

translate([5, 10, 0]) cube([1, 1, 6.6]);

translate([6, 10, 0]) cube([1, 1, 6.8]);

translate([7, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

translate([9, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 6.6]);

translate([18, 10, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 6.9]);

translate([1, 11, 0]) cube([1, 1, 6.7]);

translate([2, 11, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 11, 0]) cube([1, 1, 6]);

translate([8, 11, 0]) cube([1, 1, 6.7]);

translate([9, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

translate([12, 11, 0]) cube([1, 1, 5.360889782227871]);

translate([13, 11, 0]) cube([1, 1, 5.359122448991311]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([1, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 12, 0]) cube([1, 1, 6]);

translate([4, 12, 0]) cube([1, 1, 5.4]);

translate([5, 12, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([6, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 12, 0]) cube([1, 1, 6]);

translate([8, 12, 0]) cube([1, 1, 6.8]);

translate([9, 12, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

translate([13, 12, 0]) cube([1, 1, 5.360266223548806]);

translate([14, 12, 0]) cube([1, 1, 5.41]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 7.1]);

translate([1, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 13, 0]) cube([1, 1, 6]);

translate([3, 13, 0]) cube([1, 1, 5.4]);

translate([4, 13, 0]) cube([1, 1, 5.323445971910429]);

color([0,1,0])
translate([5, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

translate([8, 13, 0]) cube([1, 1, 6.6]);

translate([9, 13, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

translate([14, 13, 0]) cube([1, 1, 5.360015027978831]);

translate([15, 13, 0]) cube([1, 1, 5.360569639971567]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

translate([19, 13, 0]) cube([1, 1, 5.3]);

translate([0, 14, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

translate([2, 14, 0]) cube([1, 1, 5.4]);

translate([3, 14, 0]) cube([1, 1, 5.318128336552209]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

translate([8, 14, 0]) cube([1, 1, 6.7]);

translate([9, 14, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

translate([19, 14, 0]) cube([1, 1, 5.0]);

translate([0, 15, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 15, 0]) cube([1, 1, 6]);

translate([7, 15, 0]) cube([1, 1, 6.81]);

translate([8, 15, 0]) cube([1, 1, 7.1]);

translate([9, 15, 0]) cube([1, 1, 6.91]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

translate([17, 15, 0]) cube([1, 1, 5.4]);

translate([18, 15, 0]) cube([1, 1, 5.1]);

translate([19, 15, 0]) cube([1, 1, 4.707240726965554]);

color([0,1,0])
translate([0, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 16, 0]) cube([1, 1, 6]);

translate([6, 16, 0]) cube([1, 1, 6.51]);

translate([7, 16, 0]) cube([1, 1, 7.01]);

translate([8, 16, 0]) cube([1, 1, 6.819999999999999]);

color([0,1,0])
translate([9, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

translate([16, 16, 0]) cube([1, 1, 5.4]);

translate([17, 16, 0]) cube([1, 1, 5.4]);

translate([18, 16, 0]) cube([1, 1, 5.2]);

translate([19, 16, 0]) cube([1, 1, 4.707204888219084]);

color([0,1,0])
translate([0, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

translate([6, 17, 0]) cube([1, 1, 6.7]);

translate([7, 17, 0]) cube([1, 1, 6.609999999999999]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

translate([16, 18, 0]) cube([1, 1, 5.4]);

translate([17, 18, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 5.4]);

translate([1, 19, 0]) cube([1, 1, 5.300122407950005]);

translate([2, 19, 0]) cube([1, 1, 5.3]);

translate([3, 19, 0]) cube([1, 1, 5.172140165578036]);

translate([4, 19, 0]) cube([1, 1, 5.174252931198072]);

translate([5, 19, 0]) cube([1, 1, 5.399999999999998]);

translate([6, 19, 0]) cube([1, 1, 5.459999999999996]);

color([0,1,0])
translate([7, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

translate([14, 19, 0]) cube([1, 1, 5.225485005470312]);

translate([15, 19, 0]) cube([1, 1, 5.3]);

translate([16, 19, 0]) cube([1, 1, 5.3]);

translate([17, 19, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);
