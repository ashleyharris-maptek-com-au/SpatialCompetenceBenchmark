
translate([0, 0, 0]) cube([1, 1, 5.01]);

translate([1, 0, 0]) cube([1, 1, 4.639999999999999]);

translate([2, 0, 0]) cube([1, 1, 4.4099999999999975]);

translate([3, 0, 0]) cube([1, 1, 4.3999999998800545]);

translate([4, 0, 0]) cube([1, 1, 4.409999999999996]);

translate([5, 0, 0]) cube([1, 1, 4.210001149191598]);

translate([6, 0, 0]) cube([1, 1, 4.210001149786619]);

translate([7, 0, 0]) cube([1, 1, 4.200501112542507]);

translate([8, 0, 0]) cube([1, 1, 4.2007504884595805]);

translate([9, 0, 0]) cube([1, 1, 4.200800787985604]);

translate([10, 0, 0]) cube([1, 1, 4.200809332912819]);

translate([11, 0, 0]) cube([1, 1, 4.200905296809112]);

translate([12, 0, 0]) cube([1, 1, 4.200846864695203]);

translate([13, 0, 0]) cube([1, 1, 4.3]);

translate([14, 0, 0]) cube([1, 1, 4.5]);

translate([15, 0, 0]) cube([1, 1, 4.5]);

translate([16, 0, 0]) cube([1, 1, 4.4]);

translate([17, 0, 0]) cube([1, 1, 4.3]);

translate([18, 0, 0]) cube([1, 1, 4.201486791344431]);

translate([19, 0, 0]) cube([1, 1, 4.201423672660263]);

translate([20, 0, 0]) cube([1, 1, 4.3]);

translate([21, 0, 0]) cube([1, 1, 4.4]);

translate([22, 0, 0]) cube([1, 1, 4.7]);

translate([23, 0, 0]) cube([1, 1, 4.9]);

translate([24, 0, 0]) cube([1, 1, 5.0]);

translate([25, 0, 0]) cube([1, 1, 5.1]);

translate([26, 0, 0]) cube([1, 1, 5.2]);

translate([27, 0, 0]) cube([1, 1, 5.3]);

translate([28, 0, 0]) cube([1, 1, 5.4]);

translate([29, 0, 0]) cube([1, 1, 5.4]);

translate([30, 0, 0]) cube([1, 1, 5.4]);

translate([31, 0, 0]) cube([1, 1, 5.3]);

translate([32, 0, 0]) cube([1, 1, 5.1]);

translate([33, 0, 0]) cube([1, 1, 4.9]);

translate([34, 0, 0]) cube([1, 1, 4.7]);

translate([35, 0, 0]) cube([1, 1, 4.6]);

translate([36, 0, 0]) cube([1, 1, 4.4]);

translate([37, 0, 0]) cube([1, 1, 4.4]);

translate([38, 0, 0]) cube([1, 1, 4.3]);

translate([39, 0, 0]) cube([1, 1, 4.3]);

translate([40, 0, 0]) cube([1, 1, 4.3]);

translate([41, 0, 0]) cube([1, 1, 4.3]);

translate([42, 0, 0]) cube([1, 1, 4.4]);

translate([43, 0, 0]) cube([1, 1, 4.6]);

translate([44, 0, 0]) cube([1, 1, 4.6]);

translate([45, 0, 0]) cube([1, 1, 4.7]);

translate([46, 0, 0]) cube([1, 1, 4.8]);

translate([47, 0, 0]) cube([1, 1, 4.9]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.049999999999999]);

translate([2, 1, 0]) cube([1, 1, 4.749999999999999]);

translate([3, 1, 0]) cube([1, 1, 4.529999999999999]);

translate([4, 1, 0]) cube([1, 1, 4.4]);

translate([5, 1, 0]) cube([1, 1, 4.3]);

translate([6, 1, 0]) cube([1, 1, 4.210001924151894]);

translate([7, 1, 0]) cube([1, 1, 4.210001668771274]);

translate([8, 1, 0]) cube([1, 1, 4.201045363763477]);

translate([9, 1, 0]) cube([1, 1, 4.201105504540965]);

translate([10, 1, 0]) cube([1, 1, 4.201245143756441]);

translate([11, 1, 0]) cube([1, 1, 4.201343646245066]);

translate([12, 1, 0]) cube([1, 1, 4.20127593884676]);

translate([13, 1, 0]) cube([1, 1, 4.2013456306806445]);

translate([14, 1, 0]) cube([1, 1, 4.3]);

translate([15, 1, 0]) cube([1, 1, 4.3]);

translate([16, 1, 0]) cube([1, 1, 4.20118864306605]);

translate([17, 1, 0]) cube([1, 1, 4.201325784153634]);

translate([18, 1, 0]) cube([1, 1, 4.2016271030227825]);

translate([19, 1, 0]) cube([1, 1, 4.201555030363268]);

translate([20, 1, 0]) cube([1, 1, 4.201896160146471]);

translate([21, 1, 0]) cube([1, 1, 4.201815022697491]);

translate([22, 1, 0]) cube([1, 1, 4.4]);

translate([23, 1, 0]) cube([1, 1, 4.5]);

translate([24, 1, 0]) cube([1, 1, 4.7]);

translate([25, 1, 0]) cube([1, 1, 4.8]);

translate([26, 1, 0]) cube([1, 1, 4.9]);

translate([27, 1, 0]) cube([1, 1, 5.0]);

translate([28, 1, 0]) cube([1, 1, 5.0]);

translate([29, 1, 0]) cube([1, 1, 5.1]);

translate([30, 1, 0]) cube([1, 1, 5.0]);

translate([31, 1, 0]) cube([1, 1, 4.9]);

translate([32, 1, 0]) cube([1, 1, 4.8]);

translate([33, 1, 0]) cube([1, 1, 4.6]);

translate([34, 1, 0]) cube([1, 1, 4.5]);

translate([35, 1, 0]) cube([1, 1, 4.4]);

translate([36, 1, 0]) cube([1, 1, 4.3]);

translate([37, 1, 0]) cube([1, 1, 4.2]);

translate([38, 1, 0]) cube([1, 1, 4.1]);

translate([39, 1, 0]) cube([1, 1, 4.0]);

translate([40, 1, 0]) cube([1, 1, 3.9]);

translate([41, 1, 0]) cube([1, 1, 3.9]);

translate([42, 1, 0]) cube([1, 1, 4.0]);

translate([43, 1, 0]) cube([1, 1, 4.1]);

translate([44, 1, 0]) cube([1, 1, 4.2]);

translate([45, 1, 0]) cube([1, 1, 4.3]);

translate([46, 1, 0]) cube([1, 1, 4.4]);

translate([47, 1, 0]) cube([1, 1, 4.5]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

translate([2, 2, 0]) cube([1, 1, 5.309999999999998]);

translate([3, 2, 0]) cube([1, 1, 4.969999999999999]);

translate([4, 2, 0]) cube([1, 1, 4.7299999999999995]);

translate([5, 2, 0]) cube([1, 1, 4.6]);

translate([6, 2, 0]) cube([1, 1, 4.4]);

translate([7, 2, 0]) cube([1, 1, 4.200773857450564]);

translate([8, 2, 0]) cube([1, 1, 4.2009986107538815]);

translate([9, 2, 0]) cube([1, 1, 4.201231450321318]);

translate([10, 2, 0]) cube([1, 1, 4.201113635931662]);

translate([11, 2, 0]) cube([1, 1, 4.201296224753746]);

translate([12, 2, 0]) cube([1, 1, 4.201252873736081]);

translate([13, 2, 0]) cube([1, 1, 4.201239613274551]);

translate([14, 2, 0]) cube([1, 1, 4.201348348357972]);

translate([15, 2, 0]) cube([1, 1, 4.20149892703266]);

translate([16, 2, 0]) cube([1, 1, 4.201909528739547]);

translate([17, 2, 0]) cube([1, 1, 4.201684832404515]);

translate([18, 2, 0]) cube([1, 1, 4.20186901709132]);

translate([19, 2, 0]) cube([1, 1, 4.201958692557069]);

translate([20, 2, 0]) cube([1, 1, 4.201968079037851]);

translate([21, 2, 0]) cube([1, 1, 4.201961512862917]);

translate([22, 2, 0]) cube([1, 1, 4.201985757459898]);

translate([23, 2, 0]) cube([1, 1, 4.2020520062130275]);

translate([24, 2, 0]) cube([1, 1, 4.4]);

translate([25, 2, 0]) cube([1, 1, 4.4]);

translate([26, 2, 0]) cube([1, 1, 4.5]);

translate([27, 2, 0]) cube([1, 1, 4.6]);

translate([28, 2, 0]) cube([1, 1, 4.7]);

translate([29, 2, 0]) cube([1, 1, 4.7]);

translate([30, 2, 0]) cube([1, 1, 4.7]);

translate([31, 2, 0]) cube([1, 1, 4.6]);

translate([32, 2, 0]) cube([1, 1, 4.5]);

translate([33, 2, 0]) cube([1, 1, 4.4]);

translate([34, 2, 0]) cube([1, 1, 4.3]);

translate([35, 2, 0]) cube([1, 1, 4.2]);

translate([36, 2, 0]) cube([1, 1, 4.1]);

translate([37, 2, 0]) cube([1, 1, 4.0]);

translate([38, 2, 0]) cube([1, 1, 3.9]);

translate([39, 2, 0]) cube([1, 1, 3.8]);

translate([40, 2, 0]) cube([1, 1, 3.6]);

translate([41, 2, 0]) cube([1, 1, 3.6]);

translate([42, 2, 0]) cube([1, 1, 3.7]);

translate([43, 2, 0]) cube([1, 1, 3.9]);

translate([44, 2, 0]) cube([1, 1, 4.0]);

translate([45, 2, 0]) cube([1, 1, 4.0]);

translate([46, 2, 0]) cube([1, 1, 4.1]);

translate([47, 2, 0]) cube([1, 1, 4.2]);

color([0,1,0])
translate([0, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

translate([4, 3, 0]) cube([1, 1, 5.2799999999999985]);

translate([5, 3, 0]) cube([1, 1, 5.01]);

translate([6, 3, 0]) cube([1, 1, 4.8]);

translate([7, 3, 0]) cube([1, 1, 4.6]);

translate([8, 3, 0]) cube([1, 1, 4.4]);

translate([9, 3, 0]) cube([1, 1, 4.4]);

translate([10, 3, 0]) cube([1, 1, 4.4]);

translate([11, 3, 0]) cube([1, 1, 4.4]);

translate([12, 3, 0]) cube([1, 1, 4.3]);

translate([13, 3, 0]) cube([1, 1, 4.3]);

translate([14, 3, 0]) cube([1, 1, 4.201277967142556]);

translate([15, 3, 0]) cube([1, 1, 4.201981185085886]);

translate([16, 3, 0]) cube([1, 1, 4.202498103204929]);

translate([17, 3, 0]) cube([1, 1, 4.2024523388424075]);

translate([18, 3, 0]) cube([1, 1, 4.201962033762854]);

translate([19, 3, 0]) cube([1, 1, 4.202085616169834]);

translate([20, 3, 0]) cube([1, 1, 4.202179780083935]);

translate([21, 3, 0]) cube([1, 1, 4.2019570505573025]);

translate([22, 3, 0]) cube([1, 1, 4.202100691239395]);

translate([23, 3, 0]) cube([1, 1, 4.201877656909136]);

translate([24, 3, 0]) cube([1, 1, 4.20234987607476]);

translate([25, 3, 0]) cube([1, 1, 4.3]);

translate([26, 3, 0]) cube([1, 1, 4.4]);

translate([27, 3, 0]) cube([1, 1, 4.4]);

translate([28, 3, 0]) cube([1, 1, 4.5]);

translate([29, 3, 0]) cube([1, 1, 4.5]);

translate([30, 3, 0]) cube([1, 1, 4.4]);

translate([31, 3, 0]) cube([1, 1, 4.3]);

translate([32, 3, 0]) cube([1, 1, 4.3]);

translate([33, 3, 0]) cube([1, 1, 4.2]);

translate([34, 3, 0]) cube([1, 1, 4.1]);

translate([35, 3, 0]) cube([1, 1, 4.0]);

translate([36, 3, 0]) cube([1, 1, 4.0]);

translate([37, 3, 0]) cube([1, 1, 3.9]);

translate([38, 3, 0]) cube([1, 1, 3.8]);

translate([39, 3, 0]) cube([1, 1, 3.6]);

translate([40, 3, 0]) cube([1, 1, 3.5]);

translate([41, 3, 0]) cube([1, 1, 3.4]);

translate([42, 3, 0]) cube([1, 1, 3.5]);

translate([43, 3, 0]) cube([1, 1, 3.7]);

translate([44, 3, 0]) cube([1, 1, 3.8]);

translate([45, 3, 0]) cube([1, 1, 3.9]);

translate([46, 3, 0]) cube([1, 1, 3.8]);

translate([47, 3, 0]) cube([1, 1, 3.8]);

color([0,1,0])
translate([0, 4, 0]) cube([1, 1, 6]);

translate([1, 4, 0]) cube([1, 1, 6.559999999999997]);

color([0,1,0])
translate([2, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

translate([5, 4, 0]) cube([1, 1, 5.42]);

translate([6, 4, 0]) cube([1, 1, 5.2]);

translate([7, 4, 0]) cube([1, 1, 5.0]);

translate([8, 4, 0]) cube([1, 1, 4.8]);

translate([9, 4, 0]) cube([1, 1, 4.8]);

translate([10, 4, 0]) cube([1, 1, 4.8]);

translate([11, 4, 0]) cube([1, 1, 4.7]);

translate([12, 4, 0]) cube([1, 1, 4.6]);

translate([13, 4, 0]) cube([1, 1, 4.4]);

translate([14, 4, 0]) cube([1, 1, 4.201496527636213]);

translate([15, 4, 0]) cube([1, 1, 4.202078801049462]);

translate([16, 4, 0]) cube([1, 1, 4.202264473256571]);

translate([17, 4, 0]) cube([1, 1, 4.202066712734377]);

translate([18, 4, 0]) cube([1, 1, 4.202340057693676]);

translate([19, 4, 0]) cube([1, 1, 4.2020592272800155]);

translate([20, 4, 0]) cube([1, 1, 4.202100958267916]);

translate([21, 4, 0]) cube([1, 1, 4.202061371726769]);

translate([22, 4, 0]) cube([1, 1, 4.201975600375137]);

translate([23, 4, 0]) cube([1, 1, 4.2023874530111165]);

translate([24, 4, 0]) cube([1, 1, 4.2023239678831095]);

translate([25, 4, 0]) cube([1, 1, 4.3]);

translate([26, 4, 0]) cube([1, 1, 4.4]);

translate([27, 4, 0]) cube([1, 1, 4.4]);

translate([28, 4, 0]) cube([1, 1, 4.3]);

translate([29, 4, 0]) cube([1, 1, 4.3]);

translate([30, 4, 0]) cube([1, 1, 4.3]);

translate([31, 4, 0]) cube([1, 1, 4.2]);

translate([32, 4, 0]) cube([1, 1, 4.1]);

translate([33, 4, 0]) cube([1, 1, 3.9]);

translate([34, 4, 0]) cube([1, 1, 3.8]);

translate([35, 4, 0]) cube([1, 1, 3.7]);

translate([36, 4, 0]) cube([1, 1, 3.7]);

translate([37, 4, 0]) cube([1, 1, 3.7]);

translate([38, 4, 0]) cube([1, 1, 3.6]);

translate([39, 4, 0]) cube([1, 1, 3.5]);

translate([40, 4, 0]) cube([1, 1, 3.4]);

translate([41, 4, 0]) cube([1, 1, 3.362194702367821]);

translate([42, 4, 0]) cube([1, 1, 3.4]);

translate([43, 4, 0]) cube([1, 1, 3.6]);

translate([44, 4, 0]) cube([1, 1, 3.7]);

translate([45, 4, 0]) cube([1, 1, 3.8]);

translate([46, 4, 0]) cube([1, 1, 3.7]);

translate([47, 4, 0]) cube([1, 1, 3.6]);

translate([0, 5, 0]) cube([1, 1, 6.596974735966422]);

translate([1, 5, 0]) cube([1, 1, 6.759999999999996]);

translate([2, 5, 0]) cube([1, 1, 6.599999999999993]);

color([0,1,0])
translate([3, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

translate([7, 5, 0]) cube([1, 1, 5.3]);

translate([8, 5, 0]) cube([1, 1, 5.2]);

translate([9, 5, 0]) cube([1, 1, 5.2]);

translate([10, 5, 0]) cube([1, 1, 5.1]);

translate([11, 5, 0]) cube([1, 1, 5.0]);

translate([12, 5, 0]) cube([1, 1, 4.8]);

translate([13, 5, 0]) cube([1, 1, 4.6]);

translate([14, 5, 0]) cube([1, 1, 4.3]);

translate([15, 5, 0]) cube([1, 1, 4.201662495797589]);

translate([16, 5, 0]) cube([1, 1, 4.201841924081252]);

translate([17, 5, 0]) cube([1, 1, 4.202263356464273]);

translate([18, 5, 0]) cube([1, 1, 4.3]);

translate([19, 5, 0]) cube([1, 1, 4.4]);

translate([20, 5, 0]) cube([1, 1, 4.5]);

translate([21, 5, 0]) cube([1, 1, 4.4]);

translate([22, 5, 0]) cube([1, 1, 4.4]);

translate([23, 5, 0]) cube([1, 1, 4.4]);

translate([24, 5, 0]) cube([1, 1, 4.4]);

translate([25, 5, 0]) cube([1, 1, 4.5]);

translate([26, 5, 0]) cube([1, 1, 4.5]);

translate([27, 5, 0]) cube([1, 1, 4.4]);

translate([28, 5, 0]) cube([1, 1, 4.3]);

translate([29, 5, 0]) cube([1, 1, 4.2]);

translate([30, 5, 0]) cube([1, 1, 4.1]);

translate([31, 5, 0]) cube([1, 1, 4.1]);

translate([32, 5, 0]) cube([1, 1, 3.9]);

translate([33, 5, 0]) cube([1, 1, 3.7]);

translate([34, 5, 0]) cube([1, 1, 3.6]);

translate([35, 5, 0]) cube([1, 1, 3.5]);

translate([36, 5, 0]) cube([1, 1, 3.5]);

translate([37, 5, 0]) cube([1, 1, 3.6]);

translate([38, 5, 0]) cube([1, 1, 3.5]);

translate([39, 5, 0]) cube([1, 1, 3.4]);

translate([40, 5, 0]) cube([1, 1, 3.3626966867585386]);

translate([41, 5, 0]) cube([1, 1, 3.363474879268931]);

translate([42, 5, 0]) cube([1, 1, 3.4]);

translate([43, 5, 0]) cube([1, 1, 3.5]);

translate([44, 5, 0]) cube([1, 1, 3.6]);

translate([45, 5, 0]) cube([1, 1, 3.7]);

translate([46, 5, 0]) cube([1, 1, 3.6]);

translate([47, 5, 0]) cube([1, 1, 3.5835900181282945]);

translate([0, 6, 0]) cube([1, 1, 6.6169747351818105]);

translate([1, 6, 0]) cube([1, 1, 6.699688816816873]);

translate([2, 6, 0]) cube([1, 1, 6.799999999999994]);

translate([3, 6, 0]) cube([1, 1, 6.669999999999992]);

color([0,1,0])
translate([4, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

translate([8, 6, 0]) cube([1, 1, 5.42]);

translate([9, 6, 0]) cube([1, 1, 5.4]);

translate([10, 6, 0]) cube([1, 1, 5.4]);

translate([11, 6, 0]) cube([1, 1, 5.2]);

translate([12, 6, 0]) cube([1, 1, 5.0]);

translate([13, 6, 0]) cube([1, 1, 4.8]);

translate([14, 6, 0]) cube([1, 1, 4.5]);

translate([15, 6, 0]) cube([1, 1, 4.4]);

translate([16, 6, 0]) cube([1, 1, 4.4]);

translate([17, 6, 0]) cube([1, 1, 4.5]);

translate([18, 6, 0]) cube([1, 1, 4.6]);

translate([19, 6, 0]) cube([1, 1, 4.8]);

translate([20, 6, 0]) cube([1, 1, 4.8]);

translate([21, 6, 0]) cube([1, 1, 4.8]);

translate([22, 6, 0]) cube([1, 1, 4.7]);

translate([23, 6, 0]) cube([1, 1, 4.7]);

translate([24, 6, 0]) cube([1, 1, 4.7]);

translate([25, 6, 0]) cube([1, 1, 4.7]);

translate([26, 6, 0]) cube([1, 1, 4.6]);

translate([27, 6, 0]) cube([1, 1, 4.4]);

translate([28, 6, 0]) cube([1, 1, 4.2]);

translate([29, 6, 0]) cube([1, 1, 4.1]);

translate([30, 6, 0]) cube([1, 1, 4.0]);

translate([31, 6, 0]) cube([1, 1, 3.9]);

translate([32, 6, 0]) cube([1, 1, 3.8]);

translate([33, 6, 0]) cube([1, 1, 3.6]);

translate([34, 6, 0]) cube([1, 1, 3.499999999122384]);

translate([35, 6, 0]) cube([1, 1, 3.499999998454608]);

translate([36, 6, 0]) cube([1, 1, 3.4999999993641597]);

translate([37, 6, 0]) cube([1, 1, 3.5]);

translate([38, 6, 0]) cube([1, 1, 3.5]);

translate([39, 6, 0]) cube([1, 1, 3.4]);

translate([40, 6, 0]) cube([1, 1, 3.36390973558617]);

translate([41, 6, 0]) cube([1, 1, 3.3638784470019707]);

translate([42, 6, 0]) cube([1, 1, 3.3639717893160594]);

translate([43, 6, 0]) cube([1, 1, 3.4]);

translate([44, 6, 0]) cube([1, 1, 3.5]);

translate([45, 6, 0]) cube([1, 1, 3.6]);

translate([46, 6, 0]) cube([1, 1, 3.6]);

translate([47, 6, 0]) cube([1, 1, 3.5842504938310196]);

translate([0, 7, 0]) cube([1, 1, 6.7409158883640865]);

translate([1, 7, 0]) cube([1, 1, 6.827618304758714]);

translate([2, 7, 0]) cube([1, 1, 6.8337056488027965]);

translate([3, 7, 0]) cube([1, 1, 6.829999999999993]);

translate([4, 7, 0]) cube([1, 1, 6.639999999999993]);

color([0,1,0])
translate([5, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

translate([11, 7, 0]) cube([1, 1, 5.4]);

translate([12, 7, 0]) cube([1, 1, 5.2]);

translate([13, 7, 0]) cube([1, 1, 4.9]);

translate([14, 7, 0]) cube([1, 1, 4.7]);

translate([15, 7, 0]) cube([1, 1, 4.6]);

translate([16, 7, 0]) cube([1, 1, 4.6]);

translate([17, 7, 0]) cube([1, 1, 4.8]);

translate([18, 7, 0]) cube([1, 1, 4.9]);

translate([19, 7, 0]) cube([1, 1, 5.1]);

translate([20, 7, 0]) cube([1, 1, 5.1]);

translate([21, 7, 0]) cube([1, 1, 5.1]);

translate([22, 7, 0]) cube([1, 1, 5.0]);

translate([23, 7, 0]) cube([1, 1, 5.0]);

translate([24, 7, 0]) cube([1, 1, 4.9]);

translate([25, 7, 0]) cube([1, 1, 4.9]);

translate([26, 7, 0]) cube([1, 1, 4.7]);

translate([27, 7, 0]) cube([1, 1, 4.5]);

translate([28, 7, 0]) cube([1, 1, 4.2]);

translate([29, 7, 0]) cube([1, 1, 4.0]);

translate([30, 7, 0]) cube([1, 1, 3.9]);

translate([31, 7, 0]) cube([1, 1, 3.8]);

translate([32, 7, 0]) cube([1, 1, 3.7]);

translate([33, 7, 0]) cube([1, 1, 3.5]);

translate([34, 7, 0]) cube([1, 1, 3.5000075132659116]);

translate([35, 7, 0]) cube([1, 1, 3.5000000001689444]);

translate([36, 7, 0]) cube([1, 1, 3.50000000020642]);

translate([37, 7, 0]) cube([1, 1, 3.5]);

translate([38, 7, 0]) cube([1, 1, 3.5]);

translate([39, 7, 0]) cube([1, 1, 3.4]);

translate([40, 7, 0]) cube([1, 1, 3.363662288937605]);

translate([41, 7, 0]) cube([1, 1, 3.363512465162119]);

translate([42, 7, 0]) cube([1, 1, 3.36334562213902]);

translate([43, 7, 0]) cube([1, 1, 3.4]);

translate([44, 7, 0]) cube([1, 1, 3.5]);

translate([45, 7, 0]) cube([1, 1, 3.6]);

translate([46, 7, 0]) cube([1, 1, 3.6]);

translate([47, 7, 0]) cube([1, 1, 3.5836467334005966]);

translate([0, 8, 0]) cube([1, 1, 6.829994801985323]);

translate([1, 8, 0]) cube([1, 1, 6.866704813201197]);

translate([2, 8, 0]) cube([1, 1, 6.917618304968525]);

translate([3, 8, 0]) cube([1, 1, 6.883406712603289]);

translate([4, 8, 0]) cube([1, 1, 6.829999999999995]);

translate([5, 8, 0]) cube([1, 1, 6.669999999999995]);

color([0,1,0])
translate([6, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

translate([12, 8, 0]) cube([1, 1, 5.3]);

translate([13, 8, 0]) cube([1, 1, 5.1]);

translate([14, 8, 0]) cube([1, 1, 4.9]);

translate([15, 8, 0]) cube([1, 1, 4.8]);

translate([16, 8, 0]) cube([1, 1, 4.9]);

translate([17, 8, 0]) cube([1, 1, 5.1]);

translate([18, 8, 0]) cube([1, 1, 5.2]);

translate([19, 8, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([20, 8, 0]) cube([1, 1, 6]);

translate([21, 8, 0]) cube([1, 1, 5.4]);

translate([22, 8, 0]) cube([1, 1, 5.4]);

translate([23, 8, 0]) cube([1, 1, 5.3]);

translate([24, 8, 0]) cube([1, 1, 5.2]);

translate([25, 8, 0]) cube([1, 1, 5.1]);

translate([26, 8, 0]) cube([1, 1, 4.8]);

translate([27, 8, 0]) cube([1, 1, 4.5]);

translate([28, 8, 0]) cube([1, 1, 4.2]);

translate([29, 8, 0]) cube([1, 1, 3.9]);

translate([30, 8, 0]) cube([1, 1, 3.8]);

translate([31, 8, 0]) cube([1, 1, 3.7]);

translate([32, 8, 0]) cube([1, 1, 3.6]);

translate([33, 8, 0]) cube([1, 1, 3.500000001952041]);

translate([34, 8, 0]) cube([1, 1, 3.5000000030015452]);

translate([35, 8, 0]) cube([1, 1, 3.5000051476046385]);

translate([36, 8, 0]) cube([1, 1, 3.5000123453800818]);

translate([37, 8, 0]) cube([1, 1, 3.500003128356363]);

translate([38, 8, 0]) cube([1, 1, 3.6]);

translate([39, 8, 0]) cube([1, 1, 3.6]);

translate([40, 8, 0]) cube([1, 1, 3.5]);

translate([41, 8, 0]) cube([1, 1, 3.5]);

translate([42, 8, 0]) cube([1, 1, 3.5]);

translate([43, 8, 0]) cube([1, 1, 3.5]);

translate([44, 8, 0]) cube([1, 1, 3.6]);

translate([45, 8, 0]) cube([1, 1, 3.7]);

translate([46, 8, 0]) cube([1, 1, 3.7]);

translate([47, 8, 0]) cube([1, 1, 3.6]);

translate([0, 9, 0]) cube([1, 1, 6.846339064463543]);

translate([1, 9, 0]) cube([1, 1, 6.931795790801273]);

translate([2, 9, 0]) cube([1, 1, 6.987784477039465]);

translate([3, 9, 0]) cube([1, 1, 6.9707859013261455]);

translate([4, 9, 0]) cube([1, 1, 6.873432383564143]);

translate([5, 9, 0]) cube([1, 1, 6.729736681620906]);

translate([6, 9, 0]) cube([1, 1, 6.689999999999996]);

color([0,1,0])
translate([7, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

translate([13, 9, 0]) cube([1, 1, 5.3]);

translate([14, 9, 0]) cube([1, 1, 5.1]);

translate([15, 9, 0]) cube([1, 1, 5.1]);

translate([16, 9, 0]) cube([1, 1, 5.2]);

translate([17, 9, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([18, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 9, 0]) cube([1, 1, 6]);

translate([24, 9, 0]) cube([1, 1, 5.3]);

translate([25, 9, 0]) cube([1, 1, 5.1]);

translate([26, 9, 0]) cube([1, 1, 4.8]);

translate([27, 9, 0]) cube([1, 1, 4.5]);

translate([28, 9, 0]) cube([1, 1, 4.2]);

translate([29, 9, 0]) cube([1, 1, 3.9]);

translate([30, 9, 0]) cube([1, 1, 3.7]);

translate([31, 9, 0]) cube([1, 1, 3.6]);

translate([32, 9, 0]) cube([1, 1, 3.500000343292603]);

translate([33, 9, 0]) cube([1, 1, 3.5000003436589666]);

translate([34, 9, 0]) cube([1, 1, 3.500002025773324]);

translate([35, 9, 0]) cube([1, 1, 3.500113333909953]);

translate([36, 9, 0]) cube([1, 1, 3.6]);

translate([37, 9, 0]) cube([1, 1, 3.7]);

translate([38, 9, 0]) cube([1, 1, 3.7]);

translate([39, 9, 0]) cube([1, 1, 3.8]);

translate([40, 9, 0]) cube([1, 1, 3.9]);

translate([41, 9, 0]) cube([1, 1, 3.9]);

translate([42, 9, 0]) cube([1, 1, 3.8]);

translate([43, 9, 0]) cube([1, 1, 3.8]);

translate([44, 9, 0]) cube([1, 1, 3.8]);

translate([45, 9, 0]) cube([1, 1, 3.8]);

translate([46, 9, 0]) cube([1, 1, 3.8]);

translate([47, 9, 0]) cube([1, 1, 3.7]);

translate([0, 10, 0]) cube([1, 1, 6.874452143362963]);

translate([1, 10, 0]) cube([1, 1, 6.9917957903035095]);

translate([2, 10, 0]) cube([1, 1, 6.994672571502347]);

translate([3, 10, 0]) cube([1, 1, 7.03778447671889]);

translate([4, 10, 0]) cube([1, 1, 6.94923110025452]);

translate([5, 10, 0]) cube([1, 1, 6.839727663260408]);

translate([6, 10, 0]) cube([1, 1, 6.697316803253628]);

translate([7, 10, 0]) cube([1, 1, 6.679999999999996]);

translate([8, 10, 0]) cube([1, 1, 6.589999999999996]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

translate([14, 10, 0]) cube([1, 1, 5.4]);

translate([15, 10, 0]) cube([1, 1, 5.3]);

translate([16, 10, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([17, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

translate([24, 10, 0]) cube([1, 1, 5.4]);

translate([25, 10, 0]) cube([1, 1, 5.1]);

translate([26, 10, 0]) cube([1, 1, 4.8]);

translate([27, 10, 0]) cube([1, 1, 4.5]);

translate([28, 10, 0]) cube([1, 1, 4.2]);

translate([29, 10, 0]) cube([1, 1, 4.0]);

translate([30, 10, 0]) cube([1, 1, 3.8]);

translate([31, 10, 0]) cube([1, 1, 3.6]);

translate([32, 10, 0]) cube([1, 1, 3.6]);

translate([33, 10, 0]) cube([1, 1, 3.6]);

translate([34, 10, 0]) cube([1, 1, 3.7]);

translate([35, 10, 0]) cube([1, 1, 3.8]);

translate([36, 10, 0]) cube([1, 1, 3.9]);

translate([37, 10, 0]) cube([1, 1, 3.9]);

translate([38, 10, 0]) cube([1, 1, 4.0]);

translate([39, 10, 0]) cube([1, 1, 4.1]);

translate([40, 10, 0]) cube([1, 1, 4.2]);

translate([41, 10, 0]) cube([1, 1, 4.3]);

translate([42, 10, 0]) cube([1, 1, 4.2]);

translate([43, 10, 0]) cube([1, 1, 4.1]);

translate([44, 10, 0]) cube([1, 1, 4.1]);

translate([45, 10, 0]) cube([1, 1, 4.0]);

translate([46, 10, 0]) cube([1, 1, 3.9]);

translate([47, 10, 0]) cube([1, 1, 3.8]);

translate([0, 11, 0]) cube([1, 1, 6.782313927941358]);

translate([1, 11, 0]) cube([1, 1, 6.954740930575629]);

translate([2, 11, 0]) cube([1, 1, 7.068278671557851]);

translate([3, 11, 0]) cube([1, 1, 7.082911589119398]);

translate([4, 11, 0]) cube([1, 1, 6.979739915791184]);

translate([5, 11, 0]) cube([1, 1, 6.878808087076196]);

translate([6, 11, 0]) cube([1, 1, 6.77731619768347]);

translate([7, 11, 0]) cube([1, 1, 6.617426902248567]);

translate([8, 11, 0]) cube([1, 1, 6.629999999999997]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

translate([24, 11, 0]) cube([1, 1, 5.4]);

translate([25, 11, 0]) cube([1, 1, 5.1]);

translate([26, 11, 0]) cube([1, 1, 4.8]);

translate([27, 11, 0]) cube([1, 1, 4.6]);

translate([28, 11, 0]) cube([1, 1, 4.4]);

translate([29, 11, 0]) cube([1, 1, 4.2]);

translate([30, 11, 0]) cube([1, 1, 3.9]);

translate([31, 11, 0]) cube([1, 1, 3.8]);

translate([32, 11, 0]) cube([1, 1, 3.8]);

translate([33, 11, 0]) cube([1, 1, 3.9]);

translate([34, 11, 0]) cube([1, 1, 4.1]);

translate([35, 11, 0]) cube([1, 1, 4.2]);

translate([36, 11, 0]) cube([1, 1, 4.2]);

translate([37, 11, 0]) cube([1, 1, 4.2]);

translate([38, 11, 0]) cube([1, 1, 4.3]);

translate([39, 11, 0]) cube([1, 1, 4.4]);

translate([40, 11, 0]) cube([1, 1, 4.5]);

translate([41, 11, 0]) cube([1, 1, 4.5]);

translate([42, 11, 0]) cube([1, 1, 4.5]);

translate([43, 11, 0]) cube([1, 1, 4.4]);

translate([44, 11, 0]) cube([1, 1, 4.3]);

translate([45, 11, 0]) cube([1, 1, 4.2]);

translate([46, 11, 0]) cube([1, 1, 4.1]);

translate([47, 11, 0]) cube([1, 1, 4.0]);

translate([0, 12, 0]) cube([1, 1, 7.024318259362024]);

translate([1, 12, 0]) cube([1, 1, 7.134074782415591]);

translate([2, 12, 0]) cube([1, 1, 7.191653315247264]);

translate([3, 12, 0]) cube([1, 1, 7.183092215502472]);

translate([4, 12, 0]) cube([1, 1, 7.0888073491699775]);

translate([5, 12, 0]) cube([1, 1, 6.946478565731104]);

translate([6, 12, 0]) cube([1, 1, 6.827061477484369]);

translate([7, 12, 0]) cube([1, 1, 6.779999999999996]);

translate([8, 12, 0]) cube([1, 1, 6.7099999999999955]);

translate([9, 12, 0]) cube([1, 1, 6.659999999999997]);

translate([10, 12, 0]) cube([1, 1, 6.589999999999998]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

translate([24, 12, 0]) cube([1, 1, 5.4]);

translate([25, 12, 0]) cube([1, 1, 5.1]);

translate([26, 12, 0]) cube([1, 1, 4.9]);

translate([27, 12, 0]) cube([1, 1, 4.7]);

translate([28, 12, 0]) cube([1, 1, 4.5]);

translate([29, 12, 0]) cube([1, 1, 4.4]);

translate([30, 12, 0]) cube([1, 1, 4.1]);

translate([31, 12, 0]) cube([1, 1, 4.0]);

translate([32, 12, 0]) cube([1, 1, 4.1]);

translate([33, 12, 0]) cube([1, 1, 4.2]);

translate([34, 12, 0]) cube([1, 1, 4.4]);

translate([35, 12, 0]) cube([1, 1, 4.6]);

translate([36, 12, 0]) cube([1, 1, 4.6]);

translate([37, 12, 0]) cube([1, 1, 4.6]);

translate([38, 12, 0]) cube([1, 1, 4.6]);

translate([39, 12, 0]) cube([1, 1, 4.6]);

translate([40, 12, 0]) cube([1, 1, 4.7]);

translate([41, 12, 0]) cube([1, 1, 4.7]);

translate([42, 12, 0]) cube([1, 1, 4.6]);

translate([43, 12, 0]) cube([1, 1, 4.5]);

translate([44, 12, 0]) cube([1, 1, 4.5]);

translate([45, 12, 0]) cube([1, 1, 4.5]);

translate([46, 12, 0]) cube([1, 1, 4.4]);

translate([47, 12, 0]) cube([1, 1, 4.3]);

translate([0, 13, 0]) cube([1, 1, 7.07152579792428]);

translate([1, 13, 0]) cube([1, 1, 7.194074782172263]);

translate([2, 13, 0]) cube([1, 1, 7.2751617576362495]);

translate([3, 13, 0]) cube([1, 1, 7.23501583690249]);

translate([4, 13, 0]) cube([1, 1, 7.159836916093848]);

translate([5, 13, 0]) cube([1, 1, 6.993498346602707]);

translate([6, 13, 0]) cube([1, 1, 6.841293842632662]);

translate([7, 13, 0]) cube([1, 1, 6.859999999999994]);

translate([8, 13, 0]) cube([1, 1, 6.799999999999994]);

translate([9, 13, 0]) cube([1, 1, 6.699999999999996]);

translate([10, 13, 0]) cube([1, 1, 6.729999999999997]);

translate([11, 13, 0]) cube([1, 1, 6.679999999999998]);

translate([12, 13, 0]) cube([1, 1, 6.529999999999998]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 13, 0]) cube([1, 1, 6]);

translate([25, 13, 0]) cube([1, 1, 5.2]);

translate([26, 13, 0]) cube([1, 1, 4.9]);

translate([27, 13, 0]) cube([1, 1, 4.8]);

translate([28, 13, 0]) cube([1, 1, 4.7]);

translate([29, 13, 0]) cube([1, 1, 4.6]);

translate([30, 13, 0]) cube([1, 1, 4.4]);

translate([31, 13, 0]) cube([1, 1, 4.3]);

translate([32, 13, 0]) cube([1, 1, 4.3]);

translate([33, 13, 0]) cube([1, 1, 4.5]);

translate([34, 13, 0]) cube([1, 1, 4.8]);

translate([35, 13, 0]) cube([1, 1, 4.9]);

translate([36, 13, 0]) cube([1, 1, 4.9]);

translate([37, 13, 0]) cube([1, 1, 4.9]);

translate([38, 13, 0]) cube([1, 1, 4.9]);

translate([39, 13, 0]) cube([1, 1, 4.9]);

translate([40, 13, 0]) cube([1, 1, 4.9]);

translate([41, 13, 0]) cube([1, 1, 4.8]);

translate([42, 13, 0]) cube([1, 1, 4.8]);

translate([43, 13, 0]) cube([1, 1, 4.7]);

translate([44, 13, 0]) cube([1, 1, 4.7]);

translate([45, 13, 0]) cube([1, 1, 4.7]);

translate([46, 13, 0]) cube([1, 1, 4.8]);

translate([47, 13, 0]) cube([1, 1, 4.7]);

translate([0, 14, 0]) cube([1, 1, 7.111998268516411]);

translate([1, 14, 0]) cube([1, 1, 7.247123404782754]);

translate([2, 14, 0]) cube([1, 1, 7.321699382020053]);

translate([3, 14, 0]) cube([1, 1, 7.3054988752705246]);

translate([4, 14, 0]) cube([1, 1, 7.216556138864195]);

translate([5, 14, 0]) cube([1, 1, 7.052234589546367]);

translate([6, 14, 0]) cube([1, 1, 6.999999999999991]);

translate([7, 14, 0]) cube([1, 1, 6.949998125650124]);

translate([8, 14, 0]) cube([1, 1, 6.910039232240338]);

translate([9, 14, 0]) cube([1, 1, 6.859999999999994]);

translate([10, 14, 0]) cube([1, 1, 6.729999822709312]);

translate([11, 14, 0]) cube([1, 1, 6.699999823380949]);

translate([12, 14, 0]) cube([1, 1, 6.689999999999998]);

translate([13, 14, 0]) cube([1, 1, 6.559999999999997]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 14, 0]) cube([1, 1, 6]);

translate([25, 14, 0]) cube([1, 1, 5.2]);

translate([26, 14, 0]) cube([1, 1, 5.0]);

translate([27, 14, 0]) cube([1, 1, 4.9]);

translate([28, 14, 0]) cube([1, 1, 4.8]);

translate([29, 14, 0]) cube([1, 1, 4.7]);

translate([30, 14, 0]) cube([1, 1, 4.6]);

translate([31, 14, 0]) cube([1, 1, 4.5]);

translate([32, 14, 0]) cube([1, 1, 4.6]);

translate([33, 14, 0]) cube([1, 1, 4.8]);

translate([34, 14, 0]) cube([1, 1, 5.1]);

translate([35, 14, 0]) cube([1, 1, 5.3]);

translate([36, 14, 0]) cube([1, 1, 5.3]);

translate([37, 14, 0]) cube([1, 1, 5.3]);

translate([38, 14, 0]) cube([1, 1, 5.2]);

translate([39, 14, 0]) cube([1, 1, 5.1]);

translate([40, 14, 0]) cube([1, 1, 5.1]);

translate([41, 14, 0]) cube([1, 1, 5.0]);

translate([42, 14, 0]) cube([1, 1, 4.9]);

translate([43, 14, 0]) cube([1, 1, 4.8]);

translate([44, 14, 0]) cube([1, 1, 4.9]);

translate([45, 14, 0]) cube([1, 1, 5.0]);

translate([46, 14, 0]) cube([1, 1, 5.1]);

translate([47, 14, 0]) cube([1, 1, 5.1]);

translate([0, 15, 0]) cube([1, 1, 7.010577226251219]);

translate([1, 15, 0]) cube([1, 1, 7.215612040814525]);

translate([2, 15, 0]) cube([1, 1, 7.3242075090075796]);

translate([3, 15, 0]) cube([1, 1, 7.344632743109652]);

translate([4, 15, 0]) cube([1, 1, 7.282497065628731]);

translate([5, 15, 0]) cube([1, 1, 7.164901208239112]);

translate([6, 15, 0]) cube([1, 1, 7.099999999999989]);

translate([7, 15, 0]) cube([1, 1, 7.05999999999999]);

translate([8, 15, 0]) cube([1, 1, 6.917735912246891]);

translate([9, 15, 0]) cube([1, 1, 6.902243649044874]);

translate([10, 15, 0]) cube([1, 1, 6.8505628600914905]);

translate([11, 15, 0]) cube([1, 1, 6.765884282729521]);

translate([12, 15, 0]) cube([1, 1, 6.732373250965895]);

translate([13, 15, 0]) cube([1, 1, 6.689999999999996]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 15, 0]) cube([1, 1, 6]);

translate([25, 15, 0]) cube([1, 1, 5.2]);

translate([26, 15, 0]) cube([1, 1, 5.0]);

translate([27, 15, 0]) cube([1, 1, 4.9]);

translate([28, 15, 0]) cube([1, 1, 4.9]);

translate([29, 15, 0]) cube([1, 1, 4.8]);

translate([30, 15, 0]) cube([1, 1, 4.7]);

translate([31, 15, 0]) cube([1, 1, 4.6]);

translate([32, 15, 0]) cube([1, 1, 4.8]);

translate([33, 15, 0]) cube([1, 1, 5.1]);

translate([34, 15, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([35, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 15, 0]) cube([1, 1, 6]);

translate([39, 15, 0]) cube([1, 1, 5.4]);

translate([40, 15, 0]) cube([1, 1, 5.3]);

translate([41, 15, 0]) cube([1, 1, 5.2]);

translate([42, 15, 0]) cube([1, 1, 5.1]);

translate([43, 15, 0]) cube([1, 1, 5.1]);

translate([44, 15, 0]) cube([1, 1, 5.1]);

translate([45, 15, 0]) cube([1, 1, 5.3]);

translate([46, 15, 0]) cube([1, 1, 5.4]);

translate([47, 15, 0]) cube([1, 1, 5.4]);

translate([0, 16, 0]) cube([1, 1, 7.023693313743381]);

translate([1, 16, 0]) cube([1, 1, 7.301276073214413]);

translate([2, 16, 0]) cube([1, 1, 7.394207510523254]);

translate([3, 16, 0]) cube([1, 1, 7.415671909370603]);

translate([4, 16, 0]) cube([1, 1, 7.335154633217618]);

translate([5, 16, 0]) cube([1, 1, 7.250787582836115]);

translate([6, 16, 0]) cube([1, 1, 7.165993594734379]);

translate([7, 16, 0]) cube([1, 1, 7.086582070890334]);

translate([8, 16, 0]) cube([1, 1, 7.041267708415729]);

translate([9, 16, 0]) cube([1, 1, 6.9331748122622265]);

translate([10, 16, 0]) cube([1, 1, 6.8989805269366595]);

translate([11, 16, 0]) cube([1, 1, 6.852235475478871]);

translate([12, 16, 0]) cube([1, 1, 6.781373202099856]);

translate([13, 16, 0]) cube([1, 1, 6.769999999999994]);

translate([14, 16, 0]) cube([1, 1, 6.539999999999995]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 16, 0]) cube([1, 1, 6]);

translate([25, 16, 0]) cube([1, 1, 5.2]);

translate([26, 16, 0]) cube([1, 1, 5.0]);

translate([27, 16, 0]) cube([1, 1, 5.0]);

translate([28, 16, 0]) cube([1, 1, 4.9]);

translate([29, 16, 0]) cube([1, 1, 4.8]);

translate([30, 16, 0]) cube([1, 1, 4.7]);

translate([31, 16, 0]) cube([1, 1, 4.7]);

translate([32, 16, 0]) cube([1, 1, 4.9]);

translate([33, 16, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([34, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 16, 0]) cube([1, 1, 6]);

translate([43, 16, 0]) cube([1, 1, 5.43]);

color([0,1,0])
translate([44, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 16, 0]) cube([1, 1, 6]);

translate([0, 17, 0]) cube([1, 1, 6.9983779875194205]);

translate([1, 17, 0]) cube([1, 1, 7.25745087904896]);

translate([2, 17, 0]) cube([1, 1, 7.4537225544869035]);

translate([3, 17, 0]) cube([1, 1, 7.484939541160286]);

translate([4, 17, 0]) cube([1, 1, 7.413350597122921]);

translate([5, 17, 0]) cube([1, 1, 7.308264571001402]);

translate([6, 17, 0]) cube([1, 1, 7.198400651441843]);

translate([7, 17, 0]) cube([1, 1, 7.109841673868563]);

translate([8, 17, 0]) cube([1, 1, 7.0376472269911705]);

translate([9, 17, 0]) cube([1, 1, 6.995977059497682]);

translate([10, 17, 0]) cube([1, 1, 6.924687466813672]);

translate([11, 17, 0]) cube([1, 1, 6.866774654000896]);

translate([12, 17, 0]) cube([1, 1, 6.85674505965364]);

translate([13, 17, 0]) cube([1, 1, 6.849999999999994]);

translate([14, 17, 0]) cube([1, 1, 6.7599999999999945]);

translate([15, 17, 0]) cube([1, 1, 6.589999999999996]);

translate([16, 17, 0]) cube([1, 1, 6.549999999999997]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 17, 0]) cube([1, 1, 6]);

translate([25, 17, 0]) cube([1, 1, 5.3]);

translate([26, 17, 0]) cube([1, 1, 5.1]);

translate([27, 17, 0]) cube([1, 1, 5.0]);

translate([28, 17, 0]) cube([1, 1, 4.9]);

translate([29, 17, 0]) cube([1, 1, 4.9]);

translate([30, 17, 0]) cube([1, 1, 4.8]);

translate([31, 17, 0]) cube([1, 1, 4.8]);

translate([32, 17, 0]) cube([1, 1, 4.9]);

translate([33, 17, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([34, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 17, 0]) cube([1, 1, 6]);

translate([0, 18, 0]) cube([1, 1, 7.00844956563849]);

translate([1, 18, 0]) cube([1, 1, 7.280921387544865]);

translate([2, 18, 0]) cube([1, 1, 7.473824336499111]);

translate([3, 18, 0]) cube([1, 1, 7.5258579318384]);

translate([4, 18, 0]) cube([1, 1, 7.446874168525376]);

translate([5, 18, 0]) cube([1, 1, 7.336850483468267]);

translate([6, 18, 0]) cube([1, 1, 7.20519867538096]);

translate([7, 18, 0]) cube([1, 1, 7.148739910343101]);

translate([8, 18, 0]) cube([1, 1, 6.939737001102026]);

translate([9, 18, 0]) cube([1, 1, 6.937100517021602]);

translate([10, 18, 0]) cube([1, 1, 6.909499736453342]);

translate([11, 18, 0]) cube([1, 1, 6.904687621654374]);

translate([12, 18, 0]) cube([1, 1, 6.867571034261885]);

translate([13, 18, 0]) cube([1, 1, 6.8269983908834195]);

translate([14, 18, 0]) cube([1, 1, 6.8399999999999945]);

translate([15, 18, 0]) cube([1, 1, 6.769999999999996]);

translate([16, 18, 0]) cube([1, 1, 6.709999999999997]);

translate([17, 18, 0]) cube([1, 1, 6.609999999999998]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 18, 0]) cube([1, 1, 6]);

translate([25, 18, 0]) cube([1, 1, 5.4]);

translate([26, 18, 0]) cube([1, 1, 5.2]);

translate([27, 18, 0]) cube([1, 1, 5.1]);

translate([28, 18, 0]) cube([1, 1, 5.1]);

translate([29, 18, 0]) cube([1, 1, 5.0]);

translate([30, 18, 0]) cube([1, 1, 4.9]);

translate([31, 18, 0]) cube([1, 1, 4.9]);

translate([32, 18, 0]) cube([1, 1, 5.1]);

translate([33, 18, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([34, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 7.177049224044975]);

translate([1, 19, 0]) cube([1, 1, 7.305392447694249]);

translate([2, 19, 0]) cube([1, 1, 7.443829435017362]);

translate([3, 19, 0]) cube([1, 1, 7.502724104699478]);

translate([4, 19, 0]) cube([1, 1, 7.422723182595206]);

translate([5, 19, 0]) cube([1, 1, 7.35183631473479]);

translate([6, 19, 0]) cube([1, 1, 7.029329330808997]);

translate([7, 19, 0]) cube([1, 1, 6.939781464049769]);

translate([8, 19, 0]) cube([1, 1, 6.949734233074612]);

translate([9, 19, 0]) cube([1, 1, 6.939337747249351]);

translate([10, 19, 0]) cube([1, 1, 6.931287916262471]);

translate([11, 19, 0]) cube([1, 1, 6.90288139013196]);

translate([12, 19, 0]) cube([1, 1, 6.8422277320796345]);

translate([13, 19, 0]) cube([1, 1, 6.84708766796736]);

translate([14, 19, 0]) cube([1, 1, 6.777099648527494]);

translate([15, 19, 0]) cube([1, 1, 6.609969097614919]);

translate([16, 19, 0]) cube([1, 1, 6.579969289753265]);

translate([17, 19, 0]) cube([1, 1, 6.5779266110359496]);

translate([18, 19, 0]) cube([1, 1, 6.599999999999998]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 19, 0]) cube([1, 1, 6]);

translate([26, 19, 0]) cube([1, 1, 5.3]);

translate([27, 19, 0]) cube([1, 1, 5.3]);

translate([28, 19, 0]) cube([1, 1, 5.2]);

translate([29, 19, 0]) cube([1, 1, 5.2]);

translate([30, 19, 0]) cube([1, 1, 5.1]);

translate([31, 19, 0]) cube([1, 1, 5.1]);

translate([32, 19, 0]) cube([1, 1, 5.2]);

translate([33, 19, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([34, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 19, 0]) cube([1, 1, 6]);

translate([41, 19, 0]) cube([1, 1, 6.689999999999998]);

translate([42, 19, 0]) cube([1, 1, 6.669999999999998]);

translate([43, 19, 0]) cube([1, 1, 6.589999999999998]);

color([0,1,0])
translate([44, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 19, 0]) cube([1, 1, 6]);

translate([0, 20, 0]) cube([1, 1, 7.183234301548506]);

translate([1, 20, 0]) cube([1, 1, 7.266014365583152]);

translate([2, 20, 0]) cube([1, 1, 7.327867980308937]);

translate([3, 20, 0]) cube([1, 1, 7.368815089016288]);

translate([4, 20, 0]) cube([1, 1, 7.414441801050801]);

translate([5, 20, 0]) cube([1, 1, 6.990198751249796]);

translate([6, 20, 0]) cube([1, 1, 6.928980554478466]);

translate([7, 20, 0]) cube([1, 1, 6.92455389797492]);

translate([8, 20, 0]) cube([1, 1, 6.924552408644405]);

translate([9, 20, 0]) cube([1, 1, 6.924554614998135]);

translate([10, 20, 0]) cube([1, 1, 6.924555830527845]);

translate([11, 20, 0]) cube([1, 1, 6.877110155672143]);

translate([12, 20, 0]) cube([1, 1, 6.849420184885914]);

translate([13, 20, 0]) cube([1, 1, 6.800885640019284]);

translate([14, 20, 0]) cube([1, 1, 6.690974305154852]);

translate([15, 20, 0]) cube([1, 1, 6.605259453676876]);

translate([16, 20, 0]) cube([1, 1, 6.5841802898868185]);

translate([17, 20, 0]) cube([1, 1, 6.580004269890271]);

translate([18, 20, 0]) cube([1, 1, 6.679999999999998]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 20, 0]) cube([1, 1, 6]);

translate([28, 20, 0]) cube([1, 1, 5.4]);

translate([29, 20, 0]) cube([1, 1, 5.4]);

translate([30, 20, 0]) cube([1, 1, 5.3]);

translate([31, 20, 0]) cube([1, 1, 5.3]);

translate([32, 20, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([33, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 20, 0]) cube([1, 1, 6]);

translate([40, 20, 0]) cube([1, 1, 6.679999999999998]);

color([0,1,0])
translate([41, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 20, 0]) cube([1, 1, 6]);

translate([44, 20, 0]) cube([1, 1, 6.669999999999998]);

color([0,1,0])
translate([45, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 20, 0]) cube([1, 1, 6]);

translate([0, 21, 0]) cube([1, 1, 6.76065594414792]);

translate([1, 21, 0]) cube([1, 1, 7.256020718539418]);

translate([2, 21, 0]) cube([1, 1, 7.312006391604685]);

translate([3, 21, 0]) cube([1, 1, 7.317868265006826]);

translate([4, 21, 0]) cube([1, 1, 7.217567885174283]);

translate([5, 21, 0]) cube([1, 1, 7.033213997684291]);

translate([6, 21, 0]) cube([1, 1, 6.934260523373659]);

translate([7, 21, 0]) cube([1, 1, 6.972873086454594]);

translate([8, 21, 0]) cube([1, 1, 6.962835081478253]);

translate([9, 21, 0]) cube([1, 1, 6.954534526772029]);

translate([10, 21, 0]) cube([1, 1, 6.931393252506604]);

translate([11, 21, 0]) cube([1, 1, 6.867111318121895]);

translate([12, 21, 0]) cube([1, 1, 6.818145981718054]);

translate([13, 21, 0]) cube([1, 1, 6.707338579019741]);

translate([14, 21, 0]) cube([1, 1, 6.614265833549533]);

translate([15, 21, 0]) cube([1, 1, 6.614180289876685]);

translate([16, 21, 0]) cube([1, 1, 6.596012728118813]);

translate([17, 21, 0]) cube([1, 1, 6.594397356333826]);

translate([18, 21, 0]) cube([1, 1, 6.6999999999999975]);

translate([19, 21, 0]) cube([1, 1, 6.509999999999998]);

color([0,1,0])
translate([20, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 21, 0]) cube([1, 1, 6]);

translate([39, 21, 0]) cube([1, 1, 6.579999999999998]);

color([0,1,0])
translate([40, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 21, 0]) cube([1, 1, 6]);

translate([0, 22, 0]) cube([1, 1, 6.76990097256469]);

translate([1, 22, 0]) cube([1, 1, 7.140508112685829]);

translate([2, 22, 0]) cube([1, 1, 7.244402234537753]);

translate([3, 22, 0]) cube([1, 1, 7.266904021690858]);

translate([4, 22, 0]) cube([1, 1, 7.173213983836402]);

translate([5, 22, 0]) cube([1, 1, 7.0790290125212225]);

translate([6, 22, 0]) cube([1, 1, 7.010268975492089]);

translate([7, 22, 0]) cube([1, 1, 7.000778649842892]);

translate([8, 22, 0]) cube([1, 1, 6.966248018328294]);

translate([9, 22, 0]) cube([1, 1, 6.956922093861581]);

translate([10, 22, 0]) cube([1, 1, 6.915250626723135]);

translate([11, 22, 0]) cube([1, 1, 6.861024904040363]);

translate([12, 22, 0]) cube([1, 1, 6.779529300806405]);

translate([13, 22, 0]) cube([1, 1, 6.649555205110037]);

translate([14, 22, 0]) cube([1, 1, 6.61450067054564]);

translate([15, 22, 0]) cube([1, 1, 6.6051677564133655]);

translate([16, 22, 0]) cube([1, 1, 6.62408920227697]);

translate([17, 22, 0]) cube([1, 1, 6.729999999999997]);

translate([18, 22, 0]) cube([1, 1, 6.609999999999998]);

translate([19, 22, 0]) cube([1, 1, 6.555679219587148]);

color([0,1,0])
translate([20, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 22, 0]) cube([1, 1, 6]);

translate([22, 22, 0]) cube([1, 1, 6.6]);

translate([23, 22, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([24, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 22, 0]) cube([1, 1, 6]);

translate([39, 22, 0]) cube([1, 1, 6.669999999999998]);

color([0,1,0])
translate([40, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 22, 0]) cube([1, 1, 6]);

translate([0, 23, 0]) cube([1, 1, 7.134116445656532]);

translate([1, 23, 0]) cube([1, 1, 7.204314285877456]);

translate([2, 23, 0]) cube([1, 1, 7.251710363750798]);

translate([3, 23, 0]) cube([1, 1, 7.235216658777777]);

translate([4, 23, 0]) cube([1, 1, 7.159007712388277]);

translate([5, 23, 0]) cube([1, 1, 7.073423785010599]);

translate([6, 23, 0]) cube([1, 1, 7.007274087346625]);

translate([7, 23, 0]) cube([1, 1, 6.9756241669182195]);

translate([8, 23, 0]) cube([1, 1, 6.96686909578475]);

translate([9, 23, 0]) cube([1, 1, 6.926197944766854]);

translate([10, 23, 0]) cube([1, 1, 6.871742431521732]);

translate([11, 23, 0]) cube([1, 1, 6.795000719943794]);

translate([12, 23, 0]) cube([1, 1, 6.742188733924738]);

translate([13, 23, 0]) cube([1, 1, 6.691326969192213]);

translate([14, 23, 0]) cube([1, 1, 6.653396692456464]);

translate([15, 23, 0]) cube([1, 1, 6.649028049658269]);

translate([16, 23, 0]) cube([1, 1, 6.642386999086756]);

translate([17, 23, 0]) cube([1, 1, 6.719999999999997]);

translate([18, 23, 0]) cube([1, 1, 6.591421312028194]);

translate([19, 23, 0]) cube([1, 1, 6.5776465089793605]);

translate([20, 23, 0]) cube([1, 1, 6.567992313228011]);

translate([21, 23, 0]) cube([1, 1, 6.559999999999999]);

translate([22, 23, 0]) cube([1, 1, 6.619999999999999]);

translate([23, 23, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([24, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 23, 0]) cube([1, 1, 6]);

translate([39, 23, 0]) cube([1, 1, 6.579999999999998]);

translate([40, 23, 0]) cube([1, 1, 6.709999999999997]);

color([0,1,0])
translate([41, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 23, 0]) cube([1, 1, 6]);

translate([0, 24, 0]) cube([1, 1, 7.168356309807034]);

translate([1, 24, 0]) cube([1, 1, 7.208768335504407]);

translate([2, 24, 0]) cube([1, 1, 7.211235659058656]);

translate([3, 24, 0]) cube([1, 1, 7.171116863816147]);

translate([4, 24, 0]) cube([1, 1, 7.134071390898542]);

translate([5, 24, 0]) cube([1, 1, 7.014922766860401]);

translate([6, 24, 0]) cube([1, 1, 6.979318726096651]);

translate([7, 24, 0]) cube([1, 1, 6.952948904506347]);

translate([8, 24, 0]) cube([1, 1, 6.939999999999992]);

translate([9, 24, 0]) cube([1, 1, 6.859999999999992]);

translate([10, 24, 0]) cube([1, 1, 6.839999999999993]);

translate([11, 24, 0]) cube([1, 1, 6.789999999999996]);

translate([12, 24, 0]) cube([1, 1, 6.779999999999996]);

translate([13, 24, 0]) cube([1, 1, 6.63457873807839]);

translate([14, 24, 0]) cube([1, 1, 6.640371836187682]);

translate([15, 24, 0]) cube([1, 1, 6.6379137052923625]);

translate([16, 24, 0]) cube([1, 1, 6.637913705372026]);

translate([17, 24, 0]) cube([1, 1, 6.6999999999999975]);

translate([18, 24, 0]) cube([1, 1, 6.619999999999997]);

translate([19, 24, 0]) cube([1, 1, 6.596769667526892]);

translate([20, 24, 0]) cube([1, 1, 6.569922441126624]);

translate([21, 24, 0]) cube([1, 1, 6.589999999999998]);

translate([22, 24, 0]) cube([1, 1, 6.639999999999999]);

translate([23, 24, 0]) cube([1, 1, 6.549999999999999]);

color([0,1,0])
translate([24, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 24, 0]) cube([1, 1, 6]);

translate([40, 24, 0]) cube([1, 1, 6.589999999999998]);

translate([41, 24, 0]) cube([1, 1, 6.6999999999999975]);

color([0,1,0])
translate([42, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 24, 0]) cube([1, 1, 6]);

translate([44, 24, 0]) cube([1, 1, 6.679999999999998]);

color([0,1,0])
translate([45, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 24, 0]) cube([1, 1, 6]);

translate([0, 25, 0]) cube([1, 1, 7.107315799863831]);

translate([1, 25, 0]) cube([1, 1, 7.1561812495487604]);

translate([2, 25, 0]) cube([1, 1, 7.166659454082205]);

translate([3, 25, 0]) cube([1, 1, 7.145863321810196]);

translate([4, 25, 0]) cube([1, 1, 7.06588090549014]);

translate([5, 25, 0]) cube([1, 1, 6.974178186507144]);

translate([6, 25, 0]) cube([1, 1, 6.914687061751814]);

translate([7, 25, 0]) cube([1, 1, 6.919999999999993]);

translate([8, 25, 0]) cube([1, 1, 6.749999999999993]);

translate([9, 25, 0]) cube([1, 1, 6.609999999999993]);

translate([10, 25, 0]) cube([1, 1, 6.5499999999999945]);

color([0,1,0])
translate([11, 25, 0]) cube([1, 1, 6]);

translate([12, 25, 0]) cube([1, 1, 6.569999999999997]);

translate([13, 25, 0]) cube([1, 1, 6.589999999999996]);

translate([14, 25, 0]) cube([1, 1, 6.689999999999998]);

translate([15, 25, 0]) cube([1, 1, 6.6999999999999975]);

translate([16, 25, 0]) cube([1, 1, 6.679999999999998]);

translate([17, 25, 0]) cube([1, 1, 6.629999999999997]);

translate([18, 25, 0]) cube([1, 1, 6.619999999999997]);

translate([19, 25, 0]) cube([1, 1, 6.619999999999997]);

translate([20, 25, 0]) cube([1, 1, 6.619999999999997]);

translate([21, 25, 0]) cube([1, 1, 6.689999999999998]);

translate([22, 25, 0]) cube([1, 1, 6.689999999999998]);

translate([23, 25, 0]) cube([1, 1, 6.5699999999999985]);

color([0,1,0])
translate([24, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 25, 0]) cube([1, 1, 6]);

translate([28, 25, 0]) cube([1, 1, 5.4]);

translate([29, 25, 0]) cube([1, 1, 5.4]);

translate([30, 25, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([31, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 25, 0]) cube([1, 1, 6]);

translate([41, 25, 0]) cube([1, 1, 6.579999999999998]);

translate([42, 25, 0]) cube([1, 1, 6.589999999999998]);

translate([43, 25, 0]) cube([1, 1, 6.579999999999998]);

translate([44, 25, 0]) cube([1, 1, 6.579999999999998]);

color([0,1,0])
translate([45, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 25, 0]) cube([1, 1, 6]);

translate([0, 26, 0]) cube([1, 1, 6.9973165559522625]);

translate([1, 26, 0]) cube([1, 1, 7.065935079985259]);

translate([2, 26, 0]) cube([1, 1, 7.07364604421106]);

translate([3, 26, 0]) cube([1, 1, 7.050518819377313]);

translate([4, 26, 0]) cube([1, 1, 6.9305188168221035]);

translate([5, 26, 0]) cube([1, 1, 6.864867700338897]);

translate([6, 26, 0]) cube([1, 1, 6.829999999999995]);

translate([7, 26, 0]) cube([1, 1, 6.7599999999999945]);

translate([8, 26, 0]) cube([1, 1, 6.559999999999994]);

color([0,1,0])
translate([9, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 26, 0]) cube([1, 1, 6]);

translate([16, 26, 0]) cube([1, 1, 6.5699999999999985]);

translate([17, 26, 0]) cube([1, 1, 6.609999999999998]);

translate([18, 26, 0]) cube([1, 1, 6.679999999999998]);

translate([19, 26, 0]) cube([1, 1, 6.689999999999998]);

translate([20, 26, 0]) cube([1, 1, 6.48881983062899]);

translate([21, 26, 0]) cube([1, 1, 6.491878114796907]);

translate([22, 26, 0]) cube([1, 1, 6.4936143658722]);

translate([23, 26, 0]) cube([1, 1, 6.609999999999998]);

color([0,1,0])
translate([24, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 26, 0]) cube([1, 1, 6]);

translate([28, 26, 0]) cube([1, 1, 5.4]);

translate([29, 26, 0]) cube([1, 1, 5.380466752062821]);

translate([30, 26, 0]) cube([1, 1, 5.380381527648594]);

translate([31, 26, 0]) cube([1, 1, 5.380375139362632]);

translate([32, 26, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([33, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 26, 0]) cube([1, 1, 6]);

translate([0, 27, 0]) cube([1, 1, 6.9821086824955785]);

translate([1, 27, 0]) cube([1, 1, 7.009999999999991]);

translate([2, 27, 0]) cube([1, 1, 7.009999999999991]);

translate([3, 27, 0]) cube([1, 1, 6.949999999999992]);

translate([4, 27, 0]) cube([1, 1, 6.859999999999992]);

translate([5, 27, 0]) cube([1, 1, 6.789999999999994]);

translate([6, 27, 0]) cube([1, 1, 6.669999999999995]);

color([0,1,0])
translate([7, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 27, 0]) cube([1, 1, 6]);

translate([17, 27, 0]) cube([1, 1, 6.509999999999998]);

translate([18, 27, 0]) cube([1, 1, 6.689999999999998]);

translate([19, 27, 0]) cube([1, 1, 6.4888198310115435]);

translate([20, 27, 0]) cube([1, 1, 6.518727647766594]);

translate([21, 27, 0]) cube([1, 1, 6.523655581376563]);

translate([22, 27, 0]) cube([1, 1, 6.516433442861861]);

translate([23, 27, 0]) cube([1, 1, 6.504476736719766]);

translate([24, 27, 0]) cube([1, 1, 6.519999999999998]);

color([0,1,0])
translate([25, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 27, 0]) cube([1, 1, 6]);

translate([29, 27, 0]) cube([1, 1, 5.380377518240969]);

translate([30, 27, 0]) cube([1, 1, 5.380916159520666]);

translate([31, 27, 0]) cube([1, 1, 5.381135250657452]);

translate([32, 27, 0]) cube([1, 1, 5.381204336169608]);

translate([33, 27, 0]) cube([1, 1, 5.381268184377537]);

color([0,1,0])
translate([34, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 27, 0]) cube([1, 1, 6]);

translate([0, 28, 0]) cube([1, 1, 6.762116079573841]);

translate([1, 28, 0]) cube([1, 1, 6.909999999999993]);

translate([2, 28, 0]) cube([1, 1, 6.869999999999992]);

translate([3, 28, 0]) cube([1, 1, 6.739999999999993]);

translate([4, 28, 0]) cube([1, 1, 6.579999999999994]);

translate([5, 28, 0]) cube([1, 1, 6.529999999999995]);

color([0,1,0])
translate([6, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 28, 0]) cube([1, 1, 6]);

translate([18, 28, 0]) cube([1, 1, 6.619999999999997]);

translate([19, 28, 0]) cube([1, 1, 6.508924487544736]);

translate([20, 28, 0]) cube([1, 1, 6.452416227187676]);

translate([21, 28, 0]) cube([1, 1, 6.355442040838217]);

translate([22, 28, 0]) cube([1, 1, 6.397309408385221]);

translate([23, 28, 0]) cube([1, 1, 6.5144962169001275]);

translate([24, 28, 0]) cube([1, 1, 6.639999999999997]);

color([0,1,0])
translate([25, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 28, 0]) cube([1, 1, 6]);

translate([30, 28, 0]) cube([1, 1, 5.3807431570371715]);

translate([31, 28, 0]) cube([1, 1, 5.38119137123095]);

translate([32, 28, 0]) cube([1, 1, 5.381400660891773]);

translate([33, 28, 0]) cube([1, 1, 5.380955353407934]);

color([0,1,0])
translate([34, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 28, 0]) cube([1, 1, 6]);

translate([0, 29, 0]) cube([1, 1, 6.665974327735739]);

translate([1, 29, 0]) cube([1, 1, 6.681045550726394]);

translate([2, 29, 0]) cube([1, 1, 6.799999999999995]);

translate([3, 29, 0]) cube([1, 1, 6.659999999999995]);

color([0,1,0])
translate([4, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 29, 0]) cube([1, 1, 6]);

translate([18, 29, 0]) cube([1, 1, 6.559999999999997]);

translate([19, 29, 0]) cube([1, 1, 6.499076181224983]);

translate([20, 29, 0]) cube([1, 1, 6.431691814444878]);

translate([21, 29, 0]) cube([1, 1, 6.355442643748276]);

translate([22, 29, 0]) cube([1, 1, 6.419072542119973]);

translate([23, 29, 0]) cube([1, 1, 6.512561872574758]);

translate([24, 29, 0]) cube([1, 1, 6.619999999999997]);

color([0,1,0])
translate([25, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 29, 0]) cube([1, 1, 6]);

translate([30, 29, 0]) cube([1, 1, 5.4]);

translate([31, 29, 0]) cube([1, 1, 5.380762890452644]);

translate([32, 29, 0]) cube([1, 1, 5.381542377411782]);

translate([33, 29, 0]) cube([1, 1, 5.381599195353076]);

translate([34, 29, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([35, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 29, 0]) cube([1, 1, 6]);

translate([47, 29, 0]) cube([1, 1, 5.31]);

translate([0, 30, 0]) cube([1, 1, 6.552016977015769]);

translate([1, 30, 0]) cube([1, 1, 6.579865424818186]);

translate([2, 30, 0]) cube([1, 1, 6.739999999999997]);

translate([3, 30, 0]) cube([1, 1, 6.529999999999995]);

color([0,1,0])
translate([4, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 30, 0]) cube([1, 1, 6]);

translate([18, 30, 0]) cube([1, 1, 6.549999999999997]);

translate([19, 30, 0]) cube([1, 1, 6.709999999999997]);

translate([20, 30, 0]) cube([1, 1, 6.493826001901088]);

translate([21, 30, 0]) cube([1, 1, 6.424951522100731]);

translate([22, 30, 0]) cube([1, 1, 6.5136193093879085]);

translate([23, 30, 0]) cube([1, 1, 6.523172164305427]);

translate([24, 30, 0]) cube([1, 1, 6.539999999999997]);

color([0,1,0])
translate([25, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 30, 0]) cube([1, 1, 6]);

translate([31, 30, 0]) cube([1, 1, 5.4]);

translate([32, 30, 0]) cube([1, 1, 5.381293144576386]);

translate([33, 30, 0]) cube([1, 1, 5.381952097653687]);

translate([34, 30, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([35, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 30, 0]) cube([1, 1, 6]);

translate([46, 30, 0]) cube([1, 1, 5.4]);

translate([47, 30, 0]) cube([1, 1, 5.119999999999999]);

translate([0, 31, 0]) cube([1, 1, 6.499942637412681]);

translate([1, 31, 0]) cube([1, 1, 6.5334318381947085]);

translate([2, 31, 0]) cube([1, 1, 6.561345500322875]);

translate([3, 31, 0]) cube([1, 1, 6.529999999999995]);

color([0,1,0])
translate([4, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 31, 0]) cube([1, 1, 6]);

translate([19, 31, 0]) cube([1, 1, 6.739999999999997]);

translate([20, 31, 0]) cube([1, 1, 6.513528422950549]);

translate([21, 31, 0]) cube([1, 1, 6.482841836738536]);

translate([22, 31, 0]) cube([1, 1, 6.536722640618015]);

translate([23, 31, 0]) cube([1, 1, 6.659999999999997]);

color([0,1,0])
translate([24, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 31, 0]) cube([1, 1, 6]);

translate([32, 31, 0]) cube([1, 1, 5.4]);

translate([33, 31, 0]) cube([1, 1, 5.381411897178457]);

translate([34, 31, 0]) cube([1, 1, 5.381740461301624]);

translate([35, 31, 0]) cube([1, 1, 5.382676205473828]);

translate([36, 31, 0]) cube([1, 1, 5.382733089318882]);

translate([37, 31, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([38, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 31, 0]) cube([1, 1, 6]);

translate([46, 31, 0]) cube([1, 1, 5.3]);

translate([47, 31, 0]) cube([1, 1, 5.02]);

translate([0, 32, 0]) cube([1, 1, 6.492107372892949]);

translate([1, 32, 0]) cube([1, 1, 6.505793271149009]);

translate([2, 32, 0]) cube([1, 1, 6.561126916531548]);

translate([3, 32, 0]) cube([1, 1, 6.5499999999999945]);

color([0,1,0])
translate([4, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 32, 0]) cube([1, 1, 6]);

translate([19, 32, 0]) cube([1, 1, 6.739999999999997]);

translate([20, 32, 0]) cube([1, 1, 6.5363417360468965]);

translate([21, 32, 0]) cube([1, 1, 6.575001004693919]);

translate([22, 32, 0]) cube([1, 1, 6.553043754587062]);

translate([23, 32, 0]) cube([1, 1, 6.649999999999997]);

color([0,1,0])
translate([24, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 32, 0]) cube([1, 1, 6]);

translate([33, 32, 0]) cube([1, 1, 5.4]);

translate([34, 32, 0]) cube([1, 1, 5.4]);

translate([35, 32, 0]) cube([1, 1, 5.4]);

translate([36, 32, 0]) cube([1, 1, 5.382953053781046]);

translate([37, 32, 0]) cube([1, 1, 5.382908638412789]);

translate([38, 32, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([39, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 32, 0]) cube([1, 1, 6]);

translate([45, 32, 0]) cube([1, 1, 5.4]);

translate([46, 32, 0]) cube([1, 1, 5.1]);

translate([47, 32, 0]) cube([1, 1, 4.9399999999999995]);

translate([0, 33, 0]) cube([1, 1, 6.493709821304714]);

translate([1, 33, 0]) cube([1, 1, 6.5086226799777505]);

translate([2, 33, 0]) cube([1, 1, 6.538944935728509]);

color([0,1,0])
translate([3, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 33, 0]) cube([1, 1, 6]);

translate([18, 33, 0]) cube([1, 1, 6.609999999999996]);

translate([19, 33, 0]) cube([1, 1, 6.7499999999999964]);

translate([20, 33, 0]) cube([1, 1, 6.589621719626333]);

translate([21, 33, 0]) cube([1, 1, 6.5606943563287246]);

translate([22, 33, 0]) cube([1, 1, 6.553626321832049]);

translate([23, 33, 0]) cube([1, 1, 6.629999999999997]);

color([0,1,0])
translate([24, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 33, 0]) cube([1, 1, 6]);

translate([36, 33, 0]) cube([1, 1, 5.4]);

translate([37, 33, 0]) cube([1, 1, 5.4]);

translate([38, 33, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([39, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 33, 0]) cube([1, 1, 6]);

translate([44, 33, 0]) cube([1, 1, 5.4]);

translate([45, 33, 0]) cube([1, 1, 5.2]);

translate([46, 33, 0]) cube([1, 1, 5.0]);

translate([47, 33, 0]) cube([1, 1, 4.819999999999999]);

translate([0, 34, 0]) cube([1, 1, 6.5077670572895245]);

translate([1, 34, 0]) cube([1, 1, 6.506419020745798]);

translate([2, 34, 0]) cube([1, 1, 6.6999999999999975]);

color([0,1,0])
translate([3, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 34, 0]) cube([1, 1, 6]);

translate([17, 34, 0]) cube([1, 1, 6.609999999999996]);

translate([18, 34, 0]) cube([1, 1, 6.759999999999996]);

translate([19, 34, 0]) cube([1, 1, 6.600739249914991]);

translate([20, 34, 0]) cube([1, 1, 6.55898542765592]);

translate([21, 34, 0]) cube([1, 1, 6.553841600552284]);

translate([22, 34, 0]) cube([1, 1, 6.553996925255943]);

translate([23, 34, 0]) cube([1, 1, 6.639999999999997]);

color([0,1,0])
translate([24, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 34, 0]) cube([1, 1, 6]);

translate([43, 34, 0]) cube([1, 1, 5.4]);

translate([44, 34, 0]) cube([1, 1, 5.3]);

translate([45, 34, 0]) cube([1, 1, 5.1]);

translate([46, 34, 0]) cube([1, 1, 4.9]);

translate([47, 34, 0]) cube([1, 1, 4.8]);

translate([0, 35, 0]) cube([1, 1, 6.50476690224576]);

translate([1, 35, 0]) cube([1, 1, 6.504308184238654]);

translate([2, 35, 0]) cube([1, 1, 6.629999999999997]);

color([0,1,0])
translate([3, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 35, 0]) cube([1, 1, 6]);

translate([16, 35, 0]) cube([1, 1, 6.5799999999999965]);

translate([17, 35, 0]) cube([1, 1, 6.7499999999999964]);

translate([18, 35, 0]) cube([1, 1, 6.595725943574121]);

translate([19, 35, 0]) cube([1, 1, 6.606738527306504]);

translate([20, 35, 0]) cube([1, 1, 6.597438309098717]);

translate([21, 35, 0]) cube([1, 1, 6.574403645572165]);

translate([22, 35, 0]) cube([1, 1, 6.56305990818524]);

translate([23, 35, 0]) cube([1, 1, 6.649999999999997]);

color([0,1,0])
translate([24, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 35, 0]) cube([1, 1, 6]);

translate([42, 35, 0]) cube([1, 1, 5.4]);

translate([43, 35, 0]) cube([1, 1, 5.3]);

translate([44, 35, 0]) cube([1, 1, 5.1]);

translate([45, 35, 0]) cube([1, 1, 4.9]);

translate([46, 35, 0]) cube([1, 1, 4.8]);

translate([47, 35, 0]) cube([1, 1, 4.7]);

translate([0, 36, 0]) cube([1, 1, 6.669999999999998]);

translate([1, 36, 0]) cube([1, 1, 6.609999999999998]);

color([0,1,0])
translate([2, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 36, 0]) cube([1, 1, 6]);

translate([16, 36, 0]) cube([1, 1, 6.719999999999997]);

translate([17, 36, 0]) cube([1, 1, 6.597797305302428]);

translate([18, 36, 0]) cube([1, 1, 6.557605296109794]);

translate([19, 36, 0]) cube([1, 1, 6.524979606339363]);

translate([20, 36, 0]) cube([1, 1, 6.536392917085119]);

translate([21, 36, 0]) cube([1, 1, 6.534672191965748]);

translate([22, 36, 0]) cube([1, 1, 6.555141824005888]);

translate([23, 36, 0]) cube([1, 1, 6.609999999999998]);

color([0,1,0])
translate([24, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 36, 0]) cube([1, 1, 6]);

translate([40, 36, 0]) cube([1, 1, 5.4]);

translate([41, 36, 0]) cube([1, 1, 5.4]);

translate([42, 36, 0]) cube([1, 1, 5.3]);

translate([43, 36, 0]) cube([1, 1, 5.1]);

translate([44, 36, 0]) cube([1, 1, 4.9]);

translate([45, 36, 0]) cube([1, 1, 4.8]);

translate([46, 36, 0]) cube([1, 1, 4.7]);

translate([47, 36, 0]) cube([1, 1, 4.6368669807001455]);

translate([0, 37, 0]) cube([1, 1, 6.549999999999999]);

color([0,1,0])
translate([1, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 37, 0]) cube([1, 1, 6]);

translate([15, 37, 0]) cube([1, 1, 6.569999999999997]);

translate([16, 37, 0]) cube([1, 1, 6.547785063890656]);

translate([17, 37, 0]) cube([1, 1, 6.537556447198128]);

translate([18, 37, 0]) cube([1, 1, 6.455202318712749]);

translate([19, 37, 0]) cube([1, 1, 6.455202637877512]);

translate([20, 37, 0]) cube([1, 1, 6.4588444545059644]);

translate([21, 37, 0]) cube([1, 1, 6.533897236793528]);

translate([22, 37, 0]) cube([1, 1, 6.537674082823811]);

translate([23, 37, 0]) cube([1, 1, 6.549999999999997]);

color([0,1,0])
translate([24, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 37, 0]) cube([1, 1, 6]);

translate([38, 37, 0]) cube([1, 1, 5.400009496060868]);

translate([39, 37, 0]) cube([1, 1, 5.4]);

translate([40, 37, 0]) cube([1, 1, 5.4]);

translate([41, 37, 0]) cube([1, 1, 5.3]);

translate([42, 37, 0]) cube([1, 1, 5.2]);

translate([43, 37, 0]) cube([1, 1, 5.1]);

translate([44, 37, 0]) cube([1, 1, 4.9]);

translate([45, 37, 0]) cube([1, 1, 4.7]);

translate([46, 37, 0]) cube([1, 1, 4.638925447394414]);

translate([47, 37, 0]) cube([1, 1, 4.638861096758158]);

color([0,1,0])
translate([0, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 38, 0]) cube([1, 1, 6]);

translate([14, 38, 0]) cube([1, 1, 6.519999999999998]);

translate([15, 38, 0]) cube([1, 1, 6.6999999999999975]);

translate([16, 38, 0]) cube([1, 1, 6.55800059889198]);

translate([17, 38, 0]) cube([1, 1, 6.522026891933689]);

translate([18, 38, 0]) cube([1, 1, 6.287476825626826]);

translate([19, 38, 0]) cube([1, 1, 6.289285714551097]);

translate([20, 38, 0]) cube([1, 1, 6.470250954763379]);

translate([21, 38, 0]) cube([1, 1, 6.544909562850233]);

translate([22, 38, 0]) cube([1, 1, 6.619999999999997]);

color([0,1,0])
translate([23, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 38, 0]) cube([1, 1, 6]);

translate([37, 38, 0]) cube([1, 1, 5.400039592202853]);

translate([38, 38, 0]) cube([1, 1, 5.400032670940421]);

translate([39, 38, 0]) cube([1, 1, 5.40001194336199]);

translate([40, 38, 0]) cube([1, 1, 5.4]);

translate([41, 38, 0]) cube([1, 1, 5.4]);

translate([42, 38, 0]) cube([1, 1, 5.3]);

translate([43, 38, 0]) cube([1, 1, 5.1]);

translate([44, 38, 0]) cube([1, 1, 5.0]);

translate([45, 38, 0]) cube([1, 1, 4.8]);

translate([46, 38, 0]) cube([1, 1, 4.638821444491521]);

translate([47, 38, 0]) cube([1, 1, 4.638738325415742]);

color([0,1,0])
translate([0, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 39, 0]) cube([1, 1, 6]);

translate([14, 39, 0]) cube([1, 1, 6.609999999999998]);

color([0,1,0])
translate([15, 39, 0]) cube([1, 1, 6]);

translate([16, 39, 0]) cube([1, 1, 6.5069505929100995]);

translate([17, 39, 0]) cube([1, 1, 6.52739036855198]);

translate([18, 39, 0]) cube([1, 1, 6.527335746750422]);

translate([19, 39, 0]) cube([1, 1, 6.497717241019025]);

translate([20, 39, 0]) cube([1, 1, 6.52595177892621]);

translate([21, 39, 0]) cube([1, 1, 6.709999999999997]);

color([0,1,0])
translate([22, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 39, 0]) cube([1, 1, 6]);

translate([37, 39, 0]) cube([1, 1, 5.400054579612221]);

translate([38, 39, 0]) cube([1, 1, 5.400051695913485]);

translate([39, 39, 0]) cube([1, 1, 5.400039533612107]);

color([0,1,0])
translate([40, 39, 0]) cube([1, 1, 6]);

translate([41, 39, 0]) cube([1, 1, 5.4]);

translate([42, 39, 0]) cube([1, 1, 5.4]);

translate([43, 39, 0]) cube([1, 1, 5.3]);

translate([44, 39, 0]) cube([1, 1, 5.2]);

translate([45, 39, 0]) cube([1, 1, 5.0]);

translate([46, 39, 0]) cube([1, 1, 4.8]);

translate([47, 39, 0]) cube([1, 1, 4.638779895417357]);

color([0,1,0])
translate([0, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 40, 0]) cube([1, 1, 6]);

translate([13, 40, 0]) cube([1, 1, 6.579999999999998]);

translate([14, 40, 0]) cube([1, 1, 6.689999999999998]);

color([0,1,0])
translate([15, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 40, 0]) cube([1, 1, 6]);

translate([17, 40, 0]) cube([1, 1, 6.518937614349464]);

translate([18, 40, 0]) cube([1, 1, 6.519016982872573]);

translate([19, 40, 0]) cube([1, 1, 6.527906854597411]);

translate([20, 40, 0]) cube([1, 1, 6.629999999999997]);

color([0,1,0])
translate([21, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 40, 0]) cube([1, 1, 6]);

translate([45, 40, 0]) cube([1, 1, 5.3]);

translate([46, 40, 0]) cube([1, 1, 5.1]);

translate([47, 40, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 41, 0]) cube([1, 1, 6]);

translate([13, 41, 0]) cube([1, 1, 6.579999999999998]);

color([0,1,0])
translate([14, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 41, 0]) cube([1, 1, 6]);

translate([16, 41, 0]) cube([1, 1, 6.729999999999997]);

translate([17, 41, 0]) cube([1, 1, 6.709999999999997]);

translate([18, 41, 0]) cube([1, 1, 6.619999999999997]);

translate([19, 41, 0]) cube([1, 1, 6.549999999999997]);

color([0,1,0])
translate([20, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 41, 0]) cube([1, 1, 6]);

translate([47, 41, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([0, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 42, 0]) cube([1, 1, 6]);

translate([14, 42, 0]) cube([1, 1, 6.579999999999998]);

translate([15, 42, 0]) cube([1, 1, 6.609999999999998]);

translate([16, 42, 0]) cube([1, 1, 6.619999999999997]);

translate([17, 42, 0]) cube([1, 1, 6.529999999999998]);

color([0,1,0])
translate([18, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 42, 0]) cube([1, 1, 6]);

translate([40, 42, 0]) cube([1, 1, 5.4]);

translate([41, 42, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([42, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 42, 0]) cube([1, 1, 6]);

translate([47, 42, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([0, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 43, 0]) cube([1, 1, 6]);

translate([39, 43, 0]) cube([1, 1, 5.4]);

translate([40, 43, 0]) cube([1, 1, 5.300000001831218]);

translate([41, 43, 0]) cube([1, 1, 5.300000012747203]);

translate([42, 43, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([43, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 44, 0]) cube([1, 1, 6]);

translate([7, 44, 0]) cube([1, 1, 5.4]);

translate([8, 44, 0]) cube([1, 1, 5.3]);

translate([9, 44, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([10, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 44, 0]) cube([1, 1, 6]);

translate([33, 44, 0]) cube([1, 1, 5.4]);

translate([34, 44, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([35, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 44, 0]) cube([1, 1, 6]);

translate([38, 44, 0]) cube([1, 1, 5.4]);

translate([39, 44, 0]) cube([1, 1, 5.4]);

translate([40, 44, 0]) cube([1, 1, 5.300000001121378]);

translate([41, 44, 0]) cube([1, 1, 5.3000000133988605]);

translate([42, 44, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([43, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 45, 0]) cube([1, 1, 6]);

translate([1, 45, 0]) cube([1, 1, 5.4]);

translate([2, 45, 0]) cube([1, 1, 5.4]);

translate([3, 45, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([4, 45, 0]) cube([1, 1, 6]);

translate([5, 45, 0]) cube([1, 1, 5.4]);

translate([6, 45, 0]) cube([1, 1, 5.3]);

translate([7, 45, 0]) cube([1, 1, 5.2]);

translate([8, 45, 0]) cube([1, 1, 5.1]);

translate([9, 45, 0]) cube([1, 1, 5.1]);

translate([10, 45, 0]) cube([1, 1, 5.2]);

translate([11, 45, 0]) cube([1, 1, 5.3]);

translate([12, 45, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([13, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 45, 0]) cube([1, 1, 6]);

translate([16, 45, 0]) cube([1, 1, 5.4]);

translate([17, 45, 0]) cube([1, 1, 5.3]);

translate([18, 45, 0]) cube([1, 1, 5.2]);

translate([19, 45, 0]) cube([1, 1, 5.2]);

translate([20, 45, 0]) cube([1, 1, 5.3]);

translate([21, 45, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([22, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 45, 0]) cube([1, 1, 6]);

translate([32, 45, 0]) cube([1, 1, 5.4]);

translate([33, 45, 0]) cube([1, 1, 5.3]);

translate([34, 45, 0]) cube([1, 1, 5.3]);

translate([35, 45, 0]) cube([1, 1, 5.4]);

translate([36, 45, 0]) cube([1, 1, 5.4]);

translate([37, 45, 0]) cube([1, 1, 5.4]);

translate([38, 45, 0]) cube([1, 1, 5.4]);

translate([39, 45, 0]) cube([1, 1, 5.3]);

translate([40, 45, 0]) cube([1, 1, 5.300000003772086]);

translate([41, 45, 0]) cube([1, 1, 5.300000016448229]);

color([0,1,0])
translate([42, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 45, 0]) cube([1, 1, 6]);

translate([0, 46, 0]) cube([1, 1, 5.3]);

translate([1, 46, 0]) cube([1, 1, 5.3]);

translate([2, 46, 0]) cube([1, 1, 5.3]);

translate([3, 46, 0]) cube([1, 1, 5.3]);

translate([4, 46, 0]) cube([1, 1, 5.3]);

translate([5, 46, 0]) cube([1, 1, 5.3]);

translate([6, 46, 0]) cube([1, 1, 5.2]);

translate([7, 46, 0]) cube([1, 1, 5.1]);

translate([8, 46, 0]) cube([1, 1, 5.0]);

translate([9, 46, 0]) cube([1, 1, 4.965420752406175]);

translate([10, 46, 0]) cube([1, 1, 5.0]);

translate([11, 46, 0]) cube([1, 1, 5.1]);

translate([12, 46, 0]) cube([1, 1, 5.2]);

translate([13, 46, 0]) cube([1, 1, 5.2]);

translate([14, 46, 0]) cube([1, 1, 5.2]);

translate([15, 46, 0]) cube([1, 1, 5.1]);

translate([16, 46, 0]) cube([1, 1, 5.0]);

translate([17, 46, 0]) cube([1, 1, 4.9]);

translate([18, 46, 0]) cube([1, 1, 4.895588139359228]);

translate([19, 46, 0]) cube([1, 1, 4.9]);

translate([20, 46, 0]) cube([1, 1, 5.0]);

translate([21, 46, 0]) cube([1, 1, 5.2]);

translate([22, 46, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([23, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 46, 0]) cube([1, 1, 6]);

translate([32, 46, 0]) cube([1, 1, 5.4]);

translate([33, 46, 0]) cube([1, 1, 5.2]);

translate([34, 46, 0]) cube([1, 1, 5.2]);

translate([35, 46, 0]) cube([1, 1, 5.2]);

translate([36, 46, 0]) cube([1, 1, 5.2]);

translate([37, 46, 0]) cube([1, 1, 5.3]);

translate([38, 46, 0]) cube([1, 1, 5.3]);

translate([39, 46, 0]) cube([1, 1, 5.3]);

translate([40, 46, 0]) cube([1, 1, 5.3000000041613315]);

translate([41, 46, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([42, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 46, 0]) cube([1, 1, 6]);

translate([0, 47, 0]) cube([1, 1, 5.2]);

translate([1, 47, 0]) cube([1, 1, 5.120233423247784]);

translate([2, 47, 0]) cube([1, 1, 5.1202333743143225]);

translate([3, 47, 0]) cube([1, 1, 5.2]);

translate([4, 47, 0]) cube([1, 1, 5.200270746927166]);

translate([5, 47, 0]) cube([1, 1, 5.2]);

translate([6, 47, 0]) cube([1, 1, 5.1]);

translate([7, 47, 0]) cube([1, 1, 5.0]);

translate([8, 47, 0]) cube([1, 1, 4.964527553994635]);

translate([9, 47, 0]) cube([1, 1, 4.965646786714108]);

translate([10, 47, 0]) cube([1, 1, 4.965900319932927]);

translate([11, 47, 0]) cube([1, 1, 4.965699990982227]);

translate([12, 47, 0]) cube([1, 1, 5.0]);

translate([13, 47, 0]) cube([1, 1, 5.000871045363742]);

translate([14, 47, 0]) cube([1, 1, 5.0]);

translate([15, 47, 0]) cube([1, 1, 4.9]);

translate([16, 47, 0]) cube([1, 1, 4.891935242243783]);

translate([17, 47, 0]) cube([1, 1, 4.896242802960368]);

translate([18, 47, 0]) cube([1, 1, 4.896711870972926]);

translate([19, 47, 0]) cube([1, 1, 4.896713691060804]);

translate([20, 47, 0]) cube([1, 1, 4.895794472377187]);

translate([21, 47, 0]) cube([1, 1, 5.0]);

translate([22, 47, 0]) cube([1, 1, 5.2]);

translate([23, 47, 0]) cube([1, 1, 5.202260667585154]);

translate([24, 47, 0]) cube([1, 1, 5.204825782079074]);

translate([25, 47, 0]) cube([1, 1, 5.3]);

translate([26, 47, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([27, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 47, 0]) cube([1, 1, 6]);

translate([32, 47, 0]) cube([1, 1, 5.3]);

translate([33, 47, 0]) cube([1, 1, 5.100003361758656]);

translate([34, 47, 0]) cube([1, 1, 5.100003363756916]);

translate([35, 47, 0]) cube([1, 1, 5.100003375017806]);

translate([36, 47, 0]) cube([1, 1, 5.100003437223664]);

translate([37, 47, 0]) cube([1, 1, 5.2]);

translate([38, 47, 0]) cube([1, 1, 5.200000014467828]);

translate([39, 47, 0]) cube([1, 1, 5.3]);

translate([40, 47, 0]) cube([1, 1, 5.300000033693718]);

translate([41, 47, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([42, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 47, 0]) cube([1, 1, 6]);

translate([46, 47, 0]) cube([1, 1, 5.4]);

translate([47, 47, 0]) cube([1, 1, 5.3]);
