translate([0, 0, 0]) union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

translate([0, 0, 1.5]) union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

translate([0, 0, 3.0]) translate([5, 4, 0]) rotate([0, 90, 0]) union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

translate([0, 0, 8.5]) union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

translate([0, 0, 10.0]) translate([5, 4, 0]) rotate([0, 90, 0]) union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}
