
translate([0, 0, 0]) cube([1, 1, 5.000691471754814]);

translate([1, 0, 0]) cube([1, 1, 4.303044562828087]);

translate([2, 0, 0]) cube([1, 1, 4.218216976005662]);

translate([3, 0, 0]) cube([1, 1, 4.218283688394881]);

translate([4, 0, 0]) cube([1, 1, 4.080755437656865]);

translate([5, 0, 0]) cube([1, 1, 4.21671950888637]);

translate([6, 0, 0]) cube([1, 1, 4.26627933991882]);

translate([7, 0, 0]) cube([1, 1, 4.263770191659507]);

translate([8, 0, 0]) cube([1, 1, 4.263884667351457]);

translate([9, 0, 0]) cube([1, 1, 4.383139734188391]);

translate([10, 0, 0]) cube([1, 1, 4.406020230428535]);

translate([11, 0, 0]) cube([1, 1, 4.602303071427583]);

translate([12, 0, 0]) cube([1, 1, 4.639478186143973]);

translate([13, 0, 0]) cube([1, 1, 4.2826701699984735]);

translate([14, 0, 0]) cube([1, 1, 4.183954637731062]);

translate([15, 0, 0]) cube([1, 1, 4.106889066037452]);

translate([16, 0, 0]) cube([1, 1, 3.9151861763671443]);

translate([17, 0, 0]) cube([1, 1, 3.9141803781121616]);

translate([18, 0, 0]) cube([1, 1, 4.6]);

translate([19, 0, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.301382944796345]);

translate([2, 1, 0]) cube([1, 1, 4.804014716628608]);

translate([3, 1, 0]) cube([1, 1, 4.323253402590392]);

translate([4, 1, 0]) cube([1, 1, 4.319557345320597]);

translate([5, 1, 0]) cube([1, 1, 4.3452545139568155]);

translate([6, 1, 0]) cube([1, 1, 4.217451135986223]);

translate([7, 1, 0]) cube([1, 1, 4.408479739012528]);

translate([8, 1, 0]) cube([1, 1, 4.264928741685567]);

translate([9, 1, 0]) cube([1, 1, 4.318461709510631]);

translate([10, 1, 0]) cube([1, 1, 4.370027492322763]);

translate([11, 1, 0]) cube([1, 1, 4.368138034742476]);

translate([12, 1, 0]) cube([1, 1, 4.3480649174997925]);

translate([13, 1, 0]) cube([1, 1, 4.123385270639934]);

translate([14, 1, 0]) cube([1, 1, 4.063583979868952]);

translate([15, 1, 0]) cube([1, 1, 3.9552727706828312]);

translate([16, 1, 0]) cube([1, 1, 3.8558467203001654]);

translate([17, 1, 0]) cube([1, 1, 3.9143608033172423]);

translate([18, 1, 0]) cube([1, 1, 3.9143624776921038]);

translate([19, 1, 0]) cube([1, 1, 4.0]);

translate([0, 2, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.211775916548738]);

translate([4, 2, 0]) cube([1, 1, 5.11945029066824]);

translate([5, 2, 0]) cube([1, 1, 4.814567531667097]);

translate([6, 2, 0]) cube([1, 1, 4.4126130206009835]);

translate([7, 2, 0]) cube([1, 1, 4.423492622051056]);

translate([8, 2, 0]) cube([1, 1, 4.277861444133819]);

translate([9, 2, 0]) cube([1, 1, 4.355362725545867]);

translate([10, 2, 0]) cube([1, 1, 4.379374634191719]);

translate([11, 2, 0]) cube([1, 1, 4.371267269349004]);

translate([12, 2, 0]) cube([1, 1, 4.180187772606019]);

translate([13, 2, 0]) cube([1, 1, 4.048309644838663]);

translate([14, 2, 0]) cube([1, 1, 3.9765311992146612]);

translate([15, 2, 0]) cube([1, 1, 3.960336920086716]);

translate([16, 2, 0]) cube([1, 1, 3.9428599496719277]);

translate([17, 2, 0]) cube([1, 1, 3.9152365732438135]);

translate([18, 2, 0]) cube([1, 1, 3.9145066717552384]);

translate([19, 2, 0]) cube([1, 1, 3.9145029534719744]);

translate([0, 3, 0]) cube([1, 1, 7.4]);

translate([1, 3, 0]) cube([1, 1, 6.600011360733598]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.238615217475065]);

translate([6, 3, 0]) cube([1, 1, 4.780498059199125]);

translate([7, 3, 0]) cube([1, 1, 4.830850438701469]);

translate([8, 3, 0]) cube([1, 1, 5.21618650424434]);

translate([9, 3, 0]) cube([1, 1, 4.679103391984136]);

translate([10, 3, 0]) cube([1, 1, 4.427875805022771]);

translate([11, 3, 0]) cube([1, 1, 4.40799500642996]);

translate([12, 3, 0]) cube([1, 1, 4.232164286512154]);

translate([13, 3, 0]) cube([1, 1, 4.199853218615354]);

translate([14, 3, 0]) cube([1, 1, 3.955700889513425]);

translate([15, 3, 0]) cube([1, 1, 4.004399622862794]);

translate([16, 3, 0]) cube([1, 1, 3.953000943453532]);

translate([17, 3, 0]) cube([1, 1, 3.921093438388228]);

translate([18, 3, 0]) cube([1, 1, 3.914649464802004]);

translate([19, 3, 0]) cube([1, 1, 3.9145839505257576]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.2]);

translate([2, 4, 0]) cube([1, 1, 6.90004544293439]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.368550988846123]);

translate([7, 4, 0]) cube([1, 1, 5.44048011710522]);

color([0,1,0])
translate([8, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 4, 0]) cube([1, 1, 6]);

translate([10, 4, 0]) cube([1, 1, 4.707509270931643]);

translate([11, 4, 0]) cube([1, 1, 4.5076274868123605]);

translate([12, 4, 0]) cube([1, 1, 4.293885536978726]);

translate([13, 4, 0]) cube([1, 1, 4.192404123267085]);

translate([14, 4, 0]) cube([1, 1, 4.123516775412521]);

translate([15, 4, 0]) cube([1, 1, 4.026864394577115]);

translate([16, 4, 0]) cube([1, 1, 3.9837911621890196]);

translate([17, 4, 0]) cube([1, 1, 4.1]);

translate([18, 4, 0]) cube([1, 1, 4.0]);

translate([19, 4, 0]) cube([1, 1, 3.914723824702845]);

translate([0, 5, 0]) cube([1, 1, 7.9]);

translate([1, 5, 0]) cube([1, 1, 7.4]);

translate([2, 5, 0]) cube([1, 1, 7.000272657606337]);

translate([3, 5, 0]) cube([1, 1, 6.681928625956283]);

translate([4, 5, 0]) cube([1, 1, 6.5877151842781085]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 5, 0]) cube([1, 1, 6]);

translate([10, 5, 0]) cube([1, 1, 4.93856414112458]);

translate([11, 5, 0]) cube([1, 1, 4.651525647595965]);

translate([12, 5, 0]) cube([1, 1, 4.323069344946406]);

translate([13, 5, 0]) cube([1, 1, 4.124731348203243]);

translate([14, 5, 0]) cube([1, 1, 4.414178292346426]);

translate([15, 5, 0]) cube([1, 1, 4.6]);

translate([16, 5, 0]) cube([1, 1, 4.6]);

translate([17, 5, 0]) cube([1, 1, 4.7]);

translate([18, 5, 0]) cube([1, 1, 4.5]);

translate([19, 5, 0]) cube([1, 1, 4.5]);

translate([0, 6, 0]) cube([1, 1, 7.9]);

translate([1, 6, 0]) cube([1, 1, 7.201635945638022]);

translate([2, 6, 0]) cube([1, 1, 6.668719200215349]);

translate([3, 6, 0]) cube([1, 1, 6.767715014213933]);

translate([4, 6, 0]) cube([1, 1, 6.847061689236013]);

translate([5, 6, 0]) cube([1, 1, 6.646071804319462]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 6, 0]) cube([1, 1, 6]);

translate([10, 6, 0]) cube([1, 1, 5.099452156985613]);

translate([11, 6, 0]) cube([1, 1, 4.825846362702341]);

translate([12, 6, 0]) cube([1, 1, 4.8828899193871855]);

translate([13, 6, 0]) cube([1, 1, 4.670891469093563]);

translate([14, 6, 0]) cube([1, 1, 5.1]);

translate([15, 6, 0]) cube([1, 1, 5.4]);

translate([16, 6, 0]) cube([1, 1, 5.3]);

translate([17, 6, 0]) cube([1, 1, 5.1]);

translate([18, 6, 0]) cube([1, 1, 4.9]);

translate([19, 6, 0]) cube([1, 1, 5.2]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.406543782552085]);

translate([2, 7, 0]) cube([1, 1, 6.749423479773525]);

translate([3, 7, 0]) cube([1, 1, 6.805586736439388]);

translate([4, 7, 0]) cube([1, 1, 6.79298589163128]);

translate([5, 7, 0]) cube([1, 1, 6.886383245049477]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

translate([10, 7, 0]) cube([1, 1, 5.347417826055157]);

translate([11, 7, 0]) cube([1, 1, 4.892746488952052]);

translate([12, 7, 0]) cube([1, 1, 4.977794207490306]);

translate([13, 7, 0]) cube([1, 1, 4.8812150841724256]);

translate([14, 7, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 8.1]);

translate([1, 8, 0]) cube([1, 1, 7.503794642857143]);

translate([2, 8, 0]) cube([1, 1, 7.42238048735119]);

translate([3, 8, 0]) cube([1, 1, 7.014216743311743]);

translate([4, 8, 0]) cube([1, 1, 7.0088045361864255]);

translate([5, 8, 0]) cube([1, 1, 6.671543454059172]);

translate([6, 8, 0]) cube([1, 1, 6.5602190875871145]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

translate([11, 8, 0]) cube([1, 1, 5.352576764909953]);

translate([12, 8, 0]) cube([1, 1, 5.213136669546979]);

translate([13, 8, 0]) cube([1, 1, 5.105216520635349]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 8, 0]) cube([1, 1, 6]);

translate([17, 8, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([18, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 8.1]);

translate([1, 9, 0]) cube([1, 1, 7.8]);

translate([2, 9, 0]) cube([1, 1, 7.6]);

translate([3, 9, 0]) cube([1, 1, 7.4306338355654775]);

translate([4, 9, 0]) cube([1, 1, 6.664353824839057]);

translate([5, 9, 0]) cube([1, 1, 6.654104171534842]);

translate([6, 9, 0]) cube([1, 1, 6.6395059457849115]);

color([0,1,0])
translate([7, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

translate([9, 9, 0]) cube([1, 1, 6.515446127409296]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 6.9]);

translate([18, 9, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.7]);

translate([1, 10, 0]) cube([1, 1, 7.3]);

translate([2, 10, 0]) cube([1, 1, 7.206126767113096]);

translate([3, 10, 0]) cube([1, 1, 6.827785270846619]);

translate([4, 10, 0]) cube([1, 1, 6.624020577799789]);

translate([5, 10, 0]) cube([1, 1, 6.664294453956086]);

translate([6, 10, 0]) cube([1, 1, 6.824062256321905]);

translate([7, 10, 0]) cube([1, 1, 6.643332146666695]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

translate([9, 10, 0]) cube([1, 1, 6.600812074829931]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 6.6]);

translate([18, 10, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 6.9]);

translate([1, 11, 0]) cube([1, 1, 6.701531691778275]);

translate([2, 11, 0]) cube([1, 1, 6.607088745947598]);

color([0,1,0])
translate([3, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.521415785359622]);

translate([8, 11, 0]) cube([1, 1, 6.705684523809524]);

translate([9, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

translate([12, 11, 0]) cube([1, 1, 5.304895426330466]);

translate([13, 11, 0]) cube([1, 1, 5.220885690858397]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 6.8]);

translate([1, 12, 0]) cube([1, 1, 6.502873479241957]);

color([0,1,0])
translate([2, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 12, 0]) cube([1, 1, 6]);

translate([4, 12, 0]) cube([1, 1, 5.480394135563899]);

translate([5, 12, 0]) cube([1, 1, 5.483537174847437]);

color([0,1,0])
translate([6, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 12, 0]) cube([1, 1, 6]);

translate([8, 12, 0]) cube([1, 1, 6.8]);

translate([9, 12, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

translate([13, 12, 0]) cube([1, 1, 5.2209154854038475]);

translate([14, 12, 0]) cube([1, 1, 5.402023950443232]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 7.1]);

translate([1, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 13, 0]) cube([1, 1, 6]);

translate([3, 13, 0]) cube([1, 1, 5.435143107319111]);

translate([4, 13, 0]) cube([1, 1, 5.435158585444799]);

color([0,1,0])
translate([5, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

translate([8, 13, 0]) cube([1, 1, 6.6]);

translate([9, 13, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

translate([14, 13, 0]) cube([1, 1, 5.309425741188992]);

translate([15, 13, 0]) cube([1, 1, 5.309630500476116]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

translate([19, 13, 0]) cube([1, 1, 5.3]);

translate([0, 14, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

translate([2, 14, 0]) cube([1, 1, 5.435143564172231]);

translate([3, 14, 0]) cube([1, 1, 5.435144794875025]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

translate([8, 14, 0]) cube([1, 1, 6.7]);

translate([9, 14, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

translate([19, 14, 0]) cube([1, 1, 5.000115309256078]);

translate([0, 15, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 15, 0]) cube([1, 1, 6]);

translate([7, 15, 0]) cube([1, 1, 6.8]);

translate([8, 15, 0]) cube([1, 1, 7.1]);

translate([9, 15, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

translate([17, 15, 0]) cube([1, 1, 5.40035288912387]);

translate([18, 15, 0]) cube([1, 1, 5.100230620951027]);

translate([19, 15, 0]) cube([1, 1, 4.700480717610858]);

color([0,1,0])
translate([0, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 16, 0]) cube([1, 1, 6]);

translate([7, 16, 0]) cube([1, 1, 7.0]);

translate([8, 16, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([9, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

translate([16, 16, 0]) cube([1, 1, 5.4005955248365884]);

translate([17, 16, 0]) cube([1, 1, 5.400376872599706]);

translate([18, 16, 0]) cube([1, 1, 5.200192723850075]);

translate([19, 16, 0]) cube([1, 1, 4.7004812784878975]);

color([0,1,0])
translate([0, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

translate([6, 17, 0]) cube([1, 1, 6.7]);

translate([7, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

translate([16, 18, 0]) cube([1, 1, 5.400287507260692]);

translate([17, 18, 0]) cube([1, 1, 5.301724426380563]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 5.4]);

translate([1, 19, 0]) cube([1, 1, 5.3]);

translate([2, 19, 0]) cube([1, 1, 5.3]);

translate([3, 19, 0]) cube([1, 1, 5.1]);

translate([4, 19, 0]) cube([1, 1, 5.0]);

translate([5, 19, 0]) cube([1, 1, 5.3]);

translate([6, 19, 0]) cube([1, 1, 5.3]);

translate([7, 19, 0]) cube([1, 1, 5.26731278292181]);

translate([8, 19, 0]) cube([1, 1, 5.267551489013814]);

color([0,1,0])
translate([9, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

translate([14, 19, 0]) cube([1, 1, 5.2199475585070045]);

translate([15, 19, 0]) cube([1, 1, 5.30191387359838]);

translate([16, 19, 0]) cube([1, 1, 5.301744226112089]);

translate([17, 19, 0]) cube([1, 1, 5.400095835324851]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);
