
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.28963909794402]);

translate([2, 0, 0]) cube([1, 1, 4.295741378883539]);

translate([3, 0, 0]) cube([1, 1, 4.294947910050964]);

translate([4, 0, 0]) cube([1, 1, 4.4199999999999955]);

translate([5, 0, 0]) cube([1, 1, 4.539999999999999]);

translate([6, 0, 0]) cube([1, 1, 4.499999999999994]);

translate([7, 0, 0]) cube([1, 1, 3.8657533474940595]);

translate([8, 0, 0]) cube([1, 1, 3.865876229323018]);

translate([9, 0, 0]) cube([1, 1, 3.8882268818661982]);

translate([10, 0, 0]) cube([1, 1, 4.016031056048707]);

translate([11, 0, 0]) cube([1, 1, 4.026018403670928]);

translate([12, 0, 0]) cube([1, 1, 4.006033539677473]);

translate([13, 0, 0]) cube([1, 1, 4.339999999999999]);

translate([14, 0, 0]) cube([1, 1, 4.41]);

translate([15, 0, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.4399999999999995]);

translate([2, 1, 0]) cube([1, 1, 4.869999999999998]);

translate([3, 1, 0]) cube([1, 1, 4.509999999999998]);

translate([4, 1, 0]) cube([1, 1, 4.479999999999996]);

translate([5, 1, 0]) cube([1, 1, 4.469985108191114]);

translate([6, 1, 0]) cube([1, 1, 4.520698979791519]);

translate([7, 1, 0]) cube([1, 1, 4.522976822027367]);

translate([8, 1, 0]) cube([1, 1, 3.8660561557852384]);

translate([9, 1, 0]) cube([1, 1, 3.625398439285681]);

translate([10, 1, 0]) cube([1, 1, 4.639999999999995]);

translate([11, 1, 0]) cube([1, 1, 3.940995560698025]);

translate([12, 1, 0]) cube([1, 1, 4.129999999999997]);

translate([13, 1, 0]) cube([1, 1, 3.9999999999999916]);

translate([14, 1, 0]) cube([1, 1, 3.9720702116560154]);

translate([15, 1, 0]) cube([1, 1, 3.967768669251916]);

translate([0, 2, 0]) cube([1, 1, 7.2]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.489999999999998]);

translate([4, 2, 0]) cube([1, 1, 5.119999999999997]);

translate([5, 2, 0]) cube([1, 1, 4.569999999999997]);

translate([6, 2, 0]) cube([1, 1, 4.719999999999997]);

translate([7, 2, 0]) cube([1, 1, 4.879999999999998]);

translate([8, 2, 0]) cube([1, 1, 3.875721554635393]);

translate([9, 2, 0]) cube([1, 1, 4.6299999999999955]);

translate([10, 2, 0]) cube([1, 1, 4.279999999999994]);

translate([11, 2, 0]) cube([1, 1, 4.1199999999999894]);

translate([12, 2, 0]) cube([1, 1, 4.079902092096566]);

translate([13, 2, 0]) cube([1, 1, 3.990462186489452]);

translate([14, 2, 0]) cube([1, 1, 3.9754952277156916]);

translate([15, 2, 0]) cube([1, 1, 3.975064970222106]);

translate([0, 3, 0]) cube([1, 1, 7.7]);

translate([1, 3, 0]) cube([1, 1, 7.039999999999999]);

translate([2, 3, 0]) cube([1, 1, 6.589999999999998]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.219999999999997]);

color([0,1,0])
translate([6, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 3, 0]) cube([1, 1, 6]);

translate([8, 3, 0]) cube([1, 1, 4.329999999999999]);

translate([9, 3, 0]) cube([1, 1, 3.886952237078086]);

translate([10, 3, 0]) cube([1, 1, 4.1299999986988425]);

translate([11, 3, 0]) cube([1, 1, 4.100542888761114]);

translate([12, 3, 0]) cube([1, 1, 4.07999999999999]);

translate([13, 3, 0]) cube([1, 1, 3.9899999999999958]);

translate([14, 3, 0]) cube([1, 1, 3.9738347335161293]);

translate([15, 3, 0]) cube([1, 1, 3.9782254549065854]);

translate([0, 4, 0]) cube([1, 1, 7.91]);

translate([1, 4, 0]) cube([1, 1, 7.329999999999999]);

translate([2, 4, 0]) cube([1, 1, 6.879999999999998]);

translate([3, 4, 0]) cube([1, 1, 6.639999999999997]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 4, 0]) cube([1, 1, 6]);

translate([8, 4, 0]) cube([1, 1, 5.4]);

translate([9, 4, 0]) cube([1, 1, 4.749999999999999]);

translate([10, 4, 0]) cube([1, 1, 4.1999999999999975]);

translate([11, 4, 0]) cube([1, 1, 4.249999999999999]);

translate([12, 4, 0]) cube([1, 1, 4.6]);

translate([13, 4, 0]) cube([1, 1, 4.6]);

translate([14, 4, 0]) cube([1, 1, 4.6]);

translate([15, 4, 0]) cube([1, 1, 4.5]);

translate([0, 5, 0]) cube([1, 1, 8.01]);

translate([1, 5, 0]) cube([1, 1, 6.033092238486652]);

translate([2, 5, 0]) cube([1, 1, 6.729999999999997]);

translate([3, 5, 0]) cube([1, 1, 6.919999999999997]);

translate([4, 5, 0]) cube([1, 1, 6.799999999999998]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 5, 0]) cube([1, 1, 6]);

translate([9, 5, 0]) cube([1, 1, 4.91]);

translate([10, 5, 0]) cube([1, 1, 4.739999999999999]);

translate([11, 5, 0]) cube([1, 1, 5.1]);

color([0,1,0])
translate([12, 5, 0]) cube([1, 1, 6]);

translate([13, 5, 0]) cube([1, 1, 5.4]);

translate([14, 5, 0]) cube([1, 1, 5.1]);

translate([15, 5, 0]) cube([1, 1, 5.3]);

translate([0, 6, 0]) cube([1, 1, 8.2]);

translate([1, 6, 0]) cube([1, 1, 7.349999999999999]);

translate([2, 6, 0]) cube([1, 1, 6.03695879643159]);

translate([3, 6, 0]) cube([1, 1, 7.539999999999999]);

translate([4, 6, 0]) cube([1, 1, 6.999999999999998]);

translate([5, 6, 0]) cube([1, 1, 6.679999999999998]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.1]);

translate([10, 6, 0]) cube([1, 1, 4.9]);

translate([11, 6, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.72]);

translate([2, 7, 0]) cube([1, 1, 6.669999999999998]);

translate([3, 7, 0]) cube([1, 1, 5.999999999999998]);

translate([4, 7, 0]) cube([1, 1, 5.48644621132168]);

translate([5, 7, 0]) cube([1, 1, 7.029999999999999]);

translate([6, 7, 0]) cube([1, 1, 6.629999999999999]);

translate([7, 7, 0]) cube([1, 1, 6.529999999999999]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

translate([14, 7, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 7.71]);

translate([1, 8, 0]) cube([1, 1, 7.319999999999999]);

translate([2, 8, 0]) cube([1, 1, 7.0699999999999985]);

translate([3, 8, 0]) cube([1, 1, 6.619999999999997]);

translate([4, 8, 0]) cube([1, 1, 6.669999999999998]);

translate([5, 8, 0]) cube([1, 1, 6.839999999999999]);

translate([6, 8, 0]) cube([1, 1, 6.539999999999999]);

translate([7, 8, 0]) cube([1, 1, 6.529999999999999]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

translate([14, 8, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 6.81]);

translate([1, 9, 0]) cube([1, 1, 6.649999999999999]);

translate([2, 9, 0]) cube([1, 1, 6.509999999999998]);

translate([3, 9, 0]) cube([1, 1, 6.029999999999998]);

translate([4, 9, 0]) cube([1, 1, 5.909999999999996]);

translate([5, 9, 0]) cube([1, 1, 6.139999999999999]);

translate([6, 9, 0]) cube([1, 1, 6.619999999999999]);

translate([7, 9, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

translate([10, 9, 0]) cube([1, 1, 5.320033308092292]);

translate([11, 9, 0]) cube([1, 1, 5.3205452821878945]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.0]);

translate([1, 10, 0]) cube([1, 1, 6.3599999999999985]);

translate([2, 10, 0]) cube([1, 1, 4.202841171692043]);

translate([3, 10, 0]) cube([1, 1, 5.829524618221238]);

translate([4, 10, 0]) cube([1, 1, 5.829524503360842]);

translate([5, 10, 0]) cube([1, 1, 5.8699999999999966]);

translate([6, 10, 0]) cube([1, 1, 6.41]);

translate([7, 10, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

translate([11, 10, 0]) cube([1, 1, 5.329999999999999]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 7.1]);

translate([1, 11, 0]) cube([1, 1, 6.22]);

translate([2, 11, 0]) cube([1, 1, 5.8209638565889685]);

translate([3, 11, 0]) cube([1, 1, 5.831538851325123]);

translate([4, 11, 0]) cube([1, 1, 6.059999999999999]);

translate([5, 11, 0]) cube([1, 1, 6.039999999999999]);

translate([6, 11, 0]) cube([1, 1, 6.4]);

translate([7, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([8, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

translate([12, 11, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

translate([15, 11, 0]) cube([1, 1, 5.2]);

translate([0, 12, 0]) cube([1, 1, 6.6]);

translate([1, 12, 0]) cube([1, 1, 6.129999999999999]);

translate([2, 12, 0]) cube([1, 1, 5.82953827041897]);

translate([3, 12, 0]) cube([1, 1, 6.049999999999999]);

translate([4, 12, 0]) cube([1, 1, 6.139999999999999]);

translate([5, 12, 0]) cube([1, 1, 6.31]);

translate([6, 12, 0]) cube([1, 1, 7.0]);

translate([7, 12, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([8, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

translate([14, 12, 0]) cube([1, 1, 5.3]);

translate([15, 12, 0]) cube([1, 1, 4.813954747278967]);

translate([0, 13, 0]) cube([1, 1, 6.4]);

translate([1, 13, 0]) cube([1, 1, 6.21]);

translate([2, 13, 0]) cube([1, 1, 6.039999999999999]);

translate([3, 13, 0]) cube([1, 1, 6.039999999999999]);

translate([4, 13, 0]) cube([1, 1, 6.21]);

translate([5, 13, 0]) cube([1, 1, 6.7]);

translate([6, 13, 0]) cube([1, 1, 7.0]);

translate([7, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 13, 0]) cube([1, 1, 6]);

translate([10, 13, 0]) cube([1, 1, 6.51]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

translate([13, 13, 0]) cube([1, 1, 5.4]);

translate([14, 13, 0]) cube([1, 1, 5.4]);

translate([15, 13, 0]) cube([1, 1, 5.0]);

translate([0, 14, 0]) cube([1, 1, 6.1]);

translate([1, 14, 0]) cube([1, 1, 6.01]);

translate([2, 14, 0]) cube([1, 1, 5.829999999999999]);

translate([3, 14, 0]) cube([1, 1, 5.7299999999999995]);

translate([4, 14, 0]) cube([1, 1, 6.3]);

translate([5, 14, 0]) cube([1, 1, 6.5]);

translate([6, 14, 0]) cube([1, 1, 6.3]);

translate([7, 14, 0]) cube([1, 1, 5.397689667072247]);

translate([8, 14, 0]) cube([1, 1, 5.392917699652876]);

color([0,1,0])
translate([9, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 5.5]);

translate([1, 15, 0]) cube([1, 1, 5.4]);

translate([2, 15, 0]) cube([1, 1, 5.319999999999999]);

translate([3, 15, 0]) cube([1, 1, 5.273224418493765]);

translate([4, 15, 0]) cube([1, 1, 5.42]);

translate([5, 15, 0]) cube([1, 1, 5.51]);

translate([6, 15, 0]) cube([1, 1, 5.400006706724677]);

translate([7, 15, 0]) cube([1, 1, 5.499999999999998]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

translate([11, 15, 0]) cube([1, 1, 5.36104244321594]);

translate([12, 15, 0]) cube([1, 1, 5.4]);

translate([13, 15, 0]) cube([1, 1, 5.309726533250752]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);
