
translate([0, 0, 0]) cube([1, 1, 5.007307382925291]);

translate([1, 0, 0]) cube([1, 1, 4.22566125532517]);

translate([2, 0, 0]) cube([1, 1, 4.2067866649187495]);

translate([3, 0, 0]) cube([1, 1, 4.207091281537951]);

translate([4, 0, 0]) cube([1, 1, 4.412347092754439]);

translate([5, 0, 0]) cube([1, 1, 4.538174695032334]);

translate([6, 0, 0]) cube([1, 1, 4.523888407446703]);

translate([7, 0, 0]) cube([1, 1, 4.0024705077043095]);

translate([8, 0, 0]) cube([1, 1, 4.017173095346963]);

translate([9, 0, 0]) cube([1, 1, 4.168221951394009]);

translate([10, 0, 0]) cube([1, 1, 4.285658509864224]);

translate([11, 0, 0]) cube([1, 1, 4.207247017969937]);

translate([12, 0, 0]) cube([1, 1, 3.9974153782785757]);

translate([13, 0, 0]) cube([1, 1, 4.358666666666666]);

translate([14, 0, 0]) cube([1, 1, 4.41]);

translate([15, 0, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.41461476585058]);

translate([2, 1, 0]) cube([1, 1, 4.829400364148025]);

translate([3, 1, 0]) cube([1, 1, 4.439282160575471]);

translate([4, 1, 0]) cube([1, 1, 4.423889784584495]);

translate([5, 1, 0]) cube([1, 1, 4.47416333253639]);

translate([6, 1, 0]) cube([1, 1, 4.519968859830667]);

translate([7, 1, 0]) cube([1, 1, 4.5830584030989]);

translate([8, 1, 0]) cube([1, 1, 4.119376536107365]);

translate([9, 1, 0]) cube([1, 1, 3.475437772018584]);

translate([10, 1, 0]) cube([1, 1, 4.667982892432429]);

translate([11, 1, 0]) cube([1, 1, 3.9352449303067454]);

translate([12, 1, 0]) cube([1, 1, 4.165140025519839]);

translate([13, 1, 0]) cube([1, 1, 3.8766395802727285]);

translate([14, 1, 0]) cube([1, 1, 3.8765003561129214]);

translate([15, 1, 0]) cube([1, 1, 3.9025]);

translate([0, 2, 0]) cube([1, 1, 7.2]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.4593132280212435]);

translate([4, 2, 0]) cube([1, 1, 5.0616750438988465]);

translate([5, 2, 0]) cube([1, 1, 4.528559265901782]);

translate([6, 2, 0]) cube([1, 1, 4.693363217362486]);

translate([7, 2, 0]) cube([1, 1, 4.881486388675227]);

translate([8, 2, 0]) cube([1, 1, 4.2124810433401985]);

translate([9, 2, 0]) cube([1, 1, 4.700096271737493]);

translate([10, 2, 0]) cube([1, 1, 4.388133850918861]);

translate([11, 2, 0]) cube([1, 1, 4.015964121750357]);

translate([12, 2, 0]) cube([1, 1, 3.9305072855144294]);

translate([13, 2, 0]) cube([1, 1, 3.8767802255723027]);

translate([14, 2, 0]) cube([1, 1, 3.8765003554124378]);

translate([15, 2, 0]) cube([1, 1, 3.876500358912431]);

translate([0, 3, 0]) cube([1, 1, 7.7]);

translate([1, 3, 0]) cube([1, 1, 7.033192791005291]);

translate([2, 3, 0]) cube([1, 1, 6.575013847669087]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.17353186765508]);

color([0,1,0])
translate([6, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 3, 0]) cube([1, 1, 6]);

translate([8, 3, 0]) cube([1, 1, 4.5007912206282175]);

translate([9, 3, 0]) cube([1, 1, 3.3842682307918555]);

translate([10, 3, 0]) cube([1, 1, 4.102308203910288]);

translate([11, 3, 0]) cube([1, 1, 4.007734114354636]);

translate([12, 3, 0]) cube([1, 1, 3.9370756055807115]);

translate([13, 3, 0]) cube([1, 1, 3.8832277534179407]);

translate([14, 3, 0]) cube([1, 1, 3.876584515750969]);

translate([15, 3, 0]) cube([1, 1, 3.876797101144389]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.348900462962963]);

translate([2, 4, 0]) cube([1, 1, 6.97669618627323]);

translate([3, 4, 0]) cube([1, 1, 6.657811237068421]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 4, 0]) cube([1, 1, 6]);

translate([8, 4, 0]) cube([1, 1, 5.403857492974655]);

translate([9, 4, 0]) cube([1, 1, 4.742713431136409]);

translate([10, 4, 0]) cube([1, 1, 4.268053987176169]);

translate([11, 4, 0]) cube([1, 1, 4.245590182106735]);

translate([12, 4, 0]) cube([1, 1, 4.600017154156454]);

translate([13, 4, 0]) cube([1, 1, 4.60000343022374]);

translate([14, 4, 0]) cube([1, 1, 4.600000685429653]);

translate([15, 4, 0]) cube([1, 1, 4.500000227266201]);

translate([0, 5, 0]) cube([1, 1, 8.0]);

translate([1, 5, 0]) cube([1, 1, 6.24130383221548]);

translate([2, 5, 0]) cube([1, 1, 6.964785843288807]);

translate([3, 5, 0]) cube([1, 1, 6.966414764008741]);

translate([4, 5, 0]) cube([1, 1, 6.76422286021426]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 5, 0]) cube([1, 1, 6]);

translate([9, 5, 0]) cube([1, 1, 4.906475789771955]);

translate([10, 5, 0]) cube([1, 1, 4.718399614561067]);

translate([11, 5, 0]) cube([1, 1, 5.100102927750387]);

color([0,1,0])
translate([12, 5, 0]) cube([1, 1, 6]);

translate([13, 5, 0]) cube([1, 1, 5.4]);

translate([14, 5, 0]) cube([1, 1, 5.1]);

translate([15, 5, 0]) cube([1, 1, 5.3]);

translate([0, 6, 0]) cube([1, 1, 8.2]);

translate([1, 6, 0]) cube([1, 1, 7.380989583333333]);

translate([2, 6, 0]) cube([1, 1, 6.253972668384436]);

translate([3, 6, 0]) cube([1, 1, 7.5258487654321]);

translate([4, 6, 0]) cube([1, 1, 7.031063758450911]);

translate([5, 6, 0]) cube([1, 1, 6.6923654163939466]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.106882705760191]);

translate([10, 6, 0]) cube([1, 1, 4.9069999741483254]);

translate([11, 6, 0]) cube([1, 1, 5.300617569349658]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.7]);

translate([2, 7, 0]) cube([1, 1, 6.813246497158534]);

translate([3, 7, 0]) cube([1, 1, 6.210957292406348]);

translate([4, 7, 0]) cube([1, 1, 5.477464112737109]);

translate([5, 7, 0]) cube([1, 1, 7.025572546365191]);

translate([6, 7, 0]) cube([1, 1, 6.631424724256483]);

translate([7, 7, 0]) cube([1, 1, 6.5115013756589954]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

translate([14, 7, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 7.7]);

translate([1, 8, 0]) cube([1, 1, 7.320833333333333]);

translate([2, 8, 0]) cube([1, 1, 7.0540252057613175]);

translate([3, 8, 0]) cube([1, 1, 6.684236419452802]);

translate([4, 8, 0]) cube([1, 1, 6.736809531456035]);

translate([5, 8, 0]) cube([1, 1, 6.870610382779774]);

translate([6, 8, 0]) cube([1, 1, 6.536776527054518]);

translate([7, 8, 0]) cube([1, 1, 6.517858147027835]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

translate([14, 8, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 6.8069444444444445]);

translate([1, 9, 0]) cube([1, 1, 6.6204507458847734]);

color([0,1,0])
translate([2, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 9, 0]) cube([1, 1, 6]);

translate([6, 9, 0]) cube([1, 1, 6.611768397129962]);

translate([7, 9, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

translate([10, 9, 0]) cube([1, 1, 5.266903311783277]);

translate([11, 9, 0]) cube([1, 1, 5.317930295278712]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 10, 0]) cube([1, 1, 6]);

translate([2, 10, 0]) cube([1, 1, 3.860743017749112]);

color([0,1,0])
translate([3, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 10, 0]) cube([1, 1, 6]);

translate([7, 10, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

translate([11, 10, 0]) cube([1, 1, 5.323657801021708]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([1, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([8, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

translate([12, 11, 0]) cube([1, 1, 5.407611673451685]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

translate([15, 11, 0]) cube([1, 1, 5.200181953721662]);

translate([0, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 12, 0]) cube([1, 1, 6]);

translate([6, 12, 0]) cube([1, 1, 7.0]);

translate([7, 12, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([8, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

translate([14, 12, 0]) cube([1, 1, 5.300363907443324]);

translate([15, 12, 0]) cube([1, 1, 4.801297964567699]);

color([0,1,0])
translate([0, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

translate([5, 13, 0]) cube([1, 1, 6.7]);

translate([6, 13, 0]) cube([1, 1, 7.0]);

translate([7, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

translate([13, 13, 0]) cube([1, 1, 5.40084772123096]);

translate([14, 13, 0]) cube([1, 1, 5.400358183167495]);

translate([15, 13, 0]) cube([1, 1, 5.000393920235219]);

color([0,1,0])
translate([0, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

translate([7, 14, 0]) cube([1, 1, 5.217634900524942]);

translate([8, 14, 0]) cube([1, 1, 5.220702470391956]);

color([0,1,0])
translate([9, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 15, 0]) cube([1, 1, 6]);

translate([1, 15, 0]) cube([1, 1, 5.406849346781921]);

translate([2, 15, 0]) cube([1, 1, 5.314062598111933]);

translate([3, 15, 0]) cube([1, 1, 5.157945222363191]);

translate([4, 15, 0]) cube([1, 1, 5.426087273746283]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

translate([11, 15, 0]) cube([1, 1, 5.327453367875622]);

translate([12, 15, 0]) cube([1, 1, 5.401706873359449]);

translate([13, 15, 0]) cube([1, 1, 5.302787639497226]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);
