color([0.5, 0, 0]) translate([0, 0, 0]) // {'digit': 8, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 1.2]) // {'digit': 8, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 2.4]) // {'digit': 8, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 3.5999999999999996]) // {'digit': 9, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 4.8]) // {'digit': 9, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 6.0]) // {'digit': 9, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 7.2]) rotate([0, 0, 180])
  // {'digit': 6, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 8.4]) // {'digit': 9, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 9.6]) rotate([0, 0, 180])
  // {'digit': 6, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 10.799999999999999]) // {'digit': 9, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 11.999999999999998]) rotate([0, 0, 180]) // {'digit': 6, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 13.199999999999998]) rotate([0, 0, 180])
  // {'digit': 6, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0.5, 0, 0]) translate([0, 0, 14.399999999999997]) rotate([0, 0, 180])
  // {'digit': 6, 'orientation': 'rotate180Z'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([-5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([-5, 5, 0]) cube([1, 10, 1], center = true);
}

color([92 / 255, 64 / 255, 51 / 255]) translate([0, 0, 15.599999999999996]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("White") translate([0, 0, 16.799999999999997]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([210 / 255, 180 / 255, 140 / 255]) translate([0, 0, 17.999999999999996]) // {'digit': 3, 'orientation': 'flat'}
union()
{
  translate([0, -10, 0]) cube([10, 1, 1], center = true);
  translate([0, 0, 0]) cube([10, 1, 1], center = true);
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Red") translate([0, 0, 19.199999999999996]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Yellow") translate([0, 0, 20.399999999999995]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([170 / 255, 140 / 255, 100 / 255]) translate([0, 0, 21.599999999999994]) // {'digit': 7, 'orientation': 'flat'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Green") translate([0, 0, 22.799999999999994]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([62 / 255, 38 / 255, 20 / 255]) translate([0, 0, 23.999999999999993]) // {'digit': 1, 'orientation': 'flat'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Blue") translate([0, 0, 25.199999999999992]) rotate([90, 0, 0]) // {'digit': 7, 'orientation': 'rotate90X'}
union()
{
  translate([0, 10, 0]) cube([10, 1, 1], center = true);
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color("Orange") translate([0, 0, 45.39999999999999]) translate([-10, 10, 14]) rotate([90, 0, 0])
  // {'digit': 1, 'orientation': 'rotate90X'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}

color([0, 0, 0.5]) translate([0, 0, 65.6]) translate([-10, 10, 14]) rotate([90, 0, 0])
  // {'digit': 1, 'orientation': 'rotate90X'}
union()
{
  translate([5, -5, 0]) cube([1, 10, 1], center = true);
  translate([5, 5, 0]) cube([1, 10, 1], center = true);
}
