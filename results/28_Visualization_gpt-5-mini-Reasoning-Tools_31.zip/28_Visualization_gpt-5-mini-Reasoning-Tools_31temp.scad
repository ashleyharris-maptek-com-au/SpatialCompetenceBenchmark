
translate([0, 0, 0]) cube([1, 1, 5.000026813614184]);

translate([1, 0, 0]) cube([1, 1, 4.400112319657473]);

translate([2, 0, 0]) cube([1, 1, 4.200327237707837]);

translate([3, 0, 0]) cube([1, 1, 4.100758091646656]);

translate([4, 0, 0]) cube([1, 1, 4.001213855803123]);

translate([5, 0, 0]) cube([1, 1, 3.965324974507055]);

translate([6, 0, 0]) cube([1, 1, 3.966224461509333]);

translate([7, 0, 0]) cube([1, 1, 4.045387699537864]);

translate([8, 0, 0]) cube([1, 1, 4.250321799751881]);

translate([9, 0, 0]) cube([1, 1, 3.8482684247468604]);

translate([10, 0, 0]) cube([1, 1, 3.9832423650108604]);

translate([11, 0, 0]) cube([1, 1, 4.072138792346033]);

translate([12, 0, 0]) cube([1, 1, 4.216666666666667]);

translate([13, 0, 0]) cube([1, 1, 4.204166666666667]);

translate([14, 0, 0]) cube([1, 1, 4.4]);

translate([15, 0, 0]) cube([1, 1, 4.8]);

translate([16, 0, 0]) cube([1, 1, 5.0]);

translate([17, 0, 0]) cube([1, 1, 5.2]);

translate([18, 0, 0]) cube([1, 1, 5.3]);

translate([19, 0, 0]) cube([1, 1, 5.4]);

translate([20, 0, 0]) cube([1, 1, 5.4]);

translate([21, 0, 0]) cube([1, 1, 5.2]);

translate([22, 0, 0]) cube([1, 1, 4.9]);

translate([23, 0, 0]) cube([1, 1, 4.6]);

translate([24, 0, 0]) cube([1, 1, 4.4]);

translate([25, 0, 0]) cube([1, 1, 4.3]);

translate([26, 0, 0]) cube([1, 1, 4.3]);

translate([27, 0, 0]) cube([1, 1, 3.6920476190476186]);

translate([28, 0, 0]) cube([1, 1, 4.4]);

translate([29, 0, 0]) cube([1, 1, 4.6]);

translate([30, 0, 0]) cube([1, 1, 4.7]);

translate([31, 0, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.100043474055543]);

translate([2, 1, 0]) cube([1, 1, 4.700144200328077]);

translate([3, 1, 0]) cube([1, 1, 4.500354485768608]);

translate([4, 1, 0]) cube([1, 1, 4.2006902661094445]);

translate([5, 1, 0]) cube([1, 1, 4.001266930632862]);

translate([6, 1, 0]) cube([1, 1, 3.966226075841954]);

translate([7, 1, 0]) cube([1, 1, 4.047675730048321]);

translate([8, 1, 0]) cube([1, 1, 4.1810157070122145]);

translate([9, 1, 0]) cube([1, 1, 4.264651474010881]);

translate([10, 1, 0]) cube([1, 1, 4.266395393686196]);

translate([11, 1, 0]) cube([1, 1, 4.084552363034611]);

translate([12, 1, 0]) cube([1, 1, 4.069702661751638]);

translate([13, 1, 0]) cube([1, 1, 4.067981968923958]);

translate([14, 1, 0]) cube([1, 1, 4.076626662573143]);

translate([15, 1, 0]) cube([1, 1, 4.312496954189379]);

translate([16, 1, 0]) cube([1, 1, 4.5]);

translate([17, 1, 0]) cube([1, 1, 4.6]);

translate([18, 1, 0]) cube([1, 1, 4.8]);

translate([19, 1, 0]) cube([1, 1, 4.9]);

translate([20, 1, 0]) cube([1, 1, 4.8]);

translate([21, 1, 0]) cube([1, 1, 4.7]);

translate([22, 1, 0]) cube([1, 1, 4.5]);

translate([23, 1, 0]) cube([1, 1, 4.4]);

translate([24, 1, 0]) cube([1, 1, 4.2]);

translate([25, 1, 0]) cube([1, 1, 4.007142857142857]);

translate([26, 1, 0]) cube([1, 1, 3.845753968253968]);

translate([27, 1, 0]) cube([1, 1, 3.7534365079365077]);

translate([28, 1, 0]) cube([1, 1, 3.9428571428571426]);

translate([29, 1, 0]) cube([1, 1, 4.007142857142857]);

translate([30, 1, 0]) cube([1, 1, 4.2]);

translate([31, 1, 0]) cube([1, 1, 4.3]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

translate([2, 2, 0]) cube([1, 1, 5.400166588707016]);

translate([3, 2, 0]) cube([1, 1, 5.100470312750956]);

translate([4, 2, 0]) cube([1, 1, 4.800991330303673]);

translate([5, 2, 0]) cube([1, 1, 4.501635210300728]);

translate([6, 2, 0]) cube([1, 1, 4.402375796690722]);

translate([7, 2, 0]) cube([1, 1, 4.401932744934176]);

translate([8, 2, 0]) cube([1, 1, 4.3122067426839195]);

translate([9, 2, 0]) cube([1, 1, 4.236565293542193]);

translate([10, 2, 0]) cube([1, 1, 4.091793273216755]);

translate([11, 2, 0]) cube([1, 1, 4.080810299878144]);

translate([12, 2, 0]) cube([1, 1, 4.072306948460534]);

translate([13, 2, 0]) cube([1, 1, 4.067658634820947]);

translate([14, 2, 0]) cube([1, 1, 4.067666156101867]);

translate([15, 2, 0]) cube([1, 1, 4.1683208128647085]);

translate([16, 2, 0]) cube([1, 1, 4.313120016311218]);

translate([17, 2, 0]) cube([1, 1, 4.367282078574845]);

translate([18, 2, 0]) cube([1, 1, 4.405632647615771]);

translate([19, 2, 0]) cube([1, 1, 4.5]);

translate([20, 2, 0]) cube([1, 1, 4.4]);

translate([21, 2, 0]) cube([1, 1, 4.3]);

translate([22, 2, 0]) cube([1, 1, 4.2]);

translate([23, 2, 0]) cube([1, 1, 4.000297619047619]);

translate([24, 2, 0]) cube([1, 1, 4.001190476190477]);

translate([25, 2, 0]) cube([1, 1, 3.90734126984127]);

translate([26, 2, 0]) cube([1, 1, 3.6227433414279795]);

translate([27, 2, 0]) cube([1, 1, 3.44845641648548]);

translate([28, 2, 0]) cube([1, 1, 3.528988742835097]);

translate([29, 2, 0]) cube([1, 1, 3.8102380952380948]);

translate([30, 2, 0]) cube([1, 1, 3.901190476190476]);

translate([31, 2, 0]) cube([1, 1, 3.800396825396825]);

translate([0, 3, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

translate([4, 3, 0]) cube([1, 1, 5.401426318952128]);

translate([5, 3, 0]) cube([1, 1, 5.102470864976254]);

translate([6, 3, 0]) cube([1, 1, 5.003287544605375]);

translate([7, 3, 0]) cube([1, 1, 4.903292602593424]);

translate([8, 3, 0]) cube([1, 1, 4.701900549207829]);

translate([9, 3, 0]) cube([1, 1, 4.406766437033252]);

translate([10, 3, 0]) cube([1, 1, 4.121525573477189]);

translate([11, 3, 0]) cube([1, 1, 4.084682389045991]);

translate([12, 3, 0]) cube([1, 1, 4.204084178120625]);

translate([13, 3, 0]) cube([1, 1, 4.301046374589018]);

translate([14, 3, 0]) cube([1, 1, 3.8654870257599523]);

translate([15, 3, 0]) cube([1, 1, 4.348597763973253]);

translate([16, 3, 0]) cube([1, 1, 4.386925666049834]);

translate([17, 3, 0]) cube([1, 1, 4.415783463934954]);

translate([18, 3, 0]) cube([1, 1, 4.4065464568416335]);

translate([19, 3, 0]) cube([1, 1, 4.305199683599324]);

translate([20, 3, 0]) cube([1, 1, 4.201039934711033]);

translate([21, 3, 0]) cube([1, 1, 4.100207983364415]);

translate([22, 3, 0]) cube([1, 1, 3.8005422241583604]);

translate([23, 3, 0]) cube([1, 1, 3.6024304348854765]);

translate([24, 3, 0]) cube([1, 1, 3.6030322659330722]);

translate([25, 3, 0]) cube([1, 1, 3.605404630628213]);

translate([26, 3, 0]) cube([1, 1, 3.4212977533728384]);

translate([27, 3, 0]) cube([1, 1, 3.350468567338712]);

translate([28, 3, 0]) cube([1, 1, 3.4227524560660276]);

translate([29, 3, 0]) cube([1, 1, 3.602280368165785]);

translate([30, 3, 0]) cube([1, 1, 3.7019708994708997]);

translate([31, 3, 0]) cube([1, 1, 3.60143121468164]);

translate([0, 4, 0]) cube([1, 1, 7.2]);

translate([1, 4, 0]) cube([1, 1, 6.600000626437158]);

color([0,1,0])
translate([2, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.405064772861539]);

translate([7, 4, 0]) cube([1, 1, 5.305001931702407]);

translate([8, 4, 0]) cube([1, 1, 5.003108766517913]);

translate([9, 4, 0]) cube([1, 1, 4.614035128469572]);

translate([10, 4, 0]) cube([1, 1, 4.414799835154883]);

translate([11, 4, 0]) cube([1, 1, 4.41393560109076]);

translate([12, 4, 0]) cube([1, 1, 4.604055667978525]);

translate([13, 4, 0]) cube([1, 1, 4.8013832540394885]);

translate([14, 4, 0]) cube([1, 1, 4.800839329940754]);

translate([15, 4, 0]) cube([1, 1, 3.7701586174241872]);

translate([16, 4, 0]) cube([1, 1, 4.721795606212238]);

translate([17, 4, 0]) cube([1, 1, 4.711315768389707]);

translate([18, 4, 0]) cube([1, 1, 4.408619634089801]);

translate([19, 4, 0]) cube([1, 1, 4.107837431353925]);

translate([20, 4, 0]) cube([1, 1, 4.008731975448385]);

translate([21, 4, 0]) cube([1, 1, 3.9016633138998547]);

translate([22, 4, 0]) cube([1, 1, 3.60435087446803]);

translate([23, 4, 0]) cube([1, 1, 3.431634992282837]);

translate([24, 4, 0]) cube([1, 1, 3.4316367249263475]);

translate([25, 4, 0]) cube([1, 1, 3.501222282769137]);

translate([26, 4, 0]) cube([1, 1, 3.407164898331841]);

translate([27, 4, 0]) cube([1, 1, 3.342208947056484]);

translate([28, 4, 0]) cube([1, 1, 3.343244884003394]);

translate([29, 4, 0]) cube([1, 1, 3.5010462044385653]);

translate([30, 4, 0]) cube([1, 1, 3.600777383539395]);

translate([31, 4, 0]) cube([1, 1, 3.50475451021458]);

translate([0, 5, 0]) cube([1, 1, 7.4]);

translate([1, 5, 0]) cube([1, 1, 6.900000591018516]);

translate([2, 5, 0]) cube([1, 1, 6.600002170888826]);

color([0,1,0])
translate([3, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

translate([8, 5, 0]) cube([1, 1, 5.307159292620594]);

translate([9, 5, 0]) cube([1, 1, 4.919711264725953]);

translate([10, 5, 0]) cube([1, 1, 4.72426064542296]);

translate([11, 5, 0]) cube([1, 1, 4.911484920324372]);

translate([12, 5, 0]) cube([1, 1, 5.105636468347186]);

translate([13, 5, 0]) cube([1, 1, 5.301773701298131]);

translate([14, 5, 0]) cube([1, 1, 5.300872584681998]);

translate([15, 5, 0]) cube([1, 1, 5.100183890444646]);

translate([16, 5, 0]) cube([1, 1, 5.100036746047308]);

translate([17, 5, 0]) cube([1, 1, 4.901502077342314]);

translate([18, 5, 0]) cube([1, 1, 4.509944020475187]);

translate([19, 5, 0]) cube([1, 1, 4.020642877929393]);

translate([20, 5, 0]) cube([1, 1, 3.8181937824693515]);

translate([21, 5, 0]) cube([1, 1, 3.719340862152344]);

translate([22, 5, 0]) cube([1, 1, 3.5380302587990933]);

translate([23, 5, 0]) cube([1, 1, 3.431725729295017]);

translate([24, 5, 0]) cube([1, 1, 3.4317208893331217]);

translate([25, 5, 0]) cube([1, 1, 3.500428922746939]);

translate([26, 5, 0]) cube([1, 1, 3.5003750573898365]);

translate([27, 5, 0]) cube([1, 1, 3.4018849864006757]);

translate([28, 5, 0]) cube([1, 1, 3.401202165333386]);

translate([29, 5, 0]) cube([1, 1, 3.5006753196649028]);

translate([30, 5, 0]) cube([1, 1, 3.600202371016749]);

translate([31, 5, 0]) cube([1, 1, 3.6003726415058965]);

translate([0, 6, 0]) cube([1, 1, 7.7]);

translate([1, 6, 0]) cube([1, 1, 7.2]);

translate([2, 6, 0]) cube([1, 1, 7.000002364826459]);

translate([3, 6, 0]) cube([1, 1, 6.800007644914777]);

translate([4, 6, 0]) cube([1, 1, 6.503321251757259]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.222107550949076]);

translate([10, 6, 0]) cube([1, 1, 5.127954297570885]);

translate([11, 6, 0]) cube([1, 1, 5.315784553342806]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([16, 6, 0]) cube([1, 1, 5.300024603407671]);

translate([17, 6, 0]) cube([1, 1, 5.00895112117554]);

translate([18, 6, 0]) cube([1, 1, 4.531224950975077]);

translate([19, 6, 0]) cube([1, 1, 4.033899535587683]);

translate([20, 6, 0]) cube([1, 1, 3.768115243406584]);

translate([21, 6, 0]) cube([1, 1, 3.588042405817782]);

translate([22, 6, 0]) cube([1, 1, 3.551255327061075]);

translate([23, 6, 0]) cube([1, 1, 3.534619228600517]);

translate([24, 6, 0]) cube([1, 1, 3.6005615981378645]);

translate([25, 6, 0]) cube([1, 1, 3.7001644315195428]);

translate([26, 6, 0]) cube([1, 1, 3.800000000957412]);

translate([27, 6, 0]) cube([1, 1, 3.9]);

translate([28, 6, 0]) cube([1, 1, 3.8]);

translate([29, 6, 0]) cube([1, 1, 3.8]);

translate([30, 6, 0]) cube([1, 1, 3.8]);

translate([31, 6, 0]) cube([1, 1, 3.7]);

translate([0, 7, 0]) cube([1, 1, 8.0]);

translate([1, 7, 0]) cube([1, 1, 7.5]);

translate([2, 7, 0]) cube([1, 1, 7.3]);

translate([3, 7, 0]) cube([1, 1, 7.000011824547499]);

translate([4, 7, 0]) cube([1, 1, 6.800027133408526]);

translate([5, 7, 0]) cube([1, 1, 6.5165596597438435]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([16, 7, 0]) cube([1, 1, 5.400073956133711]);

translate([17, 7, 0]) cube([1, 1, 4.979964846226237]);

translate([18, 7, 0]) cube([1, 1, 4.662432905085371]);

translate([19, 7, 0]) cube([1, 1, 4.2569417568969214]);

translate([20, 7, 0]) cube([1, 1, 3.875192432019131]);

translate([21, 7, 0]) cube([1, 1, 3.7719179542553483]);

translate([22, 7, 0]) cube([1, 1, 3.8113669472129565]);

translate([23, 7, 0]) cube([1, 1, 4.001821401233493]);

translate([24, 7, 0]) cube([1, 1, 4.000822158959923]);

translate([25, 7, 0]) cube([1, 1, 4.100000006114128]);

translate([26, 7, 0]) cube([1, 1, 4.300000000673057]);

translate([27, 7, 0]) cube([1, 1, 4.4]);

translate([28, 7, 0]) cube([1, 1, 4.3]);

translate([29, 7, 0]) cube([1, 1, 4.2]);

translate([30, 7, 0]) cube([1, 1, 4.1]);

translate([31, 7, 0]) cube([1, 1, 4.0]);

translate([0, 8, 0]) cube([1, 1, 7.9]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 7.3]);

translate([3, 8, 0]) cube([1, 1, 7.000070947284988]);

translate([4, 8, 0]) cube([1, 1, 6.800089142834881]);

translate([5, 8, 0]) cube([1, 1, 6.633262795906926]);

translate([6, 8, 0]) cube([1, 1, 6.549814981256697]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([16, 8, 0]) cube([1, 1, 4.817466591915502]);

translate([17, 8, 0]) cube([1, 1, 5.122917416623022]);

translate([18, 8, 0]) cube([1, 1, 4.800331146830533]);

translate([19, 8, 0]) cube([1, 1, 4.490719788515404]);

translate([20, 8, 0]) cube([1, 1, 4.175123701793269]);

translate([21, 8, 0]) cube([1, 1, 4.044084951522628]);

translate([22, 8, 0]) cube([1, 1, 4.209461184154276]);

translate([23, 8, 0]) cube([1, 1, 4.5014672053937606]);

translate([24, 8, 0]) cube([1, 1, 4.600000025189319]);

translate([25, 8, 0]) cube([1, 1, 4.600000004844024]);

translate([26, 8, 0]) cube([1, 1, 4.600000000732076]);

translate([27, 8, 0]) cube([1, 1, 4.7]);

translate([28, 8, 0]) cube([1, 1, 4.6]);

translate([29, 8, 0]) cube([1, 1, 4.5]);

translate([30, 8, 0]) cube([1, 1, 4.5]);

translate([31, 8, 0]) cube([1, 1, 4.4]);

translate([0, 9, 0]) cube([1, 1, 7.9]);

translate([1, 9, 0]) cube([1, 1, 7.4]);

translate([2, 9, 0]) cube([1, 1, 7.100425684931152]);

translate([3, 9, 0]) cube([1, 1, 6.900439874474312]);

translate([4, 9, 0]) cube([1, 1, 6.669009240717171]);

translate([5, 9, 0]) cube([1, 1, 6.647298667757633]);

translate([6, 9, 0]) cube([1, 1, 6.652980936770876]);

translate([7, 9, 0]) cube([1, 1, 6.716910987318505]);

translate([8, 9, 0]) cube([1, 1, 6.511801280031456]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

translate([16, 9, 0]) cube([1, 1, 4.817889402355645]);

translate([17, 9, 0]) cube([1, 1, 4.823856750632484]);

translate([18, 9, 0]) cube([1, 1, 4.985784553856536]);

translate([19, 9, 0]) cube([1, 1, 4.768414200403443]);

translate([20, 9, 0]) cube([1, 1, 4.545916355867609]);

translate([21, 9, 0]) cube([1, 1, 4.438502711347177]);

translate([22, 9, 0]) cube([1, 1, 4.707335855510609]);

translate([23, 9, 0]) cube([1, 1, 5.000000153353471]);

translate([24, 9, 0]) cube([1, 1, 5.1]);

translate([25, 9, 0]) cube([1, 1, 5.1]);

translate([26, 9, 0]) cube([1, 1, 5.0]);

translate([27, 9, 0]) cube([1, 1, 4.9]);

translate([28, 9, 0]) cube([1, 1, 4.8]);

translate([29, 9, 0]) cube([1, 1, 4.8]);

translate([30, 9, 0]) cube([1, 1, 4.9]);

translate([31, 9, 0]) cube([1, 1, 4.9]);

translate([0, 10, 0]) cube([1, 1, 8.0]);

translate([1, 10, 0]) cube([1, 1, 7.5]);

translate([2, 10, 0]) cube([1, 1, 7.101702740155414]);

translate([3, 10, 0]) cube([1, 1, 6.756521349312351]);

translate([4, 10, 0]) cube([1, 1, 6.707753163305126]);

translate([5, 10, 0]) cube([1, 1, 6.702898207974789]);

translate([6, 10, 0]) cube([1, 1, 6.860326576842985]);

translate([7, 10, 0]) cube([1, 1, 6.924179528445531]);

translate([8, 10, 0]) cube([1, 1, 6.729717164621836]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 4.824306002897154]);

translate([18, 10, 0]) cube([1, 1, 4.998336959870003]);

translate([19, 10, 0]) cube([1, 1, 4.860409719604418]);

translate([20, 10, 0]) cube([1, 1, 4.764079507217608]);

translate([21, 10, 0]) cube([1, 1, 4.7366783575097235]);

translate([22, 10, 0]) cube([1, 1, 5.100000771260438]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 10, 0]) cube([1, 1, 6]);

translate([26, 10, 0]) cube([1, 1, 5.4]);

translate([27, 10, 0]) cube([1, 1, 5.2]);

translate([28, 10, 0]) cube([1, 1, 5.1]);

translate([29, 10, 0]) cube([1, 1, 5.1]);

translate([30, 10, 0]) cube([1, 1, 5.3]);

translate([31, 10, 0]) cube([1, 1, 5.4]);

translate([0, 11, 0]) cube([1, 1, 8.2]);

translate([1, 11, 0]) cube([1, 1, 7.7]);

translate([2, 11, 0]) cube([1, 1, 7.208513700777072]);

translate([3, 11, 0]) cube([1, 1, 6.956221370605578]);

translate([4, 11, 0]) cube([1, 1, 6.986572577185083]);

translate([5, 11, 0]) cube([1, 1, 7.10819665687756]);

translate([6, 11, 0]) cube([1, 1, 7.298047771385045]);

translate([7, 11, 0]) cube([1, 1, 7.171208928472316]);

translate([8, 11, 0]) cube([1, 1, 6.779343636388925]);

translate([9, 11, 0]) cube([1, 1, 6.598938738875525]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

translate([17, 11, 0]) cube([1, 1, 5.170662603513713]);

translate([18, 11, 0]) cube([1, 1, 5.064071952942458]);

translate([19, 11, 0]) cube([1, 1, 4.9521932639967945]);

translate([20, 11, 0]) cube([1, 1, 4.850317075297919]);

translate([21, 11, 0]) cube([1, 1, 4.8323114461765115]);

translate([22, 11, 0]) cube([1, 1, 5.200004632880487]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 8.2]);

translate([1, 12, 0]) cube([1, 1, 7.7]);

translate([2, 12, 0]) cube([1, 1, 7.303654026378261]);

translate([3, 12, 0]) cube([1, 1, 7.230400777984753]);

translate([4, 12, 0]) cube([1, 1, 7.361549503674746]);

translate([5, 12, 0]) cube([1, 1, 6.181467336360018]);

translate([6, 12, 0]) cube([1, 1, 6.912919148494724]);

translate([7, 12, 0]) cube([1, 1, 6.535003378548125]);

translate([8, 12, 0]) cube([1, 1, 7.01146350071226]);

translate([9, 12, 0]) cube([1, 1, 6.711152813928755]);

translate([10, 12, 0]) cube([1, 1, 6.664077840374006]);

translate([11, 12, 0]) cube([1, 1, 6.650440289792734]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

translate([17, 12, 0]) cube([1, 1, 5.349967251222757]);

translate([18, 12, 0]) cube([1, 1, 5.153420302762073]);

translate([19, 12, 0]) cube([1, 1, 5.043738499784839]);

translate([20, 12, 0]) cube([1, 1, 4.943083138324821]);

translate([21, 12, 0]) cube([1, 1, 5.003505553283551]);

translate([22, 12, 0]) cube([1, 1, 5.300023171734528]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 8.1]);

translate([1, 13, 0]) cube([1, 1, 7.7]);

translate([2, 13, 0]) cube([1, 1, 7.5039951832414475]);

translate([3, 13, 0]) cube([1, 1, 7.510620923237033]);

translate([4, 13, 0]) cube([1, 1, 7.606069189693238]);

translate([5, 13, 0]) cube([1, 1, 7.607916095107453]);

translate([6, 13, 0]) cube([1, 1, 6.995721320352578]);

translate([7, 13, 0]) cube([1, 1, 6.533151898032961]);

translate([8, 13, 0]) cube([1, 1, 7.106297663242734]);

translate([9, 13, 0]) cube([1, 1, 6.897097490828416]);

translate([10, 13, 0]) cube([1, 1, 6.83925623677633]);

translate([11, 13, 0]) cube([1, 1, 6.8556329780076695]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

translate([18, 13, 0]) cube([1, 1, 5.434515496196012]);

translate([19, 13, 0]) cube([1, 1, 5.317332167740835]);

translate([20, 13, 0]) cube([1, 1, 5.208251004380611]);

translate([21, 13, 0]) cube([1, 1, 5.2056275374677785]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 13, 0]) cube([1, 1, 6]);

translate([27, 13, 0]) cube([1, 1, 6.6]);

translate([28, 13, 0]) cube([1, 1, 6.7]);

translate([29, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([30, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 8.2]);

translate([1, 14, 0]) cube([1, 1, 7.8]);

translate([2, 14, 0]) cube([1, 1, 7.7]);

translate([3, 14, 0]) cube([1, 1, 7.601761452089886]);

translate([4, 14, 0]) cube([1, 1, 7.604060822474607]);

translate([5, 14, 0]) cube([1, 1, 7.527747267813271]);

translate([6, 14, 0]) cube([1, 1, 6.933934465344114]);

translate([7, 14, 0]) cube([1, 1, 6.944769291383968]);

translate([8, 14, 0]) cube([1, 1, 6.53390521484792]);

translate([9, 14, 0]) cube([1, 1, 7.055031054827247]);

translate([10, 14, 0]) cube([1, 1, 7.020069651828308]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

translate([13, 14, 0]) cube([1, 1, 6.5510504402866845]);

translate([14, 14, 0]) cube([1, 1, 6.555364930582731]);

translate([15, 14, 0]) cube([1, 1, 6.538644540395424]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 14, 0]) cube([1, 1, 6]);

translate([27, 14, 0]) cube([1, 1, 6.9]);

translate([28, 14, 0]) cube([1, 1, 7.0]);

translate([29, 14, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([30, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 8.1]);

translate([1, 15, 0]) cube([1, 1, 7.8]);

translate([2, 15, 0]) cube([1, 1, 7.7]);

translate([3, 15, 0]) cube([1, 1, 7.501164454746717]);

translate([4, 15, 0]) cube([1, 1, 7.306946799424895]);

translate([5, 15, 0]) cube([1, 1, 7.138531835808177]);

translate([6, 15, 0]) cube([1, 1, 6.99573918222515]);

translate([7, 15, 0]) cube([1, 1, 6.939773412961301]);

translate([8, 15, 0]) cube([1, 1, 6.9770131282122945]);

translate([9, 15, 0]) cube([1, 1, 6.955181245557752]);

translate([10, 15, 0]) cube([1, 1, 6.9278864980101025]);

translate([11, 15, 0]) cube([1, 1, 6.766838027644031]);

translate([12, 15, 0]) cube([1, 1, 6.616772202898433]);

translate([13, 15, 0]) cube([1, 1, 6.564064222154305]);

translate([14, 15, 0]) cube([1, 1, 6.5645800898949815]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 15, 0]) cube([1, 1, 6]);

translate([27, 15, 0]) cube([1, 1, 6.8]);

translate([28, 15, 0]) cube([1, 1, 6.9]);

translate([29, 15, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([30, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 15, 0]) cube([1, 1, 6]);

translate([0, 16, 0]) cube([1, 1, 7.7]);

translate([1, 16, 0]) cube([1, 1, 7.4]);

translate([2, 16, 0]) cube([1, 1, 7.300232890949342]);

translate([3, 16, 0]) cube([1, 1, 7.201668828863496]);

translate([4, 16, 0]) cube([1, 1, 7.009662383768658]);

translate([5, 16, 0]) cube([1, 1, 6.73017603998127]);

translate([6, 16, 0]) cube([1, 1, 6.581150820530824]);

translate([7, 16, 0]) cube([1, 1, 6.5884065035243795]);

translate([8, 16, 0]) cube([1, 1, 6.661483104930422]);

translate([9, 16, 0]) cube([1, 1, 6.735447739259174]);

translate([10, 16, 0]) cube([1, 1, 6.817157825800699]);

translate([11, 16, 0]) cube([1, 1, 6.634317966146742]);

translate([12, 16, 0]) cube([1, 1, 6.583770872630307]);

translate([13, 16, 0]) cube([1, 1, 6.574293026231317]);

translate([14, 16, 0]) cube([1, 1, 6.570920252549098]);

translate([15, 16, 0]) cube([1, 1, 6.606715440643593]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 16, 0]) cube([1, 1, 6]);

translate([28, 16, 0]) cube([1, 1, 6.7]);

translate([29, 16, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([30, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 16, 0]) cube([1, 1, 6]);

translate([0, 17, 0]) cube([1, 1, 7.1]);

translate([1, 17, 0]) cube([1, 1, 6.900249676188158]);

translate([2, 17, 0]) cube([1, 1, 6.900765814044189]);

translate([3, 17, 0]) cube([1, 1, 6.901927350408105]);

translate([4, 17, 0]) cube([1, 1, 6.708686920604304]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

translate([10, 17, 0]) cube([1, 1, 6.519229116938177]);

translate([11, 17, 0]) cube([1, 1, 6.609222056809634]);

translate([12, 17, 0]) cube([1, 1, 6.579524320614094]);

translate([13, 17, 0]) cube([1, 1, 6.605840981056512]);

translate([14, 17, 0]) cube([1, 1, 6.606280919152906]);

translate([15, 17, 0]) cube([1, 1, 6.604970776116518]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

translate([19, 17, 0]) cube([1, 1, 5.433160414969032]);

translate([20, 17, 0]) cube([1, 1, 5.42009732437221]);

translate([21, 17, 0]) cube([1, 1, 5.407785519879407]);

color([0,1,0])
translate([22, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 17, 0]) cube([1, 1, 6]);

translate([0, 18, 0]) cube([1, 1, 6.800062418839553]);

translate([1, 18, 0]) cube([1, 1, 6.6004451248634615]);

translate([2, 18, 0]) cube([1, 1, 6.600540195628944]);

translate([3, 18, 0]) cube([1, 1, 6.502384056137108]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

translate([12, 18, 0]) cube([1, 1, 6.602642438754049]);

translate([13, 18, 0]) cube([1, 1, 6.8]);

translate([14, 18, 0]) cube([1, 1, 6.9]);

translate([15, 18, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

translate([19, 18, 0]) cube([1, 1, 5.426026873667585]);

translate([20, 18, 0]) cube([1, 1, 5.2492588452605276]);

translate([21, 18, 0]) cube([1, 1, 5.249259100157448]);

translate([22, 18, 0]) cube([1, 1, 5.301946378010333]);

color([0,1,0])
translate([23, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 6.800015604709888]);

translate([1, 19, 0]) cube([1, 1, 6.600355488286856]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

translate([7, 19, 0]) cube([1, 1, 5.446390419090804]);

translate([8, 19, 0]) cube([1, 1, 5.44890042725502]);

color([0,1,0])
translate([9, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

translate([13, 19, 0]) cube([1, 1, 6.9]);

translate([14, 19, 0]) cube([1, 1, 7.1]);

translate([15, 19, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([16, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);

translate([20, 19, 0]) cube([1, 1, 5.405760526007343]);

translate([21, 19, 0]) cube([1, 1, 5.249259532752825]);

translate([22, 19, 0]) cube([1, 1, 5.301862202341524]);

color([0,1,0])
translate([23, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 19, 0]) cube([1, 1, 6]);

translate([0, 20, 0]) cube([1, 1, 7.0]);

translate([1, 20, 0]) cube([1, 1, 6.800003120818723]);

color([0,1,0])
translate([2, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

translate([6, 20, 0]) cube([1, 1, 5.41856587276766]);

translate([7, 20, 0]) cube([1, 1, 5.354139842657139]);

translate([8, 20, 0]) cube([1, 1, 5.444177107584536]);

color([0,1,0])
translate([9, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

translate([13, 20, 0]) cube([1, 1, 6.8]);

translate([14, 20, 0]) cube([1, 1, 7.0]);

translate([15, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

translate([21, 20, 0]) cube([1, 1, 5.302759767653622]);

translate([22, 20, 0]) cube([1, 1, 5.302544330914352]);

translate([23, 20, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([24, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 20, 0]) cube([1, 1, 6]);

translate([31, 20, 0]) cube([1, 1, 5.3]);

translate([0, 21, 0]) cube([1, 1, 7.1]);

translate([1, 21, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

translate([4, 21, 0]) cube([1, 1, 5.403864763080057]);

translate([5, 21, 0]) cube([1, 1, 5.320463863218434]);

translate([6, 21, 0]) cube([1, 1, 5.332863181446607]);

translate([7, 21, 0]) cube([1, 1, 5.418576203967559]);

color([0,1,0])
translate([8, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

translate([13, 21, 0]) cube([1, 1, 6.7]);

translate([14, 21, 0]) cube([1, 1, 6.9]);

translate([15, 21, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

translate([22, 21, 0]) cube([1, 1, 5.303357673848269]);

translate([23, 21, 0]) cube([1, 1, 5.303009394083766]);

translate([24, 21, 0]) cube([1, 1, 5.301831222159207]);

translate([25, 21, 0]) cube([1, 1, 5.301831217489061]);

color([0,1,0])
translate([26, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 21, 0]) cube([1, 1, 6]);

translate([30, 21, 0]) cube([1, 1, 5.4]);

translate([31, 21, 0]) cube([1, 1, 5.100000031703109]);

translate([0, 22, 0]) cube([1, 1, 7.1]);

translate([1, 22, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

translate([4, 22, 0]) cube([1, 1, 5.24189030030842]);

translate([5, 22, 0]) cube([1, 1, 5.241893949477211]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

translate([13, 22, 0]) cube([1, 1, 6.7]);

translate([14, 22, 0]) cube([1, 1, 6.8]);

translate([15, 22, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

translate([24, 22, 0]) cube([1, 1, 5.400085180359651]);

translate([25, 22, 0]) cube([1, 1, 5.400028581492733]);

color([0,1,0])
translate([26, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 22, 0]) cube([1, 1, 6]);

translate([30, 22, 0]) cube([1, 1, 5.20000006503161]);

translate([31, 22, 0]) cube([1, 1, 4.900000246060942]);

translate([0, 23, 0]) cube([1, 1, 6.9]);

translate([1, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 23, 0]) cube([1, 1, 6]);

translate([4, 23, 0]) cube([1, 1, 5.4001383796356155]);

color([0,1,0])
translate([5, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 23, 0]) cube([1, 1, 6]);

translate([12, 23, 0]) cube([1, 1, 6.7]);

translate([13, 23, 0]) cube([1, 1, 6.9]);

translate([14, 23, 0]) cube([1, 1, 7.0]);

translate([15, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([16, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 23, 0]) cube([1, 1, 6]);

translate([29, 23, 0]) cube([1, 1, 5.30000032620413]);

translate([30, 23, 0]) cube([1, 1, 5.000000395978865]);

translate([31, 23, 0]) cube([1, 1, 4.8000007656319035]);

translate([0, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 24, 0]) cube([1, 1, 6]);

translate([11, 24, 0]) cube([1, 1, 6.7]);

translate([12, 24, 0]) cube([1, 1, 7.0]);

translate([13, 24, 0]) cube([1, 1, 7.1]);

translate([14, 24, 0]) cube([1, 1, 7.1]);

translate([15, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 24, 0]) cube([1, 1, 6]);

translate([27, 24, 0]) cube([1, 1, 5.400003583577599]);

translate([28, 24, 0]) cube([1, 1, 5.300001631780938]);

translate([29, 24, 0]) cube([1, 1, 5.000001588658582]);

translate([30, 24, 0]) cube([1, 1, 4.800000824192392]);

translate([31, 24, 0]) cube([1, 1, 4.600001625405318]);

color([0,1,0])
translate([0, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 25, 0]) cube([1, 1, 6]);

translate([11, 25, 0]) cube([1, 1, 6.9]);

translate([12, 25, 0]) cube([1, 1, 7.2]);

translate([13, 25, 0]) cube([1, 1, 7.2]);

translate([14, 25, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([15, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 25, 0]) cube([1, 1, 6]);

translate([25, 25, 0]) cube([1, 1, 5.4000110817573495]);

translate([26, 25, 0]) cube([1, 1, 5.400008758025214]);

translate([27, 25, 0]) cube([1, 1, 5.4000045753271015]);

translate([28, 25, 0]) cube([1, 1, 5.200004071733036]);

translate([29, 25, 0]) cube([1, 1, 5.000001810712087]);

translate([30, 25, 0]) cube([1, 1, 4.700001265686996]);

translate([31, 25, 0]) cube([1, 1, 4.500005142620867]);

color([0,1,0])
translate([0, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 26, 0]) cube([1, 1, 6]);

translate([10, 26, 0]) cube([1, 1, 6.7]);

translate([11, 26, 0]) cube([1, 1, 6.9]);

translate([12, 26, 0]) cube([1, 1, 7.0]);

translate([13, 26, 0]) cube([1, 1, 6.9]);

translate([14, 26, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([15, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 26, 0]) cube([1, 1, 6]);

translate([25, 26, 0]) cube([1, 1, 5.400013154368257]);

translate([26, 26, 0]) cube([1, 1, 5.400010846420654]);

color([0,1,0])
translate([27, 26, 0]) cube([1, 1, 6]);

translate([28, 26, 0]) cube([1, 1, 5.4000015546256925]);

translate([29, 26, 0]) cube([1, 1, 5.300000310607111]);

translate([30, 26, 0]) cube([1, 1, 5.000000530084249]);

translate([31, 26, 0]) cube([1, 1, 4.700000897885622]);

color([0,1,0])
translate([0, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 27, 0]) cube([1, 1, 6]);

translate([9, 27, 0]) cube([1, 1, 6.6]);

translate([10, 27, 0]) cube([1, 1, 6.7]);

translate([11, 27, 0]) cube([1, 1, 6.7]);

translate([12, 27, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([13, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 27, 0]) cube([1, 1, 6]);

translate([31, 27, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([0, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 28, 0]) cube([1, 1, 6]);

translate([27, 28, 0]) cube([1, 1, 5.40000347368373]);

color([0,1,0])
translate([28, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 29, 0]) cube([1, 1, 6]);

translate([26, 29, 0]) cube([1, 1, 5.400004516330698]);

translate([27, 29, 0]) cube([1, 1, 5.30000707333342]);

translate([28, 29, 0]) cube([1, 1, 5.400001247884038]);

color([0,1,0])
translate([29, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 30, 0]) cube([1, 1, 6]);

translate([1, 30, 0]) cube([1, 1, 5.4]);

translate([2, 30, 0]) cube([1, 1, 5.4]);

translate([3, 30, 0]) cube([1, 1, 5.4]);

translate([4, 30, 0]) cube([1, 1, 5.3]);

translate([5, 30, 0]) cube([1, 1, 5.2]);

translate([6, 30, 0]) cube([1, 1, 5.1]);

translate([7, 30, 0]) cube([1, 1, 5.3]);

translate([8, 30, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([9, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 30, 0]) cube([1, 1, 6]);

translate([11, 30, 0]) cube([1, 1, 5.300273112612643]);

translate([12, 30, 0]) cube([1, 1, 5.205948194824677]);

translate([13, 30, 0]) cube([1, 1, 5.317571480999662]);

translate([14, 30, 0]) cube([1, 1, 5.431970167766308]);

color([0,1,0])
translate([15, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 30, 0]) cube([1, 1, 6]);

translate([22, 30, 0]) cube([1, 1, 5.300336437112321]);

translate([23, 30, 0]) cube([1, 1, 5.300158800997593]);

translate([24, 30, 0]) cube([1, 1, 5.400014495510573]);

translate([25, 30, 0]) cube([1, 1, 5.400006622193505]);

translate([26, 30, 0]) cube([1, 1, 5.300006993627147]);

translate([27, 30, 0]) cube([1, 1, 5.300007101227361]);

color([0,1,0])
translate([28, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 30, 0]) cube([1, 1, 6]);

translate([0, 31, 0]) cube([1, 1, 5.3]);

translate([1, 31, 0]) cube([1, 1, 5.2]);

translate([2, 31, 0]) cube([1, 1, 5.2]);

translate([3, 31, 0]) cube([1, 1, 5.3]);

translate([4, 31, 0]) cube([1, 1, 5.2]);

translate([5, 31, 0]) cube([1, 1, 5.0]);

translate([6, 31, 0]) cube([1, 1, 4.9]);

translate([7, 31, 0]) cube([1, 1, 5.0]);

translate([8, 31, 0]) cube([1, 1, 5.1]);

translate([9, 31, 0]) cube([1, 1, 5.1]);

translate([10, 31, 0]) cube([1, 1, 5.000136556193841]);

translate([11, 31, 0]) cube([1, 1, 4.803178931395636]);

translate([12, 31, 0]) cube([1, 1, 4.796392174305715]);

translate([13, 31, 0]) cube([1, 1, 4.869420454473094]);

translate([14, 31, 0]) cube([1, 1, 5.183351065355538]);

translate([15, 31, 0]) cube([1, 1, 5.377968766920937]);

translate([16, 31, 0]) cube([1, 1, 5.455285287334461]);

color([0,1,0])
translate([17, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 31, 0]) cube([1, 1, 6]);

translate([22, 31, 0]) cube([1, 1, 5.200653526652657]);

translate([23, 31, 0]) cube([1, 1, 5.101234399417507]);

translate([24, 31, 0]) cube([1, 1, 5.200071139144362]);

translate([25, 31, 0]) cube([1, 1, 5.200072834745858]);

translate([26, 31, 0]) cube([1, 1, 5.300007084418698]);

translate([27, 31, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 31, 0]) cube([1, 1, 6]);
