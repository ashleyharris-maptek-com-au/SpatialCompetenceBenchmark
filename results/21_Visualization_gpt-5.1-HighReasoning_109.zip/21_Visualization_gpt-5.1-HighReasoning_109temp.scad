
hull() {
    translate([13.49545, 7.5521, 8.995835]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.41355, 8.4899, 8.920865000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.39545, 8.592500000000001, 8.91253]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.15155, 9.5015, 8.83747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.1159, 9.5994, 8.829134999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.7181, 10.4526, 8.754165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.666, 10.542850000000001, 8.745835]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.126000000000001, 11.31415, 8.670865000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.05905, 11.39395, 8.66253]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.39395, 12.05905, 8.58747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.31415, 12.126000000000001, 8.579135]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.542850000000001, 12.666, 8.504165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.4526, 12.7181, 8.495835]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.5994, 13.1159, 8.420865000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.5015, 13.15155, 8.41253]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.592500000000001, 13.39545, 8.33747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.4899, 13.41355, 8.329134999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.5521, 13.49545, 8.254165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.4479, 13.49545, 8.245835]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.5101, 13.41355, 8.170865000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.407500000000001, 13.39545, 8.16253]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.498500000000001, 13.15155, 8.08747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.400600000000001, 13.1159, 8.079134999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.5474, 12.7181, 8.004165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.4571499999999995, 12.666, 7.9958350000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.68585, 12.126000000000001, 7.920865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6060499999999998, 12.05905, 7.91253]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.94095, 11.39395, 7.83747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.874, 11.31415, 7.829135]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.334, 10.542850000000001, 7.754165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.2819, 10.4526, 7.7458350000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8841, 9.5994, 7.670865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8484500000000001, 9.5015, 7.66253]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.60455, 8.592500000000001, 7.587470000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.58645, 8.4899, 7.579135000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.50455, 7.5521, 7.504165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.50455, 7.4479, 7.495835]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.58645, 6.5101, 7.420864999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.60455, 6.407500000000001, 7.412529999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8484500000000001, 5.498500000000001, 7.337470000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8841, 5.400600000000001, 7.329135000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.2819, 4.5474, 7.254165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.334, 4.4571499999999995, 7.2458350000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.874, 3.68585, 7.170865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.94095, 3.6060499999999998, 7.16253]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6060499999999998, 2.94095, 7.087470000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.68585, 2.874, 7.079135000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.4571499999999995, 2.334, 7.004165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.5474, 2.2819, 6.995835]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.400600000000001, 1.8841, 6.920864999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.498500000000001, 1.8484500000000001, 6.912529999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.407500000000001, 1.60455, 6.837470000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.5101, 1.58645, 6.829135000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.4479, 1.50455, 6.754165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.5521, 1.50455, 6.7458350000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.4899, 1.58645, 6.670865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.592500000000001, 1.60455, 6.66253]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.5015, 1.8484500000000001, 6.58747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.5994, 1.8841, 6.579135]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.4526, 2.2819, 6.504165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.542850000000001, 2.334, 6.4958350000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.31415, 2.874, 6.420865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.39395, 2.94095, 6.41253]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.05905, 3.6060499999999998, 6.337470000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.126000000000001, 3.68585, 6.329135000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.666, 4.4571499999999995, 6.254165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.7181, 4.5474, 6.245835]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.1159, 5.400600000000001, 6.170864999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.15155, 5.498500000000001, 6.162529999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.39545, 6.407500000000001, 6.087470000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.41355, 6.5101, 6.079135000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.49545, 7.4479, 6.004165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.49545, 7.5521, 5.9958350000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.41355, 8.4899, 5.920865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.39545, 8.592500000000001, 5.91253]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.15155, 9.5015, 5.837470000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.1159, 9.5994, 5.829135]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.7181, 10.4526, 5.7541649999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.666, 10.542850000000001, 5.745835]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.126000000000001, 11.31415, 5.670864999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.05905, 11.39395, 5.662529999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.39395, 12.05905, 5.587470000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.31415, 12.126000000000001, 5.579135000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.542850000000001, 12.666, 5.504165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.4526, 12.7181, 5.4958350000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.5994, 13.1159, 5.420865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.5015, 13.15155, 5.412529999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.592500000000001, 13.39545, 5.33747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.4899, 13.41355, 5.329135]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.5521, 13.49545, 5.254165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.4479, 13.49545, 5.2458350000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.5101, 13.41355, 5.170865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.407500000000001, 13.39545, 5.16253]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.498500000000001, 13.15155, 5.087470000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.400600000000001, 13.1159, 5.079135000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.5474, 12.7181, 5.004165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.4571499999999995, 12.666, 4.995835]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.68585, 12.126000000000001, 4.920864999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6060499999999998, 12.05905, 4.912529999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.94095, 11.39395, 4.837470000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.874, 11.31415, 4.829135000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.334, 10.542850000000001, 4.754165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.2819, 10.4526, 4.7458350000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8841, 9.5994, 4.670865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8484500000000001, 9.5015, 4.66253]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.60455, 8.592500000000001, 4.587470000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.58645, 8.4899, 4.579135]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.50455, 7.5521, 4.5041649999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.50455, 7.4479, 4.495835]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.58645, 6.5101, 4.420865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.60455, 6.407500000000001, 4.41253]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8484500000000001, 5.498500000000001, 4.337470000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8841, 5.400600000000001, 4.329135000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.2819, 4.5474, 4.254165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.334, 4.4571499999999995, 4.2458350000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.874, 3.68585, 4.170865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.94095, 3.6060499999999998, 4.162529999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6060499999999998, 2.94095, 4.087470000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.68585, 2.874, 4.079135000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.4571499999999995, 2.334, 4.004165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.5474, 2.2819, 3.995835]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.400600000000001, 1.8841, 3.920865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.498500000000001, 1.8484500000000001, 3.9125300000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.407500000000001, 1.60455, 3.83747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.5101, 1.58645, 3.829135]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.4479, 1.50455, 3.754165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.5521, 1.50455, 3.745835]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.4899, 1.58645, 3.670865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.592500000000001, 1.60455, 3.6625300000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.5015, 1.8484500000000001, 3.5874699999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.5994, 1.8841, 3.579135]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.4526, 2.2819, 3.504165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.542850000000001, 2.334, 3.495835]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.31415, 2.874, 3.420865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.39395, 2.94095, 3.41253]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.05905, 3.6060499999999998, 3.3374699999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.126000000000001, 3.68585, 3.329135]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.666, 4.4571499999999995, 3.2541650000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.7181, 4.5474, 3.2458350000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.1159, 5.400600000000001, 3.1708650000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.15155, 5.498500000000001, 3.1625300000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.39545, 6.407500000000001, 3.08747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.41355, 6.5101, 3.079135]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.49545, 7.4479, 3.0041650000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.49545, 7.5521, 2.995835]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.41355, 8.4899, 2.920865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.39545, 8.592500000000001, 2.9125300000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.15155, 9.5015, 2.83747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.1159, 9.5994, 2.829135]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.7181, 10.4526, 2.754165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.666, 10.542850000000001, 2.745835]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.126000000000001, 11.31415, 2.670865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.05905, 11.39395, 2.6625300000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.39395, 12.05905, 2.58747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.31415, 12.126000000000001, 2.579135]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.542850000000001, 12.666, 2.504165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.4526, 12.7181, 2.495835]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.5994, 13.1159, 2.420865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.5015, 13.15155, 2.41253]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.592500000000001, 13.39545, 2.3374699999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.4899, 13.41355, 2.329135]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.5521, 13.49545, 2.254165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.4479, 13.49545, 2.245835]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.5101, 13.41355, 2.170865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.407500000000001, 13.39545, 2.1625300000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.498500000000001, 13.15155, 2.08747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.400600000000001, 13.1159, 2.079135]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.5474, 12.7181, 2.004165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.4571499999999995, 12.666, 1.995835]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.68585, 12.126000000000001, 1.920865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6060499999999998, 12.05905, 1.91253]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.94095, 11.39395, 1.83747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.874, 11.31415, 1.829135]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.334, 10.542850000000001, 1.754165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.2819, 10.4526, 1.745835]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8841, 9.5994, 1.6708650000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8484500000000001, 9.5015, 1.6625300000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.60455, 8.592500000000001, 1.5874700000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.58645, 8.4899, 1.579135]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.50455, 7.5521, 1.504165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.50455, 7.4479, 1.495835]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.58645, 6.5101, 1.420865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.60455, 6.407500000000001, 1.41253]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8484500000000001, 5.498500000000001, 1.33747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8841, 5.400600000000001, 1.329135]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.2819, 4.5474, 1.254165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.334, 4.4571499999999995, 1.245835]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.874, 3.68585, 1.170865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.94095, 3.6060499999999998, 1.16253]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6060499999999998, 2.94095, 1.08747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.68585, 2.874, 1.079135]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.4571499999999995, 2.334, 1.004165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.5474, 2.2819, 0.995835]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.400600000000001, 1.8841, 0.9208649999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.498500000000001, 1.8484500000000001, 0.91253]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.407500000000001, 1.60455, 0.83747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.5101, 1.58645, 0.8291350000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.4479, 1.50455, 0.7541650000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.5521, 1.50455, 0.745835]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.4899, 1.58645, 0.6708649999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.592500000000001, 1.60455, 0.66253]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.5015, 1.8484500000000001, 0.58747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.5994, 1.8841, 0.5791350000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.4526, 2.2819, 0.504165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.542850000000001, 2.334, 0.495835]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.31415, 2.874, 0.42086500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.39395, 2.94095, 0.41253000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.05905, 3.6060499999999998, 0.33747000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.126000000000001, 3.68585, 0.329135]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.666, 4.4571499999999995, 0.254165]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.7181, 4.5474, 0.245835]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.1159, 5.400600000000001, 0.170865]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.15155, 5.498500000000001, 0.16253]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.39545, 6.407500000000001, 0.08746999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.41355, 6.5101, 0.079135]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.49545, 7.4479, 0.004165]) cube([0.4, 0.4, 0.1], center=true);
}

