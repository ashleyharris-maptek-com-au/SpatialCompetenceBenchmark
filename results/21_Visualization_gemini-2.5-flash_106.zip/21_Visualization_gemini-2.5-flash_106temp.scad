
hull() {
    translate([10.0, 1.074965, 18.99624]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 2.4243349999999997, 18.92856]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 2.574195, 18.921045000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 3.922305, 18.853455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 4.07203, 18.845945]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 5.41897, 18.778355]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 5.56856, 18.770845]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 6.9142399999999995, 18.703255000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 7.063689999999999, 18.695745000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 8.408109999999999, 18.628155000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 8.557424999999999, 18.620645000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 9.900675000000001, 18.553055]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 10.049855, 18.545545]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 11.391845, 18.477955]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 11.540880000000001, 18.470445]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 12.881519999999998, 18.402855000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 13.03041, 18.395345000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 14.369790000000002, 18.327755000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 14.518540000000002, 18.320245000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 15.85666, 18.252655]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 16.005264999999998, 18.245145]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 17.342035, 18.177554999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 17.490485, 18.170045000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 18.825815, 18.102455]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.069965, 18.895774999999997, 18.091175]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.329335, 18.819725, 17.955725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.4741, 18.80173, 17.940695]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.820500000000003, 18.55387, 17.805605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.969930000000002, 18.52126, 17.790595]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.313270000000001, 18.18214, 17.655505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.46235, 18.13946, 17.6405]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.802449999999999, 17.71034, 17.5055]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.95116, 17.657745, 17.4905]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.287840000000003, 17.140155, 17.3555]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.43616, 17.07782, 17.340505]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.76924, 16.473380000000002, 17.205595000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.85089, 16.367825000000003, 17.188085]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.98751, 15.072275000000001, 17.007815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.99369, 14.925360000000001, 16.987785000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.96831, 13.576440000000002, 16.807515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.96211, 13.426620000000002, 16.787485]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.87589, 12.07878, 16.607215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.86308, 11.929105, 16.587185]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.71872, 10.582795, 16.406914999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.69962, 10.43333, 16.386885]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.50018, 9.089269999999999, 16.206615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.475165, 8.94009, 16.186585]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.224335, 7.59891, 16.006315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.193865, 7.450085, 15.986285]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.896235, 6.112415, 15.806015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.860815000000002, 5.964015, 15.785985]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.520885, 4.630485, 15.605715000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.481035, 4.482585, 15.585685000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.103665, 3.153915, 15.405415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.059885, 3.006595, 15.385385]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.649215, 1.683505, 15.205115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.592855, 1.57982, 15.18513]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.989045, 1.03658, 15.005669999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.888785000000002, 1.00776, 14.985994999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.687915, 1.03224, 14.811305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.554145, 1.041395, 14.791935]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.347155, 1.181705, 14.617965]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.21298, 1.2033950000000002, 14.598675]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.00482, 1.4535050000000003, 14.425425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.87077, 1.4871150000000002, 14.406215000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.66603, 1.841985, 14.233685000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.532615, 1.8869150000000001, 14.214545000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.335885, 2.340785, 14.042555]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.203619999999999, 2.3964, 14.023485]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.019580000000001, 2.9436, 13.852215000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.888990000000001, 3.009265, 13.833215000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.722410000000001, 3.644035, 13.662485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.594015000000001, 3.7191050000000003, 13.643550000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.449485, 4.435594999999999, 13.473450000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.323805, 4.51943, 13.454580000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.206095, 5.3119700000000005, 13.285020000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.08363, 5.403955, 13.266210000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.99697, 6.267145, 13.09719]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8783149999999997, 6.366685, 13.078439999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8291849999999998, 7.295215, 12.90996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.73236, 7.400655, 12.89125]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.03864, 8.370045, 12.72295]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 8.49886, 12.703585]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 9.84814, 12.523315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 9.997995, 12.503285]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 11.346105, 12.323015000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 11.495825, 12.302985000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 12.842675, 12.122715000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 12.992255, 12.102685000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 14.337845, 11.922414999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 14.48728, 11.902384999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 15.831520000000001, 11.722114999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 15.980810000000002, 11.702084999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 17.32379, 11.521814999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 17.472935, 11.501784999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 18.814564999999998, 11.321515000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 18.889645, 11.301485000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 18.899454999999996, 11.121215000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.07502, 18.9, 11.101185000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.42358, 18.9, 10.920915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.57342, 18.9, 10.900885]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.92198, 18.9, 10.720615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.071755, 18.9, 10.700585]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.419145, 18.9, 10.520315000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.568785, 18.9, 10.500285000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.914915, 18.9, 10.320015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.064415, 18.9, 10.299985]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.409285, 18.9, 10.119715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.558645, 18.9, 10.099685]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.902255, 18.9, 9.919414999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.051475, 18.9, 9.899384999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.393825000000001, 18.9, 9.719114999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.542905000000001, 18.9, 9.699085]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.883995000000002, 18.9, 9.518815000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.032935000000002, 18.9, 9.498785000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.372765000000001, 18.9, 9.318515000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.521560000000001, 18.9, 9.298485000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.860040000000001, 18.9, 9.118215000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.008685, 18.9, 9.098185]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.345815, 18.9, 8.917915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.494305, 18.9, 8.897885]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.829995, 18.9, 8.717614999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.904205, 18.82521, 8.697585]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.904295, 17.47899, 8.517315000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.9043, 17.3292, 8.497285000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.9043, 15.979199999999999, 8.317015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.9043, 15.8292, 8.296985]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.9043, 14.4792, 8.116715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.9043, 14.3292, 8.096685]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.9043, 12.9792, 7.916415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.9043, 12.8292, 7.896385]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.9043, 11.4792, 7.716115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.9043, 11.3292, 7.696085000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.9043, 9.979199999999999, 7.515815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.9043, 9.829199999999998, 7.495785]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.9043, 8.479199999999999, 7.315515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.9043, 8.3292, 7.295485]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.9043, 6.9792000000000005, 7.115215]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.9043, 6.829200000000001, 7.095185]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.9043, 5.4792000000000005, 6.914915]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.9043, 5.3292, 6.894885]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.9043, 3.9792, 6.714615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.9043, 3.8292, 6.694585]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.9043, 2.4792, 6.514315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.8293, 2.4042, 6.494285]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.4793, 2.4042, 6.314015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.3293, 2.4042, 6.293985]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.9793, 2.4042, 6.113715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.8293, 2.4042, 6.093685000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4793, 2.4042, 5.9134150000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.3293, 2.4042, 5.893385]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.9793, 2.4042, 5.713115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.8293, 2.4042, 5.693085]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.479299999999999, 2.4042, 5.512815]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.329299999999998, 2.4042, 5.492785]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.979299999999999, 2.4042, 5.312515]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.8293, 2.4042, 5.292485000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.4793, 2.4042, 5.112215000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.3293, 2.4042, 5.092185000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.9793, 2.4042, 4.9119150000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.8293, 2.4042, 4.891885]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.4793, 2.4042, 4.711615]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.3293, 2.4042, 4.691585]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.9793000000000003, 2.4042, 4.511315]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.8293000000000004, 2.4042, 4.4912849999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.4793000000000003, 2.4042, 4.311015]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.33409, 2.4042, 4.290985]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.07031, 2.4042, 4.110715]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 2.4792, 4.090685]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 3.8292, 3.910415]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 3.9792, 3.890385]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 5.3292, 3.710115]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 5.4792000000000005, 3.6901]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 6.829200000000001, 3.5101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 6.9792000000000005, 3.4901]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 8.3292, 3.3101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 8.479199999999999, 3.2901]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 9.829199999999998, 3.1100999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 9.979199999999999, 3.0900999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 11.3292, 2.9101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 11.4792, 2.8901]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 12.8292, 2.7100999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 12.9792, 2.6900999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 14.3292, 2.5101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 14.4792, 2.4901]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 15.8292, 2.3101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 15.979199999999999, 2.2901]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 17.3292, 2.1100999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0001, 17.4792, 2.0900999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0001, 18.8292, 1.9101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0751000000000002, 18.9042, 1.8901]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.4251, 18.9042, 1.7101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.5751, 18.9042, 1.6901]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.9250999999999996, 18.9042, 1.5101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.0751, 18.9042, 1.4901]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.4251000000000005, 18.9042, 1.3101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.575100000000001, 18.9042, 1.2901]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.9251000000000005, 18.9042, 1.1101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.0751, 18.9042, 1.0901]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.4251, 18.9042, 0.9101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.575099999999999, 18.9042, 0.8901]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.9251, 18.9042, 0.7101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0751, 18.9042, 0.6900999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.4251, 18.9042, 0.5101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.575099999999999, 18.9042, 0.4901]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.9251, 18.9042, 0.3101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.075099999999999, 18.9042, 0.2901]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4251, 18.9042, 0.1101]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5751, 18.9042, 0.095095]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.9251, 18.9042, 0.005005]) cube([0.4, 0.4, 0.1], center=true);
}

