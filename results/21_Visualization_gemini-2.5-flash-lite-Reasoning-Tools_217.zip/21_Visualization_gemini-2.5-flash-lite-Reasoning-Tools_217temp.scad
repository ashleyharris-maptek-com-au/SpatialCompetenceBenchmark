
hull() {
    translate([10.07465, 10.0, 18.992900000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.41835, 10.0, 18.8651]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.5672, 10.0079, 18.8509]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.902800000000001, 10.150099999999998, 18.7231]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.050450000000001, 10.17395, 18.7089]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.37255, 10.461050000000002, 18.581100000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5183, 10.500750000000002, 18.566900000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.8197, 10.92825, 18.4391]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.962299999999999, 10.9833, 18.424899999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.2277, 11.5467, 18.297099999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.36545, 11.616449999999999, 18.282899999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.579549999999998, 12.308549999999999, 18.1551]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.7094, 12.39205, 18.140900000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.8326, 13.20295, 18.0131]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.90025, 13.299199999999999, 17.998900000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.99475, 14.2208, 17.871100000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 14.327650000000002, 17.8569]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 15.329350000000002, 17.729100000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 15.44435, 17.7149]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 16.51265, 17.5871]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 16.63305, 17.5729]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 17.73195, 17.4451]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 17.85305, 17.430899999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 18.93395, 17.3031]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.99475, 19.0443, 17.288899999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.90025, 19.9497, 17.1611]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.8819, 20.0, 17.146900000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.646099999999997, 20.0, 17.0191]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.61215, 20.0, 17.0049]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.236850000000004, 20.0, 16.877100000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.187700000000003, 20.0, 16.862900000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.6783, 20.0, 16.735100000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.6151, 20.0, 16.7209]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.986900000000002, 20.0, 16.5931]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.91095, 20.0, 16.578899999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.172050000000002, 20.0, 16.4511]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.08445, 20.0, 16.4369]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.24655, 20.0, 16.3091]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.14885, 20.0, 16.2949]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.22815, 20.0, 16.1671]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.122250000000001, 20.0, 16.1529]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.136750000000003, 20.0, 16.025100000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.024750000000001, 20.0, 16.010900000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.994250000000001, 20.0, 15.883099999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.8784, 20.0, 15.8689]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.823600000000003, 20.0, 15.741100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.706100000000001, 20.0, 15.7269]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.6459, 20.0, 15.5991]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.52885, 20.0, 15.584900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.48215, 20.0, 15.4571]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3678, 20.0, 15.4429]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.356200000000001, 20.0, 15.315100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.246500000000001, 20.0, 15.3009]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.283500000000001, 20.0, 15.1731]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.179600000000001, 20.0, 15.1589]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.2724, 20.0, 15.031099999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.17515, 20.0, 15.0169]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.33185, 20.0, 14.889100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.24205, 20.0, 14.8749]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.46895, 20.0, 14.7471]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.3874, 20.0, 14.7329]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6926, 20.0, 14.605100000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.62, 20.0, 14.590900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.008, 20.0, 14.4631]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.9448000000000003, 20.0, 14.4489]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.4192000000000005, 20.0, 14.3211]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.36595, 20.0, 14.3069]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.93305, 20.0, 14.179100000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8902999999999999, 20.0, 14.164900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.5537, 20.0, 14.037099999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5218, 20.0, 14.0229]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.2842, 20.0, 13.8951]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.26325, 19.99305, 13.8809]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.1237500000000002, 19.86795, 13.753100000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1135500000000003, 19.84725, 13.738900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.06945, 19.599749999999997, 13.611099999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0695999999999999, 19.5692, 13.596899999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.1164, 19.2668, 13.469100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1263500000000002, 19.23095, 13.4549]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.25865, 18.88805, 13.327100000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.27745, 18.84825, 13.3129]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.4835500000000001, 18.474750000000004, 13.1851]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5098000000000003, 18.432100000000002, 13.170900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7761999999999998, 18.037899999999997, 13.0431]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8085, 17.99345, 13.0289]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1235, 17.587550000000004, 12.9011]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.16045, 17.5422, 12.8869]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.51055, 17.131800000000002, 12.7591]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.5505999999999998, 17.0864, 12.744900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.9214, 16.6796, 12.6171]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.963, 16.63495, 12.6029]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.341, 16.23805, 12.4751]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3827000000000003, 16.1948, 12.460899999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.7553, 15.8132, 12.333100000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.7957, 15.77195, 12.318900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.1503, 15.411050000000001, 12.1911]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.188, 15.372300000000001, 12.1769]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.512, 15.0357, 12.0491]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.54575, 14.99975, 12.0349]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.82925, 14.689250000000001, 11.907100000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.85765, 14.65625, 11.892900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.08535, 14.37275, 11.7651]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.1068999999999996, 14.34275, 11.7509]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2671, 14.08625, 11.623099999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2806500000000005, 14.059249999999999, 11.6089]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.36435, 13.82975, 11.481100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.36905, 13.8056, 11.4669]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.36995, 13.6004, 11.3391]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.3653, 13.5789, 11.3249]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2807, 13.397100000000002, 11.197099999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2665500000000005, 13.378000000000002, 11.1829]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.09645, 13.216000000000001, 11.055100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.07295, 13.19895, 11.0409]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.82005, 13.05405, 10.9131]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.78765, 13.03865, 10.898900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.45735, 12.90635, 10.7711]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.4168, 12.892199999999999, 10.7569]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.017200000000001, 12.7698, 10.629100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.96945, 12.75655, 10.6149]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.50955, 12.640450000000001, 10.4871]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4557, 12.627650000000001, 10.472900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.9463000000000004, 12.513349999999999, 10.3451]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8875, 12.50055, 10.3309]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3385, 12.384450000000001, 10.2031]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.27595, 12.37125, 10.188899999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.69905, 12.24975, 10.0611]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.63375, 12.235750000000001, 10.0469]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.03525, 12.105250000000002, 9.919100000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9680000000000001, 12.089950000000002, 9.904900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.356, 11.94505, 9.777099999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.3059, 11.9277, 9.762899999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0161, 11.760299999999999, 9.635100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 11.739999999999998, 9.6209]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 11.542, 9.493100000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 11.5184, 9.478900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 11.291599999999999, 9.351099999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 11.264949999999999, 9.3369]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 11.012049999999999, 9.209100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 10.98265, 9.1949]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 10.70635, 9.0671]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 10.67445, 9.0529]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 10.37655, 8.925099999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 10.34245, 8.9109]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 10.02655, 8.7831]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 9.99055, 8.7689]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 9.65845, 8.641100000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 9.620800000000001, 8.626900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 9.275200000000002, 8.499100000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 9.2362, 8.484900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 8.8798, 8.357099999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 8.839749999999999, 8.3429]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 8.47525, 8.2151]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 8.4344, 8.2009]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 8.0636, 8.073100000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 8.02215, 8.058900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 7.646850000000001, 7.931100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 7.60505, 7.916900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 7.22795, 7.7891]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 7.1859, 7.774900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 6.806100000000001, 7.6471]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 6.7639000000000005, 7.632899999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 6.3841, 7.5051000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 6.34185, 7.490900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 5.96115, 7.3631]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 5.9189, 7.3489]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 5.5390999999999995, 7.221100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 5.4971, 7.206900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 5.1209, 7.0791]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 5.0792, 7.0649]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 4.7048000000000005, 6.9371]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 4.66345, 6.9229]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 4.29355, 6.795100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 4.25265, 6.780900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.88635, 6.6531]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.846, 6.6389]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.486, 6.5111]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.4463500000000002, 6.4969]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.09265, 6.3691]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.05375, 6.354900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.70725, 6.2271]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.66915, 6.212899999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.32985, 6.085100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.2925999999999997, 6.0709]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 1.9614000000000003, 5.9431]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 1.9250000000000003, 5.9289000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 1.601, 5.8011]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 1.5654000000000001, 5.7869]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 1.2486000000000002, 5.6591000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 1.21385, 5.6449]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.90515, 5.517099999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 0.8712500000000001, 5.5028999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.56975, 5.375100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 0.5367500000000001, 5.360900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.24425000000000002, 5.2331]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.00595, 0.21660000000000001, 5.2189000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.11305, 0.0114, 5.0911]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.13195, 0.0, 5.076899999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.36505, 0.0, 4.9491]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.39255, 0.0, 4.9349]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.6544500000000001, 0.0, 4.8071]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.6855500000000001, 0.0, 4.7929]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.98345, 0.0, 4.665100000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.01855, 0.0, 4.650900000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.35245, 0.0, 4.5231]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.3915, 0.0, 4.5089]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7605, 0.0, 4.3811]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8034, 0.0, 4.3669]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.2066, 0.0, 4.2391000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.2533, 0.0, 4.2249]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6906999999999996, 0.0, 4.0971]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.7411, 0.0, 4.0829]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.2109, 0.0, 3.9551]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.2649, 0.0, 3.9409]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.7671, 0.0, 3.8131000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.8245500000000003, 0.0, 3.7989]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.35645, 0.0, 3.6711]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.41705, 0.0, 3.6569000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.975949999999999, 0.0, 3.5291]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.039499999999999, 0.0, 3.5149]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.6245, 0.0, 3.3870999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.69075, 0.0, 3.3729]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.29825, 0.0, 3.2451000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.36685, 0.0, 3.2309]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.99415, 0.0, 3.1031]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.0648, 0.0, 3.0889]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.709200000000001, 0.0, 2.9611000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.781600000000001, 0.0, 2.9469000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.4404, 0.0, 2.8190999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.51425, 0.0, 2.8048999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.18475, 0.0, 2.6771]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.259699999999999, 0.0, 2.6629]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.9383, 0.0, 2.5351]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.014000000000001, 0.0, 2.5208999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.698000000000002, 0.0, 2.3931]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.774250000000002, 0.0, 2.3789000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.46275, 0.0, 2.2511]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.539299999999999, 0.0, 2.2369]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.2287, 0.0, 2.1090999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.305250000000001, 0.0, 2.0949]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.99375, 0.0, 1.9671]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.07, 0.0, 1.9529]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.754000000000001, 0.0, 1.8251000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.829600000000001, 0.0, 1.8109000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.506400000000001, 0.0, 1.6831]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.581000000000001, 0.0, 1.6689]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.247000000000002, 0.0, 1.5411000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.320200000000002, 0.0, 1.5269000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.9718, 0.0, 1.3991]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.04315, 0.0, 1.3849]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.67585, 0.0, 1.2570999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.744799999999998, 0.0, 1.2429000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.3532, 0.0, 1.1151]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.4193, 0.0, 1.1009]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.000700000000002, 0.0, 0.9731]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.06355, 0.0, 0.9589]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.61345, 0.0, 0.8311]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.6725, 0.0, 0.8169]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.1855, 0.0, 0.6891]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.24015, 0.0, 0.6749]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.710849999999997, 0.0, 0.5471]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.750149999999998, 0.0, 0.533]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.98685, 0.0, 0.40700000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 0.00595, 0.3929]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 0.11305, 0.2651]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 0.13195, 0.2509]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 0.36505, 0.12310000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 0.39255, 0.1102]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 0.6544500000000001, 0.0058000000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 0.6855500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 0.98345, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 1.01855, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 1.35245, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 1.3915, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 1.7605, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 1.8034, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 2.2066, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 2.2533, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 2.6906999999999996, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 2.7411, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 3.2109, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 3.2649, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 3.7671, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 3.8245500000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 4.35645, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 4.41705, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 4.975949999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 5.039499999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 5.6245, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 5.69075, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 6.29825, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 6.36685, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 6.99415, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 7.0648, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 7.709200000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 7.781600000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 8.4404, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 8.51425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 9.18475, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 9.259699999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 9.9383, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 10.014000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 10.698000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 10.774250000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 11.46275, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 11.539299999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 12.2287, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 12.305250000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 12.99375, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 13.07, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 13.754000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 13.829600000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 14.506400000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 14.581000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 15.247000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 15.320200000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 15.9718, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 16.04315, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 16.67585, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 16.744799999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 17.3532, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 17.4193, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 18.000700000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 18.06355, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 18.61345, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.0, 18.6725, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0, 19.1855, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.98685, 19.2533, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.750149999999998, 19.9607, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.710849999999997, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.24015, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.1858, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.6782, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.6151, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.986900000000002, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.91095, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.172050000000002, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.08445, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.24655, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.14885, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.22815, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.122250000000001, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.136750000000003, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.024750000000001, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.994250000000001, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.8784, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.823600000000003, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.706100000000001, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.6459, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.52885, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.48215, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3678, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.356200000000001, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.246500000000001, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.283500000000001, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.179600000000001, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.2724, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.17515, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.33185, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.24205, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.46895, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.3874, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6926, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.62, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.008, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.9448000000000003, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.4192000000000005, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.36595, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.93305, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8902999999999999, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.5537, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5218, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.2842, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.26325, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.1237500000000002, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1135500000000003, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.06945, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.0695999999999999, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.1164, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1263500000000002, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.25865, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.27745, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.4835500000000001, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5098000000000003, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7761999999999998, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8085, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1235, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.16045, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.51055, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.5505999999999998, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.9214, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.963, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.341, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3827000000000003, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.7553, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.7957, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.1503, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.188, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.512, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.54575, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.82925, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.85765, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.08535, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.1068999999999996, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2671, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2807, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.3653, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.37, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.37, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.3653, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2807, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2665500000000005, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.09645, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.07295, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.82005, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.78765, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.45735, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.4168, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.017200000000001, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.96945, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.50955, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4557, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.9463000000000004, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8875, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3385, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.27595, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.69905, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.63375, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.03525, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9680000000000001, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.356, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.3059, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0161, 20.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}

