
translate([0, 0, 0]) cube([1, 1, 5.0699999999999985]);

translate([1, 0, 0]) cube([1, 1, 4.529999999999998]);

translate([2, 0, 0]) cube([1, 1, 4.459999999999995]);

translate([3, 0, 0]) cube([1, 1, 4.3399999999999945]);

translate([4, 0, 0]) cube([1, 1, 4.279976683648345]);

translate([5, 0, 0]) cube([1, 1, 4.280003039600943]);

translate([6, 0, 0]) cube([1, 1, 4.268884436980916]);

translate([7, 0, 0]) cube([1, 1, 4.270139061973693]);

translate([8, 0, 0]) cube([1, 1, 4.268929353964067]);

translate([9, 0, 0]) cube([1, 1, 4.4]);

translate([10, 0, 0]) cube([1, 1, 4.5]);

translate([11, 0, 0]) cube([1, 1, 4.3]);

translate([12, 0, 0]) cube([1, 1, 4.268600756029863]);

translate([13, 0, 0]) cube([1, 1, 4.267160570356481]);

translate([14, 0, 0]) cube([1, 1, 4.4]);

translate([15, 0, 0]) cube([1, 1, 4.8]);

translate([16, 0, 0]) cube([1, 1, 5.0]);

translate([17, 0, 0]) cube([1, 1, 5.2]);

translate([18, 0, 0]) cube([1, 1, 5.3]);

translate([19, 0, 0]) cube([1, 1, 5.4]);

translate([20, 0, 0]) cube([1, 1, 5.4]);

translate([21, 0, 0]) cube([1, 1, 5.2]);

translate([22, 0, 0]) cube([1, 1, 4.9]);

translate([23, 0, 0]) cube([1, 1, 4.6]);

translate([24, 0, 0]) cube([1, 1, 4.4]);

translate([25, 0, 0]) cube([1, 1, 4.3]);

translate([26, 0, 0]) cube([1, 1, 4.3]);

translate([27, 0, 0]) cube([1, 1, 4.3]);

translate([28, 0, 0]) cube([1, 1, 4.4]);

translate([29, 0, 0]) cube([1, 1, 4.6]);

translate([30, 0, 0]) cube([1, 1, 4.7]);

translate([31, 0, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.279999999999996]);

translate([2, 1, 0]) cube([1, 1, 4.9199999999999955]);

translate([3, 1, 0]) cube([1, 1, 4.639999999999997]);

translate([4, 1, 0]) cube([1, 1, 4.289999999999998]);

translate([5, 1, 0]) cube([1, 1, 4.27997668369476]);

translate([6, 1, 0]) cube([1, 1, 4.26856901884652]);

translate([7, 1, 0]) cube([1, 1, 4.269469571093527]);

translate([8, 1, 0]) cube([1, 1, 4.270319510602957]);

translate([9, 1, 0]) cube([1, 1, 4.2702013214697985]);

translate([10, 1, 0]) cube([1, 1, 4.269446303412588]);

translate([11, 1, 0]) cube([1, 1, 4.270476021381471]);

translate([12, 1, 0]) cube([1, 1, 4.270588892876261]);

translate([13, 1, 0]) cube([1, 1, 4.270628241385669]);

translate([14, 1, 0]) cube([1, 1, 4.2699462225974285]);

translate([15, 1, 0]) cube([1, 1, 4.3]);

translate([16, 1, 0]) cube([1, 1, 4.5]);

translate([17, 1, 0]) cube([1, 1, 4.6]);

translate([18, 1, 0]) cube([1, 1, 4.8]);

translate([19, 1, 0]) cube([1, 1, 4.9]);

translate([20, 1, 0]) cube([1, 1, 4.8]);

translate([21, 1, 0]) cube([1, 1, 4.7]);

translate([22, 1, 0]) cube([1, 1, 4.5]);

translate([23, 1, 0]) cube([1, 1, 4.4]);

translate([24, 1, 0]) cube([1, 1, 4.2]);

translate([25, 1, 0]) cube([1, 1, 4.0]);

translate([26, 1, 0]) cube([1, 1, 3.8]);

translate([27, 1, 0]) cube([1, 1, 3.7]);

translate([28, 1, 0]) cube([1, 1, 3.9]);

translate([29, 1, 0]) cube([1, 1, 4.0]);

translate([30, 1, 0]) cube([1, 1, 4.2]);

translate([31, 1, 0]) cube([1, 1, 4.3]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.299999999999995]);

translate([4, 2, 0]) cube([1, 1, 4.939999999999997]);

translate([5, 2, 0]) cube([1, 1, 4.529999999999999]);

translate([6, 2, 0]) cube([1, 1, 4.42]);

translate([7, 2, 0]) cube([1, 1, 4.4]);

translate([8, 2, 0]) cube([1, 1, 4.3]);

translate([9, 2, 0]) cube([1, 1, 4.271102345340852]);

translate([10, 2, 0]) cube([1, 1, 4.2716130382262705]);

translate([11, 2, 0]) cube([1, 1, 4.271374734268458]);

translate([12, 2, 0]) cube([1, 1, 4.271122781106203]);

translate([13, 2, 0]) cube([1, 1, 4.270652495326658]);

translate([14, 2, 0]) cube([1, 1, 4.269693563421758]);

translate([15, 2, 0]) cube([1, 1, 4.270093253044039]);

translate([16, 2, 0]) cube([1, 1, 4.269460122692434]);

translate([17, 2, 0]) cube([1, 1, 4.3]);

translate([18, 2, 0]) cube([1, 1, 4.4]);

translate([19, 2, 0]) cube([1, 1, 4.5]);

translate([20, 2, 0]) cube([1, 1, 4.4]);

translate([21, 2, 0]) cube([1, 1, 4.3]);

translate([22, 2, 0]) cube([1, 1, 4.2]);

translate([23, 2, 0]) cube([1, 1, 4.0]);

translate([24, 2, 0]) cube([1, 1, 4.0]);

translate([25, 2, 0]) cube([1, 1, 3.9]);

translate([26, 2, 0]) cube([1, 1, 3.6]);

translate([27, 2, 0]) cube([1, 1, 3.4512133529882587]);

translate([28, 2, 0]) cube([1, 1, 3.5]);

translate([29, 2, 0]) cube([1, 1, 3.8]);

translate([30, 2, 0]) cube([1, 1, 3.9]);

translate([31, 2, 0]) cube([1, 1, 3.8]);

color([0,1,0])
translate([0, 3, 0]) cube([1, 1, 6]);

translate([1, 3, 0]) cube([1, 1, 6.509999999999995]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.179999999999998]);

translate([6, 3, 0]) cube([1, 1, 5.02]);

translate([7, 3, 0]) cube([1, 1, 4.9]);

translate([8, 3, 0]) cube([1, 1, 4.7]);

translate([9, 3, 0]) cube([1, 1, 4.4]);

translate([10, 3, 0]) cube([1, 1, 4.271243212333331]);

translate([11, 3, 0]) cube([1, 1, 4.270450779508058]);

translate([12, 3, 0]) cube([1, 1, 4.270941083247587]);

translate([13, 3, 0]) cube([1, 1, 4.3]);

translate([14, 3, 0]) cube([1, 1, 4.3]);

translate([15, 3, 0]) cube([1, 1, 4.2693771215566265]);

translate([16, 3, 0]) cube([1, 1, 4.3]);

translate([17, 3, 0]) cube([1, 1, 4.4]);

translate([18, 3, 0]) cube([1, 1, 4.4]);

translate([19, 3, 0]) cube([1, 1, 4.3]);

translate([20, 3, 0]) cube([1, 1, 4.2]);

translate([21, 3, 0]) cube([1, 1, 4.1]);

translate([22, 3, 0]) cube([1, 1, 3.8]);

translate([23, 3, 0]) cube([1, 1, 3.6]);

translate([24, 3, 0]) cube([1, 1, 3.6]);

translate([25, 3, 0]) cube([1, 1, 3.6]);

translate([26, 3, 0]) cube([1, 1, 3.4513335568319365]);

translate([27, 3, 0]) cube([1, 1, 3.4515310137427533]);

translate([28, 3, 0]) cube([1, 1, 3.4509662058466968]);

translate([29, 3, 0]) cube([1, 1, 3.6]);

translate([30, 3, 0]) cube([1, 1, 3.7]);

translate([31, 3, 0]) cube([1, 1, 3.6]);

color([0,1,0])
translate([0, 4, 0]) cube([1, 1, 6]);

translate([1, 4, 0]) cube([1, 1, 6.789999999999996]);

translate([2, 4, 0]) cube([1, 1, 6.629999999999993]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.469999999999999]);

translate([7, 4, 0]) cube([1, 1, 5.319999999999999]);

translate([8, 4, 0]) cube([1, 1, 5.0]);

translate([9, 4, 0]) cube([1, 1, 4.6]);

translate([10, 4, 0]) cube([1, 1, 4.41]);

translate([11, 4, 0]) cube([1, 1, 4.4]);

translate([12, 4, 0]) cube([1, 1, 4.6]);

translate([13, 4, 0]) cube([1, 1, 4.8]);

translate([14, 4, 0]) cube([1, 1, 4.8]);

translate([15, 4, 0]) cube([1, 1, 4.7]);

translate([16, 4, 0]) cube([1, 1, 4.7]);

translate([17, 4, 0]) cube([1, 1, 4.7]);

translate([18, 4, 0]) cube([1, 1, 4.4]);

translate([19, 4, 0]) cube([1, 1, 4.1]);

translate([20, 4, 0]) cube([1, 1, 4.0]);

translate([21, 4, 0]) cube([1, 1, 3.9]);

translate([22, 4, 0]) cube([1, 1, 3.6]);

translate([23, 4, 0]) cube([1, 1, 3.500000020343184]);

translate([24, 4, 0]) cube([1, 1, 3.4999999996404787]);

translate([25, 4, 0]) cube([1, 1, 3.5]);

translate([26, 4, 0]) cube([1, 1, 3.451125811024518]);

translate([27, 4, 0]) cube([1, 1, 3.4517051496670716]);

translate([28, 4, 0]) cube([1, 1, 3.451442080721884]);

translate([29, 4, 0]) cube([1, 1, 3.5]);

translate([30, 4, 0]) cube([1, 1, 3.6]);

translate([31, 4, 0]) cube([1, 1, 3.600008344693017]);

translate([0, 5, 0]) cube([1, 1, 6.595899141901892]);

translate([1, 5, 0]) cube([1, 1, 6.7207002890894785]);

translate([2, 5, 0]) cube([1, 1, 6.8399999999999945]);

translate([3, 5, 0]) cube([1, 1, 6.779999999999992]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

translate([8, 5, 0]) cube([1, 1, 5.319999999999999]);

translate([9, 5, 0]) cube([1, 1, 4.92]);

translate([10, 5, 0]) cube([1, 1, 4.72]);

translate([11, 5, 0]) cube([1, 1, 4.9]);

translate([12, 5, 0]) cube([1, 1, 5.1]);

translate([13, 5, 0]) cube([1, 1, 5.3]);

translate([14, 5, 0]) cube([1, 1, 5.3]);

translate([15, 5, 0]) cube([1, 1, 5.1]);

translate([16, 5, 0]) cube([1, 1, 5.1]);

translate([17, 5, 0]) cube([1, 1, 4.9]);

translate([18, 5, 0]) cube([1, 1, 4.5]);

translate([19, 5, 0]) cube([1, 1, 4.0]);

translate([20, 5, 0]) cube([1, 1, 3.8]);

translate([21, 5, 0]) cube([1, 1, 3.7]);

translate([22, 5, 0]) cube([1, 1, 3.5000000402880858]);

translate([23, 5, 0]) cube([1, 1, 3.4999999995330513]);

translate([24, 5, 0]) cube([1, 1, 3.4999999990326303]);

translate([25, 5, 0]) cube([1, 1, 3.5]);

translate([26, 5, 0]) cube([1, 1, 3.5]);

translate([27, 5, 0]) cube([1, 1, 3.451713503958538]);

translate([28, 5, 0]) cube([1, 1, 3.451632874254521]);

translate([29, 5, 0]) cube([1, 1, 3.5]);

translate([30, 5, 0]) cube([1, 1, 3.6]);

translate([31, 5, 0]) cube([1, 1, 3.6]);

translate([0, 6, 0]) cube([1, 1, 6.705183051758849]);

translate([1, 6, 0]) cube([1, 1, 6.834263325889212]);

translate([2, 6, 0]) cube([1, 1, 6.862159976511545]);

translate([3, 6, 0]) cube([1, 1, 6.850329888505137]);

translate([4, 6, 0]) cube([1, 1, 6.779999999999994]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.2299999999999995]);

translate([10, 6, 0]) cube([1, 1, 5.1]);

translate([11, 6, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([16, 6, 0]) cube([1, 1, 5.3]);

translate([17, 6, 0]) cube([1, 1, 5.0]);

translate([18, 6, 0]) cube([1, 1, 4.5]);

translate([19, 6, 0]) cube([1, 1, 4.0]);

translate([20, 6, 0]) cube([1, 1, 3.7]);

translate([21, 6, 0]) cube([1, 1, 3.5023906199708392]);

translate([22, 6, 0]) cube([1, 1, 3.51000082988602]);

translate([23, 6, 0]) cube([1, 1, 3.500000013429362]);

translate([24, 6, 0]) cube([1, 1, 3.6]);

translate([25, 6, 0]) cube([1, 1, 3.7]);

translate([26, 6, 0]) cube([1, 1, 3.8]);

translate([27, 6, 0]) cube([1, 1, 3.9]);

translate([28, 6, 0]) cube([1, 1, 3.8]);

translate([29, 6, 0]) cube([1, 1, 3.8]);

translate([30, 6, 0]) cube([1, 1, 3.8]);

translate([31, 6, 0]) cube([1, 1, 3.7]);

translate([0, 7, 0]) cube([1, 1, 6.744198517637359]);

translate([1, 7, 0]) cube([1, 1, 6.934263297911805]);

translate([2, 7, 0]) cube([1, 1, 6.923333878830714]);

translate([3, 7, 0]) cube([1, 1, 6.9336009192088115]);

translate([4, 7, 0]) cube([1, 1, 6.823146691986597]);

translate([5, 7, 0]) cube([1, 1, 6.739999999999995]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([16, 7, 0]) cube([1, 1, 5.4]);

translate([17, 7, 0]) cube([1, 1, 4.9]);

translate([18, 7, 0]) cube([1, 1, 4.6]);

translate([19, 7, 0]) cube([1, 1, 4.2]);

translate([20, 7, 0]) cube([1, 1, 3.8]);

translate([21, 7, 0]) cube([1, 1, 3.7]);

translate([22, 7, 0]) cube([1, 1, 3.8]);

translate([23, 7, 0]) cube([1, 1, 4.0]);

translate([24, 7, 0]) cube([1, 1, 4.0]);

translate([25, 7, 0]) cube([1, 1, 4.1]);

translate([26, 7, 0]) cube([1, 1, 4.3]);

translate([27, 7, 0]) cube([1, 1, 4.4]);

translate([28, 7, 0]) cube([1, 1, 4.3]);

translate([29, 7, 0]) cube([1, 1, 4.2]);

translate([30, 7, 0]) cube([1, 1, 4.1]);

translate([31, 7, 0]) cube([1, 1, 4.0]);

translate([0, 8, 0]) cube([1, 1, 6.787084942817028]);

translate([1, 8, 0]) cube([1, 1, 6.994940041957549]);

translate([2, 8, 0]) cube([1, 1, 6.997039299245635]);

translate([3, 8, 0]) cube([1, 1, 7.021559570648141]);

translate([4, 8, 0]) cube([1, 1, 6.886644132058097]);

translate([5, 8, 0]) cube([1, 1, 6.849999999999994]);

translate([6, 8, 0]) cube([1, 1, 6.729999999999995]);

translate([7, 8, 0]) cube([1, 1, 6.549999999999997]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([16, 8, 0]) cube([1, 1, 5.4]);

translate([17, 8, 0]) cube([1, 1, 5.0]);

translate([18, 8, 0]) cube([1, 1, 4.7]);

translate([19, 8, 0]) cube([1, 1, 4.4]);

translate([20, 8, 0]) cube([1, 1, 4.1]);

translate([21, 8, 0]) cube([1, 1, 4.0]);

translate([22, 8, 0]) cube([1, 1, 4.2]);

translate([23, 8, 0]) cube([1, 1, 4.5]);

translate([24, 8, 0]) cube([1, 1, 4.6]);

translate([25, 8, 0]) cube([1, 1, 4.6]);

translate([26, 8, 0]) cube([1, 1, 4.6]);

translate([27, 8, 0]) cube([1, 1, 4.7]);

translate([28, 8, 0]) cube([1, 1, 4.6]);

translate([29, 8, 0]) cube([1, 1, 4.5]);

translate([30, 8, 0]) cube([1, 1, 4.5]);

translate([31, 8, 0]) cube([1, 1, 4.4]);

translate([0, 9, 0]) cube([1, 1, 6.867658393967532]);

translate([1, 9, 0]) cube([1, 1, 7.063493622066945]);

translate([2, 9, 0]) cube([1, 1, 7.13771318733149]);

translate([3, 9, 0]) cube([1, 1, 7.102434423277418]);

translate([4, 9, 0]) cube([1, 1, 7.089999999999989]);

translate([5, 9, 0]) cube([1, 1, 6.949998875305749]);

translate([6, 9, 0]) cube([1, 1, 6.859999999999994]);

translate([7, 9, 0]) cube([1, 1, 6.584938743659473]);

translate([8, 9, 0]) cube([1, 1, 6.629999999999997]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 5.1]);

translate([18, 9, 0]) cube([1, 1, 4.9]);

translate([19, 9, 0]) cube([1, 1, 4.7]);

translate([20, 9, 0]) cube([1, 1, 4.5]);

translate([21, 9, 0]) cube([1, 1, 4.4]);

translate([22, 9, 0]) cube([1, 1, 4.7]);

translate([23, 9, 0]) cube([1, 1, 5.0]);

translate([24, 9, 0]) cube([1, 1, 5.1]);

translate([25, 9, 0]) cube([1, 1, 5.1]);

translate([26, 9, 0]) cube([1, 1, 5.0]);

translate([27, 9, 0]) cube([1, 1, 4.92]);

translate([28, 9, 0]) cube([1, 1, 4.819999999999999]);

translate([29, 9, 0]) cube([1, 1, 4.819999999999999]);

translate([30, 9, 0]) cube([1, 1, 4.91]);

translate([31, 9, 0]) cube([1, 1, 4.9]);

translate([0, 10, 0]) cube([1, 1, 6.866266717902233]);

translate([1, 10, 0]) cube([1, 1, 7.064651351500634]);

translate([2, 10, 0]) cube([1, 1, 7.244935059691351]);

translate([3, 10, 0]) cube([1, 1, 7.195785629934861]);

translate([4, 10, 0]) cube([1, 1, 7.119999999999989]);

translate([5, 10, 0]) cube([1, 1, 7.04999999999999]);

translate([6, 10, 0]) cube([1, 1, 6.745563868198135]);

translate([7, 10, 0]) cube([1, 1, 6.705358670818658]);

translate([8, 10, 0]) cube([1, 1, 6.645131279118419]);

translate([9, 10, 0]) cube([1, 1, 6.599999999999996]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 5.1]);

translate([18, 10, 0]) cube([1, 1, 4.9]);

translate([19, 10, 0]) cube([1, 1, 4.8]);

translate([20, 10, 0]) cube([1, 1, 4.7]);

translate([21, 10, 0]) cube([1, 1, 4.7]);

translate([22, 10, 0]) cube([1, 1, 5.1]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 10, 0]) cube([1, 1, 6]);

translate([26, 10, 0]) cube([1, 1, 5.42]);

translate([27, 10, 0]) cube([1, 1, 5.22]);

translate([28, 10, 0]) cube([1, 1, 5.139999999999999]);

translate([29, 10, 0]) cube([1, 1, 5.139999999999999]);

translate([30, 10, 0]) cube([1, 1, 5.339999999999999]);

translate([31, 10, 0]) cube([1, 1, 5.4]);

translate([0, 11, 0]) cube([1, 1, 6.852940908987605]);

translate([1, 11, 0]) cube([1, 1, 7.098296280358767]);

translate([2, 11, 0]) cube([1, 1, 7.277305905593354]);

translate([3, 11, 0]) cube([1, 1, 7.2476658753661605]);

translate([4, 11, 0]) cube([1, 1, 7.11707761322918]);

translate([5, 11, 0]) cube([1, 1, 6.934592368360651]);

translate([6, 11, 0]) cube([1, 1, 6.805513820778628]);

translate([7, 11, 0]) cube([1, 1, 6.734709251957285]);

translate([8, 11, 0]) cube([1, 1, 6.707004344027951]);

translate([9, 11, 0]) cube([1, 1, 6.699999999999996]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

translate([17, 11, 0]) cube([1, 1, 5.1]);

translate([18, 11, 0]) cube([1, 1, 5.0]);

translate([19, 11, 0]) cube([1, 1, 4.9]);

translate([20, 11, 0]) cube([1, 1, 4.8]);

translate([21, 11, 0]) cube([1, 1, 4.8]);

translate([22, 11, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 6.863169731346611]);

translate([1, 12, 0]) cube([1, 1, 7.108531016988354]);

translate([2, 12, 0]) cube([1, 1, 7.2853785031303575]);

translate([3, 12, 0]) cube([1, 1, 7.2445036052624525]);

translate([4, 12, 0]) cube([1, 1, 7.013479077281871]);

translate([5, 12, 0]) cube([1, 1, 6.93455259375062]);

translate([6, 12, 0]) cube([1, 1, 6.743200340578334]);

translate([7, 12, 0]) cube([1, 1, 6.728439915120664]);

translate([8, 12, 0]) cube([1, 1, 6.717258751483634]);

translate([9, 12, 0]) cube([1, 1, 6.779999999999996]);

translate([10, 12, 0]) cube([1, 1, 6.759999999999996]);

translate([11, 12, 0]) cube([1, 1, 6.6999999999999975]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

translate([17, 12, 0]) cube([1, 1, 5.3]);

translate([18, 12, 0]) cube([1, 1, 5.1]);

translate([19, 12, 0]) cube([1, 1, 5.0]);

translate([20, 12, 0]) cube([1, 1, 4.9]);

translate([21, 12, 0]) cube([1, 1, 5.0]);

translate([22, 12, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 6.9084202842776135]);

translate([1, 13, 0]) cube([1, 1, 7.089226488081929]);

translate([2, 13, 0]) cube([1, 1, 7.133591819761424]);

translate([3, 13, 0]) cube([1, 1, 7.073498839795529]);

translate([4, 13, 0]) cube([1, 1, 6.979016529507967]);

translate([5, 13, 0]) cube([1, 1, 6.852859590848267]);

translate([6, 13, 0]) cube([1, 1, 6.7632171579289]);

translate([7, 13, 0]) cube([1, 1, 6.738474853940506]);

translate([8, 13, 0]) cube([1, 1, 6.719696697147213]);

translate([9, 13, 0]) cube([1, 1, 6.644000753646074]);

translate([10, 13, 0]) cube([1, 1, 6.521672456309873]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

translate([12, 13, 0]) cube([1, 1, 6.6999999999999975]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

translate([18, 13, 0]) cube([1, 1, 5.4]);

translate([19, 13, 0]) cube([1, 1, 5.3]);

translate([20, 13, 0]) cube([1, 1, 5.2]);

translate([21, 13, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 13, 0]) cube([1, 1, 6]);

translate([27, 13, 0]) cube([1, 1, 6.649999999999999]);

color([0,1,0])
translate([28, 13, 0]) cube([1, 1, 6]);

translate([29, 13, 0]) cube([1, 1, 6.639999999999999]);

color([0,1,0])
translate([30, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 6.748728673355472]);

translate([1, 14, 0]) cube([1, 1, 7.045600996726561]);

translate([2, 14, 0]) cube([1, 1, 7.031225270052659]);

translate([3, 14, 0]) cube([1, 1, 7.0530676824153264]);

translate([4, 14, 0]) cube([1, 1, 6.962778575067448]);

translate([5, 14, 0]) cube([1, 1, 6.881915423232049]);

translate([6, 14, 0]) cube([1, 1, 6.796591679794602]);

translate([7, 14, 0]) cube([1, 1, 6.7366357882041985]);

translate([8, 14, 0]) cube([1, 1, 6.7216987158720665]);

translate([9, 14, 0]) cube([1, 1, 6.632402655488938]);

translate([10, 14, 0]) cube([1, 1, 6.560166539435807]);

translate([11, 14, 0]) cube([1, 1, 6.5099732263533046]);

translate([12, 14, 0]) cube([1, 1, 6.689999999999998]);

translate([13, 14, 0]) cube([1, 1, 6.519999999999998]);

translate([14, 14, 0]) cube([1, 1, 6.529999999999999]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 14, 0]) cube([1, 1, 6]);

translate([26, 14, 0]) cube([1, 1, 6.5699999999999985]);

color([0,1,0])
translate([27, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 6.788695049292449]);

translate([1, 15, 0]) cube([1, 1, 6.939340682090284]);

translate([2, 15, 0]) cube([1, 1, 7.0170792031078335]);

translate([3, 15, 0]) cube([1, 1, 7.053420425216212]);

translate([4, 15, 0]) cube([1, 1, 6.980743355013771]);

translate([5, 15, 0]) cube([1, 1, 6.884898868397992]);

translate([6, 15, 0]) cube([1, 1, 6.80619431881566]);

translate([7, 15, 0]) cube([1, 1, 6.7423057734287415]);

translate([8, 15, 0]) cube([1, 1, 6.68230568661356]);

translate([9, 15, 0]) cube([1, 1, 6.606333984213627]);

translate([10, 15, 0]) cube([1, 1, 6.543872525723402]);

translate([11, 15, 0]) cube([1, 1, 6.512299456685254]);

translate([12, 15, 0]) cube([1, 1, 6.629999999999997]);

translate([13, 15, 0]) cube([1, 1, 6.594263748759917]);

translate([14, 15, 0]) cube([1, 1, 6.589999999999998]);

translate([15, 15, 0]) cube([1, 1, 6.619999999999999]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 15, 0]) cube([1, 1, 6]);

translate([26, 15, 0]) cube([1, 1, 6.5699999999999985]);

color([0,1,0])
translate([27, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 15, 0]) cube([1, 1, 6]);

translate([0, 16, 0]) cube([1, 1, 6.90099085563146]);

translate([1, 16, 0]) cube([1, 1, 7.021672554304956]);

translate([2, 16, 0]) cube([1, 1, 7.021138609337517]);

translate([3, 16, 0]) cube([1, 1, 6.9914423003478]);

translate([4, 16, 0]) cube([1, 1, 6.915008943103806]);

translate([5, 16, 0]) cube([1, 1, 6.84775731019748]);

translate([6, 16, 0]) cube([1, 1, 6.819999999999993]);

translate([7, 16, 0]) cube([1, 1, 6.749999999999995]);

translate([8, 16, 0]) cube([1, 1, 6.759999999999996]);

translate([9, 16, 0]) cube([1, 1, 6.546695924648114]);

translate([10, 16, 0]) cube([1, 1, 6.500576250415386]);

translate([11, 16, 0]) cube([1, 1, 6.6999999999999975]);

translate([12, 16, 0]) cube([1, 1, 6.639999999999997]);

translate([13, 16, 0]) cube([1, 1, 6.624262921472146]);

translate([14, 16, 0]) cube([1, 1, 6.610001015208011]);

translate([15, 16, 0]) cube([1, 1, 6.649999999999999]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 16, 0]) cube([1, 1, 6]);

translate([27, 16, 0]) cube([1, 1, 6.579999999999998]);

color([0,1,0])
translate([28, 16, 0]) cube([1, 1, 6]);

translate([29, 16, 0]) cube([1, 1, 6.649999999999999]);

color([0,1,0])
translate([30, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 16, 0]) cube([1, 1, 6]);

translate([0, 17, 0]) cube([1, 1, 6.922511127396992]);

translate([1, 17, 0]) cube([1, 1, 6.971676605333353]);

translate([2, 17, 0]) cube([1, 1, 6.981289201293571]);

translate([3, 17, 0]) cube([1, 1, 6.971289202385039]);

translate([4, 17, 0]) cube([1, 1, 6.867757576241345]);

translate([5, 17, 0]) cube([1, 1, 6.759999999999993]);

translate([6, 17, 0]) cube([1, 1, 6.589999999999992]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

translate([10, 17, 0]) cube([1, 1, 6.579999999999998]);

translate([11, 17, 0]) cube([1, 1, 6.679999999999998]);

translate([12, 17, 0]) cube([1, 1, 6.629999999999997]);

translate([13, 17, 0]) cube([1, 1, 6.6999999999999975]);

translate([14, 17, 0]) cube([1, 1, 6.689999999999998]);

translate([15, 17, 0]) cube([1, 1, 6.679999999999998]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

translate([19, 17, 0]) cube([1, 1, 5.43]);

translate([20, 17, 0]) cube([1, 1, 5.42]);

translate([21, 17, 0]) cube([1, 1, 5.404160282382905]);

color([0,1,0])
translate([22, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 17, 0]) cube([1, 1, 6]);

translate([0, 18, 0]) cube([1, 1, 6.831959376366444]);

translate([1, 18, 0]) cube([1, 1, 6.969999999999992]);

translate([2, 18, 0]) cube([1, 1, 6.969999999999992]);

translate([3, 18, 0]) cube([1, 1, 6.879999999999992]);

translate([4, 18, 0]) cube([1, 1, 6.759999999999993]);

translate([5, 18, 0]) cube([1, 1, 6.589999999999992]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

translate([11, 18, 0]) cube([1, 1, 6.519999999999998]);

translate([12, 18, 0]) cube([1, 1, 6.689999999999998]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

translate([19, 18, 0]) cube([1, 1, 5.459999999999999]);

translate([20, 18, 0]) cube([1, 1, 5.40417171038279]);

translate([21, 18, 0]) cube([1, 1, 5.405984792847135]);

translate([22, 18, 0]) cube([1, 1, 5.404161779378852]);

color([0,1,0])
translate([23, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 6.739564687970652]);

translate([1, 19, 0]) cube([1, 1, 6.869999999999994]);

translate([2, 19, 0]) cube([1, 1, 6.699999999999994]);

translate([3, 19, 0]) cube([1, 1, 6.589999999999992]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

translate([12, 19, 0]) cube([1, 1, 6.509999999999998]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 19, 0]) cube([1, 1, 6]);

translate([16, 19, 0]) cube([1, 1, 6.5699999999999985]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);

translate([20, 19, 0]) cube([1, 1, 5.40453055104092]);

translate([21, 19, 0]) cube([1, 1, 5.407125225357882]);

translate([22, 19, 0]) cube([1, 1, 5.405515560276492]);

color([0,1,0])
translate([23, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 20, 0]) cube([1, 1, 6]);

translate([1, 20, 0]) cube([1, 1, 6.664712048630508]);

translate([2, 20, 0]) cube([1, 1, 6.619999999999993]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

translate([21, 20, 0]) cube([1, 1, 5.406122218696849]);

translate([22, 20, 0]) cube([1, 1, 5.407083321826349]);

translate([23, 20, 0]) cube([1, 1, 5.406492968720097]);

color([0,1,0])
translate([24, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 20, 0]) cube([1, 1, 6]);

translate([31, 20, 0]) cube([1, 1, 5.31]);

color([0,1,0])
translate([0, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 21, 0]) cube([1, 1, 6]);

translate([2, 21, 0]) cube([1, 1, 6.559999999999994]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 21, 0]) cube([1, 1, 6]);

translate([15, 21, 0]) cube([1, 1, 6.6999999999999975]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

translate([22, 21, 0]) cube([1, 1, 5.405547618199486]);

translate([23, 21, 0]) cube([1, 1, 5.40702689774727]);

translate([24, 21, 0]) cube([1, 1, 5.406579802116468]);

translate([25, 21, 0]) cube([1, 1, 5.405603913711295]);

color([0,1,0])
translate([26, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 21, 0]) cube([1, 1, 6]);

translate([30, 21, 0]) cube([1, 1, 5.4]);

translate([31, 21, 0]) cube([1, 1, 5.139999999999999]);

color([0,1,0])
translate([0, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

translate([12, 22, 0]) cube([1, 1, 6.559999999999997]);

color([0,1,0])
translate([13, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 22, 0]) cube([1, 1, 6]);

translate([15, 22, 0]) cube([1, 1, 6.6999999999999975]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

translate([24, 22, 0]) cube([1, 1, 5.405897903365564]);

translate([25, 22, 0]) cube([1, 1, 5.406400029837329]);

color([0,1,0])
translate([26, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 22, 0]) cube([1, 1, 6]);

translate([30, 22, 0]) cube([1, 1, 5.2]);

translate([31, 22, 0]) cube([1, 1, 4.9]);

color([0,1,0])
translate([0, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 23, 0]) cube([1, 1, 6]);

translate([11, 23, 0]) cube([1, 1, 6.539999999999997]);

color([0,1,0])
translate([12, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 23, 0]) cube([1, 1, 6]);

translate([29, 23, 0]) cube([1, 1, 5.3]);

translate([30, 23, 0]) cube([1, 1, 5.0]);

translate([31, 23, 0]) cube([1, 1, 4.8]);

translate([0, 24, 0]) cube([1, 1, 6.639999999999999]);

color([0,1,0])
translate([1, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 24, 0]) cube([1, 1, 6]);

translate([15, 24, 0]) cube([1, 1, 6.659999999999998]);

color([0,1,0])
translate([16, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 24, 0]) cube([1, 1, 6]);

translate([27, 24, 0]) cube([1, 1, 5.4]);

translate([28, 24, 0]) cube([1, 1, 5.3]);

translate([29, 24, 0]) cube([1, 1, 5.0]);

translate([30, 24, 0]) cube([1, 1, 4.8]);

translate([31, 24, 0]) cube([1, 1, 4.647705565613833]);

color([0,1,0])
translate([0, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 25, 0]) cube([1, 1, 6]);

translate([10, 25, 0]) cube([1, 1, 6.609999999999998]);

color([0,1,0])
translate([11, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 25, 0]) cube([1, 1, 6]);

translate([15, 25, 0]) cube([1, 1, 6.579999999999998]);

color([0,1,0])
translate([16, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 25, 0]) cube([1, 1, 6]);

translate([25, 25, 0]) cube([1, 1, 5.400035264491451]);

translate([26, 25, 0]) cube([1, 1, 5.4]);

translate([27, 25, 0]) cube([1, 1, 5.4]);

translate([28, 25, 0]) cube([1, 1, 5.2]);

translate([29, 25, 0]) cube([1, 1, 5.0]);

translate([30, 25, 0]) cube([1, 1, 4.7]);

translate([31, 25, 0]) cube([1, 1, 4.647705709681395]);

color([0,1,0])
translate([0, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 26, 0]) cube([1, 1, 6]);

translate([14, 26, 0]) cube([1, 1, 6.679999999999998]);

color([0,1,0])
translate([15, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 26, 0]) cube([1, 1, 6]);

translate([25, 26, 0]) cube([1, 1, 5.400098463440426]);

translate([26, 26, 0]) cube([1, 1, 5.400119241207428]);

color([0,1,0])
translate([27, 26, 0]) cube([1, 1, 6]);

translate([28, 26, 0]) cube([1, 1, 5.4]);

translate([29, 26, 0]) cube([1, 1, 5.3]);

translate([30, 26, 0]) cube([1, 1, 5.0]);

translate([31, 26, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 27, 0]) cube([1, 1, 6]);

translate([9, 27, 0]) cube([1, 1, 6.649999999999999]);

color([0,1,0])
translate([10, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 27, 0]) cube([1, 1, 6]);

translate([12, 27, 0]) cube([1, 1, 6.679999999999998]);

translate([13, 27, 0]) cube([1, 1, 6.589999999999998]);

color([0,1,0])
translate([14, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 27, 0]) cube([1, 1, 6]);

translate([31, 27, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([0, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 28, 0]) cube([1, 1, 6]);

translate([9, 28, 0]) cube([1, 1, 6.559999999999999]);

translate([10, 28, 0]) cube([1, 1, 6.559999999999999]);

color([0,1,0])
translate([11, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 28, 0]) cube([1, 1, 6]);

translate([27, 28, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 29, 0]) cube([1, 1, 6]);

translate([26, 29, 0]) cube([1, 1, 5.4]);

translate([27, 29, 0]) cube([1, 1, 5.3]);

translate([28, 29, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([29, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 30, 0]) cube([1, 1, 6]);

translate([1, 30, 0]) cube([1, 1, 5.4]);

translate([2, 30, 0]) cube([1, 1, 5.4]);

translate([3, 30, 0]) cube([1, 1, 5.4]);

translate([4, 30, 0]) cube([1, 1, 5.3]);

translate([5, 30, 0]) cube([1, 1, 5.2]);

translate([6, 30, 0]) cube([1, 1, 5.1]);

translate([7, 30, 0]) cube([1, 1, 5.3]);

translate([8, 30, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([9, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 30, 0]) cube([1, 1, 6]);

translate([11, 30, 0]) cube([1, 1, 5.3599999999999985]);

translate([12, 30, 0]) cube([1, 1, 5.269999999999999]);

translate([13, 30, 0]) cube([1, 1, 5.369999999999998]);

translate([14, 30, 0]) cube([1, 1, 5.4399999999999995]);

color([0,1,0])
translate([15, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 30, 0]) cube([1, 1, 6]);

translate([22, 30, 0]) cube([1, 1, 5.3]);

translate([23, 30, 0]) cube([1, 1, 5.3]);

translate([24, 30, 0]) cube([1, 1, 5.4]);

translate([25, 30, 0]) cube([1, 1, 5.4]);

translate([26, 30, 0]) cube([1, 1, 5.3]);

translate([27, 30, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([28, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 30, 0]) cube([1, 1, 6]);

translate([0, 31, 0]) cube([1, 1, 5.3]);

translate([1, 31, 0]) cube([1, 1, 5.229294825151096]);

translate([2, 31, 0]) cube([1, 1, 5.2292970720037095]);

translate([3, 31, 0]) cube([1, 1, 5.3]);

translate([4, 31, 0]) cube([1, 1, 5.2]);

translate([5, 31, 0]) cube([1, 1, 5.0794037969611505]);

translate([6, 31, 0]) cube([1, 1, 5.079496656408046]);

translate([7, 31, 0]) cube([1, 1, 5.0794409071024385]);

translate([8, 31, 0]) cube([1, 1, 5.1]);

translate([9, 31, 0]) cube([1, 1, 5.1]);

translate([10, 31, 0]) cube([1, 1, 5.02]);

translate([11, 31, 0]) cube([1, 1, 5.01434082688208]);

translate([12, 31, 0]) cube([1, 1, 5.015804365744261]);

translate([13, 31, 0]) cube([1, 1, 5.025843288747848]);

translate([14, 31, 0]) cube([1, 1, 5.139999999999999]);

translate([15, 31, 0]) cube([1, 1, 5.319999999999999]);

translate([16, 31, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([17, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 31, 0]) cube([1, 1, 6]);

translate([22, 31, 0]) cube([1, 1, 5.2]);

translate([23, 31, 0]) cube([1, 1, 5.1]);

translate([24, 31, 0]) cube([1, 1, 5.2]);

translate([25, 31, 0]) cube([1, 1, 5.2]);

translate([26, 31, 0]) cube([1, 1, 5.3]);

translate([27, 31, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 31, 0]) cube([1, 1, 6]);
