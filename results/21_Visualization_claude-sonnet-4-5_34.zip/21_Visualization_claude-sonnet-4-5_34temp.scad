
hull() {
    translate([5.0, 4.96, 4.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 4.24, 4.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 4.16, 4.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 3.44, 4.7075000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 3.3600000000000003, 4.692500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 2.6400000000000006, 4.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 2.5600000000000005, 4.5424999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 1.84, 4.407500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 1.76, 4.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 1.04, 4.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 0.96, 4.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 0.24000000000000002, 4.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.04, 0.2, 4.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.76, 0.2, 3.9575000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.84, 0.2, 3.9425000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.56, 0.2, 3.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.64, 0.2, 3.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.36, 0.2, 3.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.44, 0.2, 3.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.16, 0.2, 3.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.24, 0.2, 3.4924999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.959999999999999, 0.2, 3.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.04, 0.2, 3.3425000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.76, 0.2, 3.2075000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.8, 0.24000000000000002, 3.1925000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.8, 0.96, 3.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.8, 1.04, 3.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.8, 1.76, 2.9074999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.8, 1.84, 2.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.8, 2.5600000000000005, 2.7575000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.8, 2.6400000000000006, 2.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.8, 3.3600000000000003, 2.6075000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.8, 3.44, 2.5925000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.8, 4.16, 2.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.8, 4.24, 2.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.8, 4.96, 2.3074999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.8, 5.04, 2.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.8, 5.76, 2.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.8, 5.84, 2.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.8, 6.56, 2.0075000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.8, 6.64, 1.9925000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.8, 7.36, 1.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.8, 7.44, 1.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.8, 8.16, 1.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.8, 8.24, 1.6925000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.8, 8.959999999999999, 1.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.76, 9.0, 1.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.04, 9.0, 1.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.959999999999999, 9.0, 1.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.24, 9.0, 1.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.16, 9.0, 1.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.44, 9.0, 1.1075000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.36, 9.0, 1.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.64, 9.0, 0.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.56, 9.0, 0.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.84, 9.0, 0.8075000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.76, 9.0, 0.7925000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.04, 9.0, 0.6575000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.96, 9.0, 0.6425000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.24, 9.0, 0.5075000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.16, 9.0, 0.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.44, 9.0, 0.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3600000000000003, 9.0, 0.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6400000000000006, 9.0, 0.20750000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.6000000000000005, 9.0, 0.19000000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6000000000000005, 9.0, 0.010000000000000002]) cube([0.4, 0.4, 0.1], center=true);
}

