color([1, 0, 1]) hull()
{
  translate([82.9976, 50.0891, 94.99185]) cube([0.4, 0.4, 0.1], center = true);
  translate([82.9544, 51.6929, 94.84515]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([82.94375000000001, 51.8708, 94.8288]) cube([0.4, 0.4, 0.1], center = true);
  translate([82.79525000000001, 53.4692, 94.6812]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([82.77565000000001, 53.64645, 94.66480000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([82.57135, 55.238550000000004, 94.5172]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([82.5433, 55.4159, 94.5008]) cube([0.4, 0.4, 0.1], center = true);
  translate([82.2427, 57.0161, 94.3532]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([82.2043, 57.19115, 94.3368]) cube([0.4, 0.4, 0.1], center = true);
  translate([81.81370000000001, 58.74185000000001, 94.1892]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([81.76580000000001, 58.91020000000001, 94.17285]) cube([0.4, 0.4, 0.1], center = true);
  translate([81.2942, 60.38980000000001, 94.02615]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([81.2353, 60.55335000000001, 94.00985]) cube([0.4, 0.4, 0.1], center = true);
  translate([80.64670000000001, 62.01765, 93.86315]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([80.57930000000002, 62.1854, 93.84680000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([79.9547, 63.7406, 93.6992]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([79.8791, 63.92115, 93.68285]) cube([0.4, 0.4, 0.1], center = true);
  translate([79.1429, 65.61585, 93.53615]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([79.06095, 65.77425, 93.51985]) cube([0.4, 0.4, 0.1], center = true);
  translate([78.32205000000002, 66.93075, 93.37315]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([78.23315000000001, 67.0676, 93.35685]) cube([0.4, 0.4, 0.1], center = true);
  translate([77.37185, 68.37440000000001, 93.21015]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([77.2712, 68.52455, 93.19385]) cube([0.4, 0.4, 0.1], center = true);
  translate([76.32079999999999, 69.92045, 93.04715]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([76.2152, 70.066, 93.03085]) cube([0.4, 0.4, 0.1], center = true);
  translate([75.26480000000001, 71.29, 92.88415]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([75.15095000000001, 71.42365, 92.86785]) cube([0.4, 0.4, 0.1], center = true);
  translate([74.05205, 72.60535, 92.72115]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([73.92665, 72.73370000000001, 92.70485]) cube([0.4, 0.4, 0.1], center = true);
  translate([72.76835, 73.8623, 92.55815]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([72.64789999999999, 73.9778, 92.54185]) cube([0.4, 0.4, 0.1], center = true);
  translate([71.6381, 74.9282, 92.39515]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([71.5061, 75.0404, 92.3789]) cube([0.4, 0.4, 0.1], center = true);
  translate([70.1399, 76.1096, 92.2331]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([69.9947, 76.22014999999999, 92.21685]) cube([0.4, 0.4, 0.1], center = true);
  translate([68.7473, 77.14084999999999, 92.07015]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([68.5955, 77.24645, 92.05385]) cube([0.4, 0.4, 0.1], center = true);
  translate([67.11050000000002, 78.22655000000002, 91.90715]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([66.95540000000001, 78.32060000000001, 91.89085]) cube([0.4, 0.4, 0.1], center = true);
  translate([65.64859999999999, 79.0334, 91.74415]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([65.50174999999999, 79.11095, 91.7279]) cube([0.4, 0.4, 0.1], center = true);
  translate([64.16525, 79.79405, 91.5821]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([64.03325, 79.8584, 91.56585]) cube([0.4, 0.4, 0.1], center = true);
  translate([62.993750000000006, 80.3336, 91.41915]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([62.870000000000005, 80.3864, 91.40285]) cube([0.4, 0.4, 0.1], center = true);
  translate([61.682, 80.86160000000001, 91.25615]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([61.5566, 80.90945, 91.23985000000002]) cube([0.4, 0.4, 0.1], center = true);
  translate([60.487399999999994, 81.29554999999999, 91.09315000000001]) cube([0.4, 0.4, 0.1], center = true);
}
