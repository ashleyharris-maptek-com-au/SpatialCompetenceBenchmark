
hull() {
    translate([18.495800000000003, 10.05945, 18.993000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.4202, 11.12955, 18.867]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.39965, 11.24765, 18.853]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.10535, 12.30335, 18.727]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.060750000000002, 12.4183, 18.712999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.55225, 13.431700000000001, 18.586999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.484450000000002, 13.54045, 18.572999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.772550000000003, 14.484550000000002, 18.447]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.68305, 14.584100000000001, 18.433]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.78395, 15.431899999999999, 18.307000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.674800000000001, 15.5194, 18.293000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.609200000000001, 16.246599999999997, 18.167]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.483, 16.319499999999998, 18.153000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.277000000000001, 16.904500000000002, 18.027]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.13685, 16.96045, 18.012999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.82015, 17.382550000000002, 17.887]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.669550000000001, 17.4196, 17.872999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.275450000000001, 17.6644, 17.747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.1183, 17.681350000000002, 17.733]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.6837, 17.74165, 17.607000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.524049999999999, 17.73785, 17.593000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.08495, 17.60915, 17.467]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.92685, 17.58425, 17.453]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.52015, 17.26475, 17.327]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.3677, 17.21895, 17.313000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.0303, 16.71405, 17.187]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.8871, 16.6482, 17.173]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6468999999999996, 15.9678, 17.047]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.51605, 15.8835, 17.033]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.4009500000000001, 15.0465, 16.907]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.2855, 14.9461, 16.893]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.3225, 13.975900000000001, 16.767000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.2747, 13.862000000000002, 16.753]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.3773, 12.782, 16.627000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.4477, 12.65725, 16.613000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6123, 11.49175, 16.487000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.7499500000000001, 11.3589, 16.473]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.06305, 10.1331, 16.347]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.2157, 9.99555, 16.333]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.6503000000000005, 8.74545, 16.207]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.8146, 8.6072, 16.193]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.3374, 7.3688, 16.067]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.5096, 7.2339, 16.052999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.0864, 6.0441, 15.927]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.262599999999999, 5.916300000000001, 15.913]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.8574, 4.8057, 15.786999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.03385, 4.6884, 15.773]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.61515, 3.6876, 15.647]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.7884, 3.58425, 15.633000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.325600000000001, 2.7247500000000002, 15.507000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.49225, 2.63855, 15.493000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.954749999999999, 1.94645, 15.367]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.1116, 1.87995, 15.353]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.472399999999997, 1.3750499999999999, 15.227]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.616549999999997, 1.3296, 15.213000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.850450000000002, 1.0164, 15.087000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.979350000000004, 0.99265, 15.073]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.06565, 0.8783500000000001, 14.947]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.1774, 0.8764000000000001, 14.933]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.1026, 0.9556, 14.807]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.1461, 0.975, 14.793000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.003899999999998, 1.245, 14.667000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.9791, 1.2850000000000001, 14.653]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.674900000000004, 1.735, 14.527]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.63275, 1.7941, 14.513]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.17825, 2.4079000000000006, 14.387]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.1205, 2.4842000000000004, 14.373000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.5355, 3.2438000000000002, 14.247]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.464199999999998, 3.3352000000000004, 14.233]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.7658, 4.2208, 14.107]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.68315, 4.325049999999999, 14.093]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.89385, 5.315950000000001, 13.967000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.802500000000002, 5.430900000000001, 13.953000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.947500000000002, 6.5091, 13.827000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.85035, 6.63275, 13.813]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.95665, 7.7802500000000006, 13.687]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.8567, 7.910500000000001, 13.673]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.9513, 9.1075, 13.547]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.8516, 9.2421, 13.533]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.9624, 10.4679, 13.407]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.866000000000001, 10.60455, 13.393]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.020000000000001, 11.83845, 13.267]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.9298, 11.97495, 13.253]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.1522, 13.198050000000002, 13.126999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.0708, 13.3323, 13.113]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.3832, 14.5257, 12.987]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.31295, 14.655800000000001, 12.973]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.73605, 15.8042, 12.847000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.67905, 15.92825, 12.833000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.229949999999999, 17.01275, 12.707]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.18775, 17.1289, 12.693]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.87725, 18.1351, 12.567]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.8509, 18.24175, 12.553]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.687100000000001, 19.15525, 12.427000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.67735, 19.1957, 12.413]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.66565, 19.0103, 12.286999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.673449999999999, 18.950000000000003, 12.273]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.82555, 18.05, 12.147]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.8517, 17.939999999999998, 12.133000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.170300000000001, 16.86, 12.007000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.215200000000001, 16.73, 11.993]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.704799999999999, 15.470000000000002, 11.866999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.768799999999999, 15.325000000000001, 11.853]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.4312, 13.975, 11.727]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.51435, 13.82, 11.713000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.34865, 12.38, 11.587]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.4507, 12.215, 11.573]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.4533, 10.684999999999999, 11.447]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.5737, 10.514999999999999, 11.433]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.7383, 8.985, 11.307000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.8763, 8.82, 11.293000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.1957, 7.380000000000001, 11.167]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.350200000000001, 7.2250000000000005, 11.153]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.8118, 5.875, 11.027]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.9812, 5.739999999999999, 11.013]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.5688, 4.659999999999999, 10.887000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.75115, 4.55, 10.873000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.44585, 3.6500000000000004, 10.747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.4892, 3.5650000000000004, 10.733]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.5748, 2.935, 10.607]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.45095, 2.875, 10.593]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.136049999999997, 2.4250000000000003, 10.467000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.9809, 2.39, 10.453000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.5031, 2.21, 10.327]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.3371, 2.2, 10.313]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.826900000000002, 2.2, 10.187000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.6644, 2.21, 10.173]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.2496, 2.39, 10.046999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.104149999999999, 2.42, 10.033]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.90085, 2.78, 9.907]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.784600000000001, 2.83, 9.893]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.8954, 3.37, 9.767000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.81855, 3.44, 9.753]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.32445, 4.16, 9.626999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.2946, 4.245, 9.613]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.2514, 5.055, 9.487]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.2734, 5.145, 9.473]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.7126, 5.955, 9.347000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.78885, 6.045, 9.333]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.72215, 6.855, 9.206999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.852749999999999, 6.940000000000001, 9.193]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.27025, 7.660000000000001, 9.067]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.452900000000001, 7.735000000000001, 9.053]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.3231, 8.365, 8.927]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.55295, 8.425, 8.913]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.820050000000002, 8.875, 8.786999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.0391, 8.91, 8.773]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.7149, 9.09, 8.647]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.8126, 9.094999999999999, 8.633000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.8954, 9.004999999999999, 8.507]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.8645, 8.98, 8.493]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.2255, 8.620000000000001, 8.367]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.13055, 8.565, 8.353]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.06045, 7.9350000000000005, 8.227]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.9271, 7.855, 8.213000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.596899999999998, 7.045, 8.087]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.4439, 6.9399999999999995, 8.073]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.020100000000001, 5.859999999999999, 7.947000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.865450000000001, 5.734999999999999, 7.933000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.50555, 4.5649999999999995, 7.8069999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.366, 4.425, 7.792999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.214, 3.075, 7.667]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.1042, 2.9250000000000003, 7.6530000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.2798, 1.5750000000000002, 7.527]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.211, 1.425, 7.513]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.797, 0.07500000000000001, 7.3870000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.7767, 0.005000000000000001, 7.373]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.8253, 0.09500000000000001, 7.247]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.8575, 0.15500000000000003, 7.2330000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.388499999999999, 1.145, 7.106999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.47325, 1.2850000000000001, 7.093]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.467749999999999, 2.815, 6.9670000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.600999999999999, 2.995, 6.953]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.004999999999999, 4.705, 6.827000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.180299999999999, 4.890000000000001, 6.813000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.9317, 6.51, 6.686999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.14135, 6.67, 6.673]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.16365, 7.93, 6.547000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.34945, 8.05, 6.533]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.671550000000003, 8.95, 6.407000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.72475, 9.03, 6.393000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.36025, 9.57, 6.267]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.275499999999997, 9.610000000000001, 6.253]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.1145, 9.790000000000001, 6.127]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.948150000000002, 9.790000000000001, 6.113]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.11485, 9.610000000000001, 5.987000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.881500000000003, 9.57, 5.973000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.514499999999998, 9.03, 5.847]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.28155, 8.95, 5.833]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.45545, 8.05, 5.707]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.29315, 7.9350000000000005, 5.693]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.19785, 6.765000000000001, 5.566999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.125250000000001, 6.625, 5.553]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.91375, 5.275, 5.4270000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.94295, 5.130000000000001, 5.413]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.680050000000001, 3.87, 5.287000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.806700000000001, 3.735, 5.273000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.349300000000001, 2.565, 5.146999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.554800000000002, 2.455, 5.132999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.7112, 1.6450000000000002, 5.007]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.97445, 1.5750000000000002, 4.993]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.55655, 1.125, 4.867000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.81, 1.0950000000000002, 4.853000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.79, 1.0050000000000001, 4.727]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.88, 1.03, 4.713]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.52, 1.5700000000000003, 4.587]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.42, 1.6650000000000003, 4.5729999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.98, 2.835, 4.447]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.785, 3.0, 4.433000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.715, 4.8, 4.307]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.479999999999999, 5.015000000000001, 4.293]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.319999999999999, 7.085000000000001, 4.167]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.112499999999999, 7.32, 4.1530000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.5375, 9.48, 4.027]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.39, 9.72, 4.013]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.309999999999999, 11.88, 3.887]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.2225, 12.110000000000001, 3.873]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.727500000000001, 14.09, 3.747]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.709, 14.29, 3.733]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.871, 15.91, 3.607]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.924500000000002, 16.065, 3.5930000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.7255, 17.235, 3.467]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.849, 17.335, 3.453]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.271, 17.965, 3.327]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.4625, 18.0, 3.313]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4875, 18.0, 3.1870000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.743, 17.965, 3.173]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.317, 17.335, 3.047]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.582, 17.235, 3.0330000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.778, 16.065, 2.907]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.885, 15.975000000000001, 2.893]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.615000000000002, 15.525000000000002, 2.767]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.515, 15.505, 2.753]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.985, 15.594999999999999, 2.6270000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.765, 15.639999999999999, 2.613]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.334999999999999, 16.36, 2.487]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.08, 16.46, 2.4730000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.920000000000002, 17.540000000000003, 2.347]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.720000000000002, 17.665000000000003, 2.3329999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.280000000000001, 18.834999999999997, 2.2070000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.18, 18.95, 2.193]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.82, 19.85, 2.067]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.84, 19.885, 2.053]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.559999999999999, 19.615000000000002, 1.927]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.674999999999999, 19.565, 1.913]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.024999999999999, 18.935, 1.7870000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.195, 18.845, 1.7730000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.905000000000001, 17.855, 1.647]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.095, 17.72, 1.633]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.805, 16.28, 1.5070000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.974999999999998, 16.095, 1.493]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.325, 14.205, 1.3670000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.439999999999998, 13.98, 1.3530000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.16, 11.82, 1.227]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.19, 11.565, 1.213]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.01, 9.135, 1.0870000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.9375, 8.865, 1.0730000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.8125, 6.4350000000000005, 0.947]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.6525, 6.18, 0.9329999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.8975, 4.02, 0.807]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.685, 3.8049999999999997, 0.793]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.615, 2.095, 0.667]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.39, 1.935, 0.6530000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.410000000000002, 0.765, 0.527]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.215000000000002, 0.675, 0.513]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.685, 0.22500000000000003, 0.387]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.56, 0.19500000000000003, 0.373]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.84, 0.10500000000000001, 0.247]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.830000000000002, 0.125, 0.23299999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.370000000000001, 0.5750000000000001, 0.10700000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.48, 0.66, 0.09500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.92, 1.7400000000000002, 0.005000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}

