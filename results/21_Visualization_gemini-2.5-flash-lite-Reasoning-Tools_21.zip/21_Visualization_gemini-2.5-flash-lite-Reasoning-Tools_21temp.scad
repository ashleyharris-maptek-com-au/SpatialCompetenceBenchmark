
hull() {
    translate([5.0, 5.05, 4.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 5.95, 4.5249999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.775, 6.040000000000001, 4.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.7250000000000001, 6.76, 4.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.525, 6.835, 3.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9750000000000001, 7.465, 3.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.02, 7.53, 3.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.38, 8.07, 3.0250000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.415, 8.125, 2.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.685, 8.575, 2.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.715, 8.620000000000001, 2.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.985, 8.98, 2.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.0100000000000002, 9.015, 1.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1900000000000004, 9.285, 1.5250000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.205, 9.31, 1.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.295, 9.49, 1.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3049999999999997, 9.505, 0.9750000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.395, 9.595, 0.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.4000000000000004, 9.605, 0.47500000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.4000000000000004, 9.695, 0.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.4050000000000002, 9.700000000000001, -0.025]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.495, 9.700000000000001, -0.47500000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.51, 9.695, -0.525]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6900000000000004, 9.605, -0.9750000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.7150000000000003, 9.595, -1.025]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.9850000000000003, 9.505, -1.475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0200000000000005, 9.49, -1.5250000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.38, 9.31, -1.975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.42, 9.285, -2.025]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.78, 9.015, -2.475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.825, 8.98, -2.525]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.275, 8.620000000000001, -2.975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.325, 8.575, -3.0250000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.775, 8.125, -3.475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.825, 8.07, -3.525]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2749999999999995, 7.53, -3.975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.319999999999999, 7.465, -4.025]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.68, 6.835, -4.475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.71, 6.76, -4.5249999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.890000000000001, 6.040000000000001, -4.975]) cube([0.4, 0.4, 0.1], center=true);
}

