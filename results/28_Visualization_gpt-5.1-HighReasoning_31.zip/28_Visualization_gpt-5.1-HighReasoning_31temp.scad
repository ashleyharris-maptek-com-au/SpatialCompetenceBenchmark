
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.4]);

translate([2, 0, 0]) cube([1, 1, 4.2]);

translate([3, 0, 0]) cube([1, 1, 4.100000014099893]);

translate([4, 0, 0]) cube([1, 1, 4.000000126701271]);

translate([5, 0, 0]) cube([1, 1, 3.900029460713002]);

translate([6, 0, 0]) cube([1, 1, 3.9000294611310857]);

translate([7, 0, 0]) cube([1, 1, 4.0000198899542445]);

translate([8, 0, 0]) cube([1, 1, 4.20000449088791]);

translate([9, 0, 0]) cube([1, 1, 4.4]);

translate([10, 0, 0]) cube([1, 1, 4.5]);

translate([11, 0, 0]) cube([1, 1, 4.3]);

translate([12, 0, 0]) cube([1, 1, 4.2]);

translate([13, 0, 0]) cube([1, 1, 4.2]);

translate([14, 0, 0]) cube([1, 1, 4.4]);

translate([15, 0, 0]) cube([1, 1, 4.8]);

translate([16, 0, 0]) cube([1, 1, 5.0]);

translate([17, 0, 0]) cube([1, 1, 5.2]);

translate([18, 0, 0]) cube([1, 1, 5.3]);

translate([19, 0, 0]) cube([1, 1, 5.4]);

translate([20, 0, 0]) cube([1, 1, 5.4]);

translate([21, 0, 0]) cube([1, 1, 5.2]);

translate([22, 0, 0]) cube([1, 1, 4.9]);

translate([23, 0, 0]) cube([1, 1, 4.6]);

translate([24, 0, 0]) cube([1, 1, 4.4]);

translate([25, 0, 0]) cube([1, 1, 4.3]);

translate([26, 0, 0]) cube([1, 1, 4.3]);

translate([27, 0, 0]) cube([1, 1, 4.3]);

translate([28, 0, 0]) cube([1, 1, 4.4]);

translate([29, 0, 0]) cube([1, 1, 4.6]);

translate([30, 0, 0]) cube([1, 1, 4.7]);

translate([31, 0, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.1]);

translate([2, 1, 0]) cube([1, 1, 4.7]);

translate([3, 1, 0]) cube([1, 1, 4.5000000012715375]);

translate([4, 1, 0]) cube([1, 1, 4.200000037561909]);

translate([5, 1, 0]) cube([1, 1, 4.000000207203596]);

translate([6, 1, 0]) cube([1, 1, 3.9000294627011214]);

translate([7, 1, 0]) cube([1, 1, 4.000022975880833]);

translate([8, 1, 0]) cube([1, 1, 4.1000369989636045]);

translate([9, 1, 0]) cube([1, 1, 4.200017967429751]);

translate([10, 1, 0]) cube([1, 1, 4.200014491174983]);

translate([11, 1, 0]) cube([1, 1, 4.000113518471744]);

translate([12, 1, 0]) cube([1, 1, 3.9001896016991684]);

translate([13, 1, 0]) cube([1, 1, 3.9001863298376596]);

translate([14, 1, 0]) cube([1, 1, 4.000011430460905]);

translate([15, 1, 0]) cube([1, 1, 4.3]);

translate([16, 1, 0]) cube([1, 1, 4.5]);

translate([17, 1, 0]) cube([1, 1, 4.6]);

translate([18, 1, 0]) cube([1, 1, 4.8]);

translate([19, 1, 0]) cube([1, 1, 4.9]);

translate([20, 1, 0]) cube([1, 1, 4.8]);

translate([21, 1, 0]) cube([1, 1, 4.7]);

translate([22, 1, 0]) cube([1, 1, 4.5]);

translate([23, 1, 0]) cube([1, 1, 4.4]);

translate([24, 1, 0]) cube([1, 1, 4.2]);

translate([25, 1, 0]) cube([1, 1, 4.0]);

translate([26, 1, 0]) cube([1, 1, 3.8]);

translate([27, 1, 0]) cube([1, 1, 3.7]);

translate([28, 1, 0]) cube([1, 1, 3.9]);

translate([29, 1, 0]) cube([1, 1, 4.0]);

translate([30, 1, 0]) cube([1, 1, 4.2]);

translate([31, 1, 0]) cube([1, 1, 4.3]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

translate([2, 2, 0]) cube([1, 1, 5.4]);

translate([3, 2, 0]) cube([1, 1, 5.100000001394282]);

translate([4, 2, 0]) cube([1, 1, 4.800000006099726]);

translate([5, 2, 0]) cube([1, 1, 4.500000185553788]);

translate([6, 2, 0]) cube([1, 1, 4.400000811762974]);

translate([7, 2, 0]) cube([1, 1, 4.400000872910758]);

translate([8, 2, 0]) cube([1, 1, 4.300043937690772]);

translate([9, 2, 0]) cube([1, 1, 4.200043731128223]);

translate([10, 2, 0]) cube([1, 1, 4.000439586083553]);

translate([11, 2, 0]) cube([1, 1, 3.9006196508982196]);

translate([12, 2, 0]) cube([1, 1, 3.8021637336364322]);

translate([13, 2, 0]) cube([1, 1, 3.900187235780106]);

translate([14, 2, 0]) cube([1, 1, 3.900187592458997]);

translate([15, 2, 0]) cube([1, 1, 4.000045724576547]);

translate([16, 2, 0]) cube([1, 1, 4.200033949545665]);

translate([17, 2, 0]) cube([1, 1, 4.300010974974232]);

translate([18, 2, 0]) cube([1, 1, 4.40000299774081]);

translate([19, 2, 0]) cube([1, 1, 4.5]);

translate([20, 2, 0]) cube([1, 1, 4.4]);

translate([21, 2, 0]) cube([1, 1, 4.3]);

translate([22, 2, 0]) cube([1, 1, 4.2]);

translate([23, 2, 0]) cube([1, 1, 4.0]);

translate([24, 2, 0]) cube([1, 1, 4.0]);

translate([25, 2, 0]) cube([1, 1, 3.9]);

translate([26, 2, 0]) cube([1, 1, 3.600000348083671]);

translate([27, 2, 0]) cube([1, 1, 3.4000014708090904]);

translate([28, 2, 0]) cube([1, 1, 3.5]);

translate([29, 2, 0]) cube([1, 1, 3.8]);

translate([30, 2, 0]) cube([1, 1, 3.9]);

translate([31, 2, 0]) cube([1, 1, 3.8]);

translate([0, 3, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

translate([4, 3, 0]) cube([1, 1, 5.400000007875063]);

translate([5, 3, 0]) cube([1, 1, 5.10000002324656]);

translate([6, 3, 0]) cube([1, 1, 5.000000895668565]);

translate([7, 3, 0]) cube([1, 1, 4.900001926851497]);

translate([8, 3, 0]) cube([1, 1, 4.700001765801465]);

translate([9, 3, 0]) cube([1, 1, 4.4002151262357545]);

translate([10, 3, 0]) cube([1, 1, 4.100495313466125]);

translate([11, 3, 0]) cube([1, 1, 4.000580618302878]);

translate([12, 3, 0]) cube([1, 1, 4.200214622014479]);

translate([13, 3, 0]) cube([1, 1, 4.300072158445115]);

translate([14, 3, 0]) cube([1, 1, 4.3000504014742145]);

translate([15, 3, 0]) cube([1, 1, 4.200041814343132]);

translate([16, 3, 0]) cube([1, 1, 4.300011011991872]);

translate([17, 3, 0]) cube([1, 1, 4.4000051679716865]);

translate([18, 3, 0]) cube([1, 1, 4.400004247244712]);

translate([19, 3, 0]) cube([1, 1, 4.300004875543933]);

translate([20, 3, 0]) cube([1, 1, 4.2000009735516635]);

translate([21, 3, 0]) cube([1, 1, 4.100000193813521]);

translate([22, 3, 0]) cube([1, 1, 3.8000028155320487]);

translate([23, 3, 0]) cube([1, 1, 3.600042030252261]);

translate([24, 3, 0]) cube([1, 1, 3.6000084048218577]);

translate([25, 3, 0]) cube([1, 1, 3.600001399355254]);

translate([26, 3, 0]) cube([1, 1, 3.400004073675371]);

translate([27, 3, 0]) cube([1, 1, 3.3000049212118006]);

translate([28, 3, 0]) cube([1, 1, 3.400000366702151]);

translate([29, 3, 0]) cube([1, 1, 3.6]);

translate([30, 3, 0]) cube([1, 1, 3.7]);

translate([31, 3, 0]) cube([1, 1, 3.6]);

translate([0, 4, 0]) cube([1, 1, 7.2]);

translate([1, 4, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.400000069906358]);

translate([7, 4, 0]) cube([1, 1, 5.3000043529996645]);

translate([8, 4, 0]) cube([1, 1, 5.000004317355391]);

translate([9, 4, 0]) cube([1, 1, 4.600420125876367]);

translate([10, 4, 0]) cube([1, 1, 4.400662148955093]);

translate([11, 4, 0]) cube([1, 1, 4.400640123808554]);

translate([12, 4, 0]) cube([1, 1, 4.600261779523961]);

translate([13, 4, 0]) cube([1, 1, 4.800099051555544]);

translate([14, 4, 0]) cube([1, 1, 4.800061184384508]);

translate([15, 4, 0]) cube([1, 1, 4.700030551823011]);

translate([16, 4, 0]) cube([1, 1, 4.700013042219342]);

translate([17, 4, 0]) cube([1, 1, 4.7000048281506945]);

translate([18, 4, 0]) cube([1, 1, 4.400012260646877]);

translate([19, 4, 0]) cube([1, 1, 4.100020452394494]);

translate([20, 4, 0]) cube([1, 1, 4.00006531127578]);

translate([21, 4, 0]) cube([1, 1, 3.900011079275974]);

translate([22, 4, 0]) cube([1, 1, 3.600165309682262]);

translate([23, 4, 0]) cube([1, 1, 3.400843955582837]);

translate([24, 4, 0]) cube([1, 1, 3.4008290117982]);

translate([25, 4, 0]) cube([1, 1, 3.5000072024493565]);

translate([26, 4, 0]) cube([1, 1, 3.4000074576464936]);

translate([27, 4, 0]) cube([1, 1, 3.2000369944188845]);

translate([28, 4, 0]) cube([1, 1, 3.30000495098802]);

translate([29, 4, 0]) cube([1, 1, 3.5]);

translate([30, 4, 0]) cube([1, 1, 3.6]);

translate([31, 4, 0]) cube([1, 1, 3.5]);

translate([0, 5, 0]) cube([1, 1, 7.4]);

translate([1, 5, 0]) cube([1, 1, 6.9]);

translate([2, 5, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

translate([8, 5, 0]) cube([1, 1, 5.300021415068175]);

translate([9, 5, 0]) cube([1, 1, 4.900560083335595]);

translate([10, 5, 0]) cube([1, 1, 4.701092924376252]);

translate([11, 5, 0]) cube([1, 1, 4.900689902396152]);

translate([12, 5, 0]) cube([1, 1, 5.100388728084054]);

translate([13, 5, 0]) cube([1, 1, 5.300131217672867]);

translate([14, 5, 0]) cube([1, 1, 5.300065691862554]);

translate([15, 5, 0]) cube([1, 1, 5.100018638430224]);

translate([16, 5, 0]) cube([1, 1, 5.100007246540242]);

translate([17, 5, 0]) cube([1, 1, 4.900008731096428]);

translate([18, 5, 0]) cube([1, 1, 4.500059456101733]);

translate([19, 5, 0]) cube([1, 1, 4.00023475432998]);

translate([20, 5, 0]) cube([1, 1, 3.8002325260179566]);

translate([21, 5, 0]) cube([1, 1, 3.700812463603899]);

translate([22, 5, 0]) cube([1, 1, 3.5023278904187927]);

translate([23, 5, 0]) cube([1, 1, 3.3105343159529195]);

translate([24, 5, 0]) cube([1, 1, 3.400871408839345]);

translate([25, 5, 0]) cube([1, 1, 3.5000190252078878]);

translate([26, 5, 0]) cube([1, 1, 3.500009558243678]);

translate([27, 5, 0]) cube([1, 1, 3.4000042526127565]);

translate([28, 5, 0]) cube([1, 1, 3.400001415260688]);

translate([29, 5, 0]) cube([1, 1, 3.5]);

translate([30, 5, 0]) cube([1, 1, 3.6]);

translate([31, 5, 0]) cube([1, 1, 3.6]);

translate([0, 6, 0]) cube([1, 1, 7.7]);

translate([1, 6, 0]) cube([1, 1, 7.2]);

translate([2, 6, 0]) cube([1, 1, 7.0]);

translate([3, 6, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([4, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.200639786878728]);

translate([10, 6, 0]) cube([1, 1, 5.101447001352437]);

translate([11, 6, 0]) cube([1, 1, 5.301034925749668]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([16, 6, 0]) cube([1, 1, 5.300021744259368]);

translate([17, 6, 0]) cube([1, 1, 5.000023400526966]);

translate([18, 6, 0]) cube([1, 1, 4.5002607850361205]);

translate([19, 6, 0]) cube([1, 1, 4.00059850901375]);

translate([20, 6, 0]) cube([1, 1, 3.703753405306249]);

translate([21, 6, 0]) cube([1, 1, 3.5050862088343595]);

translate([22, 6, 0]) cube([1, 1, 3.5030854461180025]);

translate([23, 6, 0]) cube([1, 1, 3.5023241891326258]);

translate([24, 6, 0]) cube([1, 1, 3.600087105307945]);

translate([25, 6, 0]) cube([1, 1, 3.700026725577626]);

translate([26, 6, 0]) cube([1, 1, 3.8]);

translate([27, 6, 0]) cube([1, 1, 3.9]);

translate([28, 6, 0]) cube([1, 1, 3.8]);

translate([29, 6, 0]) cube([1, 1, 3.8]);

translate([30, 6, 0]) cube([1, 1, 3.8]);

translate([31, 6, 0]) cube([1, 1, 3.7]);

translate([0, 7, 0]) cube([1, 1, 8.0]);

translate([1, 7, 0]) cube([1, 1, 7.5]);

translate([2, 7, 0]) cube([1, 1, 7.3]);

translate([3, 7, 0]) cube([1, 1, 7.0]);

translate([4, 7, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([5, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([16, 7, 0]) cube([1, 1, 5.400111417191841]);

translate([17, 7, 0]) cube([1, 1, 4.900389400091918]);

translate([18, 7, 0]) cube([1, 1, 4.600881938405698]);

translate([19, 7, 0]) cube([1, 1, 4.201777926836615]);

translate([20, 7, 0]) cube([1, 1, 3.8044460896870547]);

translate([21, 7, 0]) cube([1, 1, 3.7046459604503448]);

translate([22, 7, 0]) cube([1, 1, 3.801368182346219]);

translate([23, 7, 0]) cube([1, 1, 4.000275172624504]);

translate([24, 7, 0]) cube([1, 1, 4.000133628943809]);

translate([25, 7, 0]) cube([1, 1, 4.100000002407574]);

translate([26, 7, 0]) cube([1, 1, 4.3]);

translate([27, 7, 0]) cube([1, 1, 4.4]);

translate([28, 7, 0]) cube([1, 1, 4.3]);

translate([29, 7, 0]) cube([1, 1, 4.2]);

translate([30, 7, 0]) cube([1, 1, 4.1]);

translate([31, 7, 0]) cube([1, 1, 4.0]);

translate([0, 8, 0]) cube([1, 1, 7.9]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 7.3]);

translate([3, 8, 0]) cube([1, 1, 7.0]);

translate([4, 8, 0]) cube([1, 1, 6.8]);

translate([5, 8, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([6, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([16, 8, 0]) cube([1, 1, 5.400445463982361]);

translate([17, 8, 0]) cube([1, 1, 5.000955579333662]);

translate([18, 8, 0]) cube([1, 1, 4.703041315805729]);

translate([19, 8, 0]) cube([1, 1, 4.404705597950618]);

translate([20, 8, 0]) cube([1, 1, 4.105787612060531]);

translate([21, 8, 0]) cube([1, 1, 4.00491471545125]);

translate([22, 8, 0]) cube([1, 1, 4.201391694995273]);

translate([23, 8, 0]) cube([1, 1, 4.500259331224593]);

translate([24, 8, 0]) cube([1, 1, 4.600000012366953]);

translate([25, 8, 0]) cube([1, 1, 4.600000001906087]);

translate([26, 8, 0]) cube([1, 1, 4.6]);

translate([27, 8, 0]) cube([1, 1, 4.7]);

translate([28, 8, 0]) cube([1, 1, 4.6]);

translate([29, 8, 0]) cube([1, 1, 4.5]);

translate([30, 8, 0]) cube([1, 1, 4.5]);

translate([31, 8, 0]) cube([1, 1, 4.4]);

translate([0, 9, 0]) cube([1, 1, 7.9]);

translate([1, 9, 0]) cube([1, 1, 7.4]);

translate([2, 9, 0]) cube([1, 1, 7.1]);

translate([3, 9, 0]) cube([1, 1, 6.9]);

translate([4, 9, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([5, 9, 0]) cube([1, 1, 6]);

translate([6, 9, 0]) cube([1, 1, 6.6]);

translate([7, 9, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 5.102587021600493]);

translate([18, 9, 0]) cube([1, 1, 4.9036347148646575]);

translate([19, 9, 0]) cube([1, 1, 4.705483937927563]);

translate([20, 9, 0]) cube([1, 1, 4.505780488018683]);

translate([21, 9, 0]) cube([1, 1, 4.405402499907273]);

translate([22, 9, 0]) cube([1, 1, 4.7012965687537465]);

translate([23, 9, 0]) cube([1, 1, 5.000000077763739]);

translate([24, 9, 0]) cube([1, 1, 5.1]);

translate([25, 9, 0]) cube([1, 1, 5.1]);

translate([26, 9, 0]) cube([1, 1, 5.0]);

translate([27, 9, 0]) cube([1, 1, 4.9]);

translate([28, 9, 0]) cube([1, 1, 4.8]);

translate([29, 9, 0]) cube([1, 1, 4.8]);

translate([30, 9, 0]) cube([1, 1, 4.9]);

translate([31, 9, 0]) cube([1, 1, 4.9]);

translate([0, 10, 0]) cube([1, 1, 8.0]);

translate([1, 10, 0]) cube([1, 1, 7.5]);

translate([2, 10, 0]) cube([1, 1, 7.1]);

translate([3, 10, 0]) cube([1, 1, 6.7]);

translate([4, 10, 0]) cube([1, 1, 6.6]);

translate([5, 10, 0]) cube([1, 1, 6.6]);

translate([6, 10, 0]) cube([1, 1, 6.8]);

translate([7, 10, 0]) cube([1, 1, 6.9]);

translate([8, 10, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 5.105964282578477]);

translate([18, 10, 0]) cube([1, 1, 4.908965676035921]);

translate([19, 10, 0]) cube([1, 1, 4.808885952753683]);

translate([20, 10, 0]) cube([1, 1, 4.708050173927794]);

translate([21, 10, 0]) cube([1, 1, 4.706482376996073]);

translate([22, 10, 0]) cube([1, 1, 5.10000039305616]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 10, 0]) cube([1, 1, 6]);

translate([26, 10, 0]) cube([1, 1, 5.4]);

translate([27, 10, 0]) cube([1, 1, 5.2]);

translate([28, 10, 0]) cube([1, 1, 5.1]);

translate([29, 10, 0]) cube([1, 1, 5.1]);

translate([30, 10, 0]) cube([1, 1, 5.3]);

translate([31, 10, 0]) cube([1, 1, 5.4]);

translate([0, 11, 0]) cube([1, 1, 8.2]);

translate([1, 11, 0]) cube([1, 1, 7.7]);

translate([2, 11, 0]) cube([1, 1, 7.2]);

translate([3, 11, 0]) cube([1, 1, 6.9]);

translate([4, 11, 0]) cube([1, 1, 6.9]);

translate([5, 11, 0]) cube([1, 1, 7.0]);

translate([6, 11, 0]) cube([1, 1, 7.2]);

translate([7, 11, 0]) cube([1, 1, 7.1]);

translate([8, 11, 0]) cube([1, 1, 6.7]);

translate([9, 11, 0]) cube([1, 1, 6.500592140065442]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

translate([17, 11, 0]) cube([1, 1, 5.114003458803343]);

translate([18, 11, 0]) cube([1, 1, 5.013544899129647]);

translate([19, 11, 0]) cube([1, 1, 4.91048612783332]);

translate([20, 11, 0]) cube([1, 1, 4.80993376060451]);

translate([21, 11, 0]) cube([1, 1, 4.807942820124964]);

translate([22, 11, 0]) cube([1, 1, 5.200002361608147]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 8.2]);

translate([1, 12, 0]) cube([1, 1, 7.7]);

translate([2, 12, 0]) cube([1, 1, 7.3]);

translate([3, 12, 0]) cube([1, 1, 7.2]);

translate([4, 12, 0]) cube([1, 1, 7.3]);

translate([5, 12, 0]) cube([1, 1, 7.4]);

translate([6, 12, 0]) cube([1, 1, 7.5]);

translate([7, 12, 0]) cube([1, 1, 7.2]);

translate([8, 12, 0]) cube([1, 1, 6.9]);

translate([9, 12, 0]) cube([1, 1, 6.600991963269832]);

translate([10, 12, 0]) cube([1, 1, 6.601376597507705]);

translate([11, 12, 0]) cube([1, 1, 6.602961040303589]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

translate([17, 12, 0]) cube([1, 1, 5.323114612914392]);

translate([18, 12, 0]) cube([1, 1, 5.119234878116364]);

translate([19, 12, 0]) cube([1, 1, 5.014281177597016]);

translate([20, 12, 0]) cube([1, 1, 4.9121928715725796]);

translate([21, 12, 0]) cube([1, 1, 5.001687262286311]);

translate([22, 12, 0]) cube([1, 1, 5.300011814272103]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 8.1]);

translate([1, 13, 0]) cube([1, 1, 7.7]);

translate([2, 13, 0]) cube([1, 1, 7.5]);

translate([3, 13, 0]) cube([1, 1, 7.5]);

translate([4, 13, 0]) cube([1, 1, 7.6]);

translate([5, 13, 0]) cube([1, 1, 7.6]);

translate([6, 13, 0]) cube([1, 1, 7.6]);

translate([7, 13, 0]) cube([1, 1, 7.3]);

translate([8, 13, 0]) cube([1, 1, 7.0]);

translate([9, 13, 0]) cube([1, 1, 6.800593400940622]);

translate([10, 13, 0]) cube([1, 1, 6.801780202821869]);

translate([11, 13, 0]) cube([1, 1, 6.801568273914504]);

translate([12, 13, 0]) cube([1, 1, 6.613623523777527]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

translate([18, 13, 0]) cube([1, 1, 5.417525701578353]);

translate([19, 13, 0]) cube([1, 1, 5.308281994861691]);

translate([20, 13, 0]) cube([1, 1, 5.203944503862787]);

translate([21, 13, 0]) cube([1, 1, 5.202731296934856]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 13, 0]) cube([1, 1, 6]);

translate([27, 13, 0]) cube([1, 1, 6.6]);

translate([28, 13, 0]) cube([1, 1, 6.7]);

translate([29, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([30, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 8.2]);

translate([1, 14, 0]) cube([1, 1, 7.8]);

translate([2, 14, 0]) cube([1, 1, 7.7]);

translate([3, 14, 0]) cube([1, 1, 7.6]);

translate([4, 14, 0]) cube([1, 1, 7.6]);

translate([5, 14, 0]) cube([1, 1, 7.5]);

translate([6, 14, 0]) cube([1, 1, 7.4]);

translate([7, 14, 0]) cube([1, 1, 7.2]);

translate([8, 14, 0]) cube([1, 1, 7.0]);

translate([9, 14, 0]) cube([1, 1, 7.0]);

translate([10, 14, 0]) cube([1, 1, 7.0]);

translate([11, 14, 0]) cube([1, 1, 6.809155328798186]);

translate([12, 14, 0]) cube([1, 1, 6.630894083162365]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

translate([14, 14, 0]) cube([1, 1, 6.532968324791853]);

translate([15, 14, 0]) cube([1, 1, 6.524443386840422]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 14, 0]) cube([1, 1, 6]);

translate([27, 14, 0]) cube([1, 1, 6.9]);

translate([28, 14, 0]) cube([1, 1, 7.0]);

translate([29, 14, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([30, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 8.1]);

translate([1, 15, 0]) cube([1, 1, 7.8]);

translate([2, 15, 0]) cube([1, 1, 7.7]);

translate([3, 15, 0]) cube([1, 1, 7.5]);

translate([4, 15, 0]) cube([1, 1, 7.3]);

translate([5, 15, 0]) cube([1, 1, 7.1]);

translate([6, 15, 0]) cube([1, 1, 6.904]);

translate([7, 15, 0]) cube([1, 1, 6.820799999999999]);

translate([8, 15, 0]) cube([1, 1, 6.587520159809958]);

translate([9, 15, 0]) cube([1, 1, 6.600099375067488]);

translate([10, 15, 0]) cube([1, 1, 6.508304988662132]);

color([0,1,0])
translate([11, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 15, 0]) cube([1, 1, 6]);

translate([27, 15, 0]) cube([1, 1, 6.8]);

translate([28, 15, 0]) cube([1, 1, 6.9]);

translate([29, 15, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([30, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 15, 0]) cube([1, 1, 6]);

translate([0, 16, 0]) cube([1, 1, 7.7]);

translate([1, 16, 0]) cube([1, 1, 7.4]);

translate([2, 16, 0]) cube([1, 1, 7.3]);

translate([3, 16, 0]) cube([1, 1, 7.2]);

translate([4, 16, 0]) cube([1, 1, 7.0]);

translate([5, 16, 0]) cube([1, 1, 6.7008]);

translate([6, 16, 0]) cube([1, 1, 6.515726170567434]);

translate([7, 16, 0]) cube([1, 1, 6.544733253698304]);

translate([8, 16, 0]) cube([1, 1, 6.643121165370909]);

translate([9, 16, 0]) cube([1, 1, 6.746680130385488]);

translate([10, 16, 0]) cube([1, 1, 6.823257511337868]);

translate([11, 16, 0]) cube([1, 1, 6.635211376511216]);

translate([12, 16, 0]) cube([1, 1, 6.539433089382765]);

translate([13, 16, 0]) cube([1, 1, 6.502996229657933]);

translate([14, 16, 0]) cube([1, 1, 6.534911592060146]);

translate([15, 16, 0]) cube([1, 1, 6.600706733696565]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 16, 0]) cube([1, 1, 6]);

translate([28, 16, 0]) cube([1, 1, 6.7]);

translate([29, 16, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([30, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 16, 0]) cube([1, 1, 6]);

translate([0, 17, 0]) cube([1, 1, 7.1]);

translate([1, 17, 0]) cube([1, 1, 6.9]);

translate([2, 17, 0]) cube([1, 1, 6.9]);

translate([3, 17, 0]) cube([1, 1, 6.9]);

translate([4, 17, 0]) cube([1, 1, 6.70016]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

translate([10, 17, 0]) cube([1, 1, 6.523062623191127]);

translate([11, 17, 0]) cube([1, 1, 6.610164097721058]);

translate([12, 17, 0]) cube([1, 1, 6.5357761102043765]);

translate([13, 17, 0]) cube([1, 1, 6.606217771059041]);

translate([14, 17, 0]) cube([1, 1, 6.604729150919627]);

translate([15, 17, 0]) cube([1, 1, 6.6009022331926595]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

translate([19, 17, 0]) cube([1, 1, 5.414734834927964]);

translate([20, 17, 0]) cube([1, 1, 5.409179883929291]);

translate([21, 17, 0]) cube([1, 1, 5.403627027009107]);

color([0,1,0])
translate([22, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 17, 0]) cube([1, 1, 6]);

translate([0, 18, 0]) cube([1, 1, 6.8]);

translate([1, 18, 0]) cube([1, 1, 6.6]);

translate([2, 18, 0]) cube([1, 1, 6.6]);

translate([3, 18, 0]) cube([1, 1, 6.500032]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

translate([12, 18, 0]) cube([1, 1, 6.602750408637462]);

translate([13, 18, 0]) cube([1, 1, 6.8]);

translate([14, 18, 0]) cube([1, 1, 6.9]);

translate([15, 18, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

translate([19, 18, 0]) cube([1, 1, 5.411607785434716]);

translate([20, 18, 0]) cube([1, 1, 5.221195078095967]);

translate([21, 18, 0]) cube([1, 1, 5.221198901167486]);

translate([22, 18, 0]) cube([1, 1, 5.300906755843962]);

color([0,1,0])
translate([23, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 6.8]);

translate([1, 19, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

translate([7, 19, 0]) cube([1, 1, 5.426416569205539]);

translate([8, 19, 0]) cube([1, 1, 5.431354790147014]);

color([0,1,0])
translate([9, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

translate([13, 19, 0]) cube([1, 1, 6.9]);

translate([14, 19, 0]) cube([1, 1, 7.1]);

translate([15, 19, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([16, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);

translate([20, 19, 0]) cube([1, 1, 5.402507861999285]);

translate([21, 19, 0]) cube([1, 1, 5.221355550595445]);

translate([22, 19, 0]) cube([1, 1, 5.300362627682202]);

color([0,1,0])
translate([23, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 19, 0]) cube([1, 1, 6]);

translate([0, 20, 0]) cube([1, 1, 7.0]);

translate([1, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([2, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

translate([6, 20, 0]) cube([1, 1, 5.40938977418143]);

translate([7, 20, 0]) cube([1, 1, 5.3127328709353705]);

translate([8, 20, 0]) cube([1, 1, 5.4263889871123]);

color([0,1,0])
translate([9, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

translate([13, 20, 0]) cube([1, 1, 6.8]);

translate([14, 20, 0]) cube([1, 1, 7.0]);

translate([15, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

translate([21, 20, 0]) cube([1, 1, 5.300541777082459]);

translate([22, 20, 0]) cube([1, 1, 5.300303430486272]);

translate([23, 20, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([24, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 20, 0]) cube([1, 1, 6]);

translate([31, 20, 0]) cube([1, 1, 5.3]);

translate([0, 21, 0]) cube([1, 1, 7.1]);

translate([1, 21, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

translate([4, 21, 0]) cube([1, 1, 5.400781089670339]);

translate([5, 21, 0]) cube([1, 1, 5.306502771825041]);

translate([6, 21, 0]) cube([1, 1, 5.308902654627552]);

translate([7, 21, 0]) cube([1, 1, 5.410075340279353]);

color([0,1,0])
translate([8, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

translate([13, 21, 0]) cube([1, 1, 6.7]);

translate([14, 21, 0]) cube([1, 1, 6.9]);

translate([15, 21, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

translate([22, 21, 0]) cube([1, 1, 5.300339156456286]);

translate([23, 21, 0]) cube([1, 1, 5.30029888204619]);

translate([24, 21, 0]) cube([1, 1, 5.300151109922738]);

translate([25, 21, 0]) cube([1, 1, 5.300150950352403]);

color([0,1,0])
translate([26, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 21, 0]) cube([1, 1, 6]);

translate([30, 21, 0]) cube([1, 1, 5.4]);

translate([31, 21, 0]) cube([1, 1, 5.1]);

translate([0, 22, 0]) cube([1, 1, 7.1]);

translate([1, 22, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

translate([4, 22, 0]) cube([1, 1, 5.211837343899697]);

translate([5, 22, 0]) cube([1, 1, 5.21188115135492]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

translate([13, 22, 0]) cube([1, 1, 6.7]);

translate([14, 22, 0]) cube([1, 1, 6.8]);

translate([15, 22, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

translate([24, 22, 0]) cube([1, 1, 5.400000415143721]);

translate([25, 22, 0]) cube([1, 1, 5.400000136673297]);

color([0,1,0])
translate([26, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 22, 0]) cube([1, 1, 6]);

translate([30, 22, 0]) cube([1, 1, 5.2]);

translate([31, 22, 0]) cube([1, 1, 4.9]);

translate([0, 23, 0]) cube([1, 1, 6.9]);

translate([1, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 23, 0]) cube([1, 1, 6]);

translate([4, 23, 0]) cube([1, 1, 5.400014626930591]);

color([0,1,0])
translate([5, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 23, 0]) cube([1, 1, 6]);

translate([12, 23, 0]) cube([1, 1, 6.7]);

translate([13, 23, 0]) cube([1, 1, 6.9]);

translate([14, 23, 0]) cube([1, 1, 7.0]);

translate([15, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([16, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 23, 0]) cube([1, 1, 6]);

translate([29, 23, 0]) cube([1, 1, 5.3]);

translate([30, 23, 0]) cube([1, 1, 5.0]);

translate([31, 23, 0]) cube([1, 1, 4.8]);

translate([0, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 24, 0]) cube([1, 1, 6]);

translate([11, 24, 0]) cube([1, 1, 6.7]);

translate([12, 24, 0]) cube([1, 1, 7.0]);

translate([13, 24, 0]) cube([1, 1, 7.1]);

translate([14, 24, 0]) cube([1, 1, 7.1]);

translate([15, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 24, 0]) cube([1, 1, 6]);

translate([27, 24, 0]) cube([1, 1, 5.4]);

translate([28, 24, 0]) cube([1, 1, 5.3]);

translate([29, 24, 0]) cube([1, 1, 5.0]);

translate([30, 24, 0]) cube([1, 1, 4.8]);

translate([31, 24, 0]) cube([1, 1, 4.6]);

color([0,1,0])
translate([0, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 25, 0]) cube([1, 1, 6]);

translate([11, 25, 0]) cube([1, 1, 6.9]);

translate([12, 25, 0]) cube([1, 1, 7.2]);

translate([13, 25, 0]) cube([1, 1, 7.2]);

translate([14, 25, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([15, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 25, 0]) cube([1, 1, 6]);

translate([25, 25, 0]) cube([1, 1, 5.4]);

translate([26, 25, 0]) cube([1, 1, 5.4]);

translate([27, 25, 0]) cube([1, 1, 5.4]);

translate([28, 25, 0]) cube([1, 1, 5.2]);

translate([29, 25, 0]) cube([1, 1, 5.0]);

translate([30, 25, 0]) cube([1, 1, 4.7]);

translate([31, 25, 0]) cube([1, 1, 4.5]);

color([0,1,0])
translate([0, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 26, 0]) cube([1, 1, 6]);

translate([10, 26, 0]) cube([1, 1, 6.7]);

translate([11, 26, 0]) cube([1, 1, 6.9]);

translate([12, 26, 0]) cube([1, 1, 7.0]);

translate([13, 26, 0]) cube([1, 1, 6.9]);

translate([14, 26, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([15, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 26, 0]) cube([1, 1, 6]);

translate([25, 26, 0]) cube([1, 1, 5.4]);

translate([26, 26, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([27, 26, 0]) cube([1, 1, 6]);

translate([28, 26, 0]) cube([1, 1, 5.4]);

translate([29, 26, 0]) cube([1, 1, 5.3]);

translate([30, 26, 0]) cube([1, 1, 5.0]);

translate([31, 26, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 27, 0]) cube([1, 1, 6]);

translate([9, 27, 0]) cube([1, 1, 6.6]);

translate([10, 27, 0]) cube([1, 1, 6.7]);

translate([11, 27, 0]) cube([1, 1, 6.7]);

translate([12, 27, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([13, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 27, 0]) cube([1, 1, 6]);

translate([31, 27, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([0, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 28, 0]) cube([1, 1, 6]);

translate([27, 28, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 29, 0]) cube([1, 1, 6]);

translate([26, 29, 0]) cube([1, 1, 5.4]);

translate([27, 29, 0]) cube([1, 1, 5.3]);

translate([28, 29, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([29, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 30, 0]) cube([1, 1, 6]);

translate([1, 30, 0]) cube([1, 1, 5.4]);

translate([2, 30, 0]) cube([1, 1, 5.4]);

translate([3, 30, 0]) cube([1, 1, 5.4]);

translate([4, 30, 0]) cube([1, 1, 5.3]);

translate([5, 30, 0]) cube([1, 1, 5.2]);

translate([6, 30, 0]) cube([1, 1, 5.1]);

translate([7, 30, 0]) cube([1, 1, 5.3]);

translate([8, 30, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([9, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 30, 0]) cube([1, 1, 6]);

translate([11, 30, 0]) cube([1, 1, 5.3]);

translate([12, 30, 0]) cube([1, 1, 5.2]);

translate([13, 30, 0]) cube([1, 1, 5.3]);

translate([14, 30, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([15, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 30, 0]) cube([1, 1, 6]);

translate([22, 30, 0]) cube([1, 1, 5.3]);

translate([23, 30, 0]) cube([1, 1, 5.3]);

translate([24, 30, 0]) cube([1, 1, 5.4]);

translate([25, 30, 0]) cube([1, 1, 5.4]);

translate([26, 30, 0]) cube([1, 1, 5.3]);

translate([27, 30, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([28, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 30, 0]) cube([1, 1, 6]);

translate([0, 31, 0]) cube([1, 1, 5.3]);

translate([1, 31, 0]) cube([1, 1, 5.2]);

translate([2, 31, 0]) cube([1, 1, 5.2]);

translate([3, 31, 0]) cube([1, 1, 5.3]);

translate([4, 31, 0]) cube([1, 1, 5.2]);

translate([5, 31, 0]) cube([1, 1, 5.0]);

translate([6, 31, 0]) cube([1, 1, 4.9]);

translate([7, 31, 0]) cube([1, 1, 5.0]);

translate([8, 31, 0]) cube([1, 1, 5.1]);

translate([9, 31, 0]) cube([1, 1, 5.1]);

translate([10, 31, 0]) cube([1, 1, 5.0]);

translate([11, 31, 0]) cube([1, 1, 4.8]);

translate([12, 31, 0]) cube([1, 1, 4.7]);

translate([13, 31, 0]) cube([1, 1, 4.8]);

translate([14, 31, 0]) cube([1, 1, 5.1]);

translate([15, 31, 0]) cube([1, 1, 5.3]);

translate([16, 31, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([17, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 31, 0]) cube([1, 1, 6]);

translate([22, 31, 0]) cube([1, 1, 5.2]);

translate([23, 31, 0]) cube([1, 1, 5.1]);

translate([24, 31, 0]) cube([1, 1, 5.2]);

translate([25, 31, 0]) cube([1, 1, 5.2]);

translate([26, 31, 0]) cube([1, 1, 5.3]);

translate([27, 31, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 31, 0]) cube([1, 1, 6]);
