
hull() {
    translate([5.04265, 0.0897, 4.9861]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.81035, 0.15630000000000002, 4.735900000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.894399999999999, 0.17110000000000003, 4.708100000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.6396, 0.3709, 4.4579]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.7198, 0.4002, 4.43015]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.4182, 0.7278, 4.1808499999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.49205, 0.7705, 4.153099999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.12295, 1.2115, 3.9029]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.1883, 1.2663000000000002, 3.8750999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.733699999999999, 1.8117, 3.6249000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.788499999999999, 1.87705, 3.5971]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.2295, 2.5079500000000006, 3.3469]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.2722, 2.5818000000000003, 3.3191500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.5998, 3.2802, 3.0698499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.6291, 3.3604, 3.0421]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.828899999999999, 4.105600000000001, 2.7919]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.8437, 4.18965, 2.7641]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.9103, 4.95735, 2.5139]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.9103, 5.04265, 2.4861]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.8437, 5.81035, 2.2359]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.828899999999999, 5.894399999999999, 2.2081]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.6291, 6.6396, 1.9579]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.5998, 6.7198, 1.93015]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.2722, 7.4182, 1.68085]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.2295, 7.49205, 1.6531]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.788499999999999, 8.12295, 1.4029]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.733699999999999, 8.1883, 1.3751]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.1883, 8.733699999999999, 1.1249]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.12295, 8.788499999999999, 1.0971]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.49205, 9.2295, 0.8469]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.4182, 9.2722, 0.81915]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.7198, 9.5998, 0.5698500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.6396, 9.6291, 0.5421]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.894399999999999, 9.828899999999999, 0.29190000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.81035, 9.8437, 0.26410000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.04265, 9.9103, 0.013900000000000003]) cube([0.4, 0.4, 0.1], center=true);
}

