
hull() {
    translate([0.045000000000000005, 0.0, 4.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.8550000000000001, 0.0, 4.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9450000000000001, 0.0, 4.8325000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7550000000000001, 0.0, 4.5175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8450000000000002, 0.0, 4.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6550000000000002, 0.0, 4.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.745, 0.0, 3.9675000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.555, 0.0, 3.3825000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6450000000000005, 0.0, 3.3075]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.455, 0.0, 2.5425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.545, 0.0, 2.45]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.355, 0.0, 1.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.445, 0.0, 1.4500000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.255, 0.0, 0.55]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.345, 0.0, 0.47500000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.155, 0.0, 0.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.2, 0.09000000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.2, 1.7100000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.2, 1.8900000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.2, 3.5100000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.2, 3.6900000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.2, 5.3100000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.19, 5.4, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.01, 5.4, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.99, 5.4, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.8100000000000005, 5.4, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.79, 5.4, 0.010000000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.609999999999999, 5.4, 0.19000000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.59, 5.4, 0.21000000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.410000000000001, 5.4, 0.39000000000000007]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.390000000000001, 5.4, 0.41000000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.21, 5.4, 0.5900000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.19, 5.4, 0.61]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.010000000000001, 5.4, 0.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.99, 5.4, 0.81]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.81, 5.4, 0.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.79, 5.4, 1.01]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.61, 5.4, 1.1900000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.59, 5.4, 1.21]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.41, 5.4, 1.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.390000000000001, 5.4, 1.4100000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.210000000000001, 5.4, 1.5900000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.19, 5.4, 1.6100000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.01, 5.4, 1.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.99, 5.4, 1.81]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.8100000000000005, 5.4, 1.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.79, 5.4, 2.0100000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.609999999999999, 5.4, 2.1900000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.59, 5.4, 2.21]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.41, 5.4, 2.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.390000000000001, 5.4, 2.41]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.21, 5.4, 2.5900000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.19, 5.4, 2.6100000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.01, 5.4, 2.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.99, 5.4, 2.81]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.81, 5.4, 2.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.79, 5.4, 3.0100000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6100000000000003, 5.4, 3.1900000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.5900000000000003, 5.4, 3.2100000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.41, 5.4, 3.39]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.39, 5.4, 3.41]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.2100000000000004, 5.4, 3.5900000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.1900000000000004, 5.4, 3.6100000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.0100000000000002, 5.4, 3.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.99, 5.4, 3.81]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.81, 5.4, 3.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.79, 5.4, 4.01]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6100000000000003, 5.4, 4.19]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.5900000000000003, 5.4, 4.21]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.41, 5.4, 4.390000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.39, 5.4, 4.41]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.21, 5.4, 4.59]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1900000000000004, 5.4, 4.609999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.0100000000000002, 5.4, 4.79]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.99, 5.4, 4.8100000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.81, 5.4, 4.99]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.79, 5.4, 4.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6100000000000003, 5.4, 4.8100000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5900000000000003, 5.4, 4.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.4100000000000001, 5.4, 4.609999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.39, 5.4, 4.59]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.21, 5.4, 4.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1900000000000002, 5.4, 4.390000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.01, 5.4, 4.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.99, 5.4, 4.19]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.81, 5.4, 4.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.79, 5.4, 3.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.61, 5.4, 3.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.5900000000000001, 5.4, 3.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.41000000000000003, 5.4, 3.6100000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.39000000000000007, 5.4, 3.5900000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.21000000000000002, 5.4, 3.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.19000000000000003, 5.4, 3.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.010000000000000002, 5.4, 3.2100000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 5.390000000000001, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 5.210000000000001, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 5.19, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 5.01, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 4.99, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 4.8100000000000005, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 4.79, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 4.609999999999999, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 4.59, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 4.41, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 4.390000000000001, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 4.21, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 4.19, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 4.01, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.99, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.81, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.79, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.6100000000000003, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.5900000000000003, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.41, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.39, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.2100000000000004, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.1900000000000004, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.0100000000000002, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.99, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.81, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.79, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.6100000000000003, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.5900000000000003, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.41, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.39, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.21, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.1900000000000004, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.0100000000000002, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 1.99, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 1.81, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 1.79, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 1.6100000000000003, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 1.5900000000000003, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 1.4100000000000001, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 1.39, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 1.21, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 1.1900000000000002, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 1.01, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 0.99, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.81, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 0.79, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.61, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 0.5900000000000001, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.41000000000000003, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 0.39000000000000007, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.21000000000000002, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 0.19000000000000003, 3.2]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.010000000000000002, 3.2]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.045000000000000005, 0.0, 3.1900000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.8550000000000001, 0.0, 3.0100000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9450000000000001, 0.0, 2.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7550000000000001, 0.0, 2.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8450000000000002, 0.0, 2.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6550000000000002, 0.0, 2.6100000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.745, 0.0, 2.5900000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.555, 0.0, 2.41]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6450000000000005, 0.0, 2.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.455, 0.0, 2.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.545, 0.0, 2.1900000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.355, 0.0, 2.0100000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.445, 0.0, 1.99]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.255, 0.0, 1.81]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.345, 0.0, 1.79]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.155, 0.0, 1.6100000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.245000000000001, 0.0, 1.5900000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.055, 0.0, 1.4100000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.145, 0.0, 1.39]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.955, 0.0, 1.21]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.045, 0.0, 1.1900000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.855, 0.0, 1.01]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.905, 0.0, 1.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.995, 0.0, 1.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 0.045000000000000005, 0.995]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 0.8550000000000001, 0.905]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 0.9450000000000001, 0.895]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 1.7550000000000001, 0.8050000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 1.8450000000000002, 0.7950000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 2.6550000000000002, 0.7050000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 2.745, 0.695]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 3.555, 0.605]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 3.6450000000000005, 0.5950000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 4.455, 0.505]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 4.545, 0.495]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 5.355, 0.405]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 5.445, 0.395]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 6.255, 0.305]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 6.345, 0.29500000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 7.155, 0.20500000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 7.245000000000001, 0.19500000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 8.055, 0.10500000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 8.145, 0.09500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 8.955, 0.005000000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 9.045, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 9.855, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.0, 9.905, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.0, 9.995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}

