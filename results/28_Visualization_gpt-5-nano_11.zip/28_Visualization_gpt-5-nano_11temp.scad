
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.3]);

translate([2, 0, 0]) cube([1, 1, 4.1]);

translate([3, 0, 0]) cube([1, 1, 3.9]);

translate([4, 0, 0]) cube([1, 1, 3.9]);

translate([5, 0, 0]) cube([1, 1, 4.2]);

translate([6, 0, 0]) cube([1, 1, 4.5]);

translate([7, 0, 0]) cube([1, 1, 4.3]);

translate([8, 0, 0]) cube([1, 1, 4.2]);

translate([9, 0, 0]) cube([1, 1, 4.6]);

translate([10, 0, 0]) cube([1, 1, 5.0]);

translate([11, 0, 0]) cube([1, 1, 5.3]);

translate([12, 0, 0]) cube([1, 1, 5.4]);

translate([13, 0, 0]) cube([1, 1, 5.3]);

translate([14, 0, 0]) cube([1, 1, 4.8]);

translate([15, 0, 0]) cube([1, 1, 4.4]);

translate([16, 0, 0]) cube([1, 1, 4.3]);

translate([17, 0, 0]) cube([1, 1, 4.3]);

translate([18, 0, 0]) cube([1, 1, 4.6]);

translate([19, 0, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.3]);

translate([2, 1, 0]) cube([1, 1, 4.8]);

translate([3, 1, 0]) cube([1, 1, 4.3]);

translate([4, 1, 0]) cube([1, 1, 4.2]);

translate([5, 1, 0]) cube([1, 1, 4.2]);

translate([6, 1, 0]) cube([1, 1, 4.100000264550264]);

translate([7, 1, 0]) cube([1, 1, 3.800411611366906]);

translate([8, 1, 0]) cube([1, 1, 3.8004124958647623]);

translate([9, 1, 0]) cube([1, 1, 4.000547125907506]);

translate([10, 1, 0]) cube([1, 1, 4.3003346773738]);

translate([11, 1, 0]) cube([1, 1, 4.5]);

translate([12, 1, 0]) cube([1, 1, 4.6]);

translate([13, 1, 0]) cube([1, 1, 4.5]);

translate([14, 1, 0]) cube([1, 1, 4.3]);

translate([15, 1, 0]) cube([1, 1, 4.1]);

translate([16, 1, 0]) cube([1, 1, 3.8]);

translate([17, 1, 0]) cube([1, 1, 3.509256869435368]);

translate([18, 1, 0]) cube([1, 1, 3.8]);

translate([19, 1, 0]) cube([1, 1, 4.0]);

translate([0, 2, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.2]);

translate([4, 2, 0]) cube([1, 1, 5.1]);

translate([5, 2, 0]) cube([1, 1, 4.8]);

translate([6, 2, 0]) cube([1, 1, 4.2]);

translate([7, 2, 0]) cube([1, 1, 4.100000529100528]);

translate([8, 2, 0]) cube([1, 1, 4.400002116402117]);

translate([9, 2, 0]) cube([1, 1, 4.300271430855784]);

translate([10, 2, 0]) cube([1, 1, 4.400486029184231]);

translate([11, 2, 0]) cube([1, 1, 4.400484080677095]);

translate([12, 2, 0]) cube([1, 1, 4.200601313082296]);

translate([13, 2, 0]) cube([1, 1, 4.100120262130242]);

translate([14, 2, 0]) cube([1, 1, 3.7062320634456407]);

translate([15, 2, 0]) cube([1, 1, 3.6066095540455647]);

translate([16, 2, 0]) cube([1, 1, 3.527286923766623]);

translate([17, 2, 0]) cube([1, 1, 3.3820634603674513]);

translate([18, 2, 0]) cube([1, 1, 3.5027688438852063]);

translate([19, 2, 0]) cube([1, 1, 3.7]);

translate([0, 3, 0]) cube([1, 1, 7.4]);

translate([1, 3, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.2]);

translate([6, 3, 0]) cube([1, 1, 4.7]);

translate([7, 3, 0]) cube([1, 1, 4.8]);

translate([8, 3, 0]) cube([1, 1, 5.2]);

translate([9, 3, 0]) cube([1, 1, 5.100012698412698]);

translate([10, 3, 0]) cube([1, 1, 5.000012698412698]);

translate([11, 3, 0]) cube([1, 1, 4.7019211760063895]);

translate([12, 3, 0]) cube([1, 1, 4.034474026032629]);

translate([13, 3, 0]) cube([1, 1, 3.8248079963651214]);

translate([14, 3, 0]) cube([1, 1, 3.6195630071597216]);

translate([15, 3, 0]) cube([1, 1, 3.580088179669166]);

translate([16, 3, 0]) cube([1, 1, 3.5332854708677317]);

translate([17, 3, 0]) cube([1, 1, 3.382225866143487]);

translate([18, 3, 0]) cube([1, 1, 3.405481205781079]);

translate([19, 3, 0]) cube([1, 1, 3.60230219798264]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.2]);

translate([2, 4, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.3]);

translate([7, 4, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([8, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 4, 0]) cube([1, 1, 6]);

translate([10, 4, 0]) cube([1, 1, 5.300063492063492]);

translate([11, 4, 0]) cube([1, 1, 4.71145086714328]);

translate([12, 4, 0]) cube([1, 1, 4.08884438211703]);

translate([13, 4, 0]) cube([1, 1, 3.7773571463814286]);

translate([14, 4, 0]) cube([1, 1, 3.738181170525518]);

translate([15, 4, 0]) cube([1, 1, 3.731468448510282]);

translate([16, 4, 0]) cube([1, 1, 3.909524796957503]);

translate([17, 4, 0]) cube([1, 1, 4.104465984959916]);

translate([18, 4, 0]) cube([1, 1, 4.00339678780727]);

translate([19, 4, 0]) cube([1, 1, 3.9035098065978757]);

translate([0, 5, 0]) cube([1, 1, 7.9]);

translate([1, 5, 0]) cube([1, 1, 7.4]);

translate([2, 5, 0]) cube([1, 1, 7.0]);

translate([3, 5, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 5, 0]) cube([1, 1, 6]);

translate([10, 5, 0]) cube([1, 1, 5.400380952380953]);

translate([11, 5, 0]) cube([1, 1, 4.856797193803318]);

translate([12, 5, 0]) cube([1, 1, 4.530467557173587]);

translate([13, 5, 0]) cube([1, 1, 4.160829066373829]);

translate([14, 5, 0]) cube([1, 1, 4.467445809810069]);

translate([15, 5, 0]) cube([1, 1, 4.6204366116886435]);

translate([16, 5, 0]) cube([1, 1, 4.617336066144391]);

translate([17, 5, 0]) cube([1, 1, 4.7053853229869755]);

translate([18, 5, 0]) cube([1, 1, 4.504074520628136]);

translate([19, 5, 0]) cube([1, 1, 4.503058111623829]);

translate([0, 6, 0]) cube([1, 1, 7.9]);

translate([1, 6, 0]) cube([1, 1, 7.2]);

translate([2, 6, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 6, 0]) cube([1, 1, 6]);

translate([4, 6, 0]) cube([1, 1, 6.8]);

translate([5, 6, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 6, 0]) cube([1, 1, 6]);

translate([11, 6, 0]) cube([1, 1, 5.069849337992604]);

translate([12, 6, 0]) cube([1, 1, 4.954990232789275]);

translate([13, 6, 0]) cube([1, 1, 4.828782597868704]);

translate([14, 6, 0]) cube([1, 1, 5.155541738649659]);

translate([15, 6, 0]) cube([1, 1, 5.432468101889958]);

translate([16, 6, 0]) cube([1, 1, 5.318363329319378]);

translate([17, 6, 0]) cube([1, 1, 5.108937399705509]);

translate([18, 6, 0]) cube([1, 1, 4.905011208896964]);

translate([19, 6, 0]) cube([1, 1, 5.2005636390358605]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.4]);

translate([2, 7, 0]) cube([1, 1, 6.9]);

translate([3, 7, 0]) cube([1, 1, 7.1]);

translate([4, 7, 0]) cube([1, 1, 7.2]);

translate([5, 7, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

translate([11, 7, 0]) cube([1, 1, 5.144252713142903]);

translate([12, 7, 0]) cube([1, 1, 5.13119529268758]);

translate([13, 7, 0]) cube([1, 1, 5.1296538205334405]);

color([0,1,0])
translate([14, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 8.1]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 7.4]);

translate([3, 8, 0]) cube([1, 1, 7.6]);

translate([4, 8, 0]) cube([1, 1, 7.5]);

translate([5, 8, 0]) cube([1, 1, 7.0]);

translate([6, 8, 0]) cube([1, 1, 6.8]);

translate([7, 8, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

translate([11, 8, 0]) cube([1, 1, 5.452710218160872]);

translate([12, 8, 0]) cube([1, 1, 5.447172305724797]);

translate([13, 8, 0]) cube([1, 1, 4.861285585704117]);

translate([14, 8, 0]) cube([1, 1, 5.045622045953671]);

translate([15, 8, 0]) cube([1, 1, 5.2370800675968665]);

color([0,1,0])
translate([16, 8, 0]) cube([1, 1, 6]);

translate([17, 8, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([18, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 8.1]);

translate([1, 9, 0]) cube([1, 1, 7.8]);

translate([2, 9, 0]) cube([1, 1, 7.6]);

translate([3, 9, 0]) cube([1, 1, 7.4]);

translate([4, 9, 0]) cube([1, 1, 7.1]);

translate([5, 9, 0]) cube([1, 1, 7.0]);

translate([6, 9, 0]) cube([1, 1, 7.0]);

translate([7, 9, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

translate([12, 9, 0]) cube([1, 1, 4.6960126161705205]);

translate([13, 9, 0]) cube([1, 1, 4.834887766007863]);

translate([14, 9, 0]) cube([1, 1, 5.996462427563618]);

translate([15, 9, 0]) cube([1, 1, 5.241425566726052]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 6.9]);

translate([18, 9, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.7]);

translate([1, 10, 0]) cube([1, 1, 7.3]);

translate([2, 10, 0]) cube([1, 1, 7.2]);

translate([3, 10, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([4, 10, 0]) cube([1, 1, 6]);

translate([5, 10, 0]) cube([1, 1, 6.6]);

translate([6, 10, 0]) cube([1, 1, 6.8]);

translate([7, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

translate([9, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

translate([13, 10, 0]) cube([1, 1, 4.776408324547102]);

translate([14, 10, 0]) cube([1, 1, 4.976806899155107]);

translate([15, 10, 0]) cube([1, 1, 5.158186602012115]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 6.6]);

translate([18, 10, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 6.9]);

translate([1, 11, 0]) cube([1, 1, 6.7]);

translate([2, 11, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 11, 0]) cube([1, 1, 6]);

translate([8, 11, 0]) cube([1, 1, 6.7]);

translate([9, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([1, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 12, 0]) cube([1, 1, 6]);

translate([4, 12, 0]) cube([1, 1, 5.4]);

translate([5, 12, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([6, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 12, 0]) cube([1, 1, 6]);

translate([8, 12, 0]) cube([1, 1, 6.8]);

translate([9, 12, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 7.1]);

translate([1, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 13, 0]) cube([1, 1, 6]);

translate([3, 13, 0]) cube([1, 1, 5.4]);

translate([4, 13, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([5, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

translate([8, 13, 0]) cube([1, 1, 6.6]);

translate([9, 13, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

translate([19, 13, 0]) cube([1, 1, 5.307274496786001]);

translate([0, 14, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

translate([2, 14, 0]) cube([1, 1, 5.4]);

translate([3, 14, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

translate([8, 14, 0]) cube([1, 1, 6.7]);

translate([9, 14, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

translate([19, 14, 0]) cube([1, 1, 5.01070373536733]);

translate([0, 15, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 15, 0]) cube([1, 1, 6]);

translate([7, 15, 0]) cube([1, 1, 6.8]);

translate([8, 15, 0]) cube([1, 1, 7.1]);

translate([9, 15, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

translate([17, 15, 0]) cube([1, 1, 5.412301311812733]);

translate([18, 15, 0]) cube([1, 1, 5.108376634171058]);

translate([19, 15, 0]) cube([1, 1, 4.7206970210407615]);

color([0,1,0])
translate([0, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 16, 0]) cube([1, 1, 6]);

translate([7, 16, 0]) cube([1, 1, 7.0]);

translate([8, 16, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([9, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

translate([16, 16, 0]) cube([1, 1, 5.41339412210177]);

translate([17, 16, 0]) cube([1, 1, 5.412065935383828]);

translate([18, 16, 0]) cube([1, 1, 5.20612020533378]);

translate([19, 16, 0]) cube([1, 1, 4.7207255834904]);

color([0,1,0])
translate([0, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

translate([6, 17, 0]) cube([1, 1, 6.7]);

translate([7, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

translate([16, 18, 0]) cube([1, 1, 5.400181722157954]);

translate([17, 18, 0]) cube([1, 1, 5.300525628278982]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 5.4]);

translate([1, 19, 0]) cube([1, 1, 5.3]);

translate([2, 19, 0]) cube([1, 1, 5.3]);

translate([3, 19, 0]) cube([1, 1, 5.1]);

translate([4, 19, 0]) cube([1, 1, 5.0]);

translate([5, 19, 0]) cube([1, 1, 5.3]);

translate([6, 19, 0]) cube([1, 1, 5.3]);

translate([7, 19, 0]) cube([1, 1, 5.0]);

translate([8, 19, 0]) cube([1, 1, 5.0]);

translate([9, 19, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

translate([14, 19, 0]) cube([1, 1, 5.200531492521609]);

translate([15, 19, 0]) cube([1, 1, 5.300380058994878]);

translate([16, 19, 0]) cube([1, 1, 5.300440609877789]);

translate([17, 19, 0]) cube([1, 1, 5.400060573518634]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);
