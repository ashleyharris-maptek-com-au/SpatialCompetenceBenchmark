
hull() {
    translate([17.995549999999998, 10.0596, 18.99625]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.91545, 11.1324, 18.92875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.8977, 11.250300000000001, 18.921200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.6583, 12.299700000000001, 18.852800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.62315, 12.41365, 18.845250000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.22985, 13.41535, 18.777750000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.1781, 13.5228, 18.770200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.6399, 14.455200000000001, 18.701800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.5727, 14.553700000000001, 18.694250000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.901300000000003, 15.394300000000001, 18.62675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.820200000000002, 15.4817, 18.61925]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0318, 16.2143, 18.55175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.938600000000001, 16.28865, 18.544199999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.0494, 16.89435, 18.4758]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.94615, 16.95395, 18.46825]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.97685, 17.42105, 18.40075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.865850000000002, 17.464599999999997, 18.393199999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.837150000000001, 17.7814, 18.3248]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.7209, 17.80795, 18.31725]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.657100000000002, 17.969050000000003, 18.24975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.538200000000002, 17.978, 18.24225]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.4618, 17.978, 18.17475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3429, 17.969050000000003, 18.1672]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.2791, 17.80795, 18.098799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.16285, 17.7814, 18.09125]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.13415, 17.464599999999997, 18.02375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.02315, 17.42105, 18.0162]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.053850000000001, 16.95395, 17.9478]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.9506000000000006, 16.89435, 17.94025]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0614, 16.28865, 17.87275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.9681999999999995, 16.2143, 17.86525]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.1798, 15.4817, 17.79775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.0987, 15.394300000000001, 17.790200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4273000000000002, 14.553700000000001, 17.7218]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3601, 14.455200000000001, 17.71425]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.8219, 13.5228, 17.64675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.77015, 13.41535, 17.6392]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.37685, 12.41365, 17.5708]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3417, 12.299700000000001, 17.56325]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1023, 11.250300000000001, 17.49575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.08455, 11.1324, 17.48825]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.0044500000000003, 10.0596, 17.42075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.0044500000000003, 9.9404, 17.413200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.08455, 8.8676, 17.344800000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1023, 8.7497, 17.33725]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3417, 7.7003, 17.26975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.37685, 7.58635, 17.2622]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.77015, 6.58465, 17.193800000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8219, 6.4772, 17.18625]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.3601, 5.5448, 17.11875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4273000000000002, 5.446300000000001, 17.11125]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.0987, 4.605700000000001, 17.04375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.1798, 4.5183, 17.0362]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.9681999999999995, 3.7857000000000003, 16.9678]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0614, 3.7113500000000004, 16.96025]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.9506000000000006, 3.1056500000000002, 16.89275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.053850000000001, 3.04605, 16.885199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.02315, 2.57895, 16.816799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.13415, 2.5353999999999997, 16.80925]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.16285, 2.2186, 16.74175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.2791, 2.19205, 16.73425]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3429, 2.03095, 16.66675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.4618, 2.022, 16.659200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.538200000000002, 2.022, 16.5908]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.657100000000002, 2.03095, 16.58325]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.7209, 2.19205, 16.51575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.837150000000001, 2.2186, 16.50825]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.865850000000002, 2.5353999999999997, 16.44075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.97685, 2.57895, 16.433200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.94615, 3.04605, 16.364800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.0494, 3.1056500000000002, 16.35725]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.938600000000001, 3.7113500000000004, 16.28975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0318, 3.7857000000000003, 16.2822]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.820200000000002, 4.5183, 16.2138]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.901300000000003, 4.605700000000001, 16.20625]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.5727, 5.446300000000001, 16.13875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.6399, 5.5448, 16.13125]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.1781, 6.4772, 16.06375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.22985, 6.58465, 16.056199999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.62315, 7.58635, 15.9878]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.6583, 7.7003, 15.98025]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.8977, 8.7497, 15.91275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.91545, 8.8676, 15.9052]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.995549999999998, 9.9404, 15.8368]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.995549999999998, 10.0596, 15.829250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.91545, 11.1324, 15.76175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.8977, 11.250300000000001, 15.754249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.6583, 12.299700000000001, 15.68675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.62315, 12.41365, 15.679200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.22985, 13.41535, 15.610800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.1781, 13.5228, 15.603250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.6399, 14.455200000000001, 15.53575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.5727, 14.553700000000001, 15.5282]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.901300000000003, 15.394300000000001, 15.4598]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.820200000000002, 15.4817, 15.45225]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0318, 16.2143, 15.38475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.938600000000001, 16.28865, 15.37725]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.0494, 16.89435, 15.30975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.94615, 16.95395, 15.3022]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.97685, 17.42105, 15.2338]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.865850000000002, 17.464599999999997, 15.22625]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.837150000000001, 17.7814, 15.15875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.7209, 17.80795, 15.1512]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.657100000000002, 17.969050000000003, 15.082800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.538200000000002, 17.978, 15.07525]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.4618, 17.978, 15.007750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3429, 17.969050000000003, 15.000250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.2791, 17.80795, 14.93275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.16285, 17.7814, 14.9252]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.13415, 17.464599999999997, 14.8568]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.02315, 17.42105, 14.84925]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.053850000000001, 16.95395, 14.78175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.9506000000000006, 16.89435, 14.7742]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0614, 16.28865, 14.7058]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.9681999999999995, 16.2143, 14.69825]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.1798, 15.4817, 14.63075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.0987, 15.394300000000001, 14.62325]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4273000000000002, 14.553700000000001, 14.55575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3601, 14.455200000000001, 14.5482]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.8219, 13.5228, 14.479800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.77015, 13.41535, 14.472250000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.37685, 12.41365, 14.40475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3417, 12.299700000000001, 14.397200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1023, 11.250300000000001, 14.328800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.08455, 11.1324, 14.32125]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.0044500000000003, 10.0596, 14.25375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.0044500000000003, 9.9404, 14.246250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.08455, 8.8676, 14.17875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1023, 8.7497, 14.1712]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3417, 7.7003, 14.1028]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.37685, 7.58635, 14.09525]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.77015, 6.58465, 14.02775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8219, 6.4772, 14.020199999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.3601, 5.5448, 13.9518]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4273000000000002, 5.446300000000001, 13.94425]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.0987, 4.605700000000001, 13.87675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.1798, 4.5183, 13.86925]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.9681999999999995, 3.7857000000000003, 13.80175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0614, 3.7113500000000004, 13.7942]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.9506000000000006, 3.1056500000000002, 13.7258]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.053850000000001, 3.04605, 13.718250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.02315, 2.57895, 13.650750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.13415, 2.5353999999999997, 13.6432]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.16285, 2.2186, 13.5748]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.2791, 2.19205, 13.567250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3429, 2.03095, 13.49975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.4618, 2.022, 13.49225]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.538200000000002, 2.022, 13.42475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.657100000000002, 2.03095, 13.4172]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.7209, 2.19205, 13.3488]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.837150000000001, 2.2186, 13.34125]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.865850000000002, 2.5353999999999997, 13.27375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.97685, 2.57895, 13.2662]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.94615, 3.04605, 13.1978]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.0494, 3.1056500000000002, 13.19025]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.938600000000001, 3.7113500000000004, 13.12275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0318, 3.7857000000000003, 13.11525]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.820200000000002, 4.5183, 13.04775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.901300000000003, 4.605700000000001, 13.040200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.5727, 5.446300000000001, 12.971800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.6399, 5.5448, 12.96425]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.1781, 6.4772, 12.89675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.22985, 6.58465, 12.889200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.62315, 7.58635, 12.820800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.6583, 7.7003, 12.813250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.8977, 8.7497, 12.745750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.91545, 8.8676, 12.73825]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.995549999999998, 9.9404, 12.67075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.995549999999998, 10.0596, 12.6632]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.91545, 11.1324, 12.5948]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.8977, 11.250300000000001, 12.58725]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.6583, 12.299700000000001, 12.51975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.62315, 12.41365, 12.5122]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.22985, 13.41535, 12.4438]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.1781, 13.5228, 12.43625]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.6399, 14.455200000000001, 12.36875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.5727, 14.553700000000001, 12.361250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.901300000000003, 15.394300000000001, 12.29375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.820200000000002, 15.4817, 12.286200000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0318, 16.2143, 12.2178]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.938600000000001, 16.28865, 12.210250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.0494, 16.89435, 12.142750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.94615, 16.95395, 12.135200000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.97685, 17.42105, 12.0668]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.865850000000002, 17.464599999999997, 12.05925]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.837150000000001, 17.7814, 11.99175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.7209, 17.80795, 11.98425]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.657100000000002, 17.969050000000003, 11.91675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.538200000000002, 17.978, 11.9092]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.4618, 17.978, 11.8408]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3429, 17.969050000000003, 11.83325]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.2791, 17.80795, 11.76575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.16285, 17.7814, 11.75825]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.13415, 17.464599999999997, 11.69075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.02315, 17.42105, 11.6832]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.053850000000001, 16.95395, 11.6148]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.9506000000000006, 16.89435, 11.60725]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0614, 16.28865, 11.53975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.9681999999999995, 16.2143, 11.532200000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.1798, 15.4817, 11.463800000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.0987, 15.394300000000001, 11.456250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4273000000000002, 14.553700000000001, 11.38875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3601, 14.455200000000001, 11.38125]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.8219, 13.5228, 11.31375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.77015, 13.41535, 11.3062]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.37685, 12.41365, 11.2378]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3417, 12.299700000000001, 11.23025]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1023, 11.250300000000001, 11.16275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.08455, 11.1324, 11.1552]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.0044500000000003, 10.0596, 11.0868]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.0044500000000003, 9.9404, 11.07925]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.08455, 8.8676, 11.01175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1023, 8.7497, 11.004249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3417, 7.7003, 10.93675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.37685, 7.58635, 10.9292]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.77015, 6.58465, 10.8608]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8219, 6.4772, 10.85325]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.3601, 5.5448, 10.78575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4273000000000002, 5.446300000000001, 10.778200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.0987, 4.605700000000001, 10.709800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.1798, 4.5183, 10.702250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.9681999999999995, 3.7857000000000003, 10.63475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0614, 3.7113500000000004, 10.62725]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.9506000000000006, 3.1056500000000002, 10.55975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.053850000000001, 3.04605, 10.5522]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.02315, 2.57895, 10.4838]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.13415, 2.5353999999999997, 10.47625]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.16285, 2.2186, 10.40875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.2791, 2.19205, 10.4012]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3429, 2.03095, 10.3328]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.4618, 2.022, 10.32525]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.538200000000002, 2.022, 10.25775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.657100000000002, 2.03095, 10.25025]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.7209, 2.19205, 10.18275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.837150000000001, 2.2186, 10.1752]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.865850000000002, 2.5353999999999997, 10.1068]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.97685, 2.57895, 10.099250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.94615, 3.04605, 10.03175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.0494, 3.1056500000000002, 10.0242]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.938600000000001, 3.7113500000000004, 9.9558]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0318, 3.7857000000000003, 9.94825]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.820200000000002, 4.5183, 9.88075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.901300000000003, 4.605700000000001, 9.87325]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.5727, 5.446300000000001, 9.80575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.6399, 5.5448, 9.7982]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.1781, 6.4772, 9.729800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.22985, 6.58465, 9.72225]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.62315, 7.58635, 9.65475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.6583, 7.7003, 9.6472]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.8977, 8.7497, 9.5788]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.91545, 8.8676, 9.57125]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.995549999999998, 9.9404, 9.50375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.995549999999998, 10.0596, 9.49625]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.91545, 11.1324, 9.42875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.8977, 11.250300000000001, 9.421200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.6583, 12.299700000000001, 9.352800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.62315, 12.41365, 9.345250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.22985, 13.41535, 9.27775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.1781, 13.5228, 9.270199999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.6399, 14.455200000000001, 9.2018]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.5727, 14.553700000000001, 9.19425]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.901300000000003, 15.394300000000001, 9.12675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.820200000000002, 15.4817, 9.11925]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0318, 16.2143, 9.05175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.938600000000001, 16.28865, 9.0442]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.0494, 16.89435, 8.9758]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.94615, 16.95395, 8.96825]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.97685, 17.42105, 8.90075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.865850000000002, 17.464599999999997, 8.8932]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.837150000000001, 17.7814, 8.8248]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.7209, 17.80795, 8.81725]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.657100000000002, 17.969050000000003, 8.74975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.538200000000002, 17.978, 8.74225]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.4618, 17.978, 8.67475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3429, 17.969050000000003, 8.6672]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.2791, 17.80795, 8.5988]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.16285, 17.7814, 8.59125]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.13415, 17.464599999999997, 8.52375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.02315, 17.42105, 8.5162]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.053850000000001, 16.95395, 8.4478]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.9506000000000006, 16.89435, 8.44025]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0614, 16.28865, 8.37275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.9681999999999995, 16.2143, 8.36525]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.1798, 15.4817, 8.29775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.0987, 15.394300000000001, 8.2902]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4273000000000002, 14.553700000000001, 8.2218]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3601, 14.455200000000001, 8.21425]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.8219, 13.5228, 8.14675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.77015, 13.41535, 8.1392]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.37685, 12.41365, 8.0708]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3417, 12.299700000000001, 8.06325]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1023, 11.250300000000001, 7.99575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.08455, 11.1324, 7.98825]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.0044500000000003, 10.0596, 7.92075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.0044500000000003, 9.9404, 7.9132]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.08455, 8.8676, 7.844800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1023, 8.7497, 7.837250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3417, 7.7003, 7.76975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.37685, 7.58635, 7.7622]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.77015, 6.58465, 7.6938]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8219, 6.4772, 7.68625]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.3601, 5.5448, 7.61875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4273000000000002, 5.446300000000001, 7.61125]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.0987, 4.605700000000001, 7.543750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.1798, 4.5183, 7.536200000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.9681999999999995, 3.7857000000000003, 7.467800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0614, 3.7113500000000004, 7.460250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.9506000000000006, 3.1056500000000002, 7.39275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.053850000000001, 3.04605, 7.3852]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.02315, 2.57895, 7.3168]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.13415, 2.5353999999999997, 7.30925]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.16285, 2.2186, 7.241750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.2791, 2.19205, 7.234250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3429, 2.03095, 7.16675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.4618, 2.022, 7.159200000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.538200000000002, 2.022, 7.090800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.657100000000002, 2.03095, 7.0832500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.7209, 2.19205, 7.01575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.837150000000001, 2.2186, 7.008249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.865850000000002, 2.5353999999999997, 6.94075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.97685, 2.57895, 6.9332]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.94615, 3.04605, 6.8648]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.0494, 3.1056500000000002, 6.8572500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.938600000000001, 3.7113500000000004, 6.78975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0318, 3.7857000000000003, 6.7822000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.820200000000002, 4.5183, 6.7138]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.901300000000003, 4.605700000000001, 6.70625]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.5727, 5.446300000000001, 6.63875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.6399, 5.5448, 6.63125]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.1781, 6.4772, 6.56375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.22985, 6.58465, 6.5562000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.62315, 7.58635, 6.4878]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.6583, 7.7003, 6.480250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.8977, 8.7497, 6.41275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.91545, 8.8676, 6.4052]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.995549999999998, 9.9404, 6.3368]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.995549999999998, 10.0596, 6.32925]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.91545, 11.1324, 6.26175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.8977, 11.250300000000001, 6.25425]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.6583, 12.299700000000001, 6.18675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.62315, 12.41365, 6.1792]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.22985, 13.41535, 6.110800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.1781, 13.5228, 6.103250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.6399, 14.455200000000001, 6.03575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.5727, 14.553700000000001, 6.0282]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.901300000000003, 15.394300000000001, 5.9598]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.820200000000002, 15.4817, 5.95225]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0318, 16.2143, 5.88475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.938600000000001, 16.28865, 5.87725]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.0494, 16.89435, 5.80975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.94615, 16.95395, 5.802200000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.97685, 17.42105, 5.733800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.865850000000002, 17.464599999999997, 5.726250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.837150000000001, 17.7814, 5.65875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.7209, 17.80795, 5.6512]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.657100000000002, 17.969050000000003, 5.5828]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.538200000000002, 17.978, 5.57525]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.4618, 17.978, 5.50775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3429, 17.969050000000003, 5.500249999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.2791, 17.80795, 5.43275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.16285, 17.7814, 5.425200000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.13415, 17.464599999999997, 5.356800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.02315, 17.42105, 5.3492500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.053850000000001, 16.95395, 5.28175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.9506000000000006, 16.89435, 5.2741999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0614, 16.28865, 5.2058]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.9681999999999995, 16.2143, 5.19825]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.1798, 15.4817, 5.13075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.0987, 15.394300000000001, 5.12325]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4273000000000002, 14.553700000000001, 5.05575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3601, 14.455200000000001, 5.0482000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.8219, 13.5228, 4.9798]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.77015, 13.41535, 4.97225]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.37685, 12.41365, 4.90475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3417, 12.299700000000001, 4.8972]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1023, 11.250300000000001, 4.8288]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.08455, 11.1324, 4.82125]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.0044500000000003, 10.0596, 4.75375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.0044500000000003, 9.9404, 4.746250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.08455, 8.8676, 4.67875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1023, 8.7497, 4.6712]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3417, 7.7003, 4.6028]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.37685, 7.58635, 4.59525]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.77015, 6.58465, 4.52775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8219, 6.4772, 4.5202]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.3601, 5.5448, 4.4518]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4273000000000002, 5.446300000000001, 4.44425]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.0987, 4.605700000000001, 4.37675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.1798, 4.5183, 4.36925]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.9681999999999995, 3.7857000000000003, 4.30175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0614, 3.7113500000000004, 4.2942]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.9506000000000006, 3.1056500000000002, 4.2258000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.053850000000001, 3.04605, 4.21825]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.02315, 2.57895, 4.15075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.13415, 2.5353999999999997, 4.1432]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.16285, 2.2186, 4.0748]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.2791, 2.19205, 4.06725]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3429, 2.03095, 3.99975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.4618, 2.022, 3.9922500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.538200000000002, 2.022, 3.9247499999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.657100000000002, 2.03095, 3.9172]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.7209, 2.19205, 3.8488]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.837150000000001, 2.2186, 3.84125]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.865850000000002, 2.5353999999999997, 3.77375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.97685, 2.57895, 3.7662000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.94615, 3.04605, 3.6978000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.0494, 3.1056500000000002, 3.6902500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.938600000000001, 3.7113500000000004, 3.6227500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0318, 3.7857000000000003, 3.6152500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.820200000000002, 4.5183, 3.54775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.901300000000003, 4.605700000000001, 3.5402]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.5727, 5.446300000000001, 3.4718]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.6399, 5.5448, 3.46425]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.1781, 6.4772, 3.39675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.22985, 6.58465, 3.3892]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.62315, 7.58635, 3.3208]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.6583, 7.7003, 3.31325]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.8977, 8.7497, 3.24575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.91545, 8.8676, 3.2382500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.995549999999998, 9.9404, 3.17075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.995549999999998, 10.0596, 3.1632]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.91545, 11.1324, 3.0948]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.8977, 11.250300000000001, 3.08725]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.6583, 12.299700000000001, 3.01975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.62315, 12.41365, 3.0122]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.22985, 13.41535, 2.9438]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.1781, 13.5228, 2.93625]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.6399, 14.455200000000001, 2.8687500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.5727, 14.553700000000001, 2.8612500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.901300000000003, 15.394300000000001, 2.79375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.820200000000002, 15.4817, 2.7862]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0318, 16.2143, 2.7178]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.938600000000001, 16.28865, 2.7102500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.0494, 16.89435, 2.64275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.94615, 16.95395, 2.6351999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.97685, 17.42105, 2.5668]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.865850000000002, 17.464599999999997, 2.55925]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.837150000000001, 17.7814, 2.4917499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.7209, 17.80795, 2.48425]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.657100000000002, 17.969050000000003, 2.41675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.538200000000002, 17.978, 2.4092]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.4618, 17.978, 2.3408]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3429, 17.969050000000003, 2.3332500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.2791, 17.80795, 2.26575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.16285, 17.7814, 2.25825]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.13415, 17.464599999999997, 2.19075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.02315, 17.42105, 2.1832]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.053850000000001, 16.95395, 2.1148000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.9506000000000006, 16.89435, 2.10725]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0614, 16.28865, 2.03975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.9681999999999995, 16.2143, 2.0322]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.1798, 15.4817, 1.9638]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.0987, 15.394300000000001, 1.95625]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4273000000000002, 14.553700000000001, 1.8887500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3601, 14.455200000000001, 1.88125]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.8219, 13.5228, 1.81375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.77015, 13.41535, 1.8062]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.37685, 12.41365, 1.7378]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3417, 12.299700000000001, 1.73025]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1023, 11.250300000000001, 1.6627500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.08455, 11.1324, 1.6552000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.0044500000000003, 10.0596, 1.5868000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.0044500000000003, 9.9404, 1.57925]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.08455, 8.8676, 1.51175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1023, 8.7497, 1.5042499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3417, 7.7003, 1.43675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.37685, 7.58635, 1.4292]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.77015, 6.58465, 1.3608]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.8219, 6.4772, 1.35325]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.3601, 5.5448, 1.2857500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4273000000000002, 5.446300000000001, 1.2782000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.0987, 4.605700000000001, 1.2098]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.1798, 4.5183, 1.2022499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.9681999999999995, 3.7857000000000003, 1.13475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0614, 3.7113500000000004, 1.12725]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.9506000000000006, 3.1056500000000002, 1.05975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.053850000000001, 3.04605, 1.0522]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.02315, 2.57895, 0.9838]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.13415, 2.5353999999999997, 0.9762500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.16285, 2.2186, 0.90875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.2791, 2.19205, 0.9012]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3429, 2.03095, 0.8328]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.4618, 2.022, 0.82525]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.538200000000002, 2.022, 0.7577499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.657100000000002, 2.03095, 0.75025]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.7209, 2.19205, 0.6827500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.837150000000001, 2.2186, 0.6752000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.865850000000002, 2.5353999999999997, 0.6068]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.97685, 2.57895, 0.59925]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.94615, 3.04605, 0.5317500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.0494, 3.1056500000000002, 0.5242]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.938600000000001, 3.7113500000000004, 0.4558]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0318, 3.7857000000000003, 0.44825]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.820200000000002, 4.5183, 0.38075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.901300000000003, 4.605700000000001, 0.37324999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.5727, 5.446300000000001, 0.30574999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.6399, 5.5448, 0.29819999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.1781, 6.4772, 0.2298]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.22985, 6.58465, 0.22225]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.62315, 7.58635, 0.15475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.6583, 7.7003, 0.1472]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.8977, 8.7497, 0.07880000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.91545, 8.8676, 0.07125000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.995549999999998, 9.9404, 0.00375]) cube([0.4, 0.4, 0.1], center=true);
}

