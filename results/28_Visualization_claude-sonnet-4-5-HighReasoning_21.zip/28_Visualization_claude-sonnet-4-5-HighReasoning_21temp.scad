
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.363970174519614]);

translate([2, 0, 0]) cube([1, 1, 4.362511426182018]);

translate([3, 0, 0]) cube([1, 1, 4.371380126543407]);

translate([4, 0, 0]) cube([1, 1, 4.372163840065242]);

translate([5, 0, 0]) cube([1, 1, 4.375177279231789]);

translate([6, 0, 0]) cube([1, 1, 3.697485844622842]);

translate([7, 0, 0]) cube([1, 1, 3.7017633076363783]);

translate([8, 0, 0]) cube([1, 1, 3.701921900316189]);

translate([9, 0, 0]) cube([1, 1, 4.609999999999991]);

translate([10, 0, 0]) cube([1, 1, 3.7978442059616686]);

translate([11, 0, 0]) cube([1, 1, 3.797790289153514]);

translate([12, 0, 0]) cube([1, 1, 4.181839563271503]);

translate([13, 0, 0]) cube([1, 1, 4.178493511904744]);

translate([14, 0, 0]) cube([1, 1, 4.1566321857987445]);

translate([15, 0, 0]) cube([1, 1, 4.079329404499472]);

translate([16, 0, 0]) cube([1, 1, 3.836779192848293]);

translate([17, 0, 0]) cube([1, 1, 3.7260122884017046]);

translate([18, 0, 0]) cube([1, 1, 3.727177192503988]);

translate([19, 0, 0]) cube([1, 1, 4.379999999999998]);

translate([20, 0, 0]) cube([1, 1, 4.3599999999999985]);

translate([21, 0, 0]) cube([1, 1, 4.41]);

translate([22, 0, 0]) cube([1, 1, 4.6]);

translate([23, 0, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.2]);

translate([2, 1, 0]) cube([1, 1, 4.7]);

translate([3, 1, 0]) cube([1, 1, 4.42]);

translate([4, 1, 0]) cube([1, 1, 4.371319063933271]);

translate([5, 1, 0]) cube([1, 1, 4.371323381165226]);

translate([6, 1, 0]) cube([1, 1, 4.449999999999995]);

translate([7, 1, 0]) cube([1, 1, 4.549999999999993]);

translate([8, 1, 0]) cube([1, 1, 4.639999999999986]);

translate([9, 1, 0]) cube([1, 1, 4.670872584332554]);

translate([10, 1, 0]) cube([1, 1, 4.6734054729160555]);

translate([11, 1, 0]) cube([1, 1, 3.79804612913877]);

translate([12, 1, 0]) cube([1, 1, 4.223877344369078]);

translate([13, 1, 0]) cube([1, 1, 4.227855385251298]);

translate([14, 1, 0]) cube([1, 1, 4.20421442208326]);

translate([15, 1, 0]) cube([1, 1, 3.896774695860573]);

translate([16, 1, 0]) cube([1, 1, 3.838164590895212]);

translate([17, 1, 0]) cube([1, 1, 3.7261152082086757]);

translate([18, 1, 0]) cube([1, 1, 3.7260122884527456]);

translate([19, 1, 0]) cube([1, 1, 4.0799999999999965]);

translate([20, 1, 0]) cube([1, 1, 3.904107446936987]);

translate([21, 1, 0]) cube([1, 1, 3.904095198279789]);

translate([22, 1, 0]) cube([1, 1, 4.0]);

translate([23, 1, 0]) cube([1, 1, 4.1]);

translate([0, 2, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.2]);

translate([4, 2, 0]) cube([1, 1, 4.829999999999999]);

translate([5, 2, 0]) cube([1, 1, 4.829999999999999]);

translate([6, 2, 0]) cube([1, 1, 4.649999999999999]);

translate([7, 2, 0]) cube([1, 1, 4.619999999999991]);

translate([8, 2, 0]) cube([1, 1, 4.61945268018113]);

translate([9, 2, 0]) cube([1, 1, 4.649999999999986]);

translate([10, 2, 0]) cube([1, 1, 4.67999999999999]);

translate([11, 2, 0]) cube([1, 1, 3.8193385338317016]);

translate([12, 2, 0]) cube([1, 1, 4.154247334648678]);

translate([13, 2, 0]) cube([1, 1, 4.148325337486748]);

translate([14, 2, 0]) cube([1, 1, 3.9867739691564448]);

translate([15, 2, 0]) cube([1, 1, 4.73999999999999]);

translate([16, 2, 0]) cube([1, 1, 4.579999999999989]);

translate([17, 2, 0]) cube([1, 1, 3.186633108481932]);

translate([18, 2, 0]) cube([1, 1, 3.1866270507726298]);

translate([19, 2, 0]) cube([1, 1, 3.9899999999999918]);

translate([20, 2, 0]) cube([1, 1, 3.9040960425867204]);

translate([21, 2, 0]) cube([1, 1, 3.904341713902096]);

translate([22, 2, 0]) cube([1, 1, 3.904130871214839]);

translate([23, 2, 0]) cube([1, 1, 3.9040127886240543]);

translate([0, 3, 0]) cube([1, 1, 7.2]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

translate([4, 3, 0]) cube([1, 1, 5.4]);

translate([5, 3, 0]) cube([1, 1, 5.4]);

translate([6, 3, 0]) cube([1, 1, 5.0]);

translate([7, 3, 0]) cube([1, 1, 4.62806979442957]);

translate([8, 3, 0]) cube([1, 1, 4.639999999999995]);

translate([9, 3, 0]) cube([1, 1, 4.679999999999998]);

translate([10, 3, 0]) cube([1, 1, 4.879999999999998]);

translate([11, 3, 0]) cube([1, 1, 3.849268157411989]);

translate([12, 3, 0]) cube([1, 1, 4.251607670490684]);

translate([13, 3, 0]) cube([1, 1, 4.308530558267229]);

translate([14, 3, 0]) cube([1, 1, 4.1370361271804414]);

translate([15, 3, 0]) cube([1, 1, 4.589999999999987]);

translate([16, 3, 0]) cube([1, 1, 4.409999999999987]);

translate([17, 3, 0]) cube([1, 1, 4.293473439172439]);

translate([18, 3, 0]) cube([1, 1, 4.199991375912201]);

translate([19, 3, 0]) cube([1, 1, 4.069999999999988]);

translate([20, 3, 0]) cube([1, 1, 3.9041423704947844]);

translate([21, 3, 0]) cube([1, 1, 3.9048047342930268]);

translate([22, 3, 0]) cube([1, 1, 3.905173361121581]);

translate([23, 3, 0]) cube([1, 1, 3.904673786949835]);

translate([0, 4, 0]) cube([1, 1, 7.5]);

translate([1, 4, 0]) cube([1, 1, 6.9]);

translate([2, 4, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.329999999999999]);

translate([7, 4, 0]) cube([1, 1, 4.92]);

translate([8, 4, 0]) cube([1, 1, 4.91]);

translate([9, 4, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([10, 4, 0]) cube([1, 1, 6]);

translate([11, 4, 0]) cube([1, 1, 5.4]);

translate([12, 4, 0]) cube([1, 1, 4.297228259982859]);

translate([13, 4, 0]) cube([1, 1, 4.338273632512467]);

translate([14, 4, 0]) cube([1, 1, 4.337500882154075]);

translate([15, 4, 0]) cube([1, 1, 3.3126272393159004]);

translate([16, 4, 0]) cube([1, 1, 4.339999999999985]);

translate([17, 4, 0]) cube([1, 1, 4.312731343143899]);

translate([18, 4, 0]) cube([1, 1, 4.275929627071735]);

translate([19, 4, 0]) cube([1, 1, 4.1199999999999894]);

translate([20, 4, 0]) cube([1, 1, 3.914897823053446]);

translate([21, 4, 0]) cube([1, 1, 3.904471011213177]);

translate([22, 4, 0]) cube([1, 1, 3.9050354166587553]);

translate([23, 4, 0]) cube([1, 1, 3.905452178182535]);

translate([0, 5, 0]) cube([1, 1, 7.9]);

translate([1, 5, 0]) cube([1, 1, 7.4]);

translate([2, 5, 0]) cube([1, 1, 7.1]);

translate([3, 5, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

translate([7, 5, 0]) cube([1, 1, 5.4399999999999995]);

translate([8, 5, 0]) cube([1, 1, 5.43]);

color([0,1,0])
translate([9, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 5, 0]) cube([1, 1, 6]);

translate([12, 5, 0]) cube([1, 1, 4.230248813269599]);

translate([13, 5, 0]) cube([1, 1, 4.357239655056056]);

translate([14, 5, 0]) cube([1, 1, 4.3577170374151954]);

translate([15, 5, 0]) cube([1, 1, 3.77635262008518]);

translate([16, 5, 0]) cube([1, 1, 4.389999978087716]);

translate([17, 5, 0]) cube([1, 1, 4.269999999999988]);

translate([18, 5, 0]) cube([1, 1, 4.249999999999993]);

translate([19, 5, 0]) cube([1, 1, 4.119999999999997]);

translate([20, 5, 0]) cube([1, 1, 4.2]);

translate([21, 5, 0]) cube([1, 1, 4.2]);

translate([22, 5, 0]) cube([1, 1, 4.1]);

translate([23, 5, 0]) cube([1, 1, 3.9050099909390505]);

translate([0, 6, 0]) cube([1, 1, 7.9]);

translate([1, 6, 0]) cube([1, 1, 7.4]);

translate([2, 6, 0]) cube([1, 1, 7.1]);

translate([3, 6, 0]) cube([1, 1, 6.81]);

translate([4, 6, 0]) cube([1, 1, 6.619999999999997]);

translate([5, 6, 0]) cube([1, 1, 6.619999999999997]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 6, 0]) cube([1, 1, 6]);

translate([12, 6, 0]) cube([1, 1, 4.231628662841478]);

translate([13, 6, 0]) cube([1, 1, 4.0900661471357695]);

translate([14, 6, 0]) cube([1, 1, 4.749999999999995]);

translate([15, 6, 0]) cube([1, 1, 4.429999999999993]);

translate([16, 6, 0]) cube([1, 1, 4.399999999999993]);

translate([17, 6, 0]) cube([1, 1, 4.449999999999999]);

translate([18, 6, 0]) cube([1, 1, 4.6]);

translate([19, 6, 0]) cube([1, 1, 4.6]);

translate([20, 6, 0]) cube([1, 1, 4.7]);

translate([21, 6, 0]) cube([1, 1, 4.6]);

translate([22, 6, 0]) cube([1, 1, 4.5]);

translate([23, 6, 0]) cube([1, 1, 4.4]);

translate([0, 7, 0]) cube([1, 1, 7.9]);

translate([1, 7, 0]) cube([1, 1, 7.3]);

translate([2, 7, 0]) cube([1, 1, 6.93]);

translate([3, 7, 0]) cube([1, 1, 6.689999999999998]);

translate([4, 7, 0]) cube([1, 1, 6.639999999999997]);

translate([5, 7, 0]) cube([1, 1, 6.759999999999999]);

translate([6, 7, 0]) cube([1, 1, 6.649999999999999]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

translate([12, 7, 0]) cube([1, 1, 4.251750646612808]);

translate([13, 7, 0]) cube([1, 1, 5.119999999999997]);

translate([14, 7, 0]) cube([1, 1, 4.939999999999997]);

translate([15, 7, 0]) cube([1, 1, 4.769999999999996]);

translate([16, 7, 0]) cube([1, 1, 4.689999999999998]);

translate([17, 7, 0]) cube([1, 1, 5.1]);

translate([18, 7, 0]) cube([1, 1, 5.3]);

translate([19, 7, 0]) cube([1, 1, 5.2]);

translate([20, 7, 0]) cube([1, 1, 5.1]);

translate([21, 7, 0]) cube([1, 1, 4.9]);

translate([22, 7, 0]) cube([1, 1, 4.9]);

translate([23, 7, 0]) cube([1, 1, 5.1]);

translate([0, 8, 0]) cube([1, 1, 8.1]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 6.969999999999999]);

translate([3, 8, 0]) cube([1, 1, 6.899999999999998]);

translate([4, 8, 0]) cube([1, 1, 7.0699999999999985]);

translate([5, 8, 0]) cube([1, 1, 7.169999999999998]);

translate([6, 8, 0]) cube([1, 1, 6.769999999999999]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

translate([13, 8, 0]) cube([1, 1, 5.109999999999998]);

translate([14, 8, 0]) cube([1, 1, 4.999999999999998]);

translate([15, 8, 0]) cube([1, 1, 4.799999999999998]);

translate([16, 8, 0]) cube([1, 1, 4.91]);

color([0,1,0])
translate([17, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 8.2]);

translate([1, 9, 0]) cube([1, 1, 7.6]);

translate([2, 9, 0]) cube([1, 1, 7.249999999999999]);

translate([3, 9, 0]) cube([1, 1, 7.369999999999998]);

translate([4, 9, 0]) cube([1, 1, 6.281132697952997]);

translate([5, 9, 0]) cube([1, 1, 6.281042502947471]);

translate([6, 9, 0]) cube([1, 1, 6.989999999999998]);

translate([7, 9, 0]) cube([1, 1, 6.659999999999998]);

translate([8, 9, 0]) cube([1, 1, 6.659999999999998]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

translate([13, 9, 0]) cube([1, 1, 5.269999999999999]);

translate([14, 9, 0]) cube([1, 1, 5.129999999999999]);

translate([15, 9, 0]) cube([1, 1, 4.9399999999999995]);

translate([16, 9, 0]) cube([1, 1, 5.1]);

color([0,1,0])
translate([17, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 8.1]);

translate([1, 10, 0]) cube([1, 1, 7.7]);

translate([2, 10, 0]) cube([1, 1, 7.529999999999999]);

translate([3, 10, 0]) cube([1, 1, 7.619999999999999]);

translate([4, 10, 0]) cube([1, 1, 6.282468094797069]);

translate([5, 10, 0]) cube([1, 1, 6.282502817517519]);

translate([6, 10, 0]) cube([1, 1, 7.079999999999998]);

translate([7, 10, 0]) cube([1, 1, 6.959999999999999]);

translate([8, 10, 0]) cube([1, 1, 6.93]);

translate([9, 10, 0]) cube([1, 1, 5.337775402747851]);

translate([10, 10, 0]) cube([1, 1, 6.509999999999998]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

translate([14, 10, 0]) cube([1, 1, 5.4]);

translate([15, 10, 0]) cube([1, 1, 5.3]);

translate([16, 10, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([17, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

translate([20, 10, 0]) cube([1, 1, 6.6]);

translate([21, 10, 0]) cube([1, 1, 6.8]);

translate([22, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 8.1]);

translate([1, 11, 0]) cube([1, 1, 7.8]);

translate([2, 11, 0]) cube([1, 1, 7.619999999999999]);

translate([3, 11, 0]) cube([1, 1, 7.449999999999999]);

translate([4, 11, 0]) cube([1, 1, 7.259999999999999]);

translate([5, 11, 0]) cube([1, 1, 7.089999999999998]);

translate([6, 11, 0]) cube([1, 1, 7.0699999999999985]);

translate([7, 11, 0]) cube([1, 1, 7.049999999999999]);

translate([8, 11, 0]) cube([1, 1, 6.8599999999999985]);

translate([9, 11, 0]) cube([1, 1, 5.33733080103226]);

translate([10, 11, 0]) cube([1, 1, 6.509999999999998]);

translate([11, 11, 0]) cube([1, 1, 6.649999999999999]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

translate([20, 11, 0]) cube([1, 1, 6.7]);

translate([21, 11, 0]) cube([1, 1, 7.0]);

translate([22, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 7.7]);

translate([1, 12, 0]) cube([1, 1, 7.4]);

translate([2, 12, 0]) cube([1, 1, 7.2299999999999995]);

translate([3, 12, 0]) cube([1, 1, 7.039999999999999]);

translate([4, 12, 0]) cube([1, 1, 6.659999999999998]);

translate([5, 12, 0]) cube([1, 1, 6.5699999999999985]);

translate([6, 12, 0]) cube([1, 1, 6.649999999999999]);

translate([7, 12, 0]) cube([1, 1, 6.839999999999999]);

translate([8, 12, 0]) cube([1, 1, 6.7299999999999995]);

translate([9, 12, 0]) cube([1, 1, 6.589999999999998]);

translate([10, 12, 0]) cube([1, 1, 6.5839285714285705]);

translate([11, 12, 0]) cube([1, 1, 6.649999999999999]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 12, 0]) cube([1, 1, 6]);

translate([21, 12, 0]) cube([1, 1, 6.7]);

translate([22, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 7.0]);

translate([1, 13, 0]) cube([1, 1, 6.8]);

translate([2, 13, 0]) cube([1, 1, 6.819999999999999]);

translate([3, 13, 0]) cube([1, 1, 6.639999999999999]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

translate([8, 13, 0]) cube([1, 1, 6.559999999999999]);

translate([9, 13, 0]) cube([1, 1, 6.629999999999999]);

translate([10, 13, 0]) cube([1, 1, 6.72]);

translate([11, 13, 0]) cube([1, 1, 6.72]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

translate([14, 13, 0]) cube([1, 1, 5.4]);

translate([15, 13, 0]) cube([1, 1, 5.3]);

translate([16, 13, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

translate([9, 14, 0]) cube([1, 1, 6.52]);

translate([10, 14, 0]) cube([1, 1, 7.0]);

translate([11, 14, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

translate([15, 14, 0]) cube([1, 1, 5.3]);

translate([16, 14, 0]) cube([1, 1, 5.186666345546443]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 7.0]);

translate([1, 15, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

translate([5, 15, 0]) cube([1, 1, 5.4201855765784]);

translate([6, 15, 0]) cube([1, 1, 5.449999999999999]);

color([0,1,0])
translate([7, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

translate([10, 15, 0]) cube([1, 1, 6.9]);

translate([11, 15, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

translate([16, 15, 0]) cube([1, 1, 5.3]);

translate([17, 15, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

translate([23, 15, 0]) cube([1, 1, 5.4]);

translate([0, 16, 0]) cube([1, 1, 7.2]);

translate([1, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

translate([3, 16, 0]) cube([1, 1, 5.4137196961733185]);

translate([4, 16, 0]) cube([1, 1, 5.420186176333832]);

translate([5, 16, 0]) cube([1, 1, 5.421460849805151]);

color([0,1,0])
translate([6, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 16, 0]) cube([1, 1, 6]);

translate([10, 16, 0]) cube([1, 1, 6.8]);

translate([11, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

translate([17, 16, 0]) cube([1, 1, 5.4]);

translate([18, 16, 0]) cube([1, 1, 5.300689218967104]);

translate([19, 16, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

translate([23, 16, 0]) cube([1, 1, 5.1]);

translate([0, 17, 0]) cube([1, 1, 7.0]);

translate([1, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

translate([3, 17, 0]) cube([1, 1, 5.414222346044668]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

translate([9, 17, 0]) cube([1, 1, 6.6]);

translate([10, 17, 0]) cube([1, 1, 6.9]);

translate([11, 17, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 17, 0]) cube([1, 1, 6]);

translate([22, 17, 0]) cube([1, 1, 5.3]);

translate([23, 17, 0]) cube([1, 1, 4.9]);

translate([0, 18, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

translate([8, 18, 0]) cube([1, 1, 6.6]);

translate([9, 18, 0]) cube([1, 1, 7.0]);

translate([10, 18, 0]) cube([1, 1, 7.1]);

translate([11, 18, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([20, 18, 0]) cube([1, 1, 5.4]);

translate([21, 18, 0]) cube([1, 1, 5.3]);

translate([22, 18, 0]) cube([1, 1, 4.9]);

translate([23, 18, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 19, 0]) cube([1, 1, 6]);

translate([8, 19, 0]) cube([1, 1, 6.8]);

translate([9, 19, 0]) cube([1, 1, 7.2]);

translate([10, 19, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

translate([19, 19, 0]) cube([1, 1, 5.4]);

translate([20, 19, 0]) cube([1, 1, 5.4]);

translate([21, 19, 0]) cube([1, 1, 5.3]);

translate([22, 19, 0]) cube([1, 1, 5.0]);

translate([23, 19, 0]) cube([1, 1, 4.6000281579005255]);

color([0,1,0])
translate([0, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 20, 0]) cube([1, 1, 6]);

translate([7, 20, 0]) cube([1, 1, 6.6]);

translate([8, 20, 0]) cube([1, 1, 6.8]);

translate([9, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 20, 0]) cube([1, 1, 6]);

translate([23, 20, 0]) cube([1, 1, 5.1]);

color([0,1,0])
translate([0, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

translate([20, 21, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

translate([4, 22, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([5, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

translate([17, 22, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

translate([19, 22, 0]) cube([1, 1, 5.4]);

translate([20, 22, 0]) cube([1, 1, 5.3]);

translate([21, 22, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

translate([0, 23, 0]) cube([1, 1, 5.300000026116732]);

translate([1, 23, 0]) cube([1, 1, 5.300000016261025]);

translate([2, 23, 0]) cube([1, 1, 5.3]);

translate([3, 23, 0]) cube([1, 1, 5.2]);

translate([4, 23, 0]) cube([1, 1, 5.000023683656268]);

translate([5, 23, 0]) cube([1, 1, 5.0000240802075755]);

translate([6, 23, 0]) cube([1, 1, 5.2]);

translate([7, 23, 0]) cube([1, 1, 5.2]);

translate([8, 23, 0]) cube([1, 1, 5.0]);

translate([9, 23, 0]) cube([1, 1, 4.8000029445180425]);

translate([10, 23, 0]) cube([1, 1, 5.0]);

translate([11, 23, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([12, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 23, 0]) cube([1, 1, 6]);

translate([16, 23, 0]) cube([1, 1, 5.4]);

translate([17, 23, 0]) cube([1, 1, 5.200001319431087]);

translate([18, 23, 0]) cube([1, 1, 5.200001271076678]);

translate([19, 23, 0]) cube([1, 1, 5.3]);

translate([20, 23, 0]) cube([1, 1, 5.300000085306248]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);
