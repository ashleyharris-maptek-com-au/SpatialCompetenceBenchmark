
hull() {
    translate([13.495830000000002, 7.54953, 8.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.420770000000001, 8.441070000000002, 8.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.404300000000003, 8.538810000000002, 8.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.1829, 9.406590000000001, 8.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.15074, 9.50022, 8.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.79326, 10.31778, 8.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.74643, 10.404660000000002, 8.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.26097, 11.15094, 8.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.20013, 11.229149999999999, 8.6355]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.59047, 11.890649999999999, 8.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.51739, 11.957699999999999, 8.5455]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.81161, 12.5031, 8.464500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.72848, 12.55695, 8.4555]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.93792, 12.98085, 8.3745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.846870000000001, 13.02027, 8.365499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.99853, 13.30593, 8.2845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.90232, 13.329690000000001, 8.2755]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.018880000000001, 13.47171, 8.1945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.920090000000001, 13.47936, 8.1855]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.02531, 13.475040000000002, 8.1045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.9265799999999995, 13.465950000000001, 8.0955]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.044219999999999, 13.306650000000001, 8.0145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.94837, 13.281300000000002, 8.0055]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.10543, 12.984300000000001, 7.9245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.01525, 12.94389, 7.9155]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.23495, 12.51351, 7.8345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.15251, 12.458849999999998, 7.825500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.44889, 11.905349999999999, 7.7445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.37683, 11.83794, 7.7355]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.78337, 11.178060000000002, 7.6545000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.72358, 11.099730000000001, 7.645500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.24082, 10.34967, 7.5645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.19468, 10.26228, 7.555499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.84692, 9.43932, 7.4745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8155999999999999, 9.34551, 7.4655]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.5996, 8.479890000000001, 7.3845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.58418, 8.38236, 7.375500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.52262, 7.49244, 7.2945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5238200000000002, 7.39371, 7.2855]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.60698, 6.50649, 7.2045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.62042, 6.417540000000001, 7.195500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.77918, 5.70366, 7.1145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.7959, 5.622, 7.1055]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9381000000000002, 4.866, 7.0245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.9534500000000001, 4.7757, 7.015499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.0875500000000002, 3.9063, 6.9345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1019500000000004, 3.80425, 6.9255]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.22705, 2.8367500000000003, 6.8445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.24045, 2.72405, 6.8355]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.35655, 1.6629500000000004, 6.7545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.36905, 1.5406500000000003, 6.7455]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.4779500000000003, 0.40035000000000004, 6.6645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.4846500000000002, 0.2775, 6.655500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.49635, -0.7935000000000001, 6.5745000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.49235, -0.9114500000000001, 6.5655]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.40865, -1.96355, 6.484500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3941000000000003, -2.07895, 6.475500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.2159, -3.10405, 6.3945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1908, -3.2163, 6.3854999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9172, -4.2117, 6.3045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.88155, -4.320450000000001, 6.2955]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.5134500000000002, -5.2825500000000005, 6.2145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.4673, -5.3774500000000005, 6.205500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0047, -6.12355, 6.1245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.94805, -6.1894, 6.1155]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.39095, -6.6286, 6.0345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.32905, -6.660399999999999, 6.025500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.22805, -6.7936000000000005, 5.9445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.29845, -6.796500000000001, 5.9355]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.00855, -6.7155000000000005, 5.8545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.0856000000000001, -6.69495, 5.8454999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.7624000000000002, -6.40605, 5.7645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.83495, -6.363549999999999, 5.7555000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([-2.4640500000000003, -5.887449999999999, 5.6745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-2.5303500000000003, -5.826, 5.6655]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.09465, -5.196, 5.5845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.1527000000000003, -5.1192, 5.5755]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.6333, -4.3668000000000005, 5.4945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.6815, -4.27895, 5.485500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.0685, -3.45005, 5.4045000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.1061, -3.3562000000000003, 5.3955]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.3959, -2.4958, 5.3145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.42315, -2.4006, 5.3055]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.62385, -1.5474, 5.224499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.64, -1.4547, 5.2155]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.73, -0.6393, 5.1345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.734350000000001, -0.55355, 5.1255]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.722650000000001, 0.17455, 5.0445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.7158500000000005, 0.25435, 5.035500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.60515, 0.96265, 4.9545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.5877, 1.0394, 4.9455]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.3843000000000005, 1.7126, 4.8645000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.3571, 1.78485, 4.8555]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.0709, 2.41215, 4.7745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.03245, 2.4783500000000003, 4.7655]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.6265500000000004, 3.04265, 4.6845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.57445, 3.10085, 4.6754999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.04255, 3.58415, 4.5945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-2.97615, 3.6287000000000003, 4.585500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-2.31285, 3.9473, 4.5045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-2.2327500000000002, 3.97645, 4.4955]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.45425, 4.18255, 4.4145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.3626, 4.19745, 4.4055]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.4914, 4.25955, 4.3245000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.3912, 4.25675, 4.3155]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.5411999999999999, 4.14425, 4.234500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.6498999999999999, 4.1226, 4.2255]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6741000000000001, 3.8454, 4.1445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.78695, 3.8065, 4.1355]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.79405, 3.3835, 4.0545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.90525, 3.3294, 4.0455]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.8997500000000005, 2.7786000000000004, 3.9645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.9805500000000005, 2.7131000000000003, 3.9555000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.44045, 2.0849, 3.8745000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.4867, 2.012, 3.8655]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.8593, 1.328, 3.7844999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.8958, 1.24905, 3.7754999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.1802, 0.51195, 3.6945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.207, 0.42785, 3.6855]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.405, -0.34885, 3.6045000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.422250000000001, -0.43445, 3.5955000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.534750000000001, -1.1985500000000002, 3.5145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.5425, -1.2840000000000003, 3.5054999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.5695, -2.058, 3.4245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.5679, -2.1451000000000002, 3.4154999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.512100000000001, -2.9389000000000003, 3.3345000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.501400000000001, -3.0287500000000005, 3.3255000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.3646, -3.85225, 3.2445000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.34505, -3.94635, 3.2355000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.12995, -4.816650000000001, 3.1545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.1019000000000005, -4.916900000000001, 3.1455]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.812100000000001, -5.8511, 3.0645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.775950000000001, -5.954899999999999, 3.0555]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.41505, -6.8891, 2.9745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.37135, -6.9902500000000005, 2.9655]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.9456500000000005, -7.87675, 2.8845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.8951000000000002, -7.9703, 2.8755]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4109, -8.7677, 2.7945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3544, -8.84915, 2.7855000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.8216, -9.517850000000001, 2.7045000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.76015, -9.58275, 2.6955]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1868499999999997, -10.08225, 2.6144999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1213499999999996, -10.12625, 2.6054999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.5156500000000002, -10.418750000000001, 2.5245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.4481000000000002, -10.4397, 2.5155000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.8379000000000001, -10.5243, 2.4345000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.77115, -10.5218, 2.4255000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.17985, -10.3922, 2.3445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.11565, -10.3664, 2.3354999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.44865, -10.0316, 2.2544999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.5076, -9.98405, 2.2455]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.0044, -9.46295, 2.1645000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.0517500000000002, -9.396199999999999, 2.1555]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.40725, -8.715800000000002, 2.0745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.4335, -8.63465, 2.0655]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.5505, -7.85435, 1.9845000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.5447, -7.764050000000001, 1.9755]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.3233, -6.918950000000001, 1.8944999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.2804499999999999, -6.83215, 1.8855]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.73055, -6.114850000000001, 1.8045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.6592, -6.0478000000000005, 1.7955]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0752, -5.5582, 1.7145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.17920000000000003, -5.51695, 1.7055]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.3168, -5.26405, 1.6245000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.439, -5.249250000000001, 1.6155000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.5010000000000003, -5.23575, 1.5345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.6130000000000004, -5.24835, 1.5255]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.567, -5.48865, 1.4445000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.665, -5.5298, 1.4355]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.475, -6.030200000000001, 1.3545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.555149999999999, -6.099950000000001, 1.3455000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.18785, -6.85505, 1.2645000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.24685, -6.9514000000000005, 1.2555]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.67615, -7.930600000000001, 1.1744999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.7126, -8.04935, 1.1655]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.9394, -9.207650000000001, 1.0845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.953749999999999, -9.345500000000001, 1.0755000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.98525, -10.668500000000002, 0.9945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.9784, -10.813800000000002, 0.9855]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.8236, -12.106200000000001, 0.9045000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.796200000000001, -12.23775, 0.8955000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.457800000000001, -13.31325, 0.8145000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.412450000000001, -13.4108, 0.8055000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.934550000000001, -14.091199999999999, 0.7245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.8755500000000005, -14.1396, 0.7155]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.29145, -14.330400000000001, 0.6345000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.22205, -14.3292, 0.6255000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.55695, -14.116800000000001, 0.5445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.48085, -14.071250000000001, 0.5355000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.7761500000000003, -13.46375, 0.4545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.6985, -13.3845, 0.4455]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.0055, -12.5655, 0.36450000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.9318500000000003, -12.475100000000001, 0.35550000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.29915, -11.6669, 0.2745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.23485, -11.578949999999999, 0.2655]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.7101500000000001, -10.804049999999998, 0.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.6547500000000002, -10.7214, 0.17550000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.18225, -10.0086, 0.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1335, -9.93375, 0.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.2715, -9.29925, 0.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.3167, -9.2248, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.7253000000000001, -8.519200000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.7708, -8.4375, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.1811999999999998, -7.6725, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.2267, -7.58525, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.6353, -6.779750000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.68045, -6.6882, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-2.08455, -5.8458000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-2.1290500000000003, -5.7503, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-2.52595, -4.8737, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-2.5696000000000003, -4.77475, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-2.9584, -3.8702499999999995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.00105, -3.768, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.37995, -2.832, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.4214499999999997, -2.7257999999999996, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.78955, -1.7502, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.8298000000000005, -1.63975, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.1862, -0.6272500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.22505, -0.51415, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.567950000000001, 0.50915, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.60525, 0.6231, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.93375, 1.6508999999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.9694, 1.7669, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.2825999999999995, 2.8271000000000006, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.316549999999999, 2.9463500000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.614450000000001, 4.03265, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.646750000000001, 4.15475, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.93025, 5.26625, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.96095, 5.3912, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-6.23005, 6.5287999999999995, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-6.2591, 6.6568, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-6.5129, 7.8232, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-6.54025, 7.95475, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-6.7787500000000005, 9.15625, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-6.80445, 9.291500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.028550000000001, 10.5245, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.052600000000001, 10.66305, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.2614, 11.923950000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.28375, 12.0655, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.477250000000001, 13.3525, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.4979000000000005, 13.496, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.6761, 14.792000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.695, 14.887500000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.856999999999999, 15.3105, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.8647, 15.338799999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.8413, 15.4252, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.818, 15.4085, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.422000000000001, 15.0215, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.355, 14.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-6.545000000000001, 14.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-6.450000000000001, 13.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.550000000000001, 13.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.45, 12.950000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.55, 12.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.45, 11.950000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.55, 11.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.45, 10.950000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-2.55, 10.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-2.45, 9.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.55, 9.049999999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.425, 8.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.07500000000000001, 8.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.07500000000000001, 7.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.425, 7.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5750000000000002, 6.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.9250000000000003, 6.050000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.075, 5.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.425, 5.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.575, 4.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.925000000000001, 4.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.075, 3.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.425, 3.0500000000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.575, 2.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.924999999999999, 2.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.075, 1.9500000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.425, 1.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.575000000000001, 0.9750000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.925, 0.525, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.075000000000001, 0.47500000000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.425, 0.025, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.55, 0.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.450000000000001, 0.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.525, 0.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.975, 0.0, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 0.15000000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 2.85, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 3.1500000000000004, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 5.8500000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 6.15, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 8.85, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 9.15, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 11.850000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.0, 12.15, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.0, 14.85, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4155, 14.41, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.8945, 3.7900000000000005, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}

