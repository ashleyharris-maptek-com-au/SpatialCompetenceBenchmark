
hull() {
    translate([25.0, 25.075, 47.996500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.0, 26.425, 47.9335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.994500000000002, 26.573500000000003, 47.926]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.8955, 27.8965, 47.854000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.877, 28.041999999999998, 47.846500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.642999999999997, 29.338, 47.783500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.61, 29.48, 47.776]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.250000000000004, 30.74, 47.70400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.203500000000002, 30.8765, 47.69650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.726499999999998, 32.0735, 47.633500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.666999999999998, 32.203, 47.626000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.073, 33.336999999999996, 47.554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.001, 33.458999999999996, 47.5465]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.299000000000003, 34.521, 47.4835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.215500000000002, 34.6345, 47.476]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.4145, 35.615500000000004, 47.403999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.321, 35.72, 47.396499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.439000000000004, 36.62, 47.3335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.337000000000003, 36.7145, 47.326]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.383, 37.5155, 47.254]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.273, 37.5995, 47.2465]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.247000000000003, 38.3105, 47.1835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.130000000000003, 38.3835, 47.176]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.049999999999997, 38.9865, 47.104]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.927999999999997, 39.0475, 47.0965]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.812000000000001, 39.5425, 47.033500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.686, 39.591499999999996, 47.026]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.534000000000002, 39.9785, 46.954]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.404500000000002, 40.015, 46.9465]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.225500000000002, 40.285, 46.8835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.094000000000001, 40.308499999999995, 46.876]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.906, 40.4615, 46.803999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.7735, 40.472, 46.796499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.5765, 40.507999999999996, 46.73349999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.443999999999999, 40.5055, 46.72599999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.255999999999998, 40.4245, 46.653999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.124999999999998, 40.408500000000004, 46.646499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.955, 40.201499999999996, 46.583499999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.8265, 40.1725, 46.57599999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.6835, 39.8575, 46.504000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.5585, 39.8155, 46.496500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.4515, 39.3745, 46.4335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.332, 39.3195, 46.426]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.288, 38.7705, 46.354000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.176500000000001, 38.703, 46.346500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.2135000000000002, 38.037000000000006, 46.283500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.112, 37.9575, 46.276]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.248, 37.1925, 46.20400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.1580000000000004, 37.102000000000004, 46.19650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.4020000000000001, 36.238, 46.133500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.3255000000000001, 36.137, 46.126000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.7045000000000001, 35.18300000000001, 46.054]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.6450000000000001, 35.07300000000001, 46.0465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.19500000000000003, 34.047000000000004, 45.9835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.16150000000000003, 33.929500000000004, 45.976]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0085, 32.840500000000006, 45.904]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 32.717, 45.8965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 31.583, 45.8335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 31.455, 45.826]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 30.285, 45.754000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 30.1535, 45.746500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 28.956500000000002, 45.6835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 28.822000000000003, 45.676]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 27.598000000000003, 45.604]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 27.461000000000002, 45.5965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 26.219, 45.533500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 26.0805, 45.526]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 24.829500000000003, 45.454]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 24.690000000000005, 45.4465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 23.43, 45.383500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 23.2895, 45.376000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 22.0205, 45.303999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 21.8795, 45.296499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 20.610500000000002, 45.2335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 20.4695, 45.226]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 19.200499999999998, 45.153999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 19.0595, 45.146499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 17.790499999999998, 45.0835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 17.65, 45.076]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 16.39, 45.004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 16.25, 44.9965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 14.990000000000002, 44.933499999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 14.8505, 44.925999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 13.599499999999999, 44.854]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 13.4615, 44.8465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 12.2285, 44.7835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 12.092500000000001, 44.775999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 10.877500000000001, 44.70400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 10.743500000000001, 44.69650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 9.5465, 44.633500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 9.415, 44.626000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 8.245000000000001, 44.554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 8.1165, 44.5465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 6.9735000000000005, 44.4835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 6.848000000000001, 44.476]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 5.731999999999999, 44.404]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 5.609999999999999, 44.3965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 4.529999999999999, 44.3335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 4.4125, 44.326]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.3775, 44.254000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.265, 44.246500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.2750000000000004, 44.1835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.168, 44.176]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 1.2320000000000002, 44.104000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 1.131, 44.096500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.249, 44.033500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 0.19000000000000003, 44.026]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.010000000000000002, 43.95400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.066, 0.0, 43.94650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.2540000000000002, 0.0, 43.883500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.3865000000000003, 0.0, 43.876000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.5835, 0.0, 43.804]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.7165, 0.0, 43.7965]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.9135, 0.0, 43.7335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.0465, 0.0, 43.726]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2435, 0.0, 43.653999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.3765, 0.0, 43.646499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.5735, 0.0, 43.5835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.7065, 0.0, 43.576]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.9035, 0.0, 43.504]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.0365, 0.0, 43.4965]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.233500000000001, 0.0, 43.4335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3665, 0.0, 43.426]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.5635, 0.0, 43.354]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.696, 0.0, 43.3465]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.883999999999999, 0.0, 43.283500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.016499999999999, 0.0, 43.276]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.2135, 0.0, 43.204]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.3465, 0.0, 43.1965]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5435, 0.0, 43.1335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.676499999999999, 0.0, 43.126]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.8735, 0.0, 43.053999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.0065, 0.0, 43.046499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.2035, 0.0, 42.98349999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.3365, 0.0, 42.97599999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.533500000000004, 0.0, 42.903999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.666500000000003, 0.0, 42.896499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.863500000000002, 0.0, 42.833499999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.9965, 0.0, 42.82599999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.1935, 0.0, 42.754000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.3265, 0.0, 42.746500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.5235, 0.0, 42.6835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.6565, 0.0, 42.676]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.853500000000004, 0.0, 42.604000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.986500000000003, 0.0, 42.596500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.183500000000002, 0.0, 42.533500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.3165, 0.0, 42.526]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.5135, 0.0, 42.45400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.6465, 0.0, 42.44650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.8435, 0.0, 42.383500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.9765, 0.0, 42.376000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.173499999999997, 0.0, 42.304]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.3065, 0.0, 42.2965]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.503500000000003, 0.0, 42.2335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.6365, 0.0, 42.226]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.8335, 0.0, 42.154]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.9665, 0.0, 42.1465]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.1635, 0.0, 42.0835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.296499999999995, 0.0, 42.076]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.493500000000004, 0.0, 42.004000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.6265, 0.0, 41.996500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.8235, 0.0, 41.9335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.956500000000005, 0.0, 41.926]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.153499999999994, 0.0, 41.854]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.2865, 0.0, 41.8465]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.4835, 0.0, 41.783500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.6165, 0.0, 41.776]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.813500000000005, 0.0, 41.704]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.9465, 0.0, 41.6965]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.143499999999996, 0.0, 41.633500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.2765, 0.0, 41.626000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.4735, 0.0, 41.553999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.606500000000004, 0.0, 41.546499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.8035, 0.0, 41.4835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.936499999999995, 0.0, 41.476]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.133500000000005, 0.0, 41.403999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.26650000000001, 0.0, 41.396499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.4635, 0.0, 41.3335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.596500000000006, 0.0, 41.326]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.793499999999995, 0.0, 41.254]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.9265, 0.0, 41.2465]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.1235, 0.0, 41.183499999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.2305, 0.045000000000000005, 41.175999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.9595, 0.8550000000000001, 41.104]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 0.9735, 41.0965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 2.2965, 41.0335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 2.4435000000000002, 41.025999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 3.7664999999999997, 40.95400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 3.9130000000000003, 40.94650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 5.226999999999999, 40.883500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 5.3735, 40.876000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 6.6965, 40.804]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 6.8435, 40.7965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 8.166500000000001, 40.7335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 8.313, 40.726]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 9.627, 40.654]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 9.7735, 40.6465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 11.0965, 40.5835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 11.243500000000001, 40.576]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 12.566500000000001, 40.504000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 12.713500000000002, 40.496500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 14.0365, 40.4335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 14.183, 40.426]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.497, 40.354000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.6435, 40.346500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 16.9665, 40.283500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 17.113500000000002, 40.276]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 18.436500000000002, 40.20400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 18.583000000000002, 40.19650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 19.897, 40.133500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 20.043499999999998, 40.126000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 21.366500000000002, 40.054]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 21.513500000000004, 40.0465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 22.8365, 39.9835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 22.983, 39.976]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 24.297, 39.903999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 24.4435, 39.896499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 25.7665, 39.8335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 25.9135, 39.826]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 27.2365, 39.754]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 27.383000000000003, 39.7465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 28.697000000000003, 39.6835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 28.8435, 39.676]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 30.1665, 39.604]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 30.313499999999998, 39.5965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 31.6365, 39.533500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 31.783, 39.526]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 33.097, 39.454]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 33.243500000000004, 39.4465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 34.566500000000005, 39.3835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 34.7135, 39.376]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 36.036500000000004, 39.303999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 36.183, 39.296499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 37.497, 39.23349999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 37.6435, 39.22599999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 38.9665, 39.153999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 39.1135, 39.146499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 40.436499999999995, 39.083499999999994]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 40.583, 39.07599999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 41.897000000000006, 39.004000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 42.0435, 38.996500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 43.366499999999995, 38.9335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 43.51349999999999, 38.926]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 44.836499999999994, 38.854000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 44.983, 38.846500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 46.297, 38.783500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 46.4435, 38.776]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 47.76650000000001, 38.70400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 47.913500000000006, 38.69650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 49.23650000000001, 38.633500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.96, 49.344500000000004, 38.626000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.24, 49.9655, 38.554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.1265, 50.0, 38.5465]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.8035, 50.0, 38.4835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.657000000000004, 50.0, 38.476]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.343, 50.0, 38.404]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.1965, 50.0, 38.3965]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.8735, 50.0, 38.3335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.727000000000004, 50.0, 38.326]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.41300000000001, 50.0, 38.254000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.26650000000001, 50.0, 38.246500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.9435, 50.0, 38.1835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.797, 50.0, 38.176]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.483, 50.0, 38.104]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.3365, 50.0, 38.0965]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.0135, 50.0, 38.033500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.867, 50.0, 38.026]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.553, 50.0, 37.954]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.4065, 50.0, 37.9465]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.0835, 50.0, 37.883500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.937, 50.0, 37.876000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.623, 50.0, 37.803999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.4765, 50.0, 37.796499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.1535, 50.0, 37.7335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.007, 50.0, 37.726]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.693, 50.0, 37.653999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.5465, 50.0, 37.646499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.223499999999998, 50.0, 37.5835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.076999999999998, 50.0, 37.576]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.763, 50.0, 37.504]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.616500000000002, 50.0, 37.4965]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.2935, 50.0, 37.433499999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.147000000000002, 50.0, 37.425999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.833000000000002, 50.0, 37.354]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.686500000000002, 50.0, 37.3465]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.363500000000002, 50.0, 37.2835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.217, 50.0, 37.275999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.903, 50.0, 37.20400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.7565, 50.0, 37.19650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.4335, 50.0, 37.133500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.287, 50.0, 37.126000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.973, 50.0, 37.054]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.8265, 50.0, 37.0465]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.5035, 50.0, 36.9835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.357, 50.0, 36.976]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.043, 50.0, 36.904]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.8965, 50.0, 36.8965]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.573500000000001, 50.0, 36.8335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.427000000000001, 50.0, 36.826]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.113, 50.0, 36.754000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.9665, 50.0, 36.746500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.643500000000001, 50.0, 36.6835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.497, 50.0, 36.676]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.183, 50.0, 36.604000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.0365, 50.0, 36.596500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7135, 50.0, 36.533500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.567, 50.0, 36.526]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.253, 50.0, 36.45400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.1065, 50.0, 36.44650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.7835, 50.0, 36.383500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.637, 50.0, 36.376000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.323, 50.0, 36.304]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.176500000000001, 50.0, 36.2965]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.8534999999999995, 50.0, 36.2335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.707, 50.0, 36.226]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3930000000000002, 50.0, 36.153999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.2465, 50.0, 36.146499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9235, 50.0, 36.0835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.8075, 49.96, 36.076]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0425, 49.24, 36.004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 49.1265, 35.9965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 47.8035, 35.9335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 47.657000000000004, 35.926]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 46.343, 35.854]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 46.1965, 35.8465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 44.8735, 35.783500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 44.727000000000004, 35.776]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 43.41300000000001, 35.704]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 43.26650000000001, 35.6965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 41.9435, 35.6335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 41.797, 35.626]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 40.483, 35.553999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 40.3365, 35.546499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 39.0135, 35.4835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 38.867, 35.476]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 37.553, 35.403999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 37.4065, 35.396499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 36.0835, 35.3335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 35.937, 35.326]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 34.623, 35.254000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 34.4765, 35.246500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 33.1535, 35.1835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 33.007, 35.176]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 31.693, 35.104000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 31.5465, 35.096500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 30.223499999999998, 35.033500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 30.076999999999998, 35.026]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 28.763, 34.954]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 28.616500000000002, 34.9465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 27.2935, 34.883500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 27.147000000000002, 34.876000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.833000000000002, 34.803999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.686500000000002, 34.796499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 24.363500000000002, 34.7335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 24.217, 34.726]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 22.903, 34.653999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 22.7565, 34.646499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 21.4335, 34.5835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 21.287, 34.576]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 19.973, 34.504]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 19.8265, 34.4965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 18.5035, 34.4335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 18.357, 34.426]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 17.043, 34.354]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 16.8965, 34.346500000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 15.573500000000001, 34.283500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 15.427000000000001, 34.276]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 14.113, 34.20400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 13.9665, 34.19650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 12.643500000000001, 34.133500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 12.497, 34.126000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 11.183, 34.054]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 11.0365, 34.0465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 9.7135, 33.9835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 9.567, 33.976]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 8.253, 33.903999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 8.1065, 33.896499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 6.7835, 33.8335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 6.637, 33.826]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 5.323, 33.754]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 5.176500000000001, 33.7465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.8534999999999995, 33.6835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.707, 33.676]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.3930000000000002, 33.604]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.2465, 33.5965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.9235, 33.533500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.04000000000000001, 0.8075, 33.526]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.7600000000000001, 0.0425, 33.45400000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.8735000000000002, 0.0, 33.44650000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1965000000000003, 0.0, 33.383500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3435, 0.0, 33.376000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6665, 0.0, 33.304]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.813, 0.0, 33.2965]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.127000000000001, 0.0, 33.2335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2735, 0.0, 33.226]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.5965, 0.0, 33.154]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.7435, 0.0, 33.1465]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.066500000000001, 0.0, 33.0835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.213000000000001, 0.0, 33.076]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.527000000000001, 0.0, 33.004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.6735, 0.0, 32.9965]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.996500000000001, 0.0, 32.9335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.143500000000001, 0.0, 32.926]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.4665, 0.0, 32.854]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.613, 0.0, 32.8465]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.927, 0.0, 32.783500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.0735, 0.0, 32.776]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.3965, 0.0, 32.704]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.5435, 0.0, 32.6965]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.866500000000002, 0.0, 32.633500000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.013, 0.0, 32.626000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.326999999999998, 0.0, 32.554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.473499999999998, 0.0, 32.546499999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.7965, 0.0, 32.4835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.943500000000004, 0.0, 32.476]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.2665, 0.0, 32.403999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.413, 0.0, 32.3965]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.727, 0.0, 32.3335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.8735, 0.0, 32.326]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.1965, 0.0, 32.254000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.3435, 0.0, 32.246500000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.6665, 0.0, 32.1835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.813000000000002, 0.0, 32.176]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.127000000000002, 0.0, 32.104]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.273500000000002, 0.0, 32.0965]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.596500000000002, 0.0, 32.033500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.7435, 0.0, 32.026]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.0665, 0.0, 31.954]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.213, 0.0, 31.9465]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.527, 0.0, 31.8835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.6735, 0.0, 31.876]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.996500000000005, 0.0, 31.804000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.1435, 0.0, 31.7965]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.466499999999996, 0.0, 31.733500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.613, 0.0, 31.726000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.927, 0.0, 31.654]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.073499999999996, 0.0, 31.6465]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.396499999999996, 0.0, 31.5835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.5435, 0.0, 31.576]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.8665, 0.0, 31.504]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.013, 0.0, 31.4965]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.327, 0.0, 31.4335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.4735, 0.0, 31.426]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.7965, 0.0, 31.354000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.9435, 0.0, 31.346500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.26650000000001, 0.0, 31.2835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.41300000000001, 0.0, 31.276000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.727000000000004, 0.0, 31.204]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.8735, 0.0, 31.1965]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.1965, 0.0, 31.133499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.3435, 0.0, 31.125999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.6665, 0.0, 31.054000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.813, 0.0, 31.0465]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.127, 0.0, 30.983500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.24, 0.04000000000000001, 30.976000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.96, 0.7600000000000001, 30.904]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 0.8735000000000002, 30.8965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 2.1965000000000003, 30.8335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 2.3435, 30.826]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 3.6665, 30.754]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 3.813, 30.7465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 5.127000000000001, 30.683500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 5.2735, 30.676000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 6.5965, 30.604000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 6.7435, 30.596500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 8.066500000000001, 30.5335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 8.213000000000001, 30.526]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 9.527000000000001, 30.454]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 9.6735, 30.4465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 10.996500000000001, 30.383499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 11.143500000000001, 30.375999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 12.4665, 30.304]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 12.613, 30.2965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 13.927, 30.2335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 14.0735, 30.226]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.3965, 30.153999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.5435, 30.146499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 16.866500000000002, 30.0835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 17.013, 30.076]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 18.326999999999998, 30.004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 18.473499999999998, 29.9965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 19.7965, 29.933500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 19.943500000000004, 29.926000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 21.2665, 29.854000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 21.413, 29.846500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 22.727, 29.783500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 22.8735, 29.776000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 24.1965, 29.704]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 24.3435, 29.6965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 25.6665, 29.633499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 25.813000000000002, 29.625999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 27.127000000000002, 29.554000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 27.273500000000002, 29.5465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 28.596500000000002, 29.4835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 28.7435, 29.476]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 30.0665, 29.404]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 30.213, 29.3965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 31.527, 29.333499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 31.6735, 29.326]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 32.996500000000005, 29.253999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 33.1435, 29.246499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 34.466499999999996, 29.183500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 34.613, 29.176000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 35.927, 29.104000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 36.073499999999996, 29.096500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 37.396499999999996, 29.033500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 37.5435, 29.026000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 38.8665, 28.954]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 39.013, 28.9465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 40.327, 28.8835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 40.4735, 28.876]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 41.7965, 28.804000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 41.9435, 28.7965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 43.26650000000001, 28.7335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 43.41300000000001, 28.726]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 44.727000000000004, 28.654]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 44.8735, 28.6465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 46.1965, 28.583499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 46.3435, 28.575999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 47.6665, 28.504]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 47.813, 28.4965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 49.127, 28.4335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.96, 49.24, 28.426000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.24, 49.96, 28.354]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.1265, 50.0, 28.3465]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.8035, 50.0, 28.283500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.657000000000004, 50.0, 28.276000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.343, 50.0, 28.204]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.1965, 50.0, 28.1965]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.8735, 50.0, 28.1335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.727000000000004, 50.0, 28.126]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.41300000000001, 50.0, 28.054000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.26650000000001, 50.0, 28.0465]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.9435, 50.0, 27.983500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.797, 50.0, 27.976000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.483, 50.0, 27.904]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.3365, 50.0, 27.8965]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.0135, 50.0, 27.8335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.867, 50.0, 27.826]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.553, 50.0, 27.754]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.4065, 50.0, 27.7465]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.0835, 50.0, 27.6835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.937, 50.0, 27.676]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.623, 50.0, 27.604000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.4765, 50.0, 27.596500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.1535, 50.0, 27.5335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.007, 50.0, 27.526000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.693, 50.0, 27.454]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.5465, 50.0, 27.4465]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.223499999999998, 50.0, 27.383499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.076999999999998, 50.0, 27.375999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.763, 50.0, 27.304000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.616500000000002, 50.0, 27.2965]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.2935, 50.0, 27.233500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.147000000000002, 50.0, 27.226000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.833000000000002, 50.0, 27.154]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.686500000000002, 50.0, 27.1465]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.363500000000002, 50.0, 27.0835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.217, 50.0, 27.076]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.903, 50.0, 27.004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.7565, 50.0, 26.9965]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.4335, 50.0, 26.933500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.287, 50.0, 26.926000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.973, 50.0, 26.854000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.8265, 50.0, 26.846500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.5035, 50.0, 26.7835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.357, 50.0, 26.776]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.043, 50.0, 26.704]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.8965, 50.0, 26.6965]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.573500000000001, 50.0, 26.633499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.427000000000001, 50.0, 26.625999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.113, 50.0, 26.554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.9665, 50.0, 26.5465]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.643500000000001, 50.0, 26.4835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.497, 50.0, 26.476]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.183, 50.0, 26.403999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.0365, 50.0, 26.396499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7135, 50.0, 26.3335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.567, 50.0, 26.326]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.253, 50.0, 26.254]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.1065, 50.0, 26.2465]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.7835, 50.0, 26.183500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.637, 50.0, 26.176000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.323, 50.0, 26.104000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.176500000000001, 50.0, 26.096500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.8534999999999995, 50.0, 26.033500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.707, 50.0, 26.026000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3930000000000002, 50.0, 25.954]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.2465, 50.0, 25.9465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9235, 50.0, 25.883499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.8075, 49.96, 25.875999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0425, 49.24, 25.804000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 49.1265, 25.7965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 47.8035, 25.7335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 47.657000000000004, 25.726]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 46.343, 25.654]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 46.1965, 25.6465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 44.8735, 25.583499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 44.727000000000004, 25.576]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 43.41300000000001, 25.503999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 43.26650000000001, 25.496499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 41.9435, 25.433500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 41.797, 25.426000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 40.483, 25.354000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 40.3365, 25.346500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 39.0135, 25.283500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 38.867, 25.276000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 37.553, 25.204]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 37.4065, 25.1965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 36.0835, 25.1335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 35.937, 25.126]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 34.623, 25.054000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 34.4765, 25.0465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 33.1535, 24.9835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 33.007, 24.976]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 31.693, 24.904]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 31.5465, 24.8965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 30.223499999999998, 24.833499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 30.076999999999998, 24.825999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 28.763, 24.754]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 28.616500000000002, 24.7465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 27.2935, 24.6835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 27.147000000000002, 24.676000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.833000000000002, 24.604]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.686500000000002, 24.5965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 24.363500000000002, 24.533500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 24.217, 24.526000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 22.903, 24.454]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 22.7565, 24.4465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 21.4335, 24.3835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 21.287, 24.376]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 19.973, 24.304000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 19.8265, 24.2965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 18.5035, 24.233500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 18.357, 24.226000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 17.043, 24.154]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 16.8965, 24.1465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 15.573500000000001, 24.0835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 15.427000000000001, 24.076]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 14.113, 24.004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 13.9665, 23.9965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 12.643500000000001, 23.9335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 12.497, 23.926]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 11.183, 23.854000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 11.0365, 23.846500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 9.7135, 23.7835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 9.567, 23.776]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 8.253, 23.703999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 8.1065, 23.696499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 6.7835, 23.633499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 6.637, 23.625999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 5.323, 23.554000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 5.176500000000001, 23.5465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.8534999999999995, 23.483500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.707, 23.476000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.3930000000000002, 23.404]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.2465, 23.3965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.9235, 23.3335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.04000000000000001, 0.8075, 23.326]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.7600000000000001, 0.0425, 23.254]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.8735000000000002, 0.0, 23.2465]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1965000000000003, 0.0, 23.183500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3435, 0.0, 23.176000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6665, 0.0, 23.104000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.813, 0.0, 23.096500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.127000000000001, 0.0, 23.0335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2735, 0.0, 23.026]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.5965, 0.0, 22.954]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.7435, 0.0, 22.9465]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.066500000000001, 0.0, 22.883499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.213000000000001, 0.0, 22.875999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.527000000000001, 0.0, 22.804]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.6735, 0.0, 22.796499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.996500000000001, 0.0, 22.7335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.143500000000001, 0.0, 22.726]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.4665, 0.0, 22.653999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.613, 0.0, 22.646499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.927, 0.0, 22.5835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.0735, 0.0, 22.576]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.3965, 0.0, 22.504]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.5435, 0.0, 22.4965]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.866500000000002, 0.0, 22.433500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.013, 0.0, 22.426000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.326999999999998, 0.0, 22.354000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.473499999999998, 0.0, 22.346500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.7965, 0.0, 22.283500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.943500000000004, 0.0, 22.276000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.2665, 0.0, 22.204]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.413, 0.0, 22.1965]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.727, 0.0, 22.133499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.8735, 0.0, 22.125999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.1965, 0.0, 22.054000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.3435, 0.0, 22.0465]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.6665, 0.0, 21.9835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.813000000000002, 0.0, 21.976]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.127000000000002, 0.0, 21.904]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.273500000000002, 0.0, 21.8965]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.596500000000002, 0.0, 21.833499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.7435, 0.0, 21.825999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.0665, 0.0, 21.753999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.213, 0.0, 21.746499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.527, 0.0, 21.683500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.6735, 0.0, 21.676000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.996500000000005, 0.0, 21.604000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.1435, 0.0, 21.596500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.466499999999996, 0.0, 21.533500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.613, 0.0, 21.526000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.927, 0.0, 21.454]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.073499999999996, 0.0, 21.4465]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.396499999999996, 0.0, 21.3835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.5435, 0.0, 21.376]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.8665, 0.0, 21.304000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.013, 0.0, 21.2965]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.327, 0.0, 21.2335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.4735, 0.0, 21.226]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.7965, 0.0, 21.154]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.9435, 0.0, 21.1465]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.26650000000001, 0.0, 21.083499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.41300000000001, 0.0, 21.075999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.727000000000004, 0.0, 21.004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.8735, 0.0, 20.9965]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.1965, 0.0, 20.9335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.3435, 0.0, 20.926]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.6665, 0.0, 20.854]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.813, 0.0, 20.8465]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.127, 0.0, 20.783500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.24, 0.04000000000000001, 20.776000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.96, 0.7600000000000001, 20.704]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 0.8735000000000002, 20.6965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 2.1965000000000003, 20.6335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 2.3435, 20.626]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 3.6665, 20.554000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 3.813, 20.5465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 5.127000000000001, 20.483500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 5.2735, 20.476000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 6.5965, 20.404]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 6.7435, 20.3965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 8.066500000000001, 20.3335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 8.213000000000001, 20.326]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 9.527000000000001, 20.254]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 9.6735, 20.2465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 10.996500000000001, 20.1835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 11.143500000000001, 20.176]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 12.4665, 20.104000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 12.613, 20.096500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 13.927, 20.0335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 14.0735, 20.026]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.3965, 19.953999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.5435, 19.946499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 16.866500000000002, 19.883499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 17.013, 19.875999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 18.326999999999998, 19.804000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 18.473499999999998, 19.7965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 19.7965, 19.733500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 19.943500000000004, 19.726000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 21.2665, 19.654]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 21.413, 19.6465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 22.727, 19.5835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 22.8735, 19.576]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 24.1965, 19.504]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 24.3435, 19.4965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 25.6665, 19.433500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 25.813000000000002, 19.426000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 27.127000000000002, 19.354000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 27.273500000000002, 19.346500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 28.596500000000002, 19.2835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 28.7435, 19.276]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 30.0665, 19.204]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 30.213, 19.1965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 31.527, 19.133499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 31.6735, 19.125999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 32.996500000000005, 19.054]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 33.1435, 19.046499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 34.466499999999996, 18.9835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 34.613, 18.976]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 35.927, 18.903999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 36.073499999999996, 18.896499999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 37.396499999999996, 18.8335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 37.5435, 18.826]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 38.8665, 18.754]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 39.013, 18.7465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 40.327, 18.683500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 40.4735, 18.676000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 41.7965, 18.604000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 41.9435, 18.596500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 43.26650000000001, 18.533500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 43.41300000000001, 18.526000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 44.727000000000004, 18.454]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 44.8735, 18.4465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 46.1965, 18.383499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 46.3435, 18.375999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 47.6665, 18.304000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 47.813, 18.2965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 49.127, 18.2335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.96, 49.24, 18.226]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.24, 49.96, 18.154]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.1265, 50.0, 18.1465]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.8035, 50.0, 18.083499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.657000000000004, 50.0, 18.075999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.343, 50.0, 18.003999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.1965, 50.0, 17.996499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.8735, 50.0, 17.933500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.727000000000004, 50.0, 17.926000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.41300000000001, 50.0, 17.854000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.26650000000001, 50.0, 17.846500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.9435, 50.0, 17.783500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.797, 50.0, 17.776000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.483, 50.0, 17.704]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.3365, 50.0, 17.6965]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.0135, 50.0, 17.633499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.867, 50.0, 17.625999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.553, 50.0, 17.554000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.4065, 50.0, 17.5465]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.0835, 50.0, 17.4835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.937, 50.0, 17.476]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.623, 50.0, 17.403999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.4765, 50.0, 17.3965]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.1535, 50.0, 17.3335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.007, 50.0, 17.326]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.693, 50.0, 17.254]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.5465, 50.0, 17.2465]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.223499999999998, 50.0, 17.1835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.076999999999998, 50.0, 17.176]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.763, 50.0, 17.104000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.616500000000002, 50.0, 17.096500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.2935, 50.0, 17.033500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.147000000000002, 50.0, 17.026000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.833000000000002, 50.0, 16.954]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.686500000000002, 50.0, 16.9465]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.363500000000002, 50.0, 16.8835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.217, 50.0, 16.876]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.903, 50.0, 16.804000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.7565, 50.0, 16.7965]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.4335, 50.0, 16.7335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.287, 50.0, 16.726]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.973, 50.0, 16.654]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.8265, 50.0, 16.6465]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.5035, 50.0, 16.583499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.357, 50.0, 16.576]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.043, 50.0, 16.503999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.8965, 50.0, 16.4965]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.573500000000001, 50.0, 16.433500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.427000000000001, 50.0, 16.426000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.113, 50.0, 16.354000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.9665, 50.0, 16.346500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.643500000000001, 50.0, 16.2835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.497, 50.0, 16.276]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.183, 50.0, 16.204]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.0365, 50.0, 16.1965]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7135, 50.0, 16.133499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.567, 50.0, 16.125999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.253, 50.0, 16.054000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.1065, 50.0, 16.0465]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.7835, 50.0, 15.983500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.637, 50.0, 15.976000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.323, 50.0, 15.904]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.176500000000001, 50.0, 15.8965]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.8534999999999995, 50.0, 15.8335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.707, 50.0, 15.826]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3930000000000002, 50.0, 15.754000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.2465, 50.0, 15.746500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9235, 50.0, 15.6835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.8075, 49.96, 15.676]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0425, 49.24, 15.604]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 49.1265, 15.596499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 47.8035, 15.5335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 47.657000000000004, 15.526]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 46.343, 15.453999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 46.1965, 15.4465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 44.8735, 15.383500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 44.727000000000004, 15.376000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 43.41300000000001, 15.304000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 43.26650000000001, 15.296500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 41.9435, 15.233500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 41.797, 15.226]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 40.483, 15.154]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 40.3365, 15.1465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 39.0135, 15.0835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 38.867, 15.076]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 37.553, 15.004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 37.4065, 14.996500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 36.0835, 14.933499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 35.937, 14.926]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 34.623, 14.854000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 34.4765, 14.8465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 33.1535, 14.7835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 33.007, 14.776]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 31.693, 14.704]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 31.5465, 14.6965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 30.223499999999998, 14.633500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 30.076999999999998, 14.626000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 28.763, 14.554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 28.616500000000002, 14.546500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 27.2935, 14.4835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 27.147000000000002, 14.476]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.833000000000002, 14.404000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.686500000000002, 14.396500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 24.363500000000002, 14.3335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 24.217, 14.326]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 22.903, 14.254000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 22.7565, 14.246500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 21.4335, 14.1835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 21.287, 14.176]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 19.973, 14.104]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 19.8265, 14.096499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 18.5035, 14.033499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 18.357, 14.026]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 17.043, 13.954]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 16.8965, 13.9465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 15.573500000000001, 13.883500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 15.427000000000001, 13.876000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 14.113, 13.804000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 13.9665, 13.796500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 12.643500000000001, 13.733500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 12.497, 13.726]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 11.183, 13.654]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 11.0365, 13.6465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 9.7135, 13.583499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 9.567, 13.576]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 8.253, 13.504000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 8.1065, 13.496500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 6.7835, 13.4335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 6.637, 13.426]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 5.323, 13.354000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 5.176500000000001, 13.3465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.8534999999999995, 13.2835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.707, 13.276]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.3930000000000002, 13.203999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.2465, 13.196499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.9235, 13.1335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.04000000000000001, 0.8075, 13.126000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.7600000000000001, 0.0425, 13.054000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.8735000000000002, 0.0, 13.046500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1965000000000003, 0.0, 12.983500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3435, 0.0, 12.976]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6665, 0.0, 12.904000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.813, 0.0, 12.896500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.127000000000001, 0.0, 12.8335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2735, 0.0, 12.826]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.5965, 0.0, 12.754]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.7435, 0.0, 12.7465]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.066500000000001, 0.0, 12.6835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.213000000000001, 0.0, 12.676000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.527000000000001, 0.0, 12.604]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.6735, 0.0, 12.596499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.996500000000001, 0.0, 12.5335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.143500000000001, 0.0, 12.526]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.4665, 0.0, 12.454]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.613, 0.0, 12.4465]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.927, 0.0, 12.383500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.0735, 0.0, 12.376000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.3965, 0.0, 12.304]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.5435, 0.0, 12.2965]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.866500000000002, 0.0, 12.233500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.013, 0.0, 12.226000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.326999999999998, 0.0, 12.154]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.473499999999998, 0.0, 12.1465]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.7965, 0.0, 12.0835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.943500000000004, 0.0, 12.076]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.2665, 0.0, 12.004000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.413, 0.0, 11.996500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.727, 0.0, 11.9335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.8735, 0.0, 11.926]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.1965, 0.0, 11.854]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.3435, 0.0, 11.846499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.6665, 0.0, 11.7835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.813000000000002, 0.0, 11.776]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.127000000000002, 0.0, 11.703999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.273500000000002, 0.0, 11.696499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.596500000000002, 0.0, 11.6335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.7435, 0.0, 11.626000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.0665, 0.0, 11.554000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.213, 0.0, 11.546500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.527, 0.0, 11.483500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.6735, 0.0, 11.476]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.996500000000005, 0.0, 11.404]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.1435, 0.0, 11.3965]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.466499999999996, 0.0, 11.3335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.613, 0.0, 11.326]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.927, 0.0, 11.254]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.073499999999996, 0.0, 11.2465]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.396499999999996, 0.0, 11.183499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.5435, 0.0, 11.176]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.8665, 0.0, 11.104000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.013, 0.0, 11.0965]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.327, 0.0, 11.0335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.4735, 0.0, 11.026]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.7965, 0.0, 10.954]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.9435, 0.0, 10.9465]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.26650000000001, 0.0, 10.883500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.41300000000001, 0.0, 10.876000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.727000000000004, 0.0, 10.804]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.8735, 0.0, 10.7965]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.1965, 0.0, 10.7335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.3435, 0.0, 10.726]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.6665, 0.0, 10.654000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.813, 0.0, 10.646500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.127, 0.0, 10.5835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.24, 0.04000000000000001, 10.576]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.96, 0.7600000000000001, 10.504000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 0.8735000000000002, 10.496500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 2.1965000000000003, 10.4335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 2.3435, 10.426]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 3.6665, 10.354]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 3.813, 10.346499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 5.127000000000001, 10.283499999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 5.2735, 10.275999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 6.5965, 10.203999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 6.7435, 10.1965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 8.066500000000001, 10.133500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 8.213000000000001, 10.126000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 9.527000000000001, 10.054000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 9.6735, 10.046500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 10.996500000000001, 9.983500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 11.143500000000001, 9.976]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 12.4665, 9.904]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 12.613, 9.8965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 13.927, 9.833499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 14.0735, 9.825999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 15.3965, 9.754]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 15.5435, 9.746500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 16.866500000000002, 9.6835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 17.013, 9.676]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 18.326999999999998, 9.604000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 18.473499999999998, 9.5965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 19.7965, 9.5335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 19.943500000000004, 9.526]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 21.2665, 9.453999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 21.413, 9.446499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 22.727, 9.3835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 22.8735, 9.376]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 24.1965, 9.304]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 24.3435, 9.296500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 25.6665, 9.233500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 25.813000000000002, 9.226]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 27.127000000000002, 9.154000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 27.273500000000002, 9.146500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 28.596500000000002, 9.0835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 28.7435, 9.076]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 30.0665, 9.004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 30.213, 8.9965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 31.527, 8.9335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 31.6735, 8.926]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 32.996500000000005, 8.854]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 33.1435, 8.846499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 34.466499999999996, 8.7835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 34.613, 8.776]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 35.927, 8.703999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 36.073499999999996, 8.696499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 37.396499999999996, 8.633500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 37.5435, 8.626000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 38.8665, 8.554000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 39.013, 8.546500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 40.327, 8.483500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 40.4735, 8.476]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 41.7965, 8.404]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 41.9435, 8.3965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 43.26650000000001, 8.3335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 43.41300000000001, 8.326]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 44.727000000000004, 8.254]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 44.8735, 8.2465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 46.1965, 8.1835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 46.3435, 8.176]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 47.6665, 8.104]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 47.813, 8.0965]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 49.127, 8.0335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.96, 49.24, 8.026]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.24, 49.96, 7.954000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.1265, 50.0, 7.9465]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.8035, 50.0, 7.8835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.657000000000004, 50.0, 7.8759999999999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.343, 50.0, 7.803999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.1965, 50.0, 7.7965]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.8735, 50.0, 7.733500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.727000000000004, 50.0, 7.726000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.41300000000001, 50.0, 7.654000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.26650000000001, 50.0, 7.6465000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.9435, 50.0, 7.5835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.797, 50.0, 7.5760000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.483, 50.0, 7.504]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.3365, 50.0, 7.4965]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.0135, 50.0, 7.4335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.867, 50.0, 7.426]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.553, 50.0, 7.354]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.4065, 50.0, 7.346500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.0835, 50.0, 7.2835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.937, 50.0, 7.276000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.623, 50.0, 7.204000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.4765, 50.0, 7.1965]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.1535, 50.0, 7.1335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.007, 50.0, 7.1259999999999994]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.693, 50.0, 7.054]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.5465, 50.0, 7.0465]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.223499999999998, 50.0, 6.983500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.076999999999998, 50.0, 6.976000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.763, 50.0, 6.904000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.616500000000002, 50.0, 6.896500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.2935, 50.0, 6.833500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.147000000000002, 50.0, 6.8260000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.833000000000002, 50.0, 6.7540000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.686500000000002, 50.0, 6.7465]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.363500000000002, 50.0, 6.6834999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.217, 50.0, 6.675999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.903, 50.0, 6.603999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.7565, 50.0, 6.5965]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.4335, 50.0, 6.533500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.287, 50.0, 6.526000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.973, 50.0, 6.454000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.8265, 50.0, 6.4465]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.5035, 50.0, 6.3835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.357, 50.0, 6.376]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.043, 50.0, 6.304]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.8965, 50.0, 6.2965]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.573500000000001, 50.0, 6.2335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.427000000000001, 50.0, 6.226]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.113, 50.0, 6.154]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.9665, 50.0, 6.1465000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.643500000000001, 50.0, 6.083500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.497, 50.0, 6.0760000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.183, 50.0, 6.0040000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.0365, 50.0, 5.9965]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.7135, 50.0, 5.9334999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.567, 50.0, 5.926]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.253, 50.0, 5.853999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.1065, 50.0, 5.8465]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.7835, 50.0, 5.7835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.637, 50.0, 5.776]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.323, 50.0, 5.704]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.176500000000001, 50.0, 5.6965]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.8534999999999995, 50.0, 5.6335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.707, 50.0, 5.626]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.3930000000000002, 50.0, 5.554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.2465, 50.0, 5.5465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9235, 50.0, 5.4835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.8075, 49.96, 5.476000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0425, 49.24, 5.404]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 49.1265, 5.3965000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 47.8035, 5.333500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 47.657000000000004, 5.3260000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 46.343, 5.2540000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 46.1965, 5.2465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 44.8735, 5.1834999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 44.727000000000004, 5.176]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 43.41300000000001, 5.104]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 43.26650000000001, 5.0965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 41.9435, 5.0335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 41.797, 5.026]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 40.483, 4.954]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 40.3365, 4.9465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 39.0135, 4.883500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 38.867, 4.876]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 37.553, 4.804]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 37.4065, 4.7965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 36.0835, 4.7335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 35.937, 4.726000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 34.623, 4.654000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 34.4765, 4.6465000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 33.1535, 4.5835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 33.007, 4.576]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 31.693, 4.504]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 31.5465, 4.4965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 30.223499999999998, 4.4334999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 30.076999999999998, 4.425999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 28.763, 4.353999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 28.616500000000002, 4.3465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 27.2935, 4.2835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 27.147000000000002, 4.276000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 25.833000000000002, 4.204000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 25.686500000000002, 4.1965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 24.363500000000002, 4.1335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 24.217, 4.126]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 22.903, 4.054]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 22.7565, 4.0475]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 21.4335, 4.0025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 21.287, 3.9965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 19.973, 3.9335000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 19.8265, 3.926]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 18.5035, 3.854]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 18.357, 3.8465000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 17.043, 3.7834999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 16.8965, 3.776]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 15.573500000000001, 3.704]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 15.427000000000001, 3.6965000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 14.113, 3.6334999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 13.9665, 3.626]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 12.643500000000001, 3.554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 12.497, 3.5465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 11.183, 3.4835000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 11.0365, 3.476]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 9.7135, 3.404]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 9.567, 3.3965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 8.253, 3.3335000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 8.1065, 3.3260000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 6.7835, 3.2540000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 6.637, 3.2465]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 5.323, 3.1835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 5.176500000000001, 3.176]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.8534999999999995, 3.104]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.707, 3.0965]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.3930000000000002, 3.0335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.2465, 3.026]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.9235, 2.954]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.04000000000000001, 0.8075, 2.9465000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.7600000000000001, 0.0425, 2.8835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.8735000000000002, 0.0, 2.876]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.1965000000000003, 0.0, 2.804]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3435, 0.0, 2.7965]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.6665, 0.0, 2.7335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.813, 0.0, 2.726]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.127000000000001, 0.0, 2.654]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2735, 0.0, 2.6464999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.5965, 0.0, 2.5835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.7435, 0.0, 2.576]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.066500000000001, 0.0, 2.504]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.213000000000001, 0.0, 2.4965]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.527000000000001, 0.0, 2.4335000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.6735, 0.0, 2.426]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.996500000000001, 0.0, 2.354]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.143500000000001, 0.0, 2.3465000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.4665, 0.0, 2.2835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.613, 0.0, 2.2760000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.927, 0.0, 2.204]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.0735, 0.0, 2.1965000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.3965, 0.0, 2.1335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.5435, 0.0, 2.126]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.866500000000002, 0.0, 2.054]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.013, 0.0, 2.0465]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.326999999999998, 0.0, 1.9835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.473499999999998, 0.0, 1.976]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.7965, 0.0, 1.904]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.943500000000004, 0.0, 1.8965]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.2665, 0.0, 1.8335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.413, 0.0, 1.826]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.727, 0.0, 1.754]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.8735, 0.0, 1.7465]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.1965, 0.0, 1.6835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.3435, 0.0, 1.6760000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.6665, 0.0, 1.604]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.813000000000002, 0.0, 1.5965000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.127000000000002, 0.0, 1.5335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.273500000000002, 0.0, 1.526]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.596500000000002, 0.0, 1.454]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.7435, 0.0, 1.4465]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.0665, 0.0, 1.3835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.213, 0.0, 1.376]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.527, 0.0, 1.304]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.6735, 0.0, 1.2965000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.996500000000005, 0.0, 1.2335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.1435, 0.0, 1.226]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.466499999999996, 0.0, 1.154]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.613, 0.0, 1.1464999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.927, 0.0, 1.0835000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.073499999999996, 0.0, 1.076]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.396499999999996, 0.0, 1.004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.5435, 0.0, 0.9965]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.8665, 0.0, 0.9335000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.013, 0.0, 0.926]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.327, 0.0, 0.854]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.4735, 0.0, 0.8465]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.7965, 0.0, 0.7835000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.9435, 0.0, 0.776]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.26650000000001, 0.0, 0.704]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.41300000000001, 0.0, 0.6965]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.727000000000004, 0.0, 0.6335000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.8735, 0.0, 0.6260000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.1965, 0.0, 0.554]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.3435, 0.0, 0.5465000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.6665, 0.0, 0.4835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.813, 0.0, 0.476]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.127, 0.0, 0.404]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.24, 0.04000000000000001, 0.3965]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.96, 0.7600000000000001, 0.3335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 0.8735000000000002, 0.32600000000000007]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 2.1965000000000003, 0.254]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 2.3435, 0.2465]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 3.6665, 0.1835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 3.813, 0.17600000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 5.127000000000001, 0.10400000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 5.2735, 0.09650000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 6.5965, 0.0335]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.0, 6.7115, 0.0285]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0, 7.4585, 0.0015]) cube([0.4, 0.4, 0.1], center=true);
}

