
hull() {
    translate([50.045, 50.0, 94.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.855000000000004, 50.0, 94.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.945, 50.0, 94.05499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.754999999999995, 50.0, 93.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.845, 50.0, 93.15500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.65500000000001, 50.0, 92.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.745000000000005, 50.0, 92.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.55500000000001, 50.0, 91.44500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.645, 50.0, 91.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.455000000000005, 50.0, 90.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.545, 50.0, 90.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.355000000000004, 50.0, 89.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.445, 50.0, 89.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.255, 50.0, 88.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.345, 50.0, 88.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.155, 50.0, 87.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.245000000000005, 50.0, 87.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.055, 50.0, 86.94500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.144999999999996, 50.0, 86.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.955, 50.0, 86.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.045, 50.0, 85.95500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.855, 50.0, 85.14500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.94499999999999, 50.0, 85.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.754999999999995, 50.0, 84.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.845, 50.0, 84.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.655, 50.0, 83.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.745000000000005, 50.0, 83.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.55500000000001, 50.0, 82.44500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.645, 50.0, 82.35500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.455, 50.0, 81.54500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.545, 50.0, 81.45500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.355, 50.0, 80.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.44500000000001, 50.0, 80.55499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.255, 50.0, 79.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.345, 50.0, 79.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.155, 50.0, 78.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.245, 50.0, 78.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.05499999999999, 50.0, 77.94500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.145, 50.0, 77.85500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.955, 50.0, 77.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.045, 50.0, 76.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.855, 50.0, 76.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.94500000000001, 50.0, 76.05499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.755, 50.0, 75.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.845, 50.0, 75.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.655, 50.0, 74.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.745, 50.0, 74.25500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.55499999999999, 50.0, 73.44500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.645, 50.0, 73.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.455, 50.0, 72.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.545, 50.0, 72.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.355, 50.0, 71.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.44500000000001, 50.0, 71.55499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.25500000000001, 50.0, 70.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.345, 50.0, 70.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.155, 50.0, 69.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.245, 50.0, 69.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.05499999999999, 50.0, 68.94500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.145, 50.0, 68.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.955, 50.0, 68.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.045, 50.0, 67.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.85500000000002, 50.0, 67.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.94500000000001, 50.0, 67.05499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.755, 50.0, 66.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.845, 50.0, 66.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.655, 50.0, 65.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.745, 50.0, 65.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.55499999999999, 50.0, 64.44500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.645, 50.0, 64.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.45500000000001, 50.0, 63.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.54500000000002, 50.0, 63.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.35500000000002, 50.0, 62.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.44500000000001, 50.0, 62.55500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.255, 50.0, 61.745000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.345, 50.0, 61.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.155, 50.0, 60.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.245, 50.0, 60.754999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.055, 50.0, 59.94499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.14500000000001, 50.0, 59.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.95500000000001, 50.0, 59.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.045, 50.0, 58.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.855, 50.0, 58.144999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.94500000000001, 50.0, 58.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.755, 50.0, 57.245000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.845, 50.0, 57.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.655, 50.0, 56.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.745, 50.0, 56.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.555, 50.0, 55.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.645, 50.0, 55.355000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.455, 50.0, 54.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.545, 50.0, 54.455000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.355, 50.0, 53.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.44500000000001, 50.0, 53.55500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.255, 50.0, 52.745000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.345, 50.0, 52.65500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.15500000000002, 50.0, 51.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.245, 50.0, 51.754999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.05499999999999, 50.0, 50.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.145, 50.0, 50.855000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.955, 50.0, 50.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.045, 50.0, 49.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.855, 50.0, 49.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.94500000000001, 50.0, 49.05500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.75500000000001, 50.0, 48.245000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.845, 50.0, 48.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.655, 50.0, 47.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.745, 50.0, 47.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.55499999999999, 50.0, 46.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.645, 50.0, 46.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.455, 50.0, 45.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 50.045, 45.455000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 50.855000000000004, 44.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 50.945, 44.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 51.754999999999995, 43.745000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 51.845, 43.65500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 52.65500000000001, 42.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 52.745000000000005, 42.754999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 53.55500000000001, 41.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 53.645, 41.855000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 54.455000000000005, 41.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 54.545, 40.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 55.355000000000004, 40.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 55.445, 40.05500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 56.255, 39.245000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 56.345, 39.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 57.155, 38.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 57.245000000000005, 38.254999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 58.055, 37.44499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 58.144999999999996, 37.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 58.955, 36.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 59.045, 36.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 59.855, 35.644999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 59.94499999999999, 35.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 60.754999999999995, 34.745000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 60.845, 34.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 61.655, 33.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 61.745000000000005, 33.754999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 62.55500000000001, 32.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 62.645, 32.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 63.455, 32.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 63.545, 31.955000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 64.355, 31.145000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 64.44500000000001, 31.055000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 65.255, 30.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 65.345, 30.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 66.155, 29.345000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 66.245, 29.255000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 67.05499999999999, 28.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 67.145, 28.354999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 67.955, 27.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 68.045, 27.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 68.855, 26.645000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 68.94500000000001, 26.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 69.755, 25.744999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 69.845, 25.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 70.655, 24.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 70.745, 24.755000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 71.55499999999999, 23.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 71.645, 23.854999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 72.455, 23.044999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 72.545, 22.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 73.355, 22.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 73.44500000000001, 22.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 74.25500000000001, 21.244999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 74.345, 21.154999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 75.155, 20.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 75.245, 20.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 76.05499999999999, 19.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 76.145, 19.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 76.955, 18.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 77.045, 18.455000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 77.85500000000002, 17.645000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 77.94500000000001, 17.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 78.755, 16.744999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 78.845, 16.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 79.655, 15.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 79.745, 15.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 80.55499999999999, 14.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 80.645, 14.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 81.45500000000001, 14.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 81.54500000000002, 13.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 82.35500000000002, 13.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 82.44500000000001, 13.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 83.255, 12.245000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 83.345, 12.155000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 84.155, 11.345000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 84.245, 11.255000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 85.055, 10.445000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 85.14500000000001, 10.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 85.95500000000001, 9.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 86.045, 9.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 86.855, 8.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 86.94500000000001, 8.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 87.755, 7.745000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 87.845, 7.655000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 88.655, 6.845000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 88.745, 6.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 89.555, 5.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 89.645, 5.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 90.455, 5.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.5, 90.5, 5.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.5, 90.5, 5.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.455, 90.5, 5.07]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.645, 90.5, 6.330000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.55499999999999, 90.5, 6.470000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.745, 90.5, 7.7299999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.655, 90.5, 7.869999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.845, 90.5, 9.129999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.75500000000001, 90.5, 9.27]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.94500000000001, 90.5, 10.53]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.855, 90.5, 10.67]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.045, 90.5, 11.930000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.955, 90.5, 12.07]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.145, 90.5, 13.33]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.05499999999999, 90.5, 13.47]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.245, 90.5, 14.73]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.15500000000002, 90.5, 14.870000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.345, 90.5, 16.13]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.255, 90.5, 16.27]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.44500000000001, 90.5, 17.53]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.355, 90.5, 17.67]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.545, 90.5, 18.93]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.455, 90.5, 19.07]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.645, 90.5, 20.33]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.555, 90.5, 20.47]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.745, 90.5, 21.73]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.655, 90.5, 21.87]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.845, 90.5, 23.13]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.755, 90.5, 23.27]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.94500000000001, 90.5, 24.53]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.855, 90.5, 24.67]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.045, 90.5, 25.930000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.95500000000001, 90.5, 26.07]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.14500000000001, 90.5, 27.33]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.055, 90.5, 27.47]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.245, 90.5, 28.730000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.155, 90.5, 28.87]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.345, 90.5, 30.13]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.255, 90.5, 30.27]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.44500000000001, 90.5, 31.53]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.35500000000002, 90.5, 31.67]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.54500000000002, 90.5, 32.93]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.45500000000001, 90.5, 33.07]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.645, 90.5, 34.33]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.55499999999999, 90.5, 34.47]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.745, 90.5, 35.73]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.655, 90.5, 35.87]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.845, 90.5, 37.13]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.755, 90.5, 37.27]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.94500000000001, 90.5, 38.53]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.85500000000002, 90.5, 38.67]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.045, 90.5, 39.93]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.955, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.145, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.05499999999999, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.245, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.155, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.345, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.25500000000001, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.44500000000001, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.355, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.545, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.455, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.645, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.55499999999999, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.745, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.655, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.845, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.755, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.94500000000001, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.855, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.045, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.955, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.145, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.05499999999999, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.245, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.155, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.345, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.255, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.44500000000001, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.355, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.545, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.455, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.645, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.55500000000001, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.745000000000005, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.655, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.845, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.754999999999995, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.94499999999999, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.855, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.045, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.955, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.144999999999996, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.055, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.245000000000005, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.155, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.345, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.255, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.445, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.355000000000004, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.545, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.455000000000005, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.645, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.55500000000001, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.745000000000005, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.65500000000001, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.845, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.754999999999995, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.945, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.855000000000004, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.045, 90.5, 40.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.955, 90.5, 39.955]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.145, 90.5, 39.145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.05500000000001, 90.5, 39.05500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.245000000000005, 90.5, 38.245000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.155, 90.5, 38.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.345, 90.5, 37.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.255, 90.5, 37.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.445, 90.5, 36.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.355, 90.5, 36.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.545, 90.5, 35.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.455000000000005, 90.5, 35.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.645, 90.5, 34.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.555, 90.5, 34.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.745000000000005, 90.5, 33.745000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.65500000000001, 90.5, 33.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.845, 90.5, 32.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.754999999999995, 90.5, 32.754999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.945, 90.5, 31.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.855000000000004, 90.5, 31.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.045, 90.5, 31.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.955, 90.5, 30.955000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.145, 90.5, 30.145000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.05500000000001, 90.5, 30.055000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.245000000000005, 90.5, 29.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.155, 90.5, 29.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.345, 90.5, 28.345000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.254999999999995, 90.5, 28.255000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.44499999999999, 90.5, 27.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.355, 90.5, 27.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.545, 90.5, 26.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.455, 90.5, 26.455000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.644999999999996, 90.5, 25.645000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.555, 90.5, 25.555000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.745000000000005, 90.5, 24.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.655, 90.5, 24.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.845, 90.5, 23.845000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.754999999999995, 90.5, 23.755000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.945, 90.5, 22.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.855, 90.5, 22.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.045, 90.5, 22.045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.955000000000002, 90.5, 21.955000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.145000000000003, 90.5, 21.145000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.055000000000003, 90.5, 21.055000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.245, 90.5, 20.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.155, 90.5, 20.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.345000000000002, 90.5, 19.345000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.255000000000003, 90.5, 19.255000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.445, 90.5, 18.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.354999999999997, 90.5, 18.354999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.545, 90.5, 17.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.455, 90.5, 17.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.645000000000003, 90.5, 16.645000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.555, 90.5, 16.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.744999999999997, 90.5, 15.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.655, 90.5, 15.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.845, 90.5, 14.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.755000000000003, 90.5, 14.755]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.945, 90.5, 13.945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.854999999999997, 90.5, 13.855]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.044999999999998, 90.5, 13.045000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.955, 90.5, 12.955000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.145, 90.5, 12.145000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.055, 90.5, 12.055]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.244999999999997, 90.5, 11.245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.154999999999998, 90.5, 11.155]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.345, 90.5, 10.345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.255, 90.5, 10.255]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.445, 90.5, 9.445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.355, 90.5, 9.355]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.545, 90.5, 8.545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.455000000000002, 90.5, 8.455]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.645000000000003, 90.5, 7.645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.555, 90.5, 7.555]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.744999999999997, 90.5, 6.745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.655, 90.5, 6.655]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.845, 90.5, 5.845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.8, 90.5, 5.76]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.8, 90.5, 5.04]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.51, 88.47500000000001, 4.75]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.29, 52.025, 0.25]) cube([0.4, 0.4, 0.1], center=true);
}

