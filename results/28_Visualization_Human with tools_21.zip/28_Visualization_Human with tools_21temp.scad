
translate([0, 0, 0]) cube([1, 1, 5.199999999999996]);

translate([1, 0, 0]) cube([1, 1, 4.669999998661702]);

translate([2, 0, 0]) cube([1, 1, 4.66999999999999]);

translate([3, 0, 0]) cube([1, 1, 4.526664233502913]);

translate([4, 0, 0]) cube([1, 1, 4.452945104894852]);

translate([5, 0, 0]) cube([1, 1, 4.376648101775443]);

translate([6, 0, 0]) cube([1, 1, 4.377487896136427]);

translate([7, 0, 0]) cube([1, 1, 4.5]);

translate([8, 0, 0]) cube([1, 1, 4.4]);

translate([9, 0, 0]) cube([1, 1, 4.372108513345242]);

translate([10, 0, 0]) cube([1, 1, 4.372727624932747]);

translate([11, 0, 0]) cube([1, 1, 4.7]);

translate([12, 0, 0]) cube([1, 1, 5.0]);

translate([13, 0, 0]) cube([1, 1, 5.2]);

translate([14, 0, 0]) cube([1, 1, 5.4]);

translate([15, 0, 0]) cube([1, 1, 5.4]);

translate([16, 0, 0]) cube([1, 1, 5.1]);

translate([17, 0, 0]) cube([1, 1, 4.7]);

translate([18, 0, 0]) cube([1, 1, 4.4]);

translate([19, 0, 0]) cube([1, 1, 4.3]);

translate([20, 0, 0]) cube([1, 1, 4.3]);

translate([21, 0, 0]) cube([1, 1, 4.4]);

translate([22, 0, 0]) cube([1, 1, 4.6]);

translate([23, 0, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 1, 0]) cube([1, 1, 6]);

translate([2, 1, 0]) cube([1, 1, 4.999999999999994]);

translate([3, 1, 0]) cube([1, 1, 4.609999999999996]);

translate([4, 1, 0]) cube([1, 1, 4.489999999999991]);

translate([5, 1, 0]) cube([1, 1, 4.370944267250163]);

translate([6, 1, 0]) cube([1, 1, 4.373478423184177]);

translate([7, 1, 0]) cube([1, 1, 4.373653724082243]);

translate([8, 1, 0]) cube([1, 1, 4.375907414982282]);

translate([9, 1, 0]) cube([1, 1, 4.3769252108143375]);

translate([10, 1, 0]) cube([1, 1, 4.3784526188422355]);

translate([11, 1, 0]) cube([1, 1, 4.377174062037114]);

translate([12, 1, 0]) cube([1, 1, 4.4]);

translate([13, 1, 0]) cube([1, 1, 4.5]);

translate([14, 1, 0]) cube([1, 1, 4.7]);

translate([15, 1, 0]) cube([1, 1, 4.7]);

translate([16, 1, 0]) cube([1, 1, 4.5]);

translate([17, 1, 0]) cube([1, 1, 4.3]);

translate([18, 1, 0]) cube([1, 1, 4.1]);

translate([19, 1, 0]) cube([1, 1, 3.9]);

translate([20, 1, 0]) cube([1, 1, 3.6]);

translate([21, 1, 0]) cube([1, 1, 3.7]);

translate([22, 1, 0]) cube([1, 1, 4.0]);

translate([23, 1, 0]) cube([1, 1, 4.1]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.439999999999995]);

translate([4, 2, 0]) cube([1, 1, 4.979999999999996]);

translate([5, 2, 0]) cube([1, 1, 4.869999999999998]);

translate([6, 2, 0]) cube([1, 1, 4.6]);

translate([7, 2, 0]) cube([1, 1, 4.374481184325511]);

translate([8, 2, 0]) cube([1, 1, 4.3740447527170625]);

translate([9, 2, 0]) cube([1, 1, 4.374654836032057]);

translate([10, 2, 0]) cube([1, 1, 4.375848308711694]);

translate([11, 2, 0]) cube([1, 1, 4.3762542207009245]);

translate([12, 2, 0]) cube([1, 1, 4.376180848170798]);

translate([13, 2, 0]) cube([1, 1, 4.4]);

translate([14, 2, 0]) cube([1, 1, 4.3]);

translate([15, 2, 0]) cube([1, 1, 4.3]);

translate([16, 2, 0]) cube([1, 1, 4.1]);

translate([17, 2, 0]) cube([1, 1, 3.8]);

translate([18, 2, 0]) cube([1, 1, 3.7]);

translate([19, 2, 0]) cube([1, 1, 3.6]);

translate([20, 2, 0]) cube([1, 1, 3.512025523209793]);

translate([21, 2, 0]) cube([1, 1, 3.5121561878418057]);

translate([22, 2, 0]) cube([1, 1, 3.7]);

translate([23, 2, 0]) cube([1, 1, 3.7]);

color([0,1,0])
translate([0, 3, 0]) cube([1, 1, 6]);

translate([1, 3, 0]) cube([1, 1, 6.649999999999997]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 3, 0]) cube([1, 1, 6]);

translate([6, 3, 0]) cube([1, 1, 5.039999999999999]);

translate([7, 3, 0]) cube([1, 1, 4.51]);

translate([8, 3, 0]) cube([1, 1, 4.43]);

translate([9, 3, 0]) cube([1, 1, 4.6]);

translate([10, 3, 0]) cube([1, 1, 4.8]);

translate([11, 3, 0]) cube([1, 1, 4.7]);

translate([12, 3, 0]) cube([1, 1, 4.7]);

translate([13, 3, 0]) cube([1, 1, 4.6]);

translate([14, 3, 0]) cube([1, 1, 4.2]);

translate([15, 3, 0]) cube([1, 1, 4.0]);

translate([16, 3, 0]) cube([1, 1, 3.8]);

translate([17, 3, 0]) cube([1, 1, 3.5114462730802902]);

translate([18, 3, 0]) cube([1, 1, 3.5121548183926135]);

translate([19, 3, 0]) cube([1, 1, 3.513274099636252]);

translate([20, 3, 0]) cube([1, 1, 3.5132099678070166]);

translate([21, 3, 0]) cube([1, 1, 3.5130057141160473]);

translate([22, 3, 0]) cube([1, 1, 3.512507450527934]);

translate([23, 3, 0]) cube([1, 1, 3.6]);

color([0,1,0])
translate([0, 4, 0]) cube([1, 1, 6]);

translate([1, 4, 0]) cube([1, 1, 6.656148708761005]);

translate([2, 4, 0]) cube([1, 1, 6.779999999999996]);

translate([3, 4, 0]) cube([1, 1, 6.65999999999999]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.379999999999998]);

translate([7, 4, 0]) cube([1, 1, 4.9399999999999995]);

translate([8, 4, 0]) cube([1, 1, 4.91]);

translate([9, 4, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([10, 4, 0]) cube([1, 1, 6]);

translate([11, 4, 0]) cube([1, 1, 5.4]);

translate([12, 4, 0]) cube([1, 1, 5.2]);

translate([13, 4, 0]) cube([1, 1, 4.8]);

translate([14, 4, 0]) cube([1, 1, 4.2]);

translate([15, 4, 0]) cube([1, 1, 3.8]);

translate([16, 4, 0]) cube([1, 1, 3.6]);

translate([17, 4, 0]) cube([1, 1, 3.5123351306564663]);

translate([18, 4, 0]) cube([1, 1, 3.512820474150738]);

translate([19, 4, 0]) cube([1, 1, 3.6]);

translate([20, 4, 0]) cube([1, 1, 3.513391611203191]);

translate([21, 4, 0]) cube([1, 1, 3.5130201101573046]);

translate([22, 4, 0]) cube([1, 1, 3.6]);

translate([23, 4, 0]) cube([1, 1, 3.7]);

translate([0, 5, 0]) cube([1, 1, 6.57381211635668]);

translate([1, 5, 0]) cube([1, 1, 6.677983899854084]);

translate([2, 5, 0]) cube([1, 1, 6.758577312909969]);

translate([3, 5, 0]) cube([1, 1, 6.736696107074146]);

translate([4, 5, 0]) cube([1, 1, 6.699999999999994]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 5, 0]) cube([1, 1, 6]);

translate([12, 5, 0]) cube([1, 1, 5.4]);

translate([13, 5, 0]) cube([1, 1, 4.8]);

translate([14, 5, 0]) cube([1, 1, 4.2]);

translate([15, 5, 0]) cube([1, 1, 3.8]);

translate([16, 5, 0]) cube([1, 1, 3.6]);

translate([17, 5, 0]) cube([1, 1, 3.7]);

translate([18, 5, 0]) cube([1, 1, 3.9]);

translate([19, 5, 0]) cube([1, 1, 4.0]);

translate([20, 5, 0]) cube([1, 1, 4.2]);

translate([21, 5, 0]) cube([1, 1, 4.2]);

translate([22, 5, 0]) cube([1, 1, 4.1]);

translate([23, 5, 0]) cube([1, 1, 3.9]);

translate([0, 6, 0]) cube([1, 1, 6.61283357632573]);

translate([1, 6, 0]) cube([1, 1, 6.73770654251272]);

translate([2, 6, 0]) cube([1, 1, 6.872037679398132]);

translate([3, 6, 0]) cube([1, 1, 6.818632659980063]);

translate([4, 6, 0]) cube([1, 1, 6.799999999999994]);

translate([5, 6, 0]) cube([1, 1, 6.739999999999995]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 6, 0]) cube([1, 1, 6]);

translate([12, 6, 0]) cube([1, 1, 5.4]);

translate([13, 6, 0]) cube([1, 1, 4.9]);

translate([14, 6, 0]) cube([1, 1, 4.5]);

translate([15, 6, 0]) cube([1, 1, 4.1]);

translate([16, 6, 0]) cube([1, 1, 4.1]);

translate([17, 6, 0]) cube([1, 1, 4.4]);

translate([18, 6, 0]) cube([1, 1, 4.6]);

translate([19, 6, 0]) cube([1, 1, 4.6]);

translate([20, 6, 0]) cube([1, 1, 4.71]);

translate([21, 6, 0]) cube([1, 1, 4.619999999999999]);

translate([22, 6, 0]) cube([1, 1, 4.52]);

translate([23, 6, 0]) cube([1, 1, 4.4]);

translate([0, 7, 0]) cube([1, 1, 6.6727459174536605]);

translate([1, 7, 0]) cube([1, 1, 6.9998728479886525]);

translate([2, 7, 0]) cube([1, 1, 7.020094164657492]);

translate([3, 7, 0]) cube([1, 1, 7.0299999999999905]);

translate([4, 7, 0]) cube([1, 1, 6.879999999999992]);

translate([5, 7, 0]) cube([1, 1, 6.661571231607573]);

translate([6, 7, 0]) cube([1, 1, 6.709999999999997]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

translate([13, 7, 0]) cube([1, 1, 5.0]);

translate([14, 7, 0]) cube([1, 1, 4.8]);

translate([15, 7, 0]) cube([1, 1, 4.6]);

translate([16, 7, 0]) cube([1, 1, 4.6]);

translate([17, 7, 0]) cube([1, 1, 5.1]);

translate([18, 7, 0]) cube([1, 1, 5.3]);

translate([19, 7, 0]) cube([1, 1, 5.21]);

translate([20, 7, 0]) cube([1, 1, 5.119999999999999]);

translate([21, 7, 0]) cube([1, 1, 4.93]);

translate([22, 7, 0]) cube([1, 1, 4.949999999999999]);

translate([23, 7, 0]) cube([1, 1, 5.129999999999999]);

translate([0, 8, 0]) cube([1, 1, 6.712707956108988]);

translate([1, 8, 0]) cube([1, 1, 7.000850118818265]);

translate([2, 8, 0]) cube([1, 1, 7.060093280865894]);

translate([3, 8, 0]) cube([1, 1, 7.021767210779709]);

translate([4, 8, 0]) cube([1, 1, 6.873428746600262]);

translate([5, 8, 0]) cube([1, 1, 6.692449621990963]);

translate([6, 8, 0]) cube([1, 1, 6.641060676544433]);

translate([7, 8, 0]) cube([1, 1, 6.589999999999994]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

translate([13, 8, 0]) cube([1, 1, 5.0]);

translate([14, 8, 0]) cube([1, 1, 4.9]);

translate([15, 8, 0]) cube([1, 1, 4.7]);

translate([16, 8, 0]) cube([1, 1, 4.9]);

color([0,1,0])
translate([17, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 6.567826533814983]);

translate([1, 9, 0]) cube([1, 1, 6.976123098996959]);

translate([2, 9, 0]) cube([1, 1, 7.046620194065553]);

translate([3, 9, 0]) cube([1, 1, 7.0080810278592125]);

translate([4, 9, 0]) cube([1, 1, 6.794981705989381]);

translate([5, 9, 0]) cube([1, 1, 6.683322582434172]);

translate([6, 9, 0]) cube([1, 1, 6.642449638615306]);

translate([7, 9, 0]) cube([1, 1, 6.719999999999997]);

translate([8, 9, 0]) cube([1, 1, 6.6999999999999975]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

translate([13, 9, 0]) cube([1, 1, 5.2]);

translate([14, 9, 0]) cube([1, 1, 5.1]);

translate([15, 9, 0]) cube([1, 1, 4.9]);

translate([16, 9, 0]) cube([1, 1, 5.1]);

color([0,1,0])
translate([17, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 6.747058254790023]);

translate([1, 10, 0]) cube([1, 1, 6.973007173288013]);

translate([2, 10, 0]) cube([1, 1, 6.958881295778206]);

translate([3, 10, 0]) cube([1, 1, 6.86436616724727]);

translate([4, 10, 0]) cube([1, 1, 6.768145176754377]);

translate([5, 10, 0]) cube([1, 1, 6.705810079903809]);

translate([6, 10, 0]) cube([1, 1, 6.609543233843065]);

translate([7, 10, 0]) cube([1, 1, 6.528766658066462]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

translate([9, 10, 0]) cube([1, 1, 6.679999999999998]);

translate([10, 10, 0]) cube([1, 1, 6.529999999999998]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

translate([14, 10, 0]) cube([1, 1, 5.4]);

translate([15, 10, 0]) cube([1, 1, 5.3]);

translate([16, 10, 0]) cube([1, 1, 5.41]);

color([0,1,0])
translate([17, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

translate([20, 10, 0]) cube([1, 1, 6.629999999999999]);

color([0,1,0])
translate([21, 10, 0]) cube([1, 1, 6]);

translate([22, 10, 0]) cube([1, 1, 6.639999999999999]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 6.746721335299531]);

translate([1, 11, 0]) cube([1, 1, 6.746301568665996]);

translate([2, 11, 0]) cube([1, 1, 6.9047259167337325]);

translate([3, 11, 0]) cube([1, 1, 6.888537176087397]);

translate([4, 11, 0]) cube([1, 1, 6.794916028411867]);

translate([5, 11, 0]) cube([1, 1, 6.69674581063896]);

translate([6, 11, 0]) cube([1, 1, 6.6065778413013]);

translate([7, 11, 0]) cube([1, 1, 6.536768372921668]);

translate([8, 11, 0]) cube([1, 1, 6.505228899551873]);

translate([9, 11, 0]) cube([1, 1, 6.619999999999997]);

translate([10, 11, 0]) cube([1, 1, 6.559999999999997]);

translate([11, 11, 0]) cube([1, 1, 6.619999999999999]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 6.747140709131547]);

translate([1, 12, 0]) cube([1, 1, 6.842914663986374]);

translate([2, 12, 0]) cube([1, 1, 6.846365219808716]);

translate([3, 12, 0]) cube([1, 1, 6.829230711466909]);

translate([4, 12, 0]) cube([1, 1, 6.8399999999999945]);

translate([5, 12, 0]) cube([1, 1, 6.719999999999995]);

translate([6, 12, 0]) cube([1, 1, 6.7499999999999964]);

color([0,1,0])
translate([7, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 12, 0]) cube([1, 1, 6]);

translate([9, 12, 0]) cube([1, 1, 6.629999999999997]);

translate([10, 12, 0]) cube([1, 1, 6.5799999999999965]);

translate([11, 12, 0]) cube([1, 1, 6.639999999999999]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

translate([20, 12, 0]) cube([1, 1, 6.539999999999999]);

color([0,1,0])
translate([21, 12, 0]) cube([1, 1, 6]);

translate([22, 12, 0]) cube([1, 1, 6.639999999999999]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 6.763299764909898]);

translate([1, 13, 0]) cube([1, 1, 6.815440396044588]);

translate([2, 13, 0]) cube([1, 1, 6.804414140940724]);

translate([3, 13, 0]) cube([1, 1, 6.8399999999999945]);

translate([4, 13, 0]) cube([1, 1, 6.629999999999993]);

color([0,1,0])
translate([5, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

translate([8, 13, 0]) cube([1, 1, 6.589999999999998]);

translate([9, 13, 0]) cube([1, 1, 6.6999999999999975]);

color([0,1,0])
translate([10, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

translate([14, 13, 0]) cube([1, 1, 5.459999999999999]);

translate([15, 13, 0]) cube([1, 1, 5.458386253644869]);

translate([16, 13, 0]) cube([1, 1, 5.457490145913908]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 6.698656514688088]);

translate([1, 14, 0]) cube([1, 1, 6.809999999999993]);

translate([2, 14, 0]) cube([1, 1, 6.729999999999991]);

translate([3, 14, 0]) cube([1, 1, 6.65999999999999]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

translate([9, 14, 0]) cube([1, 1, 6.609999999999998]);

color([0,1,0])
translate([10, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 14, 0]) cube([1, 1, 6]);

translate([12, 14, 0]) cube([1, 1, 6.5699999999999985]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

translate([15, 14, 0]) cube([1, 1, 5.4593346668784175]);

translate([16, 14, 0]) cube([1, 1, 5.460783001492885]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 15, 0]) cube([1, 1, 6]);

translate([1, 15, 0]) cube([1, 1, 6.7499999999999964]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

translate([16, 15, 0]) cube([1, 1, 5.460008864000313]);

translate([17, 15, 0]) cube([1, 1, 5.460362824461858]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

translate([23, 15, 0]) cube([1, 1, 5.4399999999999995]);

color([0,1,0])
translate([0, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

translate([17, 16, 0]) cube([1, 1, 5.45976064386834]);

translate([18, 16, 0]) cube([1, 1, 5.460033231386776]);

translate([19, 16, 0]) cube([1, 1, 5.45970034627394]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

translate([23, 16, 0]) cube([1, 1, 5.139999999999999]);

color([0,1,0])
translate([0, 17, 0]) cube([1, 1, 6]);

translate([1, 17, 0]) cube([1, 1, 6.649999999999999]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

translate([9, 17, 0]) cube([1, 1, 6.669999999999998]);

color([0,1,0])
translate([10, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 17, 0]) cube([1, 1, 6]);

translate([22, 17, 0]) cube([1, 1, 5.3]);

translate([23, 17, 0]) cube([1, 1, 4.93]);

translate([0, 18, 0]) cube([1, 1, 6.639999999999999]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

translate([8, 18, 0]) cube([1, 1, 6.679999999999998]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([20, 18, 0]) cube([1, 1, 5.4]);

translate([21, 18, 0]) cube([1, 1, 5.3]);

translate([22, 18, 0]) cube([1, 1, 4.9]);

translate([23, 18, 0]) cube([1, 1, 4.732468616064352]);

color([0,1,0])
translate([0, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

translate([11, 19, 0]) cube([1, 1, 6.559999999999999]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

translate([19, 19, 0]) cube([1, 1, 5.400143903257275]);

translate([20, 19, 0]) cube([1, 1, 5.4]);

translate([21, 19, 0]) cube([1, 1, 5.3]);

translate([22, 19, 0]) cube([1, 1, 5.0]);

translate([23, 19, 0]) cube([1, 1, 4.732493631139768]);

color([0,1,0])
translate([0, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 20, 0]) cube([1, 1, 6]);

translate([7, 20, 0]) cube([1, 1, 6.649999999999999]);

color([0,1,0])
translate([8, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 20, 0]) cube([1, 1, 6]);

translate([10, 20, 0]) cube([1, 1, 6.5699999999999985]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 20, 0]) cube([1, 1, 6]);

translate([23, 20, 0]) cube([1, 1, 5.1]);

color([0,1,0])
translate([0, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 21, 0]) cube([1, 1, 6]);

translate([7, 21, 0]) cube([1, 1, 6.559999999999999]);

translate([8, 21, 0]) cube([1, 1, 6.549999999999999]);

color([0,1,0])
translate([9, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

translate([20, 21, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

translate([4, 22, 0]) cube([1, 1, 5.335475221623232]);

color([0,1,0])
translate([5, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

translate([17, 22, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

translate([19, 22, 0]) cube([1, 1, 5.4]);

translate([20, 22, 0]) cube([1, 1, 5.3]);

translate([21, 22, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

translate([0, 23, 0]) cube([1, 1, 5.329165069501367]);

translate([1, 23, 0]) cube([1, 1, 5.332137654649913]);

translate([2, 23, 0]) cube([1, 1, 5.3323173727435]);

translate([3, 23, 0]) cube([1, 1, 5.335556439396839]);

translate([4, 23, 0]) cube([1, 1, 5.3356907317340765]);

translate([5, 23, 0]) cube([1, 1, 5.336058123342583]);

translate([6, 23, 0]) cube([1, 1, 5.3333034645274955]);

translate([7, 23, 0]) cube([1, 1, 5.333687828573115]);

translate([8, 23, 0]) cube([1, 1, 5.333792328528831]);

translate([9, 23, 0]) cube([1, 1, 5.334163391084521]);

translate([10, 23, 0]) cube([1, 1, 5.33361257770057]);

translate([11, 23, 0]) cube([1, 1, 5.4399999999999995]);

color([0,1,0])
translate([12, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 23, 0]) cube([1, 1, 6]);

translate([16, 23, 0]) cube([1, 1, 5.4]);

translate([17, 23, 0]) cube([1, 1, 5.2008385495014124]);

translate([18, 23, 0]) cube([1, 1, 5.200836292673583]);

translate([19, 23, 0]) cube([1, 1, 5.3]);

translate([20, 23, 0]) cube([1, 1, 5.300018089681771]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);
