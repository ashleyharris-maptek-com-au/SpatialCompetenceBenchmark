
translate([0, 0, 0]) cube([1, 1, 5.000012321179441]);

translate([1, 0, 0]) cube([1, 1, 4.4000520841584425]);

translate([2, 0, 0]) cube([1, 1, 4.200153545511873]);

translate([3, 0, 0]) cube([1, 1, 4.100360163886077]);

translate([4, 0, 0]) cube([1, 1, 4.0058917525682425]);

translate([5, 0, 0]) cube([1, 1, 4.0058984212516435]);

translate([6, 0, 0]) cube([1, 1, 4.006135142862267]);

translate([7, 0, 0]) cube([1, 1, 4.074919529353301]);

translate([8, 0, 0]) cube([1, 1, 4.294532016999227]);

translate([9, 0, 0]) cube([1, 1, 3.3682248712078073]);

translate([10, 0, 0]) cube([1, 1, 3.3133156306026597]);

translate([11, 0, 0]) cube([1, 1, 4.376929183813442]);

translate([12, 0, 0]) cube([1, 1, 4.225142979619831]);

translate([13, 0, 0]) cube([1, 1, 4.207160744904959]);

translate([14, 0, 0]) cube([1, 1, 4.404666666666667]);

translate([15, 0, 0]) cube([1, 1, 4.823333333333333]);

translate([16, 0, 0]) cube([1, 1, 5.066666666666666]);

translate([17, 0, 0]) cube([1, 1, 4.072327259194021]);

translate([18, 0, 0]) cube([1, 1, 5.366666666666666]);

translate([19, 0, 0]) cube([1, 1, 4.309283917436023]);

translate([20, 0, 0]) cube([1, 1, 4.186929563492064]);

translate([21, 0, 0]) cube([1, 1, 5.265555555555555]);

translate([22, 0, 0]) cube([1, 1, 4.921444444444445]);

translate([23, 0, 0]) cube([1, 1, 4.615399999999999]);

translate([24, 0, 0]) cube([1, 1, 3.209727662314799]);

translate([25, 0, 0]) cube([1, 1, 4.406326362366938]);

translate([26, 0, 0]) cube([1, 1, 4.327746753954869]);

translate([27, 0, 0]) cube([1, 1, 4.306936688488717]);

translate([28, 0, 0]) cube([1, 1, 4.4]);

translate([29, 0, 0]) cube([1, 1, 4.6]);

translate([30, 0, 0]) cube([1, 1, 4.7]);

translate([31, 0, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.1000199786030755]);

translate([2, 1, 0]) cube([1, 1, 4.700067204878694]);

translate([3, 1, 0]) cube([1, 1, 4.500167824471733]);

translate([4, 1, 0]) cube([1, 1, 4.2003317535627565]);

translate([5, 1, 0]) cube([1, 1, 4.007267079174218]);

translate([6, 1, 0]) cube([1, 1, 4.006491258893404]);

translate([7, 1, 0]) cube([1, 1, 4.082100106603418]);

translate([8, 1, 0]) cube([1, 1, 4.217859965418996]);

translate([9, 1, 0]) cube([1, 1, 4.322318152203824]);

translate([10, 1, 0]) cube([1, 1, 4.315264143469755]);

translate([11, 1, 0]) cube([1, 1, 4.114466060406389]);

translate([12, 1, 0]) cube([1, 1, 4.0899080435350825]);

translate([13, 1, 0]) cube([1, 1, 4.0898997061272535]);

translate([14, 1, 0]) cube([1, 1, 4.0903958495427934]);

translate([15, 1, 0]) cube([1, 1, 4.346410360385945]);

translate([16, 1, 0]) cube([1, 1, 4.5811409756528265]);

translate([17, 1, 0]) cube([1, 1, 4.714532928746895]);

translate([18, 1, 0]) cube([1, 1, 4.943320021460965]);

translate([19, 1, 0]) cube([1, 1, 5.043092757936508]);

translate([20, 1, 0]) cube([1, 1, 4.927785926870748]);

translate([21, 1, 0]) cube([1, 1, 4.7801211238662145]);

translate([22, 1, 0]) cube([1, 1, 4.5365042247732426]);

translate([23, 1, 0]) cube([1, 1, 4.42187638314122]);

translate([24, 1, 0]) cube([1, 1, 4.28987510076898]);

translate([25, 1, 0]) cube([1, 1, 4.094896766035438]);

translate([26, 1, 0]) cube([1, 1, 3.8684221893008655]);

translate([27, 1, 0]) cube([1, 1, 3.7261232422344275]);

translate([28, 1, 0]) cube([1, 1, 3.9013873376977437]);

translate([29, 1, 0]) cube([1, 1, 4.0]);

translate([30, 1, 0]) cube([1, 1, 4.2]);

translate([31, 1, 0]) cube([1, 1, 4.3]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

translate([2, 2, 0]) cube([1, 1, 5.400076568146179]);

translate([3, 2, 0]) cube([1, 1, 5.100220817692585]);

translate([4, 2, 0]) cube([1, 1, 4.800474531910071]);

translate([5, 2, 0]) cube([1, 1, 4.500795593739397]);

translate([6, 2, 0]) cube([1, 1, 4.402725807779207]);

translate([7, 2, 0]) cube([1, 1, 4.408603803445238]);

translate([8, 2, 0]) cube([1, 1, 4.334945332885462]);

translate([9, 2, 0]) cube([1, 1, 4.270634213804534]);

translate([10, 2, 0]) cube([1, 1, 4.113152344630246]);

translate([11, 2, 0]) cube([1, 1, 4.095624929130744]);

translate([12, 2, 0]) cube([1, 1, 4.090649154426149]);

translate([13, 2, 0]) cube([1, 1, 4.089900136866597]);

translate([14, 2, 0]) cube([1, 1, 4.0908988888182165]);

translate([15, 2, 0]) cube([1, 1, 4.184616324145069]);

translate([16, 2, 0]) cube([1, 1, 4.376693251891512]);

translate([17, 2, 0]) cube([1, 1, 4.479238351799438]);

translate([18, 2, 0]) cube([1, 1, 4.54140492117482]);

translate([19, 2, 0]) cube([1, 1, 4.588675974854227]);

translate([20, 2, 0]) cube([1, 1, 4.500532452413947]);

translate([21, 2, 0]) cube([1, 1, 4.36898874558483]);

translate([22, 2, 0]) cube([1, 1, 4.241498095473102]);

translate([23, 2, 0]) cube([1, 1, 4.045132928183845]);

translate([24, 2, 0]) cube([1, 1, 4.0419212568690295]);

translate([25, 2, 0]) cube([1, 1, 3.9377821872789074]);

translate([26, 2, 0]) cube([1, 1, 3.646217883736611]);

translate([27, 2, 0]) cube([1, 1, 3.443196169991317]);

translate([28, 2, 0]) cube([1, 1, 3.506960901454879]);

translate([29, 2, 0]) cube([1, 1, 3.8002774671859085]);

translate([30, 2, 0]) cube([1, 1, 3.9]);

translate([31, 2, 0]) cube([1, 1, 3.8]);

translate([0, 3, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

translate([4, 3, 0]) cube([1, 1, 5.40067877803123]);

translate([5, 3, 0]) cube([1, 1, 5.101202188369899]);

translate([6, 3, 0]) cube([1, 1, 5.001622471436282]);

translate([7, 3, 0]) cube([1, 1, 4.9016419020657915]);

translate([8, 3, 0]) cube([1, 1, 4.70095127562376]);

translate([9, 3, 0]) cube([1, 1, 4.402688349113813]);

translate([10, 3, 0]) cube([1, 1, 4.133336232439046]);

translate([11, 3, 0]) cube([1, 1, 4.1085641901570105]);

translate([12, 3, 0]) cube([1, 1, 4.201576935057654]);

translate([13, 3, 0]) cube([1, 1, 4.301294294092872]);

translate([14, 3, 0]) cube([1, 1, 4.304643757827444]);

translate([15, 3, 0]) cube([1, 1, 4.297248208532153]);

translate([16, 3, 0]) cube([1, 1, 4.427951194001182]);

translate([17, 3, 0]) cube([1, 1, 4.5051094426746525]);

translate([18, 3, 0]) cube([1, 1, 4.5190632018951264]);

translate([19, 3, 0]) cube([1, 1, 4.487669688306463]);

translate([20, 3, 0]) cube([1, 1, 4.313032140783408]);

translate([21, 3, 0]) cube([1, 1, 4.173704466745235]);

translate([22, 3, 0]) cube([1, 1, 3.876133165860057]);

translate([23, 3, 0]) cube([1, 1, 3.660986706040388]);

translate([24, 3, 0]) cube([1, 1, 3.6378582992027937]);

translate([25, 3, 0]) cube([1, 1, 3.6291113527990553]);

translate([26, 3, 0]) cube([1, 1, 3.445778050590409]);

translate([27, 3, 0]) cube([1, 1, 3.3956041535532098]);

translate([28, 3, 0]) cube([1, 1, 3.4126286568771214]);

translate([29, 3, 0]) cube([1, 1, 3.600055559409525]);

translate([30, 3, 0]) cube([1, 1, 3.70004624442115]);

translate([31, 3, 0]) cube([1, 1, 3.600020660133944]);

translate([0, 4, 0]) cube([1, 1, 7.2]);

translate([1, 4, 0]) cube([1, 1, 6.600000230547935]);

color([0,1,0])
translate([2, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.40252128783948]);

translate([7, 4, 0]) cube([1, 1, 5.302480860104393]);

translate([8, 4, 0]) cube([1, 1, 5.001584891797353]);

translate([9, 4, 0]) cube([1, 1, 4.60601968282364]);

translate([10, 4, 0]) cube([1, 1, 4.406125172940958]);

translate([11, 4, 0]) cube([1, 1, 4.404971541492861]);

translate([12, 4, 0]) cube([1, 1, 4.601226136314332]);

translate([13, 4, 0]) cube([1, 1, 4.800392704312249]);

translate([14, 4, 0]) cube([1, 1, 4.80020887278858]);

translate([15, 4, 0]) cube([1, 1, 4.70166332078678]);

translate([16, 4, 0]) cube([1, 1, 4.706181878227259]);

translate([17, 4, 0]) cube([1, 1, 3.7210273553138964]);

translate([18, 4, 0]) cube([1, 1, 3.6611120240572714]);

translate([19, 4, 0]) cube([1, 1, 4.328059598447665]);

translate([20, 4, 0]) cube([1, 1, 4.16455228760248]);

translate([21, 4, 0]) cube([1, 1, 3.975208429541999]);

translate([22, 4, 0]) cube([1, 1, 3.678685108365051]);

translate([23, 4, 0]) cube([1, 1, 3.5801747070690153]);

translate([24, 4, 0]) cube([1, 1, 3.5667323900793497]);

translate([25, 4, 0]) cube([1, 1, 3.5438998809386724]);

translate([26, 4, 0]) cube([1, 1, 3.4460951154675645]);

translate([27, 4, 0]) cube([1, 1, 3.3956041674295876]);

translate([28, 4, 0]) cube([1, 1, 3.3956141268561737]);

translate([29, 4, 0]) cube([1, 1, 3.500024534267276]);

translate([30, 4, 0]) cube([1, 1, 3.60001618032034]);

translate([31, 4, 0]) cube([1, 1, 3.500094574468197]);

translate([0, 5, 0]) cube([1, 1, 7.4]);

translate([1, 5, 0]) cube([1, 1, 6.9000001982792885]);

translate([2, 5, 0]) cube([1, 1, 6.600000755395979]);

color([0,1,0])
translate([3, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

translate([8, 5, 0]) cube([1, 1, 5.303738757727403]);

translate([9, 5, 0]) cube([1, 1, 4.908639634585772]);

translate([10, 5, 0]) cube([1, 1, 4.709164172348904]);

translate([11, 5, 0]) cube([1, 1, 4.903670369989225]);

translate([12, 5, 0]) cube([1, 1, 5.101593044026825]);

translate([13, 5, 0]) cube([1, 1, 5.300474563971794]);

translate([14, 5, 0]) cube([1, 1, 5.300211198553197]);

translate([15, 5, 0]) cube([1, 1, 5.1000433187850875]);

translate([16, 5, 0]) cube([1, 1, 5.100008015609325]);

translate([17, 5, 0]) cube([1, 1, 4.900002898320084]);

translate([18, 5, 0]) cube([1, 1, 3.6309997504251834]);

translate([19, 5, 0]) cube([1, 1, 4.261702152901512]);

translate([20, 5, 0]) cube([1, 1, 4.006128627877865]);

translate([21, 5, 0]) cube([1, 1, 3.8180663525764533]);

translate([22, 5, 0]) cube([1, 1, 3.6324609871331344]);

translate([23, 5, 0]) cube([1, 1, 3.591399638832769]);

translate([24, 5, 0]) cube([1, 1, 3.573433412277487]);

translate([25, 5, 0]) cube([1, 1, 3.5493909690791963]);

translate([26, 5, 0]) cube([1, 1, 3.5227780682389604]);

translate([27, 5, 0]) cube([1, 1, 3.417218295125186]);

translate([28, 5, 0]) cube([1, 1, 3.405752653333471]);

translate([29, 5, 0]) cube([1, 1, 3.5000151341851042]);

translate([30, 5, 0]) cube([1, 1, 3.6000046889124624]);

translate([31, 5, 0]) cube([1, 1, 3.6000068014283295]);

translate([0, 6, 0]) cube([1, 1, 7.7]);

translate([1, 6, 0]) cube([1, 1, 7.2]);

translate([2, 6, 0]) cube([1, 1, 7.000000793735102]);

translate([3, 6, 0]) cube([1, 1, 6.800002755854288]);

translate([4, 6, 0]) cube([1, 1, 6.501527852883272]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.20975276539535]);

translate([10, 6, 0]) cube([1, 1, 5.109899131511954]);

translate([11, 6, 0]) cube([1, 1, 5.304694789051843]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([16, 6, 0]) cube([1, 1, 5.300004052326249]);

translate([17, 6, 0]) cube([1, 1, 5.000005322170796]);

translate([18, 6, 0]) cube([1, 1, 3.3886414631278234]);

translate([19, 6, 0]) cube([1, 1, 4.194953728134132]);

translate([20, 6, 0]) cube([1, 1, 3.898373277451197]);

translate([21, 6, 0]) cube([1, 1, 3.7516210792287894]);

translate([22, 6, 0]) cube([1, 1, 3.657740103081802]);

translate([23, 6, 0]) cube([1, 1, 3.607570109840947]);

translate([24, 6, 0]) cube([1, 1, 3.607525894771727]);

translate([25, 6, 0]) cube([1, 1, 3.700000510144234]);

translate([26, 6, 0]) cube([1, 1, 3.8]);

translate([27, 6, 0]) cube([1, 1, 3.9]);

translate([28, 6, 0]) cube([1, 1, 3.8]);

translate([29, 6, 0]) cube([1, 1, 3.8]);

translate([30, 6, 0]) cube([1, 1, 3.8]);

translate([31, 6, 0]) cube([1, 1, 3.7]);

translate([0, 7, 0]) cube([1, 1, 8.0]);

translate([1, 7, 0]) cube([1, 1, 7.5]);

translate([2, 7, 0]) cube([1, 1, 7.3]);

translate([3, 7, 0]) cube([1, 1, 7.000003968866373]);

translate([4, 7, 0]) cube([1, 1, 6.800009380226365]);

translate([5, 7, 0]) cube([1, 1, 6.507623159916772]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([16, 7, 0]) cube([1, 1, 5.400019865871872]);

translate([17, 7, 0]) cube([1, 1, 4.900052710452356]);

translate([18, 7, 0]) cube([1, 1, 4.619584972753873]);

translate([19, 7, 0]) cube([1, 1, 4.286114954449631]);

translate([20, 7, 0]) cube([1, 1, 3.913515900525368]);

translate([21, 7, 0]) cube([1, 1, 3.8060104194514905]);

translate([22, 7, 0]) cube([1, 1, 3.8082742965002754]);

translate([23, 7, 0]) cube([1, 1, 4.000005508552053]);

translate([24, 7, 0]) cube([1, 1, 4.000002551618459]);

translate([25, 7, 0]) cube([1, 1, 4.1]);

translate([26, 7, 0]) cube([1, 1, 4.3]);

translate([27, 7, 0]) cube([1, 1, 4.4]);

translate([28, 7, 0]) cube([1, 1, 4.3]);

translate([29, 7, 0]) cube([1, 1, 4.2]);

translate([30, 7, 0]) cube([1, 1, 4.1]);

translate([31, 7, 0]) cube([1, 1, 4.0]);

translate([0, 8, 0]) cube([1, 1, 7.9]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 7.3]);

translate([3, 8, 0]) cube([1, 1, 7.000023814024784]);

translate([4, 8, 0]) cube([1, 1, 6.800029458749388]);

translate([5, 8, 0]) cube([1, 1, 6.609980662361295]);

translate([6, 8, 0]) cube([1, 1, 6.529273946848869]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([16, 8, 0]) cube([1, 1, 5.4000737278342426]);

translate([17, 8, 0]) cube([1, 1, 5.000107874175596]);

translate([18, 8, 0]) cube([1, 1, 4.700139910908997]);

translate([19, 8, 0]) cube([1, 1, 4.417547610419004]);

translate([20, 8, 0]) cube([1, 1, 4.126016049084188]);

translate([21, 8, 0]) cube([1, 1, 4.006578151639158]);

translate([22, 8, 0]) cube([1, 1, 4.200028353927156]);

translate([23, 8, 0]) cube([1, 1, 4.500004698859654]);

translate([24, 8, 0]) cube([1, 1, 4.6]);

translate([25, 8, 0]) cube([1, 1, 4.6]);

translate([26, 8, 0]) cube([1, 1, 4.6]);

translate([27, 8, 0]) cube([1, 1, 4.7]);

translate([28, 8, 0]) cube([1, 1, 4.6]);

translate([29, 8, 0]) cube([1, 1, 4.5]);

translate([30, 8, 0]) cube([1, 1, 4.5]);

translate([31, 8, 0]) cube([1, 1, 4.4]);

translate([0, 9, 0]) cube([1, 1, 7.9]);

translate([1, 9, 0]) cube([1, 1, 7.4]);

translate([2, 9, 0]) cube([1, 1, 7.100142884755464]);

translate([3, 9, 0]) cube([1, 1, 6.9001476475604235]);

translate([4, 9, 0]) cube([1, 1, 6.63439284005373]);

translate([5, 9, 0]) cube([1, 1, 6.60765746252375]);

translate([6, 9, 0]) cube([1, 1, 6.622106996899948]);

translate([7, 9, 0]) cube([1, 1, 6.710831251611206]);

translate([8, 9, 0]) cube([1, 1, 6.5080413362038865]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 5.100216153049886]);

translate([18, 9, 0]) cube([1, 1, 4.900177503550985]);

translate([19, 9, 0]) cube([1, 1, 4.700156922563772]);

translate([20, 9, 0]) cube([1, 1, 4.5001311322358895]);

translate([21, 9, 0]) cube([1, 1, 4.400113576668441]);

translate([22, 9, 0]) cube([1, 1, 4.700023495499285]);

translate([23, 9, 0]) cube([1, 1, 5.0]);

translate([24, 9, 0]) cube([1, 1, 5.1]);

translate([25, 9, 0]) cube([1, 1, 5.1]);

translate([26, 9, 0]) cube([1, 1, 5.0]);

translate([27, 9, 0]) cube([1, 1, 4.9]);

translate([28, 9, 0]) cube([1, 1, 4.8]);

translate([29, 9, 0]) cube([1, 1, 4.8]);

translate([30, 9, 0]) cube([1, 1, 4.9]);

translate([31, 9, 0]) cube([1, 1, 4.9]);

translate([0, 10, 0]) cube([1, 1, 8.0]);

translate([1, 10, 0]) cube([1, 1, 7.5]);

translate([2, 10, 0]) cube([1, 1, 7.100571539021857]);

translate([3, 10, 0]) cube([1, 1, 6.719507462172987]);

translate([4, 10, 0]) cube([1, 1, 6.653217055502115]);

translate([5, 10, 0]) cube([1, 1, 6.654092234069675]);

translate([6, 10, 0]) cube([1, 1, 6.836111390896172]);

translate([7, 10, 0]) cube([1, 1, 6.918707598943025]);

translate([8, 10, 0]) cube([1, 1, 6.7187091669833805]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 5.100342563319164]);

translate([18, 10, 0]) cube([1, 1, 4.9002828552019]);

translate([19, 10, 0]) cube([1, 1, 4.800199060313246]);

translate([20, 10, 0]) cube([1, 1, 4.7001822003012155]);

translate([21, 10, 0]) cube([1, 1, 4.700117478974881]);

translate([22, 10, 0]) cube([1, 1, 5.1]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 10, 0]) cube([1, 1, 6]);

translate([26, 10, 0]) cube([1, 1, 5.4]);

translate([27, 10, 0]) cube([1, 1, 5.2]);

translate([28, 10, 0]) cube([1, 1, 5.1]);

translate([29, 10, 0]) cube([1, 1, 5.1]);

translate([30, 10, 0]) cube([1, 1, 5.3]);

translate([31, 10, 0]) cube([1, 1, 5.4]);

translate([0, 11, 0]) cube([1, 1, 8.2]);

translate([1, 11, 0]) cube([1, 1, 7.7]);

translate([2, 11, 0]) cube([1, 1, 7.202857695109286]);

translate([3, 11, 0]) cube([1, 1, 6.920967782519746]);

translate([4, 11, 0]) cube([1, 1, 6.933834838067878]);

translate([5, 11, 0]) cube([1, 1, 7.0656656262286]);

translate([6, 11, 0]) cube([1, 1, 7.260602885715816]);

translate([7, 11, 0]) cube([1, 1, 7.152965575607685]);

translate([8, 11, 0]) cube([1, 1, 6.745022385616434]);

translate([9, 11, 0]) cube([1, 1, 6.544372267554891]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

translate([17, 11, 0]) cube([1, 1, 5.100480494560379]);

translate([18, 11, 0]) cube([1, 1, 5.0003131387717366]);

translate([19, 11, 0]) cube([1, 1, 4.90021569947901]);

translate([20, 11, 0]) cube([1, 1, 4.800180859318871]);

translate([21, 11, 0]) cube([1, 1, 4.8001068568726275]);

translate([22, 11, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 8.2]);

translate([1, 12, 0]) cube([1, 1, 7.7]);

translate([2, 12, 0]) cube([1, 1, 7.30163054857518]);

translate([3, 12, 0]) cube([1, 1, 7.209800232735001]);

translate([4, 12, 0]) cube([1, 1, 7.319423913551167]);

translate([5, 12, 0]) cube([1, 1, 7.469068999595978]);

translate([6, 12, 0]) cube([1, 1, 6.278675171392646]);

translate([7, 12, 0]) cube([1, 1, 7.287933922187695]);

translate([8, 12, 0]) cube([1, 1, 6.952523627524354]);

translate([9, 12, 0]) cube([1, 1, 6.644215178866115]);

translate([10, 12, 0]) cube([1, 1, 6.617018711828358]);

translate([11, 12, 0]) cube([1, 1, 6.60426975225455]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

translate([17, 12, 0]) cube([1, 1, 5.300435207143656]);

translate([18, 12, 0]) cube([1, 1, 5.100307429757888]);

translate([19, 12, 0]) cube([1, 1, 5.0001750745705404]);

translate([20, 12, 0]) cube([1, 1, 4.900138071223014]);

translate([21, 12, 0]) cube([1, 1, 5.000001636683368]);

translate([22, 12, 0]) cube([1, 1, 5.30000000427308]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 8.1]);

translate([1, 13, 0]) cube([1, 1, 7.7]);

translate([2, 13, 0]) cube([1, 1, 7.502108321331064]);

translate([3, 13, 0]) cube([1, 1, 7.50441387296966]);

translate([4, 13, 0]) cube([1, 1, 7.611624274512934]);

translate([5, 13, 0]) cube([1, 1, 7.612012420677257]);

translate([6, 13, 0]) cube([1, 1, 6.277601914986999]);

translate([7, 13, 0]) cube([1, 1, 7.381778244982819]);

translate([8, 13, 0]) cube([1, 1, 7.039940395236325]);

translate([9, 13, 0]) cube([1, 1, 6.832278578422774]);

translate([10, 13, 0]) cube([1, 1, 6.807095729459967]);

translate([11, 13, 0]) cube([1, 1, 6.801504073033513]);

translate([12, 13, 0]) cube([1, 1, 6.601434340949696]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

translate([18, 13, 0]) cube([1, 1, 5.400060087054203]);

translate([19, 13, 0]) cube([1, 1, 5.300015285366896]);

translate([20, 13, 0]) cube([1, 1, 5.200004357767256]);

translate([21, 13, 0]) cube([1, 1, 5.200002160233061]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 13, 0]) cube([1, 1, 6]);

translate([27, 13, 0]) cube([1, 1, 6.6]);

translate([28, 13, 0]) cube([1, 1, 6.7]);

translate([29, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([30, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 8.2]);

translate([1, 14, 0]) cube([1, 1, 7.8]);

translate([2, 14, 0]) cube([1, 1, 7.7]);

translate([3, 14, 0]) cube([1, 1, 7.603083195667858]);

translate([4, 14, 0]) cube([1, 1, 7.606189790023179]);

translate([5, 14, 0]) cube([1, 1, 7.539089035983457]);

translate([6, 14, 0]) cube([1, 1, 7.450748967373147]);

translate([7, 14, 0]) cube([1, 1, 7.252053191312092]);

translate([8, 14, 0]) cube([1, 1, 7.0263544933778395]);

translate([9, 14, 0]) cube([1, 1, 7.009151820763502]);

translate([10, 14, 0]) cube([1, 1, 7.00114397757353]);

translate([11, 14, 0]) cube([1, 1, 6.802163444369278]);

translate([12, 14, 0]) cube([1, 1, 6.601229059722908]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

translate([14, 14, 0]) cube([1, 1, 6.500000125205243]);

translate([15, 14, 0]) cube([1, 1, 6.500000125205243]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 14, 0]) cube([1, 1, 6]);

translate([27, 14, 0]) cube([1, 1, 6.9]);

translate([28, 14, 0]) cube([1, 1, 7.0]);

translate([29, 14, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([30, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 8.1]);

translate([1, 15, 0]) cube([1, 1, 7.8]);

translate([2, 15, 0]) cube([1, 1, 7.7]);

translate([3, 15, 0]) cube([1, 1, 7.501854597138206]);

translate([4, 15, 0]) cube([1, 1, 7.3100433237625415]);

translate([5, 15, 0]) cube([1, 1, 7.121214223428463]);

translate([6, 15, 0]) cube([1, 1, 6.932621083619434]);

translate([7, 15, 0]) cube([1, 1, 6.844185502972116]);

translate([8, 15, 0]) cube([1, 1, 6.91496427729144]);

translate([9, 15, 0]) cube([1, 1, 6.909877682018045]);

translate([10, 15, 0]) cube([1, 1, 6.903362246678371]);

translate([11, 15, 0]) cube([1, 1, 6.7017122173226085]);

translate([12, 15, 0]) cube([1, 1, 6.501289661027811]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

translate([14, 15, 0]) cube([1, 1, 6.500000708263271]);

translate([15, 15, 0]) cube([1, 1, 6.6000000442159585]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 15, 0]) cube([1, 1, 6]);

translate([27, 15, 0]) cube([1, 1, 6.8]);

translate([28, 15, 0]) cube([1, 1, 6.9]);

translate([29, 15, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([30, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 15, 0]) cube([1, 1, 6]);

translate([0, 16, 0]) cube([1, 1, 7.7]);

translate([1, 16, 0]) cube([1, 1, 7.4]);

translate([2, 16, 0]) cube([1, 1, 7.300370919427641]);

translate([3, 16, 0]) cube([1, 1, 7.202453768065677]);

translate([4, 16, 0]) cube([1, 1, 7.007113182478978]);

translate([5, 16, 0]) cube([1, 1, 6.714198362364229]);

translate([6, 16, 0]) cube([1, 1, 6.527781323639931]);

translate([7, 16, 0]) cube([1, 1, 6.526968514434682]);

translate([8, 16, 0]) cube([1, 1, 6.615009317293371]);

translate([9, 16, 0]) cube([1, 1, 6.706019124658383]);

translate([10, 16, 0]) cube([1, 1, 6.8018914182057]);

translate([11, 16, 0]) cube([1, 1, 6.601160980166766]);

translate([12, 16, 0]) cube([1, 1, 6.501107105472306]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

translate([14, 16, 0]) cube([1, 1, 6.500003851412818]);

translate([15, 16, 0]) cube([1, 1, 6.60000035424591]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 16, 0]) cube([1, 1, 6]);

translate([28, 16, 0]) cube([1, 1, 6.7]);

translate([29, 16, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([30, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 16, 0]) cube([1, 1, 6]);

translate([0, 17, 0]) cube([1, 1, 7.1]);

translate([1, 17, 0]) cube([1, 1, 6.900310726189488]);

translate([2, 17, 0]) cube([1, 1, 6.900885539986482]);

translate([3, 17, 0]) cube([1, 1, 6.901669682091864]);

translate([4, 17, 0]) cube([1, 1, 6.705086999000149]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

translate([10, 17, 0]) cube([1, 1, 6.501901515929464]);

translate([11, 17, 0]) cube([1, 1, 6.600436056811526]);

translate([12, 17, 0]) cube([1, 1, 6.500929643459005]);

translate([13, 17, 0]) cube([1, 1, 6.600012112489995]);

translate([14, 17, 0]) cube([1, 1, 6.600002422315707]);

translate([15, 17, 0]) cube([1, 1, 6.600000472707806]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

translate([19, 17, 0]) cube([1, 1, 5.400002765718775]);

translate([20, 17, 0]) cube([1, 1, 5.400001800880924]);

translate([21, 17, 0]) cube([1, 1, 5.400000862492198]);

color([0,1,0])
translate([22, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 17, 0]) cube([1, 1, 6]);

translate([0, 18, 0]) cube([1, 1, 6.80007768148486]);

translate([1, 18, 0]) cube([1, 1, 6.600519217404887]);

translate([2, 18, 0]) cube([1, 1, 6.600520332668657]);

translate([3, 18, 0]) cube([1, 1, 6.501632510429615]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

translate([12, 18, 0]) cube([1, 1, 6.600072675970379]);

translate([13, 18, 0]) cube([1, 1, 6.8]);

translate([14, 18, 0]) cube([1, 1, 6.9]);

translate([15, 18, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

translate([19, 18, 0]) cube([1, 1, 5.400001950147428]);

translate([20, 18, 0]) cube([1, 1, 5.200003970204252]);

translate([21, 18, 0]) cube([1, 1, 5.200003976336801]);

translate([22, 18, 0]) cube([1, 1, 5.300000215358415]);

color([0,1,0])
translate([23, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 6.800019420171439]);

translate([1, 19, 0]) cube([1, 1, 6.600380178568571]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

translate([7, 19, 0]) cube([1, 1, 5.411779301482271]);

translate([8, 19, 0]) cube([1, 1, 5.413886597164904]);

color([0,1,0])
translate([9, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

translate([13, 19, 0]) cube([1, 1, 6.9]);

translate([14, 19, 0]) cube([1, 1, 7.1]);

translate([15, 19, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([16, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);

translate([20, 19, 0]) cube([1, 1, 5.40000039581719]);

translate([21, 19, 0]) cube([1, 1, 5.200004012478484]);

translate([22, 19, 0]) cube([1, 1, 5.300000072990677]);

color([0,1,0])
translate([23, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 19, 0]) cube([1, 1, 6]);

translate([0, 20, 0]) cube([1, 1, 7.0]);

translate([1, 20, 0]) cube([1, 1, 6.800003883975867]);

color([0,1,0])
translate([2, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

translate([6, 20, 0]) cube([1, 1, 5.4052792618639245]);

translate([7, 20, 0]) cube([1, 1, 5.259746825478859]);

translate([8, 20, 0]) cube([1, 1, 5.411050890158389]);

color([0,1,0])
translate([9, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

translate([13, 20, 0]) cube([1, 1, 6.8]);

translate([14, 20, 0]) cube([1, 1, 7.0]);

translate([15, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

translate([21, 20, 0]) cube([1, 1, 5.300000080065648]);

translate([22, 20, 0]) cube([1, 1, 5.30000004557716]);

translate([23, 20, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([24, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 20, 0]) cube([1, 1, 6]);

translate([31, 20, 0]) cube([1, 1, 5.3]);

translate([0, 21, 0]) cube([1, 1, 7.1]);

translate([1, 21, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

translate([4, 21, 0]) cube([1, 1, 5.401768764931189]);

translate([5, 21, 0]) cube([1, 1, 5.3038710381998255]);

translate([6, 21, 0]) cube([1, 1, 5.304430956285916]);

translate([7, 21, 0]) cube([1, 1, 5.405066259487916]);

color([0,1,0])
translate([8, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

translate([13, 21, 0]) cube([1, 1, 6.7]);

translate([14, 21, 0]) cube([1, 1, 6.9]);

translate([15, 21, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

translate([22, 21, 0]) cube([1, 1, 5.300000048583656]);

translate([23, 21, 0]) cube([1, 1, 5.300000044977761]);

translate([24, 21, 0]) cube([1, 1, 5.3000000209418285]);

translate([25, 21, 0]) cube([1, 1, 5.300000019708908]);

color([0,1,0])
translate([26, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 21, 0]) cube([1, 1, 6]);

translate([30, 21, 0]) cube([1, 1, 5.4]);

translate([31, 21, 0]) cube([1, 1, 5.1]);

translate([0, 22, 0]) cube([1, 1, 7.1]);

translate([1, 22, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

translate([4, 22, 0]) cube([1, 1, 5.2084230784648256]);

translate([5, 22, 0]) cube([1, 1, 5.2085123073954485]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

translate([13, 22, 0]) cube([1, 1, 6.7]);

translate([14, 22, 0]) cube([1, 1, 6.8]);

translate([15, 22, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

translate([24, 22, 0]) cube([1, 1, 5.4]);

translate([25, 22, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([26, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 22, 0]) cube([1, 1, 6]);

translate([30, 22, 0]) cube([1, 1, 5.2]);

translate([31, 22, 0]) cube([1, 1, 4.9]);

translate([0, 23, 0]) cube([1, 1, 6.9]);

translate([1, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 23, 0]) cube([1, 1, 6]);

translate([4, 23, 0]) cube([1, 1, 5.400076710425371]);

color([0,1,0])
translate([5, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 23, 0]) cube([1, 1, 6]);

translate([12, 23, 0]) cube([1, 1, 6.7]);

translate([13, 23, 0]) cube([1, 1, 6.9]);

translate([14, 23, 0]) cube([1, 1, 7.0]);

translate([15, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([16, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 23, 0]) cube([1, 1, 6]);

translate([29, 23, 0]) cube([1, 1, 5.3]);

translate([30, 23, 0]) cube([1, 1, 5.0]);

translate([31, 23, 0]) cube([1, 1, 4.8]);

translate([0, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 24, 0]) cube([1, 1, 6]);

translate([11, 24, 0]) cube([1, 1, 6.7]);

translate([12, 24, 0]) cube([1, 1, 7.0]);

translate([13, 24, 0]) cube([1, 1, 7.1]);

translate([14, 24, 0]) cube([1, 1, 7.1]);

translate([15, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([16, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 24, 0]) cube([1, 1, 6]);

translate([27, 24, 0]) cube([1, 1, 5.4]);

translate([28, 24, 0]) cube([1, 1, 5.3]);

translate([29, 24, 0]) cube([1, 1, 5.0]);

translate([30, 24, 0]) cube([1, 1, 4.8]);

translate([31, 24, 0]) cube([1, 1, 4.6]);

color([0,1,0])
translate([0, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 25, 0]) cube([1, 1, 6]);

translate([11, 25, 0]) cube([1, 1, 6.9]);

translate([12, 25, 0]) cube([1, 1, 7.2]);

translate([13, 25, 0]) cube([1, 1, 7.2]);

translate([14, 25, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([15, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 25, 0]) cube([1, 1, 6]);

translate([25, 25, 0]) cube([1, 1, 5.4]);

translate([26, 25, 0]) cube([1, 1, 5.4]);

translate([27, 25, 0]) cube([1, 1, 5.4]);

translate([28, 25, 0]) cube([1, 1, 5.2]);

translate([29, 25, 0]) cube([1, 1, 5.0]);

translate([30, 25, 0]) cube([1, 1, 4.7]);

translate([31, 25, 0]) cube([1, 1, 4.5]);

color([0,1,0])
translate([0, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 26, 0]) cube([1, 1, 6]);

translate([10, 26, 0]) cube([1, 1, 6.7]);

translate([11, 26, 0]) cube([1, 1, 6.9]);

translate([12, 26, 0]) cube([1, 1, 7.0]);

translate([13, 26, 0]) cube([1, 1, 6.9]);

translate([14, 26, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([15, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 26, 0]) cube([1, 1, 6]);

translate([25, 26, 0]) cube([1, 1, 5.4]);

translate([26, 26, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([27, 26, 0]) cube([1, 1, 6]);

translate([28, 26, 0]) cube([1, 1, 5.4]);

translate([29, 26, 0]) cube([1, 1, 5.3]);

translate([30, 26, 0]) cube([1, 1, 5.0]);

translate([31, 26, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 27, 0]) cube([1, 1, 6]);

translate([9, 27, 0]) cube([1, 1, 6.6]);

translate([10, 27, 0]) cube([1, 1, 6.7]);

translate([11, 27, 0]) cube([1, 1, 6.7]);

translate([12, 27, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([13, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 27, 0]) cube([1, 1, 6]);

translate([31, 27, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([0, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 28, 0]) cube([1, 1, 6]);

translate([27, 28, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 29, 0]) cube([1, 1, 6]);

translate([26, 29, 0]) cube([1, 1, 5.4]);

translate([27, 29, 0]) cube([1, 1, 5.3]);

translate([28, 29, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([29, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 30, 0]) cube([1, 1, 6]);

translate([1, 30, 0]) cube([1, 1, 5.4]);

translate([2, 30, 0]) cube([1, 1, 5.4]);

translate([3, 30, 0]) cube([1, 1, 5.4]);

translate([4, 30, 0]) cube([1, 1, 5.3]);

translate([5, 30, 0]) cube([1, 1, 5.2]);

translate([6, 30, 0]) cube([1, 1, 5.1]);

translate([7, 30, 0]) cube([1, 1, 5.3]);

translate([8, 30, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([9, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 30, 0]) cube([1, 1, 6]);

translate([11, 30, 0]) cube([1, 1, 5.3]);

translate([12, 30, 0]) cube([1, 1, 5.2]);

translate([13, 30, 0]) cube([1, 1, 5.3]);

translate([14, 30, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([15, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 30, 0]) cube([1, 1, 6]);

translate([22, 30, 0]) cube([1, 1, 5.3]);

translate([23, 30, 0]) cube([1, 1, 5.3]);

translate([24, 30, 0]) cube([1, 1, 5.4]);

translate([25, 30, 0]) cube([1, 1, 5.4]);

translate([26, 30, 0]) cube([1, 1, 5.3]);

translate([27, 30, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([28, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 30, 0]) cube([1, 1, 6]);

translate([0, 31, 0]) cube([1, 1, 5.3]);

translate([1, 31, 0]) cube([1, 1, 5.2]);

translate([2, 31, 0]) cube([1, 1, 5.2]);

translate([3, 31, 0]) cube([1, 1, 5.3]);

translate([4, 31, 0]) cube([1, 1, 5.2]);

translate([5, 31, 0]) cube([1, 1, 5.0]);

translate([6, 31, 0]) cube([1, 1, 4.9]);

translate([7, 31, 0]) cube([1, 1, 5.0]);

translate([8, 31, 0]) cube([1, 1, 5.1]);

translate([9, 31, 0]) cube([1, 1, 5.1]);

translate([10, 31, 0]) cube([1, 1, 5.0]);

translate([11, 31, 0]) cube([1, 1, 4.8]);

translate([12, 31, 0]) cube([1, 1, 4.7]);

translate([13, 31, 0]) cube([1, 1, 4.8]);

translate([14, 31, 0]) cube([1, 1, 5.1]);

translate([15, 31, 0]) cube([1, 1, 5.3]);

translate([16, 31, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([17, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 31, 0]) cube([1, 1, 6]);

translate([22, 31, 0]) cube([1, 1, 5.2]);

translate([23, 31, 0]) cube([1, 1, 5.1]);

translate([24, 31, 0]) cube([1, 1, 5.2]);

translate([25, 31, 0]) cube([1, 1, 5.2]);

translate([26, 31, 0]) cube([1, 1, 5.3]);

translate([27, 31, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 31, 0]) cube([1, 1, 6]);
