
hull() {
    translate([0.5409, 0.5037, 4.97725]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.2771000000000001, 0.5702999999999999, 4.56775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.3589000000000002, 0.5851999999999999, 4.5223]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.0951, 0.7868, 4.1137]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.17695, 0.8165500000000001, 4.06825]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.91405, 1.15045, 3.6587500000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.9959, 1.19495, 3.6133]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.7321, 1.6620499999999998, 3.2047]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.8139000000000003, 1.72135, 3.15925]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.5501, 2.32165, 2.7497499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.6319, 2.39595, 2.7043]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.3681, 3.13305, 2.2957]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.4499, 3.2222999999999997, 2.2502500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.186100000000001, 4.0917, 1.84075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.2679, 4.1958, 1.7953000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.0041, 5.200200000000001, 1.3867]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.08595, 5.31925, 1.34125]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.82305, 6.45775, 0.9317500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.9049000000000005, 6.59165, 0.8863000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.6411, 7.8633500000000005, 0.4777]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.722900000000001, 8.0123, 0.43225]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.459100000000001, 9.421700000000001, 0.022750000000000003]) cube([0.4, 0.4, 0.1], center=true);
}

