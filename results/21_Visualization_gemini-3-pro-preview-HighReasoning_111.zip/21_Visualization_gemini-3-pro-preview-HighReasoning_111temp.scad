
hull() {
    translate([13.9965, 7.5465, 8.991999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.9335, 8.3835, 8.848]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.920000000000002, 8.4755, 8.832]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.740000000000002, 9.294500000000001, 8.688]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.713500000000002, 9.384500000000001, 8.672]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.416500000000001, 10.185500000000001, 8.528]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.377500000000001, 10.2725, 8.512]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.9725, 11.0375, 8.368]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.921999999999999, 11.12, 8.352]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.418000000000001, 11.84, 8.208]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.356500000000002, 11.9175, 8.192499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.7535, 12.592500000000001, 8.057500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.682, 12.6635, 8.042000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.998000000000001, 13.2665, 7.898]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.918000000000001, 13.329, 7.882]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.161999999999999, 13.851, 7.738000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.074499999999999, 13.904000000000002, 7.722000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.255500000000001, 14.336, 7.578000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.162500000000001, 14.378499999999999, 7.562000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.307500000000001, 14.711500000000001, 7.418000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.211, 14.743000000000002, 7.402000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.329000000000001, 14.977, 7.258000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.23, 14.9975, 7.242000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.33, 15.132500000000002, 7.098000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.23, 15.1415, 7.082000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.330000000000001, 15.168500000000002, 6.938000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.231000000000001, 15.166, 6.922000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.349, 15.094, 6.7780000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.252, 15.0805, 6.7620000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.388, 14.909500000000001, 6.618]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.2944999999999998, 14.885, 6.602]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.4755000000000003, 14.615, 6.458]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3875, 14.579500000000001, 6.442500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.6225, 14.2105, 6.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5415, 14.164499999999999, 6.292]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.8485000000000001, 13.705499999999999, 6.148]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.7755000000000001, 13.649999999999999, 6.132]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.1545, 13.11, 5.988]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.091, 13.046, 5.972]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.43100000000000005, 12.434000000000001, 5.828]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.48300000000000004, 12.362, 5.812]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.897, 11.678, 5.668]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.9365000000000001, 11.5995, 5.652]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.2335, 10.8705, 5.508]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.26, 10.786999999999999, 5.4965]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.44, 10.013000000000002, 5.4334999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.4535, 9.926, 5.4265]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.5165000000000002, 9.134, 5.363500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.5165000000000002, 9.046000000000001, 5.357000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.4535, 8.254000000000001, 5.303]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.44, 8.166500000000001, 5.2965]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.26, 7.3835, 5.233500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.2335, 7.298, 5.226500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.9365000000000001, 6.542000000000001, 5.1635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.8975000000000001, 6.4595, 5.1565]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.4925, 5.730500000000001, 5.093500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.441, 5.652, 5.0865]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.081, 4.968, 5.023499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.14450000000000002, 4.8950000000000005, 5.0165]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.7655000000000001, 4.265000000000001, 4.9535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.8395000000000001, 4.1985, 4.947]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.5505, 3.6315000000000004, 4.893]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.6335000000000002, 3.5730000000000004, 4.8865]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.4165, 3.087, 4.8235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.507, 3.038, 4.8165000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.353, 2.642, 4.753500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.4495, 2.6035, 4.7465]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.3405, 2.3064999999999998, 4.6834999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.441, 2.279, 4.6765]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.359000000000001, 2.081, 4.6135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.462000000000001, 2.0645, 4.607]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.398000000000001, 1.9655, 4.553]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.502000000000001, 1.9605000000000001, 4.5465]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.438000000000001, 1.9695, 4.483500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.541, 1.976, 4.476500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.459, 2.084, 4.4135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.5595, 2.1015, 4.4065]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.4505, 2.3085, 4.343500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.547500000000001, 2.337, 4.3365]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.4025, 2.6430000000000002, 4.273499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.494499999999999, 2.682, 4.2665]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.295499999999999, 3.078, 4.2035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.381, 3.1275, 4.197]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.119000000000002, 3.6225, 4.143]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.1965, 3.6820000000000004, 4.1365]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.8535, 4.258, 4.0735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.921000000000001, 4.3260000000000005, 4.0665000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.479000000000001, 4.974, 4.0035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.534500000000001, 5.049, 3.9965]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.9755, 5.751, 3.9335000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.0185, 5.831, 3.9265000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.3515, 6.569000000000001, 3.8634999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.381499999999999, 6.6530000000000005, 3.8569999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.5885, 7.427, 3.803]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.605, 7.514, 3.7965]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.695, 8.306, 3.7335000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.698, 8.394499999999999, 3.7265]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.662, 9.195500000000001, 3.6635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.6515, 9.2835, 3.6565000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4985, 10.0665, 3.5934999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4745, 10.1525, 3.5865]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.195500000000001, 10.9175, 3.5235000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.1585, 11.0005, 3.5165]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.7715, 11.7295, 3.4535000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.722, 11.807500000000001, 3.4470000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.218, 12.482500000000002, 3.3930000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.156, 12.5545, 3.3865000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.544, 13.175500000000001, 3.3235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.470500000000001, 13.2405, 3.3165]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.7595, 13.7895, 3.2535000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.6755, 13.846, 3.2465]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.8745, 14.314, 3.1835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.7815, 14.3605, 3.1765]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.9085, 14.7295, 3.1135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.8085, 14.765, 3.107]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.881499999999999, 15.035000000000002, 3.053]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.776, 15.059500000000002, 3.0465]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.804, 15.230500000000001, 2.9835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.695, 15.243500000000001, 2.9765]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.705, 15.3065, 2.9135000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.595000000000001, 15.307500000000001, 2.9065000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.605, 15.2625, 2.8435]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.4955, 15.252, 2.8365]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.5145, 15.108, 2.7735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.407500000000001, 15.086, 2.7664999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.4625000000000004, 14.834000000000001, 2.7035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3600000000000003, 14.800500000000001, 2.697]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.46, 14.4495, 2.6430000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.3635, 14.405000000000001, 2.6365000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.5265, 13.955000000000002, 2.5734999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.4380000000000002, 13.9, 2.5664999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.682, 13.36, 2.5035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.6035, 13.295, 2.4965]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.0535, 12.665000000000001, 2.4335000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.1205, 12.591000000000001, 2.4265000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.6695, 11.889, 2.3635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.7235, 11.8075, 2.357]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.1464999999999999, 11.0425, 2.303]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.186, 10.9545, 2.2965]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.474, 10.1355, 2.2335000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.499, 10.043, 2.2265]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.661, 9.197000000000001, 2.1635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.6709999999999998, 9.102500000000001, 2.1565000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.6889999999999998, 8.2475, 2.0935]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.6835, 8.1525, 2.0865]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.5665000000000002, 7.2975, 2.0235]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.5465000000000002, 7.2035, 2.0165]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.3035, 6.3665, 1.9535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.2690000000000001, 6.275500000000001, 1.9469999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.891, 5.4745, 1.8929999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.8425, 5.3885, 1.8864999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.34750000000000003, 4.6415, 1.8235000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.28650000000000003, 4.561999999999999, 1.8165000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.3165, 3.878, 1.7535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.3885, 3.8064999999999998, 1.7465]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.0815000000000001, 3.2035, 1.6835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1625000000000003, 3.1415, 1.6765]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9275, 2.6285000000000003, 1.6135000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.016, 2.5770000000000004, 1.6070000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.844, 2.1630000000000003, 1.553]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.939, 2.1235, 1.5465]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.821, 1.8265, 1.4835]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.9205, 1.8, 1.4765000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.8295, 1.62, 1.4135]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.931500000000001, 1.606, 1.4064999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.8585, 1.534, 1.3435000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.962, 1.5325, 1.3365000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.898, 1.5775000000000001, 1.2735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.0009999999999994, 1.5890000000000002, 1.2665]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.9190000000000005, 1.7510000000000001, 1.2035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.019, 1.7750000000000001, 1.197]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.901, 2.045, 1.143]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.9965, 2.0815, 1.1365]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.8335, 2.4685, 1.0735000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.923000000000002, 2.5165, 1.0665]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.697000000000001, 2.9935, 1.0035]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.778500000000001, 3.0515, 0.9975]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.4715, 3.6185, 0.9525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.5435, 3.6865, 0.948]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.1465, 4.343500000000001, 0.912]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.208, 4.4195, 0.9075000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.712000000000002, 5.1305000000000005, 0.8625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.762500000000001, 5.213, 0.858]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.1675, 5.987, 0.822]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.206, 6.075000000000001, 0.8175]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.494, 6.885, 0.7725000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.520000000000001, 6.976, 0.768]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.700000000000001, 7.803999999999999, 0.732]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.713000000000001, 7.896999999999999, 0.7275]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.767000000000001, 8.743, 0.6825000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.767000000000001, 8.8365, 0.6780000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.713000000000001, 9.6735, 0.6420000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.7005, 9.766000000000002, 0.6375000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.529499999999999, 10.594000000000001, 0.5925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.504, 10.684000000000001, 0.5880000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.216, 11.476, 0.552]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.177999999999999, 11.5615, 0.5475000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.782, 12.3085, 0.5025000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.7325, 12.3885, 0.4975]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.2375, 13.0815, 0.4525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.177000000000001, 13.155, 0.448]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.583000000000002, 13.785, 0.412]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.512, 13.8505, 0.4075]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.828, 14.3995, 0.36250000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.748000000000001, 14.455, 0.358]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.992, 14.905, 0.322]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.904, 14.9495, 0.31750000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.075999999999999, 15.3005, 0.2725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.981499999999999, 15.3335, 0.268]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.108500000000001, 15.576500000000001, 0.232]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.01, 15.5975, 0.22750000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.11, 15.7325, 0.1825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.0095, 15.741, 0.178]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.1005, 15.759, 0.14200000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.9990000000000006, 15.7545, 0.13750000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.081, 15.6555, 0.0925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.9795, 15.6385, 0.08800000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.0705, 15.4315, 0.052000000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.971, 15.402000000000001, 0.04750000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.0890000000000004, 15.078, 0.0025000000000000005]) cube([0.4, 0.4, 0.1], center=true);
}

