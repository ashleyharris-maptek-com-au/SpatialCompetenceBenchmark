color([1, 0, 1]) hull()
{
  translate([43.00015, 25.0166, 47.7]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.0028500000000005, 25.3154, 42.300000000000004]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.0023, 25.2822, 41.7]) cube([0.4, 0.4, 0.1], center = true);
  translate([42.9897, 24.3858, 36.3]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([42.9908, 24.4188, 35.699999999999996]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.023200000000001, 25.909200000000002, 30.3]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.021550000000001, 25.876450000000002, 29.7]) cube([0.4, 0.4, 0.1], center = true);
  translate([42.959450000000004, 23.796550000000003, 24.3]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([42.961850000000005, 23.830350000000003, 23.700000000000003]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.067150000000001, 26.51865, 18.3]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.064350000000001, 26.4856, 17.7]) cube([0.4, 0.4, 0.1], center = true);
  translate([42.908649999999994, 23.2024, 12.3]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([42.9118, 23.235, 11.700000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.1242, 27.105, 6.300000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.1222, 27.086000000000002, 5.7]) cube([0.4, 0.4, 0.1], center = true);
  translate([42.8738, 22.874000000000002, 0.30000000000000004]) cube([0.4, 0.4, 0.1], center = true);
}
