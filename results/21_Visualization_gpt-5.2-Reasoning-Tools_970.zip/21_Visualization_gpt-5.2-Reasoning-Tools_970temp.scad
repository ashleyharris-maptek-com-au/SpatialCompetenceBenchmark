
hull() {
    translate([94.9983, 50.087450000000004, 94.9987]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.9677, 51.661550000000005, 94.9753]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.9609, 51.83635, 94.9727]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.8691, 53.40865, 94.9493]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.8555, 53.5831, 94.94675]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.70250000000001, 55.1509, 94.92425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.68215000000001, 55.32465, 94.9217]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.46884999999999, 56.88435, 94.8983]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.44174999999998, 57.05715, 94.8957]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.16725, 58.607850000000006, 94.8723]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.13345, 58.779500000000006, 94.8697]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.79955, 60.31850000000001, 94.8463]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.7591, 60.48870000000001, 94.8437]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.3649, 62.0133, 94.8203]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.31785, 62.181799999999996, 94.81775]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.86515000000001, 63.6902, 94.79525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.81160000000001, 63.85675, 94.7927]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.30040000000001, 65.34625000000001, 94.7693]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.24045000000001, 65.51055000000001, 94.7667]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.67255, 66.97845000000001, 94.7433]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.60625, 67.14030000000001, 94.7407]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.98075, 68.5857, 94.7173]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.90814999999999, 68.7449, 94.71475]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.22684999999998, 70.1651, 94.69225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.14814999999999, 70.32135, 94.6897]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.41284999999999, 71.71365, 94.6663]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.32815, 71.86670000000001, 94.6637]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.53885000000001, 73.22930000000001, 94.6403]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.44825000000002, 73.37895, 94.6377]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.60675, 74.71005000000001, 94.6143]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.5104, 74.85605000000001, 94.6117]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.6176, 76.15294999999999, 94.5883]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.51565, 76.29509999999999, 94.58575]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.57335, 77.5569, 94.56325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.46595, 77.695, 94.5607]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.47505000000001, 78.919, 94.5373]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.36235, 79.0528, 94.5347]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.32464999999999, 80.2372, 94.5113]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.20684999999999, 80.36655, 94.5087]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.12414999999999, 81.51045, 94.4853]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.00139999999999, 81.63515, 94.48270000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.8746, 82.73585, 94.45930000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.74715, 82.85565000000001, 94.45675000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.57985000000001, 83.91135000000001, 94.43425000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.44805000000001, 84.02610000000001, 94.4317]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.24295000000001, 85.03590000000001, 94.4083]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.107, 85.14540000000001, 94.40570000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.86500000000001, 86.1066, 94.38230000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.72510000000001, 86.2107, 94.37970000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.4489, 87.12330000000001, 94.3563]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.3053, 87.22185, 94.3537]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.99670000000002, 88.08315, 94.3303]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.84960000000001, 88.17595000000001, 94.32775]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.5104, 88.98505000000002, 94.30525000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.36005, 89.07205, 94.30270000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.99295000000001, 89.82894999999999, 94.2793]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.83965, 89.9101, 94.2767]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.44735, 90.61390000000002, 94.2533]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.29135000000001, 90.68905000000001, 94.2507]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.87565, 91.33794999999999, 94.2273]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.71715, 91.40705, 94.2247]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.27985000000001, 92.00195000000001, 94.2013]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.1191, 92.06495000000001, 94.19875]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.6629, 92.60405, 94.17625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.50019999999999, 92.6608, 94.1737]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.0278, 93.14320000000001, 94.1503]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.8634, 93.1937, 94.1477]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.376599999999996, 93.6203, 94.1243]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.210750000000004, 93.6645, 94.1217]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.71225, 94.0335, 94.0983]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.5452, 94.07135, 94.0957]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.03680000000001, 94.38364999999999, 94.0723]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.86880000000001, 94.41515, 94.06975]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.3532, 94.66985, 94.04725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.18455, 94.69489999999999, 94.0447]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.66445, 94.8911, 94.0213]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.49535, 94.9097, 94.0187]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.971650000000004, 95.0483, 93.9953]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.802350000000004, 95.06049999999999, 93.9927]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.278650000000006, 95.1415, 93.9693]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.10945, 95.14725, 93.9667]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.58755, 95.16975000000001, 93.9433]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.4187, 95.16905000000001, 93.94075]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.9013, 95.13395000000001, 93.91825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.7331, 95.12685, 93.9157]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.2229, 95.03415, 93.8923]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.055550000000004, 95.0206, 93.8897]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.553450000000005, 94.86940000000001, 93.8663]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.387150000000005, 94.84940000000002, 93.8637]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.89585, 94.6406, 93.8403]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.730850000000004, 94.61425, 93.8377]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.25215000000001, 94.34875000000001, 93.8143]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.088750000000005, 94.31605000000002, 93.81175]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.626250000000006, 93.99295000000001, 93.78925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.46470000000001, 93.95395, 93.7867]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.0193, 93.57505, 93.7633]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.85985, 93.52985, 93.7607]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.43515000000001, 93.09515, 93.7373]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.27805000000001, 93.0438, 93.7347]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.87495, 92.5542, 93.7113]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.7204, 92.4968, 93.7087]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.3416, 91.9532, 93.6853]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.1899, 91.8898, 93.68275]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.8381, 91.2922, 93.66025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.689500000000002, 91.22295, 93.6577]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.366500000000002, 90.57405, 93.6343]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.22125, 90.49905, 93.6317]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.929750000000002, 89.79795, 93.6083]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.7881, 89.71735000000001, 93.6057]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.5299, 88.96765, 93.5823]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.392100000000003, 88.88165000000001, 93.57970000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.169900000000002, 88.08335, 93.55630000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.0362, 87.99205, 93.55375000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.8518, 87.14695, 93.53125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.7224, 87.0505, 93.5287]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.5776, 86.1595, 93.5053]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.45275, 86.05805, 93.5027]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.350250000000003, 85.12295, 93.4793]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.230200000000004, 85.0167, 93.47670000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.1718, 84.0393, 93.45330000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.05675, 83.9284, 93.45070000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.04425, 82.9096, 93.4273]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.9344, 82.7942, 93.42475]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.9696, 81.73580000000001, 93.40225000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.8652, 81.61610000000002, 93.39970000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.9508, 80.5199, 93.37630000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.85205, 80.3961, 93.37370000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.98895, 79.2639, 93.3503]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.89605, 79.1362, 93.3477]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.08695, 77.9698, 93.3243]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.0001, 77.83835, 93.32169999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.2459, 76.63865, 93.2983]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.16525, 76.50365, 93.29575]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.46775, 75.27335, 93.27325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.3935, 75.13495, 93.2707]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.7545, 73.87405000000001, 93.2473]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.68675, 73.7325, 93.2447]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.106250000000001, 72.4455, 93.2213]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.045100000000001, 72.301, 93.2187]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.524900000000002, 70.987, 93.1953]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.470550000000001, 70.8397, 93.1927]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.01245, 69.50229999999999, 93.1693]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.96495, 69.35249999999999, 93.16675000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.56805, 67.99350000000001, 93.14425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.5275, 67.84140000000001, 93.1417]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.194500000000001, 66.4626, 93.1183]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.161000000000001, 66.3085, 93.1157]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.891, 64.9135, 93.0923]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.8646, 64.75765, 93.0897]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.6594, 63.34735, 93.0663]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.6402, 63.19, 93.0637]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.499800000000002, 61.768, 93.0403]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.487850000000002, 61.6095, 93.0377]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.41315, 60.17849999999999, 93.0143]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.4085, 60.01904999999999, 93.01175]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.3995, 58.57995, 92.98925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.402149999999999, 58.419799999999995, 92.9867]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.45885, 56.976200000000006, 92.9633]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.468850000000002, 56.815650000000005, 92.9607]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.592150000000002, 55.369350000000004, 92.93730000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.6095, 55.208650000000006, 92.9347]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.798499999999999, 53.76235, 92.9113]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.82315, 53.60175, 92.9087]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.077850000000002, 52.157250000000005, 92.8853]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.109800000000002, 51.997, 92.88275]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.430200000000001, 50.557, 92.86025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.4695, 50.397349999999996, 92.8577]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.8565, 48.96365, 92.8343]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.903100000000002, 48.8049, 92.8317]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.3549, 47.3811, 92.8083]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.408750000000001, 47.2235, 92.8057]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.92625, 45.8105, 92.7823]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.9873, 45.6543, 92.7797]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.568700000000002, 44.2557, 92.7563]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.636900000000002, 44.1012, 92.75375]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.283100000000001, 42.7188, 92.73125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.3584, 42.5662, 92.7287]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.067599999999999, 41.2018, 92.7053]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.14995, 41.05135, 92.7027]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.92305, 39.70765000000001, 92.6793]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.012349999999998, 39.559650000000005, 92.6767]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.84665, 38.239349999999995, 92.6533]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.94275, 38.093999999999994, 92.65070000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.838250000000002, 36.798, 92.62730000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.941100000000002, 36.655550000000005, 92.62475]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.8969, 35.38745, 92.60225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.0064, 35.2482, 92.5997]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.0216, 34.009800000000006, 92.5763]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.13765, 33.874, 92.57370000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.211350000000003, 32.668, 92.55030000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.33385, 32.5359, 92.54770000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.465149999999998, 31.3641, 92.52430000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.59395, 31.236, 92.52170000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.781050000000004, 30.102000000000004, 92.4983]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.916000000000004, 29.978200000000005, 92.49575]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.158, 28.8838, 92.47325000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.299, 28.764499999999998, 92.47070000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.595000000000002, 27.7115, 92.44730000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.741850000000003, 27.596999999999998, 92.44470000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.089150000000004, 26.589000000000002, 92.4213]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.241650000000003, 26.479600000000005, 92.4187]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.63935, 25.518400000000003, 92.3953]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.7974, 25.4143, 92.3927]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.2446, 24.5017, 92.3693]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.408, 24.40315, 92.36675]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.902, 23.54185, 92.34425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.070499999999996, 23.44905, 92.3417]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.6095, 22.63995, 92.3183]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.7829, 22.5531, 92.31569999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.365100000000005, 21.798900000000003, 92.2923]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.54325000000001, 21.718300000000003, 92.2897]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.167750000000005, 21.021700000000003, 92.2663]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.3504, 20.9475, 92.2637]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.013600000000004, 20.3085, 92.2403]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.200450000000004, 20.2409, 92.23775]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.900549999999996, 19.6631, 92.21525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.091449999999995, 19.6023, 92.2127]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.827549999999995, 19.0857, 92.1893]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.02225, 19.0318, 92.1867]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.79075, 18.578200000000002, 92.1633]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.98895, 18.5314, 92.1607]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.78805, 18.142599999999998, 92.1373]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.98949999999999, 18.102949999999996, 92.1347]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.816500000000005, 17.77805, 92.1113]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.020900000000005, 17.74565, 92.10875]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.8731, 17.48735, 92.08624999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.0802, 17.46235, 92.0837]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.9558, 17.270650000000003, 92.0603]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.165350000000004, 17.253100000000003, 92.0577]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.06165, 17.1289, 92.0343]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.2733, 17.11895, 92.0317]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.1867, 17.06405, 92.0083]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.400150000000004, 17.06175, 92.0057]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.32885, 17.07525, 91.9823]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.543850000000006, 17.0806, 91.97975]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.485150000000004, 17.1634, 91.95725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.70140000000001, 17.1765, 91.9547]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.6526, 17.3295, 91.93130000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.8698, 17.350450000000002, 91.9287]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.8282, 17.574550000000002, 91.9053]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.04605, 17.60335, 91.9027]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.00895, 17.897650000000002, 91.8793]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.2271, 17.934350000000002, 91.8767]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.1909, 18.30065, 91.8533]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.409, 18.3453, 91.85075]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.37100000000001, 18.7827, 91.82825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.5888, 18.835299999999997, 91.8257]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.5472, 19.3447, 91.8023]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.76440000000001, 19.4053, 91.7997]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.71560000000001, 19.9867, 91.7763]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.9319, 20.05525, 91.7737]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.8741, 20.707749999999997, 91.7503]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.0892, 20.78425, 91.7477]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.01880000000001, 21.508750000000003, 91.7243]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.23235000000001, 21.593200000000003, 91.72175]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.14665000000001, 22.388800000000003, 91.69924999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.3584, 22.481150000000003, 91.69669999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.2556, 23.34785, 91.6733]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.46525000000001, 23.44805, 91.6707]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.34175, 24.38495, 91.6473]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.54899999999999, 24.49295, 91.64470000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.40299999999999, 25.50005, 91.62130000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.60759999999999, 25.615750000000002, 91.61870000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.43639999999999, 26.69125, 91.59530000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.63804999999999, 26.814600000000002, 91.59275000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.43894999999999, 27.959400000000002, 91.57025000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.63735, 28.09035, 91.56770000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.40765, 29.30265, 91.54430000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.6025, 29.44105, 91.54170000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.33950000000002, 30.71995, 91.51830000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.53050000000002, 30.86575, 91.51570000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.2315, 32.21125, 91.4923]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.41834999999999, 32.3643, 91.4897]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.08065, 33.7737, 91.4663]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.26310000000001, 33.9339, 91.46375]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.8849, 35.408100000000005, 91.44125000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.0627, 35.57535, 91.43870000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.6413, 37.111650000000004, 91.4153]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.81415, 37.28575000000001, 91.4127]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.34685, 38.883250000000004, 91.3893]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.5145, 39.0641, 91.3867]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.9995, 40.7219, 91.3633]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([109.16165000000001, 40.909349999999996, 91.3607]) cube([0.4, 0.4, 0.1], center=true);
    translate([110.59535, 42.62564999999999, 91.3373]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.75175, 42.819599999999994, 91.33475]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.13324999999999, 44.5944, 91.31225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([112.2837, 44.7947, 91.3097]) cube([0.4, 0.4, 0.1], center=true);
    translate([113.61030000000001, 46.625299999999996, 91.2863]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.75455000000001, 46.8317, 91.2837]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.02445, 48.7163, 91.2603]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([115.16225, 48.92865, 91.2577]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.37275000000001, 50.86635, 91.2343]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.50390000000002, 51.08445, 91.2317]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.6541, 53.07255, 91.2083]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.77835, 53.2962, 91.20575]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.86465, 55.333800000000004, 91.18325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118.98179999999999, 55.562850000000005, 91.1807]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.0042, 57.64815, 91.1573]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.11410000000001, 57.88235, 91.1547]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.0699, 60.01265, 91.1313]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.1723, 60.25175, 91.1287]) cube([0.4, 0.4, 0.1], center=true);
    translate([122.05969999999999, 62.425250000000005, 91.1053]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.15445, 62.669050000000006, 91.1027]) cube([0.4, 0.4, 0.1], center=true);
    translate([122.97255, 64.88395, 91.0793]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.0595, 65.1322, 91.07675]) cube([0.4, 0.4, 0.1], center=true);
    translate([123.8065, 67.38579999999999, 91.05425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.88550000000001, 67.63825, 91.0517]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.56049999999999, 69.92875, 91.0283]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([124.6314, 70.18515, 91.0257]) cube([0.4, 0.4, 0.1], center=true);
    translate([125.2326, 72.50985, 91.0023]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.29525000000001, 72.7699, 90.9997]) cube([0.4, 0.4, 0.1], center=true);
    translate([125.82175000000001, 75.12610000000001, 90.9763]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.876, 75.3895, 90.9737]) cube([0.4, 0.4, 0.1], center=true);
    translate([126.32600000000001, 77.77449999999999, 90.9503]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.37175, 78.041, 90.94775]) cube([0.4, 0.4, 0.1], center=true);
    translate([126.74525000000001, 80.453, 90.92525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.78235000000001, 80.7223, 90.9227]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.07665, 83.1577, 90.8993]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([127.10495, 83.42945, 90.8967]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.32005, 85.88555000000001, 90.8733]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([127.3395, 86.15950000000001, 90.8707]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.4745, 88.6345, 90.8473]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([127.485, 88.91035000000001, 90.8447]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.539, 91.40065000000001, 90.8213]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([127.54045, 91.67810000000001, 90.81875]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.51255, 94.18190000000001, 90.79625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([127.5049, 94.46065, 90.7937]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.3951, 96.97435, 90.7703]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([127.3783, 97.25405, 90.7677]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.1857, 99.77495, 90.7443]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([127.1597, 100.0553, 90.7417]) cube([0.4, 0.4, 0.1], center=true);
    translate([126.88430000000001, 102.58070000000001, 90.7183]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.84905, 102.8614, 90.71570000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([126.48995000000001, 105.3886, 90.69230000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.44545000000001, 105.6694, 90.68975]) cube([0.4, 0.4, 0.1], center=true);
    translate([126.00355, 108.19660000000002, 90.66725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.94980000000001, 108.47720000000001, 90.6647]) cube([0.4, 0.4, 0.1], center=true);
    translate([125.42419999999998, 111.00080000000001, 90.6413]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.36115, 111.28090000000002, 90.63870000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.75185, 113.7991, 90.61530000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([124.67955, 114.07844999999999, 90.61270000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([123.98745000000001, 116.58855, 90.58930000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.9059, 116.86685, 90.58670000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([123.1301, 119.36615, 90.5633]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.03935, 119.64315, 90.56075]) cube([0.4, 0.4, 0.1], center=true);
    translate([122.18165, 122.12985, 90.53825000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.08180000000002, 122.40525000000001, 90.53570000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.1422, 124.87575000000001, 90.51230000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.03330000000001, 125.14930000000001, 90.50970000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.01270000000001, 127.60270000000001, 90.4863]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.8948, 127.8742, 90.4837]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.7932, 130.30780000000001, 90.4603]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118.66645, 130.57690000000002, 90.4577]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.48655000000002, 132.9871, 90.43430000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.35110000000002, 133.25355000000002, 90.43175000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.0929, 135.63945, 90.40925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([115.94885, 135.903, 90.4067]) cube([0.4, 0.4, 0.1], center=true);
    translate([114.61415000000001, 138.261, 90.3833]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.46165000000002, 138.5214, 90.3807]) cube([0.4, 0.4, 0.1], center=true);
    translate([113.05135000000001, 140.8506, 90.3573]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([112.8906, 141.10764999999998, 90.3547]) cube([0.4, 0.4, 0.1], center=true);
    translate([111.40740000000001, 143.40535, 90.3313]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.23855, 143.6587, 90.3287]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.68245000000002, 145.92129999999997, 90.3053]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([109.50565, 146.17075, 90.30275]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.87935000000002, 148.39825000000002, 90.28025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.69485, 148.64355, 90.2777]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.00015000000002, 150.83145, 90.2543]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.80815000000001, 151.07235, 90.2517]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.04685, 153.22065, 90.2283]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.8476, 153.457, 90.2257]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.0224, 155.56300000000002, 90.2023]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.81615000000001, 155.79450000000003, 90.19969999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.92885, 157.8555, 90.1763]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.7159, 158.0819, 90.17375]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.77010000000001, 160.09609999999998, 90.15125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.55075000000001, 160.31719999999999, 90.1487]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.54825, 162.2828, 90.1253]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.32275, 162.4984, 90.1227]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.26625, 164.4136, 90.0993]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.0349, 164.6235, 90.0967]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.9271, 166.4865, 90.0733]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.69025, 166.6904, 90.0707]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.53475000000002, 168.4976, 90.0473]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.29270000000001, 168.6953, 90.04475000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.0913, 170.44670000000002, 90.02225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.84440000000001, 170.63805000000002, 90.0197]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.6016, 172.33095, 89.9963]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.3503, 172.5157, 89.9937]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.0697, 174.1483, 89.9703]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.81434999999999, 174.32635, 89.9677]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.49865, 175.89864999999998, 89.9443]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.2396, 176.0698, 89.9417]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.8924, 177.5782, 89.9183]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.63005, 177.7422, 89.91575]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.25495000000001, 179.18579999999997, 89.89325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.98965000000001, 179.34255, 89.8907]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.58935, 180.72045, 89.8673]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.3215, 180.8698, 89.8647]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.90050000000001, 182.18019999999999, 89.8413]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.6305, 182.32205, 89.8387]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.19149999999999, 183.56495, 89.8153]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.91975, 183.69915, 89.81269999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.46725000000001, 184.87185000000002, 89.7893]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.19415000000001, 184.99830000000003, 89.78675]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.730850000000004, 186.10170000000002, 89.76425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.45675, 186.22035000000002, 89.7617]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.98625, 187.25265000000002, 89.7383]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.711549999999995, 187.3634, 89.7357]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.23745, 188.3246, 89.7123]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.96255000000001, 188.42735, 89.70970000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.48845, 189.31565, 89.68630000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.21375, 189.41035000000002, 89.68370000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.74325, 190.22665, 89.6603]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.469100000000005, 190.31325, 89.65775000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.004900000000006, 191.05575000000002, 89.63525000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.73165, 191.13425, 89.63270000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.27735, 191.80475, 89.60930000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.00535, 191.87515000000002, 89.60670000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.563649999999996, 192.47185000000002, 89.58330000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.293299999999995, 192.53405, 89.58070000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.8687, 193.05695000000003, 89.5573]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.6004, 193.11100000000005, 89.5547]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.1956, 193.56100000000004, 89.5313]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.929649999999995, 193.60690000000002, 89.52875]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.54735, 193.9831, 89.50625000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.28415, 194.02085, 89.50370000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.928849999999997, 194.32415, 89.4803]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.668749999999996, 194.3538, 89.4777]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.34225, 194.5842, 89.4543]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.08555, 194.60575, 89.4517]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.79145, 194.76325000000003, 89.42830000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.53845, 194.77675000000002, 89.4257]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.27855, 194.86225000000002, 89.4023]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.02955, 194.86780000000002, 89.39975]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.807450000000003, 194.8822, 89.37725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.562800000000003, 194.8799, 89.3747]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.381200000000003, 194.8241, 89.3513]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.1411, 194.814, 89.3487]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.000900000000001, 194.68800000000002, 89.3253]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.765600000000001, 194.67015000000004, 89.3227]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.6704, 194.47485, 89.2993]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.440150000000001, 194.44940000000003, 89.2967]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.39085, 194.1866, 89.2733]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.165799999999999, 194.15365, 89.27075]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.164200000000001, 193.82335000000003, 89.24825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.944600000000001, 193.78295000000003, 89.2457]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.9934, 193.38605, 89.2223]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.7795, 193.33835000000002, 89.2197]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.8805, 192.87665, 89.1963]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.67245, 192.8218, 89.19369999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.8265500000000001, 192.2962, 89.1703]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.6245, 192.2343, 89.1677]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.16650000000000004, 191.6457, 89.1443]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.36245000000000005, 191.57690000000002, 89.14175]) cube([0.4, 0.4, 0.1], center=true);
    translate([-2.09855, 190.9271, 89.11925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-2.2883999999999998, 190.85154999999997, 89.1167]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.9696, 190.14145000000002, 89.0933]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.15325, 190.0593, 89.0907]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.77775, 189.2907, 89.0673]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.95515, 189.20209999999997, 89.0647]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.5238499999999995, 188.3759, 89.0413]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.69505, 188.281, 89.0387]) cube([0.4, 0.4, 0.1], center=true);
    translate([-9.20795, 187.399, 89.0153]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-9.3729, 187.298, 89.01275]) cube([0.4, 0.4, 0.1], center=true);
    translate([-10.8291, 186.362, 88.99025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-10.9878, 186.255, 88.9877]) cube([0.4, 0.4, 0.1], center=true);
    translate([-12.3882, 185.26500000000001, 88.9643]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-12.54065, 185.15215000000003, 88.9617]) cube([0.4, 0.4, 0.1], center=true);
    translate([-13.884350000000001, 184.11085000000003, 88.9383]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-14.0305, 183.99235000000002, 88.9357]) cube([0.4, 0.4, 0.1], center=true);
    translate([-15.317499999999999, 182.90065, 88.9123]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-15.45735, 182.77655000000001, 88.9097]) cube([0.4, 0.4, 0.1], center=true);
    translate([-16.68765, 181.63445000000002, 88.8863]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-16.82125, 181.50495, 88.88375]) cube([0.4, 0.4, 0.1], center=true);
    translate([-17.99575, 180.31605, 88.86125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-18.1231, 180.1813, 88.8587]) cube([0.4, 0.4, 0.1], center=true);
    translate([-19.240900000000003, 178.9447, 88.8353]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-19.362000000000002, 178.80485000000002, 88.8327]) cube([0.4, 0.4, 0.1], center=true);
    translate([-20.424, 177.52415000000002, 88.80930000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-20.538899999999998, 177.37945000000002, 88.8067]) cube([0.4, 0.4, 0.1], center=true);
    translate([-21.545099999999998, 176.05555, 88.7833]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-21.65375, 175.9061, 88.78070000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-22.60325, 174.53990000000002, 88.75730000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-22.7057, 174.38585, 88.75475]) cube([0.4, 0.4, 0.1], center=true);
    translate([-23.6003, 172.97915, 88.73225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-23.696550000000002, 172.82075, 88.7297]) cube([0.4, 0.4, 0.1], center=true);
    translate([-24.53445, 171.37625, 88.7063]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-24.6245, 171.21370000000002, 88.70370000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-25.407500000000002, 169.7323, 88.68030000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-25.491400000000002, 169.5657, 88.67770000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([-26.218600000000002, 168.04829999999998, 88.6543]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-26.296350000000004, 167.87785, 88.6517]) cube([0.4, 0.4, 0.1], center=true);
    translate([-26.968650000000004, 166.32715000000002, 88.6283]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-27.040300000000002, 166.15305, 88.62575]) cube([0.4, 0.4, 0.1], center=true);
    translate([-27.657700000000002, 164.56995, 88.60325000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-27.723250000000004, 164.39235000000002, 88.60070000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.285750000000004, 162.77865, 88.57730000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.345250000000004, 162.59779999999998, 88.5747]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.85375, 160.9562, 88.5513]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.90725, 160.77225, 88.5487]) cube([0.4, 0.4, 0.1], center=true);
    translate([-29.36175, 159.10275000000001, 88.5253]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-29.4092, 158.91585, 88.5227]) cube([0.4, 0.4, 0.1], center=true);
    translate([-29.808799999999998, 157.22115000000002, 88.4993]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-29.8503, 157.03155000000004, 88.49675]) cube([0.4, 0.4, 0.1], center=true);
    translate([-30.1977, 155.31345000000002, 88.47425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-30.2333, 155.1213, 88.4717]) cube([0.4, 0.4, 0.1], center=true);
    translate([-30.5267, 153.3807, 88.4483]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-30.556400000000004, 153.1862, 88.4457]) cube([0.4, 0.4, 0.1], center=true);
    translate([-30.797600000000003, 151.4258, 88.4223]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-30.8215, 151.2292, 88.4197]) cube([0.4, 0.4, 0.1], center=true);
    translate([-31.0105, 149.4508, 88.3963]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-31.02865, 149.2523, 88.3937]) cube([0.4, 0.4, 0.1], center=true);
    translate([-31.16635, 147.45770000000002, 88.3703]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-31.1788, 147.25750000000002, 88.36775]) cube([0.4, 0.4, 0.1], center=true);
    translate([-31.2652, 145.44850000000002, 88.34525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-31.27195, 145.24685000000002, 88.3427]) cube([0.4, 0.4, 0.1], center=true);
    translate([-31.30705, 143.42615, 88.3193]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-31.3082, 143.22325, 88.3167]) cube([0.4, 0.4, 0.1], center=true);
    translate([-31.293799999999997, 141.39175, 88.2933]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-31.2894, 141.1878, 88.2907]) cube([0.4, 0.4, 0.1], center=true);
    translate([-31.224600000000002, 139.34820000000002, 88.2673]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-31.2147, 139.14345, 88.2647]) cube([0.4, 0.4, 0.1], center=true);
    translate([-31.1013, 137.29755, 88.2413]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-31.086, 137.09215, 88.23875]) cube([0.4, 0.4, 0.1], center=true);
    translate([-30.924, 135.24085, 88.21625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-30.90335, 135.03505, 88.2137]) cube([0.4, 0.4, 0.1], center=true);
    translate([-30.693649999999998, 133.18195, 88.1903]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-30.667699999999996, 132.976, 88.18769999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([-30.4103, 131.122, 88.1643]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-30.379150000000003, 130.9161, 88.1617]) cube([0.4, 0.4, 0.1], center=true);
    translate([-30.075850000000003, 129.06390000000002, 88.1383]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-30.039550000000002, 128.8583, 88.1357]) cube([0.4, 0.4, 0.1], center=true);
    translate([-29.689450000000004, 127.00970000000001, 88.1123]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-29.648050000000005, 126.80455, 88.10975]) cube([0.4, 0.4, 0.1], center=true);
    translate([-29.252950000000006, 124.96045000000001, 88.08725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-29.206600000000005, 124.756, 88.0847]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.767400000000002, 122.91999999999999, 88.0613]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.71615, 122.7165, 88.0587]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.23285, 120.8895, 88.0353]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.1767, 120.68715, 88.0327]) cube([0.4, 0.4, 0.1], center=true);
    translate([-27.6493, 118.87185, 88.0093]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-27.5884, 118.67095, 88.0067]) cube([0.4, 0.4, 0.1], center=true);
    translate([-27.0196, 116.87005, 87.9833]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-26.954, 116.67075, 87.98075]) cube([0.4, 0.4, 0.1], center=true);
    translate([-26.342, 114.88425000000001, 87.95824999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-26.271749999999997, 114.6868, 87.9557]) cube([0.4, 0.4, 0.1], center=true);
    translate([-25.61925, 112.9192, 87.9323]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-25.5445, 112.7239, 87.9297]) cube([0.4, 0.4, 0.1], center=true);
    translate([-24.851499999999998, 110.9761, 87.9063]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-24.772299999999998, 110.7831, 87.9037]) cube([0.4, 0.4, 0.1], center=true);
    translate([-24.0397, 109.0569, 87.8803]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-23.95615, 108.86645, 87.8777]) cube([0.4, 0.4, 0.1], center=true);
    translate([-23.18485, 107.16455, 87.8543]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-23.09705, 106.97695, 87.85175]) cube([0.4, 0.4, 0.1], center=true);
    translate([-22.28795, 105.30205000000001, 87.82925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-22.19595, 105.1175, 87.8267]) cube([0.4, 0.4, 0.1], center=true);
    translate([-21.349050000000002, 103.4705, 87.80330000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-21.252950000000002, 103.2893, 87.8007]) cube([0.4, 0.4, 0.1], center=true);
    translate([-20.370050000000003, 101.67469999999999, 87.7773]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-20.26995, 101.49709999999999, 87.77470000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-19.35105, 99.9149, 87.75130000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-19.24705, 99.7411, 87.74870000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-18.293950000000002, 98.19489999999999, 87.7253]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-18.186100000000003, 98.02525, 87.72275]) cube([0.4, 0.4, 0.1], center=true);
    translate([-17.1979, 96.51775, 87.70025000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-17.0863, 96.35249999999999, 87.69770000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-16.0657, 94.8855, 87.67430000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-15.950500000000002, 94.72494999999999, 87.67170000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([-14.8975, 93.30205, 87.6483]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-14.77875, 93.14655, 87.6457]) cube([0.4, 0.4, 0.1], center=true);
    translate([-13.69425, 91.77045000000001, 87.6223]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-13.57205, 91.62025000000001, 87.6197]) cube([0.4, 0.4, 0.1], center=true);
    translate([-12.456949999999999, 90.29275, 87.5963]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-12.33145, 90.14819999999999, 87.59375]) cube([0.4, 0.4, 0.1], center=true);
    translate([-11.187550000000002, 88.8738, 87.57125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-11.058850000000001, 88.7352, 87.5687]) cube([0.4, 0.4, 0.1], center=true);
    translate([-9.88615, 87.51480000000001, 87.5453]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-9.7543, 87.38245, 87.5427]) cube([0.4, 0.4, 0.1], center=true);
    translate([-8.5537, 86.22055, 87.5193]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-8.41885, 86.09475, 87.5167]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.19215, 84.99225, 87.4933]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.0544, 84.8733, 87.4907]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.8016000000000005, 83.8347, 87.4673]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.6610000000000005, 83.72295, 87.46475]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.383, 82.75005, 87.44225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.2397, 82.64575, 87.4397]) cube([0.4, 0.4, 0.1], center=true);
    translate([-2.9383000000000004, 81.74125000000001, 87.4163]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-2.7924, 81.64475, 87.4137]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.4676, 80.81225, 87.3903]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.31925, 80.72380000000001, 87.3877]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.02625000000000001, 79.9642, 87.3643]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.1769, 79.88405, 87.3617]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.5431000000000001, 79.20095, 87.3383]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.6960000000000002, 79.12945, 87.33575]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.082, 78.52555000000001, 87.31325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.2369499999999998, 78.4629, 87.3107]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.6400500000000005, 77.9391, 87.2873]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.79695, 77.88555, 87.2847]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.21805, 77.44545000000001, 87.2613]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.3768, 77.40125000000002, 87.2587]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.8132, 77.04575, 87.2353]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.97365, 77.0111, 87.2327]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.42535, 76.74289999999999, 87.2093]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.5874, 76.71805, 87.20675]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.0526, 76.53895, 87.18425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.21605, 76.52404999999999, 87.1817]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.69295, 76.43495, 87.1583]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.857700000000001, 76.43020000000001, 87.1557]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.346300000000001, 76.43379999999999, 87.1323]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.5122, 76.43939999999999, 87.1297]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.009800000000002, 76.53659999999999, 87.1063]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.176650000000002, 76.55265, 87.1037]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.68235, 76.74435, 87.0803]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.850049999999996, 76.771, 87.07775]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.362949999999998, 77.05900000000001, 87.05525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.531299999999998, 77.0964, 87.0527]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.0487, 77.4816, 87.0293]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.2175, 77.5299, 87.0267]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.738500000000002, 78.0141, 87.0033]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.90755, 78.0734, 87.0007]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.42945, 78.6566, 86.9773]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.5986, 78.72695, 86.9747]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.1214, 79.41005, 86.9513]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.2905, 79.49149999999999, 86.94875]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.811500000000002, 80.27449999999999, 86.92625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.98035, 80.3671, 86.9237]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.49865, 81.2509, 86.9003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.6671, 81.35475, 86.8977]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.1809, 82.34025, 86.8743]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.348750000000003, 82.45535000000001, 86.8717]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.856249999999996, 83.54165000000002, 86.8483]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.0233, 83.66795000000002, 86.84570000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.5227, 84.85505000000002, 86.82230000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.68875, 84.99255000000001, 86.81975000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.178250000000006, 86.28045, 86.79725000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.3431, 86.4291, 86.7947]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.820899999999995, 87.8169, 86.7713]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.984399999999994, 87.9766, 86.76870000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.4496, 89.46340000000001, 86.74530000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.61155, 89.63400000000001, 86.74270000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.06145000000001, 91.21799999999999, 86.7193]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.221650000000004, 91.3994, 86.7167]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.65535, 93.08060000000002, 86.6933]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.81355, 93.27265000000001, 86.69075]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.22745, 95.04835, 86.66825000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.3834, 95.2508, 86.66570000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.7766, 97.11919999999999, 86.6423]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.93015, 97.33185, 86.6397]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.300850000000004, 99.29115000000002, 86.6163]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.451750000000004, 99.5138, 86.6137]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.79725, 101.56220000000002, 86.5903]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.9453, 101.7946, 86.5877]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.264700000000005, 103.92940000000002, 86.5643]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.40965, 104.1713, 86.56175]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.69935000000001, 106.39070000000001, 86.53925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.84100000000001, 106.64175, 86.5367]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.101000000000006, 108.94125000000001, 86.5133]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.23915, 109.20115000000001, 86.5107]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.465849999999996, 111.57985000000001, 86.4873]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.600249999999996, 111.84825000000001, 86.4847]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.79275, 114.30075000000001, 86.4613]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.923249999999996, 114.57725, 86.4587]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.079750000000004, 117.10175000000001, 86.4353]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.2061, 117.38595000000001, 86.43275]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.3239, 119.97704999999999, 86.41025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.44585000000001, 120.26849999999999, 86.4077]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.52315, 122.9235, 86.3843]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.64045, 123.22175000000001, 86.3817]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.674549999999996, 125.93525, 86.3583]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.78705, 126.2398, 86.3557]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.777950000000004, 129.0082, 86.3323]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.885450000000006, 129.3186, 86.3297]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.829550000000005, 132.1374, 86.30630000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.931850000000004, 132.4532, 86.30375000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.82915, 135.3188, 86.28125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.9261, 135.63955, 86.2787]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.7739, 138.54745000000003, 86.2553]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.86525, 138.8726, 86.2527]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.66175, 141.8174, 86.2293]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.74735000000001, 142.14645, 86.2267]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.49164999999999, 145.12455, 86.2033]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.5714, 145.45704999999998, 86.2007]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.2626, 148.46395, 86.1773]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.3364, 148.7993, 86.17475]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.9736, 151.8287, 86.15225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.0413, 152.1663, 86.1497]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.62270000000001, 155.21370000000002, 86.1263]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.68415, 155.55305, 86.1237]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.20885, 158.61395, 86.1003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.26395, 158.9544, 86.0977]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.73105000000001, 162.0216, 86.0743]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.7797, 162.36255, 86.07169999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.1883, 165.43245000000002, 86.0483]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.2304, 165.77335000000002, 86.04575]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.5796, 168.83965, 86.02325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.61500000000001, 169.1798, 86.0207]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.903, 172.2362, 85.9973]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.93165, 172.57495, 85.9947]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.15935, 175.61605, 85.9713]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.18115, 175.95275, 85.9687]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.34585000000001, 178.97225, 85.9453]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.36065, 179.30625, 85.94270000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.46235, 182.29875, 85.91930000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.4701, 182.62945000000002, 85.91675000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.5079, 185.58954999999997, 85.89425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.50850000000001, 185.91629999999998, 85.8917]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.48150000000001, 188.83769999999998, 85.8683]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.4749, 189.1598, 85.8657]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.3831, 192.0362, 85.8423]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.36925000000001, 192.35305000000002, 85.83970000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.21175000000001, 195.17995000000002, 85.81630000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.1906, 195.49095, 85.81370000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.9674, 198.26205, 85.7903]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.93885, 198.5665, 85.78775]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.64815, 201.2755, 85.76525000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.61215, 201.5728, 85.76270000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.25485, 204.2152, 85.73930000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.21135, 204.50475, 85.73670000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.78565, 207.07425, 85.7133]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.7346, 207.35535000000002, 85.7107]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.2414, 209.84565, 85.68730000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.1828, 210.1177, 85.6847]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.6212, 212.5243, 85.6613]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.55495, 212.78675, 85.65875]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.92405, 215.10425, 85.63625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.85015, 215.3564, 85.6337]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.15084999999999, 217.57760000000002, 85.6103]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.0693, 217.81885, 85.6077]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.30069999999999, 219.94015000000002, 85.5843]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.2114, 220.16995, 85.5817]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.3726, 222.18505, 85.5583]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.27555, 222.40285, 85.5557]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.36744999999999, 224.30815, 85.5323]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.2627, 224.51335, 85.52975]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.28530000000001, 226.30165000000002, 85.50725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.17280000000001, 226.49355000000003, 85.5047]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.12520000000001, 228.15945000000002, 85.4813]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.005, 228.33745000000002, 85.4787]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.889, 229.87555000000003, 85.4553]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.7612, 230.03910000000002, 85.4527]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.576800000000006, 231.44490000000002, 85.4293]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.44145, 231.59335, 85.4267]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.18955, 232.85965, 85.4033]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.04675, 232.99235, 85.40075]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.72825, 234.11464999999998, 85.37825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.5781, 234.23104999999998, 85.3757]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.1939, 235.20395000000002, 85.3523]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.03655, 235.30345, 85.3497]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.58845, 236.12154999999998, 85.3263]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.42405, 236.20355, 85.3237]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.91295, 236.86145, 85.30030000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.74165000000001, 236.9253, 85.2977]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.16935, 237.4167, 85.2743]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.99135, 237.4618, 85.27175]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.359649999999995, 237.78220000000002, 85.24925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.175149999999995, 237.80795, 85.2467]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.48585, 237.95105, 85.2233]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.2951, 237.95680000000002, 85.2207]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.5509, 237.9172, 85.1973]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.3541, 237.90235, 85.1947]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.55590000000001, 237.67465, 85.1713]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.353300000000004, 237.6386, 85.1687]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.5047, 237.2174, 85.1453]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.29665, 237.15949999999998, 85.14275]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.40035, 236.5385, 85.12025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.18715, 236.4581, 85.1177]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.24585, 235.63190000000003, 85.0943]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.02795, 235.52840000000003, 85.0917]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.04705, 234.4916, 85.0683]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.82485, 234.36435, 85.06569999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.80615, 233.11065, 85.0423]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.58005, 232.959, 85.0397]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.528950000000002, 231.48300000000003, 85.0163]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.29945, 231.30640000000002, 85.01375]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.219549999999998, 229.6036, 84.99125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.987099999999998, 229.40145, 84.9887]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.8829, 227.46555, 84.9653]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.64805, 227.23725000000002, 84.9627]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.52495, 225.06375, 84.9393]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.2882, 224.80870000000002, 84.93670000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.1498, 222.39130000000003, 84.91330000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.9118, 222.1089, 84.91070000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.766199999999998, 219.44310000000002, 84.88730000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.527549999999998, 219.13275, 84.88475000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.37745, 216.21225000000004, 84.86225000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.138649999999998, 215.87335000000002, 84.8597]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.99035, 212.69365, 84.8363]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.75215, 212.3256, 84.83370000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.61285, 208.8804, 84.81030000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.37595, 208.48255, 84.80770000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.25105, 204.76645000000002, 84.7843]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.01605, 204.33825000000002, 84.7817]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.91095, 200.34675000000001, 84.7583]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.6785499999999995, 199.88765, 84.75575]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.60045, 195.61534999999998, 84.73325000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.3713499999999996, 195.1247, 84.73070000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.32565, 190.56530000000004, 84.7073]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1005, 190.04260000000002, 84.7047]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.9065, 185.1934, 84.68130000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.1271, 184.63815, 84.6787]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.0909000000000004, 179.49285, 84.6553]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.3063000000000002, 178.9044, 84.6527]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.2197000000000005, 173.4576, 84.6293]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.4292, 172.83545, 84.62675]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.2867999999999995, 167.08355, 84.60425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.4897, 166.4272, 84.6017]) cube([0.4, 0.4, 0.1], center=true);
    translate([-9.2843, 160.36479999999997, 84.5783]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-9.47995, 159.67374999999998, 84.5757]) cube([0.4, 0.4, 0.1], center=true);
    translate([-11.20705, 153.29725000000002, 84.5523]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-11.3948, 152.57105, 84.5497]) cube([0.4, 0.4, 0.1], center=true);
    translate([-13.0472, 145.87595, 84.5263]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-13.22635, 145.11415, 84.5237]) cube([0.4, 0.4, 0.1], center=true);
    translate([-14.798649999999999, 138.09685000000002, 84.5003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-14.968499999999999, 137.29895, 84.49775]) cube([0.4, 0.4, 0.1], center=true);
    translate([-16.453500000000002, 129.95405, 84.47525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-16.613350000000004, 129.1196, 84.4727]) cube([0.4, 0.4, 0.1], center=true);
    translate([-18.00565, 121.4444, 84.4493]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-18.15485, 120.57305000000001, 84.44669999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([-19.448150000000002, 112.56395, 84.4233]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-19.586000000000002, 111.65525, 84.4207]) cube([0.4, 0.4, 0.1], center=true);
    translate([-20.774, 103.30775, 84.3973]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-20.8998, 102.3613, 84.3947]) cube([0.4, 0.4, 0.1], center=true);
    translate([-21.976200000000002, 93.67269999999999, 84.3713]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-22.089300000000005, 92.68815, 84.36875]) cube([0.4, 0.4, 0.1], center=true);
    translate([-23.048700000000004, 83.65485000000001, 84.34625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-23.148400000000002, 82.63190000000002, 84.3437]) cube([0.4, 0.4, 0.1], center=true);
    translate([-23.983600000000003, 73.2521, 84.3203]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-24.069250000000004, 72.1904, 84.3177]) cube([0.4, 0.4, 0.1], center=true);
    translate([-24.775750000000002, 62.4596, 84.2943]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-24.846700000000002, 61.358850000000004, 84.2917]) cube([0.4, 0.4, 0.1], center=true);
    translate([-25.417300000000004, 51.27615, 84.2683]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-25.472900000000003, 50.13615000000001, 84.2657]) cube([0.4, 0.4, 0.1], center=true);
    translate([-25.9031, 39.69885000000001, 84.2423]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-25.94265, 38.519400000000005, 84.23975]) cube([0.4, 0.4, 0.1], center=true);
    translate([-26.22435, 27.7266, 84.21724999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-26.2472, 26.50765, 84.2147]) cube([0.4, 0.4, 0.1], center=true);
    translate([-26.3768, 15.35935, 84.1913]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-26.3823, 14.1009, 84.1887]) cube([0.4, 0.4, 0.1], center=true);
    translate([-26.351700000000005, 2.5971, 84.1653]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-26.339100000000002, 1.29925, 84.1627]) cube([0.4, 0.4, 0.1], center=true);
    translate([-26.142900000000004, -10.55825, 84.1393]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-26.111500000000003, -11.8953, 84.1367]) cube([0.4, 0.4, 0.1], center=true);
    translate([-25.742500000000003, -24.1047, 84.1133]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-25.691550000000003, -25.48075, 84.11075]) cube([0.4, 0.4, 0.1], center=true);
    translate([-25.14345, -38.04025, 84.08825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-25.07225, -39.45505000000001, 84.0857]) cube([0.4, 0.4, 0.1], center=true);
    translate([-24.338749999999997, -52.36195000000001, 84.06230000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-24.24655, -53.815200000000004, 84.0597]) cube([0.4, 0.4, 0.1], center=true);
    translate([-23.32045, -67.0668, 84.0363]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-23.2065, -68.55825, 84.0337]) cube([0.4, 0.4, 0.1], center=true);
    translate([-22.0815, -82.15275, 84.0103]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-21.945149999999998, -83.6822, 84.00770000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-20.615850000000002, -97.6178, 83.98430000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-20.456350000000004, -99.18505, 83.98175]) cube([0.4, 0.4, 0.1], center=true);
    translate([-18.91465, -113.45995, 83.95925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-18.7313, -115.06470000000002, 83.9567]) cube([0.4, 0.4, 0.1], center=true);
    translate([-16.9727, -129.6753, 83.9333]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-16.7649, -131.3173, 83.93070000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([-14.783100000000001, -146.2627, 83.90730000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-14.55015, -147.94175, 83.90470000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([-12.338849999999999, -163.21925000000002, 83.88130000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-12.079949999999998, -164.935, 83.87870000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-9.631049999999998, -180.541, 83.8553]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-9.3455, -182.2932, 83.85275]) cube([0.4, 0.4, 0.1], center=true);
    translate([-6.6545, -198.2268, 83.83025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-6.34165, -200.0152, 83.82770000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.4013500000000003, -216.2728, 83.80430000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.0605, -218.09709999999998, 83.80170000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.13449999999999998, -234.67690000000002, 83.7783]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.504, -236.53685000000002, 83.7757]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.96, -253.43615, 83.7523]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.35885, -255.3314, 83.7497]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.08215, -272.54659999999996, 83.7263]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.511, -274.47684999999996, 83.72375]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.507, -292.00615, 83.70125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.9665, -293.9712, 83.6987]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.2415, -311.8128, 83.67530000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.7323, -313.81235, 83.6727]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.291700000000002, -331.96265, 83.6493]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.814500000000002, -333.9964, 83.6467]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.6655, -352.4536, 83.6233]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.220950000000002, -354.5213, 83.6207]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.368050000000004, -373.2827, 83.5973]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.95675, -375.3841, 83.59475]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.40625, -394.4479, 83.57225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.0289, -396.5828, 83.5697]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.787099999999995, -415.94720000000007, 83.5463]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.4443, -418.11530000000005, 83.5437]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.5157, -437.77670000000006, 83.5203]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.20805, -439.9777000000001, 83.5177]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.59895, -459.93430000000006, 83.4943]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.3271, -462.16800000000006, 83.4917]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.0429, -482.41800000000006, 83.4683]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.8074, -484.68415000000005, 83.46575]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.8526, -505.22485, 83.44324999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.65405, -507.52315, 83.44069999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.03495, -528.35185, 83.4173]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.87395, -530.68205, 83.4147]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.59505, -551.79695, 83.3913]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.4722, -554.15885, 83.3887]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.5398, -575.55815, 83.3653]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.45575000000001, -577.9514999999999, 83.3627]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.87525000000001, -599.6324999999999, 83.3393]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.83065, -602.05705, 83.33675]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.60835000000002, -624.0179500000002, 83.31425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.60375000000002, -626.4734500000001, 83.3117]) cube([0.4, 0.4, 0.1], center=true);
    translate([129.74325000000002, -648.71155, 83.2883]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([130.77925000000002, -651.19775, 83.2857]) cube([0.4, 0.4, 0.1], center=true);
    translate([140.28775000000002, -673.7112500000001, 83.2623]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([141.3649, -676.2279500000001, 83.2597]) cube([0.4, 0.4, 0.1], center=true);
    translate([151.24510000000004, -699.01505, 83.2363]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([152.36395000000002, -701.5619999999999, 83.2337]) cube([0.4, 0.4, 0.1], center=true);
    translate([162.62305, -724.6199999999999, 83.2103]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([163.7843, -727.1968999999999, 83.20775]) cube([0.4, 0.4, 0.1], center=true);
    translate([174.4277, -750.5231, 83.18525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([175.63185, -753.1297000000001, 83.1827]) cube([0.4, 0.4, 0.1], center=true);
    translate([186.66315000000003, -776.7223, 83.1593]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([187.91070000000002, -779.35845, 83.1567]) cube([0.4, 0.4, 0.1], center=true);
    translate([199.33530000000002, -803.21655, 83.1333]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([200.62685000000002, -805.8820000000001, 83.1307]) cube([0.4, 0.4, 0.1], center=true);
    translate([212.45015, -830.0020000000001, 83.1073]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([213.78625, -832.6965, 83.1047]) cube([0.4, 0.4, 0.1], center=true);
    translate([226.01275, -857.0775, 83.0813]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([227.39395000000002, -859.80085, 83.07875]) cube([0.4, 0.4, 0.1], center=true);
    translate([240.02905, -884.44015, 83.05625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([241.4559, -887.1921, 83.0537]) cube([0.4, 0.4, 0.1], center=true);
    translate([254.50410000000002, -912.0879, 83.0303]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([255.97720000000004, -914.8682500000001, 83.0277]) cube([0.4, 0.4, 0.1], center=true);
    translate([269.4448, -940.0187500000001, 83.0043]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([270.9647, -942.82735, 83.00170000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([284.8553, -968.2316500000001, 82.97830000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([286.4225, -971.06825, 82.97570000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([300.7415, -996.72275, 82.95230000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([302.35659999999996, -999.5871000000001, 82.94975000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([317.1094, -1025.4909, 82.92725000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([318.7729, -1028.383, 82.92470000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([333.9631, -1054.537, 82.90130000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([335.67555, -1057.4565, 82.89870000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([351.30944999999997, -1083.8535, 82.87530000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([353.0714, -1086.8005, 82.87270000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([369.1526, -1113.4495000000002, 82.8493]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([370.9646, -1116.4235, 82.8467]) cube([0.4, 0.4, 0.1], center=true);
    translate([387.49940000000004, -1143.3065, 82.8233]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([389.362, -1146.3075, 82.82075]) cube([0.4, 0.4, 0.1], center=true);
    translate([406.354, -1173.4425, 82.79825000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([408.26765, -1176.4705000000001, 82.79570000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([425.72135, -1203.8394999999998, 82.7723]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([427.68665, -1206.8939999999998, 82.7697]) cube([0.4, 0.4, 0.1], center=true);
    translate([445.60835, -1234.5059999999999, 82.7463]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([447.62585, -1237.587, 82.7437]) cube([0.4, 0.4, 0.1], center=true);
    translate([466.01915, -1265.4330000000002, 82.7203]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([468.08935, -1268.5400000000002, 82.7177]) cube([0.4, 0.4, 0.1], center=true);
    translate([486.95965, -1296.6200000000001, 82.6943]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([489.0831, -1299.7530000000002, 82.69175]) cube([0.4, 0.4, 0.1], center=true);
    translate([508.4349, -1328.0670000000002, 82.66925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([510.61205000000007, -1331.226, 82.6667]) cube([0.4, 0.4, 0.1], center=true);
    translate([530.4489500000001, -1359.774, 82.6433]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([532.6803, -1362.9585, 82.6407]) cube([0.4, 0.4, 0.1], center=true);
    translate([553.0076999999999, -1391.7315, 82.6173]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([555.2937499999999, -1394.9415000000001, 82.6147]) cube([0.4, 0.4, 0.1], center=true);
    translate([576.1152500000001, -1423.9485, 82.5913]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([578.45645, -1427.184, 82.5887]) cube([0.4, 0.4, 0.1], center=true);
    translate([599.77655, -1456.4160000000002, 82.5653]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([602.1734, -1459.6765, 82.56275]) cube([0.4, 0.4, 0.1], center=true);
    translate([623.9966, -1489.1335, 82.54025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([626.4495999999999, -1492.4189999999999, 82.5377]) cube([0.4, 0.4, 0.1], center=true);
    translate([648.7804, -1522.101, 82.5143]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([651.2900000000001, -1525.411, 82.5117]) cube([0.4, 0.4, 0.1], center=true);
    translate([674.1320000000001, -1555.3090000000002, 82.4883]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([676.6987, -1558.6440000000002, 82.4857]) cube([0.4, 0.4, 0.1], center=true);
    translate([700.0573, -1588.776, 82.4623]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([702.6816, -1592.136, 82.4597]) cube([0.4, 0.4, 0.1], center=true);
    translate([726.5604, -1622.4840000000002, 82.4363]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([729.24275, -1625.8685000000003, 82.43375]) cube([0.4, 0.4, 0.1], center=true);
    translate([753.64625, -1656.4415000000001, 82.41125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([756.3872, -1659.85, 82.4087]) cube([0.4, 0.4, 0.1], center=true);
    translate([781.3208000000001, -1690.63, 82.3853]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([784.12085, -1694.0625, 82.3827]) cube([0.4, 0.4, 0.1], center=true);
    translate([809.58815, -1725.0675, 82.3593]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([812.44775, -1728.5245, 82.3567]) cube([0.4, 0.4, 0.1], center=true);
    translate([838.45325, -1759.7455, 82.3333]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([841.3729500000001, -1763.2265000000002, 82.3307]) cube([0.4, 0.4, 0.1], center=true);
    translate([867.92205, -1794.6635, 82.3073]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([870.9023000000001, -1798.1685, 82.30475]) cube([0.4, 0.4, 0.1], center=true);
    translate([897.9977000000001, -1829.8215, 82.28225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([901.0389500000001, -1833.35, 82.2797]) cube([0.4, 0.4, 0.1], center=true);
    translate([928.68605, -1865.21, 82.2563]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([931.7888, -1868.7625000000003, 82.2537]) cube([0.4, 0.4, 0.1], center=true);
    translate([959.9911999999999, -1900.8475000000003, 82.2303]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([963.1559, -1904.4235000000003, 82.2277]) cube([0.4, 0.4, 0.1], center=true);
    translate([991.9181, -1936.7065000000002, 82.2043]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([995.1452, -1940.306, 82.2017]) cube([0.4, 0.4, 0.1], center=true);
    translate([1024.4707999999998, -1972.8139999999999, 82.17830000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1027.761, -1976.437, 82.17575000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1057.6589999999999, -2009.143, 82.15325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1061.012, -2012.789, 82.1507]) cube([0.4, 0.4, 0.1], center=true);
    translate([1091.468, -2045.711, 82.1273]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1094.884, -2049.38, 82.1247]) cube([0.4, 0.4, 0.1], center=true);
    translate([1125.9160000000002, -2082.5, 82.1013]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1129.3965, -2086.192, 82.0987]) cube([0.4, 0.4, 0.1], center=true);
    translate([1161.0135, -2119.5280000000002, 82.0753]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1164.559, -2123.2430000000004, 82.07270000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1196.761, -2156.777, 82.04930000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1200.3719999999998, -2160.5139999999997, 82.04675]) cube([0.4, 0.4, 0.1], center=true);
    translate([1233.168, -2194.246, 82.02425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1236.845, -2198.0055, 82.0217]) cube([0.4, 0.4, 0.1], center=true);
    translate([1270.235, -2231.9445, 81.9983]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1273.9785, -2235.7259999999997, 81.99570000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1307.9715, -2269.8540000000003, 81.97230000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1311.782, -2273.6575000000003, 81.96970000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([1346.378, -2307.9925000000003, 81.94630000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1350.2555, -2311.818, 81.9437]) cube([0.4, 0.4, 0.1], center=true);
    translate([1385.4545, -2346.342, 81.9203]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1389.3995, -2350.1895000000004, 81.91775]) cube([0.4, 0.4, 0.1], center=true);
    translate([1425.2105000000001, -2384.9205, 81.89525000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1429.2235, -2388.79, 81.89270000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([1465.6465, -2423.71, 81.86930000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1469.7275, -2427.6005, 81.86670000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1506.7624999999998, -2462.7095, 81.8433]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1510.9115, -2466.6214999999997, 81.8407]) cube([0.4, 0.4, 0.1], center=true);
    translate([1548.5585, -2501.9284999999995, 81.8173]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1552.776, -2505.8619999999996, 81.8147]) cube([0.4, 0.4, 0.1], center=true);
    translate([1591.044, -2541.3579999999997, 81.7913]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1595.3310000000001, -2545.3125, 81.78875000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1634.2290000000003, -2580.9975000000004, 81.76625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1638.5850000000003, -2584.9730000000004, 81.7637]) cube([0.4, 0.4, 0.1], center=true);
    translate([1678.095, -2620.847, 81.7403]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1682.52, -2624.8435, 81.7377]) cube([0.4, 0.4, 0.1], center=true);
    translate([1722.66, -2660.9065, 81.7143]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1727.1550000000002, -2664.9235000000003, 81.7117]) cube([0.4, 0.4, 0.1], center=true);
    translate([1767.9250000000002, -2701.1665000000003, 81.6883]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1772.49, -2705.204, 81.6857]) cube([0.4, 0.4, 0.1], center=true);
    translate([1813.89, -2741.636, 81.6623]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1818.5255000000002, -2745.694, 81.65975]) cube([0.4, 0.4, 0.1], center=true);
    translate([1860.5645000000002, -2782.3060000000005, 81.63725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1865.2705, -2786.3845000000006, 81.6347]) cube([0.4, 0.4, 0.1], center=true);
    translate([1907.9395, -2823.1855, 81.6113]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1912.7165, -2827.2844999999998, 81.6087]) cube([0.4, 0.4, 0.1], center=true);
    translate([1956.0335, -2864.2655, 81.5853]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1960.882, -2868.3845, 81.5827]) cube([0.4, 0.4, 0.1], center=true);
    translate([2004.838, -2905.5455, 81.55930000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2009.7575, -2909.6845000000003, 81.5567]) cube([0.4, 0.4, 0.1], center=true);
    translate([2054.3525, -2947.0255, 81.5333]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2059.3435, -2951.1845, 81.53075]) cube([0.4, 0.4, 0.1], center=true);
    translate([2104.5865, -2988.7055, 81.50825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2109.6495, -2992.884, 81.5057]) cube([0.4, 0.4, 0.1], center=true);
    translate([2155.5405, -3030.576, 81.4823]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2160.6755000000003, -3034.7740000000003, 81.4797]) cube([0.4, 0.4, 0.1], center=true);
    translate([2207.2145, -3072.646, 81.4563]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2212.4215000000004, -3076.8635000000004, 81.4537]) cube([0.4, 0.4, 0.1], center=true);
    translate([2259.6085000000003, -3114.9065, 81.4303]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2264.888, -3119.143, 81.4277]) cube([0.4, 0.4, 0.1], center=true);
    translate([2312.732, -3157.357, 81.4043]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2318.0845, -3161.612, 81.40175]) cube([0.4, 0.4, 0.1], center=true);
    translate([2366.5855, -3199.988, 81.37925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2372.0110000000004, -3204.2615, 81.3767]) cube([0.4, 0.4, 0.1], center=true);
    translate([2421.1690000000003, -3242.8085, 81.3533]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2426.6675, -3247.101, 81.3507]) cube([0.4, 0.4, 0.1], center=true);
    translate([2476.4825, -3285.819, 81.3273]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2482.0545, -3290.1299999999997, 81.32469999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([2532.5355, -3329.01, 81.3013]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2538.1815, -3333.3385000000003, 81.2987]) cube([0.4, 0.4, 0.1], center=true);
    translate([2589.3285, -3372.3715, 81.2753]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2595.048, -3376.7180000000003, 81.27275]) cube([0.4, 0.4, 0.1], center=true);
    translate([2646.852, -3415.922, 81.25025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2652.646, -3420.2865, 81.2477]) cube([0.4, 0.4, 0.1], center=true);
    translate([2705.1340000000005, -3459.6435, 81.2243]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2711.003, -3464.025, 81.2217]) cube([0.4, 0.4, 0.1], center=true);
    translate([2764.157, -3503.5350000000003, 81.1983]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2770.1010000000006, -3507.934, 81.1957]) cube([0.4, 0.4, 0.1], center=true);
    translate([2823.9390000000003, -3547.606, 81.1723]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2829.9585, -3552.0220000000004, 81.1697]) cube([0.4, 0.4, 0.1], center=true);
    translate([2884.4715, -3591.8380000000006, 81.1463]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2890.5665, -3596.2705000000005, 81.14375]) cube([0.4, 0.4, 0.1], center=true);
    translate([2945.7635, -3636.2395, 81.12125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2951.9345000000003, -3640.6885, 81.1187]) cube([0.4, 0.4, 0.1], center=true);
    translate([3007.8155, -3680.8015000000005, 81.0953]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3014.063, -3685.2670000000003, 81.0927]) cube([0.4, 0.4, 0.1], center=true);
    translate([3070.637, -3725.533, 81.0693]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3076.9610000000002, -3730.0145, 81.06670000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3134.2190000000005, -3770.4155, 81.04330000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3140.6195000000002, -3774.9129999999996, 81.04070000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([3198.5705, -3815.4669999999996, 81.0173]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3205.0485, -3819.9804999999997, 81.01475]) cube([0.4, 0.4, 0.1], center=true);
    translate([3263.7015, -3860.6695, 80.99225000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3270.2565000000004, -3865.198, 80.98970000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3329.5935, -3906.0220000000004, 80.96630000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3336.226, -3910.5655, 80.96370000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([3396.2740000000003, -3951.5245, 80.94030000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3402.9845000000005, -3956.083, 80.9377]) cube([0.4, 0.4, 0.1], center=true);
    translate([3463.7255, -3997.177, 80.9143]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3470.514, -4001.75, 80.9117]) cube([0.4, 0.4, 0.1], center=true);
    translate([3531.9660000000003, -4042.9700000000003, 80.8883]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3538.8335, -4047.5570000000002, 80.88575]) cube([0.4, 0.4, 0.1], center=true);
    translate([3600.9965, -4088.903, 80.86325000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3607.943, -4093.504, 80.86070000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3670.817, -4134.976, 80.8373]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3677.8424999999997, -4139.590999999999, 80.8347]) cube([0.4, 0.4, 0.1], center=true);
    translate([3741.4275, -4181.189, 80.8113]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3748.5325, -4185.8175, 80.8087]) cube([0.4, 0.4, 0.1], center=true);
    translate([3812.8374999999996, -4227.5325, 80.7853]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3820.0225, -4232.174, 80.7827]) cube([0.4, 0.4, 0.1], center=true);
    translate([3885.0474999999997, -4274.006, 80.7593]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3892.3125, -4278.6605, 80.75675]) cube([0.4, 0.4, 0.1], center=true);
    translate([3958.0575000000003, -4320.6095, 80.73425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3965.4030000000002, -4325.277, 80.7317]) cube([0.4, 0.4, 0.1], center=true);
    translate([4031.8770000000004, -4367.343000000001, 80.7083]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4039.3035000000004, -4372.023, 80.7057]) cube([0.4, 0.4, 0.1], center=true);
    translate([4106.5064999999995, -4414.197, 80.6823]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4114.014, -4418.889, 80.6797]) cube([0.4, 0.4, 0.1], center=true);
    translate([4181.946, -4461.171, 80.6563]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4189.535, -4465.874500000001, 80.6537]) cube([0.4, 0.4, 0.1], center=true);
    translate([4258.205000000001, -4508.2555, 80.6303]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4265.876, -4512.9705, 80.62775]) cube([0.4, 0.4, 0.1], center=true);
    translate([4335.284000000001, -4555.4595, 80.60525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4343.037, -4560.186, 80.6027]) cube([0.4, 0.4, 0.1], center=true);
    translate([4413.183, -4602.774, 80.5793]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4421.0185, -4607.511, 80.5767]) cube([0.4, 0.4, 0.1], center=true);
    translate([4491.9115, -4650.189, 80.55330000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4499.829500000001, -4654.9315, 80.5507]) cube([0.4, 0.4, 0.1], center=true);
    translate([4571.4605, -4697.6185, 80.5273]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4579.461499999999, -4702.367, 80.5247]) cube([0.4, 0.4, 0.1], center=true);
    translate([4651.8485, -4745.153, 80.5013]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4659.933, -4749.9065, 80.49875]) cube([0.4, 0.4, 0.1], center=true);
    translate([4733.067, -4792.6835, 80.47625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4741.235500000001, -4797.4365, 80.4737]) cube([0.4, 0.4, 0.1], center=true);
    translate([4815.1345, -4840.2135, 80.4503]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4823.387, -4844.9665, 80.4477]) cube([0.4, 0.4, 0.1], center=true);
    translate([4898.033, -4887.7435000000005, 80.4243]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4906.369500000001, -4892.4955, 80.4217]) cube([0.4, 0.4, 0.1], center=true);
    translate([4981.780500000001, -4935.2545, 80.3983]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4990.202, -4940.0055, 80.3957]) cube([0.4, 0.4, 0.1], center=true);
    translate([5066.378, -4982.7645, 80.3723]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5074.884, -4987.5145, 80.36975]) cube([0.4, 0.4, 0.1], center=true);
    translate([5151.816000000001, -5030.2555, 80.34725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5160.407000000001, -5035.004, 80.3447]) cube([0.4, 0.4, 0.1], center=true);
    translate([5238.113000000001, -5077.736, 80.3213]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5246.789500000001, -5082.483, 80.31869999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([5325.2605, -5125.197, 80.2953]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5334.022, -5129.942, 80.2927]) cube([0.4, 0.4, 0.1], center=true);
    translate([5413.258, -5172.638, 80.2693]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5422.1050000000005, -5177.3805, 80.2667]) cube([0.4, 0.4, 0.1], center=true);
    translate([5502.115000000001, -5220.0495, 80.2433]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5511.048000000001, -5224.7895, 80.24075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5591.832, -5267.440500000001, 80.21825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5600.8515, -5272.178000000001, 80.2157]) cube([0.4, 0.4, 0.1], center=true);
    translate([5682.4185, -5314.802000000001, 80.1923]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5691.5245, -5319.536, 80.1897]) cube([0.4, 0.4, 0.1], center=true);
    translate([5773.8655, -5362.124, 80.1663]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5783.057999999999, -5366.8545, 80.1637]) cube([0.4, 0.4, 0.1], center=true);
    translate([5866.182000000001, -5409.4155, 80.1403]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5875.4615, -5414.1425, 80.13770000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5959.3685, -5456.6675, 80.11430000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5968.735, -5461.389999999999, 80.11175]) cube([0.4, 0.4, 0.1], center=true);
    translate([6053.425, -5503.87, 80.08924999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6062.879, -5508.588, 80.0867]) cube([0.4, 0.4, 0.1], center=true);
    translate([6148.361, -5551.032, 80.0633]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6157.9025, -5555.745000000001, 80.06070000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6244.1675000000005, -5598.135, 80.03730000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6253.7970000000005, -5602.8425, 80.03470000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([6340.863, -5645.1875, 80.0113]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6350.581, -5649.8895, 80.0087]) cube([0.4, 0.4, 0.1], center=true);
    translate([6438.439, -5692.1805, 79.9853]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6448.245000000001, -5696.8765, 79.98275]) cube([0.4, 0.4, 0.1], center=true);
    translate([6536.895, -5739.1135, 79.96025000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6546.79, -5743.802500000001, 79.95770000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([6636.25, -5785.967500000001, 79.93430000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6646.234, -5790.6495, 79.9317]) cube([0.4, 0.4, 0.1], center=true);
    translate([6736.486000000001, -5832.7605, 79.9083]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6746.5585, -5837.4355000000005, 79.9057]) cube([0.4, 0.4, 0.1], center=true);
    translate([6837.6115, -5879.474500000001, 79.8823]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6847.7735, -5884.141500000001, 79.8797]) cube([0.4, 0.4, 0.1], center=true);
    translate([6939.6365, -5926.108499999999, 79.8563]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6949.8885, -5930.767, 79.85375]) cube([0.4, 0.4, 0.1], center=true);
    translate([7042.561500000001, -5972.653, 79.83125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7052.9035, -5977.3025, 79.8287]) cube([0.4, 0.4, 0.1], center=true);
    translate([7146.3865000000005, -6019.1075, 79.8053]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7156.819, -6023.7480000000005, 79.8027]) cube([0.4, 0.4, 0.1], center=true);
    translate([7251.121, -6065.472000000001, 79.7793]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7261.644, -6070.102500000001, 79.7767]) cube([0.4, 0.4, 0.1], center=true);
    translate([7356.756, -6111.727500000001, 79.7533]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7367.370000000001, -6116.348, 79.7507]) cube([0.4, 0.4, 0.1], center=true);
    translate([7463.310000000001, -6157.892, 79.7273]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7474.015500000001, -6162.502, 79.72475]) cube([0.4, 0.4, 0.1], center=true);
    translate([7570.7744999999995, -6203.938, 79.70224999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7581.5715, -6208.537, 79.69969999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([7679.1585000000005, -6249.883000000001, 79.6763]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7690.047500000001, -6254.4710000000005, 79.6737]) cube([0.4, 0.4, 0.1], center=true);
    translate([7788.462500000001, -6295.709, 79.6503]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7799.444, -6300.2845, 79.6477]) cube([0.4, 0.4, 0.1], center=true);
    translate([7898.696, -6341.4055, 79.6243]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7909.7699999999995, -6345.969, 79.6217]) cube([0.4, 0.4, 0.1], center=true);
    translate([8009.849999999999, -6386.991000000001, 79.5983]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8021.017, -6391.542500000001, 79.59575]) cube([0.4, 0.4, 0.1], center=true);
    translate([8121.943, -6432.4475, 79.57325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8133.2035000000005, -6436.985500000001, 79.5707]) cube([0.4, 0.4, 0.1], center=true);
    translate([8234.9665, -6477.7645, 79.5473]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8246.320500000002, -6482.289, 79.5447]) cube([0.4, 0.4, 0.1], center=true);
    translate([8348.9295, -6522.951, 79.5213]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8360.377999999999, -6527.462, 79.5187]) cube([0.4, 0.4, 0.1], center=true);
    translate([8463.842, -6567.9980000000005, 79.4953]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8475.385, -6572.494500000001, 79.4927]) cube([0.4, 0.4, 0.1], center=true);
    translate([8579.695, -6612.8955000000005, 79.4693]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8591.333, -6617.377, 79.46675]) cube([0.4, 0.4, 0.1], center=true);
    translate([8696.507000000001, -6657.643, 79.44425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8708.2405, -6662.1095, 79.4417]) cube([0.4, 0.4, 0.1], center=true);
    translate([8814.2695, -6702.2405, 79.4183]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8826.0985, -6706.6915, 79.4157]) cube([0.4, 0.4, 0.1], center=true);
    translate([8932.9915, -6746.6785, 79.3923]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8944.9165, -6751.1135, 79.3897]) cube([0.4, 0.4, 0.1], center=true);
    translate([9052.6735, -6790.9565, 79.3663]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9064.6955, -6795.3755, 79.3637]) cube([0.4, 0.4, 0.1], center=true);
    translate([9173.3345, -6835.0745, 79.3403]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9185.453500000001, -6839.4765, 79.33775]) cube([0.4, 0.4, 0.1], center=true);
    translate([9294.956500000002, -6879.0135, 79.31524999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9307.172500000002, -6883.398, 79.31269999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([9417.5575, -6922.782, 79.2893]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9429.8715, -6927.149, 79.2867]) cube([0.4, 0.4, 0.1], center=true);
    translate([9541.1385, -6966.371000000001, 79.2633]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9553.551, -6970.720000000001, 79.2607]) cube([0.4, 0.4, 0.1], center=true);
    translate([9665.709, -7009.780000000001, 79.2373]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9678.220000000001, -7014.110500000001, 79.2347]) cube([0.4, 0.4, 0.1], center=true);
    translate([9791.260000000002, -7052.9995, 79.2113]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9803.870500000003, -7057.311000000001, 79.20875]) cube([0.4, 0.4, 0.1], center=true);
    translate([9917.819500000001, -7096.029, 79.18625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9930.5295, -7100.3215, 79.1837]) cube([0.4, 0.4, 0.1], center=true);
    translate([10045.3605, -7138.8685000000005, 79.1603]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10058.17, -7143.141500000001, 79.1577]) cube([0.4, 0.4, 0.1], center=true);
    translate([10173.91, -7181.508500000001, 79.1343]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10186.82, -7185.7615000000005, 79.13170000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10303.46, -7223.9484999999995, 79.10830000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10316.4705, -7228.1815, 79.10570000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10434.019499999999, -7266.1885, 79.0823]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10447.131, -7270.401, 79.07975]) cube([0.4, 0.4, 0.1], center=true);
    translate([10565.589, -7308.218999999999, 79.05725000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10578.802, -7312.41, 79.05470000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10698.178, -7350.030000000001, 79.03130000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10711.493, -7354.200000000001, 79.02870000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10831.787, -7391.64, 79.0053]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10845.2045, -7395.788500000001, 79.0027]) cube([0.4, 0.4, 0.1], center=true);
    translate([10966.425500000001, -7433.021500000001, 78.9793]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10979.946000000002, -7437.148, 78.9767]) cube([0.4, 0.4, 0.1], center=true);
    translate([11102.094000000001, -7474.192, 78.9533]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11115.718, -7478.2965, 78.95075]) cube([0.4, 0.4, 0.1], center=true);
    translate([11238.802, -7515.133500000001, 78.92825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11252.529999999999, -7519.2155, 78.9257]) cube([0.4, 0.4, 0.1], center=true);
    translate([11376.550000000001, -7555.8545, 78.9023]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11390.382000000001, -7559.914000000001, 78.8997]) cube([0.4, 0.4, 0.1], center=true);
    translate([11515.338000000002, -7596.3460000000005, 78.8763]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11529.275000000001, -7600.3820000000005, 78.8737]) cube([0.4, 0.4, 0.1], center=true);
    translate([11655.185000000001, -7636.598, 78.8503]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11669.2275, -7640.6105, 78.8477]) cube([0.4, 0.4, 0.1], center=true);
    translate([11796.082499999999, -7676.6195, 78.8243]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11810.23, -7680.609, 78.82175]) cube([0.4, 0.4, 0.1], center=true);
    translate([11938.03, -7716.411, 78.79925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11952.2835, -7720.376499999999, 78.7967]) cube([0.4, 0.4, 0.1], center=true);
    translate([12081.0465, -7755.9535000000005, 78.7733]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12095.407000000001, -7759.895, 78.7707]) cube([0.4, 0.4, 0.1], center=true);
    translate([12225.133, -7795.264999999999, 78.7473]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12239.6005, -7799.1825, 78.7447]) cube([0.4, 0.4, 0.1], center=true);
    translate([12370.2895, -7834.3275, 78.7213]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12384.8645, -7838.2205, 78.7187]) cube([0.4, 0.4, 0.1], center=true);
    translate([12516.5255, -7873.1495, 78.6953]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12531.208, -7877.0185, 78.69275]) cube([0.4, 0.4, 0.1], center=true);
    translate([12663.832000000002, -7911.7315, 78.67025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12678.622500000001, -7915.5755, 78.6677]) cube([0.4, 0.4, 0.1], center=true);
    translate([12812.227499999999, -7950.0545, 78.6443]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12827.127, -7953.8730000000005, 78.6417]) cube([0.4, 0.4, 0.1], center=true);
    translate([12961.713, -7988.127, 78.6183]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12976.721500000001, -7991.9205, 78.6157]) cube([0.4, 0.4, 0.1], center=true);
    translate([13112.2885, -8025.949500000001, 78.5923]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13127.4065, -8029.717500000001, 78.5897]) cube([0.4, 0.4, 0.1], center=true);
    translate([13263.9635, -8063.512500000001, 78.5663]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13279.1915, -8067.254500000001, 78.56375]) cube([0.4, 0.4, 0.1], center=true);
    translate([13416.7385, -8100.815500000001, 78.54125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13432.077, -8104.532, 78.5387]) cube([0.4, 0.4, 0.1], center=true);
    translate([13570.623, -8137.868, 78.5153]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13586.0725, -8141.558500000001, 78.5127]) cube([0.4, 0.4, 0.1], center=true);
    translate([13725.617500000002, -8174.6515, 78.4893]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13741.178000000002, -8178.315500000001, 78.4867]) cube([0.4, 0.4, 0.1], center=true);
    translate([13881.722000000002, -8211.1745, 78.4633]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13897.394500000002, -8214.8125, 78.4607]) cube([0.4, 0.4, 0.1], center=true);
    translate([14038.9555, -8247.4375, 78.43730000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14054.7405, -8251.048999999999, 78.43475000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([14197.3095, -8283.430999999999, 78.41225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14213.207, -8287.016, 78.4097]) cube([0.4, 0.4, 0.1], center=true);
    translate([14356.793000000001, -8319.164, 78.3863]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14372.804000000002, -8322.7225, 78.3837]) cube([0.4, 0.4, 0.1], center=true);
    translate([14517.416000000001, -8354.6275, 78.3603]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14533.541000000001, -8358.159, 78.3577]) cube([0.4, 0.4, 0.1], center=true);
    translate([14679.179000000002, -8389.821, 78.3343]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14695.418000000001, -8393.3255, 78.3317]) cube([0.4, 0.4, 0.1], center=true);
    translate([14842.082, -8424.7445, 78.3083]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14858.436000000002, -8428.222, 78.30575]) cube([0.4, 0.4, 0.1], center=true);
    translate([15006.144, -8459.398, 78.28325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15022.613500000001, -8462.8485, 78.2807]) cube([0.4, 0.4, 0.1], center=true);
    translate([15171.356500000002, -8493.7815, 78.2573]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15187.9415, -8497.2045, 78.2547]) cube([0.4, 0.4, 0.1], center=true);
    translate([15337.7285, -8527.8855, 78.2313]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15354.43, -8531.2805, 78.2287]) cube([0.4, 0.4, 0.1], center=true);
    translate([15505.27, -8561.709499999999, 78.2053]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15522.0885, -8565.077, 78.20270000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15673.9815, -8595.263, 78.17930000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15690.917, -8598.6025, 78.17675000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15843.863000000001, -8628.5275, 78.15425000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15860.916500000001, -8631.839, 78.1517]) cube([0.4, 0.4, 0.1], center=true);
    translate([16014.9335, -8661.521, 78.1283]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16032.1055, -8664.8045, 78.12570000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([16187.1845, -8694.2255, 78.10230000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16204.474999999999, -8697.4805, 78.09970000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([16360.625, -8726.6495, 78.0763]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16378.0345, -8729.8765, 78.0737]) cube([0.4, 0.4, 0.1], center=true);
    translate([16535.255500000003, -8758.7935, 78.05030000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16552.785000000003, -8761.992, 78.04775000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([16711.095, -8790.648, 78.02525000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16728.745, -8793.8175, 78.02270000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([16888.135000000002, -8822.212500000001, 77.9993]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16905.906000000003, -8825.353000000001, 77.9967]) cube([0.4, 0.4, 0.1], center=true);
    translate([17066.394000000004, -8853.487, 77.9733]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17084.287000000004, -8856.5985, 77.9707]) cube([0.4, 0.4, 0.1], center=true);
    translate([17245.873, -8884.4715, 77.9473]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17263.888, -8887.5535, 77.9447]) cube([0.4, 0.4, 0.1], center=true);
    translate([17426.572, -8915.156500000001, 77.9213]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17444.71, -8918.2085, 77.91875]) cube([0.4, 0.4, 0.1], center=true);
    translate([17608.510000000002, -8945.5415, 77.89625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17626.772, -8948.563999999998, 77.8937]) cube([0.4, 0.4, 0.1], center=true);
    translate([17791.688, -8975.635999999999, 77.8703]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17810.074, -8978.628499999999, 77.8677]) cube([0.4, 0.4, 0.1], center=true);
    translate([17976.106000000003, -9005.4215, 77.8443]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17994.617000000002, -9008.3835, 77.8417]) cube([0.4, 0.4, 0.1], center=true);
    translate([18161.783, -9034.9065, 77.8183]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18180.42, -9037.8385, 77.81569999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([18348.719999999998, -9064.0915, 77.7923]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18367.4835, -9066.993, 77.78975]) cube([0.4, 0.4, 0.1], center=true);
    translate([18536.9265, -9092.967, 77.76725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18555.817000000003, -9095.838, 77.7647]) cube([0.4, 0.4, 0.1], center=true);
    translate([18726.403000000002, -9121.542, 77.7413]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18745.421000000002, -9124.3825, 77.7387]) cube([0.4, 0.4, 0.1], center=true);
    translate([18917.159000000003, -9149.807499999999, 77.7153]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18936.305500000002, -9152.617, 77.7127]) cube([0.4, 0.4, 0.1], center=true);
    translate([19109.2045, -9177.763, 77.6893]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19128.48, -9180.541500000001, 77.6867]) cube([0.4, 0.4, 0.1], center=true);
    translate([19302.54, -9205.408500000001, 77.6633]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19321.9455, -9208.156, 77.66075000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([19497.1845, -9232.744, 77.63825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19516.7205, -9235.460000000001, 77.6357]) cube([0.4, 0.4, 0.1], center=true);
    translate([19693.129500000003, -9259.760000000002, 77.6123]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19712.796500000004, -9262.444500000001, 77.6097]) cube([0.4, 0.4, 0.1], center=true);
    translate([19890.393500000002, -9286.4655, 77.5863]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19910.192, -9289.1185, 77.5837]) cube([0.4, 0.4, 0.1], center=true);
    translate([20088.968, -9312.8515, 77.5603]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20108.898500000003, -9315.4725, 77.5577]) cube([0.4, 0.4, 0.1], center=true);
    translate([20288.8715, -9338.9175, 77.5343]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20308.935, -9341.5065, 77.53175]) cube([0.4, 0.4, 0.1], center=true);
    translate([20490.105, -9364.6635, 77.50925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20510.302, -9367.220500000001, 77.5067]) cube([0.4, 0.4, 0.1], center=true);
    translate([20692.678000000004, -9390.0895, 77.4833]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20713.009000000002, -9392.614, 77.4807]) cube([0.4, 0.4, 0.1], center=true);
    translate([20896.591, -9415.186, 77.4573]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20917.057, -9417.678, 77.4547]) cube([0.4, 0.4, 0.1], center=true);
    translate([21101.863, -9439.962000000001, 77.43130000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21122.464500000002, -9442.421500000002, 77.4287]) cube([0.4, 0.4, 0.1], center=true);
    translate([21308.485500000003, -9464.4085, 77.4053]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21329.222500000003, -9466.8355, 77.40275]) cube([0.4, 0.4, 0.1], center=true);
    translate([21516.467500000002, -9488.5345, 77.38025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21537.341500000002, -9490.929, 77.3777]) cube([0.4, 0.4, 0.1], center=true);
    translate([21725.8285, -9512.331000000002, 77.3543]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21746.839999999997, -9514.692000000001, 77.3517]) cube([0.4, 0.4, 0.1], center=true);
    translate([21936.559999999998, -9535.787999999999, 77.3283]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21957.7095, -9538.116, 77.3257]) cube([0.4, 0.4, 0.1], center=true);
    translate([22148.680500000002, -9558.924, 77.3023]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22169.969, -9561.2185, 77.29970000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([22362.191, -9581.711500000001, 77.27630000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22383.619, -9583.9725, 77.27375]) cube([0.4, 0.4, 0.1], center=true);
    translate([22577.101, -9604.1775, 77.25125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22598.668999999998, -9606.405, 77.2487]) cube([0.4, 0.4, 0.1], center=true);
    translate([22793.411, -9626.295, 77.2253]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22815.12, -9628.4885, 77.2227]) cube([0.4, 0.4, 0.1], center=true);
    translate([23011.14, -9648.0815, 77.1993]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23032.991, -9650.241, 77.1967]) cube([0.4, 0.4, 0.1], center=true);
    translate([23230.289, -9669.519, 77.17330000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23252.2825, -9671.644, 77.17070000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([23450.867500000004, -9690.616, 77.1473]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23473.004000000004, -9692.7065, 77.14475]) cube([0.4, 0.4, 0.1], center=true);
    translate([23672.876, -9711.3635, 77.12225000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23695.156499999997, -9713.4195, 77.11970000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([23896.333499999997, -9731.7705, 77.09630000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23918.759, -9733.791500000001, 77.09370000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([24121.241, -9751.818500000001, 77.0703]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24143.812, -9753.8045, 77.0677]) cube([0.4, 0.4, 0.1], center=true);
    translate([24347.608, -9771.5255, 77.0443]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24370.3255, -9773.477, 77.0417]) cube([0.4, 0.4, 0.1], center=true);
    translate([24575.444499999998, -9790.883000000002, 77.0183]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24598.3095, -9792.799, 77.01575]) cube([0.4, 0.4, 0.1], center=true);
    translate([24804.7605, -9809.881, 76.99325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24827.774, -9811.761499999999, 76.9907]) cube([0.4, 0.4, 0.1], center=true);
    translate([25035.566000000003, -9828.528499999999, 76.9673]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25058.7285, -9830.3735, 76.9647]) cube([0.4, 0.4, 0.1], center=true);
    translate([25267.8615, -9846.8165, 76.9413]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25291.1735, -9848.626, 76.9387]) cube([0.4, 0.4, 0.1], center=true);
    translate([25501.6565, -9864.753999999999, 76.9153]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25525.1195, -9866.527999999998, 76.9127]) cube([0.4, 0.4, 0.1], center=true);
    translate([25736.970500000003, -9882.331999999999, 76.8893]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25760.585000000003, -9884.07, 76.88675]) cube([0.4, 0.4, 0.1], center=true);
    translate([25973.795000000002, -9899.550000000001, 76.86425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25997.562, -9901.252, 76.8617]) cube([0.4, 0.4, 0.1], center=true);
    translate([26212.158000000003, -9916.408, 76.8383]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26236.078500000003, -9918.074, 76.8357]) cube([0.4, 0.4, 0.1], center=true);
    translate([26452.0515, -9932.905999999999, 76.81230000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26476.126, -9934.536, 76.8097]) cube([0.4, 0.4, 0.1], center=true);
    translate([26693.494, -9949.044, 76.7863]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26717.724, -9950.6375, 76.7837]) cube([0.4, 0.4, 0.1], center=true);
    translate([26936.496000000003, -9964.8125, 76.7603]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26960.882000000005, -9966.3695, 76.75775]) cube([0.4, 0.4, 0.1], center=true);
    translate([27181.058000000005, -9980.2205, 76.73525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27205.601000000002, -9981.741, 76.7327]) cube([0.4, 0.4, 0.1], center=true);
    translate([27427.198999999997, -9995.259, 76.7093]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27451.899999999998, -9996.743, 76.7067]) cube([0.4, 0.4, 0.1], center=true);
    translate([27674.920000000002, -10009.937000000002, 76.6833]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27699.780000000002, -10011.3845, 76.6807]) cube([0.4, 0.4, 0.1], center=true);
    translate([27924.24, -10024.245499999999, 76.6573]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27949.2595, -10025.655999999999, 76.6547]) cube([0.4, 0.4, 0.1], center=true);
    translate([28175.1505, -10038.184, 76.6313]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28200.3305, -10039.5575, 76.62875]) cube([0.4, 0.4, 0.1], center=true);
    translate([28427.679500000002, -10051.7525, 76.60625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28453.021500000003, -10053.089, 76.6037]) cube([0.4, 0.4, 0.1], center=true);
    translate([28681.828500000003, -10064.951000000001, 76.5803]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28707.333000000002, -10066.2505, 76.5777]) cube([0.4, 0.4, 0.1], center=true);
    translate([28937.607, -10077.779499999999, 76.5543]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28963.275, -10079.0415, 76.5517]) cube([0.4, 0.4, 0.1], center=true);
    translate([29195.025, -10090.228500000001, 76.5283]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29220.857500000002, -10091.452500000001, 76.5257]) cube([0.4, 0.4, 0.1], center=true);
    translate([29454.092500000002, -10102.2975, 76.5023]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29480.090500000002, -10103.484, 76.49975]) cube([0.4, 0.4, 0.1], center=true);
    translate([29714.8195, -10113.996, 76.47725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29740.984, -10115.144499999999, 76.4747]) cube([0.4, 0.4, 0.1], center=true);
    translate([29977.216, -10125.305500000002, 76.4513]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30003.5485, -10126.415500000001, 76.4487]) cube([0.4, 0.4, 0.1], center=true);
    translate([30241.301499999998, -10136.2345, 76.42530000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30267.803499999998, -10137.3065, 76.4227]) cube([0.4, 0.4, 0.1], center=true);
    translate([30507.0865, -10146.7835, 76.3993]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30533.759000000002, -10147.817, 76.3967]) cube([0.4, 0.4, 0.1], center=true);
    translate([30774.581000000002, -10156.943000000001, 76.3733]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30801.4255, -10157.938000000002, 76.37075]) cube([0.4, 0.4, 0.1], center=true);
    translate([31043.804500000002, -10166.722, 76.34825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31070.822, -10167.6785, 76.3457]) cube([0.4, 0.4, 0.1], center=true);
    translate([31314.758, -10176.1115, 76.3223]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31341.950000000004, -10177.029, 76.3197]) cube([0.4, 0.4, 0.1], center=true);
    translate([31587.47, -10185.110999999999, 76.2963]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31614.838, -10185.9895, 76.29370000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([31861.942, -10193.720500000001, 76.27030000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31889.487, -10194.560000000001, 76.26770000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([32138.193, -10201.94, 76.24430000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32165.9165, -10202.74, 76.24175000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([32416.233500000002, -10209.76, 76.21925000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32444.1365, -10210.5205, 76.2167]) cube([0.4, 0.4, 0.1], center=true);
    translate([32696.073500000002, -10217.1895, 76.1933]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32724.158000000003, -10217.911, 76.1907]) cube([0.4, 0.4, 0.1], center=true);
    translate([32977.742, -10224.229, 76.16730000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33006.009, -10224.9105, 76.16470000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([33261.231, -10230.8595, 76.1413]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33289.681000000004, -10231.501, 76.1387]) cube([0.4, 0.4, 0.1], center=true);
    translate([33546.559, -10237.099, 76.1153]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33575.194, -10237.701, 76.11275]) cube([0.4, 0.4, 0.1], center=true);
    translate([33833.746, -10242.938999999998, 76.09025000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33862.567500000005, -10243.500999999998, 76.08770000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([34122.802500000005, -10248.378999999999, 76.0643]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34151.8115, -10248.901, 76.0617]) cube([0.4, 0.4, 0.1], center=true);
    translate([34413.73850000001, -10253.419, 76.0383]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34442.936, -10253.9005, 76.0357]) cube([0.4, 0.4, 0.1], center=true);
    translate([34706.564, -10258.049500000001, 76.0123]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34735.9515, -10258.490500000002, 76.0097]) cube([0.4, 0.4, 0.1], center=true);
    translate([35001.298500000004, -10262.2795, 75.9863]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35030.8775, -10262.68, 75.98375]) cube([0.4, 0.4, 0.1], center=true);
    translate([35297.9525, -10266.100000000002, 75.96124999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35327.724500000004, -10266.460000000003, 75.9587]) cube([0.4, 0.4, 0.1], center=true);
    translate([35596.5455, -10269.520000000002, 75.9353]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35626.5115, -10269.839000000002, 75.9327]) cube([0.4, 0.4, 0.1], center=true);
    translate([35897.0785, -10272.521, 75.9093]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35927.240000000005, -10272.799, 75.9067]) cube([0.4, 0.4, 0.1], center=true);
    translate([36199.58, -10275.121000000001, 75.8833]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36229.938500000004, -10275.3585, 75.8807]) cube([0.4, 0.4, 0.1], center=true);
    translate([36504.0515, -10277.3115, 75.8573]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36534.608, -10277.5075, 75.85475]) cube([0.4, 0.4, 0.1], center=true);
    translate([36810.512, -10279.0825, 75.83225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36841.2685, -10279.237000000001, 75.8297]) cube([0.4, 0.4, 0.1], center=true);
    translate([37118.9815, -10280.443000000001, 75.80630000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37149.93950000001, -10280.556, 75.8037]) cube([0.4, 0.4, 0.1], center=true);
    translate([37429.4705, -10281.384, 75.7803]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37460.631, -10281.4555, 75.7777]) cube([0.4, 0.4, 0.1], center=true);
    translate([37741.989, -10281.9145, 75.7543]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37773.3535, -10281.944500000001, 75.7517]) cube([0.4, 0.4, 0.1], center=true);
    translate([38056.5565, -10282.025500000002, 75.7283]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38088.126000000004, -10282.013500000001, 75.72575]) cube([0.4, 0.4, 0.1], center=true);
    translate([38373.174000000006, -10281.7165, 75.70325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38404.950000000004, -10281.6625, 75.7007]) cube([0.4, 0.4, 0.1], center=true);
    translate([38691.87, -10280.987500000001, 75.6773]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38723.8545, -10280.891500000002, 75.6747]) cube([0.4, 0.4, 0.1], center=true);
    translate([39012.6555, -10279.838500000002, 75.6513]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39044.849, -10279.7, 75.6487]) cube([0.4, 0.4, 0.1], center=true);
    translate([39335.531, -10278.26, 75.6253]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39367.9345, -10278.079000000002, 75.6227]) cube([0.4, 0.4, 0.1], center=true);
    translate([39660.5155, -10276.261, 75.5993]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39693.131, -10276.0375, 75.59675]) cube([0.4, 0.4, 0.1], center=true);
    translate([39987.629, -10273.8325, 75.57424999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40020.458, -10273.5665, 75.57169999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([40316.882, -10270.983500000002, 75.5483]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40349.9255, -10270.674500000001, 75.5457]) cube([0.4, 0.4, 0.1], center=true);
    translate([40648.2845, -10267.6955, 75.5223]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40681.5435, -10267.3435, 75.5197]) cube([0.4, 0.4, 0.1], center=true);
    translate([40981.8465, -10263.9865, 75.4963]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41015.3225, -10263.5915, 75.4937]) cube([0.4, 0.4, 0.1], center=true);
    translate([41317.587499999994, -10259.8385, 75.4703]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41351.2815, -10259.3995, 75.46775]) cube([0.4, 0.4, 0.1], center=true);
    translate([41655.5085, -10255.2505, 75.44525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41689.422, -10254.768, 75.4427]) cube([0.4, 0.4, 0.1], center=true);
    translate([41995.638, -10250.232, 75.4193]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42029.7725, -10249.706, 75.4167]) cube([0.4, 0.4, 0.1], center=true);
    translate([42337.97749999999, -10244.774000000001, 75.3933]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42372.3845, -10244.203500000001, 75.3907]) cube([0.4, 0.4, 0.1], center=true);
    translate([42683.5055, -10238.8665, 75.3673]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42718.274000000005, -10238.2515, 75.36470000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([43032.986000000004, -10232.518500000002, 75.34130000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43068.154, -10231.859000000002, 75.33875]) cube([0.4, 0.4, 0.1], center=true);
    translate([43386.466, -10225.721, 75.31625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43422.046500000004, -10225.016, 75.3137]) cube([0.4, 0.4, 0.1], center=true);
    translate([43744.18350000001, -10218.464, 75.2903]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43780.244000000006, -10217.713500000002, 75.28770000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([44107.196, -10210.756500000001, 75.26430000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44143.958, -10209.960500000001, 75.26170000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([44478.722, -10202.589500000002, 75.23830000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44516.868500000004, -10201.747000000001, 75.23570000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([44868.741500000004, -10193.953000000001, 75.2123]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44910.4075, -10193.064000000002, 75.20975]) cube([0.4, 0.4, 0.1], center=true);
    translate([45308.5225, -10184.856, 75.18725000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45358.203, -10183.920499999998, 75.18470000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45854.337, -10175.289499999999, 75.16130000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45926.0675, -10174.306499999999, 75.15870000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([46721.0825, -10165.2435, 75.1353]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46888.754499999995, -10164.213, 75.1327]) cube([0.4, 0.4, 0.1], center=true);
    translate([49111.835499999994, -10154.727, 75.1093]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49434.195, -10153.648500000001, 75.1067]) cube([0.4, 0.4, 0.1], center=true);
    translate([53013.58500000001, -10143.721500000001, 75.0833]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53295.289500000006, -10142.594500000001, 75.08075]) cube([0.4, 0.4, 0.1], center=true);
    translate([54786.580500000004, -10132.2355, 75.05825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55017.684, -10131.060000000001, 75.0557]) cube([0.4, 0.4, 0.1], center=true);
    translate([57686.256, -10120.26, 75.0323]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57916.602, -10119.0355, 75.0297]) cube([0.4, 0.4, 0.1], center=true);
    translate([59394.257999999994, -10107.7945, 75.0063]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59562.5995, -10106.520499999999, 75.0037]) cube([0.4, 0.4, 0.1], center=true);
    translate([61115.0905, -10094.8295, 74.9803]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61290.205, -10093.505500000001, 74.9777]) cube([0.4, 0.4, 0.1], center=true);
    translate([62889.774999999994, -10081.364500000001, 74.9543]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63069.9415, -10079.990500000002, 74.95175]) cube([0.4, 0.4, 0.1], center=true);
    translate([64713.368500000004, -10067.399500000001, 74.92925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64898.124, -10065.975, 74.9267]) cube([0.4, 0.4, 0.1], center=true);
    translate([66580.296, -10052.925000000001, 74.9033]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66769.0305, -10051.4495, 74.9007]) cube([0.4, 0.4, 0.1], center=true);
    translate([68484.07949999999, -10037.9405, 74.8773]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68676.122, -10036.414, 74.8747]) cube([0.4, 0.4, 0.1], center=true);
    translate([70417.838, -10022.446, 74.8513]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70612.481, -10020.8685, 74.8487]) cube([0.4, 0.4, 0.1], center=true);
    translate([72374.339, -10006.441499999999, 74.8253]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72570.831, -10004.812, 74.82275]) cube([0.4, 0.4, 0.1], center=true);
    translate([74345.829, -9989.908000000001, 74.80025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74543.3685, -9988.2265, 74.7977]) cube([0.4, 0.4, 0.1], center=true);
    translate([76324.0815, -9972.863500000001, 74.7743]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76521.939, -9971.129500000001, 74.7717]) cube([0.4, 0.4, 0.1], center=true);
    translate([78302.661, -9955.280499999999, 74.7483]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78500.2425, -9953.493499999999, 74.7457]) cube([0.4, 0.4, 0.1], center=true);
    translate([80275.9875, -9937.1765, 74.7223]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80472.78450000001, -9935.3365, 74.7197]) cube([0.4, 0.4, 0.1], center=true);
    translate([82239.3855, -9918.5335, 74.6963]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82434.98, -9916.64, 74.69375]) cube([0.4, 0.4, 0.1], center=true);
    translate([84189.08, -9899.359999999999, 74.67125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84383.14150000001, -9897.412999999999, 74.6687]) cube([0.4, 0.4, 0.1], center=true);
    translate([86122.1485, -9879.646999999999, 74.6453]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86314.38549999999, -9877.646, 74.6427]) cube([0.4, 0.4, 0.1], center=true);
    translate([88035.64450000001, -9859.394, 74.6193]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88225.80900000001, -9857.3385, 74.6167]) cube([0.4, 0.4, 0.1], center=true);
    translate([89927.511, -9838.5915, 74.5933]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90115.401, -9836.4815, 74.5907]) cube([0.4, 0.4, 0.1], center=true);
    translate([91795.71900000001, -9817.2485, 74.5673]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91981.12850000002, -9815.0835, 74.56475]) cube([0.4, 0.4, 0.1], center=true);
    translate([93638.1815, -9795.346500000001, 74.54225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93820.8995, -9793.1265, 74.5397]) cube([0.4, 0.4, 0.1], center=true);
    translate([95452.7705, -9772.9035, 74.5163]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95632.581, -9770.628, 74.5137]) cube([0.4, 0.4, 0.1], center=true);
    translate([97237.299, -9749.892, 74.4903]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97413.97949999999, -9747.5605, 74.4877]) cube([0.4, 0.4, 0.1], center=true);
    translate([98989.51049999999, -9726.3295, 74.4643]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99162.83249999999, -9723.942500000001, 74.4617]) cube([0.4, 0.4, 0.1], center=true);
    translate([100707.0975, -9702.2075, 74.4383]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100876.82699999999, -9699.764, 74.43575]) cube([0.4, 0.4, 0.1], center=true);
    translate([102387.693, -9677.516, 74.41325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102553.588, -9675.0155, 74.4107]) cube([0.4, 0.4, 0.1], center=true);
    translate([104028.832, -9652.2545, 74.3873]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104190.64349999999, -9649.697, 74.3847]) cube([0.4, 0.4, 0.1], center=true);
    translate([105628.0065, -9626.423, 74.3613]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105785.47850000001, -9623.808, 74.35870000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([107182.6115, -9600.012, 74.33530000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107335.4815, -9597.339, 74.33270000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([108690.0085, -9573.021, 74.30930000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108838.006, -9570.29, 74.30675000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([110147.434, -9545.45, 74.28425000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110290.27799999999, -9542.66, 74.28170000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([111552.04200000002, -9517.28, 74.25830000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111689.44200000001, -9514.431, 74.25570000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([112900.878, -9488.529, 74.23230000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113032.53099999999, -9485.6205, 74.22970000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([114190.84899999999, -9459.1695, 74.2063]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114316.43849999999, -9456.2005, 74.2037]) cube([0.4, 0.4, 0.1], center=true);
    translate([115418.7315, -9429.2095, 74.1803]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([115537.926, -9426.18, 74.17775]) cube([0.4, 0.4, 0.1], center=true);
    translate([116581.13399999999, -9398.640000000001, 74.15525000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116693.586, -9395.549, 74.15270000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([117674.514, -9367.451, 74.1293]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117779.861, -9364.298499999999, 74.1267]) cube([0.4, 0.4, 0.1], center=true);
    translate([118695.179, -9335.6515, 74.1033]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118793.04149999999, -9332.437, 74.1007]) cube([0.4, 0.4, 0.1], center=true);
    translate([119639.24849999999, -9303.223, 74.0773]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119729.22949999999, -9299.9455, 74.07469999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([120502.68049999999, -9270.164499999999, 74.0513]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120584.36649999999, -9266.8235, 74.04875]) cube([0.4, 0.4, 0.1], center=true);
    translate([121281.2635, -9236.466500000002, 74.02625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121354.223, -9233.061500000002, 74.0237]) cube([0.4, 0.4, 0.1], center=true);
    translate([121970.59700000001, -9202.1285, 74.0003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122034.3815, -9198.658500000001, 73.9977]) cube([0.4, 0.4, 0.1], center=true);
    translate([122566.1285, -9167.1315, 73.9743]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122620.273, -9163.596, 73.9717]) cube([0.4, 0.4, 0.1], center=true);
    translate([123063.127, -9131.484000000002, 73.9483]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123107.15149999999, -9127.883000000002, 73.9457]) cube([0.4, 0.4, 0.1], center=true);
    translate([123456.7385, -9095.177, 73.9223]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123490.152, -9091.509, 73.91975000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([123742.008, -9058.191, 73.89725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123764.31000000001, -9054.456, 73.8947]) cube([0.4, 0.4, 0.1], center=true);
    translate([123913.89, -9020.544, 73.8713]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123924.5685, -9016.7415, 73.8687]) cube([0.4, 0.4, 0.1], center=true);
    translate([123967.20150000001, -8982.2085, 73.8453]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123965.73200000002, -8978.338000000002, 73.8427]) cube([0.4, 0.4, 0.1], center=true);
    translate([123896.648, -8943.202, 73.8193]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123882.4945, -8939.263, 73.8167]) cube([0.4, 0.4, 0.1], center=true);
    translate([123696.81550000001, -8903.497000000001, 73.7933]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123669.43100000001, -8899.488000000001, 73.79075]) cube([0.4, 0.4, 0.1], center=true);
    translate([123362.189, -8863.092, 73.76825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123321.01599999999, -8859.0165, 73.7657]) cube([0.4, 0.4, 0.1], center=true);
    translate([122887.14399999999, -8822.0535, 73.7423]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122831.61549999999, -8817.912, 73.7397]) cube([0.4, 0.4, 0.1], center=true);
    translate([122265.9745, -8780.328, 73.7163]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122195.5145, -8776.1175, 73.7137]) cube([0.4, 0.4, 0.1], center=true);
    translate([121492.87550000001, -8737.9125, 73.6903]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121406.899, -8733.633500000002, 73.68769999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([120561.96100000001, -8694.8165, 73.6643]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120459.8745, -8690.469000000001, 73.66175]) cube([0.4, 0.4, 0.1], center=true);
    translate([119467.2555, -8651.031, 73.63925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119348.4565, -8646.615, 73.6367]) cube([0.4, 0.4, 0.1], center=true);
    translate([118202.6935, -8606.565, 73.6133]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118066.5695, -8602.0805, 73.6107]) cube([0.4, 0.4, 0.1], center=true);
    translate([116762.1005, -8561.4095, 73.5873]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116608.028, -8556.8565, 73.5847]) cube([0.4, 0.4, 0.1], center=true);
    translate([115139.19200000001, -8515.5735, 73.5613]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114966.53700000001, -8510.952500000001, 73.5587]) cube([0.4, 0.4, 0.1], center=true);
    translate([113327.58300000001, -8469.057499999999, 73.5353]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113135.7035, -8464.368999999999, 73.53275000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([111320.8265, -8421.871, 73.51025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111109.07250000001, -8417.1155, 73.5077]) cube([0.4, 0.4, 0.1], center=true);
    translate([109112.3775, -8374.014500000001, 73.4843]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108880.09, -8369.192000000001, 73.4817]) cube([0.4, 0.4, 0.1], center=true);
    translate([106695.61, -8325.488, 73.4583]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106442.122, -8320.599, 73.4557]) cube([0.4, 0.4, 0.1], center=true);
    translate([104063.81800000001, -8276.301, 73.4323]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103788.45550000001, -8271.346, 73.42970000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([101210.2345, -8226.454, 73.40630000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100912.3165, -8221.4335, 73.40375]) cube([0.4, 0.4, 0.1], center=true);
    translate([98128.0135, -8175.9565, 73.38125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97806.85100000001, -8170.871000000001, 73.3787]) cube([0.4, 0.4, 0.1], center=true);
    translate([94810.229, -8124.809000000001, 73.3553]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94465.1255, -8119.659500000001, 73.35270000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([91249.88449999999, -8073.0305, 73.32930000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90880.13799999999, -8067.817999999999, 73.32670000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([87439.94200000001, -8020.621999999999, 73.30330000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87044.84500000002, -8015.3475, 73.3007]) cube([0.4, 0.4, 0.1], center=true);
    translate([83373.29500000001, -7967.6025, 73.2773]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82952.1325, -7962.2665, 73.27475]) cube([0.4, 0.4, 0.1], center=true);
    translate([79042.7575, -7913.9635, 73.25225000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78594.80850000001, -7908.5665, 73.24970000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([74441.10149999999, -7859.7235, 73.22630000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73965.63949999999, -7854.266500000001, 73.22370000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([69561.0305, -7804.883500000001, 73.2003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69057.323, -7799.3675, 73.1977]) cube([0.4, 0.4, 0.1], center=true);
    translate([64395.19700000001, -7749.4625, 73.1743]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63862.505000000005, -7743.888, 73.1717]) cube([0.4, 0.4, 0.1], center=true);
    translate([58936.175, -7693.452, 73.1483]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58373.753000000004, -7687.82, 73.14575]) cube([0.4, 0.4, 0.1], center=true);
    translate([53176.487, -7636.880000000001, 73.12325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52583.584, -7631.191500000001, 73.1207]) cube([0.4, 0.4, 0.1], center=true);
    translate([47108.596000000005, -7579.7385, 73.0973]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46484.4525, -7573.994000000001, 73.0947]) cube([0.4, 0.4, 0.1], center=true);
    translate([40724.8575, -7522.046, 73.0713]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40068.705, -7516.246999999999, 73.06869999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([34017.555, -7463.812999999999, 73.0453]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33328.614499999996, -7457.959999999999, 73.0427]) cube([0.4, 0.4, 0.1], center=true);
    translate([26978.8355, -7405.040000000001, 73.0193]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26256.316, -7399.134, 73.01675]) cube([0.4, 0.4, 0.1], center=true);
    translate([19600.744000000002, -7345.745999999999, 72.99425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18843.842000000004, -7339.788, 72.9917]) cube([0.4, 0.4, 0.1], center=true);
    translate([11875.178000000002, -7285.932, 72.9683]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11083.077500000001, -7279.923, 72.9657]) cube([0.4, 0.4, 0.1], center=true);
    translate([3793.9325, -7225.617, 72.9423]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2965.3134999999997, -7219.5585, 72.9397]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4660.683500000001, -7164.811500000001, 72.9163]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5527.4395, -7158.704500000001, 72.9137]) cube([0.4, 0.4, 0.1], center=true);
    translate([-13503.0505, -7103.5255, 72.8903]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-14409.262999999999, -7097.371, 72.88775]) cube([0.4, 0.4, 0.1], center=true);
    translate([-22745.477, -7041.769000000001, 72.86525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-23692.265, -7035.568000000001, 72.8627]) cube([0.4, 0.4, 0.1], center=true);
    translate([-32398.235000000004, -6979.552, 72.8393]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-33386.518500000006, -6973.304999999999, 72.8367]) cube([0.4, 0.4, 0.1], center=true);
    translate([-42469.6515, -6916.875, 72.8133]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-43500.159, -6910.5835, 72.8107]) cube([0.4, 0.4, 0.1], center=true);
    translate([-52966.161, -6853.7665, 72.7873]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-54039.438, -6847.4315, 72.7847]) cube([0.4, 0.4, 0.1], center=true);
    translate([-63892.422, -6790.2185, 72.7613]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-65008.842, -6783.8405, 72.75875]) cube([0.4, 0.4, 0.1], center=true);
    translate([-75251.418, -6726.2495, 72.73625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-76411.1925, -6719.8295, 72.7337]) cube([0.4, 0.4, 0.1], center=true);
    translate([-87044.55750000001, -6661.860500000001, 72.7103]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-88247.748, -6655.399500000001, 72.7077]) cube([0.4, 0.4, 0.1], center=true);
    translate([-99271.812, -6597.0705, 72.68430000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-100518.3445, -6590.5695000000005, 72.6817]) cube([0.4, 0.4, 0.1], center=true);
    translate([-111931.8655, -6531.8805, 72.6583]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-113221.5475, -6525.3405, 72.6557]) cube([0.4, 0.4, 0.1], center=true);
    translate([-125022.3025, -6466.309499999999, 72.6323]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-126354.841, -6459.732, 72.62975]) cube([0.4, 0.4, 0.1], center=true);
    translate([-138539.779, -6400.368, 72.60725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-139914.798, -6393.754000000001, 72.6047]) cube([0.4, 0.4, 0.1], center=true);
    translate([-152480.202, -6334.066000000001, 72.5813]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-153897.262, -6327.416, 72.5787]) cube([0.4, 0.4, 0.1], center=true);
    translate([-166838.93800000002, -6267.4039999999995, 72.5553]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-168297.53600000002, -6260.718999999999, 72.5527]) cube([0.4, 0.4, 0.1], center=true);
    translate([-181610.62399999998, -6200.401, 72.5293]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-183110.186, -6193.682500000001, 72.5267]) cube([0.4, 0.4, 0.1], center=true);
    translate([-196789.214, -6133.067499999999, 72.5033]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-198329.093, -6126.3165, 72.50075]) cube([0.4, 0.4, 0.1], center=true);
    translate([-212367.887, -6065.413500000001, 72.47825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-213947.3635, -6058.631, 72.4757]) cube([0.4, 0.4, 0.1], center=true);
    translate([-228339.1465, -5997.4490000000005, 72.4523]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-229957.432, -5990.6355, 72.44969999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([-244694.788, -5929.1745, 72.4263]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-246351.0245, -5922.331, 72.42370000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-261425.92549999998, -5860.609, 72.40030000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-263119.1845, -5853.737, 72.39770000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-278522.94550000003, -5791.763, 72.3743]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-280252.22400000005, -5784.863, 72.37175]) cube([0.4, 0.4, 0.1], center=true);
    translate([-295975.476, -5722.637000000001, 72.34925000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-297739.64400000003, -5715.710000000001, 72.34670000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-313771.416, -5653.25, 72.32330000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-315569.2145, -5646.297, 72.32070000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([-331897.8155, -5583.603, 72.2973]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-333727.9085, -5576.625, 72.2947]) cube([0.4, 0.4, 0.1], center=true);
    translate([-350340.9815, -5513.715, 72.2713]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-352201.958, -5506.713000000001, 72.2687]) cube([0.4, 0.4, 0.1], center=true);
    translate([-369086.462, -5443.587, 72.2453]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-370976.8335, -5436.562, 72.24275]) cube([0.4, 0.4, 0.1], center=true);
    translate([-388119.01649999997, -5373.238, 72.22025000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-390037.217, -5366.191500000001, 72.21770000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-407422.64300000004, -5302.6785, 72.1943]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-409367.02950000006, -5295.611, 72.1917]) cube([0.4, 0.4, 0.1], center=true);
    translate([-426980.5605, -5231.909000000001, 72.1683]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-428949.41400000005, -5224.8215, 72.1657]) cube([0.4, 0.4, 0.1], center=true);
    translate([-446775.24600000004, -5160.9484999999995, 72.1423]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-448766.77450000006, -5153.842, 72.1397]) cube([0.4, 0.4, 0.1], center=true);
    translate([-466788.4555, -5089.798, 72.1163]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-468800.79099999997, -5082.673, 72.11375]) cube([0.4, 0.4, 0.1], center=true);
    translate([-487001.14900000003, -5018.467, 72.09125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-489032.347, -5011.3245, 72.0887]) cube([0.4, 0.4, 0.1], center=true);
    translate([-507393.553, -4946.9655, 72.0653]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-509441.5935, -4939.806500000001, 72.06269999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([-527945.1165, -4875.303500000001, 72.0393]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-530007.9014999999, -4868.129000000001, 72.0367]) cube([0.4, 0.4, 0.1], center=true);
    translate([-548634.5085, -4803.491, 72.0133]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-550709.8585, -4796.3015, 72.0107]) cube([0.4, 0.4, 0.1], center=true);
    translate([-569439.5515000001, -4731.5285, 71.9873]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-571525.204, -4724.324500000001, 71.98475]) cube([0.4, 0.4, 0.1], center=true);
    translate([-590337.256, -4659.4255, 71.96225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-592430.863, -4652.2075, 71.9597]) cube([0.4, 0.4, 0.1], center=true);
    translate([-611303.737, -4587.1825, 71.9363]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-613402.862, -4579.9515, 71.9337]) cube([0.4, 0.4, 0.1], center=true);
    translate([-632314.238, -4514.8185, 71.9103]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-634416.356, -4507.5755, 71.9077]) cube([0.4, 0.4, 0.1], center=true);
    translate([-653343.1039999999, -4442.3345, 71.8843]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-655445.597, -4435.08, 71.8817]) cube([0.4, 0.4, 0.1], center=true);
    translate([-674363.723, -4369.74, 71.8583]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-676463.8805, -4362.474499999999, 71.85575]) cube([0.4, 0.4, 0.1], center=true);
    translate([-695348.5895, -4297.0355, 71.83324999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-697443.6085, -4289.7595, 71.8307]) cube([0.4, 0.4, 0.1], center=true);
    translate([-716269.2415, -4224.230500000001, 71.8073]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-718356.2250000001, -4216.945000000001, 71.8047]) cube([0.4, 0.4, 0.1], center=true);
    translate([-737096.295, -4151.335, 71.7813]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-739172.2535, -4144.0405, 71.7787]) cube([0.4, 0.4, 0.1], center=true);
    translate([-757799.4365000001, -4078.3495000000003, 71.7553]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-759861.2885, -4071.047, 71.7527]) cube([0.4, 0.4, 0.1], center=true);
    translate([-778347.4415, -4005.293, 71.7293]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-780392.0165, -3997.983, 71.72675]) cube([0.4, 0.4, 0.1], center=true);
    translate([-798708.2135000001, -3932.157, 71.70425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-800732.2550000001, -3924.8395, 71.7017]) cube([0.4, 0.4, 0.1], center=true);
    translate([-818848.8050000002, -3858.9505, 71.67830000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-820848.9750000001, -3851.627, 71.6757]) cube([0.4, 0.4, 0.1], center=true);
    translate([-838735.4850000001, -3785.693, 71.6523]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-840708.3685000001, -3778.3645, 71.6497]) cube([0.4, 0.4, 0.1], center=true);
    translate([-858333.7615, -3712.3855, 71.6263]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-860275.8690000001, -3705.0525, 71.6237]) cube([0.4, 0.4, 0.1], center=true);
    translate([-877608.411, -3639.0375000000004, 71.6003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-879516.1809999999, -3631.7015, 71.59775]) cube([0.4, 0.4, 0.1], center=true);
    translate([-896523.4990000001, -3565.6685, 71.57525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-898393.2995, -3558.3305, 71.5727]) cube([0.4, 0.4, 0.1], center=true);
    translate([-915042.3905, -3492.2795000000006, 71.5493]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-916870.522, -3484.9400000000005, 71.5467]) cube([0.4, 0.4, 0.1], center=true);
    translate([-933127.798, -3418.88, 71.5233]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-934910.4924999999, -3411.5405000000005, 71.5207]) cube([0.4, 0.4, 0.1], center=true);
    translate([-950741.7175, -3345.4895000000006, 71.4973]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-952475.1344999999, -3338.1515000000004, 71.49470000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-967845.4154999999, -3272.1185, 71.47130000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-969525.6434999999, -3264.783, 71.46875]) cube([0.4, 0.4, 0.1], center=true);
    translate([-984399.4665, -3198.777, 71.44624999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-986022.575, -3191.445, 71.44369999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1000364.7050000001, -3125.475, 71.4203]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1001926.399, -3118.1485, 71.41770000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1015694.7610000002, -3052.2415, 71.39430000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1017190.4830000001, -3044.9215000000004, 71.39170000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1030345.1170000001, -2979.0685000000003, 71.3683]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1031770.6490000001, -2971.7555, 71.3657]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1044275.5910000001, -2905.9745000000003, 71.3423]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1045627.1560000001, -2898.6705, 71.33975]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1057450.384, -2832.9795, 71.31725000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1058724.1455, -2825.6859999999997, 71.31470000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1069828.6245, -2760.094, 71.2913]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1071020.689, -2752.812, 71.2887]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1081373.371, -2687.328, 71.2653]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1082480.2875, -2680.0589999999997, 71.2627]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1092052.1025, -2614.701, 71.2393]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1093070.3650000002, -2607.4460000000004, 71.2367]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1101827.2750000001, -2542.2140000000004, 71.2133]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1102753.3215, -2534.974, 71.21075]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1110665.2485, -2469.886, 71.18825]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1111495.9610000001, -2462.6625, 71.1857]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1118536.859, -2397.7275, 71.1623]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1119269.569, -2390.522, 71.1597]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1125417.451, -2325.758, 71.1363]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1126049.9945, -2318.5715, 71.1337]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1131287.8954999999, -2253.9784999999997, 71.1103]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1131818.221, -2246.8125, 71.1077]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1136126.179, -2182.4175, 71.0843]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1136552.4055, -2175.2735000000002, 71.08175]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1139916.5245, -2111.0765, 71.05925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1140237.405, -2103.956, 71.0567]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1142649.135, -2039.9840000000002, 71.0333]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1142863.9725000001, -2032.8885, 71.0307]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1144319.3175, -1969.1415, 71.0073]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1144427.8754999998, -1962.0725, 71.0047]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1144926.5745, -1898.5775, 70.9813]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1144929.0380000002, -1891.5365000000002, 70.9787]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1144474.682, -1828.2935, 70.9553]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1144371.6215, -1821.282, 70.95275]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1142970.8885000001, -1758.318, 70.93025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1142763.7265, -1751.3375, 70.9277]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1140435.5435, -1688.6525000000001, 70.9043]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1140126.721, -1681.704, 70.9017]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1136896.0990000002, -1619.3159999999998, 70.8783]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1136488.8420000002, -1612.4009999999998, 70.8757]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1132388.838, -1550.319, 70.8523]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1131887.3795, -1543.438, 70.8497]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1126961.1305, -1481.6620000000003, 70.8263]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1126370.3875, -1475.3160000000003, 70.82375]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1120663.2625, -1422.8640000000003, 70.80125]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1119988.8695, -1417.2885, 70.7987]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1113556.9205, -1369.3815, 70.7753]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1112805.72, -1364.311, 70.7727]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1105716.06, -1320.9489999999998, 70.7493]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1104896.048, -1316.3829999999998, 70.7467]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1097225.492, -1277.5570000000002, 70.7233]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1096345.7140000002, -1273.4940000000001, 70.7207]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1088180.2659999998, -1239.186, 70.6973]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1087250.714, -1235.6245, 70.69475]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1078684.226, -1205.8255000000001, 70.67225]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1077716.094, -1202.7640000000001, 70.6697]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1068856.206, -1177.456, 70.6463]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1067861.498, -1174.8925, 70.6437]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1058816.642, -1154.0575000000001, 70.6203]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1057807.7325, -1151.9905, 70.6177]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1048692.2175, -1135.6195, 70.5943]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1047681.9235, -1134.0465, 70.5917]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1038612.1465, -1122.1035000000002, 70.5683]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1037613.4815000001, -1121.022, 70.56575]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1028707.2885, -1113.498, 70.54325]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1027733.344, -1112.906, 70.5407]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1019108.5360000001, -1109.774, 70.5173]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1018172.408, -1109.6695, 70.5147]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1009946.912, -1110.9205000000002, 70.4913]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1009061.716, -1111.3005, 70.4887]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1001353.684, -1116.8895, 70.4653]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1000532.3245, -1117.751, 70.4627]) cube([0.4, 0.4, 0.1], center=true);
    translate([-993455.8855, -1127.669, 70.4393]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-992662.377, -1129.0095000000001, 70.43675]) cube([0.4, 0.4, 0.1], center=true);
    translate([-985455.6630000001, -1143.2205, 70.41425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-984654.8900000001, -1145.0369999999998, 70.4117]) cube([0.4, 0.4, 0.1], center=true);
    translate([-977447.6900000002, -1163.5230000000001, 70.3883]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-976654.2130000001, -1165.813, 70.3857]) cube([0.4, 0.4, 0.1], center=true);
    translate([-969578.827, -1188.547, 70.3623]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-968807.388, -1191.3084999999999, 70.3597]) cube([0.4, 0.4, 0.1], center=true);
    translate([-961996.872, -1218.2814999999998, 70.3363]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-961262.298, -1221.511, 70.3337]) cube([0.4, 0.4, 0.1], center=true);
    translate([-954850.482, -1252.669, 70.3103]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-954167.6875, -1256.363, 70.30775]) cube([0.4, 0.4, 0.1], center=true);
    translate([-948289.2025, -1291.6970000000001, 70.28525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-947673.1880000001, -1295.8525000000002, 70.2827]) cube([0.4, 0.4, 0.1], center=true);
    translate([-942463.412, -1335.3175, 70.2593]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-941929.263, -1339.9305, 70.2567]) cube([0.4, 0.4, 0.1], center=true);
    translate([-937524.357, -1383.4995000000001, 70.2333]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-937087.244, -1388.5670000000002, 70.2307]) cube([0.4, 0.4, 0.1], center=true);
    translate([-933624.1159999999, -1436.213, 70.2073]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-933299.2914999999, -1441.7314999999999, 70.2047]) cube([0.4, 0.4, 0.1], center=true);
    translate([-930915.5785000001, -1493.4185, 70.18130000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-930718.376, -1499.384, 70.17875000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-929552.444, -1555.076, 70.15625]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-929498.2765, -1561.4850000000001, 70.1537]) cube([0.4, 0.4, 0.1], center=true);
    translate([-929689.1935, -1621.1550000000002, 70.1303]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-929793.5545000001, -1628.0040000000001, 70.1277]) cube([0.4, 0.4, 0.1], center=true);
    translate([-931481.1355000001, -1691.6160000000002, 70.1043]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-931759.5995, -1698.9010000000003, 70.1017]) cube([0.4, 0.4, 0.1], center=true);
    translate([-935084.3705, -1766.419, 70.0783]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-935552.5900000001, -1774.1355, 70.0757]) cube([0.4, 0.4, 0.1], center=true);
    translate([-940655.77, -1845.5145000000002, 70.0523]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-941329.4255000001, -1853.659, 70.04975]) cube([0.4, 0.4, 0.1], center=true);
    translate([-948352.0445000001, -1928.8809999999999, 70.02725]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-949246.746, -1937.4495, 70.0247]) cube([0.4, 0.4, 0.1], center=true);
    translate([-958328.7540000001, -2016.4605, 70.0013]) cube([0.4, 0.4, 0.1], center=true);
}

