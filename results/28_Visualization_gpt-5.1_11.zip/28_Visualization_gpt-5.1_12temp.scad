
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.3]);

translate([2, 0, 0]) cube([1, 1, 4.1]);

translate([3, 0, 0]) cube([1, 1, 3.9]);

translate([4, 0, 0]) cube([1, 1, 3.9]);

translate([5, 0, 0]) cube([1, 1, 4.2]);

translate([6, 0, 0]) cube([1, 1, 4.5]);

translate([7, 0, 0]) cube([1, 1, 4.3]);

translate([8, 0, 0]) cube([1, 1, 4.2]);

translate([9, 0, 0]) cube([1, 1, 4.6]);

translate([10, 0, 0]) cube([1, 1, 5.0]);

translate([11, 0, 0]) cube([1, 1, 5.3]);

translate([12, 0, 0]) cube([1, 1, 5.4]);

translate([13, 0, 0]) cube([1, 1, 5.3]);

translate([14, 0, 0]) cube([1, 1, 4.8]);

translate([15, 0, 0]) cube([1, 1, 4.4]);

translate([16, 0, 0]) cube([1, 1, 4.3]);

translate([17, 0, 0]) cube([1, 1, 4.3]);

translate([18, 0, 0]) cube([1, 1, 4.6]);

translate([19, 0, 0]) cube([1, 1, 4.7]);

translate([0, 1, 0]) cube([1, 1, 6.2]);

translate([1, 1, 0]) cube([1, 1, 5.3]);

translate([2, 1, 0]) cube([1, 1, 4.8]);

translate([3, 1, 0]) cube([1, 1, 4.3]);

translate([4, 1, 0]) cube([1, 1, 4.2]);

translate([5, 1, 0]) cube([1, 1, 4.2]);

translate([6, 1, 0]) cube([1, 1, 4.1]);

translate([7, 1, 0]) cube([1, 1, 3.8]);

translate([8, 1, 0]) cube([1, 1, 3.8]);

translate([9, 1, 0]) cube([1, 1, 4.0]);

translate([10, 1, 0]) cube([1, 1, 4.3]);

translate([11, 1, 0]) cube([1, 1, 4.5]);

translate([12, 1, 0]) cube([1, 1, 4.6]);

translate([13, 1, 0]) cube([1, 1, 4.5]);

translate([14, 1, 0]) cube([1, 1, 4.3]);

translate([15, 1, 0]) cube([1, 1, 4.1]);

translate([16, 1, 0]) cube([1, 1, 3.8]);

translate([17, 1, 0]) cube([1, 1, 3.5]);

translate([18, 1, 0]) cube([1, 1, 3.8]);

translate([19, 1, 0]) cube([1, 1, 4.0]);

translate([0, 2, 0]) cube([1, 1, 7.0]);

translate([1, 2, 0]) cube([1, 1, 6.1]);

translate([2, 2, 0]) cube([1, 1, 5.7]);

translate([3, 2, 0]) cube([1, 1, 5.2]);

translate([4, 2, 0]) cube([1, 1, 5.1]);

translate([5, 2, 0]) cube([1, 1, 4.8]);

translate([6, 2, 0]) cube([1, 1, 4.2]);

translate([7, 2, 0]) cube([1, 1, 4.1]);

translate([8, 2, 0]) cube([1, 1, 4.4]);

translate([9, 2, 0]) cube([1, 1, 4.3]);

translate([10, 2, 0]) cube([1, 1, 4.4]);

translate([11, 2, 0]) cube([1, 1, 4.4]);

translate([12, 2, 0]) cube([1, 1, 4.2]);

translate([13, 2, 0]) cube([1, 1, 4.1]);

translate([14, 2, 0]) cube([1, 1, 3.7]);

translate([15, 2, 0]) cube([1, 1, 3.6]);

translate([16, 2, 0]) cube([1, 1, 3.5]);

translate([17, 2, 0]) cube([1, 1, 3.3]);

translate([18, 2, 0]) cube([1, 1, 3.5]);

translate([19, 2, 0]) cube([1, 1, 3.7]);

translate([0, 3, 0]) cube([1, 1, 7.4]);

translate([1, 3, 0]) cube([1, 1, 6.6]);

translate([2, 3, 0]) cube([1, 1, 6.3]);

translate([3, 3, 0]) cube([1, 1, 5.8]);

translate([4, 3, 0]) cube([1, 1, 5.6]);

translate([5, 3, 0]) cube([1, 1, 5.2]);

translate([6, 3, 0]) cube([1, 1, 4.7]);

translate([7, 3, 0]) cube([1, 1, 4.8]);

translate([8, 3, 0]) cube([1, 1, 5.2]);

translate([9, 3, 0]) cube([1, 1, 5.1]);

translate([10, 3, 0]) cube([1, 1, 5.0]);

translate([11, 3, 0]) cube([1, 1, 4.7]);

translate([12, 3, 0]) cube([1, 1, 4.0]);

translate([13, 3, 0]) cube([1, 1, 3.8]);

translate([14, 3, 0]) cube([1, 1, 3.4]);

translate([15, 3, 0]) cube([1, 1, 3.4]);

translate([16, 3, 0]) cube([1, 1, 3.5]);

translate([17, 3, 0]) cube([1, 1, 3.3]);

translate([18, 3, 0]) cube([1, 1, 3.4]);

translate([19, 3, 0]) cube([1, 1, 3.6]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.2]);

translate([2, 4, 0]) cube([1, 1, 6.9]);

translate([3, 4, 0]) cube([1, 1, 6.4]);

translate([4, 4, 0]) cube([1, 1, 6.1]);

translate([5, 4, 0]) cube([1, 1, 5.7]);

translate([6, 4, 0]) cube([1, 1, 5.3]);

translate([7, 4, 0]) cube([1, 1, 5.4]);

translate([8, 4, 0]) cube([1, 1, 5.8]);

translate([9, 4, 0]) cube([1, 1, 5.9]);

translate([10, 4, 0]) cube([1, 1, 5.3]);

translate([11, 4, 0]) cube([1, 1, 4.7]);

translate([12, 4, 0]) cube([1, 1, 4.0]);

translate([13, 4, 0]) cube([1, 1, 3.6]);

translate([14, 4, 0]) cube([1, 1, 3.6]);

translate([15, 4, 0]) cube([1, 1, 3.7]);

translate([16, 4, 0]) cube([1, 1, 3.9]);

translate([17, 4, 0]) cube([1, 1, 4.1]);

translate([18, 4, 0]) cube([1, 1, 4.0]);

translate([19, 4, 0]) cube([1, 1, 3.9]);

translate([0, 5, 0]) cube([1, 1, 7.9]);

translate([1, 5, 0]) cube([1, 1, 7.4]);

translate([2, 5, 0]) cube([1, 1, 7.0]);

translate([3, 5, 0]) cube([1, 1, 6.6]);

translate([4, 5, 0]) cube([1, 1, 6.5]);

translate([5, 5, 0]) cube([1, 1, 6.2]);

translate([6, 5, 0]) cube([1, 1, 5.8]);

translate([7, 5, 0]) cube([1, 1, 5.8]);

translate([8, 5, 0]) cube([1, 1, 6.1]);

translate([9, 5, 0]) cube([1, 1, 6.2]);

translate([10, 5, 0]) cube([1, 1, 5.4]);

translate([11, 5, 0]) cube([1, 1, 4.8]);

translate([12, 5, 0]) cube([1, 1, 4.4]);

translate([13, 5, 0]) cube([1, 1, 4.0]);

translate([14, 5, 0]) cube([1, 1, 4.4]);

translate([15, 5, 0]) cube([1, 1, 4.6]);

translate([16, 5, 0]) cube([1, 1, 4.6]);

translate([17, 5, 0]) cube([1, 1, 4.7]);

translate([18, 5, 0]) cube([1, 1, 4.5]);

translate([19, 5, 0]) cube([1, 1, 4.5]);

translate([0, 6, 0]) cube([1, 1, 7.9]);

translate([1, 6, 0]) cube([1, 1, 7.2]);

translate([2, 6, 0]) cube([1, 1, 6.7]);

translate([3, 6, 0]) cube([1, 1, 6.5]);

translate([4, 6, 0]) cube([1, 1, 6.8]);

translate([5, 6, 0]) cube([1, 1, 6.6]);

translate([6, 6, 0]) cube([1, 1, 6.1]);

translate([7, 6, 0]) cube([1, 1, 5.9]);

translate([8, 6, 0]) cube([1, 1, 6.1]);

translate([9, 6, 0]) cube([1, 1, 6.2]);

translate([10, 6, 0]) cube([1, 1, 5.5]);

translate([11, 6, 0]) cube([1, 1, 5.0]);

translate([12, 6, 0]) cube([1, 1, 4.8]);

translate([13, 6, 0]) cube([1, 1, 4.6]);

translate([14, 6, 0]) cube([1, 1, 5.1]);

translate([15, 6, 0]) cube([1, 1, 5.4]);

translate([16, 6, 0]) cube([1, 1, 5.3]);

translate([17, 6, 0]) cube([1, 1, 5.1]);

translate([18, 6, 0]) cube([1, 1, 4.9]);

translate([19, 6, 0]) cube([1, 1, 5.2]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.4]);

translate([2, 7, 0]) cube([1, 1, 6.9]);

translate([3, 7, 0]) cube([1, 1, 7.1]);

translate([4, 7, 0]) cube([1, 1, 7.2]);

translate([5, 7, 0]) cube([1, 1, 6.8]);

translate([6, 7, 0]) cube([1, 1, 6.4]);

translate([7, 7, 0]) cube([1, 1, 6.3]);

translate([8, 7, 0]) cube([1, 1, 6.0]);

translate([9, 7, 0]) cube([1, 1, 6.0]);

translate([10, 7, 0]) cube([1, 1, 5.6]);

translate([11, 7, 0]) cube([1, 1, 5.0]);

translate([12, 7, 0]) cube([1, 1, 4.9]);

translate([13, 7, 0]) cube([1, 1, 4.8]);

translate([14, 7, 0]) cube([1, 1, 5.4]);

translate([15, 7, 0]) cube([1, 1, 5.8]);

translate([16, 7, 0]) cube([1, 1, 5.8]);

translate([17, 7, 0]) cube([1, 1, 5.9]);

translate([18, 7, 0]) cube([1, 1, 5.7]);

translate([19, 7, 0]) cube([1, 1, 5.7]);

translate([0, 8, 0]) cube([1, 1, 8.1]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 7.4]);

translate([3, 8, 0]) cube([1, 1, 7.6]);

translate([4, 8, 0]) cube([1, 1, 7.5]);

translate([5, 8, 0]) cube([1, 1, 7.0]);

translate([6, 8, 0]) cube([1, 1, 6.8]);

translate([7, 8, 0]) cube([1, 1, 6.7]);

translate([8, 8, 0]) cube([1, 1, 6.4]);

translate([9, 8, 0]) cube([1, 1, 6.2]);

translate([10, 8, 0]) cube([1, 1, 5.8]);

translate([11, 8, 0]) cube([1, 1, 5.3]);

translate([12, 8, 0]) cube([1, 1, 5.2]);

translate([13, 8, 0]) cube([1, 1, 5.1]);

translate([14, 8, 0]) cube([1, 1, 5.6]);

translate([15, 8, 0]) cube([1, 1, 5.8]);

translate([16, 8, 0]) cube([1, 1, 6.1]);

translate([17, 8, 0]) cube([1, 1, 6.6]);

translate([18, 8, 0]) cube([1, 1, 6.5]);

translate([19, 8, 0]) cube([1, 1, 6.0]);

translate([0, 9, 0]) cube([1, 1, 8.1]);

translate([1, 9, 0]) cube([1, 1, 7.8]);

translate([2, 9, 0]) cube([1, 1, 7.6]);

translate([3, 9, 0]) cube([1, 1, 7.4]);

translate([4, 9, 0]) cube([1, 1, 7.1]);

translate([5, 9, 0]) cube([1, 1, 7.0]);

translate([6, 9, 0]) cube([1, 1, 7.0]);

translate([7, 9, 0]) cube([1, 1, 6.7]);

translate([8, 9, 0]) cube([1, 1, 6.4]);

translate([9, 9, 0]) cube([1, 1, 6.5]);

translate([10, 9, 0]) cube([1, 1, 6.3]);

translate([11, 9, 0]) cube([1, 1, 5.7]);

translate([12, 9, 0]) cube([1, 1, 5.6]);

translate([13, 9, 0]) cube([1, 1, 5.7]);

translate([14, 9, 0]) cube([1, 1, 5.9]);

translate([15, 9, 0]) cube([1, 1, 6.1]);

translate([16, 9, 0]) cube([1, 1, 6.4]);

translate([17, 9, 0]) cube([1, 1, 6.9]);

translate([18, 9, 0]) cube([1, 1, 6.9]);

translate([19, 9, 0]) cube([1, 1, 6.1]);

translate([0, 10, 0]) cube([1, 1, 7.7]);

translate([1, 10, 0]) cube([1, 1, 7.3]);

translate([2, 10, 0]) cube([1, 1, 7.2]);

translate([3, 10, 0]) cube([1, 1, 6.8]);

translate([4, 10, 0]) cube([1, 1, 6.5]);

translate([5, 10, 0]) cube([1, 1, 6.6]);

translate([6, 10, 0]) cube([1, 1, 6.8]);

translate([7, 10, 0]) cube([1, 1, 6.6]);

translate([8, 10, 0]) cube([1, 1, 6.4]);

translate([9, 10, 0]) cube([1, 1, 6.6]);

translate([10, 10, 0]) cube([1, 1, 6.3]);

translate([11, 10, 0]) cube([1, 1, 5.7]);

translate([12, 10, 0]) cube([1, 1, 5.5]);

translate([13, 10, 0]) cube([1, 1, 5.6]);

translate([14, 10, 0]) cube([1, 1, 5.8]);

translate([15, 10, 0]) cube([1, 1, 6.1]);

translate([16, 10, 0]) cube([1, 1, 6.3]);

translate([17, 10, 0]) cube([1, 1, 6.6]);

translate([18, 10, 0]) cube([1, 1, 6.7]);

translate([19, 10, 0]) cube([1, 1, 6.1]);

translate([0, 11, 0]) cube([1, 1, 6.9]);

translate([1, 11, 0]) cube([1, 1, 6.7]);

translate([2, 11, 0]) cube([1, 1, 6.6]);

translate([3, 11, 0]) cube([1, 1, 6.4]);

translate([4, 11, 0]) cube([1, 1, 5.9]);

translate([5, 11, 0]) cube([1, 1, 5.9]);

translate([6, 11, 0]) cube([1, 1, 6.2]);

translate([7, 11, 0]) cube([1, 1, 6.5]);

translate([8, 11, 0]) cube([1, 1, 6.7]);

translate([9, 11, 0]) cube([1, 1, 6.8]);

translate([10, 11, 0]) cube([1, 1, 6.4]);

translate([11, 11, 0]) cube([1, 1, 5.7]);

translate([12, 11, 0]) cube([1, 1, 5.3]);

translate([13, 11, 0]) cube([1, 1, 5.2]);

translate([14, 11, 0]) cube([1, 1, 5.5]);

translate([15, 11, 0]) cube([1, 1, 5.9]);

translate([16, 11, 0]) cube([1, 1, 6.1]);

translate([17, 11, 0]) cube([1, 1, 6.2]);

translate([18, 11, 0]) cube([1, 1, 6.2]);

translate([19, 11, 0]) cube([1, 1, 6.0]);

translate([0, 12, 0]) cube([1, 1, 6.8]);

translate([1, 12, 0]) cube([1, 1, 6.5]);

translate([2, 12, 0]) cube([1, 1, 6.1]);

translate([3, 12, 0]) cube([1, 1, 5.9]);

translate([4, 12, 0]) cube([1, 1, 5.4]);

translate([5, 12, 0]) cube([1, 1, 5.4]);

translate([6, 12, 0]) cube([1, 1, 5.7]);

translate([7, 12, 0]) cube([1, 1, 6.1]);

translate([8, 12, 0]) cube([1, 1, 6.8]);

translate([9, 12, 0]) cube([1, 1, 7.1]);

translate([10, 12, 0]) cube([1, 1, 6.5]);

translate([11, 12, 0]) cube([1, 1, 6.0]);

translate([12, 12, 0]) cube([1, 1, 5.6]);

translate([13, 12, 0]) cube([1, 1, 5.2]);

translate([14, 12, 0]) cube([1, 1, 5.4]);

translate([15, 12, 0]) cube([1, 1, 5.7]);

translate([16, 12, 0]) cube([1, 1, 6.0]);

translate([17, 12, 0]) cube([1, 1, 6.1]);

translate([18, 12, 0]) cube([1, 1, 5.8]);

translate([19, 12, 0]) cube([1, 1, 5.7]);

translate([0, 13, 0]) cube([1, 1, 7.1]);

translate([1, 13, 0]) cube([1, 1, 6.6]);

translate([2, 13, 0]) cube([1, 1, 5.6]);

translate([3, 13, 0]) cube([1, 1, 5.4]);

translate([4, 13, 0]) cube([1, 1, 5.3]);

translate([5, 13, 0]) cube([1, 1, 5.6]);

translate([6, 13, 0]) cube([1, 1, 5.8]);

translate([7, 13, 0]) cube([1, 1, 6.0]);

translate([8, 13, 0]) cube([1, 1, 6.6]);

translate([9, 13, 0]) cube([1, 1, 6.8]);

translate([10, 13, 0]) cube([1, 1, 6.2]);

translate([11, 13, 0]) cube([1, 1, 5.9]);

translate([12, 13, 0]) cube([1, 1, 5.8]);

translate([13, 13, 0]) cube([1, 1, 5.5]);

translate([14, 13, 0]) cube([1, 1, 5.3]);

translate([15, 13, 0]) cube([1, 1, 5.3]);

translate([16, 13, 0]) cube([1, 1, 5.5]);

translate([17, 13, 0]) cube([1, 1, 5.8]);

translate([18, 13, 0]) cube([1, 1, 5.7]);

translate([19, 13, 0]) cube([1, 1, 5.3]);

translate([0, 14, 0]) cube([1, 1, 7.0]);

translate([1, 14, 0]) cube([1, 1, 6.5]);

translate([2, 14, 0]) cube([1, 1, 5.4]);

translate([3, 14, 0]) cube([1, 1, 5.3]);

translate([4, 14, 0]) cube([1, 1, 5.7]);

translate([5, 14, 0]) cube([1, 1, 6.0]);

translate([6, 14, 0]) cube([1, 1, 6.1]);

translate([7, 14, 0]) cube([1, 1, 6.2]);

translate([8, 14, 0]) cube([1, 1, 6.7]);

translate([9, 14, 0]) cube([1, 1, 6.8]);

translate([10, 14, 0]) cube([1, 1, 6.2]);

translate([11, 14, 0]) cube([1, 1, 5.7]);

translate([12, 14, 0]) cube([1, 1, 5.7]);

translate([13, 14, 0]) cube([1, 1, 5.6]);

translate([14, 14, 0]) cube([1, 1, 5.6]);

translate([15, 14, 0]) cube([1, 1, 5.5]);

translate([16, 14, 0]) cube([1, 1, 5.5]);

translate([17, 14, 0]) cube([1, 1, 5.7]);

translate([18, 14, 0]) cube([1, 1, 5.5]);

translate([19, 14, 0]) cube([1, 1, 5.0]);

translate([0, 15, 0]) cube([1, 1, 6.6]);

translate([1, 15, 0]) cube([1, 1, 6.2]);

translate([2, 15, 0]) cube([1, 1, 5.6]);

translate([3, 15, 0]) cube([1, 1, 5.7]);

translate([4, 15, 0]) cube([1, 1, 6.0]);

translate([5, 15, 0]) cube([1, 1, 6.1]);

translate([6, 15, 0]) cube([1, 1, 6.2]);

translate([7, 15, 0]) cube([1, 1, 6.8]);

translate([8, 15, 0]) cube([1, 1, 7.1]);

translate([9, 15, 0]) cube([1, 1, 6.9]);

translate([10, 15, 0]) cube([1, 1, 6.2]);

translate([11, 15, 0]) cube([1, 1, 5.7]);

translate([12, 15, 0]) cube([1, 1, 5.8]);

translate([13, 15, 0]) cube([1, 1, 6.0]);

translate([14, 15, 0]) cube([1, 1, 5.9]);

translate([15, 15, 0]) cube([1, 1, 5.6]);

translate([16, 15, 0]) cube([1, 1, 5.5]);

translate([17, 15, 0]) cube([1, 1, 5.4]);

translate([18, 15, 0]) cube([1, 1, 5.1]);

translate([19, 15, 0]) cube([1, 1, 4.7]);

translate([0, 16, 0]) cube([1, 1, 6.4]);

translate([1, 16, 0]) cube([1, 1, 6.2]);

translate([2, 16, 0]) cube([1, 1, 5.9]);

translate([3, 16, 0]) cube([1, 1, 6.0]);

translate([4, 16, 0]) cube([1, 1, 6.1]);

translate([5, 16, 0]) cube([1, 1, 6.2]);

translate([6, 16, 0]) cube([1, 1, 6.5]);

translate([7, 16, 0]) cube([1, 1, 7.0]);

translate([8, 16, 0]) cube([1, 1, 7.1]);

translate([9, 16, 0]) cube([1, 1, 6.5]);

translate([10, 16, 0]) cube([1, 1, 5.9]);

translate([11, 16, 0]) cube([1, 1, 5.9]);

translate([12, 16, 0]) cube([1, 1, 6.3]);

translate([13, 16, 0]) cube([1, 1, 6.4]);

translate([14, 16, 0]) cube([1, 1, 5.9]);

translate([15, 16, 0]) cube([1, 1, 5.5]);

translate([16, 16, 0]) cube([1, 1, 5.4]);

translate([17, 16, 0]) cube([1, 1, 5.4]);

translate([18, 16, 0]) cube([1, 1, 5.2]);

translate([19, 16, 0]) cube([1, 1, 4.7]);

translate([0, 17, 0]) cube([1, 1, 6.3]);

translate([1, 17, 0]) cube([1, 1, 6.1]);

translate([2, 17, 0]) cube([1, 1, 6.0]);

translate([3, 17, 0]) cube([1, 1, 5.9]);

translate([4, 17, 0]) cube([1, 1, 5.9]);

translate([5, 17, 0]) cube([1, 1, 6.3]);

translate([6, 17, 0]) cube([1, 1, 6.7]);

translate([7, 17, 0]) cube([1, 1, 6.6]);

translate([8, 17, 0]) cube([1, 1, 6.5]);

translate([9, 17, 0]) cube([1, 1, 6.0]);

translate([10, 17, 0]) cube([1, 1, 6.0]);

translate([11, 17, 0]) cube([1, 1, 6.3]);

translate([12, 17, 0]) cube([1, 1, 6.4]);

translate([13, 17, 0]) cube([1, 1, 6.2]);

translate([14, 17, 0]) cube([1, 1, 5.7]);

translate([15, 17, 0]) cube([1, 1, 5.6]);

translate([16, 17, 0]) cube([1, 1, 5.5]);

translate([17, 17, 0]) cube([1, 1, 5.5]);

translate([18, 17, 0]) cube([1, 1, 5.6]);

translate([19, 17, 0]) cube([1, 1, 5.5]);

translate([0, 18, 0]) cube([1, 1, 5.9]);

translate([1, 18, 0]) cube([1, 1, 5.8]);

translate([2, 18, 0]) cube([1, 1, 5.8]);

translate([3, 18, 0]) cube([1, 1, 5.6]);

translate([4, 18, 0]) cube([1, 1, 5.6]);

translate([5, 18, 0]) cube([1, 1, 6.0]);

translate([6, 18, 0]) cube([1, 1, 6.2]);

translate([7, 18, 0]) cube([1, 1, 6.0]);

translate([8, 18, 0]) cube([1, 1, 5.9]);

translate([9, 18, 0]) cube([1, 1, 5.8]);

translate([10, 18, 0]) cube([1, 1, 6.0]);

translate([11, 18, 0]) cube([1, 1, 6.3]);

translate([12, 18, 0]) cube([1, 1, 6.2]);

translate([13, 18, 0]) cube([1, 1, 5.8]);

translate([14, 18, 0]) cube([1, 1, 5.5]);

translate([15, 18, 0]) cube([1, 1, 5.5]);

translate([16, 18, 0]) cube([1, 1, 5.4]);

translate([17, 18, 0]) cube([1, 1, 5.3]);

translate([18, 18, 0]) cube([1, 1, 5.6]);

translate([19, 18, 0]) cube([1, 1, 5.9]);

translate([0, 19, 0]) cube([1, 1, 5.4]);

translate([1, 19, 0]) cube([1, 1, 5.3]);

translate([2, 19, 0]) cube([1, 1, 5.3]);

translate([3, 19, 0]) cube([1, 1, 5.1]);

translate([4, 19, 0]) cube([1, 1, 5.0]);

translate([5, 19, 0]) cube([1, 1, 5.3]);

translate([6, 19, 0]) cube([1, 1, 5.3]);

translate([7, 19, 0]) cube([1, 1, 5.0]);

translate([8, 19, 0]) cube([1, 1, 5.0]);

translate([9, 19, 0]) cube([1, 1, 5.4]);

translate([10, 19, 0]) cube([1, 1, 5.6]);

translate([11, 19, 0]) cube([1, 1, 5.9]);

translate([12, 19, 0]) cube([1, 1, 5.9]);

translate([13, 19, 0]) cube([1, 1, 5.6]);

translate([14, 19, 0]) cube([1, 1, 5.2]);

translate([15, 19, 0]) cube([1, 1, 5.3]);

translate([16, 19, 0]) cube([1, 1, 5.3]);

translate([17, 19, 0]) cube([1, 1, 5.4]);

translate([18, 19, 0]) cube([1, 1, 5.7]);

translate([19, 19, 0]) cube([1, 1, 5.8]);

color([1,0,0])
translate([8.15, 8.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([9.15, 8.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([8.15, 9.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([9.15, 9.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([10.15, 9.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([10.15, 8.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([7.15, 8.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([8.15, 7.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([9.15, 7.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([7.15, 9.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([7.15, 10.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([8.15, 10.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([9.15, 10.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([10.15, 10.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([11.15, 9.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([11.15, 8.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([10.15, 7.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([8.15, 6.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([9.15, 6.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([7.15, 7.15, 0]) cube([0.15, 0.15, 10]);
