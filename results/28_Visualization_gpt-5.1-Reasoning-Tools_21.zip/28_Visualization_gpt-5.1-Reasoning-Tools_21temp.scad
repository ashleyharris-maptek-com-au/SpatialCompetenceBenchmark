
translate([0, 0, 0]) cube([1, 1, 5.000000052053334]);

translate([1, 0, 0]) cube([1, 1, 4.300111071566681]);

translate([2, 0, 0]) cube([1, 1, 4.093343414030705]);

translate([3, 0, 0]) cube([1, 1, 4.093349402334392]);

translate([4, 0, 0]) cube([1, 1, 4.170462990325033]);

translate([5, 0, 0]) cube([1, 1, 4.185611478662527]);

translate([6, 0, 0]) cube([1, 1, 4.249532395384651]);

translate([7, 0, 0]) cube([1, 1, 4.5]);

translate([8, 0, 0]) cube([1, 1, 4.4]);

translate([9, 0, 0]) cube([1, 1, 4.298133347848386]);

translate([10, 0, 0]) cube([1, 1, 4.302347222222221]);

translate([11, 0, 0]) cube([1, 1, 4.706666666666667]);

translate([12, 0, 0]) cube([1, 1, 5.033333333333333]);

translate([13, 0, 0]) cube([1, 1, 4.617467424952235]);

translate([14, 0, 0]) cube([1, 1, 4.822376543209876]);

translate([15, 0, 0]) cube([1, 1, 4.729777750220459]);

translate([16, 0, 0]) cube([1, 1, 4.597975120661691]);

translate([17, 0, 0]) cube([1, 1, 4.257914630268258]);

translate([18, 0, 0]) cube([1, 1, 4.0044274218000115]);

translate([19, 0, 0]) cube([1, 1, 4.32786164021164]);

translate([20, 0, 0]) cube([1, 1, 4.30696541005291]);

translate([21, 0, 0]) cube([1, 1, 4.4]);

translate([22, 0, 0]) cube([1, 1, 4.6]);

translate([23, 0, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.200000104716191]);

translate([2, 1, 0]) cube([1, 1, 4.700221989035541]);

translate([3, 1, 0]) cube([1, 1, 4.0956618035268395]);

translate([4, 1, 0]) cube([1, 1, 4.184357136916131]);

translate([5, 1, 0]) cube([1, 1, 4.195830275418487]);

translate([6, 1, 0]) cube([1, 1, 4.2607453075862]);

translate([7, 1, 0]) cube([1, 1, 4.289765219785787]);

translate([8, 1, 0]) cube([1, 1, 4.2980222975940805]);

translate([9, 1, 0]) cube([1, 1, 4.2981479528400515]);

translate([10, 1, 0]) cube([1, 1, 4.298815188471684]);

translate([11, 1, 0]) cube([1, 1, 4.301804902463839]);

translate([12, 1, 0]) cube([1, 1, 4.512843374978188]);

translate([13, 1, 0]) cube([1, 1, 4.387912840095109]);

translate([14, 1, 0]) cube([1, 1, 4.381791886724254]);

translate([15, 1, 0]) cube([1, 1, 4.331304959658903]);

translate([16, 1, 0]) cube([1, 1, 4.239147696805971]);

translate([17, 1, 0]) cube([1, 1, 4.034567629736853]);

translate([18, 1, 0]) cube([1, 1, 4.222140938440448]);

translate([19, 1, 0]) cube([1, 1, 3.968945748767669]);

translate([20, 1, 0]) cube([1, 1, 3.70833326947274]);

translate([21, 1, 0]) cube([1, 1, 3.708334304271069]);

translate([22, 1, 0]) cube([1, 1, 4.0]);

translate([23, 1, 0]) cube([1, 1, 4.1]);

translate([0, 2, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.201109316677187]);

translate([4, 2, 0]) cube([1, 1, 4.807601651298368]);

translate([5, 2, 0]) cube([1, 1, 4.815290385056488]);

translate([6, 2, 0]) cube([1, 1, 4.641679151576102]);

translate([7, 2, 0]) cube([1, 1, 4.3251235623881]);

translate([8, 2, 0]) cube([1, 1, 4.298155303997475]);

translate([9, 2, 0]) cube([1, 1, 4.298434807298351]);

translate([10, 2, 0]) cube([1, 1, 4.300000822524056]);

translate([11, 2, 0]) cube([1, 1, 4.306618180015531]);

translate([12, 2, 0]) cube([1, 1, 4.412073228711271]);

translate([13, 2, 0]) cube([1, 1, 4.37943568124075]);

translate([14, 2, 0]) cube([1, 1, 4.479652036186243]);

translate([15, 2, 0]) cube([1, 1, 4.424495945464917]);

translate([16, 2, 0]) cube([1, 1, 4.248247416814508]);

translate([17, 2, 0]) cube([1, 1, 4.018799254754019]);

translate([18, 2, 0]) cube([1, 1, 3.854138487800527]);

translate([19, 2, 0]) cube([1, 1, 3.731543433486787]);

translate([20, 2, 0]) cube([1, 1, 3.7083450845877937]);

translate([21, 2, 0]) cube([1, 1, 3.7083410515446484]);

translate([22, 2, 0]) cube([1, 1, 3.708376967892341]);

translate([23, 2, 0]) cube([1, 1, 3.7085975947432037]);

translate([0, 3, 0]) cube([1, 1, 7.2]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

translate([4, 3, 0]) cube([1, 1, 5.405543436761844]);

translate([5, 3, 0]) cube([1, 1, 5.408496149063263]);

translate([6, 3, 0]) cube([1, 1, 5.077667429957636]);

translate([7, 3, 0]) cube([1, 1, 4.705812856195057]);

translate([8, 3, 0]) cube([1, 1, 4.7004583763035495]);

translate([9, 3, 0]) cube([1, 1, 4.738433059538887]);

translate([10, 3, 0]) cube([1, 1, 4.86044396989948]);

translate([11, 3, 0]) cube([1, 1, 4.773379446564585]);

translate([12, 3, 0]) cube([1, 1, 4.768649423748164]);

translate([13, 3, 0]) cube([1, 1, 4.371633318843253]);

translate([14, 3, 0]) cube([1, 1, 4.372202599393995]);

translate([15, 3, 0]) cube([1, 1, 4.1971504358535165]);

translate([16, 3, 0]) cube([1, 1, 4.002358842805699]);

translate([17, 3, 0]) cube([1, 1, 3.8586928009472143]);

translate([18, 3, 0]) cube([1, 1, 3.828296510442434]);

translate([19, 3, 0]) cube([1, 1, 3.7404024106170035]);

translate([20, 3, 0]) cube([1, 1, 3.709109943115524]);

translate([21, 3, 0]) cube([1, 1, 3.708642394121255]);

translate([22, 3, 0]) cube([1, 1, 3.7085923470895716]);

translate([23, 3, 0]) cube([1, 1, 3.708801889640674]);

translate([0, 4, 0]) cube([1, 1, 7.5]);

translate([1, 4, 0]) cube([1, 1, 6.9]);

translate([2, 4, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.372163066148359]);

translate([7, 4, 0]) cube([1, 1, 5.260736339416505]);

translate([8, 4, 0]) cube([1, 1, 5.265500180300132]);

translate([9, 4, 0]) cube([1, 1, 5.385477289469153]);

color([0,1,0])
translate([10, 4, 0]) cube([1, 1, 6]);

translate([11, 4, 0]) cube([1, 1, 5.496442671828654]);

translate([12, 4, 0]) cube([1, 1, 5.312736835682739]);

translate([13, 4, 0]) cube([1, 1, 4.877218078548793]);

translate([14, 4, 0]) cube([1, 1, 4.364003761589724]);

translate([15, 4, 0]) cube([1, 1, 4.058719586587815]);

translate([16, 4, 0]) cube([1, 1, 3.9687761101269112]);

translate([17, 4, 0]) cube([1, 1, 3.8640273868357693]);

translate([18, 4, 0]) cube([1, 1, 3.834487145074881]);

translate([19, 4, 0]) cube([1, 1, 3.7618883242620256]);

translate([20, 4, 0]) cube([1, 1, 3.710452021196126]);

translate([21, 4, 0]) cube([1, 1, 3.7098816541632633]);

translate([22, 4, 0]) cube([1, 1, 3.711493928917448]);

translate([23, 4, 0]) cube([1, 1, 3.7433141021982603]);

translate([0, 5, 0]) cube([1, 1, 7.9]);

translate([1, 5, 0]) cube([1, 1, 7.4]);

translate([2, 5, 0]) cube([1, 1, 7.1]);

translate([3, 5, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

translate([6, 5, 0]) cube([1, 1, 5.419134516694294]);

translate([7, 5, 0]) cube([1, 1, 5.345273803667409]);

translate([8, 5, 0]) cube([1, 1, 5.38921617736709]);

translate([9, 5, 0]) cube([1, 1, 5.4478182252740925]);

translate([10, 5, 0]) cube([1, 1, 5.499237656443182]);

color([0,1,0])
translate([11, 5, 0]) cube([1, 1, 6]);

translate([12, 5, 0]) cube([1, 1, 5.095603655606824]);

translate([13, 5, 0]) cube([1, 1, 4.96896056680774]);

translate([14, 5, 0]) cube([1, 1, 4.389832905569862]);

translate([15, 5, 0]) cube([1, 1, 4.105329053381855]);

translate([16, 5, 0]) cube([1, 1, 3.9717711866820125]);

translate([17, 5, 0]) cube([1, 1, 3.9659906139588506]);

translate([18, 5, 0]) cube([1, 1, 3.970526071051778]);

translate([19, 5, 0]) cube([1, 1, 4.071255915647921]);

translate([20, 5, 0]) cube([1, 1, 4.2710416542797365]);

translate([21, 5, 0]) cube([1, 1, 4.273349689608743]);

translate([22, 5, 0]) cube([1, 1, 4.181968017349437]);

translate([23, 5, 0]) cube([1, 1, 3.9912883941421886]);

translate([0, 6, 0]) cube([1, 1, 7.9]);

translate([1, 6, 0]) cube([1, 1, 7.4]);

translate([2, 6, 0]) cube([1, 1, 7.1]);

translate([3, 6, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([4, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

translate([7, 6, 0]) cube([1, 1, 5.476558786646077]);

translate([8, 6, 0]) cube([1, 1, 5.442214231762371]);

color([0,1,0])
translate([9, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 6, 0]) cube([1, 1, 6]);

translate([12, 6, 0]) cube([1, 1, 5.1177175776675226]);

translate([13, 6, 0]) cube([1, 1, 5.104752192156414]);

translate([14, 6, 0]) cube([1, 1, 4.790936135699147]);

translate([15, 6, 0]) cube([1, 1, 4.3987983866305065]);

translate([16, 6, 0]) cube([1, 1, 4.347644151982351]);

translate([17, 6, 0]) cube([1, 1, 4.494049978258097]);

translate([18, 6, 0]) cube([1, 1, 4.6675233127062805]);

translate([19, 6, 0]) cube([1, 1, 4.719801162866205]);

translate([20, 6, 0]) cube([1, 1, 4.797913450741918]);

translate([21, 6, 0]) cube([1, 1, 4.744593231526539]);

translate([22, 6, 0]) cube([1, 1, 4.6171421950717955]);

translate([23, 6, 0]) cube([1, 1, 4.474754974046957]);

translate([0, 7, 0]) cube([1, 1, 7.9]);

translate([1, 7, 0]) cube([1, 1, 7.3]);

translate([2, 7, 0]) cube([1, 1, 6.9]);

translate([3, 7, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([4, 7, 0]) cube([1, 1, 6]);

translate([5, 7, 0]) cube([1, 1, 6.7]);

translate([6, 7, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

translate([12, 7, 0]) cube([1, 1, 5.231830856940574]);

translate([13, 7, 0]) cube([1, 1, 5.2028132966463]);

translate([14, 7, 0]) cube([1, 1, 5.101655555835908]);

translate([15, 7, 0]) cube([1, 1, 4.8855629391246564]);

translate([16, 7, 0]) cube([1, 1, 4.865868493958474]);

translate([17, 7, 0]) cube([1, 1, 5.169458471178391]);

translate([18, 7, 0]) cube([1, 1, 5.367399622788732]);

translate([19, 7, 0]) cube([1, 1, 5.314028904776291]);

translate([20, 7, 0]) cube([1, 1, 4.815163670949638]);

translate([21, 7, 0]) cube([1, 1, 4.733995014169303]);

translate([22, 7, 0]) cube([1, 1, 4.997593274404036]);

translate([23, 7, 0]) cube([1, 1, 5.109529456984775]);

translate([0, 8, 0]) cube([1, 1, 8.1]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 6.9]);

translate([3, 8, 0]) cube([1, 1, 6.8]);

translate([4, 8, 0]) cube([1, 1, 7.0]);

translate([5, 8, 0]) cube([1, 1, 7.1]);

translate([6, 8, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

translate([12, 8, 0]) cube([1, 1, 5.258490991187651]);

translate([13, 8, 0]) cube([1, 1, 5.050291306473579]);

translate([14, 8, 0]) cube([1, 1, 5.220256103746897]);

translate([15, 8, 0]) cube([1, 1, 5.141882607336798]);

translate([16, 8, 0]) cube([1, 1, 5.170369758597686]);

color([0,1,0])
translate([17, 8, 0]) cube([1, 1, 6]);

translate([18, 8, 0]) cube([1, 1, 5.3112923126908855]);

translate([19, 8, 0]) cube([1, 1, 5.334797628125829]);

translate([20, 8, 0]) cube([1, 1, 5.289988422240997]);

translate([21, 8, 0]) cube([1, 1, 5.152714898774513]);

color([0,1,0])
translate([22, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 8.2]);

translate([1, 9, 0]) cube([1, 1, 7.6]);

translate([2, 9, 0]) cube([1, 1, 7.2]);

translate([3, 9, 0]) cube([1, 1, 7.3]);

translate([4, 9, 0]) cube([1, 1, 7.5]);

translate([5, 9, 0]) cube([1, 1, 7.4]);

translate([6, 9, 0]) cube([1, 1, 6.9]);

translate([7, 9, 0]) cube([1, 1, 6.6]);

translate([8, 9, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

translate([12, 9, 0]) cube([1, 1, 5.28617457199499]);

translate([13, 9, 0]) cube([1, 1, 5.244441052662432]);

translate([14, 9, 0]) cube([1, 1, 5.050557044194448]);

translate([15, 9, 0]) cube([1, 1, 5.3343339968862065]);

translate([16, 9, 0]) cube([1, 1, 5.3572365482329305]);

translate([17, 9, 0]) cube([1, 1, 5.314620830816383]);

color([0,1,0])
translate([18, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 8.1]);

translate([1, 10, 0]) cube([1, 1, 7.7]);

translate([2, 10, 0]) cube([1, 1, 7.5]);

translate([3, 10, 0]) cube([1, 1, 7.6]);

translate([4, 10, 0]) cube([1, 1, 7.6]);

translate([5, 10, 0]) cube([1, 1, 7.4]);

translate([6, 10, 0]) cube([1, 1, 7.0]);

translate([7, 10, 0]) cube([1, 1, 6.9]);

translate([8, 10, 0]) cube([1, 1, 6.9]);

translate([9, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

translate([13, 10, 0]) cube([1, 1, 5.37642116064351]);

translate([14, 10, 0]) cube([1, 1, 5.3584428163150175]);

translate([15, 10, 0]) cube([1, 1, 5.360527129777864]);

translate([16, 10, 0]) cube([1, 1, 5.3660212281313955]);

color([0,1,0])
translate([17, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 10, 0]) cube([1, 1, 6]);

translate([21, 10, 0]) cube([1, 1, 6.8]);

translate([22, 10, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 8.1]);

translate([1, 11, 0]) cube([1, 1, 7.8]);

translate([2, 11, 0]) cube([1, 1, 7.6]);

translate([3, 11, 0]) cube([1, 1, 7.4]);

translate([4, 11, 0]) cube([1, 1, 7.2]);

translate([5, 11, 0]) cube([1, 1, 7.0]);

translate([6, 11, 0]) cube([1, 1, 7.0]);

translate([7, 11, 0]) cube([1, 1, 7.0]);

translate([8, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

translate([13, 11, 0]) cube([1, 1, 5.383428720704858]);

translate([14, 11, 0]) cube([1, 1, 5.369695977119131]);

translate([15, 11, 0]) cube([1, 1, 5.367656169486369]);

translate([16, 11, 0]) cube([1, 1, 5.375308816272697]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

translate([20, 11, 0]) cube([1, 1, 6.7]);

translate([21, 11, 0]) cube([1, 1, 7.0]);

translate([22, 11, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 7.7]);

translate([1, 12, 0]) cube([1, 1, 7.4]);

translate([2, 12, 0]) cube([1, 1, 7.2]);

translate([3, 12, 0]) cube([1, 1, 7.0]);

translate([4, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([5, 12, 0]) cube([1, 1, 6]);

translate([6, 12, 0]) cube([1, 1, 6.6]);

translate([7, 12, 0]) cube([1, 1, 6.8]);

translate([8, 12, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([9, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

translate([11, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

translate([14, 12, 0]) cube([1, 1, 5.277928635699427]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 12, 0]) cube([1, 1, 6]);

translate([21, 12, 0]) cube([1, 1, 6.7]);

translate([22, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 7.0]);

translate([1, 13, 0]) cube([1, 1, 6.8]);

translate([2, 13, 0]) cube([1, 1, 6.8]);

translate([3, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([4, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 13, 0]) cube([1, 1, 6]);

translate([9, 13, 0]) cube([1, 1, 6.6]);

translate([10, 13, 0]) cube([1, 1, 6.7]);

translate([11, 13, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

translate([15, 13, 0]) cube([1, 1, 5.442084742260566]);

translate([16, 13, 0]) cube([1, 1, 5.458003992239891]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([1, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 14, 0]) cube([1, 1, 6]);

translate([10, 14, 0]) cube([1, 1, 7.0]);

translate([11, 14, 0]) cube([1, 1, 7.0]);

color([0,1,0])
translate([12, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

translate([15, 14, 0]) cube([1, 1, 5.411376766394042]);

translate([16, 14, 0]) cube([1, 1, 5.4113669984254855]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 7.0]);

translate([1, 15, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 15, 0]) cube([1, 1, 6]);

translate([5, 15, 0]) cube([1, 1, 5.3]);

translate([6, 15, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([7, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 15, 0]) cube([1, 1, 6]);

translate([10, 15, 0]) cube([1, 1, 6.9]);

translate([11, 15, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([12, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

translate([16, 15, 0]) cube([1, 1, 5.411404134548447]);

translate([17, 15, 0]) cube([1, 1, 5.411357994131535]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

translate([23, 15, 0]) cube([1, 1, 5.400599745203627]);

translate([0, 16, 0]) cube([1, 1, 7.2]);

translate([1, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 16, 0]) cube([1, 1, 6]);

translate([3, 16, 0]) cube([1, 1, 5.3]);

translate([4, 16, 0]) cube([1, 1, 5.3]);

translate([5, 16, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([6, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 16, 0]) cube([1, 1, 6]);

translate([10, 16, 0]) cube([1, 1, 6.8]);

translate([11, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([12, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

translate([17, 16, 0]) cube([1, 1, 5.411409144494354]);

translate([18, 16, 0]) cube([1, 1, 5.332724173571556]);

translate([19, 16, 0]) cube([1, 1, 5.4036323896318565]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

translate([23, 16, 0]) cube([1, 1, 5.100671264068611]);

translate([0, 17, 0]) cube([1, 1, 7.0]);

translate([1, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 17, 0]) cube([1, 1, 6]);

translate([3, 17, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([4, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 17, 0]) cube([1, 1, 6]);

translate([9, 17, 0]) cube([1, 1, 6.6]);

translate([10, 17, 0]) cube([1, 1, 6.9]);

translate([11, 17, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([12, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 17, 0]) cube([1, 1, 6]);

translate([22, 17, 0]) cube([1, 1, 5.300100445620851]);

translate([23, 17, 0]) cube([1, 1, 4.900343009225232]);

translate([0, 18, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

translate([8, 18, 0]) cube([1, 1, 6.6]);

translate([9, 18, 0]) cube([1, 1, 7.0]);

translate([10, 18, 0]) cube([1, 1, 7.1]);

translate([11, 18, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([12, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

translate([20, 18, 0]) cube([1, 1, 5.400069509715337]);

translate([21, 18, 0]) cube([1, 1, 5.300088185038099]);

translate([22, 18, 0]) cube([1, 1, 4.900239123067124]);

translate([23, 18, 0]) cube([1, 1, 4.700361648688555]);

color([0,1,0])
translate([0, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 19, 0]) cube([1, 1, 6]);

translate([8, 19, 0]) cube([1, 1, 6.8]);

translate([9, 19, 0]) cube([1, 1, 7.2]);

translate([10, 19, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

translate([19, 19, 0]) cube([1, 1, 5.400077250362146]);

translate([20, 19, 0]) cube([1, 1, 5.400064610347437]);

translate([21, 19, 0]) cube([1, 1, 5.30007444445794]);

translate([22, 19, 0]) cube([1, 1, 5.000040721739345]);

translate([23, 19, 0]) cube([1, 1, 4.600641582112427]);

color([0,1,0])
translate([0, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 20, 0]) cube([1, 1, 6]);

translate([7, 20, 0]) cube([1, 1, 6.6]);

translate([8, 20, 0]) cube([1, 1, 6.8]);

translate([9, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([10, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 20, 0]) cube([1, 1, 6]);

translate([23, 20, 0]) cube([1, 1, 5.100000022246004]);

color([0,1,0])
translate([0, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

translate([20, 21, 0]) cube([1, 1, 5.4000020452605]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

translate([4, 22, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([5, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

translate([10, 22, 0]) cube([1, 1, 5.444441353718625]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

translate([17, 22, 0]) cube([1, 1, 5.400000077848554]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

translate([19, 22, 0]) cube([1, 1, 5.400000852663614]);

translate([20, 22, 0]) cube([1, 1, 5.300002135558173]);

translate([21, 22, 0]) cube([1, 1, 5.400000742982146]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

translate([0, 23, 0]) cube([1, 1, 5.3]);

translate([1, 23, 0]) cube([1, 1, 5.3]);

translate([2, 23, 0]) cube([1, 1, 5.3]);

translate([3, 23, 0]) cube([1, 1, 5.2]);

translate([4, 23, 0]) cube([1, 1, 5.017168973041931]);

translate([5, 23, 0]) cube([1, 1, 5.017168973041931]);

translate([6, 23, 0]) cube([1, 1, 5.234337946083864]);

translate([7, 23, 0]) cube([1, 1, 5.268675892167726]);

translate([8, 23, 0]) cube([1, 1, 5.328333391204009]);

translate([9, 23, 0]) cube([1, 1, 5.417300944827097]);

color([0,1,0])
translate([10, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 23, 0]) cube([1, 1, 6]);

translate([16, 23, 0]) cube([1, 1, 5.400000036790444]);

translate([17, 23, 0]) cube([1, 1, 5.200001862598282]);

translate([18, 23, 0]) cube([1, 1, 5.200001904578952]);

translate([19, 23, 0]) cube([1, 1, 5.300002099808847]);

translate([20, 23, 0]) cube([1, 1, 5.300002156455583]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);
