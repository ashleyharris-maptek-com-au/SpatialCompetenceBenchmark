translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.379999999999996]);

translate([2, 0, 0]) cube([1, 1, 4.355855662053106]);

translate([3, 0, 0]) cube([1, 1, 4.195292642545232]);

translate([4, 0, 0]) cube([1, 1, 4.228674044564647]);

translate([5, 0, 0]) cube([1, 1, 4.2924365175432815]);

translate([6, 0, 0]) cube([1, 1, 4.35065640703798]);

translate([7, 0, 0]) cube([1, 1, 4.368641783173453]);

translate([8, 0, 0]) cube([1, 1, 5.01]);

translate([9, 0, 0]) cube([1, 1, 5.31]);

translate([10, 0, 0]) cube([1, 1, 4.295949843930851]);

translate([11, 0, 0]) cube([1, 1, 4.07861284026047]);

translate([12, 0, 0]) cube([1, 1, 4.4399999999999995]);

translate([13, 0, 0]) cube([1, 1, 4.319999999999999]);

translate([14, 0, 0]) cube([1, 1, 4.4]);

translate([15, 0, 0]) cube([1, 1, 4.7]);

color([0, 1, 0]) translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.4]);

translate([2, 1, 0]) cube([1, 1, 4.819999999999999]);

translate([3, 1, 0]) cube([1, 1, 4.509999999999998]);

translate([4, 1, 0]) cube([1, 1, 4.187205867698508]);

translate([5, 1, 0]) cube([1, 1, 4.389999999999992]);

translate([6, 1, 0]) cube([1, 1, 4.279092048534462]);

translate([7, 1, 0]) cube([1, 1, 4.332982724466452]);

translate([8, 1, 0]) cube([1, 1, 3.852798480157674]);

translate([9, 1, 0]) cube([1, 1, 4.559999999999997]);

translate([10, 1, 0]) cube([1, 1, 4.529999999999998]);

translate([11, 1, 0]) cube([1, 1, 4.309999999999998]);

translate([12, 1, 0]) cube([1, 1, 4.0699999999999985]);

translate([13, 1, 0]) cube([1, 1, 3.84064269655381]);

translate([14, 1, 0]) cube([1, 1, 3.3696240847117065]);

translate([15, 1, 0]) cube([1, 1, 3.9199999999999995]);

translate([0, 2, 0]) cube([1, 1, 7.2]);

color([0, 1, 0]) translate([1, 2, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 2, 0]) cube([1, 1, 6]);

translate([3, 2, 0]) cube([1, 1, 5.4]);

translate([4, 2, 0]) cube([1, 1, 5.01]);

translate([5, 2, 0]) cube([1, 1, 4.589999999999996]);

translate([6, 2, 0]) cube([1, 1, 4.2819940174684135]);

translate([7, 2, 0]) cube([1, 1, 4.32822928595629]);

translate([8, 2, 0]) cube([1, 1, 3.853064571640615]);

translate([9, 2, 0]) cube([1, 1, 4.559999999999997]);

translate([10, 2, 0]) cube([1, 1, 4.139999999999997]);

translate([11, 2, 0]) cube([1, 1, 3.858324444044156]);

translate([12, 2, 0]) cube([1, 1, 3.8583290659899476]);

translate([13, 2, 0]) cube([1, 1, 3.8418622312179287]);

translate([14, 2, 0]) cube([1, 1, 3.836280618031181]);

translate([15, 2, 0]) cube([1, 1, 3.8350806067931806]);

translate([0, 3, 0]) cube([1, 1, 7.7]);

translate([1, 3, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([2, 3, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 3, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 3, 0]) cube([1, 1, 6]);

translate([5, 3, 0]) cube([1, 1, 5.109999999999999]);

translate([6, 3, 0]) cube([1, 1, 4.3256048611111035]);

color([0, 1, 0]) translate([7, 3, 0]) cube([1, 1, 6]);

translate([8, 3, 0]) cube([1, 1, 5.3]);

translate([9, 3, 0]) cube([1, 1, 4.599999999999998]);

translate([10, 3, 0]) cube([1, 1, 3.9099999999999957]);

translate([11, 3, 0]) cube([1, 1, 3.879999999999992]);

translate([12, 3, 0]) cube([1, 1, 3.8699999999999943]);

translate([13, 3, 0]) cube([1, 1, 3.889999999999998]);

translate([14, 3, 0]) cube([1, 1, 3.879999999999998]);

translate([15, 3, 0]) cube([1, 1, 3.8699999999999983]);

translate([0, 4, 0]) cube([1, 1, 7.9]);

translate([1, 4, 0]) cube([1, 1, 7.3]);

translate([2, 4, 0]) cube([1, 1, 6.8]);

color([0, 1, 0]) translate([3, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 4, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 4, 0]) cube([1, 1, 6]);

translate([8, 4, 0]) cube([1, 1, 5.4]);

translate([9, 4, 0]) cube([1, 1, 4.819999999999998]);

translate([10, 4, 0]) cube([1, 1, 4.269999999999996]);

translate([11, 4, 0]) cube([1, 1, 4.309999999999998]);

translate([12, 4, 0]) cube([1, 1, 4.659999999999998]);

translate([13, 4, 0]) cube([1, 1, 4.659999999999998]);

translate([14, 4, 0]) cube([1, 1, 4.659999999999998]);

translate([15, 4, 0]) cube([1, 1, 4.549999999999999]);

translate([0, 5, 0]) cube([1, 1, 8.0]);

translate([1, 5, 0]) cube([1, 1, 7.1]);

translate([2, 5, 0]) cube([1, 1, 6.6]);

translate([3, 5, 0]) cube([1, 1, 6.8]);

translate([4, 5, 0]) cube([1, 1, 6.7]);

color([0, 1, 0]) translate([5, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 5, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 5, 0]) cube([1, 1, 6]);

translate([9, 5, 0]) cube([1, 1, 5.019999999999998]);

translate([10, 5, 0]) cube([1, 1, 4.8699999999999966]);

translate([11, 5, 0]) cube([1, 1, 5.169999999999998]);

color([0, 1, 0]) translate([12, 5, 0]) cube([1, 1, 6]);

translate([13, 5, 0]) cube([1, 1, 5.459999999999999]);

translate([14, 5, 0]) cube([1, 1, 5.149999999999999]);

translate([15, 5, 0]) cube([1, 1, 5.319999999999999]);

translate([0, 6, 0]) cube([1, 1, 8.2]);

translate([1, 6, 0]) cube([1, 1, 7.3]);

translate([2, 6, 0]) cube([1, 1, 7.3]);

translate([3, 6, 0]) cube([1, 1, 7.5]);

translate([4, 6, 0]) cube([1, 1, 6.9]);

translate([5, 6, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([6, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.169999999999998]);

translate([10, 6, 0]) cube([1, 1, 5.089999999999996]);

translate([11, 6, 0]) cube([1, 1, 5.369999999999998]);

color([0, 1, 0]) translate([12, 6, 0]) cube([1, 1, 6]);

translate([13, 6, 0]) cube([1, 1, 5.123941138530241]);

color([0, 1, 0]) translate([14, 6, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 6, 0]) cube([1, 1, 6]);

translate([0, 7, 0]) cube([1, 1, 8.2]);

translate([1, 7, 0]) cube([1, 1, 7.7]);

translate([2, 7, 0]) cube([1, 1, 7.6]);

translate([3, 7, 0]) cube([1, 1, 7.4]);

translate([4, 7, 0]) cube([1, 1, 7.0]);

translate([5, 7, 0]) cube([1, 1, 7.0]);

translate([6, 7, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([7, 7, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 7, 0]) cube([1, 1, 6]);

translate([9, 7, 0]) cube([1, 1, 5.072938681640621]);

translate([10, 7, 0]) cube([1, 1, 5.068151312456209]);

color([0, 1, 0]) translate([11, 7, 0]) cube([1, 1, 6]);

translate([12, 7, 0]) cube([1, 1, 5.17406133244161]);

color([0, 1, 0]) translate([13, 7, 0]) cube([1, 1, 6]);

translate([14, 7, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([15, 7, 0]) cube([1, 1, 6]);

translate([0, 8, 0]) cube([1, 1, 7.7]);

translate([1, 8, 0]) cube([1, 1, 7.3]);

translate([2, 8, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([3, 8, 0]) cube([1, 1, 6]);

translate([4, 8, 0]) cube([1, 1, 6.6]);

translate([5, 8, 0]) cube([1, 1, 6.8]);

color([0, 1, 0]) translate([6, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 8, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 8, 0]) cube([1, 1, 6]);

translate([14, 8, 0]) cube([1, 1, 6.7]);

color([0, 1, 0]) translate([15, 8, 0]) cube([1, 1, 6]);

translate([0, 9, 0]) cube([1, 1, 6.8]);

translate([1, 9, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([2, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 9, 0]) cube([1, 1, 6]);

translate([6, 9, 0]) cube([1, 1, 6.6]);

translate([7, 9, 0]) cube([1, 1, 6.9]);

color([0, 1, 0]) translate([8, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 9, 0]) cube([1, 1, 6]);

translate([10, 9, 0]) cube([1, 1, 5.4778793533242665]);

translate([11, 9, 0]) cube([1, 1, 5.4725196112164305]);

color([0, 1, 0]) translate([12, 9, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 9, 0]) cube([1, 1, 6]);

translate([14, 9, 0]) cube([1, 1, 5.473514943521431]);

color([0, 1, 0]) translate([15, 9, 0]) cube([1, 1, 6]);

translate([0, 10, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([1, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 10, 0]) cube([1, 1, 6]);

translate([3, 10, 0]) cube([1, 1, 5.4]);

translate([4, 10, 0]) cube([1, 1, 5.4]);

color([0, 1, 0]) translate([5, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 10, 0]) cube([1, 1, 6]);

translate([7, 10, 0]) cube([1, 1, 7.0]);

color([0, 1, 0]) translate([8, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 10, 0]) cube([1, 1, 6]);

translate([11, 10, 0]) cube([1, 1, 5.480209687838619]);

color([0, 1, 0]) translate([12, 10, 0]) cube([1, 1, 6]);

translate([13, 10, 0]) cube([1, 1, 5.469502262849582]);

color([0, 1, 0]) translate([14, 10, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 10, 0]) cube([1, 1, 6]);

translate([0, 11, 0]) cube([1, 1, 7.1]);

color([0, 1, 0]) translate([1, 11, 0]) cube([1, 1, 6]);

translate([2, 11, 0]) cube([1, 1, 5.2]);

color([0, 1, 0]) translate([3, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 11, 0]) cube([1, 1, 6]);

translate([7, 11, 0]) cube([1, 1, 6.8]);

color([0, 1, 0]) translate([8, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 11, 0]) cube([1, 1, 6]);

translate([12, 11, 0]) cube([1, 1, 5.479999999999999]);

color([0, 1, 0]) translate([13, 11, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 11, 0]) cube([1, 1, 6]);

translate([15, 11, 0]) cube([1, 1, 5.239999999999999]);

translate([0, 12, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([1, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 12, 0]) cube([1, 1, 6]);

translate([6, 12, 0]) cube([1, 1, 7.0]);

translate([7, 12, 0]) cube([1, 1, 7.1]);

color([0, 1, 0]) translate([8, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 12, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 12, 0]) cube([1, 1, 6]);

translate([14, 12, 0]) cube([1, 1, 5.329999999999999]);

translate([15, 12, 0]) cube([1, 1, 5.036625571316382]);

color([0, 1, 0]) translate([0, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([1, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 13, 0]) cube([1, 1, 6]);

translate([5, 13, 0]) cube([1, 1, 6.7]);

translate([6, 13, 0]) cube([1, 1, 7.0]);

translate([7, 13, 0]) cube([1, 1, 6.6]);

color([0, 1, 0]) translate([8, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 13, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 13, 0]) cube([1, 1, 6]);

translate([13, 13, 0]) cube([1, 1, 5.41]);

translate([14, 13, 0]) cube([1, 1, 5.41]);

translate([15, 13, 0]) cube([1, 1, 5.049999999999999]);

color([0, 1, 0]) translate([0, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([1, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([2, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([3, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([4, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([5, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([6, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([7, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([8, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([11, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([12, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([13, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([14, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 14, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([0, 15, 0]) cube([1, 1, 6]);

translate([1, 15, 0]) cube([1, 1, 5.4]);

translate([2, 15, 0]) cube([1, 1, 5.3]);

translate([3, 15, 0]) cube([1, 1, 5.1]);

translate([4, 15, 0]) cube([1, 1, 5.4]);

color([0, 1, 0]) translate([5, 15, 0]) cube([1, 1, 6]);

translate([6, 15, 0]) cube([1, 1, 5.2]);

translate([7, 15, 0]) cube([1, 1, 5.4]);

color([0, 1, 0]) translate([8, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([9, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([10, 15, 0]) cube([1, 1, 6]);

translate([11, 15, 0]) cube([1, 1, 5.300642633932921]);

translate([12, 15, 0]) cube([1, 1, 5.4]);

translate([13, 15, 0]) cube([1, 1, 5.302777999381538]);

color([0, 1, 0]) translate([14, 15, 0]) cube([1, 1, 6]);

color([0, 1, 0]) translate([15, 15, 0]) cube([1, 1, 6]);
