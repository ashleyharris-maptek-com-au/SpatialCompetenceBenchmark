
translate([0, 0, 0]) cube([1, 1, 5.000000076771556]);

translate([1, 0, 0]) cube([1, 1, 4.600000451247936]);

translate([2, 0, 0]) cube([1, 1, 4.30000206417704]);

translate([3, 0, 0]) cube([1, 1, 4.2000196112858355]);

translate([4, 0, 0]) cube([1, 1, 4.200020006259974]);

translate([5, 0, 0]) cube([1, 1, 4.100063586588435]);

translate([6, 0, 0]) cube([1, 1, 4.000133145404389]);

translate([7, 0, 0]) cube([1, 1, 3.9010163115774046]);

translate([8, 0, 0]) cube([1, 1, 3.90101689635643]);

translate([9, 0, 0]) cube([1, 1, 3.9010532301632206]);

translate([10, 0, 0]) cube([1, 1, 4.000197423709103]);

translate([11, 0, 0]) cube([1, 1, 4.100120835510305]);

translate([12, 0, 0]) cube([1, 1, 4.200044590351277]);

translate([13, 0, 0]) cube([1, 1, 4.3]);

translate([14, 0, 0]) cube([1, 1, 4.5]);

translate([15, 0, 0]) cube([1, 1, 4.5]);

translate([16, 0, 0]) cube([1, 1, 4.4]);

translate([17, 0, 0]) cube([1, 1, 4.3]);

translate([18, 0, 0]) cube([1, 1, 4.2]);

translate([19, 0, 0]) cube([1, 1, 4.2]);

translate([20, 0, 0]) cube([1, 1, 4.3]);

translate([21, 0, 0]) cube([1, 1, 4.4]);

translate([22, 0, 0]) cube([1, 1, 4.7]);

translate([23, 0, 0]) cube([1, 1, 4.9]);

translate([24, 0, 0]) cube([1, 1, 5.0]);

translate([25, 0, 0]) cube([1, 1, 5.1]);

translate([26, 0, 0]) cube([1, 1, 5.2]);

translate([27, 0, 0]) cube([1, 1, 5.3]);

translate([28, 0, 0]) cube([1, 1, 5.4]);

translate([29, 0, 0]) cube([1, 1, 5.4]);

translate([30, 0, 0]) cube([1, 1, 5.4]);

translate([31, 0, 0]) cube([1, 1, 5.3]);

translate([32, 0, 0]) cube([1, 1, 5.1]);

translate([33, 0, 0]) cube([1, 1, 4.9]);

translate([34, 0, 0]) cube([1, 1, 4.7]);

translate([35, 0, 0]) cube([1, 1, 4.6]);

translate([36, 0, 0]) cube([1, 1, 4.4]);

translate([37, 0, 0]) cube([1, 1, 4.4]);

translate([38, 0, 0]) cube([1, 1, 4.3]);

translate([39, 0, 0]) cube([1, 1, 4.3]);

translate([40, 0, 0]) cube([1, 1, 4.3]);

translate([41, 0, 0]) cube([1, 1, 4.3]);

translate([42, 0, 0]) cube([1, 1, 4.4]);

translate([43, 0, 0]) cube([1, 1, 4.6]);

translate([44, 0, 0]) cube([1, 1, 4.6]);

translate([45, 0, 0]) cube([1, 1, 4.7]);

translate([46, 0, 0]) cube([1, 1, 4.8]);

translate([47, 0, 0]) cube([1, 1, 4.9]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.000000133599666]);

translate([2, 1, 0]) cube([1, 1, 4.700000667590229]);

translate([3, 1, 0]) cube([1, 1, 4.500002877377634]);

translate([4, 1, 0]) cube([1, 1, 4.400010319178216]);

translate([5, 1, 0]) cube([1, 1, 4.300030510369844]);

translate([6, 1, 0]) cube([1, 1, 4.100079070771394]);

translate([7, 1, 0]) cube([1, 1, 4.0001628033635255]);

translate([8, 1, 0]) cube([1, 1, 3.9010299316648824]);

translate([9, 1, 0]) cube([1, 1, 3.901099375450488]);

translate([10, 1, 0]) cube([1, 1, 3.9013079466559133]);

translate([11, 1, 0]) cube([1, 1, 4.000668864416077]);

translate([12, 1, 0]) cube([1, 1, 4.100438758273051]);

translate([13, 1, 0]) cube([1, 1, 4.200178366894609]);

translate([14, 1, 0]) cube([1, 1, 4.3]);

translate([15, 1, 0]) cube([1, 1, 4.3]);

translate([16, 1, 0]) cube([1, 1, 4.2]);

translate([17, 1, 0]) cube([1, 1, 4.000352959040775]);

translate([18, 1, 0]) cube([1, 1, 3.9009923883478588]);

translate([19, 1, 0]) cube([1, 1, 3.900406337177163]);

translate([20, 1, 0]) cube([1, 1, 4.000000807892284]);

translate([21, 1, 0]) cube([1, 1, 4.100004054107758]);

translate([22, 1, 0]) cube([1, 1, 4.4]);

translate([23, 1, 0]) cube([1, 1, 4.5]);

translate([24, 1, 0]) cube([1, 1, 4.7]);

translate([25, 1, 0]) cube([1, 1, 4.8]);

translate([26, 1, 0]) cube([1, 1, 4.9]);

translate([27, 1, 0]) cube([1, 1, 5.0]);

translate([28, 1, 0]) cube([1, 1, 5.0]);

translate([29, 1, 0]) cube([1, 1, 5.1]);

translate([30, 1, 0]) cube([1, 1, 5.0]);

translate([31, 1, 0]) cube([1, 1, 4.9]);

translate([32, 1, 0]) cube([1, 1, 4.8]);

translate([33, 1, 0]) cube([1, 1, 4.6]);

translate([34, 1, 0]) cube([1, 1, 4.5]);

translate([35, 1, 0]) cube([1, 1, 4.4]);

translate([36, 1, 0]) cube([1, 1, 4.3]);

translate([37, 1, 0]) cube([1, 1, 4.2]);

translate([38, 1, 0]) cube([1, 1, 4.1]);

translate([39, 1, 0]) cube([1, 1, 4.0]);

translate([40, 1, 0]) cube([1, 1, 3.9]);

translate([41, 1, 0]) cube([1, 1, 3.9]);

translate([42, 1, 0]) cube([1, 1, 4.0]);

translate([43, 1, 0]) cube([1, 1, 4.1]);

translate([44, 1, 0]) cube([1, 1, 4.2]);

translate([45, 1, 0]) cube([1, 1, 4.3]);

translate([46, 1, 0]) cube([1, 1, 4.4]);

translate([47, 1, 0]) cube([1, 1, 4.5]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

translate([2, 2, 0]) cube([1, 1, 5.2000005357638015]);

translate([3, 2, 0]) cube([1, 1, 4.900002573333535]);

translate([4, 2, 0]) cube([1, 1, 4.7000106128211785]);

translate([5, 2, 0]) cube([1, 1, 4.600035536793787]);

translate([6, 2, 0]) cube([1, 1, 4.4000960851855835]);

translate([7, 2, 0]) cube([1, 1, 4.200220498714905]);

translate([8, 2, 0]) cube([1, 1, 4.100348693073644]);

translate([9, 2, 0]) cube([1, 1, 4.0006789706322445]);

translate([10, 2, 0]) cube([1, 1, 4.100440083864585]);

translate([11, 2, 0]) cube([1, 1, 4.100606152930344]);

translate([12, 2, 0]) cube([1, 1, 4.200356180097706]);

translate([13, 2, 0]) cube([1, 1, 4.200286537947005]);

translate([14, 2, 0]) cube([1, 1, 4.20018519072859]);

translate([15, 2, 0]) cube([1, 1, 4.100655878176105]);

translate([16, 2, 0]) cube([1, 1, 4.001411847980884]);

translate([17, 2, 0]) cube([1, 1, 3.903616608568307]);

translate([18, 2, 0]) cube([1, 1, 3.8182353983654953]);

translate([19, 2, 0]) cube([1, 1, 3.818235394536996]);

translate([20, 2, 0]) cube([1, 1, 3.900462881063361]);

translate([21, 2, 0]) cube([1, 1, 3.9004893075621645]);

translate([22, 2, 0]) cube([1, 1, 4.10001622947483]);

translate([23, 2, 0]) cube([1, 1, 4.200006097224587]);

translate([24, 2, 0]) cube([1, 1, 4.400000012951389]);

translate([25, 2, 0]) cube([1, 1, 4.400000088972196]);

translate([26, 2, 0]) cube([1, 1, 4.5]);

translate([27, 2, 0]) cube([1, 1, 4.6]);

translate([28, 2, 0]) cube([1, 1, 4.7]);

translate([29, 2, 0]) cube([1, 1, 4.7]);

translate([30, 2, 0]) cube([1, 1, 4.7]);

translate([31, 2, 0]) cube([1, 1, 4.6]);

translate([32, 2, 0]) cube([1, 1, 4.5]);

translate([33, 2, 0]) cube([1, 1, 4.4]);

translate([34, 2, 0]) cube([1, 1, 4.3]);

translate([35, 2, 0]) cube([1, 1, 4.2]);

translate([36, 2, 0]) cube([1, 1, 4.1]);

translate([37, 2, 0]) cube([1, 1, 4.0]);

translate([38, 2, 0]) cube([1, 1, 3.9]);

translate([39, 2, 0]) cube([1, 1, 3.8]);

translate([40, 2, 0]) cube([1, 1, 3.6]);

translate([41, 2, 0]) cube([1, 1, 3.6]);

translate([42, 2, 0]) cube([1, 1, 3.7]);

translate([43, 2, 0]) cube([1, 1, 3.9]);

translate([44, 2, 0]) cube([1, 1, 4.0]);

translate([45, 2, 0]) cube([1, 1, 4.0]);

translate([46, 2, 0]) cube([1, 1, 4.1]);

translate([47, 2, 0]) cube([1, 1, 4.2]);

color([0,1,0])
translate([0, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

translate([3, 3, 0]) cube([1, 1, 5.400002114670198]);

translate([4, 3, 0]) cube([1, 1, 5.200009803267489]);

translate([5, 3, 0]) cube([1, 1, 5.000038577518375]);

translate([6, 3, 0]) cube([1, 1, 4.800118691789816]);

translate([7, 3, 0]) cube([1, 1, 4.60028762502793]);

translate([8, 3, 0]) cube([1, 1, 4.400600098745543]);

translate([9, 3, 0]) cube([1, 1, 4.40063524558931]);

translate([10, 3, 0]) cube([1, 1, 4.400691767797042]);

translate([11, 3, 0]) cube([1, 1, 4.400648940783951]);

translate([12, 3, 0]) cube([1, 1, 4.300796661826862]);

translate([13, 3, 0]) cube([1, 1, 4.300439323176839]);

translate([14, 3, 0]) cube([1, 1, 4.10243833579353]);

translate([15, 3, 0]) cube([1, 1, 4.006403372908914]);

translate([16, 3, 0]) cube([1, 1, 3.9163182420454006]);

translate([17, 3, 0]) cube([1, 1, 3.818339877275485]);

translate([18, 3, 0]) cube([1, 1, 3.8182357493703516]);

translate([19, 3, 0]) cube([1, 1, 3.900718049855449]);

translate([20, 3, 0]) cube([1, 1, 3.900505070159708]);

translate([21, 3, 0]) cube([1, 1, 3.9005059748715047]);

translate([22, 3, 0]) cube([1, 1, 4.0001351072744535]);

translate([23, 3, 0]) cube([1, 1, 4.100075058177544]);

translate([24, 3, 0]) cube([1, 1, 4.200024390388009]);

translate([25, 3, 0]) cube([1, 1, 4.300002709607951]);

translate([26, 3, 0]) cube([1, 1, 4.400000380932038]);

translate([27, 3, 0]) cube([1, 1, 4.40000044767041]);

translate([28, 3, 0]) cube([1, 1, 4.5]);

translate([29, 3, 0]) cube([1, 1, 4.5]);

translate([30, 3, 0]) cube([1, 1, 4.4]);

translate([31, 3, 0]) cube([1, 1, 4.300000009941211]);

translate([32, 3, 0]) cube([1, 1, 4.3]);

translate([33, 3, 0]) cube([1, 1, 4.2]);

translate([34, 3, 0]) cube([1, 1, 4.1]);

translate([35, 3, 0]) cube([1, 1, 4.0]);

translate([36, 3, 0]) cube([1, 1, 4.0]);

translate([37, 3, 0]) cube([1, 1, 3.9]);

translate([38, 3, 0]) cube([1, 1, 3.8]);

translate([39, 3, 0]) cube([1, 1, 3.6]);

translate([40, 3, 0]) cube([1, 1, 3.5000465845522033]);

translate([41, 3, 0]) cube([1, 1, 3.400137388775881]);

translate([42, 3, 0]) cube([1, 1, 3.5000002421318914]);

translate([43, 3, 0]) cube([1, 1, 3.7]);

translate([44, 3, 0]) cube([1, 1, 3.8]);

translate([45, 3, 0]) cube([1, 1, 3.9]);

translate([46, 3, 0]) cube([1, 1, 3.8]);

translate([47, 3, 0]) cube([1, 1, 3.8]);

translate([0, 4, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([1, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

translate([5, 4, 0]) cube([1, 1, 5.40003702712869]);

translate([6, 4, 0]) cube([1, 1, 5.200137923529382]);

translate([7, 4, 0]) cube([1, 1, 5.0003799328590555]);

translate([8, 4, 0]) cube([1, 1, 4.800801580732383]);

translate([9, 4, 0]) cube([1, 1, 4.800886458254598]);

translate([10, 4, 0]) cube([1, 1, 4.80083066632965]);

translate([11, 4, 0]) cube([1, 1, 4.701193044966371]);

translate([12, 4, 0]) cube([1, 1, 4.601145000041132]);

translate([13, 4, 0]) cube([1, 1, 4.400845306511384]);

translate([14, 4, 0]) cube([1, 1, 4.2079969946726115]);

translate([15, 4, 0]) cube([1, 1, 4.014344943162594]);

translate([16, 4, 0]) cube([1, 1, 3.9217356568140995]);

translate([17, 4, 0]) cube([1, 1, 4.0044774352066534]);

translate([18, 4, 0]) cube([1, 1, 4.003425004855848]);

translate([19, 4, 0]) cube([1, 1, 4.1006526612331005]);

translate([20, 4, 0]) cube([1, 1, 4.200188901721567]);

translate([21, 4, 0]) cube([1, 1, 4.100145002174826]);

translate([22, 4, 0]) cube([1, 1, 4.10012981324334]);

translate([23, 4, 0]) cube([1, 1, 4.200033125627061]);

translate([24, 4, 0]) cube([1, 1, 4.200031877327448]);

translate([25, 4, 0]) cube([1, 1, 4.3000069720087035]);

translate([26, 4, 0]) cube([1, 1, 4.400000685366142]);

translate([27, 4, 0]) cube([1, 1, 4.400000574099422]);

translate([28, 4, 0]) cube([1, 1, 4.300000843538587]);

translate([29, 4, 0]) cube([1, 1, 4.3000004342935645]);

translate([30, 4, 0]) cube([1, 1, 4.300000067195746]);

translate([31, 4, 0]) cube([1, 1, 4.200000010241708]);

translate([32, 4, 0]) cube([1, 1, 4.1000001956211225]);

translate([33, 4, 0]) cube([1, 1, 3.900001903021314]);

translate([34, 4, 0]) cube([1, 1, 3.80000037241637]);

translate([35, 4, 0]) cube([1, 1, 3.700000066696256]);

translate([36, 4, 0]) cube([1, 1, 3.700000009206325]);

translate([37, 4, 0]) cube([1, 1, 3.7]);

translate([38, 4, 0]) cube([1, 1, 3.6]);

translate([39, 4, 0]) cube([1, 1, 3.5001863456958566]);

translate([40, 4, 0]) cube([1, 1, 3.4003653451221663]);

translate([41, 4, 0]) cube([1, 1, 3.302691102647868]);

translate([42, 4, 0]) cube([1, 1, 3.4000493058371544]);

translate([43, 4, 0]) cube([1, 1, 3.600000973669034]);

translate([44, 4, 0]) cube([1, 1, 3.7]);

translate([45, 4, 0]) cube([1, 1, 3.8]);

translate([46, 4, 0]) cube([1, 1, 3.7]);

translate([47, 4, 0]) cube([1, 1, 3.6000059037868564]);

translate([0, 5, 0]) cube([1, 1, 7.0]);

translate([1, 5, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

translate([7, 5, 0]) cube([1, 1, 5.30048262840879]);

translate([8, 5, 0]) cube([1, 1, 5.2011398225392265]);

translate([9, 5, 0]) cube([1, 1, 5.2010982273717925]);

translate([10, 5, 0]) cube([1, 1, 5.101521311727802]);

translate([11, 5, 0]) cube([1, 1, 5.001425992697392]);

translate([12, 5, 0]) cube([1, 1, 4.802187267053423]);

translate([13, 5, 0]) cube([1, 1, 4.601739578384376]);

translate([14, 5, 0]) cube([1, 1, 4.313281962712068]);

translate([15, 5, 0]) cube([1, 1, 4.215706798531032]);

translate([16, 5, 0]) cube([1, 1, 4.117947838084722]);

translate([17, 5, 0]) cube([1, 1, 4.206252180541554]);

translate([18, 5, 0]) cube([1, 1, 4.302135350075281]);

translate([19, 5, 0]) cube([1, 1, 4.400711648025392]);

translate([20, 5, 0]) cube([1, 1, 4.500227414739228]);

translate([21, 5, 0]) cube([1, 1, 4.4001943559246035]);

translate([22, 5, 0]) cube([1, 1, 4.400106985572313]);

translate([23, 5, 0]) cube([1, 1, 4.400047013684225]);

translate([24, 5, 0]) cube([1, 1, 4.400023273101775]);

translate([25, 5, 0]) cube([1, 1, 4.500002417507522]);

translate([26, 5, 0]) cube([1, 1, 4.5000011413537235]);

translate([27, 5, 0]) cube([1, 1, 4.400001079438489]);

translate([28, 5, 0]) cube([1, 1, 4.300000909559833]);

translate([29, 5, 0]) cube([1, 1, 4.2000046317205415]);

translate([30, 5, 0]) cube([1, 1, 4.1000048397533515]);

translate([31, 5, 0]) cube([1, 1, 4.100000815015355]);

translate([32, 5, 0]) cube([1, 1, 3.900007448924611]);

translate([33, 5, 0]) cube([1, 1, 3.700011855371086]);

translate([34, 5, 0]) cube([1, 1, 3.600021884042941]);

translate([35, 5, 0]) cube([1, 1, 3.5001407086476823]);

translate([36, 5, 0]) cube([1, 1, 3.500540525051485]);

translate([37, 5, 0]) cube([1, 1, 3.6]);

translate([38, 5, 0]) cube([1, 1, 3.5009317368248314]);

translate([39, 5, 0]) cube([1, 1, 3.4015938036433835]);

translate([40, 5, 0]) cube([1, 1, 3.3026911091271187]);

translate([41, 5, 0]) cube([1, 1, 3.3026933615835987]);

translate([42, 5, 0]) cube([1, 1, 3.4000522058655296]);

translate([43, 5, 0]) cube([1, 1, 3.500019636467339]);

translate([44, 5, 0]) cube([1, 1, 3.6000048737368906]);

translate([45, 5, 0]) cube([1, 1, 3.7]);

translate([46, 5, 0]) cube([1, 1, 3.6000118121315454]);

translate([47, 5, 0]) cube([1, 1, 3.5001312955240356]);

translate([0, 6, 0]) cube([1, 1, 7.2]);

translate([1, 6, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([2, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

translate([8, 6, 0]) cube([1, 1, 5.4016353975742275]);

translate([9, 6, 0]) cube([1, 1, 5.401982254497467]);

translate([10, 6, 0]) cube([1, 1, 5.401807243566338]);

translate([11, 6, 0]) cube([1, 1, 5.2027188441076655]);

translate([12, 6, 0]) cube([1, 1, 5.002245389091421]);

translate([13, 6, 0]) cube([1, 1, 4.80518395043804]);

translate([14, 6, 0]) cube([1, 1, 4.522463294155207]);

translate([15, 6, 0]) cube([1, 1, 4.422895725120129]);

translate([16, 6, 0]) cube([1, 1, 4.41986802744831]);

translate([17, 6, 0]) cube([1, 1, 4.507068625814977]);

translate([18, 6, 0]) cube([1, 1, 4.60218890393302]);

translate([19, 6, 0]) cube([1, 1, 4.800707578973571]);

translate([20, 6, 0]) cube([1, 1, 4.800434349286522]);

translate([21, 6, 0]) cube([1, 1, 4.8002225669637095]);

translate([22, 6, 0]) cube([1, 1, 4.700087456359192]);

translate([23, 6, 0]) cube([1, 1, 4.7000305568062455]);

translate([24, 6, 0]) cube([1, 1, 4.700010074360029]);

translate([25, 6, 0]) cube([1, 1, 4.70000303546953]);

translate([26, 6, 0]) cube([1, 1, 4.600001404418569]);

translate([27, 6, 0]) cube([1, 1, 4.40000336287991]);

translate([28, 6, 0]) cube([1, 1, 4.200016293248812]);

translate([29, 6, 0]) cube([1, 1, 4.100014231997594]);

translate([30, 6, 0]) cube([1, 1, 4.000020028875452]);

translate([31, 6, 0]) cube([1, 1, 3.9000362469813963]);

translate([32, 6, 0]) cube([1, 1, 3.8000375209601764]);

translate([33, 6, 0]) cube([1, 1, 3.600073362213565]);

translate([34, 6, 0]) cube([1, 1, 3.401853069388414]);

translate([35, 6, 0]) cube([1, 1, 3.4040755256703936]);

translate([36, 6, 0]) cube([1, 1, 3.40667857349806]);

translate([37, 6, 0]) cube([1, 1, 3.5021620464109873]);

translate([38, 6, 0]) cube([1, 1, 3.502180235286417]);

translate([39, 6, 0]) cube([1, 1, 3.4034216680352922]);

translate([40, 6, 0]) cube([1, 1, 3.3039652851218304]);

translate([41, 6, 0]) cube([1, 1, 3.226474313518778]);

translate([42, 6, 0]) cube([1, 1, 3.303011055947862]);

translate([43, 6, 0]) cube([1, 1, 3.4002301053831934]);

translate([44, 6, 0]) cube([1, 1, 3.5000923370985926]);

translate([45, 6, 0]) cube([1, 1, 3.600024372074046]);

translate([46, 6, 0]) cube([1, 1, 3.600024372074046]);

translate([47, 6, 0]) cube([1, 1, 3.5001313050017298]);

translate([0, 7, 0]) cube([1, 1, 7.4]);

translate([1, 7, 0]) cube([1, 1, 7.0]);

translate([2, 7, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

translate([11, 7, 0]) cube([1, 1, 5.403479819244716]);

translate([12, 7, 0]) cube([1, 1, 5.206110868490148]);

translate([13, 7, 0]) cube([1, 1, 4.922109627411965]);

translate([14, 7, 0]) cube([1, 1, 4.734184104906691]);

translate([15, 7, 0]) cube([1, 1, 4.6266359197011635]);

translate([16, 7, 0]) cube([1, 1, 4.623782770562007]);

translate([17, 7, 0]) cube([1, 1, 4.806501611014322]);

translate([18, 7, 0]) cube([1, 1, 4.9028698506583215]);

translate([19, 7, 0]) cube([1, 1, 5.100865483927703]);

translate([20, 7, 0]) cube([1, 1, 5.100477471244424]);

translate([21, 7, 0]) cube([1, 1, 5.100153896167841]);

translate([22, 7, 0]) cube([1, 1, 5.000047131007849]);

translate([23, 7, 0]) cube([1, 1, 5.0000136955822985]);

translate([24, 7, 0]) cube([1, 1, 4.900004507290366]);

translate([25, 7, 0]) cube([1, 1, 4.900001618058045]);

translate([26, 7, 0]) cube([1, 1, 4.7000037925315326]);

translate([27, 7, 0]) cube([1, 1, 4.500010499598665]);

translate([28, 7, 0]) cube([1, 1, 4.200049341491017]);

translate([29, 7, 0]) cube([1, 1, 4.000055611107527]);

translate([30, 7, 0]) cube([1, 1, 3.9001555762042104]);

translate([31, 7, 0]) cube([1, 1, 3.800143116874842]);

translate([32, 7, 0]) cube([1, 1, 3.7003100087432887]);

translate([33, 7, 0]) cube([1, 1, 3.501235893256793]);

translate([34, 7, 0]) cube([1, 1, 3.4004596456226355]);

translate([35, 7, 0]) cube([1, 1, 3.400459915264958]);

translate([36, 7, 0]) cube([1, 1, 3.4113461086302506]);

translate([37, 7, 0]) cube([1, 1, 3.5053869483958042]);

translate([38, 7, 0]) cube([1, 1, 3.5066901257125034]);

translate([39, 7, 0]) cube([1, 1, 3.407917102968404]);

translate([40, 7, 0]) cube([1, 1, 3.306618094989822]);

translate([41, 7, 0]) cube([1, 1, 3.3039801984313066]);

translate([42, 7, 0]) cube([1, 1, 3.303463007572744]);

translate([43, 7, 0]) cube([1, 1, 3.4005333158300903]);

translate([44, 7, 0]) cube([1, 1, 3.500270261331304]);

translate([45, 7, 0]) cube([1, 1, 3.600069843877848]);

translate([46, 7, 0]) cube([1, 1, 3.6000593283315347]);

translate([47, 7, 0]) cube([1, 1, 3.500139608401147]);

translate([0, 8, 0]) cube([1, 1, 7.5]);

translate([1, 8, 0]) cube([1, 1, 7.2]);

translate([2, 8, 0]) cube([1, 1, 6.9]);

translate([3, 8, 0]) cube([1, 1, 6.7]);

translate([4, 8, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([5, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

translate([12, 8, 0]) cube([1, 1, 5.324177203586553]);

translate([13, 8, 0]) cube([1, 1, 5.133148282509594]);

translate([14, 8, 0]) cube([1, 1, 4.9349368614514475]);

translate([15, 8, 0]) cube([1, 1, 4.841357701663397]);

translate([16, 8, 0]) cube([1, 1, 4.917410837620707]);

translate([17, 8, 0]) cube([1, 1, 5.108515112185367]);

translate([18, 8, 0]) cube([1, 1, 5.203712257759783]);

translate([19, 8, 0]) cube([1, 1, 5.401256404894348]);

color([0,1,0])
translate([20, 8, 0]) cube([1, 1, 6]);

translate([21, 8, 0]) cube([1, 1, 5.400061931534455]);

translate([22, 8, 0]) cube([1, 1, 5.4000161931259365]);

translate([23, 8, 0]) cube([1, 1, 5.300003641702015]);

translate([24, 8, 0]) cube([1, 1, 5.2000015215864]);

translate([25, 8, 0]) cube([1, 1, 5.100003687008035]);

translate([26, 8, 0]) cube([1, 1, 4.800012663953892]);

translate([27, 8, 0]) cube([1, 1, 4.500034661736328]);

translate([28, 8, 0]) cube([1, 1, 4.200198204181979]);

translate([29, 8, 0]) cube([1, 1, 3.9006880241088693]);

translate([30, 8, 0]) cube([1, 1, 3.8005037471123972]);

translate([31, 8, 0]) cube([1, 1, 3.7013331749746317]);

translate([32, 8, 0]) cube([1, 1, 3.6057585888081283]);

translate([33, 8, 0]) cube([1, 1, 3.4433323101842164]);

translate([34, 8, 0]) cube([1, 1, 3.4004604060265002]);

translate([35, 8, 0]) cube([1, 1, 3.4004607307995767]);

translate([36, 8, 0]) cube([1, 1, 3.4303276035465173]);

translate([37, 8, 0]) cube([1, 1, 3.5192085450927366]);

translate([38, 8, 0]) cube([1, 1, 3.6101643156513745]);

translate([39, 8, 0]) cube([1, 1, 3.6078085860784492]);

translate([40, 8, 0]) cube([1, 1, 3.50386954960311]);

translate([41, 8, 0]) cube([1, 1, 3.501665384932438]);

translate([42, 8, 0]) cube([1, 1, 3.500882161359189]);

translate([43, 8, 0]) cube([1, 1, 3.500672103122826]);

translate([44, 8, 0]) cube([1, 1, 3.6002164016005165]);

translate([45, 8, 0]) cube([1, 1, 3.700098328476251]);

translate([46, 8, 0]) cube([1, 1, 3.7000773850955264]);

translate([47, 8, 0]) cube([1, 1, 3.6001035296867347]);

translate([0, 9, 0]) cube([1, 1, 7.7]);

translate([1, 9, 0]) cube([1, 1, 7.4]);

translate([2, 9, 0]) cube([1, 1, 7.1]);

translate([3, 9, 0]) cube([1, 1, 7.0]);

translate([4, 9, 0]) cube([1, 1, 6.8]);

translate([5, 9, 0]) cube([1, 1, 6.7]);

translate([6, 9, 0]) cube([1, 1, 6.500080088346058]);

color([0,1,0])
translate([7, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

translate([13, 9, 0]) cube([1, 1, 5.339021449130887]);

translate([14, 9, 0]) cube([1, 1, 5.145858444663025]);

translate([15, 9, 0]) cube([1, 1, 5.144476045725969]);

translate([16, 9, 0]) cube([1, 1, 5.22274862102977]);

translate([17, 9, 0]) cube([1, 1, 5.311314413983189]);

color([0,1,0])
translate([18, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 9, 0]) cube([1, 1, 6]);

translate([24, 9, 0]) cube([1, 1, 5.300004574254718]);

translate([25, 9, 0]) cube([1, 1, 5.100016046464542]);

translate([26, 9, 0]) cube([1, 1, 4.800041995551954]);

translate([27, 9, 0]) cube([1, 1, 4.500114874174835]);

translate([28, 9, 0]) cube([1, 1, 4.200831002657518]);

translate([29, 9, 0]) cube([1, 1, 3.9016195347850475]);

translate([30, 9, 0]) cube([1, 1, 3.705863444271494]);

translate([31, 9, 0]) cube([1, 1, 3.6270066497099105]);

translate([32, 9, 0]) cube([1, 1, 3.5507023811562104]);

translate([33, 9, 0]) cube([1, 1, 3.5393818439210767]);

translate([34, 9, 0]) cube([1, 1, 3.5326082263651872]);

translate([35, 9, 0]) cube([1, 1, 3.536129038945977]);

translate([36, 9, 0]) cube([1, 1, 3.6338913899866787]);

translate([37, 9, 0]) cube([1, 1, 3.724373680588464]);

translate([38, 9, 0]) cube([1, 1, 3.7237734056336285]);

translate([39, 9, 0]) cube([1, 1, 3.807865259301737]);

translate([40, 9, 0]) cube([1, 1, 3.9022135202264336]);

translate([41, 9, 0]) cube([1, 1, 3.9014603875645872]);

translate([42, 9, 0]) cube([1, 1, 3.800783473069629]);

translate([43, 9, 0]) cube([1, 1, 3.800501566874405]);

translate([44, 9, 0]) cube([1, 1, 3.8003048121831036]);

translate([45, 9, 0]) cube([1, 1, 3.80017730252536]);

translate([46, 9, 0]) cube([1, 1, 3.800083501321167]);

translate([47, 9, 0]) cube([1, 1, 3.700108097618751]);

translate([0, 10, 0]) cube([1, 1, 7.9]);

translate([1, 10, 0]) cube([1, 1, 7.6]);

translate([2, 10, 0]) cube([1, 1, 7.4]);

translate([3, 10, 0]) cube([1, 1, 7.2]);

translate([4, 10, 0]) cube([1, 1, 7.1]);

translate([5, 10, 0]) cube([1, 1, 6.9]);

translate([6, 10, 0]) cube([1, 1, 6.7]);

translate([7, 10, 0]) cube([1, 1, 6.500400443165491]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

translate([14, 10, 0]) cube([1, 1, 5.443354617715813]);

translate([15, 10, 0]) cube([1, 1, 5.356065671557617]);

translate([16, 10, 0]) cube([1, 1, 5.429426594096733]);

color([0,1,0])
translate([17, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

translate([24, 10, 0]) cube([1, 1, 5.400017499692704]);

translate([25, 10, 0]) cube([1, 1, 5.10005663705554]);

translate([26, 10, 0]) cube([1, 1, 4.800133628632473]);

translate([27, 10, 0]) cube([1, 1, 4.500386099411955]);

translate([28, 10, 0]) cube([1, 1, 4.203619391562536]);

translate([29, 10, 0]) cube([1, 1, 4.003447494269692]);

translate([30, 10, 0]) cube([1, 1, 3.8171949865405113]);

translate([31, 10, 0]) cube([1, 1, 3.6352889724672774]);

translate([32, 10, 0]) cube([1, 1, 3.628569928733902]);

translate([33, 10, 0]) cube([1, 1, 3.6279753708322136]);

translate([34, 10, 0]) cube([1, 1, 3.7348284216059744]);

translate([35, 10, 0]) cube([1, 1, 3.846317059251844]);

translate([36, 10, 0]) cube([1, 1, 3.9472766842521523]);

translate([37, 10, 0]) cube([1, 1, 3.9514895486552466]);

translate([38, 10, 0]) cube([1, 1, 4.024996289937066]);

translate([39, 10, 0]) cube([1, 1, 4.108848448518924]);

translate([40, 10, 0]) cube([1, 1, 4.203268037826265]);

translate([41, 10, 0]) cube([1, 1, 4.301053527141155]);

translate([42, 10, 0]) cube([1, 1, 4.2008779639973985]);

translate([43, 10, 0]) cube([1, 1, 4.100525488366813]);

translate([44, 10, 0]) cube([1, 1, 4.1003209106430765]);

translate([45, 10, 0]) cube([1, 1, 4.000176096002676]);

translate([46, 10, 0]) cube([1, 1, 3.90008469579297]);

translate([47, 10, 0]) cube([1, 1, 3.8001001525857463]);

translate([0, 11, 0]) cube([1, 1, 8.0]);

translate([1, 11, 0]) cube([1, 1, 7.7]);

translate([2, 11, 0]) cube([1, 1, 7.5]);

translate([3, 11, 0]) cube([1, 1, 7.3]);

translate([4, 11, 0]) cube([1, 1, 7.2]);

translate([5, 11, 0]) cube([1, 1, 7.0]);

translate([6, 11, 0]) cube([1, 1, 6.8]);

translate([7, 11, 0]) cube([1, 1, 6.7]);

translate([8, 11, 0]) cube([1, 1, 6.502002216123562]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

translate([24, 11, 0]) cube([1, 1, 5.400071341888368]);

translate([25, 11, 0]) cube([1, 1, 5.100189805368536]);

translate([26, 11, 0]) cube([1, 1, 4.800405673624934]);

translate([27, 11, 0]) cube([1, 1, 4.6013492136843634]);

translate([28, 11, 0]) cube([1, 1, 4.407573024475959]);

translate([29, 11, 0]) cube([1, 1, 4.205214058553064]);

translate([30, 11, 0]) cube([1, 1, 3.9251857263892522]);

translate([31, 11, 0]) cube([1, 1, 3.8333131365218707]);

translate([32, 11, 0]) cube([1, 1, 3.831412500377903]);

translate([33, 11, 0]) cube([1, 1, 3.9239541606462356]);

translate([34, 11, 0]) cube([1, 1, 4.132469181696994]);

translate([35, 11, 0]) cube([1, 1, 4.271401730770435]);

translate([36, 11, 0]) cube([1, 1, 4.280437718527325]);

translate([37, 11, 0]) cube([1, 1, 4.278723458646205]);

translate([38, 11, 0]) cube([1, 1, 4.327621275365625]);

translate([39, 11, 0]) cube([1, 1, 4.409788270472001]);

translate([40, 11, 0]) cube([1, 1, 4.503564659716848]);

translate([41, 11, 0]) cube([1, 1, 4.501933732570364]);

translate([42, 11, 0]) cube([1, 1, 4.500822773254406]);

translate([43, 11, 0]) cube([1, 1, 4.400579789828541]);

translate([44, 11, 0]) cube([1, 1, 4.30034691619156]);

translate([45, 11, 0]) cube([1, 1, 4.200152359532197]);

translate([46, 11, 0]) cube([1, 1, 4.100060295656345]);

translate([47, 11, 0]) cube([1, 1, 4.000034728668521]);

translate([0, 12, 0]) cube([1, 1, 7.9]);

translate([1, 12, 0]) cube([1, 1, 7.6]);

translate([2, 12, 0]) cube([1, 1, 7.4]);

translate([3, 12, 0]) cube([1, 1, 7.3]);

translate([4, 12, 0]) cube([1, 1, 7.1]);

translate([5, 12, 0]) cube([1, 1, 7.0]);

translate([6, 12, 0]) cube([1, 1, 6.8]);

translate([7, 12, 0]) cube([1, 1, 6.600000815334116]);

translate([8, 12, 0]) cube([1, 1, 6.50485338210948]);

translate([9, 12, 0]) cube([1, 1, 6.505802281406595]);

translate([10, 12, 0]) cube([1, 1, 6.511746586246743]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

translate([12, 12, 0]) cube([1, 1, 5.041351010327902]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

translate([24, 12, 0]) cube([1, 1, 5.400280100887725]);

translate([25, 12, 0]) cube([1, 1, 5.100580313223824]);

translate([26, 12, 0]) cube([1, 1, 4.901201627698703]);

translate([27, 12, 0]) cube([1, 1, 4.70500515203962]);

translate([28, 12, 0]) cube([1, 1, 4.5095869656814385]);

translate([29, 12, 0]) cube([1, 1, 4.413964674962045]);

translate([30, 12, 0]) cube([1, 1, 4.130350257550347]);

translate([31, 12, 0]) cube([1, 1, 4.047766425821119]);

translate([32, 12, 0]) cube([1, 1, 4.129279258632918]);

translate([33, 12, 0]) cube([1, 1, 4.225321054726608]);

translate([34, 12, 0]) cube([1, 1, 4.432701323255805]);

translate([35, 12, 0]) cube([1, 1, 4.632921824969254]);

translate([36, 12, 0]) cube([1, 1, 3.657231153424165]);

translate([37, 12, 0]) cube([1, 1, 4.636042510041963]);

translate([38, 12, 0]) cube([1, 1, 4.625965030490357]);

translate([39, 12, 0]) cube([1, 1, 4.616310567689534]);

translate([40, 12, 0]) cube([1, 1, 4.70310109618644]);

translate([41, 12, 0]) cube([1, 1, 4.701976294690032]);

translate([42, 12, 0]) cube([1, 1, 4.601026613063765]);

translate([43, 12, 0]) cube([1, 1, 4.500772471812648]);

translate([44, 12, 0]) cube([1, 1, 4.500277091599912]);

translate([45, 12, 0]) cube([1, 1, 4.5001052292546255]);

translate([46, 12, 0]) cube([1, 1, 4.400032562052737]);

translate([47, 12, 0]) cube([1, 1, 4.300011329731426]);

translate([0, 13, 0]) cube([1, 1, 7.9]);

translate([1, 13, 0]) cube([1, 1, 7.6]);

translate([2, 13, 0]) cube([1, 1, 7.3]);

translate([3, 13, 0]) cube([1, 1, 7.2]);

translate([4, 13, 0]) cube([1, 1, 7.0]);

translate([5, 13, 0]) cube([1, 1, 6.9]);

translate([6, 13, 0]) cube([1, 1, 6.7]);

translate([7, 13, 0]) cube([1, 1, 6.600003261336468]);

translate([8, 13, 0]) cube([1, 1, 6.506780933345888]);

translate([9, 13, 0]) cube([1, 1, 6.508918823560815]);

translate([10, 13, 0]) cube([1, 1, 6.611065661863034]);

translate([11, 13, 0]) cube([1, 1, 6.6180814148440215]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 13, 0]) cube([1, 1, 6]);

translate([25, 13, 0]) cube([1, 1, 5.20152989242531]);

translate([26, 13, 0]) cube([1, 1, 4.9037081415291315]);

translate([27, 13, 0]) cube([1, 1, 4.806041183675729]);

translate([28, 13, 0]) cube([1, 1, 4.708663990338353]);

translate([29, 13, 0]) cube([1, 1, 4.617288327149172]);

translate([30, 13, 0]) cube([1, 1, 4.434284097117826]);

translate([31, 13, 0]) cube([1, 1, 4.350649881404834]);

translate([32, 13, 0]) cube([1, 1, 4.3465022169748275]);

translate([33, 13, 0]) cube([1, 1, 4.523923149708521]);

translate([34, 13, 0]) cube([1, 1, 4.823478598819543]);

translate([35, 13, 0]) cube([1, 1, 4.933183061566531]);

translate([36, 13, 0]) cube([1, 1, 4.94086929076849]);

translate([37, 13, 0]) cube([1, 1, 4.93365158854879]);

translate([38, 13, 0]) cube([1, 1, 4.92062106987469]);

translate([39, 13, 0]) cube([1, 1, 4.910623098058209]);

translate([40, 13, 0]) cube([1, 1, 4.904931977379001]);

translate([41, 13, 0]) cube([1, 1, 4.802108117576115]);

translate([42, 13, 0]) cube([1, 1, 4.800683667705044]);

translate([43, 13, 0]) cube([1, 1, 4.7003649863427]);

translate([44, 13, 0]) cube([1, 1, 4.700191848781652]);

translate([45, 13, 0]) cube([1, 1, 4.700056152894906]);

translate([46, 13, 0]) cube([1, 1, 4.800001053584685]);

translate([47, 13, 0]) cube([1, 1, 4.7000003769853365]);

translate([0, 14, 0]) cube([1, 1, 7.9]);

translate([1, 14, 0]) cube([1, 1, 7.6]);

translate([2, 14, 0]) cube([1, 1, 7.3]);

translate([3, 14, 0]) cube([1, 1, 7.1]);

translate([4, 14, 0]) cube([1, 1, 6.9]);

translate([5, 14, 0]) cube([1, 1, 6.7]);

translate([6, 14, 0]) cube([1, 1, 6.600019568018813]);

translate([7, 14, 0]) cube([1, 1, 6.50737016623225]);

translate([8, 14, 0]) cube([1, 1, 6.507911378035886]);

translate([9, 14, 0]) cube([1, 1, 6.606972825787657]);

translate([10, 14, 0]) cube([1, 1, 6.712633153988161]);

translate([11, 14, 0]) cube([1, 1, 6.742107288375341]);

translate([12, 14, 0]) cube([1, 1, 6.653367217180604]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 14, 0]) cube([1, 1, 6]);

translate([25, 14, 0]) cube([1, 1, 5.203158226904941]);

translate([26, 14, 0]) cube([1, 1, 5.003582068609444]);

translate([27, 14, 0]) cube([1, 1, 4.905982076410988]);

translate([28, 14, 0]) cube([1, 1, 4.809690828314364]);

translate([29, 14, 0]) cube([1, 1, 4.7216058698452406]);

translate([30, 14, 0]) cube([1, 1, 4.646480952601531]);

translate([31, 14, 0]) cube([1, 1, 4.586045340439551]);

translate([32, 14, 0]) cube([1, 1, 4.6423087141424215]);

translate([33, 14, 0]) cube([1, 1, 4.827212105398779]);

translate([34, 14, 0]) cube([1, 1, 5.126616348304634]);

translate([35, 14, 0]) cube([1, 1, 5.361192064634778]);

translate([36, 14, 0]) cube([1, 1, 5.367411006570964]);

translate([37, 14, 0]) cube([1, 1, 5.355697570259737]);

translate([38, 14, 0]) cube([1, 1, 5.219898270410713]);

translate([39, 14, 0]) cube([1, 1, 5.108981428961486]);

translate([40, 14, 0]) cube([1, 1, 5.10361472104415]);

translate([41, 14, 0]) cube([1, 1, 5.001440639858588]);

translate([42, 14, 0]) cube([1, 1, 4.900553250069792]);

translate([43, 14, 0]) cube([1, 1, 4.800562592942157]);

translate([44, 14, 0]) cube([1, 1, 4.900025421581696]);

translate([45, 14, 0]) cube([1, 1, 5.000006243771853]);

translate([46, 14, 0]) cube([1, 1, 5.100000046035989]);

translate([47, 14, 0]) cube([1, 1, 5.100000033998198]);

translate([0, 15, 0]) cube([1, 1, 8.0]);

translate([1, 15, 0]) cube([1, 1, 7.7]);

translate([2, 15, 0]) cube([1, 1, 7.4]);

translate([3, 15, 0]) cube([1, 1, 7.1]);

translate([4, 15, 0]) cube([1, 1, 6.8]);

translate([5, 15, 0]) cube([1, 1, 6.7]);

translate([6, 15, 0]) cube([1, 1, 6.600023363315697]);

translate([7, 15, 0]) cube([1, 1, 6.6000527153439155]);

translate([8, 15, 0]) cube([1, 1, 6.700263576719577]);

translate([9, 15, 0]) cube([1, 1, 6.801317883597883]);

translate([10, 15, 0]) cube([1, 1, 6.9065894179894185]);

translate([11, 15, 0]) cube([1, 1, 6.814036860670194]);

translate([12, 15, 0]) cube([1, 1, 5.487091973218955]);

translate([13, 15, 0]) cube([1, 1, 6.5711367222148525]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 15, 0]) cube([1, 1, 6]);

translate([25, 15, 0]) cube([1, 1, 5.205084619153533]);

translate([26, 15, 0]) cube([1, 1, 5.008137617236761]);

translate([27, 15, 0]) cube([1, 1, 4.913930308440846]);

translate([28, 15, 0]) cube([1, 1, 4.9071583655507185]);

translate([29, 15, 0]) cube([1, 1, 4.821383399187347]);

translate([30, 15, 0]) cube([1, 1, 4.7697967645051165]);

translate([31, 15, 0]) cube([1, 1, 4.719618735047295]);

translate([32, 15, 0]) cube([1, 1, 4.865976202930185]);

translate([33, 15, 0]) cube([1, 1, 5.120985825268698]);

translate([34, 15, 0]) cube([1, 1, 5.42788360141161]);

color([0,1,0])
translate([35, 15, 0]) cube([1, 1, 6]);

translate([36, 15, 0]) cube([1, 1, 4.488686610001702]);

color([0,1,0])
translate([37, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 15, 0]) cube([1, 1, 6]);

translate([39, 15, 0]) cube([1, 1, 5.405808481576308]);

translate([40, 15, 0]) cube([1, 1, 5.302352594341602]);

translate([41, 15, 0]) cube([1, 1, 5.200931101071024]);

translate([42, 15, 0]) cube([1, 1, 5.100304783571192]);

translate([43, 15, 0]) cube([1, 1, 5.100089726951905]);

translate([44, 15, 0]) cube([1, 1, 5.100030929751179]);

translate([45, 15, 0]) cube([1, 1, 5.300000208174752]);

translate([46, 15, 0]) cube([1, 1, 5.400000036423861]);

translate([47, 15, 0]) cube([1, 1, 5.400000026907761]);

translate([0, 16, 0]) cube([1, 1, 8.1]);

translate([1, 16, 0]) cube([1, 1, 7.8]);

translate([2, 16, 0]) cube([1, 1, 7.5]);

translate([3, 16, 0]) cube([1, 1, 7.1]);

translate([4, 16, 0]) cube([1, 1, 6.9]);

translate([5, 16, 0]) cube([1, 1, 6.8]);

translate([6, 16, 0]) cube([1, 1, 6.8]);

translate([7, 16, 0]) cube([1, 1, 6.8]);

translate([8, 16, 0]) cube([1, 1, 7.0]);

translate([9, 16, 0]) cube([1, 1, 7.1]);

translate([10, 16, 0]) cube([1, 1, 7.1]);

translate([11, 16, 0]) cube([1, 1, 6.91096507936508]);

translate([12, 16, 0]) cube([1, 1, 6.741646206153244]);

translate([13, 16, 0]) cube([1, 1, 6.602575351013514]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

translate([16, 16, 0]) cube([1, 1, 5.346708673067412]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 16, 0]) cube([1, 1, 6]);

translate([25, 16, 0]) cube([1, 1, 5.20733218807442]);

translate([26, 16, 0]) cube([1, 1, 5.014956767945852]);

translate([27, 16, 0]) cube([1, 1, 5.009294747793336]);

translate([28, 16, 0]) cube([1, 1, 4.91975825624778]);

translate([29, 16, 0]) cube([1, 1, 4.856197662592324]);

translate([30, 16, 0]) cube([1, 1, 4.825328359924578]);

translate([31, 16, 0]) cube([1, 1, 4.829502514653224]);

translate([32, 16, 0]) cube([1, 1, 4.165301856721967]);

translate([33, 16, 0]) cube([1, 1, 5.226170143697759]);

color([0,1,0])
translate([34, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 16, 0]) cube([1, 1, 6]);

translate([43, 16, 0]) cube([1, 1, 5.400032818952295]);

color([0,1,0])
translate([44, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 16, 0]) cube([1, 1, 6]);

translate([0, 17, 0]) cube([1, 1, 8.2]);

translate([1, 17, 0]) cube([1, 1, 7.9]);

translate([2, 17, 0]) cube([1, 1, 7.5]);

translate([3, 17, 0]) cube([1, 1, 7.2]);

translate([4, 17, 0]) cube([1, 1, 7.0]);

translate([5, 17, 0]) cube([1, 1, 7.0]);

translate([6, 17, 0]) cube([1, 1, 7.0]);

translate([7, 17, 0]) cube([1, 1, 7.1]);

translate([8, 17, 0]) cube([1, 1, 7.3]);

translate([9, 17, 0]) cube([1, 1, 7.3]);

translate([10, 17, 0]) cube([1, 1, 7.2]);

translate([11, 17, 0]) cube([1, 1, 7.0096]);

translate([12, 17, 0]) cube([1, 1, 6.859557662159514]);

translate([13, 17, 0]) cube([1, 1, 6.697696228418232]);

translate([14, 17, 0]) cube([1, 1, 6.593627096400669]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 17, 0]) cube([1, 1, 6]);

translate([25, 17, 0]) cube([1, 1, 5.308116882791381]);

translate([26, 17, 0]) cube([1, 1, 5.118069214282379]);

translate([27, 17, 0]) cube([1, 1, 5.021370259868205]);

translate([28, 17, 0]) cube([1, 1, 4.943594907616107]);

translate([29, 17, 0]) cube([1, 1, 4.932637867938849]);

translate([30, 17, 0]) cube([1, 1, 4.905768246386895]);

translate([31, 17, 0]) cube([1, 1, 4.921957417666904]);

translate([32, 17, 0]) cube([1, 1, 4.970428795757054]);

translate([33, 17, 0]) cube([1, 1, 5.241730878385677]);

color([0,1,0])
translate([34, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 17, 0]) cube([1, 1, 6]);

translate([0, 18, 0]) cube([1, 1, 8.2]);

translate([1, 18, 0]) cube([1, 1, 7.9]);

translate([2, 18, 0]) cube([1, 1, 7.6]);

translate([3, 18, 0]) cube([1, 1, 7.3]);

translate([4, 18, 0]) cube([1, 1, 7.2]);

translate([5, 18, 0]) cube([1, 1, 7.2]);

translate([6, 18, 0]) cube([1, 1, 7.3]);

translate([7, 18, 0]) cube([1, 1, 7.4]);

translate([8, 18, 0]) cube([1, 1, 7.5]);

translate([9, 18, 0]) cube([1, 1, 7.5]);

translate([10, 18, 0]) cube([1, 1, 7.4]);

translate([11, 18, 0]) cube([1, 1, 7.108]);

translate([12, 18, 0]) cube([1, 1, 5.772221818023137]);

translate([13, 18, 0]) cube([1, 1, 6.798046394349565]);

translate([14, 18, 0]) cube([1, 1, 6.693909027893631]);

translate([15, 18, 0]) cube([1, 1, 6.657733929065086]);

translate([16, 18, 0]) cube([1, 1, 6.634730862485637]);

translate([17, 18, 0]) cube([1, 1, 6.523271285161968]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 18, 0]) cube([1, 1, 6]);

translate([25, 18, 0]) cube([1, 1, 5.40780742257156]);

translate([26, 18, 0]) cube([1, 1, 5.221233251050701]);

translate([27, 18, 0]) cube([1, 1, 5.133240372609573]);

translate([28, 18, 0]) cube([1, 1, 5.128258552391639]);

translate([29, 18, 0]) cube([1, 1, 5.038098299391967]);

translate([30, 18, 0]) cube([1, 1, 4.986309193672606]);

translate([31, 18, 0]) cube([1, 1, 4.998517626162263]);

translate([32, 18, 0]) cube([1, 1, 5.164090395339235]);

translate([33, 18, 0]) cube([1, 1, 5.3509249886494965]);

color([0,1,0])
translate([34, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 18, 0]) cube([1, 1, 6]);

translate([36, 18, 0]) cube([1, 1, 4.949792485492788]);

color([0,1,0])
translate([37, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 8.1]);

translate([1, 19, 0]) cube([1, 1, 7.9]);

translate([2, 19, 0]) cube([1, 1, 7.6]);

translate([3, 19, 0]) cube([1, 1, 7.4]);

translate([4, 19, 0]) cube([1, 1, 7.4]);

translate([5, 19, 0]) cube([1, 1, 7.4]);

translate([6, 19, 0]) cube([1, 1, 7.5]);

translate([7, 19, 0]) cube([1, 1, 7.6]);

translate([8, 19, 0]) cube([1, 1, 7.6]);

translate([9, 19, 0]) cube([1, 1, 7.6]);

translate([10, 19, 0]) cube([1, 1, 7.4]);

translate([11, 19, 0]) cube([1, 1, 7.2]);

translate([12, 19, 0]) cube([1, 1, 7.037993141289439]);

translate([13, 19, 0]) cube([1, 1, 6.907470797190906]);

translate([14, 19, 0]) cube([1, 1, 6.804093945746308]);

translate([15, 19, 0]) cube([1, 1, 6.84715288940545]);

translate([16, 19, 0]) cube([1, 1, 6.843359461646245]);

translate([17, 19, 0]) cube([1, 1, 6.73837099554335]);

translate([18, 19, 0]) cube([1, 1, 6.52524943921133]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 19, 0]) cube([1, 1, 6]);

translate([26, 19, 0]) cube([1, 1, 5.32130218566726]);

translate([27, 19, 0]) cube([1, 1, 5.3394757369853005]);

translate([28, 19, 0]) cube([1, 1, 5.251060310412547]);

translate([29, 19, 0]) cube([1, 1, 5.245193478272256]);

translate([30, 19, 0]) cube([1, 1, 5.165979166196543]);

translate([31, 19, 0]) cube([1, 1, 5.199637710470969]);

translate([32, 19, 0]) cube([1, 1, 5.299154475130099]);

translate([33, 19, 0]) cube([1, 1, 5.445147545416363]);

color([0,1,0])
translate([34, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 19, 0]) cube([1, 1, 6]);

translate([41, 19, 0]) cube([1, 1, 6.6]);

translate([42, 19, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([43, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 19, 0]) cube([1, 1, 6]);

translate([0, 20, 0]) cube([1, 1, 8.1]);

translate([1, 20, 0]) cube([1, 1, 7.9]);

translate([2, 20, 0]) cube([1, 1, 7.7]);

translate([3, 20, 0]) cube([1, 1, 7.6]);

translate([4, 20, 0]) cube([1, 1, 7.5]);

translate([5, 20, 0]) cube([1, 1, 7.6]);

translate([6, 20, 0]) cube([1, 1, 7.6]);

translate([7, 20, 0]) cube([1, 1, 7.6]);

translate([8, 20, 0]) cube([1, 1, 7.6]);

translate([9, 20, 0]) cube([1, 1, 7.6]);

translate([10, 20, 0]) cube([1, 1, 7.4]);

translate([11, 20, 0]) cube([1, 1, 7.2]);

translate([12, 20, 0]) cube([1, 1, 7.033915500685871]);

translate([13, 20, 0]) cube([1, 1, 7.018508105181693]);

translate([14, 20, 0]) cube([1, 1, 6.948473455866842]);

translate([15, 20, 0]) cube([1, 1, 6.919212127782818]);

translate([16, 20, 0]) cube([1, 1, 5.938313797204915]);

translate([17, 20, 0]) cube([1, 1, 6.840115009437933]);

translate([18, 20, 0]) cube([1, 1, 6.622656297991863]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 20, 0]) cube([1, 1, 6]);

translate([28, 20, 0]) cube([1, 1, 4.808438931747683]);

translate([29, 20, 0]) cube([1, 1, 5.415594284808516]);

translate([30, 20, 0]) cube([1, 1, 5.345933167041934]);

translate([31, 20, 0]) cube([1, 1, 5.373113588971016]);

translate([32, 20, 0]) cube([1, 1, 4.61299847536708]);

color([0,1,0])
translate([33, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 20, 0]) cube([1, 1, 6]);

translate([40, 20, 0]) cube([1, 1, 6.6]);

translate([41, 20, 0]) cube([1, 1, 6.8]);

translate([42, 20, 0]) cube([1, 1, 6.8]);

translate([43, 20, 0]) cube([1, 1, 6.8]);

translate([44, 20, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([45, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 20, 0]) cube([1, 1, 6]);

translate([47, 20, 0]) cube([1, 1, 5.400000420409102]);

translate([0, 21, 0]) cube([1, 1, 8.2]);

translate([1, 21, 0]) cube([1, 1, 7.9]);

translate([2, 21, 0]) cube([1, 1, 7.8]);

translate([3, 21, 0]) cube([1, 1, 7.7]);

translate([4, 21, 0]) cube([1, 1, 7.6]);

translate([5, 21, 0]) cube([1, 1, 7.6]);

translate([6, 21, 0]) cube([1, 1, 7.6]);

translate([7, 21, 0]) cube([1, 1, 7.5]);

translate([8, 21, 0]) cube([1, 1, 7.5]);

translate([9, 21, 0]) cube([1, 1, 7.4]);

translate([10, 21, 0]) cube([1, 1, 7.2]);

translate([11, 21, 0]) cube([1, 1, 7.1]);

translate([12, 21, 0]) cube([1, 1, 6.281196359030726]);

translate([13, 21, 0]) cube([1, 1, 7.018689493367433]);

translate([14, 21, 0]) cube([1, 1, 7.016054460635619]);

translate([15, 21, 0]) cube([1, 1, 7.003337442787045]);

translate([16, 21, 0]) cube([1, 1, 6.912086183944982]);

translate([17, 21, 0]) cube([1, 1, 6.738372795686977]);

translate([18, 21, 0]) cube([1, 1, 6.619351072416729]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 21, 0]) cube([1, 1, 6]);

translate([21, 21, 0]) cube([1, 1, 6.504920835299042]);

translate([22, 21, 0]) cube([1, 1, 6.505545652256515]);

color([0,1,0])
translate([23, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 21, 0]) cube([1, 1, 6]);

translate([36, 21, 0]) cube([1, 1, 4.898914742290282]);

color([0,1,0])
translate([37, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 21, 0]) cube([1, 1, 6]);

translate([40, 21, 0]) cube([1, 1, 6.8]);

translate([41, 21, 0]) cube([1, 1, 6.9]);

translate([42, 21, 0]) cube([1, 1, 7.0]);

translate([43, 21, 0]) cube([1, 1, 6.9]);

translate([44, 21, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([45, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 21, 0]) cube([1, 1, 6]);

translate([47, 21, 0]) cube([1, 1, 5.400000422016671]);

translate([0, 22, 0]) cube([1, 1, 8.1]);

translate([1, 22, 0]) cube([1, 1, 7.9]);

translate([2, 22, 0]) cube([1, 1, 7.8]);

translate([3, 22, 0]) cube([1, 1, 7.7]);

translate([4, 22, 0]) cube([1, 1, 7.6]);

translate([5, 22, 0]) cube([1, 1, 7.5]);

translate([6, 22, 0]) cube([1, 1, 7.4]);

translate([7, 22, 0]) cube([1, 1, 7.3]);

translate([8, 22, 0]) cube([1, 1, 7.2]);

translate([9, 22, 0]) cube([1, 1, 7.0000301932733855]);

translate([10, 22, 0]) cube([1, 1, 7.000120773441327]);

translate([11, 22, 0]) cube([1, 1, 7.000603867206638]);

translate([12, 22, 0]) cube([1, 1, 7.003623203724424]);

translate([13, 22, 0]) cube([1, 1, 7.005856188864662]);

translate([14, 22, 0]) cube([1, 1, 7.006160831599294]);

translate([15, 22, 0]) cube([1, 1, 7.003636732512953]);

translate([16, 22, 0]) cube([1, 1, 6.816802161640192]);

translate([17, 22, 0]) cube([1, 1, 6.629331994535498]);

translate([18, 22, 0]) cube([1, 1, 6.53200513553308]);

color([0,1,0])
translate([19, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 22, 0]) cube([1, 1, 6]);

translate([21, 22, 0]) cube([1, 1, 6.509313086967525]);

translate([22, 22, 0]) cube([1, 1, 6.600050555869495]);

translate([23, 22, 0]) cube([1, 1, 6.600050555869495]);

color([0,1,0])
translate([24, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 22, 0]) cube([1, 1, 6]);

translate([39, 22, 0]) cube([1, 1, 6.6]);

translate([40, 22, 0]) cube([1, 1, 6.7]);

translate([41, 22, 0]) cube([1, 1, 6.9]);

translate([42, 22, 0]) cube([1, 1, 7.0]);

translate([43, 22, 0]) cube([1, 1, 6.9]);

translate([44, 22, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([45, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 22, 0]) cube([1, 1, 6]);

translate([47, 22, 0]) cube([1, 1, 5.400000831167719]);

translate([0, 23, 0]) cube([1, 1, 8.0]);

translate([1, 23, 0]) cube([1, 1, 7.8]);

translate([2, 23, 0]) cube([1, 1, 7.6]);

translate([3, 23, 0]) cube([1, 1, 7.6]);

translate([4, 23, 0]) cube([1, 1, 7.5]);

translate([5, 23, 0]) cube([1, 1, 7.4]);

translate([6, 23, 0]) cube([1, 1, 7.2]);

translate([7, 23, 0]) cube([1, 1, 7.1]);

translate([8, 23, 0]) cube([1, 1, 6.900006038458499]);

translate([9, 23, 0]) cube([1, 1, 6.700144222110926]);

translate([10, 23, 0]) cube([1, 1, 6.7004198832704995]);

translate([11, 23, 0]) cube([1, 1, 6.80134458287465]);

translate([12, 23, 0]) cube([1, 1, 6.802704288107841]);

translate([13, 23, 0]) cube([1, 1, 6.9031089629134]);

translate([14, 23, 0]) cube([1, 1, 6.90314983251966]);

translate([15, 23, 0]) cube([1, 1, 6.9021578992886585]);

translate([16, 23, 0]) cube([1, 1, 6.812855550273183]);

translate([17, 23, 0]) cube([1, 1, 6.638671363349512]);

color([0,1,0])
translate([18, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 23, 0]) cube([1, 1, 6]);

translate([21, 23, 0]) cube([1, 1, 6.512829616727314]);

translate([22, 23, 0]) cube([1, 1, 6.600179458262225]);

translate([23, 23, 0]) cube([1, 1, 6.600179458262225]);

color([0,1,0])
translate([24, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 23, 0]) cube([1, 1, 6]);

translate([40, 23, 0]) cube([1, 1, 6.6]);

translate([41, 23, 0]) cube([1, 1, 6.8]);

translate([42, 23, 0]) cube([1, 1, 6.8]);

translate([43, 23, 0]) cube([1, 1, 6.8]);

translate([44, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([45, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 23, 0]) cube([1, 1, 6]);

translate([0, 24, 0]) cube([1, 1, 7.7]);

translate([1, 24, 0]) cube([1, 1, 7.5]);

translate([2, 24, 0]) cube([1, 1, 7.4]);

translate([3, 24, 0]) cube([1, 1, 7.3]);

translate([4, 24, 0]) cube([1, 1, 7.2]);

translate([5, 24, 0]) cube([1, 1, 7.1]);

translate([6, 24, 0]) cube([1, 1, 7.0]);

translate([7, 24, 0]) cube([1, 1, 6.800001207566904]);

translate([8, 24, 0]) cube([1, 1, 6.600030293493265]);

translate([9, 24, 0]) cube([1, 1, 6.503616116638678]);

translate([10, 24, 0]) cube([1, 1, 6.513864029221527]);

translate([11, 24, 0]) cube([1, 1, 6.617411459042164]);

color([0,1,0])
translate([12, 24, 0]) cube([1, 1, 6]);

translate([13, 24, 0]) cube([1, 1, 6.724906800467748]);

translate([14, 24, 0]) cube([1, 1, 6.815570918797827]);

translate([15, 24, 0]) cube([1, 1, 6.812575561111013]);

translate([16, 24, 0]) cube([1, 1, 5.755490623910402]);

translate([17, 24, 0]) cube([1, 1, 6.641188449434927]);

translate([18, 24, 0]) cube([1, 1, 6.5397689587377075]);

translate([19, 24, 0]) cube([1, 1, 6.507778514264962]);

color([0,1,0])
translate([20, 24, 0]) cube([1, 1, 6]);

translate([21, 24, 0]) cube([1, 1, 6.52029166949251]);

translate([22, 24, 0]) cube([1, 1, 6.601200627362473]);

translate([23, 24, 0]) cube([1, 1, 6.501702969859819]);

color([0,1,0])
translate([24, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 24, 0]) cube([1, 1, 6]);

translate([28, 24, 0]) cube([1, 1, 5.026328459515714]);

color([0,1,0])
translate([29, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 24, 0]) cube([1, 1, 6]);

translate([32, 24, 0]) cube([1, 1, 4.754046332037153]);

color([0,1,0])
translate([33, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 24, 0]) cube([1, 1, 6]);

translate([36, 24, 0]) cube([1, 1, 4.918894570345028]);

color([0,1,0])
translate([37, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 24, 0]) cube([1, 1, 6]);

translate([41, 24, 0]) cube([1, 1, 6.6]);

translate([42, 24, 0]) cube([1, 1, 6.7]);

translate([43, 24, 0]) cube([1, 1, 6.7]);

translate([44, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([45, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 24, 0]) cube([1, 1, 6]);

translate([0, 25, 0]) cube([1, 1, 7.3]);

translate([1, 25, 0]) cube([1, 1, 7.1]);

translate([2, 25, 0]) cube([1, 1, 7.1]);

translate([3, 25, 0]) cube([1, 1, 7.0]);

translate([4, 25, 0]) cube([1, 1, 7.0]);

translate([5, 25, 0]) cube([1, 1, 6.9]);

translate([6, 25, 0]) cube([1, 1, 6.800000241255086]);

translate([7, 25, 0]) cube([1, 1, 6.60000634836889]);

color([0,1,0])
translate([8, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 25, 0]) cube([1, 1, 6]);

translate([14, 25, 0]) cube([1, 1, 6.624981253736314]);

translate([15, 25, 0]) cube([1, 1, 6.639004106517274]);

translate([16, 25, 0]) cube([1, 1, 6.64111621023864]);

translate([17, 25, 0]) cube([1, 1, 6.550591317421034]);

translate([18, 25, 0]) cube([1, 1, 6.543381498777711]);

translate([19, 25, 0]) cube([1, 1, 6.535971003951082]);

translate([20, 25, 0]) cube([1, 1, 6.531645657193312]);

translate([21, 25, 0]) cube([1, 1, 6.606066783558034]);

translate([22, 25, 0]) cube([1, 1, 6.60372499363514]);

translate([23, 25, 0]) cube([1, 1, 6.5028009217381015]);

color([0,1,0])
translate([24, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 25, 0]) cube([1, 1, 6]);

translate([28, 25, 0]) cube([1, 1, 5.484226311773086]);

translate([29, 25, 0]) cube([1, 1, 5.4680313390372906]);

translate([30, 25, 0]) cube([1, 1, 5.455679048740125]);

color([0,1,0])
translate([31, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 25, 0]) cube([1, 1, 6]);

translate([0, 26, 0]) cube([1, 1, 7.0]);

translate([1, 26, 0]) cube([1, 1, 6.8]);

translate([2, 26, 0]) cube([1, 1, 6.8]);

translate([3, 26, 0]) cube([1, 1, 6.8]);

translate([4, 26, 0]) cube([1, 1, 6.8]);

translate([5, 26, 0]) cube([1, 1, 6.700000047977494]);

translate([6, 26, 0]) cube([1, 1, 6.600001327326741]);

translate([7, 26, 0]) cube([1, 1, 6.500001319377137]);

color([0,1,0])
translate([8, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 26, 0]) cube([1, 1, 6]);

translate([16, 26, 0]) cube([1, 1, 6.526294204002746]);

translate([17, 26, 0]) cube([1, 1, 6.53677736643067]);

translate([18, 26, 0]) cube([1, 1, 6.610604150369103]);

translate([19, 26, 0]) cube([1, 1, 6.615655183857428]);

translate([20, 26, 0]) cube([1, 1, 6.7138123859723295]);

translate([21, 26, 0]) cube([1, 1, 6.7125147324423535]);

translate([22, 26, 0]) cube([1, 1, 6.706227321655642]);

translate([23, 26, 0]) cube([1, 1, 6.504029994025144]);

color([0,1,0])
translate([24, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 26, 0]) cube([1, 1, 6]);

translate([28, 26, 0]) cube([1, 1, 5.482107202483344]);

translate([29, 26, 0]) cube([1, 1, 5.457264822602257]);

translate([30, 26, 0]) cube([1, 1, 5.445884892364542]);

translate([31, 26, 0]) cube([1, 1, 5.439867522081833]);

translate([32, 26, 0]) cube([1, 1, 5.4598286083554255]);

color([0,1,0])
translate([33, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 26, 0]) cube([1, 1, 6]);

translate([0, 27, 0]) cube([1, 1, 6.8]);

translate([1, 27, 0]) cube([1, 1, 6.6]);

translate([2, 27, 0]) cube([1, 1, 6.6]);

translate([3, 27, 0]) cube([1, 1, 6.6]);

translate([4, 27, 0]) cube([1, 1, 6.500000068973867]);

translate([5, 27, 0]) cube([1, 1, 6.500000228999361]);

color([0,1,0])
translate([6, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 27, 0]) cube([1, 1, 6]);

translate([12, 27, 0]) cube([1, 1, 4.9144431215747595]);

color([0,1,0])
translate([13, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 27, 0]) cube([1, 1, 6]);

translate([18, 27, 0]) cube([1, 1, 6.6126696020758615]);

translate([19, 27, 0]) cube([1, 1, 6.730762886220248]);

translate([20, 27, 0]) cube([1, 1, 6.926559842687075]);

translate([21, 27, 0]) cube([1, 1, 6.925065104166666]);

translate([22, 27, 0]) cube([1, 1, 6.904673549107143]);

translate([23, 27, 0]) cube([1, 1, 6.70307219883473]);

color([0,1,0])
translate([24, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 27, 0]) cube([1, 1, 6]);

translate([29, 27, 0]) cube([1, 1, 5.461102234922429]);

translate([30, 27, 0]) cube([1, 1, 5.4424677814524935]);

translate([31, 27, 0]) cube([1, 1, 5.437143722811388]);

translate([32, 27, 0]) cube([1, 1, 5.415366020747398]);

translate([33, 27, 0]) cube([1, 1, 5.411130654833242]);

color([0,1,0])
translate([34, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 27, 0]) cube([1, 1, 6]);

translate([36, 27, 0]) cube([1, 1, 4.690833524130634]);

color([0,1,0])
translate([37, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 27, 0]) cube([1, 1, 6]);

translate([0, 28, 0]) cube([1, 1, 6.7]);

translate([1, 28, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 28, 0]) cube([1, 1, 6]);

translate([16, 28, 0]) cube([1, 1, 5.409030545395756]);

color([0,1,0])
translate([17, 28, 0]) cube([1, 1, 6]);

translate([18, 28, 0]) cube([1, 1, 6.520684320584136]);

translate([19, 28, 0]) cube([1, 1, 6.83100683477756]);

translate([20, 28, 0]) cube([1, 1, 6.309055424644899]);

translate([21, 28, 0]) cube([1, 1, 7.1]);

translate([22, 28, 0]) cube([1, 1, 7.002976190476191]);

translate([23, 28, 0]) cube([1, 1, 6.801483932934671]);

translate([24, 28, 0]) cube([1, 1, 6.500940523436741]);

color([0,1,0])
translate([25, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 28, 0]) cube([1, 1, 6]);

translate([28, 28, 0]) cube([1, 1, 5.067330030322131]);

color([0,1,0])
translate([29, 28, 0]) cube([1, 1, 6]);

translate([30, 28, 0]) cube([1, 1, 5.442581283692377]);

translate([31, 28, 0]) cube([1, 1, 5.43311448312375]);

translate([32, 28, 0]) cube([1, 1, 5.008897457872573]);

translate([33, 28, 0]) cube([1, 1, 5.412450763449162]);

color([0,1,0])
translate([34, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 28, 0]) cube([1, 1, 6]);

translate([0, 29, 0]) cube([1, 1, 6.9]);

translate([1, 29, 0]) cube([1, 1, 6.7]);

translate([2, 29, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 29, 0]) cube([1, 1, 6]);

translate([10, 29, 0]) cube([1, 1, 5.4971014338110065]);

color([0,1,0])
translate([11, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 29, 0]) cube([1, 1, 6]);

translate([19, 29, 0]) cube([1, 1, 6.7289822798470125]);

translate([20, 29, 0]) cube([1, 1, 7.000011810279667]);

translate([21, 29, 0]) cube([1, 1, 7.1]);

translate([22, 29, 0]) cube([1, 1, 7.000496031746032]);

translate([23, 29, 0]) cube([1, 1, 6.800859201946596]);

translate([24, 29, 0]) cube([1, 1, 6.500670615884282]);

color([0,1,0])
translate([25, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 29, 0]) cube([1, 1, 6]);

translate([30, 29, 0]) cube([1, 1, 5.446412520104995]);

translate([31, 29, 0]) cube([1, 1, 5.430386906783261]);

translate([32, 29, 0]) cube([1, 1, 5.420533592248697]);

translate([33, 29, 0]) cube([1, 1, 5.415893649092145]);

translate([34, 29, 0]) cube([1, 1, 5.449827074275665]);

color([0,1,0])
translate([35, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 29, 0]) cube([1, 1, 6]);

translate([47, 29, 0]) cube([1, 1, 5.300066089896572]);

translate([0, 30, 0]) cube([1, 1, 7.0]);

translate([1, 30, 0]) cube([1, 1, 6.9]);

translate([2, 30, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 30, 0]) cube([1, 1, 6]);

translate([9, 30, 0]) cube([1, 1, 5.462847713312167]);

translate([10, 30, 0]) cube([1, 1, 5.475752408715121]);

translate([11, 30, 0]) cube([1, 1, 5.496149425765523]);

translate([12, 30, 0]) cube([1, 1, 4.9259415537288485]);

color([0,1,0])
translate([13, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 30, 0]) cube([1, 1, 6]);

translate([19, 30, 0]) cube([1, 1, 6.605806595427581]);

translate([20, 30, 0]) cube([1, 1, 6.90001789116771]);

translate([21, 30, 0]) cube([1, 1, 7.0000708616780045]);

translate([22, 30, 0]) cube([1, 1, 6.900097680854749]);

translate([23, 30, 0]) cube([1, 1, 6.7002972288280125]);

color([0,1,0])
translate([24, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 30, 0]) cube([1, 1, 6]);

translate([31, 30, 0]) cube([1, 1, 5.441969401779496]);

translate([32, 30, 0]) cube([1, 1, 5.429879510459284]);

translate([33, 30, 0]) cube([1, 1, 5.432729566821037]);

translate([34, 30, 0]) cube([1, 1, 5.458895145271053]);

color([0,1,0])
translate([35, 30, 0]) cube([1, 1, 6]);

translate([36, 30, 0]) cube([1, 1, 4.560574890108964]);

color([0,1,0])
translate([37, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 30, 0]) cube([1, 1, 6]);

translate([46, 30, 0]) cube([1, 1, 5.400047668902595]);

translate([47, 30, 0]) cube([1, 1, 5.10010123125893]);

translate([0, 31, 0]) cube([1, 1, 7.1]);

translate([1, 31, 0]) cube([1, 1, 7.0]);

translate([2, 31, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 31, 0]) cube([1, 1, 6]);

translate([7, 31, 0]) cube([1, 1, 5.400818756161721]);

translate([8, 31, 0]) cube([1, 1, 5.393788707159499]);

translate([9, 31, 0]) cube([1, 1, 5.419827797560276]);

translate([10, 31, 0]) cube([1, 1, 5.462987256274748]);

translate([11, 31, 0]) cube([1, 1, 5.478909266634517]);

color([0,1,0])
translate([12, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 31, 0]) cube([1, 1, 6]);

translate([19, 31, 0]) cube([1, 1, 6.6011706027060395]);

translate([20, 31, 0]) cube([1, 1, 6.800020995843518]);

translate([21, 31, 0]) cube([1, 1, 6.900023761157902]);

translate([22, 31, 0]) cube([1, 1, 6.800033229592681]);

translate([23, 31, 0]) cube([1, 1, 6.500088552871164]);

color([0,1,0])
translate([24, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 31, 0]) cube([1, 1, 6]);

translate([32, 31, 0]) cube([1, 1, 5.466825401282895]);

translate([33, 31, 0]) cube([1, 1, 5.458733953124558]);

translate([34, 31, 0]) cube([1, 1, 5.460132813102974]);

translate([35, 31, 0]) cube([1, 1, 5.473829303132055]);

translate([36, 31, 0]) cube([1, 1, 5.485244314346659]);

color([0,1,0])
translate([37, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 31, 0]) cube([1, 1, 6]);

translate([46, 31, 0]) cube([1, 1, 5.300051289856347]);

translate([47, 31, 0]) cube([1, 1, 5.000135210151042]);

translate([0, 32, 0]) cube([1, 1, 7.2]);

translate([1, 32, 0]) cube([1, 1, 7.0]);

translate([2, 32, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 32, 0]) cube([1, 1, 6]);

translate([6, 32, 0]) cube([1, 1, 5.330195314657298]);

translate([7, 32, 0]) cube([1, 1, 5.330196210923299]);

translate([8, 32, 0]) cube([1, 1, 5.376387365527875]);

translate([9, 32, 0]) cube([1, 1, 5.396361156116617]);

translate([10, 32, 0]) cube([1, 1, 5.461067074023978]);

color([0,1,0])
translate([11, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 32, 0]) cube([1, 1, 6]);

translate([16, 32, 0]) cube([1, 1, 5.219839340864845]);

color([0,1,0])
translate([17, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 32, 0]) cube([1, 1, 6]);

translate([19, 32, 0]) cube([1, 1, 6.600240772557899]);

translate([20, 32, 0]) cube([1, 1, 6.8000075310913966]);

translate([21, 32, 0]) cube([1, 1, 6.800011404424846]);

translate([22, 32, 0]) cube([1, 1, 6.700014625664794]);

translate([23, 32, 0]) cube([1, 1, 6.500028859176969]);

color([0,1,0])
translate([24, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 32, 0]) cube([1, 1, 6]);

translate([32, 32, 0]) cube([1, 1, 4.648375171850376]);

translate([33, 32, 0]) cube([1, 1, 5.485302809069029]);

translate([34, 32, 0]) cube([1, 1, 5.485510964404068]);

color([0,1,0])
translate([35, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 32, 0]) cube([1, 1, 6]);

translate([45, 32, 0]) cube([1, 1, 5.400069054935829]);

translate([46, 32, 0]) cube([1, 1, 5.100070233492133]);

translate([47, 32, 0]) cube([1, 1, 4.900209290187958]);

translate([0, 33, 0]) cube([1, 1, 7.1]);

translate([1, 33, 0]) cube([1, 1, 7.0]);

translate([2, 33, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 33, 0]) cube([1, 1, 6]);

translate([5, 33, 0]) cube([1, 1, 5.400552884480578]);

translate([6, 33, 0]) cube([1, 1, 5.330195334439321]);

translate([7, 33, 0]) cube([1, 1, 5.330195350288339]);

translate([8, 33, 0]) cube([1, 1, 5.352790853740272]);

color([0,1,0])
translate([9, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 33, 0]) cube([1, 1, 6]);

translate([12, 33, 0]) cube([1, 1, 4.830312548468093]);

color([0,1,0])
translate([13, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 33, 0]) cube([1, 1, 6]);

translate([19, 33, 0]) cube([1, 1, 6.600063555167346]);

translate([20, 33, 0]) cube([1, 1, 6.800004733732957]);

translate([21, 33, 0]) cube([1, 1, 6.800004733732957]);

translate([22, 33, 0]) cube([1, 1, 6.7000078881701715]);

translate([23, 33, 0]) cube([1, 1, 6.5000104323740056]);

color([0,1,0])
translate([24, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 33, 0]) cube([1, 1, 6]);

translate([36, 33, 0]) cube([1, 1, 4.470201674678039]);

color([0,1,0])
translate([37, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 33, 0]) cube([1, 1, 6]);

translate([44, 33, 0]) cube([1, 1, 5.400143832941676]);

translate([45, 33, 0]) cube([1, 1, 5.20016243762418]);

translate([46, 33, 0]) cube([1, 1, 5.000161852209501]);

translate([47, 33, 0]) cube([1, 1, 4.800811053642582]);

translate([0, 34, 0]) cube([1, 1, 7.0]);

translate([1, 34, 0]) cube([1, 1, 6.9]);

translate([2, 34, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 34, 0]) cube([1, 1, 6]);

translate([5, 34, 0]) cube([1, 1, 5.402168276891073]);

translate([6, 34, 0]) cube([1, 1, 5.330196138059011]);

translate([7, 34, 0]) cube([1, 1, 5.330196449487274]);

color([0,1,0])
translate([8, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 34, 0]) cube([1, 1, 6]);

translate([18, 34, 0]) cube([1, 1, 6.600012947595929]);

translate([19, 34, 0]) cube([1, 1, 6.700001183287136]);

translate([20, 34, 0]) cube([1, 1, 6.9]);

translate([21, 34, 0]) cube([1, 1, 6.9]);

translate([22, 34, 0]) cube([1, 1, 6.800000788858091]);

translate([23, 34, 0]) cube([1, 1, 6.500003853372831]);

color([0,1,0])
translate([24, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 34, 0]) cube([1, 1, 6]);

translate([43, 34, 0]) cube([1, 1, 5.400505528625592]);

translate([44, 34, 0]) cube([1, 1, 5.300508852315373]);

translate([45, 34, 0]) cube([1, 1, 5.100507541721905]);

translate([46, 34, 0]) cube([1, 1, 4.900455119484009]);

translate([47, 34, 0]) cube([1, 1, 4.800813110331031]);

translate([0, 35, 0]) cube([1, 1, 6.8]);

translate([1, 35, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 35, 0]) cube([1, 1, 6]);

translate([17, 35, 0]) cube([1, 1, 6.600002589394555]);

translate([18, 35, 0]) cube([1, 1, 6.8]);

translate([19, 35, 0]) cube([1, 1, 6.9]);

translate([20, 35, 0]) cube([1, 1, 7.0]);

translate([21, 35, 0]) cube([1, 1, 7.0]);

translate([22, 35, 0]) cube([1, 1, 6.800000157674215]);

translate([23, 35, 0]) cube([1, 1, 6.500000966201149]);

color([0,1,0])
translate([24, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 35, 0]) cube([1, 1, 6]);

translate([42, 35, 0]) cube([1, 1, 5.402307174572923]);

translate([43, 35, 0]) cube([1, 1, 5.3018731566510615]);

translate([44, 35, 0]) cube([1, 1, 5.1017547408475465]);

translate([45, 35, 0]) cube([1, 1, 4.90146862884687]);

translate([46, 35, 0]) cube([1, 1, 4.8010504369118365]);

translate([47, 35, 0]) cube([1, 1, 4.702028258016582]);

translate([0, 36, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 36, 0]) cube([1, 1, 6]);

translate([12, 36, 0]) cube([1, 1, 5.145521105252614]);

color([0,1,0])
translate([13, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 36, 0]) cube([1, 1, 6]);

translate([16, 36, 0]) cube([1, 1, 6.600000517749197]);

translate([17, 36, 0]) cube([1, 1, 6.8]);

translate([18, 36, 0]) cube([1, 1, 7.0]);

translate([19, 36, 0]) cube([1, 1, 7.1]);

translate([20, 36, 0]) cube([1, 1, 7.1]);

translate([21, 36, 0]) cube([1, 1, 7.1]);

translate([22, 36, 0]) cube([1, 1, 6.800000031437441]);

translate([23, 36, 0]) cube([1, 1, 6.500000232228658]);

color([0,1,0])
translate([24, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 36, 0]) cube([1, 1, 6]);

translate([36, 36, 0]) cube([1, 1, 4.497640822949153]);

color([0,1,0])
translate([37, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 36, 0]) cube([1, 1, 6]);

translate([40, 36, 0]) cube([1, 1, 5.41905911296202]);

translate([41, 36, 0]) cube([1, 1, 5.4091979998998445]);

translate([42, 36, 0]) cube([1, 1, 5.306506756294526]);

translate([43, 36, 0]) cube([1, 1, 5.105890232789291]);

translate([44, 36, 0]) cube([1, 1, 4.90456922507341]);

translate([45, 36, 0]) cube([1, 1, 4.802732860733233]);

translate([46, 36, 0]) cube([1, 1, 4.702075025283916]);

translate([47, 36, 0]) cube([1, 1, 4.602866256579787]);

color([0,1,0])
translate([0, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 37, 0]) cube([1, 1, 6]);

translate([16, 37, 0]) cube([1, 1, 6.7]);

translate([17, 37, 0]) cube([1, 1, 7.0]);

translate([18, 37, 0]) cube([1, 1, 7.2]);

translate([19, 37, 0]) cube([1, 1, 7.2]);

translate([20, 37, 0]) cube([1, 1, 7.2]);

translate([21, 37, 0]) cube([1, 1, 7.0]);

translate([22, 37, 0]) cube([1, 1, 6.700000006191561]);

color([0,1,0])
translate([23, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 37, 0]) cube([1, 1, 6]);

translate([38, 37, 0]) cube([1, 1, 5.444986226279265]);

translate([39, 37, 0]) cube([1, 1, 5.427825903355686]);

translate([40, 37, 0]) cube([1, 1, 5.418369816872285]);

translate([41, 37, 0]) cube([1, 1, 5.318897207511785]);

translate([42, 37, 0]) cube([1, 1, 5.212408783301098]);

translate([43, 37, 0]) cube([1, 1, 5.106690438431339]);

translate([44, 37, 0]) cube([1, 1, 4.905833128752432]);

translate([45, 37, 0]) cube([1, 1, 4.704815629980966]);

translate([46, 37, 0]) cube([1, 1, 4.602882784890498]);

translate([47, 37, 0]) cube([1, 1, 4.5095183774067635]);

color([0,1,0])
translate([0, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 38, 0]) cube([1, 1, 6]);

translate([15, 38, 0]) cube([1, 1, 6.6]);

translate([16, 38, 0]) cube([1, 1, 6.8]);

translate([17, 38, 0]) cube([1, 1, 7.0]);

translate([18, 38, 0]) cube([1, 1, 7.2]);

translate([19, 38, 0]) cube([1, 1, 7.2]);

translate([20, 38, 0]) cube([1, 1, 7.1]);

translate([21, 38, 0]) cube([1, 1, 6.9]);

translate([22, 38, 0]) cube([1, 1, 6.5000000011601715]);

color([0,1,0])
translate([23, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 38, 0]) cube([1, 1, 6]);

translate([37, 38, 0]) cube([1, 1, 5.442965236319397]);

translate([38, 38, 0]) cube([1, 1, 5.435717906123984]);

translate([39, 38, 0]) cube([1, 1, 5.429749545228845]);

translate([40, 38, 0]) cube([1, 1, 5.421566489977899]);

translate([41, 38, 0]) cube([1, 1, 5.407344664768427]);

translate([42, 38, 0]) cube([1, 1, 5.307688509093831]);

translate([43, 38, 0]) cube([1, 1, 5.1089694322727235]);

translate([44, 38, 0]) cube([1, 1, 5.0038286816630135]);

translate([45, 38, 0]) cube([1, 1, 4.80226902675486]);

translate([46, 38, 0]) cube([1, 1, 4.602881704124058]);

translate([47, 38, 0]) cube([1, 1, 4.5095727782107105]);

color([0,1,0])
translate([0, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 39, 0]) cube([1, 1, 6]);

translate([15, 39, 0]) cube([1, 1, 6.7]);

translate([16, 39, 0]) cube([1, 1, 6.8]);

translate([17, 39, 0]) cube([1, 1, 6.9]);

translate([18, 39, 0]) cube([1, 1, 7.0]);

translate([19, 39, 0]) cube([1, 1, 7.0]);

translate([20, 39, 0]) cube([1, 1, 6.8]);

translate([21, 39, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([22, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 39, 0]) cube([1, 1, 6]);

translate([37, 39, 0]) cube([1, 1, 5.441619155786088]);

translate([38, 39, 0]) cube([1, 1, 5.439199022560844]);

translate([39, 39, 0]) cube([1, 1, 5.439051067597658]);

color([0,1,0])
translate([40, 39, 0]) cube([1, 1, 6]);

translate([41, 39, 0]) cube([1, 1, 5.408286643909228]);

translate([42, 39, 0]) cube([1, 1, 5.403914034360747]);

translate([43, 39, 0]) cube([1, 1, 5.302902678426167]);

translate([44, 39, 0]) cube([1, 1, 5.2005808612312965]);

translate([45, 39, 0]) cube([1, 1, 5.001102465464773]);

translate([46, 39, 0]) cube([1, 1, 4.800674309998274]);

translate([47, 39, 0]) cube([1, 1, 4.601946586669736]);

color([0,1,0])
translate([0, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 40, 0]) cube([1, 1, 6]);

translate([14, 40, 0]) cube([1, 1, 6.6]);

translate([15, 40, 0]) cube([1, 1, 6.7]);

translate([16, 40, 0]) cube([1, 1, 6.8]);

translate([17, 40, 0]) cube([1, 1, 6.8]);

translate([18, 40, 0]) cube([1, 1, 6.8]);

translate([19, 40, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([20, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 40, 0]) cube([1, 1, 6]);

translate([45, 40, 0]) cube([1, 1, 5.300000051984845]);

translate([46, 40, 0]) cube([1, 1, 5.100000010331328]);

translate([47, 40, 0]) cube([1, 1, 4.800337155217924]);

color([0,1,0])
translate([0, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 41, 0]) cube([1, 1, 6]);

translate([14, 41, 0]) cube([1, 1, 6.7]);

translate([15, 41, 0]) cube([1, 1, 6.7]);

translate([16, 41, 0]) cube([1, 1, 6.6]);

translate([17, 41, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([18, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 41, 0]) cube([1, 1, 6]);

translate([47, 41, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([0, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 42, 0]) cube([1, 1, 6]);

translate([40, 42, 0]) cube([1, 1, 5.400055937465824]);

translate([41, 42, 0]) cube([1, 1, 5.400029643400493]);

color([0,1,0])
translate([42, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 42, 0]) cube([1, 1, 6]);

translate([47, 42, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([0, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 43, 0]) cube([1, 1, 6]);

translate([39, 43, 0]) cube([1, 1, 5.4000530363867485]);

translate([40, 43, 0]) cube([1, 1, 5.300060338288788]);

translate([41, 43, 0]) cube([1, 1, 5.300056473887045]);

translate([42, 43, 0]) cube([1, 1, 5.400008413222528]);

color([0,1,0])
translate([43, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 44, 0]) cube([1, 1, 6]);

translate([7, 44, 0]) cube([1, 1, 5.40048838539686]);

translate([8, 44, 0]) cube([1, 1, 5.3010412767986725]);

translate([9, 44, 0]) cube([1, 1, 5.400605900835642]);

color([0,1,0])
translate([10, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 44, 0]) cube([1, 1, 6]);

translate([33, 44, 0]) cube([1, 1, 5.40000229345227]);

translate([34, 44, 0]) cube([1, 1, 5.400005301650678]);

color([0,1,0])
translate([35, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 44, 0]) cube([1, 1, 6]);

translate([38, 44, 0]) cube([1, 1, 5.400041019590895]);

translate([39, 44, 0]) cube([1, 1, 5.400026023561629]);

translate([40, 44, 0]) cube([1, 1, 5.300046184740821]);

translate([41, 44, 0]) cube([1, 1, 5.300049858191794]);

translate([42, 44, 0]) cube([1, 1, 5.400002102981055]);

color([0,1,0])
translate([43, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 45, 0]) cube([1, 1, 6]);

translate([1, 45, 0]) cube([1, 1, 5.400004233081099]);

translate([2, 45, 0]) cube([1, 1, 5.400009331307858]);

translate([3, 45, 0]) cube([1, 1, 5.400018659609595]);

color([0,1,0])
translate([4, 45, 0]) cube([1, 1, 6]);

translate([5, 45, 0]) cube([1, 1, 5.400080171979502]);

translate([6, 45, 0]) cube([1, 1, 5.300180537119284]);

translate([7, 45, 0]) cube([1, 1, 5.200395339075698]);

translate([8, 45, 0]) cube([1, 1, 5.100603944752877]);

translate([9, 45, 0]) cube([1, 1, 5.10059443308277]);

translate([10, 45, 0]) cube([1, 1, 5.200242563826294]);

translate([11, 45, 0]) cube([1, 1, 5.300109461841888]);

translate([12, 45, 0]) cube([1, 1, 5.4000298869719225]);

color([0,1,0])
translate([13, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 45, 0]) cube([1, 1, 6]);

translate([16, 45, 0]) cube([1, 1, 5.400000066964644]);

translate([17, 45, 0]) cube([1, 1, 5.300000015669294]);

translate([18, 45, 0]) cube([1, 1, 5.200000003280226]);

translate([19, 45, 0]) cube([1, 1, 5.2]);

translate([20, 45, 0]) cube([1, 1, 5.3]);

translate([21, 45, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([22, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 45, 0]) cube([1, 1, 6]);

translate([32, 45, 0]) cube([1, 1, 5.400000618970519]);

translate([33, 45, 0]) cube([1, 1, 5.300004753576898]);

translate([34, 45, 0]) cube([1, 1, 5.300005740216441]);

translate([35, 45, 0]) cube([1, 1, 5.400009297806623]);

translate([36, 45, 0]) cube([1, 1, 5.400015307155919]);

translate([37, 45, 0]) cube([1, 1, 5.400020321191425]);

translate([38, 45, 0]) cube([1, 1, 5.4000202833319815]);

translate([39, 45, 0]) cube([1, 1, 5.300035702080412]);

translate([40, 45, 0]) cube([1, 1, 5.300039367004046]);

translate([41, 45, 0]) cube([1, 1, 5.300045543140869]);

color([0,1,0])
translate([42, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 45, 0]) cube([1, 1, 6]);

translate([0, 46, 0]) cube([1, 1, 5.300003153035048]);

translate([1, 46, 0]) cube([1, 1, 5.300004760941599]);

translate([2, 46, 0]) cube([1, 1, 5.300009765836513]);

translate([3, 46, 0]) cube([1, 1, 5.300016808682319]);

translate([4, 46, 0]) cube([1, 1, 5.300033639284041]);

translate([5, 46, 0]) cube([1, 1, 5.3000471531894435]);

translate([6, 46, 0]) cube([1, 1, 5.200140639924326]);

translate([7, 46, 0]) cube([1, 1, 5.100265343630563]);

translate([8, 46, 0]) cube([1, 1, 5.000403342451435]);

translate([9, 46, 0]) cube([1, 1, 4.9006086892699985]);

translate([10, 46, 0]) cube([1, 1, 5.000205520604586]);

translate([11, 46, 0]) cube([1, 1, 5.100081146301614]);

translate([12, 46, 0]) cube([1, 1, 5.200023822383552]);

translate([13, 46, 0]) cube([1, 1, 5.2000116666605365]);

translate([14, 46, 0]) cube([1, 1, 5.200003312454315]);

translate([15, 46, 0]) cube([1, 1, 5.100000937542204]);

translate([16, 46, 0]) cube([1, 1, 5.000000258283208]);

translate([17, 46, 0]) cube([1, 1, 4.900000068737367]);

translate([18, 46, 0]) cube([1, 1, 4.800000021708883]);

translate([19, 46, 0]) cube([1, 1, 4.9]);

translate([20, 46, 0]) cube([1, 1, 5.0]);

translate([21, 46, 0]) cube([1, 1, 5.2]);

translate([22, 46, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([23, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 46, 0]) cube([1, 1, 6]);

translate([32, 46, 0]) cube([1, 1, 5.4000001233023465]);

translate([33, 46, 0]) cube([1, 1, 5.20000522760765]);

translate([34, 46, 0]) cube([1, 1, 5.2000061075829045]);

translate([35, 46, 0]) cube([1, 1, 5.2000096468523935]);

translate([36, 46, 0]) cube([1, 1, 5.2000184799885885]);

translate([37, 46, 0]) cube([1, 1, 5.300014111224981]);

translate([38, 46, 0]) cube([1, 1, 5.300023342814423]);

translate([39, 46, 0]) cube([1, 1, 5.3000294064922295]);

translate([40, 46, 0]) cube([1, 1, 5.300033797931723]);

translate([41, 46, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([42, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 46, 0]) cube([1, 1, 6]);

translate([0, 47, 0]) cube([1, 1, 5.200003956459301]);

translate([1, 47, 0]) cube([1, 1, 5.100060186355627]);

translate([2, 47, 0]) cube([1, 1, 5.10006055136014]);

translate([3, 47, 0]) cube([1, 1, 5.200067767423387]);

translate([4, 47, 0]) cube([1, 1, 5.200079002209466]);

translate([5, 47, 0]) cube([1, 1, 5.200082353755172]);

translate([6, 47, 0]) cube([1, 1, 5.10026461405926]);

translate([7, 47, 0]) cube([1, 1, 5.000458141936515]);

translate([8, 47, 0]) cube([1, 1, 4.9006752802901765]);

translate([9, 47, 0]) cube([1, 1, 4.801479714397547]);

translate([10, 47, 0]) cube([1, 1, 4.801483251861126]);

translate([11, 47, 0]) cube([1, 1, 4.9001747789177825]);

translate([12, 47, 0]) cube([1, 1, 5.00003907147414]);

translate([13, 47, 0]) cube([1, 1, 5.000038646183368]);

translate([14, 47, 0]) cube([1, 1, 5.000027280978801]);

translate([15, 47, 0]) cube([1, 1, 4.900015894341076]);

translate([16, 47, 0]) cube([1, 1, 4.700008578744661]);

translate([17, 47, 0]) cube([1, 1, 4.600004462451207]);

translate([18, 47, 0]) cube([1, 1, 4.500004561714966]);

translate([19, 47, 0]) cube([1, 1, 4.6000000103972924]);

translate([20, 47, 0]) cube([1, 1, 4.8]);

translate([21, 47, 0]) cube([1, 1, 5.0]);

translate([22, 47, 0]) cube([1, 1, 5.2]);

translate([23, 47, 0]) cube([1, 1, 5.2]);

translate([24, 47, 0]) cube([1, 1, 5.2]);

translate([25, 47, 0]) cube([1, 1, 5.3]);

translate([26, 47, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([27, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 47, 0]) cube([1, 1, 6]);

translate([32, 47, 0]) cube([1, 1, 5.300000040446917]);

translate([33, 47, 0]) cube([1, 1, 5.100029808953893]);

translate([34, 47, 0]) cube([1, 1, 5.100029909020011]);

translate([35, 47, 0]) cube([1, 1, 5.100037237117902]);

translate([36, 47, 0]) cube([1, 1, 5.100046242658633]);

translate([37, 47, 0]) cube([1, 1, 5.2000342471597225]);

translate([38, 47, 0]) cube([1, 1, 5.200052945788004]);

translate([39, 47, 0]) cube([1, 1, 5.300030822452326]);

translate([40, 47, 0]) cube([1, 1, 5.300034927142851]);

translate([41, 47, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([42, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 47, 0]) cube([1, 1, 6]);

translate([46, 47, 0]) cube([1, 1, 5.4]);

translate([47, 47, 0]) cube([1, 1, 5.3]);
