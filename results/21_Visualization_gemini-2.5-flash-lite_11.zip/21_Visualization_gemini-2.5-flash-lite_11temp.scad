color([1, 0, 1]) hull()
{
  translate([5.025, 5.0, 4.975]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.4750000000000005, 5.0, 4.5249999999999995]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([5.525, 5.0, 4.475]) cube([0.4, 0.4, 0.1], center = true);
  translate([5.9750000000000005, 5.0, 4.025]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([6.025, 5.0, 3.975]) cube([0.4, 0.4, 0.1], center = true);
  translate([6.4750000000000005, 5.0, 3.525]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([6.525, 5.0, 3.475]) cube([0.4, 0.4, 0.1], center = true);
  translate([6.975, 5.0, 3.0250000000000004]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.025, 5.0, 2.975]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.475, 5.0, 2.525]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([7.525, 5.0, 2.475]) cube([0.4, 0.4, 0.1], center = true);
  translate([7.9750000000000005, 5.0, 2.025]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.025, 5.0, 1.975]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.475, 5.0, 1.5250000000000001]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([8.525, 5.0, 1.475]) cube([0.4, 0.4, 0.1], center = true);
  translate([8.975, 5.0, 1.025]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([9.025, 5.0, 0.9750000000000001]) cube([0.4, 0.4, 0.1], center = true);
  translate([9.475000000000001, 5.0, 0.525]) cube([0.4, 0.4, 0.1], center = true);
}

hull()
{
  translate([9.525, 5.0, 0.47500000000000003]) cube([0.4, 0.4, 0.1], center = true);
  translate([9.975, 5.0, 0.025]) cube([0.4, 0.4, 0.1], center = true);
}
