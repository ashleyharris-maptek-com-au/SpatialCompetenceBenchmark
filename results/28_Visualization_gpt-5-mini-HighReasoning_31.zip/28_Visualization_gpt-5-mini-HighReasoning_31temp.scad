
translate([0, 0, 0]) cube([1, 1, 5.00000333635294]);

translate([1, 0, 0]) cube([1, 1, 4.4000226741610815]);

translate([2, 0, 0]) cube([1, 1, 4.200094662383443]);

translate([3, 0, 0]) cube([1, 1, 4.1002892641370705]);

translate([4, 0, 0]) cube([1, 1, 4.000548133893897]);

translate([5, 0, 0]) cube([1, 1, 3.906442691331152]);

translate([6, 0, 0]) cube([1, 1, 3.906442698506532]);

translate([7, 0, 0]) cube([1, 1, 4.002438561325339]);

translate([8, 0, 0]) cube([1, 1, 4.200450274133797]);

translate([9, 0, 0]) cube([1, 1, 4.4]);

translate([10, 0, 0]) cube([1, 1, 4.5]);

translate([11, 0, 0]) cube([1, 1, 4.3]);

translate([12, 0, 0]) cube([1, 1, 4.2]);

translate([13, 0, 0]) cube([1, 1, 4.2]);

translate([14, 0, 0]) cube([1, 1, 4.4]);

translate([15, 0, 0]) cube([1, 1, 4.8]);

translate([16, 0, 0]) cube([1, 1, 5.0]);

translate([17, 0, 0]) cube([1, 1, 5.2]);

translate([18, 0, 0]) cube([1, 1, 5.3]);

translate([19, 0, 0]) cube([1, 1, 5.4]);

translate([20, 0, 0]) cube([1, 1, 5.4]);

translate([21, 0, 0]) cube([1, 1, 5.2]);

translate([22, 0, 0]) cube([1, 1, 4.9]);

translate([23, 0, 0]) cube([1, 1, 4.6]);

translate([24, 0, 0]) cube([1, 1, 4.4]);

translate([25, 0, 0]) cube([1, 1, 4.3]);

translate([26, 0, 0]) cube([1, 1, 4.3]);

translate([27, 0, 0]) cube([1, 1, 4.3]);

translate([28, 0, 0]) cube([1, 1, 4.4]);

translate([29, 0, 0]) cube([1, 1, 4.6]);

translate([30, 0, 0]) cube([1, 1, 4.7]);

translate([31, 0, 0]) cube([1, 1, 4.8]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.100006069113522]);

translate([2, 1, 0]) cube([1, 1, 4.7000353387258595]);

translate([3, 1, 0]) cube([1, 1, 4.500125243967318]);

translate([4, 1, 0]) cube([1, 1, 4.200323290359848]);

translate([5, 1, 0]) cube([1, 1, 4.000777931716664]);

translate([6, 1, 0]) cube([1, 1, 3.9064428102156774]);

translate([7, 1, 0]) cube([1, 1, 4.003487833573128]);

translate([8, 1, 0]) cube([1, 1, 4.10431950632819]);

translate([9, 1, 0]) cube([1, 1, 4.201801102811154]);

translate([10, 1, 0]) cube([1, 1, 4.201374753335856]);

translate([11, 1, 0]) cube([1, 1, 4.008504457923858]);

translate([12, 1, 0]) cube([1, 1, 3.9290418225309134]);

translate([13, 1, 0]) cube([1, 1, 3.929041826927538]);

translate([14, 1, 0]) cube([1, 1, 4.002016666964488]);

translate([15, 1, 0]) cube([1, 1, 4.3]);

translate([16, 1, 0]) cube([1, 1, 4.5]);

translate([17, 1, 0]) cube([1, 1, 4.6]);

translate([18, 1, 0]) cube([1, 1, 4.8]);

translate([19, 1, 0]) cube([1, 1, 4.9]);

translate([20, 1, 0]) cube([1, 1, 4.8]);

translate([21, 1, 0]) cube([1, 1, 4.7]);

translate([22, 1, 0]) cube([1, 1, 4.5]);

translate([23, 1, 0]) cube([1, 1, 4.4]);

translate([24, 1, 0]) cube([1, 1, 4.2]);

translate([25, 1, 0]) cube([1, 1, 4.0]);

translate([26, 1, 0]) cube([1, 1, 3.8]);

translate([27, 1, 0]) cube([1, 1, 3.7]);

translate([28, 1, 0]) cube([1, 1, 3.9]);

translate([29, 1, 0]) cube([1, 1, 4.0]);

translate([30, 1, 0]) cube([1, 1, 4.2]);

translate([31, 1, 0]) cube([1, 1, 4.3]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

translate([2, 2, 0]) cube([1, 1, 5.400027324241722]);

translate([3, 2, 0]) cube([1, 1, 5.10014088327212]);

translate([4, 2, 0]) cube([1, 1, 4.800422676100729]);

translate([5, 2, 0]) cube([1, 1, 4.500927657897145]);

translate([6, 2, 0]) cube([1, 1, 4.4017965884874295]);

translate([7, 2, 0]) cube([1, 1, 4.4015459516568605]);

translate([8, 2, 0]) cube([1, 1, 4.304897092547319]);

translate([9, 2, 0]) cube([1, 1, 4.204264101266775]);

translate([10, 2, 0]) cube([1, 1, 4.032643083116301]);

translate([11, 2, 0]) cube([1, 1, 3.948074476399179]);

translate([12, 2, 0]) cube([1, 1, 3.929044770604721]);

translate([13, 2, 0]) cube([1, 1, 3.9290420292751547]);

translate([14, 2, 0]) cube([1, 1, 3.929046419602935]);

translate([15, 2, 0]) cube([1, 1, 4.008066675905413]);

translate([16, 2, 0]) cube([1, 1, 4.207230472301265]);

translate([17, 2, 0]) cube([1, 1, 4.303213489081291]);

translate([18, 2, 0]) cube([1, 1, 4.400798287746206]);

translate([19, 2, 0]) cube([1, 1, 4.5]);

translate([20, 2, 0]) cube([1, 1, 4.4]);

translate([21, 2, 0]) cube([1, 1, 4.3]);

translate([22, 2, 0]) cube([1, 1, 4.2]);

translate([23, 2, 0]) cube([1, 1, 4.0]);

translate([24, 2, 0]) cube([1, 1, 4.0]);

translate([25, 2, 0]) cube([1, 1, 3.9]);

translate([26, 2, 0]) cube([1, 1, 3.6000116587458617]);

translate([27, 2, 0]) cube([1, 1, 3.400034185816328]);

translate([28, 2, 0]) cube([1, 1, 3.500000000589727]);

translate([29, 2, 0]) cube([1, 1, 3.8]);

translate([30, 2, 0]) cube([1, 1, 3.9]);

translate([31, 2, 0]) cube([1, 1, 3.8]);

translate([0, 3, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 3, 0]) cube([1, 1, 6]);

translate([4, 3, 0]) cube([1, 1, 5.400542989343515]);

translate([5, 3, 0]) cube([1, 1, 5.10130739536067]);

translate([6, 3, 0]) cube([1, 1, 5.002365237878293]);

translate([7, 3, 0]) cube([1, 1, 4.902973857348378]);

translate([8, 3, 0]) cube([1, 1, 4.702002879711572]);

translate([9, 3, 0]) cube([1, 1, 4.4179627781035045]);

translate([10, 3, 0]) cube([1, 1, 4.139365255919782]);

translate([11, 3, 0]) cube([1, 1, 4.04594569022887]);

translate([12, 3, 0]) cube([1, 1, 4.216389953270339]);

translate([13, 3, 0]) cube([1, 1, 4.306754761195255]);

translate([14, 3, 0]) cube([1, 1, 4.305528350219756]);

translate([15, 3, 0]) cube([1, 1, 4.207896000619394]);

translate([16, 3, 0]) cube([1, 1, 4.303545207615078]);

translate([17, 3, 0]) cube([1, 1, 4.401645795883955]);

translate([18, 3, 0]) cube([1, 1, 4.401258064075172]);

translate([19, 3, 0]) cube([1, 1, 4.3013020594821585]);

translate([20, 3, 0]) cube([1, 1, 4.2002604093575115]);

translate([21, 3, 0]) cube([1, 1, 4.100052079009277]);

translate([22, 3, 0]) cube([1, 1, 3.800297513801454]);

translate([23, 3, 0]) cube([1, 1, 3.6013996793240834]);

translate([24, 3, 0]) cube([1, 1, 3.6002799328574504]);

translate([25, 3, 0]) cube([1, 1, 3.600046653158069]);

translate([26, 3, 0]) cube([1, 1, 3.400090914186634]);

translate([27, 3, 0]) cube([1, 1, 3.3001116906984103]);

translate([28, 3, 0]) cube([1, 1, 3.4000085776474855]);

translate([29, 3, 0]) cube([1, 1, 3.600000003878624]);

translate([30, 3, 0]) cube([1, 1, 3.7]);

translate([31, 3, 0]) cube([1, 1, 3.60000000969656]);

translate([0, 4, 0]) cube([1, 1, 7.2]);

translate([1, 4, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 4, 0]) cube([1, 1, 6]);

translate([6, 4, 0]) cube([1, 1, 5.40346062748698]);

translate([7, 4, 0]) cube([1, 1, 5.305063525074424]);

translate([8, 4, 0]) cube([1, 1, 5.003979900104727]);

translate([9, 4, 0]) cube([1, 1, 4.638510615105766]);

translate([10, 4, 0]) cube([1, 1, 4.449688686846335]);

translate([11, 4, 0]) cube([1, 1, 4.447034846668325]);

translate([12, 4, 0]) cube([1, 1, 4.618519591562699]);

translate([13, 4, 0]) cube([1, 1, 4.809640571175044]);

translate([14, 4, 0]) cube([1, 1, 4.807955050326555]);

translate([15, 4, 0]) cube([1, 1, 4.707704728947865]);

translate([16, 4, 0]) cube([1, 1, 4.705011128323224]);

translate([17, 4, 0]) cube([1, 1, 4.7025440182156295]);

translate([18, 4, 0]) cube([1, 1, 4.403151891565547]);

translate([19, 4, 0]) cube([1, 1, 4.103737769115773]);

translate([20, 4, 0]) cube([1, 1, 4.006515451672388]);

translate([21, 4, 0]) cube([1, 1, 3.901137988453182]);

translate([22, 4, 0]) cube([1, 1, 3.6053012115200644]);

translate([23, 4, 0]) cube([1, 1, 3.4601786454626415]);

translate([24, 4, 0]) cube([1, 1, 3.460179835065315]);

translate([25, 4, 0]) cube([1, 1, 3.5001577309865524]);

translate([26, 4, 0]) cube([1, 1, 3.4001582160642787]);

translate([27, 4, 0]) cube([1, 1, 3.2007949118152204]);

translate([28, 4, 0]) cube([1, 1, 3.300107705519391]);

translate([29, 4, 0]) cube([1, 1, 3.5000001358769963]);

translate([30, 4, 0]) cube([1, 1, 3.6000000210310956]);

translate([31, 4, 0]) cube([1, 1, 3.5000001732251897]);

translate([0, 5, 0]) cube([1, 1, 7.4]);

translate([1, 5, 0]) cube([1, 1, 6.9]);

translate([2, 5, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 5, 0]) cube([1, 1, 6]);

translate([8, 5, 0]) cube([1, 1, 5.312646894488413]);

translate([9, 5, 0]) cube([1, 1, 4.956358480446372]);

translate([10, 5, 0]) cube([1, 1, 4.779054308842074]);

translate([11, 5, 0]) cube([1, 1, 4.9423981821378264]);

translate([12, 5, 0]) cube([1, 1, 5.1262322838005705]);

translate([13, 5, 0]) cube([1, 1, 5.314326923240526]);

translate([14, 5, 0]) cube([1, 1, 5.3112581209860545]);

translate([15, 5, 0]) cube([1, 1, 5.110575741715508]);

translate([16, 5, 0]) cube([1, 1, 5.105256925790405]);

translate([17, 5, 0]) cube([1, 1, 4.90499606160018]);

translate([18, 5, 0]) cube([1, 1, 4.508978657035081]);

translate([19, 5, 0]) cube([1, 1, 4.020709500870648]);

translate([20, 5, 0]) cube([1, 1, 3.8182715876184754]);

translate([21, 5, 0]) cube([1, 1, 3.7250184828269]);

translate([22, 5, 0]) cube([1, 1, 3.561623172571167]);

translate([23, 5, 0]) cube([1, 1, 3.4601844830152553]);

translate([24, 5, 0]) cube([1, 1, 3.4601847670976977]);

translate([25, 5, 0]) cube([1, 1, 3.5003844063460243]);

translate([26, 5, 0]) cube([1, 1, 3.500191714797834]);

translate([27, 5, 0]) cube([1, 1, 3.400093305511802]);

translate([28, 5, 0]) cube([1, 1, 3.4000327958219305]);

translate([29, 5, 0]) cube([1, 1, 3.50000043680477]);

translate([30, 5, 0]) cube([1, 1, 3.600000082019376]);

translate([31, 5, 0]) cube([1, 1, 3.6000000607040388]);

translate([0, 6, 0]) cube([1, 1, 7.7]);

translate([1, 6, 0]) cube([1, 1, 7.2]);

translate([2, 6, 0]) cube([1, 1, 7.0]);

translate([3, 6, 0]) cube([1, 1, 6.8]);

translate([4, 6, 0]) cube([1, 1, 6.500009793871253]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 6, 0]) cube([1, 1, 6]);

translate([9, 6, 0]) cube([1, 1, 5.269216753520503]);

translate([10, 6, 0]) cube([1, 1, 5.1939333741966935]);

translate([11, 6, 0]) cube([1, 1, 5.3543104482728365]);

color([0,1,0])
translate([12, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 6, 0]) cube([1, 1, 6]);

translate([16, 6, 0]) cube([1, 1, 5.311699050045058]);

translate([17, 6, 0]) cube([1, 1, 5.013020400259875]);

translate([18, 6, 0]) cube([1, 1, 4.530326909785809]);

translate([19, 6, 0]) cube([1, 1, 4.04098564346946]);

translate([20, 6, 0]) cube([1, 1, 3.799167393101095]);

translate([21, 6, 0]) cube([1, 1, 3.63949071569019]);

translate([22, 6, 0]) cube([1, 1, 3.5840972744140376]);

translate([23, 6, 0]) cube([1, 1, 3.557043208657112]);

translate([24, 6, 0]) cube([1, 1, 3.6016966066621285]);

translate([25, 6, 0]) cube([1, 1, 3.7005144033989246]);

translate([26, 6, 0]) cube([1, 1, 3.8000191038073243]);

translate([27, 6, 0]) cube([1, 1, 3.9000029691358025]);

translate([28, 6, 0]) cube([1, 1, 3.8000012340740743]);

translate([29, 6, 0]) cube([1, 1, 3.8000003230123456]);

translate([30, 6, 0]) cube([1, 1, 3.800000088839506]);

translate([31, 6, 0]) cube([1, 1, 3.700000037851852]);

translate([0, 7, 0]) cube([1, 1, 8.0]);

translate([1, 7, 0]) cube([1, 1, 7.5]);

translate([2, 7, 0]) cube([1, 1, 7.3]);

translate([3, 7, 0]) cube([1, 1, 7.0]);

translate([4, 7, 0]) cube([1, 1, 6.8]);

translate([5, 7, 0]) cube([1, 1, 6.500048969356261]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 7, 0]) cube([1, 1, 6]);

translate([16, 7, 0]) cube([1, 1, 5.42116643166312]);

translate([17, 7, 0]) cube([1, 1, 4.962635927418911]);

translate([18, 7, 0]) cube([1, 1, 4.664988068668337]);

translate([19, 7, 0]) cube([1, 1, 4.253434588924776]);

translate([20, 7, 0]) cube([1, 1, 3.9071984117465464]);

translate([21, 7, 0]) cube([1, 1, 3.8101647230267646]);

translate([22, 7, 0]) cube([1, 1, 3.8407340917435087]);

translate([23, 7, 0]) cube([1, 1, 4.005430641363563]);

translate([24, 7, 0]) cube([1, 1, 4.0024627787369065]);

translate([25, 7, 0]) cube([1, 1, 4.100075216208019]);

translate([26, 7, 0]) cube([1, 1, 4.300014927417882]);

translate([27, 7, 0]) cube([1, 1, 4.400002407407407]);

translate([28, 7, 0]) cube([1, 1, 4.300000481481481]);

translate([29, 7, 0]) cube([1, 1, 4.2000000962962964]);

translate([30, 7, 0]) cube([1, 1, 4.100000019259259]);

translate([31, 7, 0]) cube([1, 1, 4.000000006172839]);

translate([0, 8, 0]) cube([1, 1, 7.9]);

translate([1, 8, 0]) cube([1, 1, 7.5]);

translate([2, 8, 0]) cube([1, 1, 7.3]);

translate([3, 8, 0]) cube([1, 1, 7.0]);

translate([4, 8, 0]) cube([1, 1, 6.8]);

translate([5, 8, 0]) cube([1, 1, 6.600026868386243]);

translate([6, 8, 0]) cube([1, 1, 6.50021797839506]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

translate([8, 8, 0]) cube([1, 1, 5.465517651533463]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

translate([11, 8, 0]) cube([1, 1, 5.2539987029508515]);

color([0,1,0])
translate([12, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 8, 0]) cube([1, 1, 6]);

translate([14, 8, 0]) cube([1, 1, 5.377058393156016]);

color([0,1,0])
translate([15, 8, 0]) cube([1, 1, 6]);

translate([16, 8, 0]) cube([1, 1, 5.4325906211979005]);

translate([17, 8, 0]) cube([1, 1, 4.31342697963343]);

translate([18, 8, 0]) cube([1, 1, 4.782183415859259]);

translate([19, 8, 0]) cube([1, 1, 4.489674557189036]);

translate([20, 8, 0]) cube([1, 1, 3.830972882669369]);

translate([21, 8, 0]) cube([1, 1, 4.09475441606974]);

translate([22, 8, 0]) cube([1, 1, 4.228296375353407]);

translate([23, 8, 0]) cube([1, 1, 4.503998554335744]);

translate([24, 8, 0]) cube([1, 1, 4.600288925792836]);

translate([25, 8, 0]) cube([1, 1, 4.600057784500706]);

translate([26, 8, 0]) cube([1, 1, 4.600014445813343]);

translate([27, 8, 0]) cube([1, 1, 4.7]);

translate([28, 8, 0]) cube([1, 1, 4.6]);

translate([29, 8, 0]) cube([1, 1, 4.5]);

translate([30, 8, 0]) cube([1, 1, 4.5]);

translate([31, 8, 0]) cube([1, 1, 4.4]);

translate([0, 9, 0]) cube([1, 1, 7.9]);

translate([1, 9, 0]) cube([1, 1, 7.4]);

translate([2, 9, 0]) cube([1, 1, 7.1]);

translate([3, 9, 0]) cube([1, 1, 6.9]);

translate([4, 9, 0]) cube([1, 1, 6.600020782811581]);

translate([5, 9, 0]) cube([1, 1, 6.500235959545854]);

translate([6, 9, 0]) cube([1, 1, 6.600148809523809]);

translate([7, 9, 0]) cube([1, 1, 6.700892857142858]);

translate([8, 9, 0]) cube([1, 1, 6.507291666666666]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 9, 0]) cube([1, 1, 6]);

translate([17, 9, 0]) cube([1, 1, 5.1363082893739245]);

translate([18, 9, 0]) cube([1, 1, 4.962934356017264]);

translate([19, 9, 0]) cube([1, 1, 4.78172359237319]);

translate([20, 9, 0]) cube([1, 1, 4.566868798677392]);

translate([21, 9, 0]) cube([1, 1, 4.467779473752098]);

translate([22, 9, 0]) cube([1, 1, 4.71797029359073]);

translate([23, 9, 0]) cube([1, 1, 5.001733559777687]);

translate([24, 9, 0]) cube([1, 1, 5.1]);

translate([25, 9, 0]) cube([1, 1, 5.1]);

translate([26, 9, 0]) cube([1, 1, 5.0]);

translate([27, 9, 0]) cube([1, 1, 4.9]);

translate([28, 9, 0]) cube([1, 1, 4.8]);

translate([29, 9, 0]) cube([1, 1, 4.8]);

translate([30, 9, 0]) cube([1, 1, 4.9]);

translate([31, 9, 0]) cube([1, 1, 4.9]);

translate([0, 10, 0]) cube([1, 1, 8.0]);

translate([1, 10, 0]) cube([1, 1, 7.5]);

translate([2, 10, 0]) cube([1, 1, 7.1]);

translate([3, 10, 0]) cube([1, 1, 6.7]);

translate([4, 10, 0]) cube([1, 1, 6.600020553167254]);

translate([5, 10, 0]) cube([1, 1, 6.600040302579365]);

translate([6, 10, 0]) cube([1, 1, 6.8]);

translate([7, 10, 0]) cube([1, 1, 6.9]);

translate([8, 10, 0]) cube([1, 1, 6.705357142857143]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 10, 0]) cube([1, 1, 6]);

translate([17, 10, 0]) cube([1, 1, 5.1681817663396314]);

translate([18, 10, 0]) cube([1, 1, 4.992755805405249]);

translate([19, 10, 0]) cube([1, 1, 4.875009407247205]);

translate([20, 10, 0]) cube([1, 1, 4.798160892285002]);

translate([21, 10, 0]) cube([1, 1, 4.779450104132852]);

translate([22, 10, 0]) cube([1, 1, 5.108667810185668]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 10, 0]) cube([1, 1, 6]);

translate([26, 10, 0]) cube([1, 1, 5.4]);

translate([27, 10, 0]) cube([1, 1, 5.2]);

translate([28, 10, 0]) cube([1, 1, 5.1]);

translate([29, 10, 0]) cube([1, 1, 5.1]);

translate([30, 10, 0]) cube([1, 1, 5.3]);

translate([31, 10, 0]) cube([1, 1, 5.4]);

translate([0, 11, 0]) cube([1, 1, 8.2]);

translate([1, 11, 0]) cube([1, 1, 7.7]);

translate([2, 11, 0]) cube([1, 1, 7.2]);

translate([3, 11, 0]) cube([1, 1, 6.9]);

translate([4, 11, 0]) cube([1, 1, 6.9]);

translate([5, 11, 0]) cube([1, 1, 7.0]);

translate([6, 11, 0]) cube([1, 1, 7.2]);

translate([7, 11, 0]) cube([1, 1, 7.1]);

color([0,1,0])
translate([8, 11, 0]) cube([1, 1, 6]);

translate([9, 11, 0]) cube([1, 1, 6.566571276360111]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

translate([17, 11, 0]) cube([1, 1, 4.738184820118264]);

translate([18, 11, 0]) cube([1, 1, 5.088193337203012]);

translate([19, 11, 0]) cube([1, 1, 4.986719097987619]);

translate([20, 11, 0]) cube([1, 1, 4.6139582045291085]);

translate([21, 11, 0]) cube([1, 1, 4.861675503653858]);

translate([22, 11, 0]) cube([1, 1, 5.2020068698396384]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 11, 0]) cube([1, 1, 6]);

translate([0, 12, 0]) cube([1, 1, 8.2]);

translate([1, 12, 0]) cube([1, 1, 7.7]);

translate([2, 12, 0]) cube([1, 1, 7.3]);

translate([3, 12, 0]) cube([1, 1, 7.2]);

translate([4, 12, 0]) cube([1, 1, 7.3]);

translate([5, 12, 0]) cube([1, 1, 7.4]);

translate([6, 12, 0]) cube([1, 1, 7.5]);

translate([7, 12, 0]) cube([1, 1, 7.2]);

translate([8, 12, 0]) cube([1, 1, 6.906588385916781]);

translate([9, 12, 0]) cube([1, 1, 6.668689216611609]);

translate([10, 12, 0]) cube([1, 1, 6.6406144935578935]);

translate([11, 12, 0]) cube([1, 1, 6.619371649537677]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

translate([17, 12, 0]) cube([1, 1, 5.374013214235067]);

translate([18, 12, 0]) cube([1, 1, 5.19389665325563]);

translate([19, 12, 0]) cube([1, 1, 5.081394670244548]);

translate([20, 12, 0]) cube([1, 1, 4.988776376568264]);

translate([21, 12, 0]) cube([1, 1, 5.0427721562323695]);

translate([22, 12, 0]) cube([1, 1, 5.31003436071546]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 12, 0]) cube([1, 1, 6]);

translate([0, 13, 0]) cube([1, 1, 8.1]);

translate([1, 13, 0]) cube([1, 1, 7.7]);

translate([2, 13, 0]) cube([1, 1, 7.5]);

translate([3, 13, 0]) cube([1, 1, 7.5]);

translate([4, 13, 0]) cube([1, 1, 7.6]);

translate([5, 13, 0]) cube([1, 1, 7.6]);

translate([6, 13, 0]) cube([1, 1, 7.6]);

translate([7, 13, 0]) cube([1, 1, 7.3]);

translate([8, 13, 0]) cube([1, 1, 7.006275262917238]);

translate([9, 13, 0]) cube([1, 1, 6.845433305478569]);

translate([10, 13, 0]) cube([1, 1, 6.81997055731689]);

translate([11, 13, 0]) cube([1, 1, 6.825527007430009]);

translate([12, 13, 0]) cube([1, 1, 6.635526066773495]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

translate([18, 13, 0]) cube([1, 1, 5.456370568880872]);

translate([19, 13, 0]) cube([1, 1, 5.366218402152195]);

translate([20, 13, 0]) cube([1, 1, 5.270522658322664]);

translate([21, 13, 0]) cube([1, 1, 5.266626743056823]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 13, 0]) cube([1, 1, 6]);

translate([27, 13, 0]) cube([1, 1, 6.6]);

translate([28, 13, 0]) cube([1, 1, 6.7]);

translate([29, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([30, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 13, 0]) cube([1, 1, 6]);

translate([0, 14, 0]) cube([1, 1, 8.2]);

translate([1, 14, 0]) cube([1, 1, 7.8]);

translate([2, 14, 0]) cube([1, 1, 7.7]);

translate([3, 14, 0]) cube([1, 1, 7.6]);

translate([4, 14, 0]) cube([1, 1, 7.6]);

translate([5, 14, 0]) cube([1, 1, 7.5]);

translate([6, 14, 0]) cube([1, 1, 7.4]);

translate([7, 14, 0]) cube([1, 1, 7.2]);

translate([8, 14, 0]) cube([1, 1, 6.210282811905489]);

translate([9, 14, 0]) cube([1, 1, 7.010697302240513]);

translate([10, 14, 0]) cube([1, 1, 7.0071344878829445]);

translate([11, 14, 0]) cube([1, 1, 6.14843148920323]);

translate([12, 14, 0]) cube([1, 1, 6.63910339984894]);

translate([13, 14, 0]) cube([1, 1, 6.524232646142882]);

color([0,1,0])
translate([14, 14, 0]) cube([1, 1, 6]);

translate([15, 14, 0]) cube([1, 1, 6.535876013707414]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

translate([17, 14, 0]) cube([1, 1, 5.268677635813682]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

translate([20, 14, 0]) cube([1, 1, 4.86228674753755]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 14, 0]) cube([1, 1, 6]);

translate([27, 14, 0]) cube([1, 1, 6.9]);

translate([28, 14, 0]) cube([1, 1, 7.0]);

translate([29, 14, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([30, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 14, 0]) cube([1, 1, 6]);

translate([0, 15, 0]) cube([1, 1, 8.1]);

translate([1, 15, 0]) cube([1, 1, 7.8]);

translate([2, 15, 0]) cube([1, 1, 7.7]);

translate([3, 15, 0]) cube([1, 1, 7.5]);

translate([4, 15, 0]) cube([1, 1, 7.3]);

translate([5, 15, 0]) cube([1, 1, 7.1]);

translate([6, 15, 0]) cube([1, 1, 6.9068571428571435]);

translate([7, 15, 0]) cube([1, 1, 6.843924246736852]);

translate([8, 15, 0]) cube([1, 1, 6.941335519398544]);

translate([9, 15, 0]) cube([1, 1, 6.935244726154181]);

translate([10, 15, 0]) cube([1, 1, 6.908846086046273]);

translate([11, 15, 0]) cube([1, 1, 6.733519701452147]);

translate([12, 15, 0]) cube([1, 1, 6.559807732802489]);

translate([13, 15, 0]) cube([1, 1, 6.541181916076574]);

translate([14, 15, 0]) cube([1, 1, 6.5431276303969]);

translate([15, 15, 0]) cube([1, 1, 6.608053465681556]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 15, 0]) cube([1, 1, 6]);

translate([27, 15, 0]) cube([1, 1, 6.8]);

translate([28, 15, 0]) cube([1, 1, 6.9]);

translate([29, 15, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([30, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 15, 0]) cube([1, 1, 6]);

translate([0, 16, 0]) cube([1, 1, 7.7]);

translate([1, 16, 0]) cube([1, 1, 7.4]);

translate([2, 16, 0]) cube([1, 1, 7.3]);

translate([3, 16, 0]) cube([1, 1, 7.2]);

translate([4, 16, 0]) cube([1, 1, 7.0]);

translate([5, 16, 0]) cube([1, 1, 6.701371428571429]);

translate([6, 16, 0]) cube([1, 1, 6.5160870755642355]);

translate([7, 16, 0]) cube([1, 1, 6.526956844635737]);

translate([8, 16, 0]) cube([1, 1, 6.627905953641931]);

translate([9, 16, 0]) cube([1, 1, 6.719025275920085]);

translate([10, 16, 0]) cube([1, 1, 6.809700048001426]);

translate([11, 16, 0]) cube([1, 1, 6.623850600795703]);

translate([12, 16, 0]) cube([1, 1, 6.5626626655110645]);

translate([13, 16, 0]) cube([1, 1, 6.553271147140572]);

translate([14, 16, 0]) cube([1, 1, 6.558623759409808]);

translate([15, 16, 0]) cube([1, 1, 6.627472994048691]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 16, 0]) cube([1, 1, 6]);

translate([28, 16, 0]) cube([1, 1, 6.7]);

translate([29, 16, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([30, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 16, 0]) cube([1, 1, 6]);

translate([0, 17, 0]) cube([1, 1, 7.1]);

translate([1, 17, 0]) cube([1, 1, 6.9]);

translate([2, 17, 0]) cube([1, 1, 6.9]);

translate([3, 17, 0]) cube([1, 1, 6.9]);

translate([4, 17, 0]) cube([1, 1, 6.700274285714286]);

color([0,1,0])
translate([5, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 17, 0]) cube([1, 1, 6]);

translate([8, 17, 0]) cube([1, 1, 5.488407770286195]);

color([0,1,0])
translate([9, 17, 0]) cube([1, 1, 6]);

translate([10, 17, 0]) cube([1, 1, 6.538163296917106]);

color([0,1,0])
translate([11, 17, 0]) cube([1, 1, 6]);

translate([12, 17, 0]) cube([1, 1, 6.5616150765533625]);

translate([13, 17, 0]) cube([1, 1, 6.615021717582764]);

translate([14, 17, 0]) cube([1, 1, 6.036838557249188]);

translate([15, 17, 0]) cube([1, 1, 6.634552505412516]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

translate([17, 17, 0]) cube([1, 1, 5.34332435490873]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

translate([19, 17, 0]) cube([1, 1, 5.496940178890204]);

translate([20, 17, 0]) cube([1, 1, 5.253327043450278]);

translate([21, 17, 0]) cube([1, 1, 5.424962859454594]);

color([0,1,0])
translate([22, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 17, 0]) cube([1, 1, 6]);

translate([0, 18, 0]) cube([1, 1, 6.8]);

translate([1, 18, 0]) cube([1, 1, 6.6]);

translate([2, 18, 0]) cube([1, 1, 6.6]);

translate([3, 18, 0]) cube([1, 1, 6.500054857142858]);

color([0,1,0])
translate([4, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 18, 0]) cube([1, 1, 6]);

translate([12, 18, 0]) cube([1, 1, 6.6094551336509895]);

translate([13, 18, 0]) cube([1, 1, 6.804557291666667]);

translate([14, 18, 0]) cube([1, 1, 6.9056640625000005]);

translate([15, 18, 0]) cube([1, 1, 6.804557291666667]);

color([0,1,0])
translate([16, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

translate([19, 18, 0]) cube([1, 1, 5.487245540325237]);

translate([20, 18, 0]) cube([1, 1, 5.397885432593781]);

translate([21, 18, 0]) cube([1, 1, 5.381989143242484]);

translate([22, 18, 0]) cube([1, 1, 5.382012403010541]);

color([0,1,0])
translate([23, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 6.8]);

translate([1, 19, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 19, 0]) cube([1, 1, 6]);

translate([7, 19, 0]) cube([1, 1, 5.493276503871283]);

color([0,1,0])
translate([8, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 19, 0]) cube([1, 1, 6]);

translate([13, 19, 0]) cube([1, 1, 6.9216796875]);

translate([14, 19, 0]) cube([1, 1, 7.1]);

translate([15, 19, 0]) cube([1, 1, 6.9216796875]);

translate([16, 19, 0]) cube([1, 1, 6.508678747106481]);

color([0,1,0])
translate([17, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);

translate([20, 19, 0]) cube([1, 1, 5.474689845126199]);

translate([21, 19, 0]) cube([1, 1, 5.382015304380828]);

translate([22, 19, 0]) cube([1, 1, 5.382027393932717]);

color([0,1,0])
translate([23, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 19, 0]) cube([1, 1, 6]);

translate([0, 20, 0]) cube([1, 1, 7.0]);

translate([1, 20, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([2, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 20, 0]) cube([1, 1, 6]);

translate([6, 20, 0]) cube([1, 1, 5.472765128174129]);

translate([7, 20, 0]) cube([1, 1, 5.488712189187999]);

translate([8, 20, 0]) cube([1, 1, 5.149443855676893]);

color([0,1,0])
translate([9, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 20, 0]) cube([1, 1, 6]);

translate([11, 20, 0]) cube([1, 1, 5.3741705819216365]);

color([0,1,0])
translate([12, 20, 0]) cube([1, 1, 6]);

translate([13, 20, 0]) cube([1, 1, 6.8289605034722225]);

translate([14, 20, 0]) cube([1, 1, 6.131014901620372]);

translate([15, 20, 0]) cube([1, 1, 6.825835503472223]);

color([0,1,0])
translate([16, 20, 0]) cube([1, 1, 6]);

translate([17, 20, 0]) cube([1, 1, 5.333858924594037]);

color([0,1,0])
translate([18, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

translate([20, 20, 0]) cube([1, 1, 4.943656903415022]);

translate([21, 20, 0]) cube([1, 1, 5.384774732934738]);

translate([22, 20, 0]) cube([1, 1, 5.3820336281754155]);

translate([23, 20, 0]) cube([1, 1, 5.402058201058202]);

color([0,1,0])
translate([24, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 20, 0]) cube([1, 1, 6]);

translate([31, 20, 0]) cube([1, 1, 5.3]);

translate([0, 21, 0]) cube([1, 1, 7.1]);

translate([1, 21, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 21, 0]) cube([1, 1, 6]);

translate([4, 21, 0]) cube([1, 1, 5.401947527787874]);

translate([5, 21, 0]) cube([1, 1, 5.372200511992275]);

translate([6, 21, 0]) cube([1, 1, 5.426841329183928]);

translate([7, 21, 0]) cube([1, 1, 5.495879246719556]);

color([0,1,0])
translate([8, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 21, 0]) cube([1, 1, 6]);

translate([13, 21, 0]) cube([1, 1, 6.728148509837963]);

translate([14, 21, 0]) cube([1, 1, 6.920833333333333]);

translate([15, 21, 0]) cube([1, 1, 6.63387767650463]);

color([0,1,0])
translate([16, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 21, 0]) cube([1, 1, 6]);

translate([22, 21, 0]) cube([1, 1, 5.382372808941349]);

translate([23, 21, 0]) cube([1, 1, 5.381363363478158]);

translate([24, 21, 0]) cube([1, 1, 5.3441157895273195]);

translate([25, 21, 0]) cube([1, 1, 5.344108060282493]);

color([0,1,0])
translate([26, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 21, 0]) cube([1, 1, 6]);

translate([30, 21, 0]) cube([1, 1, 5.4]);

translate([31, 21, 0]) cube([1, 1, 5.1]);

translate([0, 22, 0]) cube([1, 1, 7.1]);

translate([1, 22, 0]) cube([1, 1, 6.9]);

color([0,1,0])
translate([2, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 22, 0]) cube([1, 1, 6]);

translate([4, 22, 0]) cube([1, 1, 5.3488619495764596]);

translate([5, 22, 0]) cube([1, 1, 5.348862027241947]);

color([0,1,0])
translate([6, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 22, 0]) cube([1, 1, 6]);

translate([13, 22, 0]) cube([1, 1, 6.713894766348379]);

translate([14, 22, 0]) cube([1, 1, 6.806597222222222]);

translate([15, 22, 0]) cube([1, 1, 6.6156019422743055]);

color([0,1,0])
translate([16, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 22, 0]) cube([1, 1, 6]);

translate([24, 22, 0]) cube([1, 1, 5.400607061880752]);

translate([25, 22, 0]) cube([1, 1, 5.400202352639154]);

color([0,1,0])
translate([26, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 22, 0]) cube([1, 1, 6]);

translate([30, 22, 0]) cube([1, 1, 5.2]);

translate([31, 22, 0]) cube([1, 1, 4.9]);

translate([0, 23, 0]) cube([1, 1, 6.9]);

translate([1, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 23, 0]) cube([1, 1, 6]);

translate([4, 23, 0]) cube([1, 1, 5.401213547580719]);

color([0,1,0])
translate([5, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 23, 0]) cube([1, 1, 6]);

translate([12, 23, 0]) cube([1, 1, 6.702778953269676]);

translate([13, 23, 0]) cube([1, 1, 6.9]);

translate([14, 23, 0]) cube([1, 1, 7.0]);

translate([15, 23, 0]) cube([1, 1, 6.701099537037037]);

color([0,1,0])
translate([16, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 23, 0]) cube([1, 1, 6]);

translate([29, 23, 0]) cube([1, 1, 5.3]);

translate([30, 23, 0]) cube([1, 1, 5.0]);

translate([31, 23, 0]) cube([1, 1, 4.8]);

translate([0, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 24, 0]) cube([1, 1, 6]);

translate([11, 24, 0]) cube([1, 1, 6.700555790653936]);

translate([12, 24, 0]) cube([1, 1, 7.0]);

translate([13, 24, 0]) cube([1, 1, 7.1]);

translate([14, 24, 0]) cube([1, 1, 7.1]);

translate([15, 24, 0]) cube([1, 1, 6.600219907407407]);

color([0,1,0])
translate([16, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 24, 0]) cube([1, 1, 6]);

translate([27, 24, 0]) cube([1, 1, 5.4]);

translate([28, 24, 0]) cube([1, 1, 5.3]);

translate([29, 24, 0]) cube([1, 1, 5.0]);

translate([30, 24, 0]) cube([1, 1, 4.8]);

translate([31, 24, 0]) cube([1, 1, 4.6]);

color([0,1,0])
translate([0, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 25, 0]) cube([1, 1, 6]);

translate([10, 25, 0]) cube([1, 1, 6.500111158130787]);

translate([11, 25, 0]) cube([1, 1, 6.9]);

translate([12, 25, 0]) cube([1, 1, 7.2]);

translate([13, 25, 0]) cube([1, 1, 7.2]);

translate([14, 25, 0]) cube([1, 1, 7.0]);

translate([15, 25, 0]) cube([1, 1, 6.500043981481482]);

color([0,1,0])
translate([16, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 25, 0]) cube([1, 1, 6]);

translate([25, 25, 0]) cube([1, 1, 5.4]);

translate([26, 25, 0]) cube([1, 1, 5.4]);

translate([27, 25, 0]) cube([1, 1, 5.4]);

translate([28, 25, 0]) cube([1, 1, 5.2]);

translate([29, 25, 0]) cube([1, 1, 5.0]);

translate([30, 25, 0]) cube([1, 1, 4.7]);

translate([31, 25, 0]) cube([1, 1, 4.5]);

color([0,1,0])
translate([0, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 26, 0]) cube([1, 1, 6]);

translate([10, 26, 0]) cube([1, 1, 6.7]);

translate([11, 26, 0]) cube([1, 1, 6.9]);

translate([12, 26, 0]) cube([1, 1, 7.0]);

translate([13, 26, 0]) cube([1, 1, 6.9]);

translate([14, 26, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([15, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 26, 0]) cube([1, 1, 6]);

translate([25, 26, 0]) cube([1, 1, 5.4]);

translate([26, 26, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([27, 26, 0]) cube([1, 1, 6]);

translate([28, 26, 0]) cube([1, 1, 5.4]);

translate([29, 26, 0]) cube([1, 1, 5.3]);

translate([30, 26, 0]) cube([1, 1, 5.0]);

translate([31, 26, 0]) cube([1, 1, 4.7]);

color([0,1,0])
translate([0, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 27, 0]) cube([1, 1, 6]);

translate([9, 27, 0]) cube([1, 1, 6.6]);

translate([10, 27, 0]) cube([1, 1, 6.7]);

translate([11, 27, 0]) cube([1, 1, 6.7]);

translate([12, 27, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([13, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 27, 0]) cube([1, 1, 6]);

translate([31, 27, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([0, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 28, 0]) cube([1, 1, 6]);

translate([27, 28, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 29, 0]) cube([1, 1, 6]);

translate([26, 29, 0]) cube([1, 1, 5.4]);

translate([27, 29, 0]) cube([1, 1, 5.3]);

translate([28, 29, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([29, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 30, 0]) cube([1, 1, 6]);

translate([1, 30, 0]) cube([1, 1, 5.400000322155071]);

translate([2, 30, 0]) cube([1, 1, 5.4000009470856165]);

translate([3, 30, 0]) cube([1, 1, 5.40000215122747]);

translate([4, 30, 0]) cube([1, 1, 5.30000800153531]);

translate([5, 30, 0]) cube([1, 1, 5.2000140926342295]);

translate([6, 30, 0]) cube([1, 1, 5.100021522375265]);

translate([7, 30, 0]) cube([1, 1, 5.300008672770466]);

translate([8, 30, 0]) cube([1, 1, 5.4000028584095645]);

color([0,1,0])
translate([9, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 30, 0]) cube([1, 1, 6]);

translate([11, 30, 0]) cube([1, 1, 5.300000029241955]);

translate([12, 30, 0]) cube([1, 1, 5.200000079793239]);

translate([13, 30, 0]) cube([1, 1, 5.300000209470378]);

translate([14, 30, 0]) cube([1, 1, 5.400000315140033]);

color([0,1,0])
translate([15, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 30, 0]) cube([1, 1, 6]);

translate([22, 30, 0]) cube([1, 1, 5.3]);

translate([23, 30, 0]) cube([1, 1, 5.3]);

translate([24, 30, 0]) cube([1, 1, 5.4]);

translate([25, 30, 0]) cube([1, 1, 5.4]);

translate([26, 30, 0]) cube([1, 1, 5.3]);

translate([27, 30, 0]) cube([1, 1, 5.3]);

color([0,1,0])
translate([28, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 30, 0]) cube([1, 1, 6]);

translate([0, 31, 0]) cube([1, 1, 5.300000175422802]);

translate([1, 31, 0]) cube([1, 1, 5.200004278947804]);

translate([2, 31, 0]) cube([1, 1, 5.20000431472091]);

translate([3, 31, 0]) cube([1, 1, 5.300003699674774]);

translate([4, 31, 0]) cube([1, 1, 5.2000138903589725]);

translate([5, 31, 0]) cube([1, 1, 5.000028753171948]);

translate([6, 31, 0]) cube([1, 1, 4.900091557152578]);

translate([7, 31, 0]) cube([1, 1, 5.000018516200671]);

translate([8, 31, 0]) cube([1, 1, 5.100003979339655]);

translate([9, 31, 0]) cube([1, 1, 5.10000367593979]);

translate([10, 31, 0]) cube([1, 1, 5.000002109466764]);

translate([11, 31, 0]) cube([1, 1, 4.800001162697059]);

translate([12, 31, 0]) cube([1, 1, 4.700002115945558]);

translate([13, 31, 0]) cube([1, 1, 4.80000063474293]);

translate([14, 31, 0]) cube([1, 1, 5.100000666266476]);

translate([15, 31, 0]) cube([1, 1, 5.3000005124180705]);

translate([16, 31, 0]) cube([1, 1, 5.400000273364091]);

color([0,1,0])
translate([17, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 31, 0]) cube([1, 1, 6]);

translate([22, 31, 0]) cube([1, 1, 5.2]);

translate([23, 31, 0]) cube([1, 1, 5.1]);

translate([24, 31, 0]) cube([1, 1, 5.2]);

translate([25, 31, 0]) cube([1, 1, 5.2]);

translate([26, 31, 0]) cube([1, 1, 5.3]);

translate([27, 31, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([28, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 31, 0]) cube([1, 1, 6]);
