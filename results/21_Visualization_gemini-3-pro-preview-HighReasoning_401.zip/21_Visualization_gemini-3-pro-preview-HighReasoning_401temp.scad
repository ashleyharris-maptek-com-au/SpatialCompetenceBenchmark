
hull() {
    translate([46.99785000000001, 25.0687, 47.994]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.95915, 26.3053, 47.886]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.95055, 26.44255, 47.87400000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.834450000000004, 27.676450000000003, 47.766000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.8173, 27.813250000000004, 47.754000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.6247, 29.04175, 47.64600000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.59905, 29.1778, 47.63400000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.329950000000004, 30.398200000000003, 47.526]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.2958, 30.533200000000004, 47.514]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.950199999999995, 31.7428, 47.406]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.90755, 31.8765, 47.394]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.48545000000001, 33.0735, 47.286]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.434400000000004, 33.205600000000004, 47.274]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.937599999999996, 34.386399999999995, 47.166]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.878249999999994, 34.516549999999995, 47.153999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.306749999999994, 35.67845, 47.046]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.2392, 35.806400000000004, 47.034]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.5948, 36.94760000000001, 46.926]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.51925, 37.07305000000001, 46.914]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.80375, 38.18995, 46.806]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.7204, 38.31255, 46.794]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.9356, 39.40245, 46.686]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.84465, 39.5219, 46.674]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.99235, 40.582100000000004, 46.566]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.893950000000004, 40.69815, 46.554]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.97505, 41.72685, 46.446]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.869400000000006, 41.839150000000004, 46.434]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.8866, 42.83185, 46.326]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.77395, 42.94005, 46.314]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.72905, 43.89495, 46.206]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.60965, 43.998850000000004, 46.194]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.50535000000001, 44.91415000000001, 46.086]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.379450000000006, 45.013400000000004, 46.074]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.21755, 45.8846, 45.966]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.0854, 45.9789, 45.95400000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.8686, 46.8051, 45.84600000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.730500000000006, 46.89415, 45.83400000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.4615, 47.67085, 45.726000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.317699999999995, 47.7543, 45.714000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.9983, 48.47970000000001, 45.606]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.8491, 48.557300000000005, 45.594]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.4829, 49.228699999999996, 45.486]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.32865, 49.3002, 45.474]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.91835, 49.915800000000004, 45.366]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.7594, 49.98100000000001, 45.354]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.308600000000006, 50.539, 45.246]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.145350000000004, 50.597699999999996, 45.234]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.65765, 51.0963, 45.126]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.49045, 51.14835, 45.114]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.96855, 51.58665, 45.006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.79785, 51.63195, 44.994]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.24715, 52.00905, 44.886]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.073400000000003, 52.04750000000001, 44.874]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.4966, 52.362500000000004, 44.766]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.320149999999998, 52.394000000000005, 44.754]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.720850000000002, 52.646, 44.646]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.542150000000003, 52.6705, 44.634]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.924850000000003, 52.8595, 44.526]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.744350000000003, 52.876999999999995, 44.514]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.11265, 53.003, 44.406]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.93075, 53.01349999999999, 44.394]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.28825, 53.076499999999996, 44.286]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.1054, 53.07995, 44.274]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.4566, 53.07905, 44.166]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.27325, 53.075450000000004, 44.153999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.621749999999999, 53.01155, 44.046]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.4383, 53.001000000000005, 44.034000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.7877, 52.875, 43.92600000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.6046, 52.857600000000005, 43.91400000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.9594000000000005, 52.6704, 43.806000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.777100000000001, 52.64615, 43.794000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.1409000000000002, 52.39685, 43.686]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.9598, 52.3658, 43.674]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.3361999999999998, 52.056200000000004, 43.566]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1566999999999998, 52.018350000000005, 43.554]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.45070000000000005, 51.64665, 43.446]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.6282000000000001, 51.602000000000004, 43.434]) cube([0.4, 0.4, 0.1], center=true);
    translate([-2.2157999999999998, 51.17, 43.326]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-2.3909, 51.11865, 43.314]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.9551, 50.62635, 43.206]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.1274, 50.568349999999995, 43.194]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.6646, 50.01665, 43.086]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.83375, 49.95215, 43.074]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.3412500000000005, 49.34285, 42.966]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.50685, 49.27195, 42.954]) cube([0.4, 0.4, 0.1], center=true);
    translate([-8.980149999999998, 48.60505, 42.846000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-9.1418, 48.5279, 42.834]) cube([0.4, 0.4, 0.1], center=true);
    translate([-10.5782, 47.8061, 42.726]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-10.73555, 47.722899999999996, 42.714]) cube([0.4, 0.4, 0.1], center=true);
    translate([-12.13145, 46.947100000000006, 42.606]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-12.28415, 46.85795000000001, 42.594]) cube([0.4, 0.4, 0.1], center=true);
    translate([-13.636849999999999, 46.02905, 42.486]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-13.78455, 45.934149999999995, 42.474]) cube([0.4, 0.4, 0.1], center=true);
    translate([-15.09045, 45.05485, 42.366]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-15.232800000000001, 44.9544, 42.354]) cube([0.4, 0.4, 0.1], center=true);
    translate([-16.489200000000004, 44.0256, 42.246]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-16.6259, 43.9198, 42.23400000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-17.830099999999998, 42.9442, 42.126000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-17.960749999999997, 42.8333, 42.114000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([-19.108249999999998, 41.81270000000001, 42.00600000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-19.23255, 41.69690000000001, 41.99400000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-20.32245, 40.6331, 41.886]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-20.44015, 40.512649999999994, 41.874]) cube([0.4, 0.4, 0.1], center=true);
    translate([-21.46885, 39.40835, 41.766]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-21.57965, 39.283500000000004, 41.754]) cube([0.4, 0.4, 0.1], center=true);
    translate([-22.545350000000003, 38.1405, 41.646]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-22.649, 38.01155, 41.634]) cube([0.4, 0.4, 0.1], center=true);
    translate([-23.549, 36.83345, 41.526]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-23.64515, 36.7007, 41.514]) cube([0.4, 0.4, 0.1], center=true);
    translate([-24.47585, 35.4893, 41.406]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-24.56425, 35.35295, 41.394]) cube([0.4, 0.4, 0.1], center=true);
    translate([-25.32475, 34.110049999999994, 41.286]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-25.4052, 33.9704, 41.274]) cube([0.4, 0.4, 0.1], center=true);
    translate([-26.0928, 32.6996, 41.166]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-26.16505, 32.557, 41.153999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([-26.77795, 31.261, 41.046]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-26.841900000000003, 31.1157, 41.034]) cube([0.4, 0.4, 0.1], center=true);
    translate([-27.3801, 29.7963, 40.926]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-27.435650000000003, 29.64865, 40.914]) cube([0.4, 0.4, 0.1], center=true);
    translate([-27.897349999999996, 28.310350000000003, 40.806]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-27.9443, 28.160700000000002, 40.794]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.3277, 26.805300000000003, 40.686]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.3659, 26.653950000000002, 40.674]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.6701, 25.28505, 40.566]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.6995, 25.13235, 40.554]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.924500000000002, 23.75265, 40.446]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.945050000000002, 23.5989, 40.434]) cube([0.4, 0.4, 0.1], center=true);
    translate([-29.089949999999998, 22.211100000000002, 40.326]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-29.101599999999998, 22.05665, 40.31400000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-29.166400000000003, 20.664350000000002, 40.20600000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-29.169150000000002, 20.509500000000003, 40.19400000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-29.15385, 19.1145, 40.086000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-29.14765, 18.9596, 40.074000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([-29.05135, 17.5664, 39.966]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-29.036250000000003, 17.41175, 39.954]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.860750000000003, 16.021250000000002, 39.846000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.8368, 15.86715, 39.834]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.5812, 14.48385, 39.726]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.548450000000003, 14.33065, 39.714]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.214550000000003, 12.95635, 39.606]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.1731, 12.80425, 39.594]) cube([0.4, 0.4, 0.1], center=true);
    translate([-27.760900000000003, 11.440750000000001, 39.486]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-27.710800000000003, 11.29005, 39.474]) cube([0.4, 0.4, 0.1], center=true);
    translate([-27.2212, 9.94095, 39.366]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-27.16255, 9.79195, 39.354]) cube([0.4, 0.4, 0.1], center=true);
    translate([-26.59645, 8.45905, 39.246]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-26.52935, 8.312, 39.234]) cube([0.4, 0.4, 0.1], center=true);
    translate([-25.88765, 6.998, 39.126]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-25.8122, 6.8532, 39.114]) cube([0.4, 0.4, 0.1], center=true);
    translate([-25.0958, 5.5608, 39.006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-25.01215, 5.41855, 38.994]) cube([0.4, 0.4, 0.1], center=true);
    translate([-24.22285, 4.15045, 38.886]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-24.131249999999998, 4.011, 38.874]) cube([0.4, 0.4, 0.1], center=true);
    translate([-23.27175, 2.769, 38.766]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-23.17245, 2.6326, 38.754]) cube([0.4, 0.4, 0.1], center=true);
    translate([-22.24455, 1.4194000000000002, 38.646]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-22.13775, 1.2863000000000002, 38.634]) cube([0.4, 0.4, 0.1], center=true);
    translate([-21.143250000000002, 0.10370000000000001, 38.526]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-21.02915, -0.025799999999999997, 38.51400000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-19.96985, -1.1742000000000001, 38.406000000000006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-19.8487, -1.2998, 38.394000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([-18.7273, -2.4122000000000003, 38.28600000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-18.5993, -2.5337000000000005, 38.27400000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-17.4167, -3.6083000000000003, 38.166000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-17.282049999999998, -3.7254500000000004, 38.154]) cube([0.4, 0.4, 0.1], center=true);
    translate([-16.040950000000002, -4.75955, 38.046]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-15.8999, -4.87205, 38.034]) cube([0.4, 0.4, 0.1], center=true);
    translate([-14.6021, -5.86295, 37.926]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-14.4549, -5.97065, 37.914]) cube([0.4, 0.4, 0.1], center=true);
    translate([-13.103100000000001, -6.91835, 37.806]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-12.949950000000001, -7.021000000000001, 37.794]) cube([0.4, 0.4, 0.1], center=true);
    translate([-11.545050000000002, -7.921000000000001, 37.686]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-11.386200000000002, -8.0184, 37.674]) cube([0.4, 0.4, 0.1], center=true);
    translate([-9.931800000000003, -8.8716, 37.566]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-9.767550000000002, -8.963600000000001, 37.554]) cube([0.4, 0.4, 0.1], center=true);
    translate([-8.265450000000001, -9.7664, 37.446]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-8.09605, -9.8528, 37.434]) cube([0.4, 0.4, 0.1], center=true);
    translate([-6.54895, -10.6052, 37.326]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-6.3747, -10.68595, 37.314]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.7853, -11.38705, 37.206]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.6066, -11.462, 37.194]) cube([0.4, 0.4, 0.1], center=true);
    translate([-2.9794, -12.110000000000001, 37.086]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-2.7965999999999998, -12.178950000000002, 37.074]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.1334, -12.77205, 36.966]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.94685, -12.8349, 36.954]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.74785, -13.3731, 36.846000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9376500000000001, -13.429800000000002, 36.834]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.65935, -13.9122, 36.726]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.852, -13.9626, 36.714]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.598000000000001, -14.3874, 36.606]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.7931, -14.4314, 36.59400000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.5588999999999995, -14.7986, 36.486000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.75595, -14.836200000000002, 36.474000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.537049999999999, -15.145800000000001, 36.36600000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.7356, -15.176900000000002, 36.354000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.528400000000001, -15.427100000000001, 36.246]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.728000000000002, -15.451500000000001, 36.234]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.528, -15.640500000000001, 36.126]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.7282, -15.658150000000001, 36.114]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.531799999999999, -15.786850000000001, 36.006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.732149999999999, -15.79775, 35.994]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.534850000000002, -15.86525, 35.886]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.73485, -15.869299999999999, 35.874]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.53215, -15.8747, 35.766]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.731350000000003, -15.8719, 35.754]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.519650000000002, -15.8161, 35.646]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.717550000000003, -15.80655, 35.634]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.49145, -15.690449999999998, 35.526]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.6876, -15.67415, 35.514]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.4444, -15.49685, 35.406]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.6384, -15.4738, 35.394]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.3736, -15.236200000000002, 35.286]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.56495, -15.206500000000002, 35.274]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.27405, -14.909500000000001, 35.166]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.4623, -14.87325, 35.153999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.1417, -14.51775, 35.046]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.3264, -14.47505, 35.034]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.971600000000002, -14.06195, 34.926]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.152300000000004, -14.01295, 34.914]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.759699999999995, -13.544050000000002, 34.806]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.936049999999994, -13.488900000000001, 34.794]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.502950000000006, -12.9651, 34.686]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.67450000000001, -12.904, 34.674]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.1955, -12.328, 34.566]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.36185, -12.26115, 34.554]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.83515, -11.633849999999999, 34.446]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.996050000000004, -11.561399999999999, 34.434]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.41895, -10.884599999999999, 34.326]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.57405, -10.806799999999999, 34.314]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.942949999999996, -10.0832, 34.206]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.091899999999995, -10.000300000000001, 34.194]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.4041, -9.231700000000002, 34.086]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.5466, -9.14395, 34.074]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.7994, -8.33305, 33.966]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.93515, -8.2406, 33.954]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.12585, -7.3873999999999995, 33.846000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.25455, -7.2904, 33.834]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.38045, -6.3976, 33.726]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.501850000000005, -6.29625, 33.714]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.56115, -5.36475, 33.606]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.674949999999995, -5.2592, 33.594]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.66405, -4.290800000000001, 33.486]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.76995, -4.1813, 33.474]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.68705, -3.1787, 33.366]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.78485, -3.0655, 33.354]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.62815, -2.0305, 33.246]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.71765, -1.9139000000000002, 33.234]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.48535, -0.8501000000000001, 33.126]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.56635, -0.73035, 33.114]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.25665000000001, 0.36134999999999995, 33.006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.328950000000006, 0.484, 32.994]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.94005, 1.6, 32.886]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.00345, 1.7252, 32.874]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.533550000000005, 2.8628000000000005, 32.766]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.587950000000006, 2.9903000000000004, 32.754]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.03705, 4.1477, 32.646]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.0824, 4.2772, 32.634]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.449600000000004, 5.4508, 32.526]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.485800000000005, 5.581950000000001, 32.514]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.7702, 6.76905, 32.406]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.79715, 6.9016, 32.394]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.99785000000001, 8.1004, 32.286]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.0155, 8.23405, 32.274]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.1325, 9.440949999999999, 32.166]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.14085, 9.57535, 32.153999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.174150000000004, 10.787650000000001, 32.046]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.17315000000001, 10.922450000000001, 32.034]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.12185, 12.136550000000002, 31.926000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.1115, 12.271450000000002, 31.914]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.9765, 13.485550000000002, 31.806]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.956900000000005, 13.620250000000002, 31.794]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.7391, 14.830750000000002, 31.686]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.71025, 14.9649, 31.674]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.408750000000005, 16.1691, 31.566]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.3707, 16.302400000000002, 31.554000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.987300000000005, 17.497600000000002, 31.446000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.94015, 17.6297, 31.434000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.47485, 18.8123, 31.326000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.41865, 18.9429, 31.314000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.87235, 20.1111, 31.206]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.807249999999996, 20.2399, 31.194]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.181749999999994, 21.3901, 31.086]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.1079, 21.516750000000002, 31.073999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.4041, 22.64625, 30.966]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.321650000000005, 22.7705, 30.954]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.54135, 23.8775, 30.846]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.4505, 23.99905, 30.834]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.5955, 25.07995, 30.726]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.4964, 25.198500000000003, 30.714]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.5676, 26.2515, 30.606]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.46045, 26.36675, 30.594]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.460550000000005, 27.388250000000003, 30.486000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.345650000000006, 27.499950000000002, 30.474000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.27735, 28.489050000000002, 30.366000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.15485, 28.597050000000003, 30.354000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.01815, 29.55195, 30.246]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.88825, 29.656000000000002, 30.233999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.68675, 30.574, 30.126]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.5497, 30.67385, 30.114]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.2843, 31.553150000000002, 30.006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.14035, 31.64865, 29.994]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.81465, 32.48835, 29.886]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.664, 32.57935, 29.874]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.278, 33.377649999999996, 29.766000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.120850000000004, 33.463899999999995, 29.754000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.67815, 34.2181, 29.646]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.51475, 34.29945, 29.634]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.01625, 35.00955, 29.526000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.846849999999996, 35.08585, 29.514000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.29615, 35.74915, 29.406000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.12105, 35.8202, 29.394000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.519949999999994, 36.4358, 29.286]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.33945, 36.501400000000004, 29.274]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.691550000000003, 37.066599999999994, 29.166]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.506, 37.126599999999996, 29.154]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.814, 37.641400000000004, 29.046]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.6237, 37.69565000000001, 29.034]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.890300000000003, 38.15735, 28.926000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.69565, 38.20565, 28.914]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.92535, 38.613350000000004, 28.806]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.726750000000003, 38.655550000000005, 28.794000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.92225, 39.007450000000006, 28.686]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.72, 39.04345000000001, 28.674]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.884, 39.33955, 28.566000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.6785, 39.3693, 28.554000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.8155, 39.608700000000006, 28.446]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.6072, 39.63215, 28.434]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.7208, 39.81485, 28.326]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.5101, 39.832, 28.314]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.6039, 39.958000000000006, 28.206]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.3912, 39.96880000000001, 28.194]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.4688, 40.0372, 28.086]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.25455, 40.041599999999995, 28.073999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.32045, 40.0524, 27.966]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.1051, 40.0503, 27.954]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.1629, 40.00170000000001, 27.846]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.94685, 39.993100000000005, 27.834000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.0001500000000005, 39.886900000000004, 27.726]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.783900000000001, 39.871900000000004, 27.714]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.838100000000001, 39.7081, 27.606]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.62215, 39.68665, 27.594000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6808500000000004, 39.464349999999996, 27.486]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.46565, 39.43645, 27.474]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.53335, 39.15655, 27.366]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.3194, 39.1223, 27.354]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.5994000000000002, 38.785700000000006, 27.246]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.8116, 38.74515, 27.233999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.7123999999999997, 38.35185, 27.126]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.9223, 38.3051, 27.114]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.7997, 37.8569, 27.006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-6.00675, 37.804050000000004, 26.994]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.85625, 37.30095, 26.886]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-8.06, 37.2421, 26.874000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([-9.878, 36.6859, 26.766000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-10.07795, 36.6212, 26.754000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([-11.85905, 36.012800000000006, 26.646000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-12.0547, 35.942400000000006, 26.634000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([-13.795300000000001, 35.2836, 26.526]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-13.9862, 35.20765, 26.514]) cube([0.4, 0.4, 0.1], center=true);
    translate([-15.681799999999999, 34.49935, 26.406]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-15.86745, 34.417950000000005, 26.394]) cube([0.4, 0.4, 0.1], center=true);
    translate([-17.51355, 33.66105, 26.286]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-17.6935, 33.574400000000004, 26.274]) cube([0.4, 0.4, 0.1], center=true);
    translate([-19.2865, 32.7716, 26.166]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-19.46035, 32.679899999999996, 26.154]) cube([0.4, 0.4, 0.1], center=true);
    translate([-20.996650000000002, 31.8321, 26.046]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-21.16395, 31.735400000000002, 26.034]) cube([0.4, 0.4, 0.1], center=true);
    translate([-22.63905, 30.8426, 25.926000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-22.79935, 30.74105, 25.914]) cube([0.4, 0.4, 0.1], center=true);
    translate([-24.20965, 29.805950000000003, 25.806000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-24.362550000000002, 29.69975, 25.794000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([-25.70445, 28.72325, 25.686000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-25.8495, 28.6125, 25.674000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([-27.118500000000004, 27.595500000000005, 25.566]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-27.255250000000004, 27.480400000000003, 25.554]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.447750000000003, 26.4256, 25.446]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.575850000000003, 26.306350000000002, 25.434]) cube([0.4, 0.4, 0.1], center=true);
    translate([-29.68915, 25.21465, 25.326]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-29.8083, 25.091450000000002, 25.314]) cube([0.4, 0.4, 0.1], center=true);
    translate([-30.839699999999997, 23.96555, 25.206]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-30.94955, 23.8386, 25.194]) cube([0.4, 0.4, 0.1], center=true);
    translate([-31.89545, 22.6794, 25.086]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-31.99565, 22.5489, 25.073999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([-32.853350000000006, 21.359099999999998, 24.966]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-32.943650000000005, 21.225299999999997, 24.954]) cube([0.4, 0.4, 0.1], center=true);
    translate([-33.711349999999996, 20.0067, 24.846000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-33.79155, 19.8699, 24.834000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([-34.46745000000001, 18.6261, 24.726000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-34.53735, 18.4866, 24.714000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([-35.11965, 17.2194, 24.606]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-35.1791, 17.0774, 24.594]) cube([0.4, 0.4, 0.1], center=true);
    translate([-35.6669, 15.7886, 24.486]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-35.71575, 15.644350000000001, 24.474]) cube([0.4, 0.4, 0.1], center=true);
    translate([-36.10725, 14.33665, 24.366]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-36.14535, 14.19045, 24.354]) cube([0.4, 0.4, 0.1], center=true);
    translate([-36.43965, 12.86655, 24.246]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-36.4669, 12.71865, 24.233999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([-36.6631, 11.38035, 24.126]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-36.679449999999996, 11.23105, 24.114000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([-36.77755, 9.88195, 24.006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-36.783, 9.73155, 23.994]) cube([0.4, 0.4, 0.1], center=true);
    translate([-36.783, 8.37345, 23.886]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-36.77755, 8.2222, 23.874000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([-36.679449999999996, 6.857800000000001, 23.766000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-36.663199999999996, 6.70605, 23.754]) cube([0.4, 0.4, 0.1], center=true);
    translate([-36.468799999999995, 5.33895, 23.646]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-36.4418, 5.187, 23.634]) cube([0.4, 0.4, 0.1], center=true);
    translate([-36.1502, 3.819, 23.526]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-36.11245, 3.6672000000000002, 23.514]) cube([0.4, 0.4, 0.1], center=true);
    translate([-35.72455000000001, 2.3027999999999995, 23.406]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-35.67615000000001, 2.1514999999999995, 23.394]) cube([0.4, 0.4, 0.1], center=true);
    translate([-35.19284999999999, 0.7925, 23.286]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-35.133849999999995, 0.642, 23.274]) cube([0.4, 0.4, 0.1], center=true);
    translate([-34.555150000000005, -0.708, 23.166]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-34.4857, -0.8573500000000001, 23.154]) cube([0.4, 0.4, 0.1], center=true);
    translate([-33.8143, -2.19565, 23.046]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-33.7346, -2.34355, 23.034]) cube([0.4, 0.4, 0.1], center=true);
    translate([-32.9714, -3.66745, 22.926000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-32.88165, -3.8136, 22.914000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([-32.02935, -5.1204, 22.806]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-31.92975, -5.2645, 22.794]) cube([0.4, 0.4, 0.1], center=true);
    translate([-30.989250000000002, -6.5515, 22.686]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-30.880000000000003, -6.69325, 22.674]) cube([0.4, 0.4, 0.1], center=true);
    translate([-29.854, -7.957750000000001, 22.566]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-29.73545, -8.096850000000002, 22.554]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.62755, -9.33615, 22.446]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.500049999999998, -9.472299999999999, 22.434]) cube([0.4, 0.4, 0.1], center=true);
    translate([-27.31295, -10.6837, 22.326]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-27.1768, -10.816650000000001, 22.314]) cube([0.4, 0.4, 0.1], center=true);
    translate([-25.913200000000003, -11.99835, 22.206]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-25.768700000000003, -12.12785, 22.194]) cube([0.4, 0.4, 0.1], center=true);
    translate([-24.4313, -13.27715, 22.086]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-24.278699999999997, -13.4029, 22.073999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([-22.8693, -14.517100000000001, 21.966]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-22.7089, -14.63885, 21.954000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([-21.2311, -15.716149999999999, 21.846]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-21.063250000000004, -15.833649999999999, 21.834]) cube([0.4, 0.4, 0.1], center=true);
    translate([-19.519750000000002, -16.87135, 21.726]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-19.3448, -16.98435, 21.714]) cube([0.4, 0.4, 0.1], center=true);
    translate([-17.7392, -17.98065, 21.606]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-17.5575, -18.088900000000002, 21.594]) cube([0.4, 0.4, 0.1], center=true);
    translate([-15.892500000000002, -19.041100000000004, 21.486]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-15.704350000000002, -19.144350000000003, 21.474]) cube([0.4, 0.4, 0.1], center=true);
    translate([-13.98265, -20.05065, 21.366]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-13.788450000000001, -20.14865, 21.354]) cube([0.4, 0.4, 0.1], center=true);
    translate([-12.014550000000002, -21.006349999999998, 21.246]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-11.814750000000002, -21.0989, 21.233999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([-9.99225, -21.907100000000003, 21.126]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-9.78725, -21.99395, 21.114000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.91975, -22.74905, 21.006000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.70995, -22.830000000000002, 20.994000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.801050000000001, -23.532000000000004, 20.886]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.586850000000001, -23.60685, 20.874]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.64015, -24.25215, 20.766000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.422, -24.320700000000002, 20.754]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.4420000000000002, -24.9093, 20.646]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.22045, -24.971500000000002, 20.634]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.78745, -25.5025, 20.526]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.01185, -25.55815, 20.514]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.0431500000000002, -26.028850000000002, 20.406]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.2698500000000004, -26.07785, 20.394]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.3191500000000005, -26.489150000000002, 20.286]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.54755, -26.5314, 20.274]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.60945, -26.8806, 20.166]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.839, -26.9159, 20.154000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.908999999999999, -27.2021, 20.046000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.139249999999999, -27.230400000000003, 20.034000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.213750000000001, -27.4536, 19.926000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.444150000000002, -27.4749, 19.914]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.51685, -27.6351, 19.806]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.746849999999998, -27.64935, 19.794]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.814149999999998, -27.745650000000005, 19.686]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.0432, -27.752850000000002, 19.674]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.0988, -27.78615, 19.566]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.32635, -27.78635, 19.554]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.36665, -27.756649999999997, 19.446]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.59225, -27.74985, 19.434]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.612750000000002, -27.65715, 19.326]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.835850000000004, -27.64345, 19.314]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.83115, -27.48955, 19.206]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.05125, -27.469, 19.194000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.01775, -27.253, 19.086000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.23435, -27.22565, 19.074]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.16665, -26.949350000000003, 18.966]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.3792, -26.915300000000002, 18.954]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.272800000000004, -26.5787, 18.846]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.4809, -26.537950000000002, 18.834]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.3331, -26.14105, 18.726]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.53625, -26.093700000000002, 18.714]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.34075, -25.6383, 18.606]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.5384, -25.5845, 18.594]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.2916, -25.0715, 18.486]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.48335, -25.01135, 18.474]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.181650000000005, -24.441650000000003, 18.366]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.367050000000006, -24.37525, 18.354]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.005950000000006, -23.74975, 18.246]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.1846, -23.677249999999997, 18.234]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.761399999999995, -22.99775, 18.126]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.93299999999999, -22.9193, 18.114]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.445, -22.186700000000002, 18.006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.60915, -22.10245, 17.994]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.051849999999995, -21.318550000000002, 17.886]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.2082, -21.2286, 17.874]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.5798, -20.3934, 17.766000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.7281, -20.297900000000002, 17.754]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.0259, -19.4141, 17.646]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.165800000000004, -19.31315, 17.634]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.3862, -18.37985, 17.526]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.51745, -18.273600000000002, 17.514]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.659549999999996, -17.2944, 17.406]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.782, -17.183049999999998, 17.394]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.844, -16.15795, 17.286]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.95745, -16.04165, 17.274]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.937549999999995, -14.97335, 17.166]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.04185, -14.85235, 17.154]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.93915, -13.74265, 17.046]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.03415, -13.617149999999999, 17.034]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.84685, -12.46785, 16.926000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.93235000000001, -12.33815, 16.914]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.65865, -11.15285, 16.806]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.7345, -11.019200000000001, 16.794]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.3735, -9.7988, 16.686]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.43965, -9.661449999999999, 16.674]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.99135, -8.40955, 16.566]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.04775, -8.2689, 16.554]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.511250000000004, -6.9891000000000005, 16.446]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.5578, -6.8454500000000005, 16.434]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.9322, -5.53955, 16.326]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.9688, -5.3932, 16.314]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.2532, -4.0648, 16.206]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.27985, -3.9161, 16.194]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.47515, -2.5679, 16.086]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.49185, -2.41725, 16.073999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.597150000000006, -1.05375, 15.966000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.60385, -0.90155, 15.954]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.61915, 0.4745500000000001, 15.846]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.61585, 0.62785, 15.834]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.54115, 2.01115, 15.726000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.5279, 2.1650500000000004, 15.714000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.3641, 3.55195, 15.606]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.341, 3.7060000000000004, 15.594]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.089000000000006, 5.092, 15.486]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.0561, 5.2457, 15.474]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.715900000000005, 6.6263000000000005, 15.366]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.67325000000001, 6.7792, 15.354]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.24575000000001, 8.1508, 15.246000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.193450000000006, 8.30245, 15.234000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.679550000000006, 9.66055, 15.126]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.61775000000001, 9.810500000000001, 15.113999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.01925, 11.1515, 15.006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.9481, 11.29935, 14.994]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.2659, 12.61965, 14.886000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.185550000000006, 12.765, 14.874000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.42144999999999, 14.061, 14.766000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.3321, 14.2034, 14.754000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.4879, 15.470600000000001, 14.646]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.3898, 15.6097, 14.634]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.4682, 16.8463, 14.526]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.36155000000001, 16.9818, 14.514]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.36345, 18.1842, 14.406]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.24855, 18.315800000000003, 14.394000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.17845, 19.482200000000002, 14.286000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.05565, 19.609550000000002, 14.274000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.91535, 20.73545, 14.166]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.78485, 20.858249999999998, 14.154]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.576150000000005, 21.94275, 14.046]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.4382, 22.060750000000002, 14.033999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.1638, 23.100250000000003, 13.926]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.01865, 23.2131, 13.914000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.68035, 24.204900000000002, 13.806000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.52825, 24.312400000000004, 13.794000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.128750000000004, 25.2556, 13.686]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.970000000000006, 25.35755, 13.674]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.512, 26.24945, 13.566]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.3469, 26.3456, 13.554]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.8331, 27.184400000000004, 13.446]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.662, 27.274550000000005, 13.434000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.096, 28.05845, 13.326]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.91925, 28.142400000000002, 13.314000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.30375, 28.869600000000002, 13.206]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.121700000000004, 28.947200000000002, 13.193999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.460300000000004, 29.6168, 13.086]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.27335, 29.687900000000003, 13.074]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.56965, 30.2981, 12.966000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.37820000000001, 30.36255, 12.954]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.6358, 30.91245, 12.846]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.4403, 30.970100000000002, 12.834000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.663700000000002, 31.457900000000002, 12.726]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.464650000000002, 31.50855, 12.714]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.658350000000002, 31.932450000000003, 12.606]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.456200000000003, 31.976, 12.594]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.6238, 32.336000000000006, 12.486]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.418999999999997, 32.372400000000006, 12.474]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.564999999999998, 32.6676, 12.366]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.35805, 32.696749999999994, 12.354000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.48695, 32.926249999999996, 12.246]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.27835, 32.9481, 12.234]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.39465, 33.1119, 12.126]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.1849, 33.126400000000004, 12.113999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.2931, 33.2236, 12.006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.0827, 33.23075, 11.994000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.1873, 33.26225, 11.886000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.9768, 33.262100000000004, 11.874]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.0832, 33.227900000000005, 11.766]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.87305, 33.2204, 11.754]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.98395, 33.1196, 11.646]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.774600000000001, 33.1048, 11.634]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.895400000000002, 32.9392, 11.526]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.687450000000002, 32.91715, 11.514000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.823549999999999, 32.68585, 11.406]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.61745, 32.65655, 11.394]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.77155, 32.36045, 11.286]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.56775, 32.324, 11.274]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.7452500000000004, 31.964000000000002, 11.166]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.5443000000000002, 31.9204, 11.154]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7496999999999998, 31.495600000000003, 11.046]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.5520999999999998, 31.444900000000004, 11.034]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.2101, 30.9571, 10.926]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.40395000000000003, 30.89945, 10.914]) cube([0.4, 0.4, 0.1], center=true);
    translate([-2.1310499999999997, 30.34955, 10.806000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-2.3206999999999995, 30.28505, 10.794]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.0073, 29.67395, 10.686]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.19235, 29.60275, 10.674]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.836650000000001, 28.932250000000003, 10.566]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-6.01675, 28.854550000000003, 10.554000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.61425, 28.12645, 10.446]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.789000000000001, 28.0424, 10.434]) cube([0.4, 0.4, 0.1], center=true);
    translate([-9.337, 27.2576, 10.326]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-9.50605, 27.1673, 10.314]) cube([0.4, 0.4, 0.1], center=true);
    translate([-11.00095, 26.326700000000002, 10.206]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-11.1639, 26.2303, 10.193999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([-12.6021, 25.335700000000003, 10.086]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-12.75865, 25.23335, 10.074000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([-14.138349999999999, 24.28565, 9.966000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-14.2883, 24.1775, 9.954]) cube([0.4, 0.4, 0.1], center=true);
    translate([-15.6077, 23.1785, 9.846]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-15.7507, 23.0648, 9.834]) cube([0.4, 0.4, 0.1], center=true);
    translate([-17.0053, 22.017200000000003, 9.726]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-17.14105, 21.89815, 9.714]) cube([0.4, 0.4, 0.1], center=true);
    translate([-18.32995, 20.80285, 9.606]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-18.45825, 20.67865, 9.594000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-19.57875, 19.538350000000005, 9.486]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-19.6994, 19.409250000000004, 9.474]) cube([0.4, 0.4, 0.1], center=true);
    translate([-20.750600000000002, 18.22575, 9.366]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-20.863400000000002, 18.092000000000002, 9.354]) cube([0.4, 0.4, 0.1], center=true);
    translate([-21.8426, 16.868000000000002, 9.246]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-21.9473, 16.729850000000003, 9.234]) cube([0.4, 0.4, 0.1], center=true);
    translate([-22.8527, 15.46715, 9.126]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-22.94905, 15.324850000000001, 9.114]) cube([0.4, 0.4, 0.1], center=true);
    translate([-23.77795, 14.026150000000001, 9.006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-23.865850000000002, 13.88, 8.994]) cube([0.4, 0.4, 0.1], center=true);
    translate([-24.61915, 12.548000000000002, 8.886000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-24.698500000000003, 12.3983, 8.874]) cube([0.4, 0.4, 0.1], center=true);
    translate([-25.3735, 11.0357, 8.766]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-25.444100000000002, 10.882700000000002, 8.754]) cube([0.4, 0.4, 0.1], center=true);
    translate([-26.039900000000003, 9.4913, 8.646]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-26.1016, 9.3353, 8.634]) cube([0.4, 0.4, 0.1], center=true);
    translate([-26.6164, 7.9187, 8.526]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-26.6691, 7.76005, 8.514]) cube([0.4, 0.4, 0.1], center=true);
    translate([-27.1029, 6.32095, 8.406]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-27.14655, 6.16, 8.394]) cube([0.4, 0.4, 0.1], center=true);
    translate([-27.498450000000002, 4.702000000000001, 8.286]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-27.53295, 4.539150000000001, 8.274]) cube([0.4, 0.4, 0.1], center=true);
    translate([-27.80205, 3.06585, 8.166]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-27.82735, 2.90145, 8.154]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.013650000000002, 1.41555, 8.046]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.029750000000003, 1.25, 8.033999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.13325, -0.244, 7.926]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.14015, -0.41025, 7.914]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.16085, -1.90875, 7.805999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.15855, -2.07525, 7.794]) cube([0.4, 0.4, 0.1], center=true);
    translate([-28.09645, -3.57375, 7.686]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-28.0849, -3.7399500000000003, 7.6739999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([-27.939100000000003, -5.2330499999999995, 7.565999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-27.918350000000004, -5.3985, 7.553999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([-27.690649999999998, -6.8835, 7.446000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-27.660800000000002, -7.047750000000001, 7.434000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-27.3512, -8.519250000000001, 7.3260000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-27.31225, -8.6818, 7.314]) cube([0.4, 0.4, 0.1], center=true);
    translate([-26.920750000000005, -10.136200000000002, 7.206]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-26.872800000000005, -10.296600000000002, 7.194000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-26.401200000000003, -11.7294, 7.086]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-26.344350000000002, -11.8872, 7.074]) cube([0.4, 0.4, 0.1], center=true);
    translate([-25.792650000000002, -13.2948, 6.966]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-25.726950000000002, -13.44955, 6.954000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-25.096049999999998, -14.82745, 6.846]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-25.0217, -14.9788, 6.834]) cube([0.4, 0.4, 0.1], center=true);
    translate([-24.3143, -16.3252, 6.726]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-24.23145, -16.4728, 6.714]) cube([0.4, 0.4, 0.1], center=true);
    translate([-23.44755, -17.783200000000004, 6.606]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-23.356350000000003, -17.926600000000004, 6.593999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([-22.49865, -19.197400000000002, 6.486000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-22.3993, -19.33625, 6.474000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-21.468700000000002, -20.56475, 6.3660000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-21.36135, -20.698800000000002, 6.354]) cube([0.4, 0.4, 0.1], center=true);
    translate([-20.35965, -21.883200000000002, 6.246]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-20.244549999999997, -22.012050000000002, 6.234000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-19.174449999999997, -23.146950000000004, 6.126]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-19.05175, -23.270250000000004, 6.114]) cube([0.4, 0.4, 0.1], center=true);
    translate([-17.91325, -24.354750000000003, 6.006]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-17.7831, -24.4723, 5.994000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-16.5789, -25.5037, 5.886]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-16.4415, -25.6152, 5.874]) cube([0.4, 0.4, 0.1], center=true);
    translate([-15.172500000000001, -26.5908, 5.766]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-15.02805, -26.695999999999998, 5.7540000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([-13.696950000000001, -27.613999999999997, 5.646]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-13.54575, -27.71275, 5.6339999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([-12.15525, -28.572250000000004, 5.526]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-11.99755, -28.664350000000002, 5.514]) cube([0.4, 0.4, 0.1], center=true);
    translate([-10.54945, -29.46265, 5.406000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-10.38555, -29.54795, 5.394]) cube([0.4, 0.4, 0.1], center=true);
    translate([-8.88345, -30.285050000000002, 5.2860000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-8.713650000000001, -30.363400000000002, 5.274000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.159350000000001, -31.036600000000004, 5.166]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-6.98395, -31.107850000000003, 5.154]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.38105, -31.71715, 5.046]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.2004, -31.78125, 5.034000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.5515999999999996, -32.325750000000006, 4.926]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.3659499999999998, -32.38255, 4.914]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.67305, -32.86045, 4.806]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.48285, -32.90985, 4.7940000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.24785, -33.32115, 4.686]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.4421, -33.36305, 4.6739999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.2079, -33.70595, 4.566]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.40565, -33.74025, 4.554]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.199350000000001, -34.01475, 4.446000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.4001, -34.0414, 4.434]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.2199, -34.2466, 4.3260000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.4232000000000005, -34.2655, 4.314]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.2628, -34.4005, 4.206]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.46805, -34.41165, 4.194]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.32295, -34.47735, 4.086]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.52965, -34.4807, 4.074]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.39535, -34.475300000000004, 3.966]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.6029, -34.470800000000004, 3.954]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4731, -34.395199999999996, 3.846]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.680850000000001, -34.3829, 3.834]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.55015, -34.2371, 3.7260000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.7576, -34.217, 3.7140000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.6224, -34.001, 3.6060000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.829, -33.97315, 3.5940000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.683000000000003, -33.68785, 3.486]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.888150000000003, -33.65235, 3.474]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.726850000000002, -33.29865, 3.366]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.930000000000003, -33.25555000000001, 3.354]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.748, -32.833450000000006, 3.2460000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.9486, -32.7828, 3.2340000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.7414, -32.2932, 3.1260000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.938950000000002, -32.2351, 3.1140000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.702050000000003, -31.6789, 3.0060000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.896100000000004, -31.61345, 2.994]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.6259, -30.99155, 2.886]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.816000000000003, -30.91885, 2.874]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.507999999999996, -30.232149999999997, 2.766]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.6937, -30.1524, 2.754]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.3443, -29.403599999999997, 2.6460000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.5251, -29.31695, 2.6340000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.1289, -28.50605, 2.5260000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.30435000000001, -28.412599999999998, 2.5140000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.858650000000004, -27.5414, 2.406]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.0284, -27.441300000000002, 2.394]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.529599999999995, -26.5107, 2.286]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.69325, -26.4041, 2.274]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.137750000000004, -25.4159, 2.1660000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.29495, -25.30305, 2.1540000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.680049999999994, -24.25995, 2.0460000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.8304, -24.14105, 2.0340000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.1516, -23.04395, 1.926]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.29475, -22.919249999999998, 1.914]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.55025, -21.771749999999997, 1.806]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.6859, -21.641499999999997, 1.794]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.8721, -20.444499999999998, 1.686]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.999900000000004, -20.30885, 1.674]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.1141, -19.06415, 1.5660000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.233850000000004, -18.923350000000003, 1.5540000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.275150000000004, -17.633650000000003, 1.4460000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.38655, -17.488000000000003, 1.434]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.35045000000001, -16.156000000000002, 1.326]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.45315000000001, -16.0058, 1.314]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.33785, -14.6342, 1.206]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.431650000000005, -14.47975, 1.1940000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.23535, -13.07125, 1.086]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.32, -12.9129, 1.074]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.04, -11.471100000000002, 0.966]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.1152, -11.30915, 0.954]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.7488, -9.835849999999999, 0.846]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.8143, -9.670649999999998, 0.8340000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.359700000000004, -8.17035, 0.726]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.4153, -8.0023, 0.714]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.87070000000001, -6.4777000000000005, 0.606]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.916250000000005, -6.30715, 0.5940000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.280750000000005, -4.76185, 0.486]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.31615000000001, -4.5892, 0.474]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.58885, -3.0267999999999997, 0.366]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.613949999999996, -2.8524499999999997, 0.354]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.793049999999994, -1.27655, 0.246]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.8078, -1.1009, 0.23399999999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.8942, 0.48489999999999994, 0.126]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.8986, 0.6614, 0.114]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.8914, 2.2526000000000006, 0.006]) cube([0.4, 0.4, 0.1], center=true);
}

