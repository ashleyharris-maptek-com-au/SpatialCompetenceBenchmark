
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.6]);

translate([2, 0, 0]) cube([1, 1, 4.3]);

translate([3, 0, 0]) cube([1, 1, 4.2]);

translate([4, 0, 0]) cube([1, 1, 4.2]);

translate([5, 0, 0]) cube([1, 1, 4.1]);

translate([6, 0, 0]) cube([1, 1, 4.0]);

translate([7, 0, 0]) cube([1, 1, 3.9]);

translate([8, 0, 0]) cube([1, 1, 3.9]);

translate([9, 0, 0]) cube([1, 1, 3.9]);

translate([10, 0, 0]) cube([1, 1, 4.0]);

translate([11, 0, 0]) cube([1, 1, 4.1]);

translate([12, 0, 0]) cube([1, 1, 4.2]);

translate([13, 0, 0]) cube([1, 1, 4.3]);

translate([14, 0, 0]) cube([1, 1, 4.5]);

translate([15, 0, 0]) cube([1, 1, 4.5]);

translate([16, 0, 0]) cube([1, 1, 4.4]);

translate([17, 0, 0]) cube([1, 1, 4.3]);

translate([18, 0, 0]) cube([1, 1, 4.2]);

translate([19, 0, 0]) cube([1, 1, 4.2]);

translate([20, 0, 0]) cube([1, 1, 4.3]);

translate([21, 0, 0]) cube([1, 1, 4.4]);

translate([22, 0, 0]) cube([1, 1, 4.7]);

translate([23, 0, 0]) cube([1, 1, 4.9]);

translate([24, 0, 0]) cube([1, 1, 5.0]);

translate([25, 0, 0]) cube([1, 1, 5.1]);

translate([26, 0, 0]) cube([1, 1, 5.2]);

translate([27, 0, 0]) cube([1, 1, 5.3]);

translate([28, 0, 0]) cube([1, 1, 5.4]);

translate([29, 0, 0]) cube([1, 1, 5.4]);

translate([30, 0, 0]) cube([1, 1, 5.4]);

translate([31, 0, 0]) cube([1, 1, 5.3]);

translate([32, 0, 0]) cube([1, 1, 5.1]);

translate([33, 0, 0]) cube([1, 1, 4.9]);

translate([34, 0, 0]) cube([1, 1, 4.7]);

translate([35, 0, 0]) cube([1, 1, 4.6]);

translate([36, 0, 0]) cube([1, 1, 4.4]);

translate([37, 0, 0]) cube([1, 1, 4.4]);

translate([38, 0, 0]) cube([1, 1, 4.3]);

translate([39, 0, 0]) cube([1, 1, 4.3]);

translate([40, 0, 0]) cube([1, 1, 4.3]);

translate([41, 0, 0]) cube([1, 1, 4.3]);

translate([42, 0, 0]) cube([1, 1, 4.4]);

translate([43, 0, 0]) cube([1, 1, 4.6]);

translate([44, 0, 0]) cube([1, 1, 4.6]);

translate([45, 0, 0]) cube([1, 1, 4.7]);

translate([46, 0, 0]) cube([1, 1, 4.8]);

translate([47, 0, 0]) cube([1, 1, 4.9]);

translate([0, 1, 0]) cube([1, 1, 5.5]);

translate([1, 1, 0]) cube([1, 1, 5.0]);

translate([2, 1, 0]) cube([1, 1, 4.7]);

translate([3, 1, 0]) cube([1, 1, 4.5]);

translate([4, 1, 0]) cube([1, 1, 4.4]);

translate([5, 1, 0]) cube([1, 1, 4.3]);

translate([6, 1, 0]) cube([1, 1, 4.1]);

translate([7, 1, 0]) cube([1, 1, 4.0]);

translate([8, 1, 0]) cube([1, 1, 3.9]);

translate([9, 1, 0]) cube([1, 1, 3.9]);

translate([10, 1, 0]) cube([1, 1, 3.9]);

translate([11, 1, 0]) cube([1, 1, 4.0]);

translate([12, 1, 0]) cube([1, 1, 4.1]);

translate([13, 1, 0]) cube([1, 1, 4.2]);

translate([14, 1, 0]) cube([1, 1, 4.3]);

translate([15, 1, 0]) cube([1, 1, 4.3]);

translate([16, 1, 0]) cube([1, 1, 4.2]);

translate([17, 1, 0]) cube([1, 1, 4.0]);

translate([18, 1, 0]) cube([1, 1, 3.9]);

translate([19, 1, 0]) cube([1, 1, 3.9]);

translate([20, 1, 0]) cube([1, 1, 4.0]);

translate([21, 1, 0]) cube([1, 1, 4.1]);

translate([22, 1, 0]) cube([1, 1, 4.4]);

translate([23, 1, 0]) cube([1, 1, 4.5]);

translate([24, 1, 0]) cube([1, 1, 4.7]);

translate([25, 1, 0]) cube([1, 1, 4.8]);

translate([26, 1, 0]) cube([1, 1, 4.9]);

translate([27, 1, 0]) cube([1, 1, 5.0]);

translate([28, 1, 0]) cube([1, 1, 5.0]);

translate([29, 1, 0]) cube([1, 1, 5.1]);

translate([30, 1, 0]) cube([1, 1, 5.0]);

translate([31, 1, 0]) cube([1, 1, 4.9]);

translate([32, 1, 0]) cube([1, 1, 4.8]);

translate([33, 1, 0]) cube([1, 1, 4.6]);

translate([34, 1, 0]) cube([1, 1, 4.5]);

translate([35, 1, 0]) cube([1, 1, 4.4]);

translate([36, 1, 0]) cube([1, 1, 4.3]);

translate([37, 1, 0]) cube([1, 1, 4.2]);

translate([38, 1, 0]) cube([1, 1, 4.1]);

translate([39, 1, 0]) cube([1, 1, 4.0]);

translate([40, 1, 0]) cube([1, 1, 3.9]);

translate([41, 1, 0]) cube([1, 1, 3.9]);

translate([42, 1, 0]) cube([1, 1, 4.0]);

translate([43, 1, 0]) cube([1, 1, 4.1]);

translate([44, 1, 0]) cube([1, 1, 4.2]);

translate([45, 1, 0]) cube([1, 1, 4.3]);

translate([46, 1, 0]) cube([1, 1, 4.4]);

translate([47, 1, 0]) cube([1, 1, 4.5]);

translate([0, 2, 0]) cube([1, 1, 6.0]);

translate([1, 2, 0]) cube([1, 1, 5.6]);

translate([2, 2, 0]) cube([1, 1, 5.2]);

translate([3, 2, 0]) cube([1, 1, 4.9]);

translate([4, 2, 0]) cube([1, 1, 4.7]);

translate([5, 2, 0]) cube([1, 1, 4.6]);

translate([6, 2, 0]) cube([1, 1, 4.4]);

translate([7, 2, 0]) cube([1, 1, 4.2]);

translate([8, 2, 0]) cube([1, 1, 4.1]);

translate([9, 2, 0]) cube([1, 1, 4.0]);

translate([10, 2, 0]) cube([1, 1, 4.1]);

translate([11, 2, 0]) cube([1, 1, 4.1]);

translate([12, 2, 0]) cube([1, 1, 4.2]);

translate([13, 2, 0]) cube([1, 1, 4.2]);

translate([14, 2, 0]) cube([1, 1, 4.2]);

translate([15, 2, 0]) cube([1, 1, 4.1]);

translate([16, 2, 0]) cube([1, 1, 4.0]);

translate([17, 2, 0]) cube([1, 1, 3.9]);

translate([18, 2, 0]) cube([1, 1, 3.8]);

translate([19, 2, 0]) cube([1, 1, 3.8]);

translate([20, 2, 0]) cube([1, 1, 3.9]);

translate([21, 2, 0]) cube([1, 1, 3.9]);

translate([22, 2, 0]) cube([1, 1, 4.1]);

translate([23, 2, 0]) cube([1, 1, 4.2]);

translate([24, 2, 0]) cube([1, 1, 4.4]);

translate([25, 2, 0]) cube([1, 1, 4.4]);

translate([26, 2, 0]) cube([1, 1, 4.5]);

translate([27, 2, 0]) cube([1, 1, 4.6]);

translate([28, 2, 0]) cube([1, 1, 4.7]);

translate([29, 2, 0]) cube([1, 1, 4.7]);

translate([30, 2, 0]) cube([1, 1, 4.7]);

translate([31, 2, 0]) cube([1, 1, 4.6]);

translate([32, 2, 0]) cube([1, 1, 4.5]);

translate([33, 2, 0]) cube([1, 1, 4.4]);

translate([34, 2, 0]) cube([1, 1, 4.3]);

translate([35, 2, 0]) cube([1, 1, 4.2]);

translate([36, 2, 0]) cube([1, 1, 4.1]);

translate([37, 2, 0]) cube([1, 1, 4.0]);

translate([38, 2, 0]) cube([1, 1, 3.9]);

translate([39, 2, 0]) cube([1, 1, 3.8]);

translate([40, 2, 0]) cube([1, 1, 3.6]);

translate([41, 2, 0]) cube([1, 1, 3.6]);

translate([42, 2, 0]) cube([1, 1, 3.7]);

translate([43, 2, 0]) cube([1, 1, 3.9]);

translate([44, 2, 0]) cube([1, 1, 4.0]);

translate([45, 2, 0]) cube([1, 1, 4.0]);

translate([46, 2, 0]) cube([1, 1, 4.1]);

translate([47, 2, 0]) cube([1, 1, 4.2]);

translate([0, 3, 0]) cube([1, 1, 6.4]);

translate([1, 3, 0]) cube([1, 1, 6.0]);

translate([2, 3, 0]) cube([1, 1, 5.7]);

translate([3, 3, 0]) cube([1, 1, 5.4]);

translate([4, 3, 0]) cube([1, 1, 5.2]);

translate([5, 3, 0]) cube([1, 1, 5.0]);

translate([6, 3, 0]) cube([1, 1, 4.8]);

translate([7, 3, 0]) cube([1, 1, 4.6]);

translate([8, 3, 0]) cube([1, 1, 4.4]);

translate([9, 3, 0]) cube([1, 1, 4.4]);

translate([10, 3, 0]) cube([1, 1, 4.4]);

translate([11, 3, 0]) cube([1, 1, 4.4]);

translate([12, 3, 0]) cube([1, 1, 4.3]);

translate([13, 3, 0]) cube([1, 1, 4.3]);

translate([14, 3, 0]) cube([1, 1, 4.1]);

translate([15, 3, 0]) cube([1, 1, 4.0]);

translate([16, 3, 0]) cube([1, 1, 3.9]);

translate([17, 3, 0]) cube([1, 1, 3.8]);

translate([18, 3, 0]) cube([1, 1, 3.8]);

translate([19, 3, 0]) cube([1, 1, 3.9]);

translate([20, 3, 0]) cube([1, 1, 3.9]);

translate([21, 3, 0]) cube([1, 1, 3.9]);

translate([22, 3, 0]) cube([1, 1, 4.0]);

translate([23, 3, 0]) cube([1, 1, 4.1]);

translate([24, 3, 0]) cube([1, 1, 4.2]);

translate([25, 3, 0]) cube([1, 1, 4.3]);

translate([26, 3, 0]) cube([1, 1, 4.4]);

translate([27, 3, 0]) cube([1, 1, 4.4]);

translate([28, 3, 0]) cube([1, 1, 4.5]);

translate([29, 3, 0]) cube([1, 1, 4.5]);

translate([30, 3, 0]) cube([1, 1, 4.4]);

translate([31, 3, 0]) cube([1, 1, 4.3]);

translate([32, 3, 0]) cube([1, 1, 4.3]);

translate([33, 3, 0]) cube([1, 1, 4.2]);

translate([34, 3, 0]) cube([1, 1, 4.1]);

translate([35, 3, 0]) cube([1, 1, 4.0]);

translate([36, 3, 0]) cube([1, 1, 4.0]);

translate([37, 3, 0]) cube([1, 1, 3.9]);

translate([38, 3, 0]) cube([1, 1, 3.8]);

translate([39, 3, 0]) cube([1, 1, 3.6]);

translate([40, 3, 0]) cube([1, 1, 3.5]);

translate([41, 3, 0]) cube([1, 1, 3.4]);

translate([42, 3, 0]) cube([1, 1, 3.5]);

translate([43, 3, 0]) cube([1, 1, 3.7]);

translate([44, 3, 0]) cube([1, 1, 3.8]);

translate([45, 3, 0]) cube([1, 1, 3.9]);

translate([46, 3, 0]) cube([1, 1, 3.8]);

translate([47, 3, 0]) cube([1, 1, 3.8]);

translate([0, 4, 0]) cube([1, 1, 6.8]);

translate([1, 4, 0]) cube([1, 1, 6.4]);

translate([2, 4, 0]) cube([1, 1, 6.0]);

translate([3, 4, 0]) cube([1, 1, 5.8]);

translate([4, 4, 0]) cube([1, 1, 5.6]);

translate([5, 4, 0]) cube([1, 1, 5.4]);

translate([6, 4, 0]) cube([1, 1, 5.2]);

translate([7, 4, 0]) cube([1, 1, 5.0]);

translate([8, 4, 0]) cube([1, 1, 4.8]);

translate([9, 4, 0]) cube([1, 1, 4.8]);

translate([10, 4, 0]) cube([1, 1, 4.8]);

translate([11, 4, 0]) cube([1, 1, 4.7]);

translate([12, 4, 0]) cube([1, 1, 4.6]);

translate([13, 4, 0]) cube([1, 1, 4.4]);

translate([14, 4, 0]) cube([1, 1, 4.2]);

translate([15, 4, 0]) cube([1, 1, 4.0]);

translate([16, 4, 0]) cube([1, 1, 3.9]);

translate([17, 4, 0]) cube([1, 1, 4.0]);

translate([18, 4, 0]) cube([1, 1, 4.0]);

translate([19, 4, 0]) cube([1, 1, 4.1]);

translate([20, 4, 0]) cube([1, 1, 4.2]);

translate([21, 4, 0]) cube([1, 1, 4.1]);

translate([22, 4, 0]) cube([1, 1, 4.1]);

translate([23, 4, 0]) cube([1, 1, 4.2]);

translate([24, 4, 0]) cube([1, 1, 4.2]);

translate([25, 4, 0]) cube([1, 1, 4.3]);

translate([26, 4, 0]) cube([1, 1, 4.4]);

translate([27, 4, 0]) cube([1, 1, 4.4]);

translate([28, 4, 0]) cube([1, 1, 4.3]);

translate([29, 4, 0]) cube([1, 1, 4.3]);

translate([30, 4, 0]) cube([1, 1, 4.3]);

translate([31, 4, 0]) cube([1, 1, 4.2]);

translate([32, 4, 0]) cube([1, 1, 4.1]);

translate([33, 4, 0]) cube([1, 1, 3.9]);

translate([34, 4, 0]) cube([1, 1, 3.8]);

translate([35, 4, 0]) cube([1, 1, 3.7]);

translate([36, 4, 0]) cube([1, 1, 3.7]);

translate([37, 4, 0]) cube([1, 1, 3.7]);

translate([38, 4, 0]) cube([1, 1, 3.6]);

translate([39, 4, 0]) cube([1, 1, 3.5]);

translate([40, 4, 0]) cube([1, 1, 3.4]);

translate([41, 4, 0]) cube([1, 1, 3.3]);

translate([42, 4, 0]) cube([1, 1, 3.4]);

translate([43, 4, 0]) cube([1, 1, 3.6]);

translate([44, 4, 0]) cube([1, 1, 3.7]);

translate([45, 4, 0]) cube([1, 1, 3.8]);

translate([46, 4, 0]) cube([1, 1, 3.7]);

translate([47, 4, 0]) cube([1, 1, 3.6]);

translate([0, 5, 0]) cube([1, 1, 7.0]);

translate([1, 5, 0]) cube([1, 1, 6.6]);

translate([2, 5, 0]) cube([1, 1, 6.3]);

translate([3, 5, 0]) cube([1, 1, 6.1]);

translate([4, 5, 0]) cube([1, 1, 5.9]);

translate([5, 5, 0]) cube([1, 1, 5.8]);

translate([6, 5, 0]) cube([1, 1, 5.5]);

translate([7, 5, 0]) cube([1, 1, 5.3]);

translate([8, 5, 0]) cube([1, 1, 5.2]);

translate([9, 5, 0]) cube([1, 1, 5.2]);

translate([10, 5, 0]) cube([1, 1, 5.1]);

translate([11, 5, 0]) cube([1, 1, 5.0]);

translate([12, 5, 0]) cube([1, 1, 4.8]);

translate([13, 5, 0]) cube([1, 1, 4.6]);

translate([14, 5, 0]) cube([1, 1, 4.3]);

translate([15, 5, 0]) cube([1, 1, 4.2]);

translate([16, 5, 0]) cube([1, 1, 4.1]);

translate([17, 5, 0]) cube([1, 1, 4.2]);

translate([18, 5, 0]) cube([1, 1, 4.3]);

translate([19, 5, 0]) cube([1, 1, 4.4]);

translate([20, 5, 0]) cube([1, 1, 4.5]);

translate([21, 5, 0]) cube([1, 1, 4.4]);

translate([22, 5, 0]) cube([1, 1, 4.4]);

translate([23, 5, 0]) cube([1, 1, 4.4]);

translate([24, 5, 0]) cube([1, 1, 4.4]);

translate([25, 5, 0]) cube([1, 1, 4.5]);

translate([26, 5, 0]) cube([1, 1, 4.5]);

translate([27, 5, 0]) cube([1, 1, 4.4]);

translate([28, 5, 0]) cube([1, 1, 4.3]);

translate([29, 5, 0]) cube([1, 1, 4.2]);

translate([30, 5, 0]) cube([1, 1, 4.1]);

translate([31, 5, 0]) cube([1, 1, 4.1]);

translate([32, 5, 0]) cube([1, 1, 3.9]);

translate([33, 5, 0]) cube([1, 1, 3.7]);

translate([34, 5, 0]) cube([1, 1, 3.6]);

translate([35, 5, 0]) cube([1, 1, 3.5]);

translate([36, 5, 0]) cube([1, 1, 3.5]);

translate([37, 5, 0]) cube([1, 1, 3.6]);

translate([38, 5, 0]) cube([1, 1, 3.5]);

translate([39, 5, 0]) cube([1, 1, 3.4]);

translate([40, 5, 0]) cube([1, 1, 3.3]);

translate([41, 5, 0]) cube([1, 1, 3.3]);

translate([42, 5, 0]) cube([1, 1, 3.4]);

translate([43, 5, 0]) cube([1, 1, 3.5]);

translate([44, 5, 0]) cube([1, 1, 3.6]);

translate([45, 5, 0]) cube([1, 1, 3.7]);

translate([46, 5, 0]) cube([1, 1, 3.6]);

translate([47, 5, 0]) cube([1, 1, 3.5]);

translate([0, 6, 0]) cube([1, 1, 7.2]);

translate([1, 6, 0]) cube([1, 1, 6.8]);

translate([2, 6, 0]) cube([1, 1, 6.5]);

translate([3, 6, 0]) cube([1, 1, 6.3]);

translate([4, 6, 0]) cube([1, 1, 6.2]);

translate([5, 6, 0]) cube([1, 1, 6.0]);

translate([6, 6, 0]) cube([1, 1, 5.8]);

translate([7, 6, 0]) cube([1, 1, 5.5]);

translate([8, 6, 0]) cube([1, 1, 5.4]);

translate([9, 6, 0]) cube([1, 1, 5.4]);

translate([10, 6, 0]) cube([1, 1, 5.4]);

translate([11, 6, 0]) cube([1, 1, 5.2]);

translate([12, 6, 0]) cube([1, 1, 5.0]);

translate([13, 6, 0]) cube([1, 1, 4.8]);

translate([14, 6, 0]) cube([1, 1, 4.5]);

translate([15, 6, 0]) cube([1, 1, 4.4]);

translate([16, 6, 0]) cube([1, 1, 4.4]);

translate([17, 6, 0]) cube([1, 1, 4.5]);

translate([18, 6, 0]) cube([1, 1, 4.6]);

translate([19, 6, 0]) cube([1, 1, 4.8]);

translate([20, 6, 0]) cube([1, 1, 4.8]);

translate([21, 6, 0]) cube([1, 1, 4.8]);

translate([22, 6, 0]) cube([1, 1, 4.7]);

translate([23, 6, 0]) cube([1, 1, 4.7]);

translate([24, 6, 0]) cube([1, 1, 4.7]);

translate([25, 6, 0]) cube([1, 1, 4.7]);

translate([26, 6, 0]) cube([1, 1, 4.6]);

translate([27, 6, 0]) cube([1, 1, 4.4]);

translate([28, 6, 0]) cube([1, 1, 4.2]);

translate([29, 6, 0]) cube([1, 1, 4.1]);

translate([30, 6, 0]) cube([1, 1, 4.0]);

translate([31, 6, 0]) cube([1, 1, 3.9]);

translate([32, 6, 0]) cube([1, 1, 3.8]);

translate([33, 6, 0]) cube([1, 1, 3.6]);

translate([34, 6, 0]) cube([1, 1, 3.4]);

translate([35, 6, 0]) cube([1, 1, 3.4]);

translate([36, 6, 0]) cube([1, 1, 3.4]);

translate([37, 6, 0]) cube([1, 1, 3.5]);

translate([38, 6, 0]) cube([1, 1, 3.5]);

translate([39, 6, 0]) cube([1, 1, 3.4]);

translate([40, 6, 0]) cube([1, 1, 3.3]);

translate([41, 6, 0]) cube([1, 1, 3.2]);

translate([42, 6, 0]) cube([1, 1, 3.3]);

translate([43, 6, 0]) cube([1, 1, 3.4]);

translate([44, 6, 0]) cube([1, 1, 3.5]);

translate([45, 6, 0]) cube([1, 1, 3.6]);

translate([46, 6, 0]) cube([1, 1, 3.6]);

translate([47, 6, 0]) cube([1, 1, 3.5]);

translate([0, 7, 0]) cube([1, 1, 7.4]);

translate([1, 7, 0]) cube([1, 1, 7.0]);

translate([2, 7, 0]) cube([1, 1, 6.7]);

translate([3, 7, 0]) cube([1, 1, 6.5]);

translate([4, 7, 0]) cube([1, 1, 6.3]);

translate([5, 7, 0]) cube([1, 1, 6.2]);

translate([6, 7, 0]) cube([1, 1, 6.0]);

translate([7, 7, 0]) cube([1, 1, 5.8]);

translate([8, 7, 0]) cube([1, 1, 5.6]);

translate([9, 7, 0]) cube([1, 1, 5.6]);

translate([10, 7, 0]) cube([1, 1, 5.6]);

translate([11, 7, 0]) cube([1, 1, 5.4]);

translate([12, 7, 0]) cube([1, 1, 5.2]);

translate([13, 7, 0]) cube([1, 1, 4.9]);

translate([14, 7, 0]) cube([1, 1, 4.7]);

translate([15, 7, 0]) cube([1, 1, 4.6]);

translate([16, 7, 0]) cube([1, 1, 4.6]);

translate([17, 7, 0]) cube([1, 1, 4.8]);

translate([18, 7, 0]) cube([1, 1, 4.9]);

translate([19, 7, 0]) cube([1, 1, 5.1]);

translate([20, 7, 0]) cube([1, 1, 5.1]);

translate([21, 7, 0]) cube([1, 1, 5.1]);

translate([22, 7, 0]) cube([1, 1, 5.0]);

translate([23, 7, 0]) cube([1, 1, 5.0]);

translate([24, 7, 0]) cube([1, 1, 4.9]);

translate([25, 7, 0]) cube([1, 1, 4.9]);

translate([26, 7, 0]) cube([1, 1, 4.7]);

translate([27, 7, 0]) cube([1, 1, 4.5]);

translate([28, 7, 0]) cube([1, 1, 4.2]);

translate([29, 7, 0]) cube([1, 1, 4.0]);

translate([30, 7, 0]) cube([1, 1, 3.9]);

translate([31, 7, 0]) cube([1, 1, 3.8]);

translate([32, 7, 0]) cube([1, 1, 3.7]);

translate([33, 7, 0]) cube([1, 1, 3.5]);

translate([34, 7, 0]) cube([1, 1, 3.3]);

translate([35, 7, 0]) cube([1, 1, 3.3]);

translate([36, 7, 0]) cube([1, 1, 3.4]);

translate([37, 7, 0]) cube([1, 1, 3.5]);

translate([38, 7, 0]) cube([1, 1, 3.5]);

translate([39, 7, 0]) cube([1, 1, 3.4]);

translate([40, 7, 0]) cube([1, 1, 3.3]);

translate([41, 7, 0]) cube([1, 1, 3.3]);

translate([42, 7, 0]) cube([1, 1, 3.3]);

translate([43, 7, 0]) cube([1, 1, 3.4]);

translate([44, 7, 0]) cube([1, 1, 3.5]);

translate([45, 7, 0]) cube([1, 1, 3.6]);

translate([46, 7, 0]) cube([1, 1, 3.6]);

translate([47, 7, 0]) cube([1, 1, 3.5]);

translate([0, 8, 0]) cube([1, 1, 7.5]);

translate([1, 8, 0]) cube([1, 1, 7.2]);

translate([2, 8, 0]) cube([1, 1, 6.9]);

translate([3, 8, 0]) cube([1, 1, 6.7]);

translate([4, 8, 0]) cube([1, 1, 6.6]);

translate([5, 8, 0]) cube([1, 1, 6.4]);

translate([6, 8, 0]) cube([1, 1, 6.2]);

translate([7, 8, 0]) cube([1, 1, 6.0]);

translate([8, 8, 0]) cube([1, 1, 5.9]);

translate([9, 8, 0]) cube([1, 1, 5.8]);

translate([10, 8, 0]) cube([1, 1, 5.7]);

translate([11, 8, 0]) cube([1, 1, 5.6]);

translate([12, 8, 0]) cube([1, 1, 5.3]);

translate([13, 8, 0]) cube([1, 1, 5.1]);

translate([14, 8, 0]) cube([1, 1, 4.9]);

translate([15, 8, 0]) cube([1, 1, 4.8]);

translate([16, 8, 0]) cube([1, 1, 4.9]);

translate([17, 8, 0]) cube([1, 1, 5.1]);

translate([18, 8, 0]) cube([1, 1, 5.2]);

translate([19, 8, 0]) cube([1, 1, 5.4]);

translate([20, 8, 0]) cube([1, 1, 5.5]);

translate([21, 8, 0]) cube([1, 1, 5.4]);

translate([22, 8, 0]) cube([1, 1, 5.4]);

translate([23, 8, 0]) cube([1, 1, 5.3]);

translate([24, 8, 0]) cube([1, 1, 5.2]);

translate([25, 8, 0]) cube([1, 1, 5.1]);

translate([26, 8, 0]) cube([1, 1, 4.8]);

translate([27, 8, 0]) cube([1, 1, 4.5]);

translate([28, 8, 0]) cube([1, 1, 4.2]);

translate([29, 8, 0]) cube([1, 1, 3.9]);

translate([30, 8, 0]) cube([1, 1, 3.8]);

translate([31, 8, 0]) cube([1, 1, 3.7]);

translate([32, 8, 0]) cube([1, 1, 3.6]);

translate([33, 8, 0]) cube([1, 1, 3.4]);

translate([34, 8, 0]) cube([1, 1, 3.3]);

translate([35, 8, 0]) cube([1, 1, 3.3]);

translate([36, 8, 0]) cube([1, 1, 3.4]);

translate([37, 8, 0]) cube([1, 1, 3.5]);

translate([38, 8, 0]) cube([1, 1, 3.6]);

translate([39, 8, 0]) cube([1, 1, 3.6]);

translate([40, 8, 0]) cube([1, 1, 3.5]);

translate([41, 8, 0]) cube([1, 1, 3.5]);

translate([42, 8, 0]) cube([1, 1, 3.5]);

translate([43, 8, 0]) cube([1, 1, 3.5]);

translate([44, 8, 0]) cube([1, 1, 3.6]);

translate([45, 8, 0]) cube([1, 1, 3.7]);

translate([46, 8, 0]) cube([1, 1, 3.7]);

translate([47, 8, 0]) cube([1, 1, 3.6]);

translate([0, 9, 0]) cube([1, 1, 7.7]);

translate([1, 9, 0]) cube([1, 1, 7.4]);

translate([2, 9, 0]) cube([1, 1, 7.1]);

translate([3, 9, 0]) cube([1, 1, 7.0]);

translate([4, 9, 0]) cube([1, 1, 6.8]);

translate([5, 9, 0]) cube([1, 1, 6.7]);

translate([6, 9, 0]) cube([1, 1, 6.5]);

translate([7, 9, 0]) cube([1, 1, 6.3]);

translate([8, 9, 0]) cube([1, 1, 6.1]);

translate([9, 9, 0]) cube([1, 1, 6.0]);

translate([10, 9, 0]) cube([1, 1, 5.9]);

translate([11, 9, 0]) cube([1, 1, 5.7]);

translate([12, 9, 0]) cube([1, 1, 5.5]);

translate([13, 9, 0]) cube([1, 1, 5.3]);

translate([14, 9, 0]) cube([1, 1, 5.1]);

translate([15, 9, 0]) cube([1, 1, 5.1]);

translate([16, 9, 0]) cube([1, 1, 5.2]);

translate([17, 9, 0]) cube([1, 1, 5.3]);

translate([18, 9, 0]) cube([1, 1, 5.5]);

translate([19, 9, 0]) cube([1, 1, 5.7]);

translate([20, 9, 0]) cube([1, 1, 5.8]);

translate([21, 9, 0]) cube([1, 1, 5.8]);

translate([22, 9, 0]) cube([1, 1, 5.7]);

translate([23, 9, 0]) cube([1, 1, 5.5]);

translate([24, 9, 0]) cube([1, 1, 5.3]);

translate([25, 9, 0]) cube([1, 1, 5.1]);

translate([26, 9, 0]) cube([1, 1, 4.8]);

translate([27, 9, 0]) cube([1, 1, 4.5]);

translate([28, 9, 0]) cube([1, 1, 4.2]);

translate([29, 9, 0]) cube([1, 1, 3.9]);

translate([30, 9, 0]) cube([1, 1, 3.7]);

translate([31, 9, 0]) cube([1, 1, 3.6]);

translate([32, 9, 0]) cube([1, 1, 3.5]);

translate([33, 9, 0]) cube([1, 1, 3.5]);

translate([34, 9, 0]) cube([1, 1, 3.5]);

translate([35, 9, 0]) cube([1, 1, 3.5]);

translate([36, 9, 0]) cube([1, 1, 3.6]);

translate([37, 9, 0]) cube([1, 1, 3.7]);

translate([38, 9, 0]) cube([1, 1, 3.7]);

translate([39, 9, 0]) cube([1, 1, 3.8]);

translate([40, 9, 0]) cube([1, 1, 3.9]);

translate([41, 9, 0]) cube([1, 1, 3.9]);

translate([42, 9, 0]) cube([1, 1, 3.8]);

translate([43, 9, 0]) cube([1, 1, 3.8]);

translate([44, 9, 0]) cube([1, 1, 3.8]);

translate([45, 9, 0]) cube([1, 1, 3.8]);

translate([46, 9, 0]) cube([1, 1, 3.8]);

translate([47, 9, 0]) cube([1, 1, 3.7]);

translate([0, 10, 0]) cube([1, 1, 7.9]);

translate([1, 10, 0]) cube([1, 1, 7.6]);

translate([2, 10, 0]) cube([1, 1, 7.4]);

translate([3, 10, 0]) cube([1, 1, 7.2]);

translate([4, 10, 0]) cube([1, 1, 7.1]);

translate([5, 10, 0]) cube([1, 1, 6.9]);

translate([6, 10, 0]) cube([1, 1, 6.7]);

translate([7, 10, 0]) cube([1, 1, 6.5]);

translate([8, 10, 0]) cube([1, 1, 6.4]);

translate([9, 10, 0]) cube([1, 1, 6.2]);

translate([10, 10, 0]) cube([1, 1, 6.1]);

translate([11, 10, 0]) cube([1, 1, 5.9]);

translate([12, 10, 0]) cube([1, 1, 5.8]);

translate([13, 10, 0]) cube([1, 1, 5.6]);

translate([14, 10, 0]) cube([1, 1, 5.4]);

translate([15, 10, 0]) cube([1, 1, 5.3]);

translate([16, 10, 0]) cube([1, 1, 5.4]);

translate([17, 10, 0]) cube([1, 1, 5.6]);

translate([18, 10, 0]) cube([1, 1, 5.7]);

translate([19, 10, 0]) cube([1, 1, 5.9]);

translate([20, 10, 0]) cube([1, 1, 6.0]);

translate([21, 10, 0]) cube([1, 1, 6.0]);

translate([22, 10, 0]) cube([1, 1, 5.9]);

translate([23, 10, 0]) cube([1, 1, 5.6]);

translate([24, 10, 0]) cube([1, 1, 5.4]);

translate([25, 10, 0]) cube([1, 1, 5.1]);

translate([26, 10, 0]) cube([1, 1, 4.8]);

translate([27, 10, 0]) cube([1, 1, 4.5]);

translate([28, 10, 0]) cube([1, 1, 4.2]);

translate([29, 10, 0]) cube([1, 1, 4.0]);

translate([30, 10, 0]) cube([1, 1, 3.8]);

translate([31, 10, 0]) cube([1, 1, 3.6]);

translate([32, 10, 0]) cube([1, 1, 3.6]);

translate([33, 10, 0]) cube([1, 1, 3.6]);

translate([34, 10, 0]) cube([1, 1, 3.7]);

translate([35, 10, 0]) cube([1, 1, 3.8]);

translate([36, 10, 0]) cube([1, 1, 3.9]);

translate([37, 10, 0]) cube([1, 1, 3.9]);

translate([38, 10, 0]) cube([1, 1, 4.0]);

translate([39, 10, 0]) cube([1, 1, 4.1]);

translate([40, 10, 0]) cube([1, 1, 4.2]);

translate([41, 10, 0]) cube([1, 1, 4.3]);

translate([42, 10, 0]) cube([1, 1, 4.2]);

translate([43, 10, 0]) cube([1, 1, 4.1]);

translate([44, 10, 0]) cube([1, 1, 4.1]);

translate([45, 10, 0]) cube([1, 1, 4.0]);

translate([46, 10, 0]) cube([1, 1, 3.9]);

translate([47, 10, 0]) cube([1, 1, 3.8]);

translate([0, 11, 0]) cube([1, 1, 8.0]);

translate([1, 11, 0]) cube([1, 1, 7.7]);

translate([2, 11, 0]) cube([1, 1, 7.5]);

translate([3, 11, 0]) cube([1, 1, 7.3]);

translate([4, 11, 0]) cube([1, 1, 7.2]);

translate([5, 11, 0]) cube([1, 1, 7.0]);

translate([6, 11, 0]) cube([1, 1, 6.8]);

translate([7, 11, 0]) cube([1, 1, 6.7]);

translate([8, 11, 0]) cube([1, 1, 6.5]);

translate([9, 11, 0]) cube([1, 1, 6.4]);

translate([10, 11, 0]) cube([1, 1, 6.3]);

translate([11, 11, 0]) cube([1, 1, 6.2]);

translate([12, 11, 0]) cube([1, 1, 6.0]);

translate([13, 11, 0]) cube([1, 1, 5.9]);

translate([14, 11, 0]) cube([1, 1, 5.7]);

translate([15, 11, 0]) cube([1, 1, 5.6]);

translate([16, 11, 0]) cube([1, 1, 5.6]);

translate([17, 11, 0]) cube([1, 1, 5.7]);

translate([18, 11, 0]) cube([1, 1, 5.9]);

translate([19, 11, 0]) cube([1, 1, 6.0]);

translate([20, 11, 0]) cube([1, 1, 6.1]);

translate([21, 11, 0]) cube([1, 1, 6.2]);

translate([22, 11, 0]) cube([1, 1, 6.0]);

translate([23, 11, 0]) cube([1, 1, 5.7]);

translate([24, 11, 0]) cube([1, 1, 5.4]);

translate([25, 11, 0]) cube([1, 1, 5.1]);

translate([26, 11, 0]) cube([1, 1, 4.8]);

translate([27, 11, 0]) cube([1, 1, 4.6]);

translate([28, 11, 0]) cube([1, 1, 4.4]);

translate([29, 11, 0]) cube([1, 1, 4.2]);

translate([30, 11, 0]) cube([1, 1, 3.9]);

translate([31, 11, 0]) cube([1, 1, 3.8]);

translate([32, 11, 0]) cube([1, 1, 3.8]);

translate([33, 11, 0]) cube([1, 1, 3.9]);

translate([34, 11, 0]) cube([1, 1, 4.1]);

translate([35, 11, 0]) cube([1, 1, 4.2]);

translate([36, 11, 0]) cube([1, 1, 4.2]);

translate([37, 11, 0]) cube([1, 1, 4.2]);

translate([38, 11, 0]) cube([1, 1, 4.3]);

translate([39, 11, 0]) cube([1, 1, 4.4]);

translate([40, 11, 0]) cube([1, 1, 4.5]);

translate([41, 11, 0]) cube([1, 1, 4.5]);

translate([42, 11, 0]) cube([1, 1, 4.5]);

translate([43, 11, 0]) cube([1, 1, 4.4]);

translate([44, 11, 0]) cube([1, 1, 4.3]);

translate([45, 11, 0]) cube([1, 1, 4.2]);

translate([46, 11, 0]) cube([1, 1, 4.1]);

translate([47, 11, 0]) cube([1, 1, 4.0]);

translate([0, 12, 0]) cube([1, 1, 7.9]);

translate([1, 12, 0]) cube([1, 1, 7.6]);

translate([2, 12, 0]) cube([1, 1, 7.4]);

translate([3, 12, 0]) cube([1, 1, 7.3]);

translate([4, 12, 0]) cube([1, 1, 7.1]);

translate([5, 12, 0]) cube([1, 1, 7.0]);

translate([6, 12, 0]) cube([1, 1, 6.8]);

translate([7, 12, 0]) cube([1, 1, 6.6]);

translate([8, 12, 0]) cube([1, 1, 6.5]);

translate([9, 12, 0]) cube([1, 1, 6.5]);

translate([10, 12, 0]) cube([1, 1, 6.5]);

translate([11, 12, 0]) cube([1, 1, 6.4]);

translate([12, 12, 0]) cube([1, 1, 6.2]);

translate([13, 12, 0]) cube([1, 1, 6.1]);

translate([14, 12, 0]) cube([1, 1, 5.9]);

translate([15, 12, 0]) cube([1, 1, 5.7]);

translate([16, 12, 0]) cube([1, 1, 5.7]);

translate([17, 12, 0]) cube([1, 1, 5.8]);

translate([18, 12, 0]) cube([1, 1, 5.9]);

translate([19, 12, 0]) cube([1, 1, 6.1]);

translate([20, 12, 0]) cube([1, 1, 6.2]);

translate([21, 12, 0]) cube([1, 1, 6.2]);

translate([22, 12, 0]) cube([1, 1, 6.1]);

translate([23, 12, 0]) cube([1, 1, 5.8]);

translate([24, 12, 0]) cube([1, 1, 5.4]);

translate([25, 12, 0]) cube([1, 1, 5.1]);

translate([26, 12, 0]) cube([1, 1, 4.9]);

translate([27, 12, 0]) cube([1, 1, 4.7]);

translate([28, 12, 0]) cube([1, 1, 4.5]);

translate([29, 12, 0]) cube([1, 1, 4.4]);

translate([30, 12, 0]) cube([1, 1, 4.1]);

translate([31, 12, 0]) cube([1, 1, 4.0]);

translate([32, 12, 0]) cube([1, 1, 4.1]);

translate([33, 12, 0]) cube([1, 1, 4.2]);

translate([34, 12, 0]) cube([1, 1, 4.4]);

translate([35, 12, 0]) cube([1, 1, 4.6]);

translate([36, 12, 0]) cube([1, 1, 4.6]);

translate([37, 12, 0]) cube([1, 1, 4.6]);

translate([38, 12, 0]) cube([1, 1, 4.6]);

translate([39, 12, 0]) cube([1, 1, 4.6]);

translate([40, 12, 0]) cube([1, 1, 4.7]);

translate([41, 12, 0]) cube([1, 1, 4.7]);

translate([42, 12, 0]) cube([1, 1, 4.6]);

translate([43, 12, 0]) cube([1, 1, 4.5]);

translate([44, 12, 0]) cube([1, 1, 4.5]);

translate([45, 12, 0]) cube([1, 1, 4.5]);

translate([46, 12, 0]) cube([1, 1, 4.4]);

translate([47, 12, 0]) cube([1, 1, 4.3]);

translate([0, 13, 0]) cube([1, 1, 7.9]);

translate([1, 13, 0]) cube([1, 1, 7.6]);

translate([2, 13, 0]) cube([1, 1, 7.3]);

translate([3, 13, 0]) cube([1, 1, 7.2]);

translate([4, 13, 0]) cube([1, 1, 7.0]);

translate([5, 13, 0]) cube([1, 1, 6.9]);

translate([6, 13, 0]) cube([1, 1, 6.7]);

translate([7, 13, 0]) cube([1, 1, 6.6]);

translate([8, 13, 0]) cube([1, 1, 6.5]);

translate([9, 13, 0]) cube([1, 1, 6.5]);

translate([10, 13, 0]) cube([1, 1, 6.6]);

translate([11, 13, 0]) cube([1, 1, 6.6]);

translate([12, 13, 0]) cube([1, 1, 6.4]);

translate([13, 13, 0]) cube([1, 1, 6.2]);

translate([14, 13, 0]) cube([1, 1, 6.0]);

translate([15, 13, 0]) cube([1, 1, 5.9]);

translate([16, 13, 0]) cube([1, 1, 5.8]);

translate([17, 13, 0]) cube([1, 1, 5.9]);

translate([18, 13, 0]) cube([1, 1, 6.0]);

translate([19, 13, 0]) cube([1, 1, 6.2]);

translate([20, 13, 0]) cube([1, 1, 6.3]);

translate([21, 13, 0]) cube([1, 1, 6.3]);

translate([22, 13, 0]) cube([1, 1, 6.1]);

translate([23, 13, 0]) cube([1, 1, 5.8]);

translate([24, 13, 0]) cube([1, 1, 5.5]);

translate([25, 13, 0]) cube([1, 1, 5.2]);

translate([26, 13, 0]) cube([1, 1, 4.9]);

translate([27, 13, 0]) cube([1, 1, 4.8]);

translate([28, 13, 0]) cube([1, 1, 4.7]);

translate([29, 13, 0]) cube([1, 1, 4.6]);

translate([30, 13, 0]) cube([1, 1, 4.4]);

translate([31, 13, 0]) cube([1, 1, 4.3]);

translate([32, 13, 0]) cube([1, 1, 4.3]);

translate([33, 13, 0]) cube([1, 1, 4.5]);

translate([34, 13, 0]) cube([1, 1, 4.8]);

translate([35, 13, 0]) cube([1, 1, 4.9]);

translate([36, 13, 0]) cube([1, 1, 4.9]);

translate([37, 13, 0]) cube([1, 1, 4.9]);

translate([38, 13, 0]) cube([1, 1, 4.9]);

translate([39, 13, 0]) cube([1, 1, 4.9]);

translate([40, 13, 0]) cube([1, 1, 4.9]);

translate([41, 13, 0]) cube([1, 1, 4.8]);

translate([42, 13, 0]) cube([1, 1, 4.8]);

translate([43, 13, 0]) cube([1, 1, 4.7]);

translate([44, 13, 0]) cube([1, 1, 4.7]);

translate([45, 13, 0]) cube([1, 1, 4.7]);

translate([46, 13, 0]) cube([1, 1, 4.8]);

translate([47, 13, 0]) cube([1, 1, 4.7]);

translate([0, 14, 0]) cube([1, 1, 7.9]);

translate([1, 14, 0]) cube([1, 1, 7.6]);

translate([2, 14, 0]) cube([1, 1, 7.3]);

translate([3, 14, 0]) cube([1, 1, 7.1]);

translate([4, 14, 0]) cube([1, 1, 6.9]);

translate([5, 14, 0]) cube([1, 1, 6.7]);

translate([6, 14, 0]) cube([1, 1, 6.6]);

translate([7, 14, 0]) cube([1, 1, 6.5]);

translate([8, 14, 0]) cube([1, 1, 6.5]);

translate([9, 14, 0]) cube([1, 1, 6.6]);

translate([10, 14, 0]) cube([1, 1, 6.7]);

translate([11, 14, 0]) cube([1, 1, 6.7]);

translate([12, 14, 0]) cube([1, 1, 6.6]);

translate([13, 14, 0]) cube([1, 1, 6.4]);

translate([14, 14, 0]) cube([1, 1, 6.2]);

translate([15, 14, 0]) cube([1, 1, 6.0]);

translate([16, 14, 0]) cube([1, 1, 5.9]);

translate([17, 14, 0]) cube([1, 1, 5.9]);

translate([18, 14, 0]) cube([1, 1, 6.0]);

translate([19, 14, 0]) cube([1, 1, 6.1]);

translate([20, 14, 0]) cube([1, 1, 6.2]);

translate([21, 14, 0]) cube([1, 1, 6.2]);

translate([22, 14, 0]) cube([1, 1, 6.1]);

translate([23, 14, 0]) cube([1, 1, 5.8]);

translate([24, 14, 0]) cube([1, 1, 5.5]);

translate([25, 14, 0]) cube([1, 1, 5.2]);

translate([26, 14, 0]) cube([1, 1, 5.0]);

translate([27, 14, 0]) cube([1, 1, 4.9]);

translate([28, 14, 0]) cube([1, 1, 4.8]);

translate([29, 14, 0]) cube([1, 1, 4.7]);

translate([30, 14, 0]) cube([1, 1, 4.6]);

translate([31, 14, 0]) cube([1, 1, 4.5]);

translate([32, 14, 0]) cube([1, 1, 4.6]);

translate([33, 14, 0]) cube([1, 1, 4.8]);

translate([34, 14, 0]) cube([1, 1, 5.1]);

translate([35, 14, 0]) cube([1, 1, 5.3]);

translate([36, 14, 0]) cube([1, 1, 5.3]);

translate([37, 14, 0]) cube([1, 1, 5.3]);

translate([38, 14, 0]) cube([1, 1, 5.2]);

translate([39, 14, 0]) cube([1, 1, 5.1]);

translate([40, 14, 0]) cube([1, 1, 5.1]);

translate([41, 14, 0]) cube([1, 1, 5.0]);

translate([42, 14, 0]) cube([1, 1, 4.9]);

translate([43, 14, 0]) cube([1, 1, 4.8]);

translate([44, 14, 0]) cube([1, 1, 4.9]);

translate([45, 14, 0]) cube([1, 1, 5.0]);

translate([46, 14, 0]) cube([1, 1, 5.1]);

translate([47, 14, 0]) cube([1, 1, 5.1]);

translate([0, 15, 0]) cube([1, 1, 8.0]);

translate([1, 15, 0]) cube([1, 1, 7.7]);

translate([2, 15, 0]) cube([1, 1, 7.4]);

translate([3, 15, 0]) cube([1, 1, 7.1]);

translate([4, 15, 0]) cube([1, 1, 6.8]);

translate([5, 15, 0]) cube([1, 1, 6.7]);

translate([6, 15, 0]) cube([1, 1, 6.6]);

translate([7, 15, 0]) cube([1, 1, 6.6]);

translate([8, 15, 0]) cube([1, 1, 6.7]);

translate([9, 15, 0]) cube([1, 1, 6.8]);

translate([10, 15, 0]) cube([1, 1, 6.9]);

translate([11, 15, 0]) cube([1, 1, 6.8]);

translate([12, 15, 0]) cube([1, 1, 6.7]);

translate([13, 15, 0]) cube([1, 1, 6.5]);

translate([14, 15, 0]) cube([1, 1, 6.3]);

translate([15, 15, 0]) cube([1, 1, 6.1]);

translate([16, 15, 0]) cube([1, 1, 6.0]);

translate([17, 15, 0]) cube([1, 1, 6.0]);

translate([18, 15, 0]) cube([1, 1, 6.0]);

translate([19, 15, 0]) cube([1, 1, 6.0]);

translate([20, 15, 0]) cube([1, 1, 6.1]);

translate([21, 15, 0]) cube([1, 1, 6.1]);

translate([22, 15, 0]) cube([1, 1, 6.1]);

translate([23, 15, 0]) cube([1, 1, 5.8]);

translate([24, 15, 0]) cube([1, 1, 5.5]);

translate([25, 15, 0]) cube([1, 1, 5.2]);

translate([26, 15, 0]) cube([1, 1, 5.0]);

translate([27, 15, 0]) cube([1, 1, 4.9]);

translate([28, 15, 0]) cube([1, 1, 4.9]);

translate([29, 15, 0]) cube([1, 1, 4.8]);

translate([30, 15, 0]) cube([1, 1, 4.7]);

translate([31, 15, 0]) cube([1, 1, 4.6]);

translate([32, 15, 0]) cube([1, 1, 4.8]);

translate([33, 15, 0]) cube([1, 1, 5.1]);

translate([34, 15, 0]) cube([1, 1, 5.4]);

translate([35, 15, 0]) cube([1, 1, 5.5]);

translate([36, 15, 0]) cube([1, 1, 5.6]);

translate([37, 15, 0]) cube([1, 1, 5.6]);

translate([38, 15, 0]) cube([1, 1, 5.5]);

translate([39, 15, 0]) cube([1, 1, 5.4]);

translate([40, 15, 0]) cube([1, 1, 5.3]);

translate([41, 15, 0]) cube([1, 1, 5.2]);

translate([42, 15, 0]) cube([1, 1, 5.1]);

translate([43, 15, 0]) cube([1, 1, 5.1]);

translate([44, 15, 0]) cube([1, 1, 5.1]);

translate([45, 15, 0]) cube([1, 1, 5.3]);

translate([46, 15, 0]) cube([1, 1, 5.4]);

translate([47, 15, 0]) cube([1, 1, 5.4]);

translate([0, 16, 0]) cube([1, 1, 8.1]);

translate([1, 16, 0]) cube([1, 1, 7.8]);

translate([2, 16, 0]) cube([1, 1, 7.5]);

translate([3, 16, 0]) cube([1, 1, 7.1]);

translate([4, 16, 0]) cube([1, 1, 6.9]);

translate([5, 16, 0]) cube([1, 1, 6.8]);

translate([6, 16, 0]) cube([1, 1, 6.8]);

translate([7, 16, 0]) cube([1, 1, 6.8]);

translate([8, 16, 0]) cube([1, 1, 7.0]);

translate([9, 16, 0]) cube([1, 1, 7.1]);

translate([10, 16, 0]) cube([1, 1, 7.1]);

translate([11, 16, 0]) cube([1, 1, 6.9]);

translate([12, 16, 0]) cube([1, 1, 6.7]);

translate([13, 16, 0]) cube([1, 1, 6.5]);

translate([14, 16, 0]) cube([1, 1, 6.3]);

translate([15, 16, 0]) cube([1, 1, 6.2]);

translate([16, 16, 0]) cube([1, 1, 6.2]);

translate([17, 16, 0]) cube([1, 1, 6.1]);

translate([18, 16, 0]) cube([1, 1, 6.0]);

translate([19, 16, 0]) cube([1, 1, 6.0]);

translate([20, 16, 0]) cube([1, 1, 6.0]);

translate([21, 16, 0]) cube([1, 1, 6.0]);

translate([22, 16, 0]) cube([1, 1, 6.0]);

translate([23, 16, 0]) cube([1, 1, 5.8]);

translate([24, 16, 0]) cube([1, 1, 5.5]);

translate([25, 16, 0]) cube([1, 1, 5.2]);

translate([26, 16, 0]) cube([1, 1, 5.0]);

translate([27, 16, 0]) cube([1, 1, 5.0]);

translate([28, 16, 0]) cube([1, 1, 4.9]);

translate([29, 16, 0]) cube([1, 1, 4.8]);

translate([30, 16, 0]) cube([1, 1, 4.7]);

translate([31, 16, 0]) cube([1, 1, 4.7]);

translate([32, 16, 0]) cube([1, 1, 4.9]);

translate([33, 16, 0]) cube([1, 1, 5.2]);

translate([34, 16, 0]) cube([1, 1, 5.5]);

translate([35, 16, 0]) cube([1, 1, 5.7]);

translate([36, 16, 0]) cube([1, 1, 5.7]);

translate([37, 16, 0]) cube([1, 1, 5.7]);

translate([38, 16, 0]) cube([1, 1, 5.7]);

translate([39, 16, 0]) cube([1, 1, 5.6]);

translate([40, 16, 0]) cube([1, 1, 5.6]);

translate([41, 16, 0]) cube([1, 1, 5.5]);

translate([42, 16, 0]) cube([1, 1, 5.5]);

translate([43, 16, 0]) cube([1, 1, 5.4]);

translate([44, 16, 0]) cube([1, 1, 5.5]);

translate([45, 16, 0]) cube([1, 1, 5.6]);

translate([46, 16, 0]) cube([1, 1, 5.6]);

translate([47, 16, 0]) cube([1, 1, 5.5]);

translate([0, 17, 0]) cube([1, 1, 8.2]);

translate([1, 17, 0]) cube([1, 1, 7.9]);

translate([2, 17, 0]) cube([1, 1, 7.5]);

translate([3, 17, 0]) cube([1, 1, 7.2]);

translate([4, 17, 0]) cube([1, 1, 7.0]);

translate([5, 17, 0]) cube([1, 1, 7.0]);

translate([6, 17, 0]) cube([1, 1, 7.0]);

translate([7, 17, 0]) cube([1, 1, 7.1]);

translate([8, 17, 0]) cube([1, 1, 7.3]);

translate([9, 17, 0]) cube([1, 1, 7.3]);

translate([10, 17, 0]) cube([1, 1, 7.2]);

translate([11, 17, 0]) cube([1, 1, 7.0]);

translate([12, 17, 0]) cube([1, 1, 6.8]);

translate([13, 17, 0]) cube([1, 1, 6.6]);

translate([14, 17, 0]) cube([1, 1, 6.5]);

translate([15, 17, 0]) cube([1, 1, 6.4]);

translate([16, 17, 0]) cube([1, 1, 6.4]);

translate([17, 17, 0]) cube([1, 1, 6.3]);

translate([18, 17, 0]) cube([1, 1, 6.2]);

translate([19, 17, 0]) cube([1, 1, 6.1]);

translate([20, 17, 0]) cube([1, 1, 6.0]);

translate([21, 17, 0]) cube([1, 1, 6.0]);

translate([22, 17, 0]) cube([1, 1, 6.0]);

translate([23, 17, 0]) cube([1, 1, 5.8]);

translate([24, 17, 0]) cube([1, 1, 5.6]);

translate([25, 17, 0]) cube([1, 1, 5.3]);

translate([26, 17, 0]) cube([1, 1, 5.1]);

translate([27, 17, 0]) cube([1, 1, 5.0]);

translate([28, 17, 0]) cube([1, 1, 4.9]);

translate([29, 17, 0]) cube([1, 1, 4.9]);

translate([30, 17, 0]) cube([1, 1, 4.8]);

translate([31, 17, 0]) cube([1, 1, 4.8]);

translate([32, 17, 0]) cube([1, 1, 4.9]);

translate([33, 17, 0]) cube([1, 1, 5.2]);

translate([34, 17, 0]) cube([1, 1, 5.5]);

translate([35, 17, 0]) cube([1, 1, 5.7]);

translate([36, 17, 0]) cube([1, 1, 5.8]);

translate([37, 17, 0]) cube([1, 1, 5.8]);

translate([38, 17, 0]) cube([1, 1, 5.8]);

translate([39, 17, 0]) cube([1, 1, 5.8]);

translate([40, 17, 0]) cube([1, 1, 5.9]);

translate([41, 17, 0]) cube([1, 1, 5.9]);

translate([42, 17, 0]) cube([1, 1, 5.9]);

translate([43, 17, 0]) cube([1, 1, 5.8]);

translate([44, 17, 0]) cube([1, 1, 5.8]);

translate([45, 17, 0]) cube([1, 1, 5.8]);

translate([46, 17, 0]) cube([1, 1, 5.7]);

translate([47, 17, 0]) cube([1, 1, 5.5]);

translate([0, 18, 0]) cube([1, 1, 8.2]);

translate([1, 18, 0]) cube([1, 1, 7.9]);

translate([2, 18, 0]) cube([1, 1, 7.6]);

translate([3, 18, 0]) cube([1, 1, 7.3]);

translate([4, 18, 0]) cube([1, 1, 7.2]);

translate([5, 18, 0]) cube([1, 1, 7.2]);

translate([6, 18, 0]) cube([1, 1, 7.3]);

translate([7, 18, 0]) cube([1, 1, 7.4]);

translate([8, 18, 0]) cube([1, 1, 7.5]);

translate([9, 18, 0]) cube([1, 1, 7.5]);

translate([10, 18, 0]) cube([1, 1, 7.4]);

translate([11, 18, 0]) cube([1, 1, 7.1]);

translate([12, 18, 0]) cube([1, 1, 6.9]);

translate([13, 18, 0]) cube([1, 1, 6.7]);

translate([14, 18, 0]) cube([1, 1, 6.6]);

translate([15, 18, 0]) cube([1, 1, 6.6]);

translate([16, 18, 0]) cube([1, 1, 6.6]);

translate([17, 18, 0]) cube([1, 1, 6.5]);

translate([18, 18, 0]) cube([1, 1, 6.4]);

translate([19, 18, 0]) cube([1, 1, 6.2]);

translate([20, 18, 0]) cube([1, 1, 6.1]);

translate([21, 18, 0]) cube([1, 1, 6.1]);

translate([22, 18, 0]) cube([1, 1, 6.1]);

translate([23, 18, 0]) cube([1, 1, 5.9]);

translate([24, 18, 0]) cube([1, 1, 5.6]);

translate([25, 18, 0]) cube([1, 1, 5.4]);

translate([26, 18, 0]) cube([1, 1, 5.2]);

translate([27, 18, 0]) cube([1, 1, 5.1]);

translate([28, 18, 0]) cube([1, 1, 5.1]);

translate([29, 18, 0]) cube([1, 1, 5.0]);

translate([30, 18, 0]) cube([1, 1, 4.9]);

translate([31, 18, 0]) cube([1, 1, 4.9]);

translate([32, 18, 0]) cube([1, 1, 5.1]);

translate([33, 18, 0]) cube([1, 1, 5.3]);

translate([34, 18, 0]) cube([1, 1, 5.6]);

translate([35, 18, 0]) cube([1, 1, 5.7]);

translate([36, 18, 0]) cube([1, 1, 5.8]);

translate([37, 18, 0]) cube([1, 1, 5.8]);

translate([38, 18, 0]) cube([1, 1, 5.9]);

translate([39, 18, 0]) cube([1, 1, 6.0]);

translate([40, 18, 0]) cube([1, 1, 6.2]);

translate([41, 18, 0]) cube([1, 1, 6.3]);

translate([42, 18, 0]) cube([1, 1, 6.3]);

translate([43, 18, 0]) cube([1, 1, 6.2]);

translate([44, 18, 0]) cube([1, 1, 6.1]);

translate([45, 18, 0]) cube([1, 1, 6.0]);

translate([46, 18, 0]) cube([1, 1, 5.8]);

translate([47, 18, 0]) cube([1, 1, 5.5]);

translate([0, 19, 0]) cube([1, 1, 8.1]);

translate([1, 19, 0]) cube([1, 1, 7.9]);

translate([2, 19, 0]) cube([1, 1, 7.6]);

translate([3, 19, 0]) cube([1, 1, 7.4]);

translate([4, 19, 0]) cube([1, 1, 7.4]);

translate([5, 19, 0]) cube([1, 1, 7.4]);

translate([6, 19, 0]) cube([1, 1, 7.5]);

translate([7, 19, 0]) cube([1, 1, 7.6]);

translate([8, 19, 0]) cube([1, 1, 7.6]);

translate([9, 19, 0]) cube([1, 1, 7.6]);

translate([10, 19, 0]) cube([1, 1, 7.4]);

translate([11, 19, 0]) cube([1, 1, 7.2]);

translate([12, 19, 0]) cube([1, 1, 7.0]);

translate([13, 19, 0]) cube([1, 1, 6.8]);

translate([14, 19, 0]) cube([1, 1, 6.7]);

translate([15, 19, 0]) cube([1, 1, 6.8]);

translate([16, 19, 0]) cube([1, 1, 6.8]);

translate([17, 19, 0]) cube([1, 1, 6.7]);

translate([18, 19, 0]) cube([1, 1, 6.5]);

translate([19, 19, 0]) cube([1, 1, 6.4]);

translate([20, 19, 0]) cube([1, 1, 6.3]);

translate([21, 19, 0]) cube([1, 1, 6.2]);

translate([22, 19, 0]) cube([1, 1, 6.2]);

translate([23, 19, 0]) cube([1, 1, 6.0]);

translate([24, 19, 0]) cube([1, 1, 5.8]);

translate([25, 19, 0]) cube([1, 1, 5.5]);

translate([26, 19, 0]) cube([1, 1, 5.3]);

translate([27, 19, 0]) cube([1, 1, 5.3]);

translate([28, 19, 0]) cube([1, 1, 5.2]);

translate([29, 19, 0]) cube([1, 1, 5.2]);

translate([30, 19, 0]) cube([1, 1, 5.1]);

translate([31, 19, 0]) cube([1, 1, 5.1]);

translate([32, 19, 0]) cube([1, 1, 5.2]);

translate([33, 19, 0]) cube([1, 1, 5.4]);

translate([34, 19, 0]) cube([1, 1, 5.6]);

translate([35, 19, 0]) cube([1, 1, 5.8]);

translate([36, 19, 0]) cube([1, 1, 5.8]);

translate([37, 19, 0]) cube([1, 1, 5.9]);

translate([38, 19, 0]) cube([1, 1, 6.0]);

translate([39, 19, 0]) cube([1, 1, 6.2]);

translate([40, 19, 0]) cube([1, 1, 6.4]);

translate([41, 19, 0]) cube([1, 1, 6.6]);

translate([42, 19, 0]) cube([1, 1, 6.6]);

translate([43, 19, 0]) cube([1, 1, 6.5]);

translate([44, 19, 0]) cube([1, 1, 6.3]);

translate([45, 19, 0]) cube([1, 1, 6.1]);

translate([46, 19, 0]) cube([1, 1, 5.8]);

translate([47, 19, 0]) cube([1, 1, 5.5]);

translate([0, 20, 0]) cube([1, 1, 8.1]);

translate([1, 20, 0]) cube([1, 1, 7.9]);

translate([2, 20, 0]) cube([1, 1, 7.7]);

translate([3, 20, 0]) cube([1, 1, 7.6]);

translate([4, 20, 0]) cube([1, 1, 7.5]);

translate([5, 20, 0]) cube([1, 1, 7.6]);

translate([6, 20, 0]) cube([1, 1, 7.6]);

translate([7, 20, 0]) cube([1, 1, 7.6]);

translate([8, 20, 0]) cube([1, 1, 7.6]);

translate([9, 20, 0]) cube([1, 1, 7.6]);

translate([10, 20, 0]) cube([1, 1, 7.4]);

translate([11, 20, 0]) cube([1, 1, 7.2]);

translate([12, 20, 0]) cube([1, 1, 7.0]);

translate([13, 20, 0]) cube([1, 1, 6.9]);

translate([14, 20, 0]) cube([1, 1, 6.9]);

translate([15, 20, 0]) cube([1, 1, 6.9]);

translate([16, 20, 0]) cube([1, 1, 6.9]);

translate([17, 20, 0]) cube([1, 1, 6.8]);

translate([18, 20, 0]) cube([1, 1, 6.6]);

translate([19, 20, 0]) cube([1, 1, 6.4]);

translate([20, 20, 0]) cube([1, 1, 6.4]);

translate([21, 20, 0]) cube([1, 1, 6.4]);

translate([22, 20, 0]) cube([1, 1, 6.3]);

translate([23, 20, 0]) cube([1, 1, 6.2]);

translate([24, 20, 0]) cube([1, 1, 6.0]);

translate([25, 20, 0]) cube([1, 1, 5.7]);

translate([26, 20, 0]) cube([1, 1, 5.6]);

translate([27, 20, 0]) cube([1, 1, 5.5]);

translate([28, 20, 0]) cube([1, 1, 5.4]);

translate([29, 20, 0]) cube([1, 1, 5.4]);

translate([30, 20, 0]) cube([1, 1, 5.3]);

translate([31, 20, 0]) cube([1, 1, 5.3]);

translate([32, 20, 0]) cube([1, 1, 5.4]);

translate([33, 20, 0]) cube([1, 1, 5.6]);

translate([34, 20, 0]) cube([1, 1, 5.7]);

translate([35, 20, 0]) cube([1, 1, 5.9]);

translate([36, 20, 0]) cube([1, 1, 5.9]);

translate([37, 20, 0]) cube([1, 1, 6.0]);

translate([38, 20, 0]) cube([1, 1, 6.1]);

translate([39, 20, 0]) cube([1, 1, 6.4]);

translate([40, 20, 0]) cube([1, 1, 6.6]);

translate([41, 20, 0]) cube([1, 1, 6.8]);

translate([42, 20, 0]) cube([1, 1, 6.8]);

translate([43, 20, 0]) cube([1, 1, 6.8]);

translate([44, 20, 0]) cube([1, 1, 6.6]);

translate([45, 20, 0]) cube([1, 1, 6.3]);

translate([46, 20, 0]) cube([1, 1, 5.8]);

translate([47, 20, 0]) cube([1, 1, 5.4]);

translate([0, 21, 0]) cube([1, 1, 8.2]);

translate([1, 21, 0]) cube([1, 1, 7.9]);

translate([2, 21, 0]) cube([1, 1, 7.8]);

translate([3, 21, 0]) cube([1, 1, 7.7]);

translate([4, 21, 0]) cube([1, 1, 7.6]);

translate([5, 21, 0]) cube([1, 1, 7.6]);

translate([6, 21, 0]) cube([1, 1, 7.6]);

translate([7, 21, 0]) cube([1, 1, 7.5]);

translate([8, 21, 0]) cube([1, 1, 7.5]);

translate([9, 21, 0]) cube([1, 1, 7.4]);

translate([10, 21, 0]) cube([1, 1, 7.2]);

translate([11, 21, 0]) cube([1, 1, 7.1]);

translate([12, 21, 0]) cube([1, 1, 7.0]);

translate([13, 21, 0]) cube([1, 1, 7.0]);

translate([14, 21, 0]) cube([1, 1, 7.0]);

translate([15, 21, 0]) cube([1, 1, 7.0]);

translate([16, 21, 0]) cube([1, 1, 6.9]);

translate([17, 21, 0]) cube([1, 1, 6.7]);

translate([18, 21, 0]) cube([1, 1, 6.6]);

translate([19, 21, 0]) cube([1, 1, 6.4]);

translate([20, 21, 0]) cube([1, 1, 6.4]);

translate([21, 21, 0]) cube([1, 1, 6.5]);

translate([22, 21, 0]) cube([1, 1, 6.5]);

translate([23, 21, 0]) cube([1, 1, 6.4]);

translate([24, 21, 0]) cube([1, 1, 6.2]);

translate([25, 21, 0]) cube([1, 1, 6.0]);

translate([26, 21, 0]) cube([1, 1, 5.7]);

translate([27, 21, 0]) cube([1, 1, 5.6]);

translate([28, 21, 0]) cube([1, 1, 5.6]);

translate([29, 21, 0]) cube([1, 1, 5.5]);

translate([30, 21, 0]) cube([1, 1, 5.5]);

translate([31, 21, 0]) cube([1, 1, 5.6]);

translate([32, 21, 0]) cube([1, 1, 5.6]);

translate([33, 21, 0]) cube([1, 1, 5.8]);

translate([34, 21, 0]) cube([1, 1, 5.9]);

translate([35, 21, 0]) cube([1, 1, 6.0]);

translate([36, 21, 0]) cube([1, 1, 6.1]);

translate([37, 21, 0]) cube([1, 1, 6.2]);

translate([38, 21, 0]) cube([1, 1, 6.3]);

translate([39, 21, 0]) cube([1, 1, 6.5]);

translate([40, 21, 0]) cube([1, 1, 6.8]);

translate([41, 21, 0]) cube([1, 1, 6.9]);

translate([42, 21, 0]) cube([1, 1, 7.0]);

translate([43, 21, 0]) cube([1, 1, 6.9]);

translate([44, 21, 0]) cube([1, 1, 6.7]);

translate([45, 21, 0]) cube([1, 1, 6.4]);

translate([46, 21, 0]) cube([1, 1, 5.9]);

translate([47, 21, 0]) cube([1, 1, 5.4]);

translate([0, 22, 0]) cube([1, 1, 8.1]);

translate([1, 22, 0]) cube([1, 1, 7.9]);

translate([2, 22, 0]) cube([1, 1, 7.8]);

translate([3, 22, 0]) cube([1, 1, 7.7]);

translate([4, 22, 0]) cube([1, 1, 7.6]);

translate([5, 22, 0]) cube([1, 1, 7.5]);

translate([6, 22, 0]) cube([1, 1, 7.4]);

translate([7, 22, 0]) cube([1, 1, 7.3]);

translate([8, 22, 0]) cube([1, 1, 7.2]);

translate([9, 22, 0]) cube([1, 1, 7.0]);

translate([10, 22, 0]) cube([1, 1, 7.0]);

translate([11, 22, 0]) cube([1, 1, 7.0]);

translate([12, 22, 0]) cube([1, 1, 7.0]);

translate([13, 22, 0]) cube([1, 1, 7.0]);

translate([14, 22, 0]) cube([1, 1, 7.0]);

translate([15, 22, 0]) cube([1, 1, 7.0]);

translate([16, 22, 0]) cube([1, 1, 6.8]);

translate([17, 22, 0]) cube([1, 1, 6.6]);

translate([18, 22, 0]) cube([1, 1, 6.5]);

translate([19, 22, 0]) cube([1, 1, 6.4]);

translate([20, 22, 0]) cube([1, 1, 6.4]);

translate([21, 22, 0]) cube([1, 1, 6.5]);

translate([22, 22, 0]) cube([1, 1, 6.6]);

translate([23, 22, 0]) cube([1, 1, 6.6]);

translate([24, 22, 0]) cube([1, 1, 6.4]);

translate([25, 22, 0]) cube([1, 1, 6.1]);

translate([26, 22, 0]) cube([1, 1, 5.8]);

translate([27, 22, 0]) cube([1, 1, 5.7]);

translate([28, 22, 0]) cube([1, 1, 5.6]);

translate([29, 22, 0]) cube([1, 1, 5.6]);

translate([30, 22, 0]) cube([1, 1, 5.6]);

translate([31, 22, 0]) cube([1, 1, 5.7]);

translate([32, 22, 0]) cube([1, 1, 5.8]);

translate([33, 22, 0]) cube([1, 1, 5.9]);

translate([34, 22, 0]) cube([1, 1, 6.0]);

translate([35, 22, 0]) cube([1, 1, 6.0]);

translate([36, 22, 0]) cube([1, 1, 6.2]);

translate([37, 22, 0]) cube([1, 1, 6.3]);

translate([38, 22, 0]) cube([1, 1, 6.4]);

translate([39, 22, 0]) cube([1, 1, 6.6]);

translate([40, 22, 0]) cube([1, 1, 6.7]);

translate([41, 22, 0]) cube([1, 1, 6.9]);

translate([42, 22, 0]) cube([1, 1, 7.0]);

translate([43, 22, 0]) cube([1, 1, 6.9]);

translate([44, 22, 0]) cube([1, 1, 6.8]);

translate([45, 22, 0]) cube([1, 1, 6.4]);

translate([46, 22, 0]) cube([1, 1, 6.0]);

translate([47, 22, 0]) cube([1, 1, 5.4]);

translate([0, 23, 0]) cube([1, 1, 8.0]);

translate([1, 23, 0]) cube([1, 1, 7.8]);

translate([2, 23, 0]) cube([1, 1, 7.6]);

translate([3, 23, 0]) cube([1, 1, 7.6]);

translate([4, 23, 0]) cube([1, 1, 7.5]);

translate([5, 23, 0]) cube([1, 1, 7.4]);

translate([6, 23, 0]) cube([1, 1, 7.2]);

translate([7, 23, 0]) cube([1, 1, 7.1]);

translate([8, 23, 0]) cube([1, 1, 6.9]);

translate([9, 23, 0]) cube([1, 1, 6.7]);

translate([10, 23, 0]) cube([1, 1, 6.7]);

translate([11, 23, 0]) cube([1, 1, 6.8]);

translate([12, 23, 0]) cube([1, 1, 6.8]);

translate([13, 23, 0]) cube([1, 1, 6.9]);

translate([14, 23, 0]) cube([1, 1, 6.9]);

translate([15, 23, 0]) cube([1, 1, 6.9]);

translate([16, 23, 0]) cube([1, 1, 6.8]);

translate([17, 23, 0]) cube([1, 1, 6.6]);

translate([18, 23, 0]) cube([1, 1, 6.4]);

translate([19, 23, 0]) cube([1, 1, 6.4]);

translate([20, 23, 0]) cube([1, 1, 6.4]);

translate([21, 23, 0]) cube([1, 1, 6.5]);

translate([22, 23, 0]) cube([1, 1, 6.6]);

translate([23, 23, 0]) cube([1, 1, 6.6]);

translate([24, 23, 0]) cube([1, 1, 6.4]);

translate([25, 23, 0]) cube([1, 1, 6.1]);

translate([26, 23, 0]) cube([1, 1, 5.9]);

translate([27, 23, 0]) cube([1, 1, 5.6]);

translate([28, 23, 0]) cube([1, 1, 5.6]);

translate([29, 23, 0]) cube([1, 1, 5.6]);

translate([30, 23, 0]) cube([1, 1, 5.6]);

translate([31, 23, 0]) cube([1, 1, 5.7]);

translate([32, 23, 0]) cube([1, 1, 5.8]);

translate([33, 23, 0]) cube([1, 1, 5.9]);

translate([34, 23, 0]) cube([1, 1, 6.0]);

translate([35, 23, 0]) cube([1, 1, 6.0]);

translate([36, 23, 0]) cube([1, 1, 6.2]);

translate([37, 23, 0]) cube([1, 1, 6.3]);

translate([38, 23, 0]) cube([1, 1, 6.4]);

translate([39, 23, 0]) cube([1, 1, 6.5]);

translate([40, 23, 0]) cube([1, 1, 6.6]);

translate([41, 23, 0]) cube([1, 1, 6.8]);

translate([42, 23, 0]) cube([1, 1, 6.8]);

translate([43, 23, 0]) cube([1, 1, 6.8]);

translate([44, 23, 0]) cube([1, 1, 6.7]);

translate([45, 23, 0]) cube([1, 1, 6.4]);

translate([46, 23, 0]) cube([1, 1, 6.0]);

translate([47, 23, 0]) cube([1, 1, 5.5]);

translate([0, 24, 0]) cube([1, 1, 7.7]);

translate([1, 24, 0]) cube([1, 1, 7.5]);

translate([2, 24, 0]) cube([1, 1, 7.4]);

translate([3, 24, 0]) cube([1, 1, 7.3]);

translate([4, 24, 0]) cube([1, 1, 7.2]);

translate([5, 24, 0]) cube([1, 1, 7.1]);

translate([6, 24, 0]) cube([1, 1, 7.0]);

translate([7, 24, 0]) cube([1, 1, 6.8]);

translate([8, 24, 0]) cube([1, 1, 6.6]);

translate([9, 24, 0]) cube([1, 1, 6.5]);

translate([10, 24, 0]) cube([1, 1, 6.5]);

translate([11, 24, 0]) cube([1, 1, 6.6]);

translate([12, 24, 0]) cube([1, 1, 6.6]);

translate([13, 24, 0]) cube([1, 1, 6.7]);

translate([14, 24, 0]) cube([1, 1, 6.8]);

translate([15, 24, 0]) cube([1, 1, 6.8]);

translate([16, 24, 0]) cube([1, 1, 6.7]);

translate([17, 24, 0]) cube([1, 1, 6.6]);

translate([18, 24, 0]) cube([1, 1, 6.5]);

translate([19, 24, 0]) cube([1, 1, 6.4]);

translate([20, 24, 0]) cube([1, 1, 6.4]);

translate([21, 24, 0]) cube([1, 1, 6.5]);

translate([22, 24, 0]) cube([1, 1, 6.6]);

translate([23, 24, 0]) cube([1, 1, 6.5]);

translate([24, 24, 0]) cube([1, 1, 6.3]);

translate([25, 24, 0]) cube([1, 1, 6.1]);

translate([26, 24, 0]) cube([1, 1, 5.8]);

translate([27, 24, 0]) cube([1, 1, 5.6]);

translate([28, 24, 0]) cube([1, 1, 5.5]);

translate([29, 24, 0]) cube([1, 1, 5.5]);

translate([30, 24, 0]) cube([1, 1, 5.5]);

translate([31, 24, 0]) cube([1, 1, 5.6]);

translate([32, 24, 0]) cube([1, 1, 5.7]);

translate([33, 24, 0]) cube([1, 1, 5.8]);

translate([34, 24, 0]) cube([1, 1, 5.8]);

translate([35, 24, 0]) cube([1, 1, 5.9]);

translate([36, 24, 0]) cube([1, 1, 6.1]);

translate([37, 24, 0]) cube([1, 1, 6.2]);

translate([38, 24, 0]) cube([1, 1, 6.3]);

translate([39, 24, 0]) cube([1, 1, 6.4]);

translate([40, 24, 0]) cube([1, 1, 6.5]);

translate([41, 24, 0]) cube([1, 1, 6.6]);

translate([42, 24, 0]) cube([1, 1, 6.7]);

translate([43, 24, 0]) cube([1, 1, 6.7]);

translate([44, 24, 0]) cube([1, 1, 6.6]);

translate([45, 24, 0]) cube([1, 1, 6.4]);

translate([46, 24, 0]) cube([1, 1, 6.0]);

translate([47, 24, 0]) cube([1, 1, 5.5]);

translate([0, 25, 0]) cube([1, 1, 7.3]);

translate([1, 25, 0]) cube([1, 1, 7.1]);

translate([2, 25, 0]) cube([1, 1, 7.1]);

translate([3, 25, 0]) cube([1, 1, 7.0]);

translate([4, 25, 0]) cube([1, 1, 7.0]);

translate([5, 25, 0]) cube([1, 1, 6.9]);

translate([6, 25, 0]) cube([1, 1, 6.8]);

translate([7, 25, 0]) cube([1, 1, 6.6]);

translate([8, 25, 0]) cube([1, 1, 6.4]);

translate([9, 25, 0]) cube([1, 1, 6.3]);

translate([10, 25, 0]) cube([1, 1, 6.3]);

translate([11, 25, 0]) cube([1, 1, 6.3]);

translate([12, 25, 0]) cube([1, 1, 6.4]);

translate([13, 25, 0]) cube([1, 1, 6.4]);

translate([14, 25, 0]) cube([1, 1, 6.6]);

translate([15, 25, 0]) cube([1, 1, 6.6]);

translate([16, 25, 0]) cube([1, 1, 6.6]);

translate([17, 25, 0]) cube([1, 1, 6.5]);

translate([18, 25, 0]) cube([1, 1, 6.5]);

translate([19, 25, 0]) cube([1, 1, 6.5]);

translate([20, 25, 0]) cube([1, 1, 6.5]);

translate([21, 25, 0]) cube([1, 1, 6.6]);

translate([22, 25, 0]) cube([1, 1, 6.6]);

translate([23, 25, 0]) cube([1, 1, 6.5]);

translate([24, 25, 0]) cube([1, 1, 6.3]);

translate([25, 25, 0]) cube([1, 1, 6.0]);

translate([26, 25, 0]) cube([1, 1, 5.8]);

translate([27, 25, 0]) cube([1, 1, 5.5]);

translate([28, 25, 0]) cube([1, 1, 5.4]);

translate([29, 25, 0]) cube([1, 1, 5.4]);

translate([30, 25, 0]) cube([1, 1, 5.4]);

translate([31, 25, 0]) cube([1, 1, 5.5]);

translate([32, 25, 0]) cube([1, 1, 5.6]);

translate([33, 25, 0]) cube([1, 1, 5.6]);

translate([34, 25, 0]) cube([1, 1, 5.7]);

translate([35, 25, 0]) cube([1, 1, 5.8]);

translate([36, 25, 0]) cube([1, 1, 5.9]);

translate([37, 25, 0]) cube([1, 1, 6.1]);

translate([38, 25, 0]) cube([1, 1, 6.2]);

translate([39, 25, 0]) cube([1, 1, 6.2]);

translate([40, 25, 0]) cube([1, 1, 6.4]);

translate([41, 25, 0]) cube([1, 1, 6.5]);

translate([42, 25, 0]) cube([1, 1, 6.5]);

translate([43, 25, 0]) cube([1, 1, 6.5]);

translate([44, 25, 0]) cube([1, 1, 6.5]);

translate([45, 25, 0]) cube([1, 1, 6.3]);

translate([46, 25, 0]) cube([1, 1, 5.9]);

translate([47, 25, 0]) cube([1, 1, 5.5]);

translate([0, 26, 0]) cube([1, 1, 7.0]);

translate([1, 26, 0]) cube([1, 1, 6.8]);

translate([2, 26, 0]) cube([1, 1, 6.8]);

translate([3, 26, 0]) cube([1, 1, 6.8]);

translate([4, 26, 0]) cube([1, 1, 6.8]);

translate([5, 26, 0]) cube([1, 1, 6.7]);

translate([6, 26, 0]) cube([1, 1, 6.6]);

translate([7, 26, 0]) cube([1, 1, 6.5]);

translate([8, 26, 0]) cube([1, 1, 6.3]);

translate([9, 26, 0]) cube([1, 1, 6.1]);

translate([10, 26, 0]) cube([1, 1, 6.0]);

translate([11, 26, 0]) cube([1, 1, 6.0]);

translate([12, 26, 0]) cube([1, 1, 6.0]);

translate([13, 26, 0]) cube([1, 1, 6.1]);

translate([14, 26, 0]) cube([1, 1, 6.3]);

translate([15, 26, 0]) cube([1, 1, 6.4]);

translate([16, 26, 0]) cube([1, 1, 6.5]);

translate([17, 26, 0]) cube([1, 1, 6.5]);

translate([18, 26, 0]) cube([1, 1, 6.6]);

translate([19, 26, 0]) cube([1, 1, 6.6]);

translate([20, 26, 0]) cube([1, 1, 6.7]);

translate([21, 26, 0]) cube([1, 1, 6.7]);

translate([22, 26, 0]) cube([1, 1, 6.7]);

translate([23, 26, 0]) cube([1, 1, 6.5]);

translate([24, 26, 0]) cube([1, 1, 6.3]);

translate([25, 26, 0]) cube([1, 1, 6.1]);

translate([26, 26, 0]) cube([1, 1, 5.8]);

translate([27, 26, 0]) cube([1, 1, 5.6]);

translate([28, 26, 0]) cube([1, 1, 5.4]);

translate([29, 26, 0]) cube([1, 1, 5.3]);

translate([30, 26, 0]) cube([1, 1, 5.3]);

translate([31, 26, 0]) cube([1, 1, 5.3]);

translate([32, 26, 0]) cube([1, 1, 5.4]);

translate([33, 26, 0]) cube([1, 1, 5.5]);

translate([34, 26, 0]) cube([1, 1, 5.6]);

translate([35, 26, 0]) cube([1, 1, 5.7]);

translate([36, 26, 0]) cube([1, 1, 5.9]);

translate([37, 26, 0]) cube([1, 1, 6.0]);

translate([38, 26, 0]) cube([1, 1, 6.1]);

translate([39, 26, 0]) cube([1, 1, 6.2]);

translate([40, 26, 0]) cube([1, 1, 6.2]);

translate([41, 26, 0]) cube([1, 1, 6.3]);

translate([42, 26, 0]) cube([1, 1, 6.3]);

translate([43, 26, 0]) cube([1, 1, 6.3]);

translate([44, 26, 0]) cube([1, 1, 6.3]);

translate([45, 26, 0]) cube([1, 1, 6.1]);

translate([46, 26, 0]) cube([1, 1, 5.9]);

translate([47, 26, 0]) cube([1, 1, 5.5]);

translate([0, 27, 0]) cube([1, 1, 6.8]);

translate([1, 27, 0]) cube([1, 1, 6.6]);

translate([2, 27, 0]) cube([1, 1, 6.6]);

translate([3, 27, 0]) cube([1, 1, 6.6]);

translate([4, 27, 0]) cube([1, 1, 6.5]);

translate([5, 27, 0]) cube([1, 1, 6.5]);

translate([6, 27, 0]) cube([1, 1, 6.4]);

translate([7, 27, 0]) cube([1, 1, 6.3]);

translate([8, 27, 0]) cube([1, 1, 6.1]);

translate([9, 27, 0]) cube([1, 1, 5.9]);

translate([10, 27, 0]) cube([1, 1, 5.7]);

translate([11, 27, 0]) cube([1, 1, 5.7]);

translate([12, 27, 0]) cube([1, 1, 5.7]);

translate([13, 27, 0]) cube([1, 1, 5.8]);

translate([14, 27, 0]) cube([1, 1, 6.0]);

translate([15, 27, 0]) cube([1, 1, 6.1]);

translate([16, 27, 0]) cube([1, 1, 6.3]);

translate([17, 27, 0]) cube([1, 1, 6.4]);

translate([18, 27, 0]) cube([1, 1, 6.6]);

translate([19, 27, 0]) cube([1, 1, 6.7]);

translate([20, 27, 0]) cube([1, 1, 6.9]);

translate([21, 27, 0]) cube([1, 1, 6.9]);

translate([22, 27, 0]) cube([1, 1, 6.9]);

translate([23, 27, 0]) cube([1, 1, 6.7]);

translate([24, 27, 0]) cube([1, 1, 6.4]);

translate([25, 27, 0]) cube([1, 1, 6.2]);

translate([26, 27, 0]) cube([1, 1, 5.9]);

translate([27, 27, 0]) cube([1, 1, 5.7]);

translate([28, 27, 0]) cube([1, 1, 5.5]);

translate([29, 27, 0]) cube([1, 1, 5.3]);

translate([30, 27, 0]) cube([1, 1, 5.2]);

translate([31, 27, 0]) cube([1, 1, 5.2]);

translate([32, 27, 0]) cube([1, 1, 5.2]);

translate([33, 27, 0]) cube([1, 1, 5.3]);

translate([34, 27, 0]) cube([1, 1, 5.5]);

translate([35, 27, 0]) cube([1, 1, 5.7]);

translate([36, 27, 0]) cube([1, 1, 5.9]);

translate([37, 27, 0]) cube([1, 1, 6.0]);

translate([38, 27, 0]) cube([1, 1, 6.1]);

translate([39, 27, 0]) cube([1, 1, 6.1]);

translate([40, 27, 0]) cube([1, 1, 6.2]);

translate([41, 27, 0]) cube([1, 1, 6.2]);

translate([42, 27, 0]) cube([1, 1, 6.1]);

translate([43, 27, 0]) cube([1, 1, 6.1]);

translate([44, 27, 0]) cube([1, 1, 6.0]);

translate([45, 27, 0]) cube([1, 1, 6.0]);

translate([46, 27, 0]) cube([1, 1, 5.8]);

translate([47, 27, 0]) cube([1, 1, 5.5]);

translate([0, 28, 0]) cube([1, 1, 6.7]);

translate([1, 28, 0]) cube([1, 1, 6.6]);

translate([2, 28, 0]) cube([1, 1, 6.5]);

translate([3, 28, 0]) cube([1, 1, 6.4]);

translate([4, 28, 0]) cube([1, 1, 6.3]);

translate([5, 28, 0]) cube([1, 1, 6.3]);

translate([6, 28, 0]) cube([1, 1, 6.2]);

translate([7, 28, 0]) cube([1, 1, 6.1]);

translate([8, 28, 0]) cube([1, 1, 6.0]);

translate([9, 28, 0]) cube([1, 1, 5.7]);

translate([10, 28, 0]) cube([1, 1, 5.5]);

translate([11, 28, 0]) cube([1, 1, 5.4]);

translate([12, 28, 0]) cube([1, 1, 5.5]);

translate([13, 28, 0]) cube([1, 1, 5.6]);

translate([14, 28, 0]) cube([1, 1, 5.7]);

translate([15, 28, 0]) cube([1, 1, 5.9]);

translate([16, 28, 0]) cube([1, 1, 6.1]);

translate([17, 28, 0]) cube([1, 1, 6.3]);

translate([18, 28, 0]) cube([1, 1, 6.5]);

translate([19, 28, 0]) cube([1, 1, 6.8]);

translate([20, 28, 0]) cube([1, 1, 7.0]);

translate([21, 28, 0]) cube([1, 1, 7.1]);

translate([22, 28, 0]) cube([1, 1, 7.0]);

translate([23, 28, 0]) cube([1, 1, 6.8]);

translate([24, 28, 0]) cube([1, 1, 6.5]);

translate([25, 28, 0]) cube([1, 1, 6.3]);

translate([26, 28, 0]) cube([1, 1, 6.1]);

translate([27, 28, 0]) cube([1, 1, 5.9]);

translate([28, 28, 0]) cube([1, 1, 5.7]);

translate([29, 28, 0]) cube([1, 1, 5.5]);

translate([30, 28, 0]) cube([1, 1, 5.3]);

translate([31, 28, 0]) cube([1, 1, 5.2]);

translate([32, 28, 0]) cube([1, 1, 5.1]);

translate([33, 28, 0]) cube([1, 1, 5.3]);

translate([34, 28, 0]) cube([1, 1, 5.5]);

translate([35, 28, 0]) cube([1, 1, 5.7]);

translate([36, 28, 0]) cube([1, 1, 5.8]);

translate([37, 28, 0]) cube([1, 1, 5.9]);

translate([38, 28, 0]) cube([1, 1, 6.0]);

translate([39, 28, 0]) cube([1, 1, 6.1]);

translate([40, 28, 0]) cube([1, 1, 6.1]);

translate([41, 28, 0]) cube([1, 1, 6.1]);

translate([42, 28, 0]) cube([1, 1, 6.0]);

translate([43, 28, 0]) cube([1, 1, 5.9]);

translate([44, 28, 0]) cube([1, 1, 5.9]);

translate([45, 28, 0]) cube([1, 1, 5.8]);

translate([46, 28, 0]) cube([1, 1, 5.7]);

translate([47, 28, 0]) cube([1, 1, 5.5]);

translate([0, 29, 0]) cube([1, 1, 6.9]);

translate([1, 29, 0]) cube([1, 1, 6.7]);

translate([2, 29, 0]) cube([1, 1, 6.6]);

translate([3, 29, 0]) cube([1, 1, 6.4]);

translate([4, 29, 0]) cube([1, 1, 6.2]);

translate([5, 29, 0]) cube([1, 1, 6.0]);

translate([6, 29, 0]) cube([1, 1, 6.0]);

translate([7, 29, 0]) cube([1, 1, 5.9]);

translate([8, 29, 0]) cube([1, 1, 5.7]);

translate([9, 29, 0]) cube([1, 1, 5.5]);

translate([10, 29, 0]) cube([1, 1, 5.3]);

translate([11, 29, 0]) cube([1, 1, 5.3]);

translate([12, 29, 0]) cube([1, 1, 5.4]);

translate([13, 29, 0]) cube([1, 1, 5.5]);

translate([14, 29, 0]) cube([1, 1, 5.6]);

translate([15, 29, 0]) cube([1, 1, 5.7]);

translate([16, 29, 0]) cube([1, 1, 5.9]);

translate([17, 29, 0]) cube([1, 1, 6.1]);

translate([18, 29, 0]) cube([1, 1, 6.4]);

translate([19, 29, 0]) cube([1, 1, 6.7]);

translate([20, 29, 0]) cube([1, 1, 7.0]);

translate([21, 29, 0]) cube([1, 1, 7.1]);

translate([22, 29, 0]) cube([1, 1, 7.0]);

translate([23, 29, 0]) cube([1, 1, 6.8]);

translate([24, 29, 0]) cube([1, 1, 6.5]);

translate([25, 29, 0]) cube([1, 1, 6.3]);

translate([26, 29, 0]) cube([1, 1, 6.1]);

translate([27, 29, 0]) cube([1, 1, 6.0]);

translate([28, 29, 0]) cube([1, 1, 5.8]);

translate([29, 29, 0]) cube([1, 1, 5.6]);

translate([30, 29, 0]) cube([1, 1, 5.4]);

translate([31, 29, 0]) cube([1, 1, 5.3]);

translate([32, 29, 0]) cube([1, 1, 5.2]);

translate([33, 29, 0]) cube([1, 1, 5.3]);

translate([34, 29, 0]) cube([1, 1, 5.4]);

translate([35, 29, 0]) cube([1, 1, 5.6]);

translate([36, 29, 0]) cube([1, 1, 5.7]);

translate([37, 29, 0]) cube([1, 1, 5.8]);

translate([38, 29, 0]) cube([1, 1, 5.9]);

translate([39, 29, 0]) cube([1, 1, 6.0]);

translate([40, 29, 0]) cube([1, 1, 6.1]);

translate([41, 29, 0]) cube([1, 1, 6.1]);

translate([42, 29, 0]) cube([1, 1, 6.0]);

translate([43, 29, 0]) cube([1, 1, 5.8]);

translate([44, 29, 0]) cube([1, 1, 5.8]);

translate([45, 29, 0]) cube([1, 1, 5.7]);

translate([46, 29, 0]) cube([1, 1, 5.6]);

translate([47, 29, 0]) cube([1, 1, 5.3]);

translate([0, 30, 0]) cube([1, 1, 7.0]);

translate([1, 30, 0]) cube([1, 1, 6.9]);

translate([2, 30, 0]) cube([1, 1, 6.6]);

translate([3, 30, 0]) cube([1, 1, 6.3]);

translate([4, 30, 0]) cube([1, 1, 6.0]);

translate([5, 30, 0]) cube([1, 1, 5.8]);

translate([6, 30, 0]) cube([1, 1, 5.7]);

translate([7, 30, 0]) cube([1, 1, 5.6]);

translate([8, 30, 0]) cube([1, 1, 5.5]);

translate([9, 30, 0]) cube([1, 1, 5.4]);

translate([10, 30, 0]) cube([1, 1, 5.3]);

translate([11, 30, 0]) cube([1, 1, 5.3]);

translate([12, 30, 0]) cube([1, 1, 5.4]);

translate([13, 30, 0]) cube([1, 1, 5.6]);

translate([14, 30, 0]) cube([1, 1, 5.7]);

translate([15, 30, 0]) cube([1, 1, 5.7]);

translate([16, 30, 0]) cube([1, 1, 5.9]);

translate([17, 30, 0]) cube([1, 1, 6.1]);

translate([18, 30, 0]) cube([1, 1, 6.4]);

translate([19, 30, 0]) cube([1, 1, 6.6]);

translate([20, 30, 0]) cube([1, 1, 6.9]);

translate([21, 30, 0]) cube([1, 1, 7.0]);

translate([22, 30, 0]) cube([1, 1, 6.9]);

translate([23, 30, 0]) cube([1, 1, 6.7]);

translate([24, 30, 0]) cube([1, 1, 6.4]);

translate([25, 30, 0]) cube([1, 1, 6.2]);

translate([26, 30, 0]) cube([1, 1, 6.0]);

translate([27, 30, 0]) cube([1, 1, 5.9]);

translate([28, 30, 0]) cube([1, 1, 5.9]);

translate([29, 30, 0]) cube([1, 1, 5.8]);

translate([30, 30, 0]) cube([1, 1, 5.6]);

translate([31, 30, 0]) cube([1, 1, 5.4]);

translate([32, 30, 0]) cube([1, 1, 5.3]);

translate([33, 30, 0]) cube([1, 1, 5.3]);

translate([34, 30, 0]) cube([1, 1, 5.4]);

translate([35, 30, 0]) cube([1, 1, 5.5]);

translate([36, 30, 0]) cube([1, 1, 5.5]);

translate([37, 30, 0]) cube([1, 1, 5.6]);

translate([38, 30, 0]) cube([1, 1, 5.7]);

translate([39, 30, 0]) cube([1, 1, 5.8]);

translate([40, 30, 0]) cube([1, 1, 5.9]);

translate([41, 30, 0]) cube([1, 1, 5.9]);

translate([42, 30, 0]) cube([1, 1, 5.9]);

translate([43, 30, 0]) cube([1, 1, 5.8]);

translate([44, 30, 0]) cube([1, 1, 5.7]);

translate([45, 30, 0]) cube([1, 1, 5.6]);

translate([46, 30, 0]) cube([1, 1, 5.4]);

translate([47, 30, 0]) cube([1, 1, 5.1]);

translate([0, 31, 0]) cube([1, 1, 7.1]);

translate([1, 31, 0]) cube([1, 1, 7.0]);

translate([2, 31, 0]) cube([1, 1, 6.7]);

translate([3, 31, 0]) cube([1, 1, 6.3]);

translate([4, 31, 0]) cube([1, 1, 5.9]);

translate([5, 31, 0]) cube([1, 1, 5.6]);

translate([6, 31, 0]) cube([1, 1, 5.5]);

translate([7, 31, 0]) cube([1, 1, 5.4]);

translate([8, 31, 0]) cube([1, 1, 5.3]);

translate([9, 31, 0]) cube([1, 1, 5.3]);

translate([10, 31, 0]) cube([1, 1, 5.3]);

translate([11, 31, 0]) cube([1, 1, 5.4]);

translate([12, 31, 0]) cube([1, 1, 5.5]);

translate([13, 31, 0]) cube([1, 1, 5.7]);

translate([14, 31, 0]) cube([1, 1, 5.8]);

translate([15, 31, 0]) cube([1, 1, 5.8]);

translate([16, 31, 0]) cube([1, 1, 5.9]);

translate([17, 31, 0]) cube([1, 1, 6.1]);

translate([18, 31, 0]) cube([1, 1, 6.3]);

translate([19, 31, 0]) cube([1, 1, 6.6]);

translate([20, 31, 0]) cube([1, 1, 6.8]);

translate([21, 31, 0]) cube([1, 1, 6.9]);

translate([22, 31, 0]) cube([1, 1, 6.8]);

translate([23, 31, 0]) cube([1, 1, 6.5]);

translate([24, 31, 0]) cube([1, 1, 6.2]);

translate([25, 31, 0]) cube([1, 1, 6.0]);

translate([26, 31, 0]) cube([1, 1, 5.9]);

translate([27, 31, 0]) cube([1, 1, 5.9]);

translate([28, 31, 0]) cube([1, 1, 5.9]);

translate([29, 31, 0]) cube([1, 1, 5.8]);

translate([30, 31, 0]) cube([1, 1, 5.7]);

translate([31, 31, 0]) cube([1, 1, 5.5]);

translate([32, 31, 0]) cube([1, 1, 5.4]);

translate([33, 31, 0]) cube([1, 1, 5.3]);

translate([34, 31, 0]) cube([1, 1, 5.3]);

translate([35, 31, 0]) cube([1, 1, 5.3]);

translate([36, 31, 0]) cube([1, 1, 5.3]);

translate([37, 31, 0]) cube([1, 1, 5.4]);

translate([38, 31, 0]) cube([1, 1, 5.5]);

translate([39, 31, 0]) cube([1, 1, 5.7]);

translate([40, 31, 0]) cube([1, 1, 5.8]);

translate([41, 31, 0]) cube([1, 1, 5.8]);

translate([42, 31, 0]) cube([1, 1, 5.8]);

translate([43, 31, 0]) cube([1, 1, 5.7]);

translate([44, 31, 0]) cube([1, 1, 5.6]);

translate([45, 31, 0]) cube([1, 1, 5.5]);

translate([46, 31, 0]) cube([1, 1, 5.3]);

translate([47, 31, 0]) cube([1, 1, 5.0]);

translate([0, 32, 0]) cube([1, 1, 7.2]);

translate([1, 32, 0]) cube([1, 1, 7.0]);

translate([2, 32, 0]) cube([1, 1, 6.7]);

translate([3, 32, 0]) cube([1, 1, 6.3]);

translate([4, 32, 0]) cube([1, 1, 5.8]);

translate([5, 32, 0]) cube([1, 1, 5.5]);

translate([6, 32, 0]) cube([1, 1, 5.3]);

translate([7, 32, 0]) cube([1, 1, 5.2]);

translate([8, 32, 0]) cube([1, 1, 5.3]);

translate([9, 32, 0]) cube([1, 1, 5.3]);

translate([10, 32, 0]) cube([1, 1, 5.4]);

translate([11, 32, 0]) cube([1, 1, 5.6]);

translate([12, 32, 0]) cube([1, 1, 5.8]);

translate([13, 32, 0]) cube([1, 1, 5.9]);

translate([14, 32, 0]) cube([1, 1, 6.0]);

translate([15, 32, 0]) cube([1, 1, 5.9]);

translate([16, 32, 0]) cube([1, 1, 5.9]);

translate([17, 32, 0]) cube([1, 1, 6.1]);

translate([18, 32, 0]) cube([1, 1, 6.3]);

translate([19, 32, 0]) cube([1, 1, 6.6]);

translate([20, 32, 0]) cube([1, 1, 6.8]);

translate([21, 32, 0]) cube([1, 1, 6.8]);

translate([22, 32, 0]) cube([1, 1, 6.7]);

translate([23, 32, 0]) cube([1, 1, 6.5]);

translate([24, 32, 0]) cube([1, 1, 6.2]);

translate([25, 32, 0]) cube([1, 1, 5.9]);

translate([26, 32, 0]) cube([1, 1, 5.8]);

translate([27, 32, 0]) cube([1, 1, 5.8]);

translate([28, 32, 0]) cube([1, 1, 5.8]);

translate([29, 32, 0]) cube([1, 1, 5.8]);

translate([30, 32, 0]) cube([1, 1, 5.7]);

translate([31, 32, 0]) cube([1, 1, 5.6]);

translate([32, 32, 0]) cube([1, 1, 5.5]);

translate([33, 32, 0]) cube([1, 1, 5.4]);

translate([34, 32, 0]) cube([1, 1, 5.4]);

translate([35, 32, 0]) cube([1, 1, 5.4]);

translate([36, 32, 0]) cube([1, 1, 5.3]);

translate([37, 32, 0]) cube([1, 1, 5.3]);

translate([38, 32, 0]) cube([1, 1, 5.4]);

translate([39, 32, 0]) cube([1, 1, 5.6]);

translate([40, 32, 0]) cube([1, 1, 5.8]);

translate([41, 32, 0]) cube([1, 1, 5.8]);

translate([42, 32, 0]) cube([1, 1, 5.8]);

translate([43, 32, 0]) cube([1, 1, 5.7]);

translate([44, 32, 0]) cube([1, 1, 5.5]);

translate([45, 32, 0]) cube([1, 1, 5.4]);

translate([46, 32, 0]) cube([1, 1, 5.1]);

translate([47, 32, 0]) cube([1, 1, 4.9]);

translate([0, 33, 0]) cube([1, 1, 7.1]);

translate([1, 33, 0]) cube([1, 1, 7.0]);

translate([2, 33, 0]) cube([1, 1, 6.7]);

translate([3, 33, 0]) cube([1, 1, 6.2]);

translate([4, 33, 0]) cube([1, 1, 5.7]);

translate([5, 33, 0]) cube([1, 1, 5.4]);

translate([6, 33, 0]) cube([1, 1, 5.2]);

translate([7, 33, 0]) cube([1, 1, 5.2]);

translate([8, 33, 0]) cube([1, 1, 5.3]);

translate([9, 33, 0]) cube([1, 1, 5.5]);

translate([10, 33, 0]) cube([1, 1, 5.7]);

translate([11, 33, 0]) cube([1, 1, 5.8]);

translate([12, 33, 0]) cube([1, 1, 6.0]);

translate([13, 33, 0]) cube([1, 1, 6.1]);

translate([14, 33, 0]) cube([1, 1, 6.1]);

translate([15, 33, 0]) cube([1, 1, 6.0]);

translate([16, 33, 0]) cube([1, 1, 6.0]);

translate([17, 33, 0]) cube([1, 1, 6.2]);

translate([18, 33, 0]) cube([1, 1, 6.4]);

translate([19, 33, 0]) cube([1, 1, 6.6]);

translate([20, 33, 0]) cube([1, 1, 6.8]);

translate([21, 33, 0]) cube([1, 1, 6.8]);

translate([22, 33, 0]) cube([1, 1, 6.7]);

translate([23, 33, 0]) cube([1, 1, 6.5]);

translate([24, 33, 0]) cube([1, 1, 6.2]);

translate([25, 33, 0]) cube([1, 1, 5.9]);

translate([26, 33, 0]) cube([1, 1, 5.8]);

translate([27, 33, 0]) cube([1, 1, 5.7]);

translate([28, 33, 0]) cube([1, 1, 5.7]);

translate([29, 33, 0]) cube([1, 1, 5.7]);

translate([30, 33, 0]) cube([1, 1, 5.7]);

translate([31, 33, 0]) cube([1, 1, 5.6]);

translate([32, 33, 0]) cube([1, 1, 5.6]);

translate([33, 33, 0]) cube([1, 1, 5.5]);

translate([34, 33, 0]) cube([1, 1, 5.5]);

translate([35, 33, 0]) cube([1, 1, 5.5]);

translate([36, 33, 0]) cube([1, 1, 5.4]);

translate([37, 33, 0]) cube([1, 1, 5.4]);

translate([38, 33, 0]) cube([1, 1, 5.4]);

translate([39, 33, 0]) cube([1, 1, 5.6]);

translate([40, 33, 0]) cube([1, 1, 5.7]);

translate([41, 33, 0]) cube([1, 1, 5.7]);

translate([42, 33, 0]) cube([1, 1, 5.7]);

translate([43, 33, 0]) cube([1, 1, 5.6]);

translate([44, 33, 0]) cube([1, 1, 5.4]);

translate([45, 33, 0]) cube([1, 1, 5.2]);

translate([46, 33, 0]) cube([1, 1, 5.0]);

translate([47, 33, 0]) cube([1, 1, 4.8]);

translate([0, 34, 0]) cube([1, 1, 7.0]);

translate([1, 34, 0]) cube([1, 1, 6.9]);

translate([2, 34, 0]) cube([1, 1, 6.6]);

translate([3, 34, 0]) cube([1, 1, 6.2]);

translate([4, 34, 0]) cube([1, 1, 5.7]);

translate([5, 34, 0]) cube([1, 1, 5.4]);

translate([6, 34, 0]) cube([1, 1, 5.3]);

translate([7, 34, 0]) cube([1, 1, 5.3]);

translate([8, 34, 0]) cube([1, 1, 5.5]);

translate([9, 34, 0]) cube([1, 1, 5.7]);

translate([10, 34, 0]) cube([1, 1, 5.8]);

translate([11, 34, 0]) cube([1, 1, 6.0]);

translate([12, 34, 0]) cube([1, 1, 6.1]);

translate([13, 34, 0]) cube([1, 1, 6.1]);

translate([14, 34, 0]) cube([1, 1, 6.1]);

translate([15, 34, 0]) cube([1, 1, 6.1]);

translate([16, 34, 0]) cube([1, 1, 6.2]);

translate([17, 34, 0]) cube([1, 1, 6.4]);

translate([18, 34, 0]) cube([1, 1, 6.6]);

translate([19, 34, 0]) cube([1, 1, 6.7]);

translate([20, 34, 0]) cube([1, 1, 6.9]);

translate([21, 34, 0]) cube([1, 1, 6.9]);

translate([22, 34, 0]) cube([1, 1, 6.8]);

translate([23, 34, 0]) cube([1, 1, 6.5]);

translate([24, 34, 0]) cube([1, 1, 6.3]);

translate([25, 34, 0]) cube([1, 1, 6.0]);

translate([26, 34, 0]) cube([1, 1, 5.8]);

translate([27, 34, 0]) cube([1, 1, 5.7]);

translate([28, 34, 0]) cube([1, 1, 5.6]);

translate([29, 34, 0]) cube([1, 1, 5.6]);

translate([30, 34, 0]) cube([1, 1, 5.7]);

translate([31, 34, 0]) cube([1, 1, 5.7]);

translate([32, 34, 0]) cube([1, 1, 5.7]);

translate([33, 34, 0]) cube([1, 1, 5.7]);

translate([34, 34, 0]) cube([1, 1, 5.7]);

translate([35, 34, 0]) cube([1, 1, 5.7]);

translate([36, 34, 0]) cube([1, 1, 5.6]);

translate([37, 34, 0]) cube([1, 1, 5.5]);

translate([38, 34, 0]) cube([1, 1, 5.5]);

translate([39, 34, 0]) cube([1, 1, 5.6]);

translate([40, 34, 0]) cube([1, 1, 5.6]);

translate([41, 34, 0]) cube([1, 1, 5.6]);

translate([42, 34, 0]) cube([1, 1, 5.6]);

translate([43, 34, 0]) cube([1, 1, 5.4]);

translate([44, 34, 0]) cube([1, 1, 5.3]);

translate([45, 34, 0]) cube([1, 1, 5.1]);

translate([46, 34, 0]) cube([1, 1, 4.9]);

translate([47, 34, 0]) cube([1, 1, 4.8]);

translate([0, 35, 0]) cube([1, 1, 6.8]);

translate([1, 35, 0]) cube([1, 1, 6.7]);

translate([2, 35, 0]) cube([1, 1, 6.5]);

translate([3, 35, 0]) cube([1, 1, 6.1]);

translate([4, 35, 0]) cube([1, 1, 5.8]);

translate([5, 35, 0]) cube([1, 1, 5.5]);

translate([6, 35, 0]) cube([1, 1, 5.5]);

translate([7, 35, 0]) cube([1, 1, 5.5]);

translate([8, 35, 0]) cube([1, 1, 5.7]);

translate([9, 35, 0]) cube([1, 1, 5.8]);

translate([10, 35, 0]) cube([1, 1, 6.0]);

translate([11, 35, 0]) cube([1, 1, 6.0]);

translate([12, 35, 0]) cube([1, 1, 6.1]);

translate([13, 35, 0]) cube([1, 1, 6.1]);

translate([14, 35, 0]) cube([1, 1, 6.1]);

translate([15, 35, 0]) cube([1, 1, 6.2]);

translate([16, 35, 0]) cube([1, 1, 6.4]);

translate([17, 35, 0]) cube([1, 1, 6.6]);

translate([18, 35, 0]) cube([1, 1, 6.8]);

translate([19, 35, 0]) cube([1, 1, 6.9]);

translate([20, 35, 0]) cube([1, 1, 7.0]);

translate([21, 35, 0]) cube([1, 1, 7.0]);

translate([22, 35, 0]) cube([1, 1, 6.8]);

translate([23, 35, 0]) cube([1, 1, 6.5]);

translate([24, 35, 0]) cube([1, 1, 6.3]);

translate([25, 35, 0]) cube([1, 1, 6.0]);

translate([26, 35, 0]) cube([1, 1, 5.8]);

translate([27, 35, 0]) cube([1, 1, 5.6]);

translate([28, 35, 0]) cube([1, 1, 5.6]);

translate([29, 35, 0]) cube([1, 1, 5.7]);

translate([30, 35, 0]) cube([1, 1, 5.7]);

translate([31, 35, 0]) cube([1, 1, 5.8]);

translate([32, 35, 0]) cube([1, 1, 5.8]);

translate([33, 35, 0]) cube([1, 1, 5.8]);

translate([34, 35, 0]) cube([1, 1, 5.8]);

translate([35, 35, 0]) cube([1, 1, 5.8]);

translate([36, 35, 0]) cube([1, 1, 5.6]);

translate([37, 35, 0]) cube([1, 1, 5.5]);

translate([38, 35, 0]) cube([1, 1, 5.5]);

translate([39, 35, 0]) cube([1, 1, 5.5]);

translate([40, 35, 0]) cube([1, 1, 5.5]);

translate([41, 35, 0]) cube([1, 1, 5.5]);

translate([42, 35, 0]) cube([1, 1, 5.4]);

translate([43, 35, 0]) cube([1, 1, 5.3]);

translate([44, 35, 0]) cube([1, 1, 5.1]);

translate([45, 35, 0]) cube([1, 1, 4.9]);

translate([46, 35, 0]) cube([1, 1, 4.8]);

translate([47, 35, 0]) cube([1, 1, 4.7]);

translate([0, 36, 0]) cube([1, 1, 6.6]);

translate([1, 36, 0]) cube([1, 1, 6.5]);

translate([2, 36, 0]) cube([1, 1, 6.3]);

translate([3, 36, 0]) cube([1, 1, 6.1]);

translate([4, 36, 0]) cube([1, 1, 5.8]);

translate([5, 36, 0]) cube([1, 1, 5.6]);

translate([6, 36, 0]) cube([1, 1, 5.6]);

translate([7, 36, 0]) cube([1, 1, 5.7]);

translate([8, 36, 0]) cube([1, 1, 5.8]);

translate([9, 36, 0]) cube([1, 1, 6.0]);

translate([10, 36, 0]) cube([1, 1, 6.0]);

translate([11, 36, 0]) cube([1, 1, 6.0]);

translate([12, 36, 0]) cube([1, 1, 6.1]);

translate([13, 36, 0]) cube([1, 1, 6.1]);

translate([14, 36, 0]) cube([1, 1, 6.2]);

translate([15, 36, 0]) cube([1, 1, 6.3]);

translate([16, 36, 0]) cube([1, 1, 6.6]);

translate([17, 36, 0]) cube([1, 1, 6.8]);

translate([18, 36, 0]) cube([1, 1, 7.0]);

translate([19, 36, 0]) cube([1, 1, 7.1]);

translate([20, 36, 0]) cube([1, 1, 7.1]);

translate([21, 36, 0]) cube([1, 1, 7.1]);

translate([22, 36, 0]) cube([1, 1, 6.8]);

translate([23, 36, 0]) cube([1, 1, 6.5]);

translate([24, 36, 0]) cube([1, 1, 6.2]);

translate([25, 36, 0]) cube([1, 1, 5.9]);

translate([26, 36, 0]) cube([1, 1, 5.8]);

translate([27, 36, 0]) cube([1, 1, 5.7]);

translate([28, 36, 0]) cube([1, 1, 5.7]);

translate([29, 36, 0]) cube([1, 1, 5.8]);

translate([30, 36, 0]) cube([1, 1, 5.9]);

translate([31, 36, 0]) cube([1, 1, 6.0]);

translate([32, 36, 0]) cube([1, 1, 6.0]);

translate([33, 36, 0]) cube([1, 1, 6.0]);

translate([34, 36, 0]) cube([1, 1, 5.9]);

translate([35, 36, 0]) cube([1, 1, 5.8]);

translate([36, 36, 0]) cube([1, 1, 5.6]);

translate([37, 36, 0]) cube([1, 1, 5.5]);

translate([38, 36, 0]) cube([1, 1, 5.5]);

translate([39, 36, 0]) cube([1, 1, 5.5]);

translate([40, 36, 0]) cube([1, 1, 5.4]);

translate([41, 36, 0]) cube([1, 1, 5.4]);

translate([42, 36, 0]) cube([1, 1, 5.3]);

translate([43, 36, 0]) cube([1, 1, 5.1]);

translate([44, 36, 0]) cube([1, 1, 4.9]);

translate([45, 36, 0]) cube([1, 1, 4.8]);

translate([46, 36, 0]) cube([1, 1, 4.7]);

translate([47, 36, 0]) cube([1, 1, 4.6]);

translate([0, 37, 0]) cube([1, 1, 6.5]);

translate([1, 37, 0]) cube([1, 1, 6.4]);

translate([2, 37, 0]) cube([1, 1, 6.2]);

translate([3, 37, 0]) cube([1, 1, 6.0]);

translate([4, 37, 0]) cube([1, 1, 5.8]);

translate([5, 37, 0]) cube([1, 1, 5.7]);

translate([6, 37, 0]) cube([1, 1, 5.7]);

translate([7, 37, 0]) cube([1, 1, 5.8]);

translate([8, 37, 0]) cube([1, 1, 6.0]);

translate([9, 37, 0]) cube([1, 1, 6.0]);

translate([10, 37, 0]) cube([1, 1, 6.1]);

translate([11, 37, 0]) cube([1, 1, 6.1]);

translate([12, 37, 0]) cube([1, 1, 6.1]);

translate([13, 37, 0]) cube([1, 1, 6.2]);

translate([14, 37, 0]) cube([1, 1, 6.2]);

translate([15, 37, 0]) cube([1, 1, 6.4]);

translate([16, 37, 0]) cube([1, 1, 6.7]);

translate([17, 37, 0]) cube([1, 1, 7.0]);

translate([18, 37, 0]) cube([1, 1, 7.2]);

translate([19, 37, 0]) cube([1, 1, 7.2]);

translate([20, 37, 0]) cube([1, 1, 7.2]);

translate([21, 37, 0]) cube([1, 1, 7.0]);

translate([22, 37, 0]) cube([1, 1, 6.7]);

translate([23, 37, 0]) cube([1, 1, 6.4]);

translate([24, 37, 0]) cube([1, 1, 6.1]);

translate([25, 37, 0]) cube([1, 1, 5.9]);

translate([26, 37, 0]) cube([1, 1, 5.7]);

translate([27, 37, 0]) cube([1, 1, 5.8]);

translate([28, 37, 0]) cube([1, 1, 5.9]);

translate([29, 37, 0]) cube([1, 1, 6.0]);

translate([30, 37, 0]) cube([1, 1, 6.1]);

translate([31, 37, 0]) cube([1, 1, 6.2]);

translate([32, 37, 0]) cube([1, 1, 6.2]);

translate([33, 37, 0]) cube([1, 1, 6.1]);

translate([34, 37, 0]) cube([1, 1, 5.9]);

translate([35, 37, 0]) cube([1, 1, 5.8]);

translate([36, 37, 0]) cube([1, 1, 5.6]);

translate([37, 37, 0]) cube([1, 1, 5.5]);

translate([38, 37, 0]) cube([1, 1, 5.4]);

translate([39, 37, 0]) cube([1, 1, 5.4]);

translate([40, 37, 0]) cube([1, 1, 5.4]);

translate([41, 37, 0]) cube([1, 1, 5.3]);

translate([42, 37, 0]) cube([1, 1, 5.2]);

translate([43, 37, 0]) cube([1, 1, 5.1]);

translate([44, 37, 0]) cube([1, 1, 4.9]);

translate([45, 37, 0]) cube([1, 1, 4.7]);

translate([46, 37, 0]) cube([1, 1, 4.6]);

translate([47, 37, 0]) cube([1, 1, 4.5]);

translate([0, 38, 0]) cube([1, 1, 6.4]);

translate([1, 38, 0]) cube([1, 1, 6.3]);

translate([2, 38, 0]) cube([1, 1, 6.2]);

translate([3, 38, 0]) cube([1, 1, 6.1]);

translate([4, 38, 0]) cube([1, 1, 5.9]);

translate([5, 38, 0]) cube([1, 1, 5.9]);

translate([6, 38, 0]) cube([1, 1, 5.9]);

translate([7, 38, 0]) cube([1, 1, 6.0]);

translate([8, 38, 0]) cube([1, 1, 6.0]);

translate([9, 38, 0]) cube([1, 1, 6.1]);

translate([10, 38, 0]) cube([1, 1, 6.1]);

translate([11, 38, 0]) cube([1, 1, 6.1]);

translate([12, 38, 0]) cube([1, 1, 6.1]);

translate([13, 38, 0]) cube([1, 1, 6.2]);

translate([14, 38, 0]) cube([1, 1, 6.4]);

translate([15, 38, 0]) cube([1, 1, 6.6]);

translate([16, 38, 0]) cube([1, 1, 6.8]);

translate([17, 38, 0]) cube([1, 1, 7.0]);

translate([18, 38, 0]) cube([1, 1, 7.2]);

translate([19, 38, 0]) cube([1, 1, 7.2]);

translate([20, 38, 0]) cube([1, 1, 7.1]);

translate([21, 38, 0]) cube([1, 1, 6.9]);

translate([22, 38, 0]) cube([1, 1, 6.5]);

translate([23, 38, 0]) cube([1, 1, 6.2]);

translate([24, 38, 0]) cube([1, 1, 6.0]);

translate([25, 38, 0]) cube([1, 1, 5.8]);

translate([26, 38, 0]) cube([1, 1, 5.8]);

translate([27, 38, 0]) cube([1, 1, 5.9]);

translate([28, 38, 0]) cube([1, 1, 6.1]);

translate([29, 38, 0]) cube([1, 1, 6.3]);

translate([30, 38, 0]) cube([1, 1, 6.3]);

translate([31, 38, 0]) cube([1, 1, 6.4]);

translate([32, 38, 0]) cube([1, 1, 6.3]);

translate([33, 38, 0]) cube([1, 1, 6.1]);

translate([34, 38, 0]) cube([1, 1, 5.9]);

translate([35, 38, 0]) cube([1, 1, 5.7]);

translate([36, 38, 0]) cube([1, 1, 5.5]);

translate([37, 38, 0]) cube([1, 1, 5.4]);

translate([38, 38, 0]) cube([1, 1, 5.4]);

translate([39, 38, 0]) cube([1, 1, 5.4]);

translate([40, 38, 0]) cube([1, 1, 5.4]);

translate([41, 38, 0]) cube([1, 1, 5.4]);

translate([42, 38, 0]) cube([1, 1, 5.3]);

translate([43, 38, 0]) cube([1, 1, 5.1]);

translate([44, 38, 0]) cube([1, 1, 5.0]);

translate([45, 38, 0]) cube([1, 1, 4.8]);

translate([46, 38, 0]) cube([1, 1, 4.6]);

translate([47, 38, 0]) cube([1, 1, 4.5]);

translate([0, 39, 0]) cube([1, 1, 6.4]);

translate([1, 39, 0]) cube([1, 1, 6.3]);

translate([2, 39, 0]) cube([1, 1, 6.2]);

translate([3, 39, 0]) cube([1, 1, 6.2]);

translate([4, 39, 0]) cube([1, 1, 6.1]);

translate([5, 39, 0]) cube([1, 1, 6.0]);

translate([6, 39, 0]) cube([1, 1, 6.0]);

translate([7, 39, 0]) cube([1, 1, 6.0]);

translate([8, 39, 0]) cube([1, 1, 6.0]);

translate([9, 39, 0]) cube([1, 1, 6.0]);

translate([10, 39, 0]) cube([1, 1, 6.0]);

translate([11, 39, 0]) cube([1, 1, 6.1]);

translate([12, 39, 0]) cube([1, 1, 6.2]);

translate([13, 39, 0]) cube([1, 1, 6.4]);

translate([14, 39, 0]) cube([1, 1, 6.5]);

translate([15, 39, 0]) cube([1, 1, 6.7]);

translate([16, 39, 0]) cube([1, 1, 6.8]);

translate([17, 39, 0]) cube([1, 1, 6.9]);

translate([18, 39, 0]) cube([1, 1, 7.0]);

translate([19, 39, 0]) cube([1, 1, 7.0]);

translate([20, 39, 0]) cube([1, 1, 6.8]);

translate([21, 39, 0]) cube([1, 1, 6.6]);

translate([22, 39, 0]) cube([1, 1, 6.3]);

translate([23, 39, 0]) cube([1, 1, 6.0]);

translate([24, 39, 0]) cube([1, 1, 5.9]);

translate([25, 39, 0]) cube([1, 1, 5.8]);

translate([26, 39, 0]) cube([1, 1, 5.9]);

translate([27, 39, 0]) cube([1, 1, 6.1]);

translate([28, 39, 0]) cube([1, 1, 6.3]);

translate([29, 39, 0]) cube([1, 1, 6.4]);

translate([30, 39, 0]) cube([1, 1, 6.5]);

translate([31, 39, 0]) cube([1, 1, 6.4]);

translate([32, 39, 0]) cube([1, 1, 6.3]);

translate([33, 39, 0]) cube([1, 1, 6.0]);

translate([34, 39, 0]) cube([1, 1, 5.8]);

translate([35, 39, 0]) cube([1, 1, 5.6]);

translate([36, 39, 0]) cube([1, 1, 5.5]);

translate([37, 39, 0]) cube([1, 1, 5.4]);

translate([38, 39, 0]) cube([1, 1, 5.4]);

translate([39, 39, 0]) cube([1, 1, 5.4]);

translate([40, 39, 0]) cube([1, 1, 5.5]);

translate([41, 39, 0]) cube([1, 1, 5.4]);

translate([42, 39, 0]) cube([1, 1, 5.4]);

translate([43, 39, 0]) cube([1, 1, 5.3]);

translate([44, 39, 0]) cube([1, 1, 5.2]);

translate([45, 39, 0]) cube([1, 1, 5.0]);

translate([46, 39, 0]) cube([1, 1, 4.8]);

translate([47, 39, 0]) cube([1, 1, 4.6]);

translate([0, 40, 0]) cube([1, 1, 6.4]);

translate([1, 40, 0]) cube([1, 1, 6.3]);

translate([2, 40, 0]) cube([1, 1, 6.2]);

translate([3, 40, 0]) cube([1, 1, 6.2]);

translate([4, 40, 0]) cube([1, 1, 6.1]);

translate([5, 40, 0]) cube([1, 1, 6.1]);

translate([6, 40, 0]) cube([1, 1, 6.0]);

translate([7, 40, 0]) cube([1, 1, 6.0]);

translate([8, 40, 0]) cube([1, 1, 5.9]);

translate([9, 40, 0]) cube([1, 1, 5.9]);

translate([10, 40, 0]) cube([1, 1, 6.0]);

translate([11, 40, 0]) cube([1, 1, 6.1]);

translate([12, 40, 0]) cube([1, 1, 6.3]);

translate([13, 40, 0]) cube([1, 1, 6.5]);

translate([14, 40, 0]) cube([1, 1, 6.6]);

translate([15, 40, 0]) cube([1, 1, 6.7]);

translate([16, 40, 0]) cube([1, 1, 6.8]);

translate([17, 40, 0]) cube([1, 1, 6.8]);

translate([18, 40, 0]) cube([1, 1, 6.8]);

translate([19, 40, 0]) cube([1, 1, 6.7]);

translate([20, 40, 0]) cube([1, 1, 6.5]);

translate([21, 40, 0]) cube([1, 1, 6.3]);

translate([22, 40, 0]) cube([1, 1, 6.1]);

translate([23, 40, 0]) cube([1, 1, 6.0]);

translate([24, 40, 0]) cube([1, 1, 5.9]);

translate([25, 40, 0]) cube([1, 1, 5.9]);

translate([26, 40, 0]) cube([1, 1, 6.1]);

translate([27, 40, 0]) cube([1, 1, 6.3]);

translate([28, 40, 0]) cube([1, 1, 6.4]);

translate([29, 40, 0]) cube([1, 1, 6.5]);

translate([30, 40, 0]) cube([1, 1, 6.4]);

translate([31, 40, 0]) cube([1, 1, 6.4]);

translate([32, 40, 0]) cube([1, 1, 6.2]);

translate([33, 40, 0]) cube([1, 1, 5.9]);

translate([34, 40, 0]) cube([1, 1, 5.7]);

translate([35, 40, 0]) cube([1, 1, 5.6]);

translate([36, 40, 0]) cube([1, 1, 5.5]);

translate([37, 40, 0]) cube([1, 1, 5.5]);

translate([38, 40, 0]) cube([1, 1, 5.5]);

translate([39, 40, 0]) cube([1, 1, 5.5]);

translate([40, 40, 0]) cube([1, 1, 5.5]);

translate([41, 40, 0]) cube([1, 1, 5.5]);

translate([42, 40, 0]) cube([1, 1, 5.5]);

translate([43, 40, 0]) cube([1, 1, 5.5]);

translate([44, 40, 0]) cube([1, 1, 5.5]);

translate([45, 40, 0]) cube([1, 1, 5.3]);

translate([46, 40, 0]) cube([1, 1, 5.1]);

translate([47, 40, 0]) cube([1, 1, 4.8]);

translate([0, 41, 0]) cube([1, 1, 6.3]);

translate([1, 41, 0]) cube([1, 1, 6.2]);

translate([2, 41, 0]) cube([1, 1, 6.1]);

translate([3, 41, 0]) cube([1, 1, 6.1]);

translate([4, 41, 0]) cube([1, 1, 6.1]);

translate([5, 41, 0]) cube([1, 1, 6.0]);

translate([6, 41, 0]) cube([1, 1, 5.9]);

translate([7, 41, 0]) cube([1, 1, 5.9]);

translate([8, 41, 0]) cube([1, 1, 5.8]);

translate([9, 41, 0]) cube([1, 1, 5.8]);

translate([10, 41, 0]) cube([1, 1, 5.9]);

translate([11, 41, 0]) cube([1, 1, 6.1]);

translate([12, 41, 0]) cube([1, 1, 6.3]);

translate([13, 41, 0]) cube([1, 1, 6.5]);

translate([14, 41, 0]) cube([1, 1, 6.7]);

translate([15, 41, 0]) cube([1, 1, 6.7]);

translate([16, 41, 0]) cube([1, 1, 6.6]);

translate([17, 41, 0]) cube([1, 1, 6.6]);

translate([18, 41, 0]) cube([1, 1, 6.5]);

translate([19, 41, 0]) cube([1, 1, 6.4]);

translate([20, 41, 0]) cube([1, 1, 6.3]);

translate([21, 41, 0]) cube([1, 1, 6.1]);

translate([22, 41, 0]) cube([1, 1, 6.0]);

translate([23, 41, 0]) cube([1, 1, 6.0]);

translate([24, 41, 0]) cube([1, 1, 6.0]);

translate([25, 41, 0]) cube([1, 1, 6.1]);

translate([26, 41, 0]) cube([1, 1, 6.2]);

translate([27, 41, 0]) cube([1, 1, 6.4]);

translate([28, 41, 0]) cube([1, 1, 6.4]);

translate([29, 41, 0]) cube([1, 1, 6.4]);

translate([30, 41, 0]) cube([1, 1, 6.3]);

translate([31, 41, 0]) cube([1, 1, 6.2]);

translate([32, 41, 0]) cube([1, 1, 6.0]);

translate([33, 41, 0]) cube([1, 1, 5.8]);

translate([34, 41, 0]) cube([1, 1, 5.7]);

translate([35, 41, 0]) cube([1, 1, 5.6]);

translate([36, 41, 0]) cube([1, 1, 5.6]);

translate([37, 41, 0]) cube([1, 1, 5.5]);

translate([38, 41, 0]) cube([1, 1, 5.5]);

translate([39, 41, 0]) cube([1, 1, 5.5]);

translate([40, 41, 0]) cube([1, 1, 5.5]);

translate([41, 41, 0]) cube([1, 1, 5.5]);

translate([42, 41, 0]) cube([1, 1, 5.6]);

translate([43, 41, 0]) cube([1, 1, 5.6]);

translate([44, 41, 0]) cube([1, 1, 5.7]);

translate([45, 41, 0]) cube([1, 1, 5.6]);

translate([46, 41, 0]) cube([1, 1, 5.5]);

translate([47, 41, 0]) cube([1, 1, 5.2]);

translate([0, 42, 0]) cube([1, 1, 6.1]);

translate([1, 42, 0]) cube([1, 1, 6.0]);

translate([2, 42, 0]) cube([1, 1, 6.0]);

translate([3, 42, 0]) cube([1, 1, 6.0]);

translate([4, 42, 0]) cube([1, 1, 6.0]);

translate([5, 42, 0]) cube([1, 1, 5.9]);

translate([6, 42, 0]) cube([1, 1, 5.8]);

translate([7, 42, 0]) cube([1, 1, 5.8]);

translate([8, 42, 0]) cube([1, 1, 5.7]);

translate([9, 42, 0]) cube([1, 1, 5.7]);

translate([10, 42, 0]) cube([1, 1, 5.9]);

translate([11, 42, 0]) cube([1, 1, 6.1]);

translate([12, 42, 0]) cube([1, 1, 6.3]);

translate([13, 42, 0]) cube([1, 1, 6.4]);

translate([14, 42, 0]) cube([1, 1, 6.5]);

translate([15, 42, 0]) cube([1, 1, 6.5]);

translate([16, 42, 0]) cube([1, 1, 6.5]);

translate([17, 42, 0]) cube([1, 1, 6.4]);

translate([18, 42, 0]) cube([1, 1, 6.3]);

translate([19, 42, 0]) cube([1, 1, 6.2]);

translate([20, 42, 0]) cube([1, 1, 6.1]);

translate([21, 42, 0]) cube([1, 1, 6.0]);

translate([22, 42, 0]) cube([1, 1, 5.9]);

translate([23, 42, 0]) cube([1, 1, 6.0]);

translate([24, 42, 0]) cube([1, 1, 6.0]);

translate([25, 42, 0]) cube([1, 1, 6.2]);

translate([26, 42, 0]) cube([1, 1, 6.3]);

translate([27, 42, 0]) cube([1, 1, 6.4]);

translate([28, 42, 0]) cube([1, 1, 6.4]);

translate([29, 42, 0]) cube([1, 1, 6.3]);

translate([30, 42, 0]) cube([1, 1, 6.2]);

translate([31, 42, 0]) cube([1, 1, 6.0]);

translate([32, 42, 0]) cube([1, 1, 5.8]);

translate([33, 42, 0]) cube([1, 1, 5.7]);

translate([34, 42, 0]) cube([1, 1, 5.6]);

translate([35, 42, 0]) cube([1, 1, 5.6]);

translate([36, 42, 0]) cube([1, 1, 5.6]);

translate([37, 42, 0]) cube([1, 1, 5.5]);

translate([38, 42, 0]) cube([1, 1, 5.5]);

translate([39, 42, 0]) cube([1, 1, 5.5]);

translate([40, 42, 0]) cube([1, 1, 5.4]);

translate([41, 42, 0]) cube([1, 1, 5.4]);

translate([42, 42, 0]) cube([1, 1, 5.5]);

translate([43, 42, 0]) cube([1, 1, 5.6]);

translate([44, 42, 0]) cube([1, 1, 5.7]);

translate([45, 42, 0]) cube([1, 1, 5.8]);

translate([46, 42, 0]) cube([1, 1, 5.7]);

translate([47, 42, 0]) cube([1, 1, 5.4]);

translate([0, 43, 0]) cube([1, 1, 5.9]);

translate([1, 43, 0]) cube([1, 1, 5.9]);

translate([2, 43, 0]) cube([1, 1, 5.8]);

translate([3, 43, 0]) cube([1, 1, 5.9]);

translate([4, 43, 0]) cube([1, 1, 5.8]);

translate([5, 43, 0]) cube([1, 1, 5.8]);

translate([6, 43, 0]) cube([1, 1, 5.7]);

translate([7, 43, 0]) cube([1, 1, 5.6]);

translate([8, 43, 0]) cube([1, 1, 5.6]);

translate([9, 43, 0]) cube([1, 1, 5.6]);

translate([10, 43, 0]) cube([1, 1, 5.7]);

translate([11, 43, 0]) cube([1, 1, 5.9]);

translate([12, 43, 0]) cube([1, 1, 6.1]);

translate([13, 43, 0]) cube([1, 1, 6.2]);

translate([14, 43, 0]) cube([1, 1, 6.3]);

translate([15, 43, 0]) cube([1, 1, 6.3]);

translate([16, 43, 0]) cube([1, 1, 6.2]);

translate([17, 43, 0]) cube([1, 1, 6.1]);

translate([18, 43, 0]) cube([1, 1, 6.0]);

translate([19, 43, 0]) cube([1, 1, 6.0]);

translate([20, 43, 0]) cube([1, 1, 5.9]);

translate([21, 43, 0]) cube([1, 1, 5.8]);

translate([22, 43, 0]) cube([1, 1, 5.8]);

translate([23, 43, 0]) cube([1, 1, 5.9]);

translate([24, 43, 0]) cube([1, 1, 6.0]);

translate([25, 43, 0]) cube([1, 1, 6.2]);

translate([26, 43, 0]) cube([1, 1, 6.3]);

translate([27, 43, 0]) cube([1, 1, 6.4]);

translate([28, 43, 0]) cube([1, 1, 6.3]);

translate([29, 43, 0]) cube([1, 1, 6.2]);

translate([30, 43, 0]) cube([1, 1, 6.0]);

translate([31, 43, 0]) cube([1, 1, 5.9]);

translate([32, 43, 0]) cube([1, 1, 5.7]);

translate([33, 43, 0]) cube([1, 1, 5.5]);

translate([34, 43, 0]) cube([1, 1, 5.5]);

translate([35, 43, 0]) cube([1, 1, 5.6]);

translate([36, 43, 0]) cube([1, 1, 5.5]);

translate([37, 43, 0]) cube([1, 1, 5.5]);

translate([38, 43, 0]) cube([1, 1, 5.5]);

translate([39, 43, 0]) cube([1, 1, 5.4]);

translate([40, 43, 0]) cube([1, 1, 5.3]);

translate([41, 43, 0]) cube([1, 1, 5.3]);

translate([42, 43, 0]) cube([1, 1, 5.4]);

translate([43, 43, 0]) cube([1, 1, 5.6]);

translate([44, 43, 0]) cube([1, 1, 5.7]);

translate([45, 43, 0]) cube([1, 1, 5.9]);

translate([46, 43, 0]) cube([1, 1, 5.8]);

translate([47, 43, 0]) cube([1, 1, 5.6]);

translate([0, 44, 0]) cube([1, 1, 5.7]);

translate([1, 44, 0]) cube([1, 1, 5.6]);

translate([2, 44, 0]) cube([1, 1, 5.6]);

translate([3, 44, 0]) cube([1, 1, 5.6]);

translate([4, 44, 0]) cube([1, 1, 5.6]);

translate([5, 44, 0]) cube([1, 1, 5.6]);

translate([6, 44, 0]) cube([1, 1, 5.5]);

translate([7, 44, 0]) cube([1, 1, 5.4]);

translate([8, 44, 0]) cube([1, 1, 5.3]);

translate([9, 44, 0]) cube([1, 1, 5.4]);

translate([10, 44, 0]) cube([1, 1, 5.5]);

translate([11, 44, 0]) cube([1, 1, 5.6]);

translate([12, 44, 0]) cube([1, 1, 5.8]);

translate([13, 44, 0]) cube([1, 1, 5.9]);

translate([14, 44, 0]) cube([1, 1, 5.9]);

translate([15, 44, 0]) cube([1, 1, 5.9]);

translate([16, 44, 0]) cube([1, 1, 5.8]);

translate([17, 44, 0]) cube([1, 1, 5.7]);

translate([18, 44, 0]) cube([1, 1, 5.6]);

translate([19, 44, 0]) cube([1, 1, 5.6]);

translate([20, 44, 0]) cube([1, 1, 5.6]);

translate([21, 44, 0]) cube([1, 1, 5.7]);

translate([22, 44, 0]) cube([1, 1, 5.7]);

translate([23, 44, 0]) cube([1, 1, 5.9]);

translate([24, 44, 0]) cube([1, 1, 6.0]);

translate([25, 44, 0]) cube([1, 1, 6.1]);

translate([26, 44, 0]) cube([1, 1, 6.2]);

translate([27, 44, 0]) cube([1, 1, 6.3]);

translate([28, 44, 0]) cube([1, 1, 6.2]);

translate([29, 44, 0]) cube([1, 1, 6.0]);

translate([30, 44, 0]) cube([1, 1, 5.9]);

translate([31, 44, 0]) cube([1, 1, 5.7]);

translate([32, 44, 0]) cube([1, 1, 5.5]);

translate([33, 44, 0]) cube([1, 1, 5.4]);

translate([34, 44, 0]) cube([1, 1, 5.4]);

translate([35, 44, 0]) cube([1, 1, 5.5]);

translate([36, 44, 0]) cube([1, 1, 5.5]);

translate([37, 44, 0]) cube([1, 1, 5.5]);

translate([38, 44, 0]) cube([1, 1, 5.4]);

translate([39, 44, 0]) cube([1, 1, 5.4]);

translate([40, 44, 0]) cube([1, 1, 5.3]);

translate([41, 44, 0]) cube([1, 1, 5.3]);

translate([42, 44, 0]) cube([1, 1, 5.4]);

translate([43, 44, 0]) cube([1, 1, 5.6]);

translate([44, 44, 0]) cube([1, 1, 5.7]);

translate([45, 44, 0]) cube([1, 1, 5.9]);

translate([46, 44, 0]) cube([1, 1, 5.9]);

translate([47, 44, 0]) cube([1, 1, 5.8]);

translate([0, 45, 0]) cube([1, 1, 5.5]);

translate([1, 45, 0]) cube([1, 1, 5.4]);

translate([2, 45, 0]) cube([1, 1, 5.4]);

translate([3, 45, 0]) cube([1, 1, 5.4]);

translate([4, 45, 0]) cube([1, 1, 5.5]);

translate([5, 45, 0]) cube([1, 1, 5.4]);

translate([6, 45, 0]) cube([1, 1, 5.3]);

translate([7, 45, 0]) cube([1, 1, 5.2]);

translate([8, 45, 0]) cube([1, 1, 5.1]);

translate([9, 45, 0]) cube([1, 1, 5.1]);

translate([10, 45, 0]) cube([1, 1, 5.2]);

translate([11, 45, 0]) cube([1, 1, 5.3]);

translate([12, 45, 0]) cube([1, 1, 5.4]);

translate([13, 45, 0]) cube([1, 1, 5.5]);

translate([14, 45, 0]) cube([1, 1, 5.5]);

translate([15, 45, 0]) cube([1, 1, 5.5]);

translate([16, 45, 0]) cube([1, 1, 5.4]);

translate([17, 45, 0]) cube([1, 1, 5.3]);

translate([18, 45, 0]) cube([1, 1, 5.2]);

translate([19, 45, 0]) cube([1, 1, 5.2]);

translate([20, 45, 0]) cube([1, 1, 5.3]);

translate([21, 45, 0]) cube([1, 1, 5.4]);

translate([22, 45, 0]) cube([1, 1, 5.6]);

translate([23, 45, 0]) cube([1, 1, 5.7]);

translate([24, 45, 0]) cube([1, 1, 5.8]);

translate([25, 45, 0]) cube([1, 1, 5.9]);

translate([26, 45, 0]) cube([1, 1, 6.0]);

translate([27, 45, 0]) cube([1, 1, 6.1]);

translate([28, 45, 0]) cube([1, 1, 6.0]);

translate([29, 45, 0]) cube([1, 1, 6.0]);

translate([30, 45, 0]) cube([1, 1, 5.8]);

translate([31, 45, 0]) cube([1, 1, 5.6]);

translate([32, 45, 0]) cube([1, 1, 5.4]);

translate([33, 45, 0]) cube([1, 1, 5.3]);

translate([34, 45, 0]) cube([1, 1, 5.3]);

translate([35, 45, 0]) cube([1, 1, 5.4]);

translate([36, 45, 0]) cube([1, 1, 5.4]);

translate([37, 45, 0]) cube([1, 1, 5.4]);

translate([38, 45, 0]) cube([1, 1, 5.4]);

translate([39, 45, 0]) cube([1, 1, 5.3]);

translate([40, 45, 0]) cube([1, 1, 5.3]);

translate([41, 45, 0]) cube([1, 1, 5.3]);

translate([42, 45, 0]) cube([1, 1, 5.5]);

translate([43, 45, 0]) cube([1, 1, 5.6]);

translate([44, 45, 0]) cube([1, 1, 5.8]);

translate([45, 45, 0]) cube([1, 1, 5.9]);

translate([46, 45, 0]) cube([1, 1, 5.9]);

translate([47, 45, 0]) cube([1, 1, 5.8]);

translate([0, 46, 0]) cube([1, 1, 5.3]);

translate([1, 46, 0]) cube([1, 1, 5.3]);

translate([2, 46, 0]) cube([1, 1, 5.3]);

translate([3, 46, 0]) cube([1, 1, 5.3]);

translate([4, 46, 0]) cube([1, 1, 5.3]);

translate([5, 46, 0]) cube([1, 1, 5.3]);

translate([6, 46, 0]) cube([1, 1, 5.2]);

translate([7, 46, 0]) cube([1, 1, 5.1]);

translate([8, 46, 0]) cube([1, 1, 5.0]);

translate([9, 46, 0]) cube([1, 1, 4.9]);

translate([10, 46, 0]) cube([1, 1, 5.0]);

translate([11, 46, 0]) cube([1, 1, 5.1]);

translate([12, 46, 0]) cube([1, 1, 5.2]);

translate([13, 46, 0]) cube([1, 1, 5.2]);

translate([14, 46, 0]) cube([1, 1, 5.2]);

translate([15, 46, 0]) cube([1, 1, 5.1]);

translate([16, 46, 0]) cube([1, 1, 5.0]);

translate([17, 46, 0]) cube([1, 1, 4.9]);

translate([18, 46, 0]) cube([1, 1, 4.8]);

translate([19, 46, 0]) cube([1, 1, 4.9]);

translate([20, 46, 0]) cube([1, 1, 5.0]);

translate([21, 46, 0]) cube([1, 1, 5.2]);

translate([22, 46, 0]) cube([1, 1, 5.4]);

translate([23, 46, 0]) cube([1, 1, 5.5]);

translate([24, 46, 0]) cube([1, 1, 5.5]);

translate([25, 46, 0]) cube([1, 1, 5.6]);

translate([26, 46, 0]) cube([1, 1, 5.7]);

translate([27, 46, 0]) cube([1, 1, 5.8]);

translate([28, 46, 0]) cube([1, 1, 5.9]);

translate([29, 46, 0]) cube([1, 1, 5.9]);

translate([30, 46, 0]) cube([1, 1, 5.8]);

translate([31, 46, 0]) cube([1, 1, 5.6]);

translate([32, 46, 0]) cube([1, 1, 5.4]);

translate([33, 46, 0]) cube([1, 1, 5.2]);

translate([34, 46, 0]) cube([1, 1, 5.2]);

translate([35, 46, 0]) cube([1, 1, 5.2]);

translate([36, 46, 0]) cube([1, 1, 5.2]);

translate([37, 46, 0]) cube([1, 1, 5.3]);

translate([38, 46, 0]) cube([1, 1, 5.3]);

translate([39, 46, 0]) cube([1, 1, 5.3]);

translate([40, 46, 0]) cube([1, 1, 5.3]);

translate([41, 46, 0]) cube([1, 1, 5.4]);

translate([42, 46, 0]) cube([1, 1, 5.5]);

translate([43, 46, 0]) cube([1, 1, 5.6]);

translate([44, 46, 0]) cube([1, 1, 5.7]);

translate([45, 46, 0]) cube([1, 1, 5.7]);

translate([46, 46, 0]) cube([1, 1, 5.7]);

translate([47, 46, 0]) cube([1, 1, 5.6]);

translate([0, 47, 0]) cube([1, 1, 5.2]);

translate([1, 47, 0]) cube([1, 1, 5.1]);

translate([2, 47, 0]) cube([1, 1, 5.1]);

translate([3, 47, 0]) cube([1, 1, 5.2]);

translate([4, 47, 0]) cube([1, 1, 5.2]);

translate([5, 47, 0]) cube([1, 1, 5.2]);

translate([6, 47, 0]) cube([1, 1, 5.1]);

translate([7, 47, 0]) cube([1, 1, 5.0]);

translate([8, 47, 0]) cube([1, 1, 4.9]);

translate([9, 47, 0]) cube([1, 1, 4.8]);

translate([10, 47, 0]) cube([1, 1, 4.8]);

translate([11, 47, 0]) cube([1, 1, 4.9]);

translate([12, 47, 0]) cube([1, 1, 5.0]);

translate([13, 47, 0]) cube([1, 1, 5.0]);

translate([14, 47, 0]) cube([1, 1, 5.0]);

translate([15, 47, 0]) cube([1, 1, 4.9]);

translate([16, 47, 0]) cube([1, 1, 4.7]);

translate([17, 47, 0]) cube([1, 1, 4.6]);

translate([18, 47, 0]) cube([1, 1, 4.5]);

translate([19, 47, 0]) cube([1, 1, 4.6]);

translate([20, 47, 0]) cube([1, 1, 4.8]);

translate([21, 47, 0]) cube([1, 1, 5.0]);

translate([22, 47, 0]) cube([1, 1, 5.2]);

translate([23, 47, 0]) cube([1, 1, 5.2]);

translate([24, 47, 0]) cube([1, 1, 5.2]);

translate([25, 47, 0]) cube([1, 1, 5.3]);

translate([26, 47, 0]) cube([1, 1, 5.4]);

translate([27, 47, 0]) cube([1, 1, 5.6]);

translate([28, 47, 0]) cube([1, 1, 5.7]);

translate([29, 47, 0]) cube([1, 1, 5.8]);

translate([30, 47, 0]) cube([1, 1, 5.7]);

translate([31, 47, 0]) cube([1, 1, 5.5]);

translate([32, 47, 0]) cube([1, 1, 5.3]);

translate([33, 47, 0]) cube([1, 1, 5.1]);

translate([34, 47, 0]) cube([1, 1, 5.1]);

translate([35, 47, 0]) cube([1, 1, 5.1]);

translate([36, 47, 0]) cube([1, 1, 5.1]);

translate([37, 47, 0]) cube([1, 1, 5.2]);

translate([38, 47, 0]) cube([1, 1, 5.2]);

translate([39, 47, 0]) cube([1, 1, 5.3]);

translate([40, 47, 0]) cube([1, 1, 5.3]);

translate([41, 47, 0]) cube([1, 1, 5.4]);

translate([42, 47, 0]) cube([1, 1, 5.5]);

translate([43, 47, 0]) cube([1, 1, 5.6]);

translate([44, 47, 0]) cube([1, 1, 5.6]);

translate([45, 47, 0]) cube([1, 1, 5.5]);

translate([46, 47, 0]) cube([1, 1, 5.4]);

translate([47, 47, 0]) cube([1, 1, 5.3]);

color([1,0,0])
translate([24.15, 24.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([24.15, 23.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([23.15, 24.15, 0]) cube([0.15, 0.15, 10]);

color([1,0,0])
translate([23.15, 23.15, 0]) cube([0.15, 0.15, 10]);
