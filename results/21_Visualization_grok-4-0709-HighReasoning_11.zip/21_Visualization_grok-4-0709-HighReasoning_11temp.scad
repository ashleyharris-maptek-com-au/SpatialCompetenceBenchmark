
hull() {
    translate([0.05, 0.05, 4.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9500000000000001, 0.9500000000000001, 4.5249999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.05, 1.05, 4.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.9500000000000002, 1.9500000000000002, 4.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.05, 2.05, 3.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.95, 2.95, 3.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0500000000000003, 3.0500000000000003, 3.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.95, 3.95, 3.0250000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.05, 4.05, 2.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.95, 4.95, 2.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.05, 5.05, 2.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.95, 5.95, 2.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.050000000000001, 6.050000000000001, 1.975]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.95, 6.95, 1.5250000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.05, 7.05, 1.475]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.95, 7.95, 1.025]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.05, 8.05, 0.9750000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.95, 8.95, 0.525]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.049999999999999, 9.049999999999999, 0.47500000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.95, 9.95, 0.025]) cube([0.4, 0.4, 0.1], center=true);
}

