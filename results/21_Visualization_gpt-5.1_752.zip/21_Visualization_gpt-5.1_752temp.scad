
hull() {
    translate([0.045000000000000005, 0.0, 249.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.8550000000000001, 0.0, 249.85750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.9450000000000001, 0.0, 249.842]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.7550000000000001, 0.0, 249.698]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.8450000000000002, 0.0, 249.6825]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.6550000000000002, 0.0, 249.54749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.745, 0.0, 249.53199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.555, 0.0, 249.388]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.6450000000000005, 0.0, 249.3725]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.455, 0.0, 249.23749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.545, 0.0, 249.22199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.355, 0.0, 249.078]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.445, 0.0, 249.0625]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.255, 0.0, 248.9275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.345, 0.0, 248.91199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.155, 0.0, 248.76799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.245000000000001, 0.0, 248.7525]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.055, 0.0, 248.61750000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.145, 0.0, 248.60200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.955, 0.0, 248.458]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.045, 0.0, 248.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.855, 0.0, 248.30750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.945, 0.0, 248.29200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.755, 0.0, 248.148]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.845, 0.0, 248.1325]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.655, 0.0, 247.9975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.745, 0.0, 247.982]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.555, 0.0, 247.83800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.645, 0.0, 247.82250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.455, 0.0, 247.6875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.545, 0.0, 247.67200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.355, 0.0, 247.52800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.445, 0.0, 247.5125]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.255000000000003, 0.0, 247.3775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.345000000000002, 0.0, 247.36200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.155, 0.0, 247.21800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.245, 0.0, 247.20250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.055000000000003, 0.0, 247.06750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.145000000000003, 0.0, 247.05200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.955, 0.0, 246.90800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.044999999999998, 0.0, 246.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.854999999999997, 0.0, 246.75750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.944999999999997, 0.0, 246.74200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([19.755, 0.0, 246.598]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([19.845, 0.0, 246.5825]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.654999999999998, 0.0, 246.4475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.744999999999997, 0.0, 246.432]) cube([0.4, 0.4, 0.1], center=true);
    translate([21.555, 0.0, 246.288]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([21.645000000000003, 0.0, 246.2725]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.455, 0.0, 246.1375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.545, 0.0, 246.122]) cube([0.4, 0.4, 0.1], center=true);
    translate([23.354999999999997, 0.0, 245.978]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([23.445, 0.0, 245.96249999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.255000000000003, 0.0, 245.8275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.345000000000002, 0.0, 245.812]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.155, 0.0, 245.668]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.245, 0.0, 245.6525]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.055000000000003, 0.0, 245.5175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([26.145000000000003, 0.0, 245.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([26.955000000000002, 0.0, 245.358]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.045, 0.0, 245.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.855, 0.0, 245.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.945, 0.0, 245.192]) cube([0.4, 0.4, 0.1], center=true);
    translate([28.755000000000003, 0.0, 245.048]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([28.845000000000002, 0.0, 245.0325]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.655, 0.0, 244.89749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.745, 0.0, 244.88199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([30.555000000000003, 0.0, 244.738]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([30.645000000000003, 0.0, 244.7225]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.455000000000002, 0.0, 244.5875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.545, 0.0, 244.572]) cube([0.4, 0.4, 0.1], center=true);
    translate([32.355000000000004, 0.0, 244.428]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([32.445, 0.0, 244.41249999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.254999999999995, 0.0, 244.27750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.345, 0.0, 244.26200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([34.155, 0.0, 244.11800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([34.245000000000005, 0.0, 244.10250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.05500000000001, 0.0, 243.96750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.145, 0.0, 243.95200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.955, 0.0, 243.80800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.045, 0.0, 243.79250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.855000000000004, 0.0, 243.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.945, 0.0, 243.642]) cube([0.4, 0.4, 0.1], center=true);
    translate([37.754999999999995, 0.0, 243.49800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([37.845, 0.0, 243.48250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.65500000000001, 0.0, 243.3475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.745000000000005, 0.0, 243.332]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.555, 0.0, 243.18800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.645, 0.0, 243.1725]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.455000000000005, 0.0, 243.03750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.545, 0.0, 243.022]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.355, 0.0, 242.878]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.445, 0.0, 242.8625]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.255, 0.0, 242.72750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.345, 0.0, 242.71200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([43.155, 0.0, 242.568]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([43.245000000000005, 0.0, 242.5525]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.05500000000001, 0.0, 242.41750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([44.145, 0.0, 242.40200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([44.955, 0.0, 242.258]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.045, 0.0, 242.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.855000000000004, 0.0, 242.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.945, 0.0, 242.09199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.754999999999995, 0.0, 241.948]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.845, 0.0, 241.9325]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.65500000000001, 0.0, 241.79749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.745000000000005, 0.0, 241.78199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.55500000000001, 0.0, 241.638]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.645, 0.0, 241.6225]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.455000000000005, 0.0, 241.4875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.545, 0.0, 241.47199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.355000000000004, 0.0, 241.32799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.445, 0.0, 241.3125]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.255, 0.0, 241.1775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.345, 0.0, 241.162]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.155, 0.0, 241.018]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.245000000000005, 0.0, 241.0025]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.055, 0.0, 240.86750000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.144999999999996, 0.0, 240.85200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.955, 0.0, 240.708]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.045, 0.0, 240.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.855, 0.0, 240.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.94499999999999, 0.0, 240.542]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.754999999999995, 0.0, 240.398]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.845, 0.0, 240.3825]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.655, 0.0, 240.2475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.745000000000005, 0.0, 240.23200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.55500000000001, 0.0, 240.08800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.645, 0.0, 240.0725]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.455, 0.0, 239.9375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.545, 0.0, 239.92200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.355000000000004, 0.0, 239.77800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.445, 0.0, 239.76250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.254999999999995, 0.0, 239.62750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.345, 0.0, 239.61200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.15500000000001, 0.0, 239.46800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.245000000000005, 0.0, 239.45250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.055, 0.0, 239.31750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.145, 0.0, 239.30200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.955000000000005, 0.0, 239.15800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.045, 0.0, 239.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.855, 0.0, 239.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.945, 0.0, 238.992]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.755, 0.0, 238.848]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.845, 0.0, 238.8325]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.655, 0.0, 238.6975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.745, 0.0, 238.68200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.55499999999999, 0.0, 238.538]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.645, 0.0, 238.52249999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.455, 0.0, 238.3875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.545, 0.0, 238.372]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.355, 0.0, 238.228]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.44500000000001, 0.0, 238.2125]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.255, 0.0, 238.07750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.345, 0.0, 238.062]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.155, 0.0, 237.918]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.245, 0.0, 237.9025]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.05499999999999, 0.0, 237.7675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.145, 0.0, 237.752]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.955, 0.0, 237.608]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.045, 0.0, 237.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.85500000000002, 0.0, 237.45749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.94500000000001, 0.0, 237.44199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.755, 0.0, 237.298]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.845, 0.0, 237.2825]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.655, 0.0, 237.14749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.745, 0.0, 237.132]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.55499999999999, 0.0, 236.988]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.645, 0.0, 236.97249999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.45500000000001, 0.0, 236.83750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.54500000000002, 0.0, 236.82200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.35500000000002, 0.0, 236.678]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.44500000000001, 0.0, 236.6625]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.255, 0.0, 236.52750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.345, 0.0, 236.51200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.155, 0.0, 236.36800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.245, 0.0, 236.35250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.055, 0.0, 236.2175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.14500000000001, 0.0, 236.202]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.95500000000001, 0.0, 236.05800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.045, 0.0, 236.04250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.855, 0.0, 235.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.94500000000001, 0.0, 235.892]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.755, 0.0, 235.74800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.845, 0.0, 235.73250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.655, 0.0, 235.59750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.745, 0.0, 235.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.555, 0.0, 235.438]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.645, 0.0, 235.4225]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.455, 0.0, 235.28750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.545, 0.0, 235.27200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.355, 0.0, 235.12800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.44500000000001, 0.0, 235.1125]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.255, 0.0, 234.97750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.345, 0.0, 234.96200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.15500000000002, 0.0, 234.818]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.245, 0.0, 234.8025]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.05499999999999, 0.0, 234.6675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.145, 0.0, 234.652]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.955, 0.0, 234.508]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 0.045000000000000005, 234.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 0.8550000000000001, 234.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 0.9450000000000001, 234.34199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 1.7550000000000001, 234.198]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 1.8450000000000002, 234.1825]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 2.6550000000000002, 234.0475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 2.745, 234.03199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 3.555, 233.88799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 3.6450000000000005, 233.8725]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 4.455, 233.7375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 4.545, 233.722]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 5.355, 233.578]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 5.445, 233.5625]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 6.255, 233.4275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 6.345, 233.412]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 7.155, 233.268]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 7.245000000000001, 233.2525]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 8.055, 233.1175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 8.145, 233.102]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 8.955, 232.958]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 9.045, 232.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 9.855, 232.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 9.945, 232.792]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 10.755, 232.648]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 10.845, 232.6325]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 11.655, 232.4975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 11.745, 232.48200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 12.555, 232.33800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 12.645, 232.32250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 13.455, 232.18750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 13.545, 232.17200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 14.355, 232.02800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 14.445, 232.01250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 15.255000000000003, 231.87750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 15.345000000000002, 231.86200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 16.155, 231.71800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 16.245, 231.70250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 17.055000000000003, 231.5675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 17.145000000000003, 231.552]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 17.955, 231.40800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 18.044999999999998, 231.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 18.854999999999997, 231.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 18.944999999999997, 231.24200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 19.755, 231.098]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 19.845, 231.08249999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 20.654999999999998, 230.9475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 20.744999999999997, 230.93200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 21.555, 230.788]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 21.645000000000003, 230.7725]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 22.455, 230.63750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 22.545, 230.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 23.354999999999997, 230.478]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 23.445, 230.4625]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 24.255000000000003, 230.32750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 24.345000000000002, 230.312]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 25.155, 230.168]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 25.245, 230.1525]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 26.055000000000003, 230.01749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 26.145000000000003, 230.00199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 26.955000000000002, 229.858]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 27.045, 229.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 27.855, 229.70749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 27.945, 229.692]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 28.755000000000003, 229.548]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 28.845000000000002, 229.53249999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 29.655, 229.39749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 29.745, 229.382]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 30.555000000000003, 229.238]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 30.645000000000003, 229.2225]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 31.455000000000002, 229.08750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 31.545, 229.07200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 32.355000000000004, 228.928]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 32.445, 228.9125]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 33.254999999999995, 228.7775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 33.345, 228.762]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 34.155, 228.61800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 34.245000000000005, 228.60250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 35.05500000000001, 228.4675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 35.145, 228.452]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 35.955, 228.30800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 36.045, 228.29250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 36.855000000000004, 228.15750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 36.945, 228.142]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 37.754999999999995, 227.998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 37.845, 227.98250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 38.65500000000001, 227.84750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 38.745000000000005, 227.83200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 39.555, 227.68800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 39.645, 227.6725]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 40.455000000000005, 227.53750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 40.545, 227.52200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 41.355, 227.37800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 41.445, 227.3625]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 42.255, 227.2275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 42.345, 227.212]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 43.155, 227.068]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 43.245000000000005, 227.0525]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 44.05500000000001, 226.9175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 44.145, 226.902]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 44.955, 226.758]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 45.045, 226.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 45.855000000000004, 226.60750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 45.945, 226.59199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 46.754999999999995, 226.44799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 46.845, 226.4325]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 47.65500000000001, 226.2975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 47.745000000000005, 226.282]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 48.55500000000001, 226.138]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 48.645, 226.1225]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 49.455000000000005, 225.9875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 49.545, 225.972]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 50.355000000000004, 225.828]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 50.445, 225.8125]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 51.255, 225.67749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 51.345, 225.66199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 52.155, 225.518]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 52.245000000000005, 225.5025]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 53.055, 225.3675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 53.144999999999996, 225.352]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 53.955, 225.208]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 54.045, 225.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 54.855, 225.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 54.94499999999999, 225.04200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 55.754999999999995, 224.89799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 55.845, 224.8825]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 56.655, 224.74750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 56.745000000000005, 224.73200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 57.55500000000001, 224.58800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 57.645, 224.57250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 58.455, 224.43750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 58.545, 224.42200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 59.355000000000004, 224.27800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 59.445, 224.26250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 60.254999999999995, 224.1275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 60.345, 224.112]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 61.15500000000001, 223.96800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 61.245000000000005, 223.95250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 62.055, 223.8175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 62.145, 223.80200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 62.955000000000005, 223.65800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 63.045, 223.64249999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 63.855, 223.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 63.945, 223.49200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 64.755, 223.348]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 64.845, 223.3325]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 65.655, 223.19750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 65.745, 223.18200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 66.55499999999999, 223.038]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 66.645, 223.0225]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 67.455, 222.88750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 67.545, 222.872]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 68.355, 222.728]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 68.44500000000001, 222.7125]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 69.255, 222.5775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 69.345, 222.56199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 70.155, 222.418]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 70.245, 222.4025]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 71.05499999999999, 222.26749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 71.145, 222.252]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 71.955, 222.108]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 72.045, 222.09249999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 72.85500000000002, 221.95749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 72.94500000000001, 221.942]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 73.755, 221.798]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 73.845, 221.7825]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 74.655, 221.6475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 74.745, 221.632]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 75.55499999999999, 221.488]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 75.645, 221.4725]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 76.45500000000001, 221.3375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 76.54500000000002, 221.322]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 77.35500000000002, 221.178]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 77.44500000000001, 221.1625]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 78.255, 221.0275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 78.345, 221.012]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 79.155, 220.86800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 79.245, 220.85250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 80.055, 220.71750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 80.14500000000001, 220.702]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 80.95500000000001, 220.558]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 81.045, 220.54250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 81.855, 220.40750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 81.94500000000001, 220.39200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 82.755, 220.24800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 82.845, 220.23250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 83.655, 220.09750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 83.745, 220.08200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 84.555, 219.93800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 84.645, 219.9225]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 85.455, 219.7875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 85.545, 219.772]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 86.355, 219.62800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 86.44500000000001, 219.6125]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 87.255, 219.4775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 87.345, 219.462]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 88.15500000000002, 219.318]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 88.245, 219.3025]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 89.05499999999999, 219.16750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 89.145, 219.152]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 89.955, 219.00799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.045, 90.0, 218.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.855, 90.0, 218.85750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.94500000000001, 90.0, 218.842]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.75500000000001, 90.0, 218.698]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.845, 90.0, 218.6825]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.655, 90.0, 218.5475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.745, 90.0, 218.532]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.55499999999999, 90.0, 218.388]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.645, 90.0, 218.3725]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.455, 90.0, 218.23749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.545, 90.0, 218.22199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.35500000000002, 90.0, 218.078]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.44500000000001, 90.0, 218.0625]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.255, 90.0, 217.92749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.345, 90.0, 217.91199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.155, 90.0, 217.768]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.245, 90.0, 217.7525]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.05499999999999, 90.0, 217.6175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.145, 90.0, 217.60200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.95500000000001, 90.0, 217.45799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.04500000000002, 90.0, 217.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.85500000000002, 90.0, 217.30750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.94500000000001, 90.0, 217.29200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.755, 90.0, 217.148]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.845, 90.0, 217.1325]) cube([0.4, 0.4, 0.1], center=true);
    translate([101.655, 90.0, 216.99750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.745, 90.0, 216.98200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.555, 90.0, 216.83800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.64500000000001, 90.0, 216.82250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.45500000000001, 90.0, 216.6875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.545, 90.0, 216.672]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.355, 90.0, 216.52800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.44500000000001, 90.0, 216.51250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.255, 90.0, 216.3775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.345, 90.0, 216.36200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.155, 90.0, 216.21800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.245, 90.0, 216.2025]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.055, 90.0, 216.0675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.145, 90.0, 216.05200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.955, 90.0, 215.90800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.045, 90.0, 215.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.855, 90.0, 215.75750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.94500000000001, 90.0, 215.74200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.755, 90.0, 215.598]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([109.845, 90.0, 215.5825]) cube([0.4, 0.4, 0.1], center=true);
    translate([110.65500000000002, 90.0, 215.44750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.745, 90.0, 215.43200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([111.555, 90.0, 215.288]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.645, 90.0, 215.2725]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.455, 90.0, 215.1375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([112.545, 90.0, 215.12199999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([113.355, 90.0, 214.978]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.44500000000001, 90.0, 214.9625]) cube([0.4, 0.4, 0.1], center=true);
    translate([114.25500000000001, 90.0, 214.8275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.345, 90.0, 214.812]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.155, 90.0, 214.668]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([115.245, 90.0, 214.65249999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.05499999999999, 90.0, 214.51749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.145, 90.0, 214.502]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.955, 90.0, 214.358]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.045, 90.0, 214.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.85500000000002, 90.0, 214.2075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.94500000000002, 90.0, 214.192]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.755, 90.0, 214.048]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118.845, 90.0, 214.0325]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.655, 90.0, 213.8975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.745, 90.0, 213.882]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.55499999999999, 90.0, 213.738]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.645, 90.0, 213.7225]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.45500000000001, 90.0, 213.5875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.54500000000002, 90.0, 213.572]) cube([0.4, 0.4, 0.1], center=true);
    translate([122.35500000000002, 90.0, 213.428]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.44500000000001, 90.0, 213.4125]) cube([0.4, 0.4, 0.1], center=true);
    translate([123.255, 90.0, 213.2775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.345, 90.0, 213.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.155, 90.0, 213.118]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([124.245, 90.0, 213.10250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([125.055, 90.0, 212.96750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.14500000000001, 90.0, 212.95200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([125.95500000000001, 90.0, 212.80800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.045, 90.0, 212.79250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([126.855, 90.0, 212.65750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.94500000000001, 90.0, 212.64200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.755, 90.0, 212.49800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([127.845, 90.0, 212.48250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([128.655, 90.0, 212.3475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.745, 90.0, 212.332]) cube([0.4, 0.4, 0.1], center=true);
    translate([129.555, 90.0, 212.18800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([129.645, 90.0, 212.1725]) cube([0.4, 0.4, 0.1], center=true);
    translate([130.455, 90.0, 212.0375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([130.54500000000002, 90.0, 212.022]) cube([0.4, 0.4, 0.1], center=true);
    translate([131.35500000000002, 90.0, 211.87800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([131.445, 90.0, 211.8625]) cube([0.4, 0.4, 0.1], center=true);
    translate([132.255, 90.0, 211.72750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([132.345, 90.0, 211.712]) cube([0.4, 0.4, 0.1], center=true);
    translate([133.155, 90.0, 211.56799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([133.245, 90.0, 211.5525]) cube([0.4, 0.4, 0.1], center=true);
    translate([134.055, 90.0, 211.41750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([134.145, 90.0, 211.40200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([134.955, 90.0, 211.258]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 90.045, 211.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 90.855, 211.10750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 90.94500000000001, 211.092]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 91.75500000000001, 210.948]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 91.845, 210.9325]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 92.655, 210.79749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 92.745, 210.78199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 93.55499999999999, 210.638]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 93.645, 210.6225]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 94.455, 210.48749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 94.545, 210.47199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 95.35500000000002, 210.328]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 95.44500000000001, 210.3125]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 96.255, 210.1775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 96.345, 210.16199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 97.155, 210.01799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 97.245, 210.0025]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 98.05499999999999, 209.86750000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 98.145, 209.85200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 98.95500000000001, 209.708]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 99.04500000000002, 209.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 99.85500000000002, 209.55750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 99.94500000000001, 209.54200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 100.755, 209.398]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 100.845, 209.3825]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 101.655, 209.2475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 101.745, 209.232]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 102.555, 209.08800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 102.64500000000001, 209.07250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 103.45500000000001, 208.9375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 103.545, 208.92200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 104.355, 208.77800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 104.44500000000001, 208.7625]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 105.255, 208.6275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 105.345, 208.61200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 106.155, 208.46800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 106.245, 208.45250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 107.055, 208.31750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 107.145, 208.30200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 107.955, 208.15800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 108.045, 208.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 108.855, 208.00750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 108.94500000000001, 207.99200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 109.755, 207.848]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 109.845, 207.8325]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 110.65500000000002, 207.6975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 110.745, 207.682]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 111.555, 207.538]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 111.645, 207.5225]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 112.455, 207.3875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 112.545, 207.372]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 113.355, 207.228]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 113.44500000000001, 207.21249999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 114.25500000000001, 207.0775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 114.345, 207.062]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 115.155, 206.918]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 115.245, 206.9025]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 116.05499999999999, 206.7675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 116.145, 206.752]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 116.955, 206.608]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 117.045, 206.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 117.85500000000002, 206.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 117.94500000000002, 206.442]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 118.755, 206.298]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 118.845, 206.2825]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 119.655, 206.14749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 119.745, 206.13199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 120.55499999999999, 205.988]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 120.645, 205.9725]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 121.45500000000001, 205.8375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 121.54500000000002, 205.822]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 122.35500000000002, 205.678]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 122.44500000000001, 205.66249999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 123.255, 205.52750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 123.345, 205.51200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 124.155, 205.36800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 124.245, 205.35250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 125.055, 205.21750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 125.14500000000001, 205.20200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 125.95500000000001, 205.05800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 126.045, 205.04250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 126.855, 204.9075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 126.94500000000001, 204.892]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 127.755, 204.74800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 127.845, 204.73250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 128.655, 204.5975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 128.745, 204.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 129.555, 204.43800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 129.645, 204.4225]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 130.455, 204.28750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 130.54500000000002, 204.272]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 131.35500000000002, 204.128]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 131.445, 204.1125]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 132.255, 203.97750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 132.345, 203.96200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 133.155, 203.818]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 133.245, 203.8025]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 134.055, 203.66750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([135.0, 134.145, 203.65200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([135.0, 134.955, 203.508]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([134.955, 135.0, 203.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([134.145, 135.0, 203.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([134.055, 135.0, 203.34199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([133.245, 135.0, 203.198]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([133.155, 135.0, 203.1825]) cube([0.4, 0.4, 0.1], center=true);
    translate([132.345, 135.0, 203.04749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([132.255, 135.0, 203.03199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([131.445, 135.0, 202.888]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([131.35500000000002, 135.0, 202.8725]) cube([0.4, 0.4, 0.1], center=true);
    translate([130.54500000000002, 135.0, 202.7375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([130.455, 135.0, 202.72199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([129.645, 135.0, 202.57799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([129.555, 135.0, 202.5625]) cube([0.4, 0.4, 0.1], center=true);
    translate([128.745, 135.0, 202.4275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([128.655, 135.0, 202.412]) cube([0.4, 0.4, 0.1], center=true);
    translate([127.845, 135.0, 202.268]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([127.755, 135.0, 202.2525]) cube([0.4, 0.4, 0.1], center=true);
    translate([126.94500000000001, 135.0, 202.11750000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([126.855, 135.0, 202.10200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([126.045, 135.0, 201.958]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.95500000000001, 135.0, 201.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([125.14500000000001, 135.0, 201.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([125.055, 135.0, 201.792]) cube([0.4, 0.4, 0.1], center=true);
    translate([124.245, 135.0, 201.648]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([124.155, 135.0, 201.6325]) cube([0.4, 0.4, 0.1], center=true);
    translate([123.345, 135.0, 201.4975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([123.255, 135.0, 201.48200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([122.44500000000001, 135.0, 201.33800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([122.35500000000002, 135.0, 201.3225]) cube([0.4, 0.4, 0.1], center=true);
    translate([121.54500000000002, 135.0, 201.1875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([121.45500000000001, 135.0, 201.17200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([120.645, 135.0, 201.02800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([120.55499999999999, 135.0, 201.01250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([119.745, 135.0, 200.87750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([119.655, 135.0, 200.86200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([118.845, 135.0, 200.71800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([118.755, 135.0, 200.70250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.94500000000002, 135.0, 200.56750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([117.85500000000002, 135.0, 200.55200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([117.045, 135.0, 200.40800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.955, 135.0, 200.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([116.145, 135.0, 200.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([116.05499999999999, 135.0, 200.242]) cube([0.4, 0.4, 0.1], center=true);
    translate([115.245, 135.0, 200.098]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([115.155, 135.0, 200.0825]) cube([0.4, 0.4, 0.1], center=true);
    translate([114.345, 135.0, 199.9475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([114.25500000000001, 135.0, 199.93200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([113.44500000000001, 135.0, 199.788]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([113.355, 135.0, 199.77249999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([112.545, 135.0, 199.6375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([112.455, 135.0, 199.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([111.645, 135.0, 199.478]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([111.555, 135.0, 199.4625]) cube([0.4, 0.4, 0.1], center=true);
    translate([110.745, 135.0, 199.32750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([110.65500000000002, 135.0, 199.312]) cube([0.4, 0.4, 0.1], center=true);
    translate([109.845, 135.0, 199.168]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([109.755, 135.0, 199.1525]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.94500000000001, 135.0, 199.0175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([108.855, 135.0, 199.002]) cube([0.4, 0.4, 0.1], center=true);
    translate([108.045, 135.0, 198.858]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.955, 135.0, 198.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([107.145, 135.0, 198.70749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([107.055, 135.0, 198.69199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([106.245, 135.0, 198.548]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([106.155, 135.0, 198.5325]) cube([0.4, 0.4, 0.1], center=true);
    translate([105.345, 135.0, 198.39749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([105.255, 135.0, 198.382]) cube([0.4, 0.4, 0.1], center=true);
    translate([104.44500000000001, 135.0, 198.238]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([104.355, 135.0, 198.22249999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([103.545, 135.0, 198.08750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([103.45500000000001, 135.0, 198.07200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([102.64500000000001, 135.0, 197.928]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([102.555, 135.0, 197.9125]) cube([0.4, 0.4, 0.1], center=true);
    translate([101.745, 135.0, 197.77750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([101.655, 135.0, 197.76200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([100.845, 135.0, 197.61800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([100.755, 135.0, 197.60250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.94500000000001, 135.0, 197.4675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([99.85500000000002, 135.0, 197.452]) cube([0.4, 0.4, 0.1], center=true);
    translate([99.04500000000002, 135.0, 197.30800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.95500000000001, 135.0, 197.29250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([98.145, 135.0, 197.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([98.05499999999999, 135.0, 197.142]) cube([0.4, 0.4, 0.1], center=true);
    translate([97.245, 135.0, 196.99800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([97.155, 135.0, 196.98250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([96.345, 135.0, 196.84750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([96.255, 135.0, 196.832]) cube([0.4, 0.4, 0.1], center=true);
    translate([95.44500000000001, 135.0, 196.688]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([95.35500000000002, 135.0, 196.6725]) cube([0.4, 0.4, 0.1], center=true);
    translate([94.545, 135.0, 196.53750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([94.455, 135.0, 196.52200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([93.645, 135.0, 196.37800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([93.55499999999999, 135.0, 196.3625]) cube([0.4, 0.4, 0.1], center=true);
    translate([92.745, 135.0, 196.22750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([92.655, 135.0, 196.21200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([91.845, 135.0, 196.068]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([91.75500000000001, 135.0, 196.0525]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.94500000000001, 135.0, 195.9175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.855, 135.0, 195.902]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.045, 135.0, 195.758]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 135.045, 195.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 135.855, 195.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 135.945, 195.59199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 136.75500000000002, 195.448]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 136.84500000000003, 195.4325]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 137.655, 195.2975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 137.745, 195.28199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 138.555, 195.13799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 138.64499999999998, 195.1225]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 139.45499999999998, 194.9875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 139.545, 194.972]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 140.35500000000002, 194.828]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 140.44500000000002, 194.8125]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 141.25500000000002, 194.6775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 141.34500000000003, 194.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 142.155, 194.518]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 142.24499999999998, 194.5025]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 143.05499999999998, 194.3675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 143.14499999999998, 194.352]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 143.95499999999998, 194.208]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 144.045, 194.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 144.855, 194.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 144.945, 194.042]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 145.75500000000002, 193.898]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 145.84500000000003, 193.8825]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 146.655, 193.7475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 146.745, 193.73200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 147.555, 193.58800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 147.645, 193.57250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 148.455, 193.43750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 148.54500000000002, 193.42200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 149.35500000000002, 193.27800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 149.44500000000002, 193.26250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 150.25500000000002, 193.12750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 150.345, 193.11200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 151.15499999999997, 192.96800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 151.24499999999998, 192.95250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 152.05499999999998, 192.8175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 152.14499999999998, 192.802]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 152.955, 192.65800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 153.04500000000002, 192.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 153.85500000000002, 192.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 153.94500000000002, 192.49200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 154.75500000000002, 192.348]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 154.84500000000003, 192.33249999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 155.655, 192.1975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 155.745, 192.18200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 156.555, 192.038]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 156.645, 192.0225]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 157.455, 191.88750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 157.545, 191.872]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 158.355, 191.728]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 158.445, 191.7125]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 159.255, 191.57750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 159.345, 191.562]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 160.155, 191.418]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 160.245, 191.4025]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 161.055, 191.26749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 161.145, 191.25199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 161.955, 191.108]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 162.04500000000002, 191.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 162.85500000000002, 190.95749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 162.94500000000002, 190.94199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 163.75500000000002, 190.79799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 163.84500000000003, 190.78249999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 164.655, 190.64749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 164.74499999999998, 190.632]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 165.55499999999998, 190.488]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 165.64499999999998, 190.4725]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 166.45499999999998, 190.33750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 166.545, 190.32200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 167.355, 190.178]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 167.445, 190.1625]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 168.25500000000002, 190.0275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 168.34500000000003, 190.012]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 169.155, 189.86800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 169.245, 189.85250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 170.055, 189.7175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 170.145, 189.702]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 170.955, 189.55800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 171.04500000000002, 189.54250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 171.85500000000002, 189.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 171.94500000000002, 189.392]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 172.75500000000002, 189.248]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 172.845, 189.23250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 173.65499999999997, 189.09750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 173.74499999999998, 189.08200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 174.55499999999998, 188.93800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 174.64499999999998, 188.9225]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 175.455, 188.78750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 175.54500000000002, 188.77200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 176.35500000000002, 188.62800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 176.44500000000002, 188.6125]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 177.25500000000002, 188.4775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 177.34500000000003, 188.462]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 178.155, 188.318]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 178.245, 188.3025]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 179.055, 188.1675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 179.145, 188.152]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 179.955, 188.008]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.955, 180.0, 187.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.145, 180.0, 187.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.05499999999999, 180.0, 187.84199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.245, 180.0, 187.69799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.15500000000002, 180.0, 187.6825]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.345, 180.0, 187.5475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.255, 180.0, 187.532]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.44500000000001, 180.0, 187.388]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.355, 180.0, 187.3725]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.545, 180.0, 187.2375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.455, 180.0, 187.222]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.645, 180.0, 187.078]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.555, 180.0, 187.0625]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.745, 180.0, 186.92749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.655, 180.0, 186.91199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.845, 180.0, 186.768]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.755, 180.0, 186.7525]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.94500000000001, 180.0, 186.6175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.855, 180.0, 186.602]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.045, 180.0, 186.458]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.95500000000001, 180.0, 186.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.14500000000001, 180.0, 186.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.055, 180.0, 186.29200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.245, 180.0, 186.14799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.155, 180.0, 186.1325]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.345, 180.0, 185.99750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.255, 180.0, 185.98200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.44500000000001, 180.0, 185.83800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.35500000000002, 180.0, 185.82250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.54500000000002, 180.0, 185.68750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.45500000000001, 180.0, 185.67200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.645, 180.0, 185.52800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.55499999999999, 180.0, 185.51250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.745, 180.0, 185.3775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.655, 180.0, 185.362]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.845, 180.0, 185.21800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.755, 180.0, 185.20250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.94500000000001, 180.0, 185.0675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.85500000000002, 180.0, 185.052]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.045, 180.0, 184.908]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.955, 180.0, 184.89249999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.145, 180.0, 184.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.05499999999999, 180.0, 184.74200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.245, 180.0, 184.598]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.155, 180.0, 184.5825]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.345, 180.0, 184.44750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.255, 180.0, 184.43200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.44500000000001, 180.0, 184.288]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.355, 180.0, 184.2725]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.545, 180.0, 184.13750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.455, 180.0, 184.122]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.645, 180.0, 183.978]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.55499999999999, 180.0, 183.9625]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.745, 180.0, 183.8275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.655, 180.0, 183.81199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.845, 180.0, 183.668]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.755, 180.0, 183.6525]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.945, 180.0, 183.51749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.855, 180.0, 183.50199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.045, 180.0, 183.35799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.955000000000005, 180.0, 183.34249999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.145, 180.0, 183.20749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.055, 180.0, 183.192]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.245000000000005, 180.0, 183.048]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.15500000000001, 180.0, 183.0325]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.345, 180.0, 182.8975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.254999999999995, 180.0, 182.882]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.445, 180.0, 182.738]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.355000000000004, 180.0, 182.7225]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.545, 180.0, 182.5875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.455, 180.0, 182.572]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.645, 180.0, 182.428]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.55500000000001, 180.0, 182.4125]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.745000000000005, 180.0, 182.2775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.655, 180.0, 182.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.845, 180.0, 182.11800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.754999999999995, 180.0, 182.10250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.94499999999999, 180.0, 181.9675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.855, 180.0, 181.952]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.045, 180.0, 181.808]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.955, 180.0, 181.79250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.144999999999996, 180.0, 181.65750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.055, 180.0, 181.64200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.245000000000005, 180.0, 181.49800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.155, 180.0, 181.48250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.345, 180.0, 181.34750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.255, 180.0, 181.33200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.445, 180.0, 181.18800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.355000000000004, 180.0, 181.1725]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.545, 180.0, 181.0375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.455000000000005, 180.0, 181.022]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.645, 180.0, 180.87800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.55500000000001, 180.0, 180.8625]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.745000000000005, 180.0, 180.7275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.65500000000001, 180.0, 180.712]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.845, 180.0, 180.568]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.754999999999995, 180.0, 180.5525]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.945, 180.0, 180.4175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.855000000000004, 180.0, 180.402]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.045, 180.0, 180.25799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 180.045, 180.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 180.855, 180.10750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 180.945, 180.092]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 181.755, 179.948]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 181.845, 179.9325]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 182.655, 179.7975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 182.745, 179.782]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 183.555, 179.638]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 183.645, 179.6225]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 184.455, 179.48749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 184.54500000000002, 179.47199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 185.35500000000002, 179.328]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 185.44500000000002, 179.3125]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 186.25500000000002, 179.17749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 186.34500000000003, 179.16199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 187.155, 179.018]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 187.24499999999998, 179.0025]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 188.05499999999998, 178.8675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 188.14499999999998, 178.85200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 188.95499999999998, 178.70799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 189.045, 178.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 189.855, 178.55750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 189.945, 178.54200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 190.75500000000002, 178.398]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 190.84500000000003, 178.3825]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 191.655, 178.24750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 191.745, 178.23200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 192.555, 178.08800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 192.645, 178.07250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 193.455, 177.9375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 193.54500000000002, 177.922]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 194.35500000000002, 177.77800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 194.44500000000002, 177.76250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 195.25500000000002, 177.6275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 195.34500000000003, 177.612]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 196.15499999999997, 177.468]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 196.24499999999998, 177.4525]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 197.05499999999998, 177.3175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 197.14499999999998, 177.30200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 197.955, 177.15800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 198.04500000000002, 177.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 198.85500000000002, 177.00750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 198.94500000000002, 176.99200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 199.75500000000002, 176.848]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 199.84500000000003, 176.8325]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 200.655, 176.69750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 200.745, 176.68200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 201.555, 176.538]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 201.645, 176.5225]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 202.455, 176.3875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 202.54500000000002, 176.37199999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 203.35500000000002, 176.228]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 203.445, 176.2125]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 204.255, 176.0775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 204.345, 176.06199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 205.155, 175.91799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 205.245, 175.90249999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 206.055, 175.76749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 206.145, 175.752]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 206.955, 175.608]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 207.04500000000002, 175.5925]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 207.85500000000002, 175.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 207.94500000000002, 175.442]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 208.75500000000002, 175.298]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 208.84500000000003, 175.2825]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 209.655, 175.1475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 209.745, 175.132]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 210.555, 174.988]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 210.64499999999998, 174.9725]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 211.45499999999998, 174.8375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 211.545, 174.822]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 212.355, 174.678]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 212.445, 174.6625]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 213.25500000000002, 174.5275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 213.34500000000003, 174.512]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 214.155, 174.368]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 214.245, 174.35250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 215.055, 174.21750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 215.145, 174.20200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 215.955, 174.05800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 216.04500000000002, 174.04250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 216.85500000000002, 173.90750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 216.94500000000002, 173.89200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 217.75500000000002, 173.74800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 217.84500000000003, 173.73250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 218.65499999999997, 173.5975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 218.74499999999998, 173.582]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 219.55499999999998, 173.43800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 219.64499999999998, 173.4225]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 220.455, 173.2875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 220.54500000000002, 173.272]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 221.35500000000002, 173.12800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 221.44500000000002, 173.1125]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 222.25500000000002, 172.9775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 222.34500000000003, 172.962]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 223.155, 172.81799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 223.245, 172.8025]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 224.055, 172.66750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 224.145, 172.65200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 224.955, 172.508]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.045, 225.0, 172.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.855000000000004, 225.0, 172.35750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.945, 225.0, 172.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.754999999999995, 225.0, 172.198]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.845, 225.0, 172.1825]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.65500000000001, 225.0, 172.04749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.745000000000005, 225.0, 172.03199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.55500000000001, 225.0, 171.888]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.645, 225.0, 171.8725]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.455000000000005, 225.0, 171.73749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.545, 225.0, 171.72199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.355000000000004, 225.0, 171.578]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.445, 225.0, 171.5625]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.255, 225.0, 171.42749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.345, 225.0, 171.41199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.155, 225.0, 171.26799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.245000000000005, 225.0, 171.2525]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.055, 225.0, 171.11750000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.144999999999996, 225.0, 171.10200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.955, 225.0, 170.958]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.045, 225.0, 170.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.855, 225.0, 170.80750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.94499999999999, 225.0, 170.79200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.754999999999995, 225.0, 170.648]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.845, 225.0, 170.6325]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.655, 225.0, 170.4975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.745000000000005, 225.0, 170.482]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.55500000000001, 225.0, 170.33800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.645, 225.0, 170.32250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.455, 225.0, 170.1875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.545, 225.0, 170.172]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.355000000000004, 225.0, 170.028]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.445, 225.0, 170.0125]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.254999999999995, 225.0, 169.8775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.345, 225.0, 169.86200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.15500000000001, 225.0, 169.71800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.245000000000005, 225.0, 169.70250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.055, 225.0, 169.56750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.145, 225.0, 169.55200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.955000000000005, 225.0, 169.40800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.045, 225.0, 169.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.855, 225.0, 169.25750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.945, 225.0, 169.24200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.755, 225.0, 169.098]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.845, 225.0, 169.0825]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.655, 225.0, 168.9475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.745, 225.0, 168.932]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.55499999999999, 225.0, 168.788]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.645, 225.0, 168.7725]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.455, 225.0, 168.6375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.545, 225.0, 168.62199999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.355, 225.0, 168.47799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.44500000000001, 225.0, 168.46249999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.255, 225.0, 168.3275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.345, 225.0, 168.312]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.155, 225.0, 168.168]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.245, 225.0, 168.1525]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.05499999999999, 225.0, 168.0175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.145, 225.0, 168.002]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.955, 225.0, 167.858]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.045, 225.0, 167.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.85500000000002, 225.0, 167.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.94500000000001, 225.0, 167.692]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.755, 225.0, 167.548]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.845, 225.0, 167.5325]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.655, 225.0, 167.39749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.745, 225.0, 167.38199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.55499999999999, 225.0, 167.238]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.645, 225.0, 167.2225]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.45500000000001, 225.0, 167.0875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.54500000000002, 225.0, 167.072]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.35500000000002, 225.0, 166.92799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.44500000000001, 225.0, 166.91249999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.255, 225.0, 166.77750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.345, 225.0, 166.76200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.155, 225.0, 166.61800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.245, 225.0, 166.60250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.055, 225.0, 166.46750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.14500000000001, 225.0, 166.45200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.95500000000001, 225.0, 166.30800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.045, 225.0, 166.29250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.855, 225.0, 166.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.94500000000001, 225.0, 166.142]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.755, 225.0, 165.99800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.845, 225.0, 165.98250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.655, 225.0, 165.8475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.745, 225.0, 165.832]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.555, 225.0, 165.68800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.645, 225.0, 165.6725]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.455, 225.0, 165.5375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.545, 225.0, 165.522]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.355, 225.0, 165.378]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.44500000000001, 225.0, 165.3625]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.255, 225.0, 165.22750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.345, 225.0, 165.21200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.15500000000002, 225.0, 165.068]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.245, 225.0, 165.0525]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.05499999999999, 225.0, 164.91750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.145, 225.0, 164.90200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.955, 225.0, 164.758]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 224.955, 164.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 224.145, 164.6075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 224.055, 164.59199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 223.245, 164.448]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 223.155, 164.4325]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 222.34500000000003, 164.29749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 222.25500000000002, 164.28199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 221.44500000000002, 164.138]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 221.35500000000002, 164.1225]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 220.54500000000002, 163.98749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 220.455, 163.97199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 219.64499999999998, 163.82799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 219.55499999999998, 163.8125]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 218.74499999999998, 163.6775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 218.65499999999997, 163.662]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 217.84500000000003, 163.518]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 217.75500000000002, 163.5025]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 216.94500000000002, 163.36750000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 216.85500000000002, 163.35200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 216.04500000000002, 163.208]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 215.955, 163.1925]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 215.145, 163.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 215.055, 163.042]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 214.245, 162.898]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 214.155, 162.8825]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 213.34500000000003, 162.7475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 213.25500000000002, 162.732]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 212.445, 162.588]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 212.355, 162.5725]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 211.545, 162.4375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 211.45499999999998, 162.42200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 210.64499999999998, 162.27800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 210.555, 162.26250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 209.745, 162.12750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 209.655, 162.11200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 208.84500000000003, 161.96800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 208.75500000000002, 161.95250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 207.94500000000002, 161.81750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 207.85500000000002, 161.80200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 207.04500000000002, 161.65800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 206.955, 161.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 206.145, 161.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 206.055, 161.492]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 205.245, 161.348]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 205.155, 161.3325]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 204.345, 161.1975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 204.255, 161.182]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 203.445, 161.03799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 203.35500000000002, 161.02249999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 202.54500000000002, 160.8875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 202.455, 160.872]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 201.645, 160.728]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 201.555, 160.7125]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 200.745, 160.57750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 200.655, 160.562]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 199.84500000000003, 160.418]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 199.75500000000002, 160.4025]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 198.94500000000002, 160.2675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 198.85500000000002, 160.252]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 198.04500000000002, 160.108]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 197.955, 160.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 197.14499999999998, 159.95749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 197.05499999999998, 159.94199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 196.24499999999998, 159.798]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 196.15499999999997, 159.7825]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 195.34500000000003, 159.64749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 195.25500000000002, 159.63199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 194.44500000000002, 159.48799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 194.35500000000002, 159.47249999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 193.54500000000002, 159.33750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 193.455, 159.32200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 192.645, 159.178]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 192.555, 159.1625]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 191.745, 159.02750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 191.655, 159.01200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 190.84500000000003, 158.86800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 190.75500000000002, 158.85250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 189.945, 158.7175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 189.855, 158.702]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 189.045, 158.55800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 188.95499999999998, 158.54250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 188.14499999999998, 158.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 188.05499999999998, 158.392]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 187.24499999999998, 158.24800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 187.155, 158.23250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 186.34500000000003, 158.0975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 186.25500000000002, 158.082]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 185.44500000000002, 157.938]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 185.35500000000002, 157.9225]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 184.54500000000002, 157.78750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 184.455, 157.77200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 183.645, 157.62800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 183.555, 157.6125]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 182.745, 157.47750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 182.655, 157.46200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 181.845, 157.318]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 181.755, 157.3025]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 180.945, 157.1675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 180.855, 157.152]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 180.045, 157.008]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.955, 180.0, 156.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.145, 180.0, 156.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.05499999999999, 180.0, 156.84199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.245, 180.0, 156.698]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.15500000000002, 180.0, 156.6825]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.345, 180.0, 156.54749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.255, 180.0, 156.53199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.44500000000001, 180.0, 156.38799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.355, 180.0, 156.3725]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.545, 180.0, 156.2375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.455, 180.0, 156.222]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.645, 180.0, 156.078]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.555, 180.0, 156.0625]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.745, 180.0, 155.9275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.655, 180.0, 155.912]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.845, 180.0, 155.768]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.755, 180.0, 155.7525]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.94500000000001, 180.0, 155.6175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.855, 180.0, 155.602]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.045, 180.0, 155.458]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.95500000000001, 180.0, 155.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.14500000000001, 180.0, 155.3075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.055, 180.0, 155.292]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.245, 180.0, 155.148]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.155, 180.0, 155.1325]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.345, 180.0, 154.9975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.255, 180.0, 154.98200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.44500000000001, 180.0, 154.83800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.35500000000002, 180.0, 154.82250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.54500000000002, 180.0, 154.68750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.45500000000001, 180.0, 154.67200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.645, 180.0, 154.52800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.55499999999999, 180.0, 154.51250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.745, 180.0, 154.37750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.655, 180.0, 154.36200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.845, 180.0, 154.21800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.755, 180.0, 154.20250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.94500000000001, 180.0, 154.0675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.85500000000002, 180.0, 154.052]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.045, 180.0, 153.90800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.955, 180.0, 153.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.145, 180.0, 153.7575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.05499999999999, 180.0, 153.742]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.245, 180.0, 153.59799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.155, 180.0, 153.58249999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.345, 180.0, 153.4475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.255, 180.0, 153.43200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.44500000000001, 180.0, 153.288]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.355, 180.0, 153.2725]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.545, 180.0, 153.13750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.455, 180.0, 153.122]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.645, 180.0, 152.978]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.55499999999999, 180.0, 152.9625]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.745, 180.0, 152.82750000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.655, 180.0, 152.812]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.845, 180.0, 152.668]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.755, 180.0, 152.6525]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.945, 180.0, 152.51749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.855, 180.0, 152.50199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.045, 180.0, 152.358]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.955000000000005, 180.0, 152.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.145, 180.0, 152.20749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.055, 180.0, 152.19199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.245000000000005, 180.0, 152.04799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.15500000000001, 180.0, 152.03249999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.345, 180.0, 151.89749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.254999999999995, 180.0, 151.882]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.445, 180.0, 151.738]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.355000000000004, 180.0, 151.7225]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.545, 180.0, 151.58750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.455, 180.0, 151.57200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.645, 180.0, 151.428]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.55500000000001, 180.0, 151.4125]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.745000000000005, 180.0, 151.2775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.655, 180.0, 151.262]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.845, 180.0, 151.11800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.754999999999995, 180.0, 151.10250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.94499999999999, 180.0, 150.9675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.855, 180.0, 150.952]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.045, 180.0, 150.80800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.955, 180.0, 150.79250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.144999999999996, 180.0, 150.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.055, 180.0, 150.642]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.245000000000005, 180.0, 150.498]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.155, 180.0, 150.48250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.345, 180.0, 150.34750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.255, 180.0, 150.33200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.445, 180.0, 150.18800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.355000000000004, 180.0, 150.1725]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.545, 180.0, 150.03750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.455000000000005, 180.0, 150.02200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.645, 180.0, 149.87800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.55500000000001, 180.0, 149.8625]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.745000000000005, 180.0, 149.7275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.65500000000001, 180.0, 149.712]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.845, 180.0, 149.568]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.754999999999995, 180.0, 149.5525]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.945, 180.0, 149.4175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.855000000000004, 180.0, 149.402]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.045, 180.0, 149.258]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 179.955, 149.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 179.145, 149.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 179.055, 149.09199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 178.245, 148.94799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 178.155, 148.9325]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 177.34500000000003, 148.7975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 177.25500000000002, 148.782]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 176.44500000000002, 148.638]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 176.35500000000002, 148.6225]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 175.54500000000002, 148.4875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 175.455, 148.472]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 174.64499999999998, 148.328]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 174.55499999999998, 148.3125]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 173.74499999999998, 148.17749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 173.65499999999997, 148.16199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 172.845, 148.018]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 172.75500000000002, 148.0025]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 171.94500000000002, 147.8675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 171.85500000000002, 147.852]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 171.04500000000002, 147.708]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 170.955, 147.6925]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 170.145, 147.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 170.055, 147.54200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 169.245, 147.39799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 169.155, 147.3825]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 168.34500000000003, 147.24750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 168.25500000000002, 147.23200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 167.445, 147.08800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 167.355, 147.07250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 166.545, 146.93750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 166.45499999999998, 146.92200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 165.64499999999998, 146.77800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 165.55499999999998, 146.76250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 164.74499999999998, 146.6275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 164.655, 146.612]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 163.84500000000003, 146.46800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 163.75500000000002, 146.45250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 162.94500000000002, 146.3175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 162.85500000000002, 146.302]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 162.04500000000002, 146.158]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 161.955, 146.14249999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 161.145, 146.0075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 161.055, 145.99200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 160.245, 145.848]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 160.155, 145.8325]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 159.345, 145.69750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 159.255, 145.68200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 158.445, 145.538]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 158.355, 145.5225]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 157.545, 145.38750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 157.455, 145.372]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 156.645, 145.228]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 156.555, 145.2125]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 155.745, 145.0775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 155.655, 145.06199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 154.84500000000003, 144.918]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 154.75500000000002, 144.9025]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 153.94500000000002, 144.76749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 153.85500000000002, 144.75199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 153.04500000000002, 144.60799999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 152.955, 144.59249999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 152.14499999999998, 144.45749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 152.05499999999998, 144.442]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 151.24499999999998, 144.298]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 151.15499999999997, 144.2825]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 150.345, 144.1475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 150.25500000000002, 144.132]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 149.44500000000002, 143.988]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 149.35500000000002, 143.9725]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 148.54500000000002, 143.8375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 148.455, 143.822]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 147.645, 143.678]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 147.555, 143.6625]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 146.745, 143.5275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 146.655, 143.512]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 145.84500000000003, 143.36800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 145.75500000000002, 143.35250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 144.945, 143.2175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 144.855, 143.202]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 144.045, 143.058]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 143.95499999999998, 143.04250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 143.14499999999998, 142.90750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 143.05499999999998, 142.89200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 142.24499999999998, 142.74800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 142.155, 142.73250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 141.34500000000003, 142.59750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 141.25500000000002, 142.58200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 140.44500000000002, 142.43800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 140.35500000000002, 142.4225]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 139.545, 142.2875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 139.45499999999998, 142.272]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 138.64499999999998, 142.128]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 138.555, 142.1125]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 137.745, 141.9775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 137.655, 141.962]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 136.84500000000003, 141.818]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 136.75500000000002, 141.8025]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 135.945, 141.6675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.0, 135.855, 141.652]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.0, 135.045, 141.508]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.045, 135.0, 141.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([45.855000000000004, 135.0, 141.35750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([45.945, 135.0, 141.342]) cube([0.4, 0.4, 0.1], center=true);
    translate([46.754999999999995, 135.0, 141.198]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([46.845, 135.0, 141.1825]) cube([0.4, 0.4, 0.1], center=true);
    translate([47.65500000000001, 135.0, 141.04749999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([47.745000000000005, 135.0, 141.03199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([48.55500000000001, 135.0, 140.888]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([48.645, 135.0, 140.8725]) cube([0.4, 0.4, 0.1], center=true);
    translate([49.455000000000005, 135.0, 140.7375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([49.545, 135.0, 140.72199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([50.355000000000004, 135.0, 140.57799999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([50.445, 135.0, 140.5625]) cube([0.4, 0.4, 0.1], center=true);
    translate([51.255, 135.0, 140.42749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([51.345, 135.0, 140.41199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([52.155, 135.0, 140.268]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([52.245000000000005, 135.0, 140.2525]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.055, 135.0, 140.1175]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([53.144999999999996, 135.0, 140.10200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([53.955, 135.0, 139.958]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.045, 135.0, 139.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([54.855, 135.0, 139.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([54.94499999999999, 135.0, 139.792]) cube([0.4, 0.4, 0.1], center=true);
    translate([55.754999999999995, 135.0, 139.648]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([55.845, 135.0, 139.6325]) cube([0.4, 0.4, 0.1], center=true);
    translate([56.655, 135.0, 139.4975]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([56.745000000000005, 135.0, 139.48200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([57.55500000000001, 135.0, 139.33800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([57.645, 135.0, 139.32250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([58.455, 135.0, 139.1875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([58.545, 135.0, 139.17200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([59.355000000000004, 135.0, 139.02800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([59.445, 135.0, 139.01250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([60.254999999999995, 135.0, 138.8775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([60.345, 135.0, 138.862]) cube([0.4, 0.4, 0.1], center=true);
    translate([61.15500000000001, 135.0, 138.71800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([61.245000000000005, 135.0, 138.70250000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.055, 135.0, 138.5675]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([62.145, 135.0, 138.55200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([62.955000000000005, 135.0, 138.40800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.045, 135.0, 138.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([63.855, 135.0, 138.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([63.945, 135.0, 138.242]) cube([0.4, 0.4, 0.1], center=true);
    translate([64.755, 135.0, 138.098]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([64.845, 135.0, 138.0825]) cube([0.4, 0.4, 0.1], center=true);
    translate([65.655, 135.0, 137.9475]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([65.745, 135.0, 137.93200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([66.55499999999999, 135.0, 137.788]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([66.645, 135.0, 137.7725]) cube([0.4, 0.4, 0.1], center=true);
    translate([67.455, 135.0, 137.6375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([67.545, 135.0, 137.622]) cube([0.4, 0.4, 0.1], center=true);
    translate([68.355, 135.0, 137.478]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([68.44500000000001, 135.0, 137.4625]) cube([0.4, 0.4, 0.1], center=true);
    translate([69.255, 135.0, 137.3275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([69.345, 135.0, 137.31199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([70.155, 135.0, 137.168]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([70.245, 135.0, 137.1525]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.05499999999999, 135.0, 137.01749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([71.145, 135.0, 137.002]) cube([0.4, 0.4, 0.1], center=true);
    translate([71.955, 135.0, 136.858]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.045, 135.0, 136.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([72.85500000000002, 135.0, 136.70749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([72.94500000000001, 135.0, 136.69199999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([73.755, 135.0, 136.548]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([73.845, 135.0, 136.5325]) cube([0.4, 0.4, 0.1], center=true);
    translate([74.655, 135.0, 136.39749999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([74.745, 135.0, 136.382]) cube([0.4, 0.4, 0.1], center=true);
    translate([75.55499999999999, 135.0, 136.238]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([75.645, 135.0, 136.2225]) cube([0.4, 0.4, 0.1], center=true);
    translate([76.45500000000001, 135.0, 136.0875]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([76.54500000000002, 135.0, 136.072]) cube([0.4, 0.4, 0.1], center=true);
    translate([77.35500000000002, 135.0, 135.928]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([77.44500000000001, 135.0, 135.9125]) cube([0.4, 0.4, 0.1], center=true);
    translate([78.255, 135.0, 135.7775]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([78.345, 135.0, 135.762]) cube([0.4, 0.4, 0.1], center=true);
    translate([79.155, 135.0, 135.61800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([79.245, 135.0, 135.60250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.055, 135.0, 135.46750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([80.14500000000001, 135.0, 135.45200000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([80.95500000000001, 135.0, 135.30800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.045, 135.0, 135.29250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([81.855, 135.0, 135.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([81.94500000000001, 135.0, 135.142]) cube([0.4, 0.4, 0.1], center=true);
    translate([82.755, 135.0, 134.99800000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([82.845, 135.0, 134.98250000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([83.655, 135.0, 134.84750000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([83.745, 135.0, 134.832]) cube([0.4, 0.4, 0.1], center=true);
    translate([84.555, 135.0, 134.688]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([84.645, 135.0, 134.6725]) cube([0.4, 0.4, 0.1], center=true);
    translate([85.455, 135.0, 134.5375]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([85.545, 135.0, 134.522]) cube([0.4, 0.4, 0.1], center=true);
    translate([86.355, 135.0, 134.37800000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([86.44500000000001, 135.0, 134.3625]) cube([0.4, 0.4, 0.1], center=true);
    translate([87.255, 135.0, 134.2275]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([87.345, 135.0, 134.212]) cube([0.4, 0.4, 0.1], center=true);
    translate([88.15500000000002, 135.0, 134.068]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([88.245, 135.0, 134.0525]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.05499999999999, 135.0, 133.91750000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([89.145, 135.0, 133.90200000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([89.955, 135.0, 133.758]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([90.0, 135.0, 127.0625]) cube([0.4, 0.4, 0.1], center=true);
    translate([90.0, 135.0, 6.6875]) cube([0.4, 0.4, 0.1], center=true);
}

