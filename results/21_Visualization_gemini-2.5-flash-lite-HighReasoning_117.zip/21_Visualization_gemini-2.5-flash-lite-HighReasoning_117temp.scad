
hull() {
    translate([7.554, 7.5, 8.9955]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.526, 7.5, 8.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.634500000000001, 7.5, 8.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.615499999999999, 7.5, 8.8245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.724, 7.5, 8.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.696000000000002, 7.5, 8.7345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.804, 7.5, 8.7255]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.776, 7.5, 8.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.884, 7.5, 8.6355]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.856, 7.5, 8.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.948, 7.5125, 8.546500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.632000000000001, 7.737500000000001, 8.483500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.670000000000002, 7.800000000000001, 8.4755]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.670000000000002, 8.7, 8.3945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.670000000000002, 8.8, 8.3855]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.670000000000002, 9.700000000000001, 8.3045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.670000000000002, 9.8, 8.2955]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.670000000000002, 10.700000000000001, 8.214500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.670000000000002, 10.8, 8.2055]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.670000000000002, 11.700000000000001, 8.1245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.670000000000002, 11.8, 8.115499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.670000000000002, 12.7, 8.0345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.654, 12.7845, 8.026499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.366, 13.4055, 7.9635]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.314, 13.44, 7.9555]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.666, 13.44, 7.8745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.594000000000001, 13.44, 7.8655]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.946000000000002, 13.44, 7.7845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.874, 13.44, 7.775500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.225999999999999, 13.44, 7.694500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.154, 13.44, 7.6855]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.506, 13.44, 7.6045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.434, 13.44, 7.5954999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.786, 13.44, 7.5145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.714, 13.44, 7.5055000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.065999999999999, 13.44, 7.4245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.994, 13.44, 7.4155]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.346, 13.44, 7.3345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.274000000000001, 13.44, 7.325500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.626, 13.44, 7.2445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.554, 13.44, 7.2355]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.906, 13.44, 7.1545000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.834, 13.44, 7.1455]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.186, 13.44, 7.064500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.114, 13.44, 7.0555]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.465999999999999, 13.44, 6.9745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.393999999999999, 13.44, 6.9655]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.7459999999999996, 13.44, 6.8845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.6739999999999995, 13.44, 6.875500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.026, 13.44, 6.794499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.954, 13.44, 6.7855]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.306, 13.44, 6.7045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.234, 13.44, 6.6955]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.586, 13.44, 6.6145000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.514, 13.44, 6.605500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.866, 13.44, 6.5245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.794, 13.44, 6.515499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.1460000000000001, 13.44, 6.4345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.074, 13.44, 6.4254999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.42600000000000005, 13.44, 6.3445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.37050000000000005, 13.405000000000001, 6.336500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.019500000000000003, 12.775000000000002, 6.2735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 12.699000000000002, 6.265499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 11.961, 6.1845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 11.879, 6.1755]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 11.141, 6.0945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 11.059000000000001, 6.0855]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 10.320999999999998, 6.0045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 10.238999999999999, 5.995500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 9.501000000000001, 5.9145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 9.419, 5.9055]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 8.681000000000001, 5.8245000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 8.599, 5.8155]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 7.861000000000001, 5.734500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 7.779, 5.725500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 7.041, 5.6445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 6.959, 5.6354999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 6.221, 5.5545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 6.139, 5.5455000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 5.401000000000001, 5.464499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 5.319000000000001, 5.4555]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 4.581, 5.3745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 4.4990000000000006, 5.3655]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 3.761, 5.2845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 3.6790000000000003, 5.275500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.941, 5.194500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.859, 5.1855]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 2.121, 5.1045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 2.039, 5.0954999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 1.3010000000000002, 5.0145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.0, 1.219, 5.0055000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.0, 0.48100000000000004, 4.9245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.019500000000000003, 0.41800000000000004, 4.9165]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.37050000000000005, 0.022000000000000002, 4.8535]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.42600000000000005, 0.0, 4.8455]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.074, 0.0, 4.7645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.1460000000000001, 0.0, 4.7555]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.794, 0.0, 4.6745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.866, 0.0, 4.665500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.514, 0.0, 4.5845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.586, 0.0, 4.5755]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.234, 0.0, 4.4945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.306, 0.0, 4.4855]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.954, 0.0, 4.4045000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.026, 0.0, 4.3955]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.6739999999999995, 0.0, 4.3145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.7459999999999996, 0.0, 4.305499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.393999999999999, 0.0, 4.2245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.465999999999999, 0.0, 4.2155000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.114, 0.0, 4.1345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.186, 0.0, 4.1255]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.834, 0.0, 4.0445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.906, 0.0, 4.0355]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.554, 0.0, 3.9545000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.626, 0.0, 3.9455]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.274000000000001, 0.0, 3.8644999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.346, 0.0, 3.8554999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.994, 0.0, 3.7745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.065999999999999, 0.0, 3.7655000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.714, 0.0, 3.6845000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.786, 0.0, 3.6755000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.434, 0.0, 3.5945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.506, 0.0, 3.5854999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.154, 0.0, 3.5045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.225999999999999, 0.0, 3.4955]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.874, 0.0, 3.4145000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.946000000000002, 0.0, 3.4055000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.594000000000001, 0.0, 3.3245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.666, 0.0, 3.3155]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.314, 0.0, 3.2345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.387, 0.0, 3.2255000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.053, 0.0, 3.1445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.105500000000001, 0.018, 3.1365]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.384500000000001, 0.342, 3.0735]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 0.401, 3.0655]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 1.139, 2.9844999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 1.221, 2.9755]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 1.959, 2.8945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 2.041, 2.8855]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 2.779, 2.8045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 2.8609999999999998, 2.7955]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 3.599, 2.7145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 3.681, 2.7055000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 4.4190000000000005, 2.6245000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 4.501, 2.6155]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 5.239000000000001, 2.5344999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 5.321000000000001, 2.5254999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 6.059, 2.4445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 6.141, 2.4355]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 6.879, 2.3545000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 6.961, 2.3455000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 7.699, 2.2645]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 7.781000000000001, 2.2554999999999996]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 8.519, 2.1745]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 8.601, 2.1655]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 9.339, 2.0845000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 9.421, 2.0755]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 10.158999999999999, 1.9945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 10.241, 1.9855]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 10.979, 1.9045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 11.061, 1.8955]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 11.799000000000001, 1.8145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 11.881, 1.8055]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 12.619, 1.7245000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.4, 12.701, 1.7155]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4, 13.439000000000002, 1.6344999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.3785, 13.514000000000001, 1.6269999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.9915, 14.126, 1.573]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.934000000000001, 14.16, 1.5655000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.286000000000001, 14.16, 1.4845000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.214, 14.16, 1.4755]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.565999999999999, 14.16, 1.3944999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.494, 14.16, 1.3855]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.846000000000002, 14.16, 1.3045000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.774000000000001, 14.16, 1.2955]) cube([0.4, 0.4, 0.1], center=true);
    translate([11.126, 14.16, 1.2145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.054, 14.16, 1.2055]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.406, 14.16, 1.1245000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.334, 14.16, 1.1155000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.686, 14.16, 1.0345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.614, 14.16, 1.0255]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.966000000000001, 14.16, 0.9445]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.894, 14.16, 0.9355]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.246, 14.16, 0.8545]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.174000000000001, 14.16, 0.8455]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.526000000000001, 14.16, 0.7645000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.454000000000001, 14.16, 0.7555000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.806, 14.16, 0.6745000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.734, 14.16, 0.6655000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.086, 14.16, 0.5845]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.014, 14.16, 0.5755]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.3660000000000005, 14.16, 0.4945]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2940000000000005, 14.16, 0.4855]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.646, 14.16, 0.4045]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.574, 14.16, 0.3955]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.926, 14.16, 0.3145]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.8540000000000005, 14.16, 0.30550000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.2060000000000004, 14.16, 0.2245]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.1340000000000003, 14.16, 0.2155]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.486, 14.16, 0.1345]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.414, 14.16, 0.1255]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.766, 14.16, 0.044500000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.7109999999999999, 14.152, 0.038000000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.3690000000000002, 14.008, 0.002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.35, 13.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.35, 13.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.35, 12.950000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.35, 12.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.35, 11.950000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.35, 11.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.35, 10.950000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.35, 10.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.35, 9.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.35, 9.049999999999999, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.35, 8.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.35, 8.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.35, 7.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.35, 7.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.35, 6.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.35, 6.050000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.35, 5.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.35, 5.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.35, 4.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.35, 4.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.35, 3.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.35, 3.0500000000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.35, 2.95, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.35, 2.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.35, 1.9500000000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.35, 1.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.35, 0.9500000000000001, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.35, 0.05, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}

