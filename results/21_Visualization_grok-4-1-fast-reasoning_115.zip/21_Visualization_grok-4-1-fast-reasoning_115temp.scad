
hull() {
    translate([18.993000000000002, 10.078, 18.991500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.867, 11.482, 18.8385]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.827, 11.632, 18.8215]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.233, 12.928, 18.6685]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.1455, 13.067, 18.6515]) cube([0.4, 0.4, 0.1], center=true);
    translate([17.1645, 14.273, 18.4985]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([17.037, 14.401, 18.481499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.723, 15.499000000000002, 18.3285]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.5625, 15.614, 18.3115]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.9875, 16.586000000000002, 18.1585]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.801, 16.685000000000002, 18.1415]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.019, 17.495, 17.988500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.814, 17.5765, 17.971500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.906, 18.233500000000003, 17.8185]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.6865, 18.2965, 17.8015]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.6435, 18.773500000000002, 17.648500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.4125000000000005, 18.816000000000003, 17.631500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.2975, 19.104000000000003, 17.4785]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.063, 19.125500000000002, 17.461499999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.957, 19.224500000000003, 17.3085]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.7275, 19.224500000000003, 17.2915]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.7025, 19.125500000000002, 17.1385]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.48350000000000004, 19.104000000000003, 17.1215]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.4335000000000002, 18.816000000000003, 16.968500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.6340000000000001, 18.773500000000002, 16.951500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.3259999999999996, 18.2965, 16.798499999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.4985, 18.233500000000003, 16.781499999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.9115, 17.5765, 16.628500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.053000000000001, 17.495, 16.611500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([-6.187, 16.685000000000002, 16.4585]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-6.297000000000001, 16.586000000000002, 16.4415]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.143000000000001, 15.614, 16.288500000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.2205, 15.499000000000002, 16.2715]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.7695, 14.401, 16.1185]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.814, 14.273, 16.1015]) cube([0.4, 0.4, 0.1], center=true);
    translate([-8.066, 13.067, 15.9485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-8.078, 12.928, 15.9315]) cube([0.4, 0.4, 0.1], center=true);
    translate([-8.042, 11.632, 15.7785]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-8.0215, 11.482, 15.7615]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.6885, 10.078, 15.6085]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.6355, 9.922, 15.5915]) cube([0.4, 0.4, 0.1], center=true);
    translate([-7.014500000000001, 8.518, 15.438500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-6.929500000000001, 8.3675, 15.4215]) cube([0.4, 0.4, 0.1], center=true);
    translate([-6.0205, 7.0625, 15.2685]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.905, 6.923500000000001, 15.2515]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.735, 5.726500000000001, 15.0985]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.591, 5.603000000000001, 15.0815]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.169, 4.577, 14.928500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.0005, 4.476, 14.9115]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.3895000000000002, 3.684, 14.758500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.2005000000000001, 3.6095, 14.7415]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.5905, 3.0604999999999998, 14.5885]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.783, 3.0124999999999997, 14.5715]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.457, 2.6975000000000002, 14.418500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.635, 2.676, 14.401500000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.165, 2.604, 14.2485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.327500000000001, 2.6090000000000004, 14.2315]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.7225, 2.771, 14.0785]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.868, 2.8024999999999998, 14.0615]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.0920000000000005, 3.2075, 13.9085]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.2175, 3.265, 13.8915]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.252500000000001, 3.8950000000000005, 13.738500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.356000000000002, 3.9770000000000003, 13.7215]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.184000000000001, 4.823, 13.5685]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.2635, 4.928, 13.5515]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.8665, 5.972, 13.3985]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.9205, 6.0985000000000005, 13.3815]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.2895, 7.3315, 13.228500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.3175, 7.4785, 13.211500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.452500000000002, 8.8915, 13.058500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.454500000000001, 9.057500000000001, 13.041500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.3555, 10.632500000000002, 12.8885]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.3315, 10.816, 12.871500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.998500000000002, 12.544, 12.718500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.949000000000002, 12.744000000000002, 12.701500000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.391, 14.616000000000001, 12.5485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.3165, 14.831000000000001, 12.5315]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.5335, 16.829, 12.378499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.4345, 17.057000000000002, 12.3615]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.4355, 19.163, 12.2085]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.313000000000001, 19.3565, 12.191500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.107, 20.7335, 12.038499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.9615, 20.8015, 12.0215]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.5485, 20.648500000000002, 11.8685]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.382, 20.601, 11.8515]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.798, 19.898999999999997, 11.6985]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.6145, 19.796999999999997, 11.6815]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.8955000000000001, 18.663000000000004, 11.528500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.7135000000000001, 18.5195, 11.5115]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.8435, 17.0705, 11.3585]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.0030000000000001, 16.8985, 11.3415]) cube([0.4, 0.4, 0.1], center=true);
    translate([-2.317, 15.2515, 11.1885]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-2.4485, 15.060500000000001, 11.1715]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.5015, 13.2695, 11.018500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.604, 13.065999999999999, 11.0015]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.396000000000001, 11.193999999999999, 10.8485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.470000000000001, 10.985, 10.8315]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.010000000000001, 9.095, 10.6785]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.056000000000001, 8.886500000000002, 10.6615]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.344000000000001, 7.0235, 10.508500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.362000000000001, 6.8235, 10.4915]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.398000000000001, 5.086500000000001, 10.3385]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.3885000000000005, 4.9045000000000005, 10.3215]) cube([0.4, 0.4, 0.1], center=true);
    translate([-5.181500000000001, 3.3655, 10.1685]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-5.1455, 3.2095, 10.1515]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.7044999999999995, 1.9405000000000001, 9.9985]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.6425, 1.819, 9.9815]) cube([0.4, 0.4, 0.1], center=true);
    translate([-3.9675000000000002, 0.901, 9.828500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-3.8800000000000003, 0.8205, 9.8115]) cube([0.4, 0.4, 0.1], center=true);
    translate([-2.98, 0.2895, 9.6585]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-2.868, 0.2535, 9.6415]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.752, 0.1365, 9.4885]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.619, 0.14650000000000002, 9.4715]) cube([0.4, 0.4, 0.1], center=true);
    translate([-0.341, 0.44350000000000006, 9.318500000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-0.192, 0.49850000000000005, 9.3015]) cube([0.4, 0.4, 0.1], center=true);
    translate([1.212, 1.1915, 9.1485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([1.371, 1.2894999999999999, 9.1315]) cube([0.4, 0.4, 0.1], center=true);
    translate([2.829, 2.3605, 8.9785]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([2.992, 2.4995, 8.961500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([4.468, 3.9305, 8.8085]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([4.632499999999999, 4.1085, 8.791500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.1175, 5.881500000000001, 8.6385]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.282, 6.0955, 8.621500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.758, 8.1745, 8.4685]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.9195, 8.4215, 8.451500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.3505, 10.788499999999999, 8.298499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.5055, 11.0655, 8.2815]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.8645, 13.684500000000002, 8.128499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([11.0085, 13.989500000000001, 8.1115]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.2415, 16.8605, 7.958500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.3695, 17.191499999999998, 7.9415000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.4405, 20.2785, 7.788500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.5475, 20.627000000000002, 7.7715000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.4025, 23.813, 7.6185]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.485, 24.171999999999997, 7.601500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.115, 27.448, 7.448500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.1725, 27.817500000000003, 7.431500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.577499999999999, 31.192500000000003, 7.2785]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.61, 31.571, 7.2615]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.790000000000001, 35.009, 7.108499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.798000000000002, 35.3945, 7.0915]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.762, 38.895500000000006, 6.9385]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.7465, 39.2875, 6.9215]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.5035, 42.842499999999994, 6.7684999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([15.464500000000001, 43.239999999999995, 6.7515]) cube([0.4, 0.4, 0.1], center=true);
    translate([15.005500000000001, 46.839999999999996, 6.5985]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.943000000000001, 47.2415, 6.5815]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.277000000000001, 50.8685, 6.4285000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.191500000000001, 51.2725, 6.4115]) cube([0.4, 0.4, 0.1], center=true);
    translate([13.3185, 54.9175, 6.2585]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([13.211, 55.32299999999999, 6.2415]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.149000000000001, 58.977000000000004, 6.088500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.02, 59.383, 6.0715]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.76, 63.037000000000006, 5.9185]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.610000000000001, 63.44200000000001, 5.9015]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.170000000000002, 67.078, 5.7485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0, 67.4805, 5.7315000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.38, 71.0895, 5.578500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.191, 71.4885, 5.5615000000000006]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.409, 75.06150000000001, 5.4085]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.2025, 75.456, 5.391500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([3.2675, 78.98400000000001, 5.238500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([3.0450000000000004, 79.37300000000002, 5.221500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([0.9750000000000001, 82.84700000000001, 5.068499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([0.7375, 83.23, 5.051499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([-1.4675, 86.65, 4.898499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-1.7195, 87.0265, 4.8815]) cube([0.4, 0.4, 0.1], center=true);
    translate([-4.0504999999999995, 90.3835, 4.7285]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-4.3165, 90.7525, 4.7115]) cube([0.4, 0.4, 0.1], center=true);
    translate([-6.7735, 94.0375, 4.5584999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-7.053000000000001, 94.398, 4.5415]) cube([0.4, 0.4, 0.1], center=true);
    translate([-9.626999999999999, 97.602, 4.3885000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-9.918999999999999, 97.953, 4.3715]) cube([0.4, 0.4, 0.1], center=true);
    translate([-12.600999999999999, 101.06700000000001, 4.218500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-12.905, 101.408, 4.2015]) cube([0.4, 0.4, 0.1], center=true);
    translate([-15.695, 104.432, 4.0485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-16.0105, 104.762, 4.0315]) cube([0.4, 0.4, 0.1], center=true);
    translate([-18.8995, 107.67800000000001, 3.8785000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-19.226, 107.99550000000002, 3.8615000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([-22.214, 110.7945, 3.7085]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-22.5505, 111.099, 3.6915]) cube([0.4, 0.4, 0.1], center=true);
    translate([-25.6195, 113.781, 3.5385]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-25.965, 114.07150000000001, 3.5215]) cube([0.4, 0.4, 0.1], center=true);
    translate([-29.115000000000002, 116.61850000000001, 3.3685]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-29.469, 116.894, 3.3515]) cube([0.4, 0.4, 0.1], center=true);
    translate([-32.690999999999995, 119.306, 3.1985]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-33.052499999999995, 119.56649999999999, 3.1814999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([-36.337500000000006, 121.84349999999999, 3.0285]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-36.706, 122.088, 3.0115]) cube([0.4, 0.4, 0.1], center=true);
    translate([-40.054, 124.212, 2.8585]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-40.429, 124.44000000000001, 2.8415]) cube([0.4, 0.4, 0.1], center=true);
    translate([-43.831, 126.42000000000002, 2.6885000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-44.212, 126.63150000000002, 2.6715000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([-47.668, 128.45850000000002, 2.5185]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-48.055, 128.6525, 2.5015]) cube([0.4, 0.4, 0.1], center=true);
    translate([-51.565, 130.3175, 2.3485]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-51.957499999999996, 130.494, 2.3314999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([-55.5125, 132.006, 2.1785]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-55.910000000000004, 132.165, 2.1615]) cube([0.4, 0.4, 0.1], center=true);
    translate([-59.510000000000005, 133.51500000000001, 2.0085]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-59.91250000000001, 133.656, 1.9915]) cube([0.4, 0.4, 0.1], center=true);
    translate([-63.557500000000005, 134.844, 1.8385]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-63.9645, 134.9665, 1.8215000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-67.6455, 135.9835, 1.6685]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-68.0565, 136.087, 1.6515]) cube([0.4, 0.4, 0.1], center=true);
    translate([-71.77350000000001, 136.933, 1.4985]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-72.1885, 137.01749999999998, 1.4815]) cube([0.4, 0.4, 0.1], center=true);
    translate([-75.9415, 137.6925, 1.3285000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-76.36000000000001, 137.75799999999998, 1.3115]) cube([0.4, 0.4, 0.1], center=true);
    translate([-80.14, 138.262, 1.1584999999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-80.5615, 138.308, 1.1415]) cube([0.4, 0.4, 0.1], center=true);
    translate([-84.3685, 138.632, 0.9885]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-84.793, 138.6585, 0.9715]) cube([0.4, 0.4, 0.1], center=true);
    translate([-88.62700000000001, 138.8115, 0.8185000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-89.054, 138.8185, 0.8015000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-92.906, 138.7915, 0.6485000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-93.33500000000001, 138.7785, 0.6315000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-97.205, 138.57150000000001, 0.4785]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-97.636, 138.5385, 0.4615]) cube([0.4, 0.4, 0.1], center=true);
    translate([-101.524, 138.1515, 0.3085]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-101.9565, 138.09799999999998, 0.29150000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([-105.8535, 137.52200000000002, 0.1385]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-106.2875, 137.44750000000002, 0.12350000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([-110.2025, 136.68249999999998, 0.006500000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-110.638, 136.58749999999998, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-114.56200000000001, 135.6425, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([-114.9985, 135.52700000000002, 0.0]) cube([0.4, 0.4, 0.1], center=true);
    translate([-118.93150000000001, 134.39300000000003, 0.0]) cube([0.4, 0.4, 0.1], center=true);
}

