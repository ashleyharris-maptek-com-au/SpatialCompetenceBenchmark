
hull() {
    translate([5.0, 5.0, 4.9]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 5.0, 3.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 5.0, 2.9000000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 5.0, 1.1]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 5.0, 0.9500000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 5.0, 0.05]) cube([0.4, 0.4, 0.1], center=true);
}

