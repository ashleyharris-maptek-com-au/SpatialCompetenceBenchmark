
translate([0, 0, 0]) cube([1, 1, 5.0]);

translate([1, 0, 0]) cube([1, 1, 4.600000003125467]);

translate([2, 0, 0]) cube([1, 1, 4.300000031754155]);

translate([3, 0, 0]) cube([1, 1, 4.200000516368375]);

translate([4, 0, 0]) cube([1, 1, 4.200000539853658]);

translate([5, 0, 0]) cube([1, 1, 4.10000187713407]);

translate([6, 0, 0]) cube([1, 1, 4.0000046510440725]);

translate([7, 0, 0]) cube([1, 1, 3.9000562907727483]);

translate([8, 0, 0]) cube([1, 1, 3.900057006366254]);

translate([9, 0, 0]) cube([1, 1, 3.9000607037283967]);

translate([10, 0, 0]) cube([1, 1, 4.00001552722847]);

translate([11, 0, 0]) cube([1, 1, 4.100009551325677]);

translate([12, 0, 0]) cube([1, 1, 4.200003864993151]);

translate([13, 0, 0]) cube([1, 1, 4.3]);

translate([14, 0, 0]) cube([1, 1, 4.5]);

translate([15, 0, 0]) cube([1, 1, 4.5]);

translate([16, 0, 0]) cube([1, 1, 4.4]);

translate([17, 0, 0]) cube([1, 1, 4.3]);

translate([18, 0, 0]) cube([1, 1, 4.2]);

translate([19, 0, 0]) cube([1, 1, 4.2]);

translate([20, 0, 0]) cube([1, 1, 4.3]);

translate([21, 0, 0]) cube([1, 1, 4.4]);

translate([22, 0, 0]) cube([1, 1, 4.7]);

translate([23, 0, 0]) cube([1, 1, 4.9]);

translate([24, 0, 0]) cube([1, 1, 5.0]);

translate([25, 0, 0]) cube([1, 1, 5.1]);

translate([26, 0, 0]) cube([1, 1, 5.2]);

translate([27, 0, 0]) cube([1, 1, 5.3]);

translate([28, 0, 0]) cube([1, 1, 5.4]);

translate([29, 0, 0]) cube([1, 1, 5.4]);

translate([30, 0, 0]) cube([1, 1, 5.4]);

translate([31, 0, 0]) cube([1, 1, 5.3]);

translate([32, 0, 0]) cube([1, 1, 5.1]);

translate([33, 0, 0]) cube([1, 1, 4.9]);

translate([34, 0, 0]) cube([1, 1, 4.7]);

translate([35, 0, 0]) cube([1, 1, 4.6]);

translate([36, 0, 0]) cube([1, 1, 4.4]);

translate([37, 0, 0]) cube([1, 1, 4.4]);

translate([38, 0, 0]) cube([1, 1, 4.3]);

translate([39, 0, 0]) cube([1, 1, 4.3]);

translate([40, 0, 0]) cube([1, 1, 4.3]);

translate([41, 0, 0]) cube([1, 1, 4.3]);

translate([42, 0, 0]) cube([1, 1, 4.4]);

translate([43, 0, 0]) cube([1, 1, 4.6]);

translate([44, 0, 0]) cube([1, 1, 4.6]);

translate([45, 0, 0]) cube([1, 1, 4.7]);

translate([46, 0, 0]) cube([1, 1, 4.8]);

translate([47, 0, 0]) cube([1, 1, 4.9]);

color([0,1,0])
translate([0, 1, 0]) cube([1, 1, 6]);

translate([1, 1, 0]) cube([1, 1, 5.000000000273067]);

translate([2, 1, 0]) cube([1, 1, 4.700000006912435]);

translate([3, 1, 0]) cube([1, 1, 4.500000053443211]);

translate([4, 1, 0]) cube([1, 1, 4.400000261052359]);

translate([5, 1, 0]) cube([1, 1, 4.300000928815689]);

translate([6, 1, 0]) cube([1, 1, 4.100002845656967]);

translate([7, 1, 0]) cube([1, 1, 4.000006302977472]);

translate([8, 1, 0]) cube([1, 1, 3.9000589680230813]);

translate([9, 1, 0]) cube([1, 1, 3.900065094267305]);

translate([10, 1, 0]) cube([1, 1, 3.900084238254119]);

translate([11, 1, 0]) cube([1, 1, 4.000052560711787]);

translate([12, 1, 0]) cube([1, 1, 4.100034345242717]);

translate([13, 1, 0]) cube([1, 1, 4.200015470273465]);

translate([14, 1, 0]) cube([1, 1, 4.3]);

translate([15, 1, 0]) cube([1, 1, 4.3]);

translate([16, 1, 0]) cube([1, 1, 4.2]);

translate([17, 1, 0]) cube([1, 1, 4.000095165448057]);

translate([18, 1, 0]) cube([1, 1, 3.9004134147908047]);

translate([19, 1, 0]) cube([1, 1, 3.90040846061283]);

translate([20, 1, 0]) cube([1, 1, 4.000037292988095]);

translate([21, 1, 0]) cube([1, 1, 4.100186480869797]);

translate([22, 1, 0]) cube([1, 1, 4.4]);

translate([23, 1, 0]) cube([1, 1, 4.5]);

translate([24, 1, 0]) cube([1, 1, 4.7]);

translate([25, 1, 0]) cube([1, 1, 4.8]);

translate([26, 1, 0]) cube([1, 1, 4.9]);

translate([27, 1, 0]) cube([1, 1, 5.0]);

translate([28, 1, 0]) cube([1, 1, 5.0]);

translate([29, 1, 0]) cube([1, 1, 5.1]);

translate([30, 1, 0]) cube([1, 1, 5.0]);

translate([31, 1, 0]) cube([1, 1, 4.9]);

translate([32, 1, 0]) cube([1, 1, 4.8]);

translate([33, 1, 0]) cube([1, 1, 4.6]);

translate([34, 1, 0]) cube([1, 1, 4.5]);

translate([35, 1, 0]) cube([1, 1, 4.4]);

translate([36, 1, 0]) cube([1, 1, 4.3]);

translate([37, 1, 0]) cube([1, 1, 4.2]);

translate([38, 1, 0]) cube([1, 1, 4.1]);

translate([39, 1, 0]) cube([1, 1, 4.0]);

translate([40, 1, 0]) cube([1, 1, 3.9]);

translate([41, 1, 0]) cube([1, 1, 3.9]);

translate([42, 1, 0]) cube([1, 1, 4.0]);

translate([43, 1, 0]) cube([1, 1, 4.1]);

translate([44, 1, 0]) cube([1, 1, 4.2]);

translate([45, 1, 0]) cube([1, 1, 4.3]);

translate([46, 1, 0]) cube([1, 1, 4.4]);

translate([47, 1, 0]) cube([1, 1, 4.5]);

color([0,1,0])
translate([0, 2, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 2, 0]) cube([1, 1, 6]);

translate([2, 2, 0]) cube([1, 1, 5.200000002503112]);

translate([3, 2, 0]) cube([1, 1, 4.900000032116427]);

translate([4, 2, 0]) cube([1, 1, 4.7000002258876705]);

translate([5, 2, 0]) cube([1, 1, 4.600000994309476]);

translate([6, 2, 0]) cube([1, 1, 4.400003163808978]);

translate([7, 2, 0]) cube([1, 1, 4.200008328034832]);

translate([8, 2, 0]) cube([1, 1, 4.100014532235332]);

translate([9, 2, 0]) cube([1, 1, 4.000034557612491]);

translate([10, 2, 0]) cube([1, 1, 4.100028809682303]);

translate([11, 2, 0]) cube([1, 1, 4.100048535550494]);

translate([12, 2, 0]) cube([1, 1, 4.200032579412225]);

translate([13, 2, 0]) cube([1, 1, 4.200026594029908]);

translate([14, 2, 0]) cube([1, 1, 4.200017174166424]);

translate([15, 2, 0]) cube([1, 1, 4.100146466527418]);

translate([16, 2, 0]) cube([1, 1, 4.000380665600064]);

translate([17, 2, 0]) cube([1, 1, 3.901075547437584]);

translate([18, 2, 0]) cube([1, 1, 3.807755868059108]);

translate([19, 2, 0]) cube([1, 1, 3.8077608484863927]);

translate([20, 2, 0]) cube([1, 1, 3.901386829017455]);

translate([21, 2, 0]) cube([1, 1, 3.9024261954029447]);

translate([22, 2, 0]) cube([1, 1, 4.1007459313523285]);

translate([23, 2, 0]) cube([1, 1, 4.200605653860991]);

translate([24, 2, 0]) cube([1, 1, 4.400018452708642]);

translate([25, 2, 0]) cube([1, 1, 4.400092268648081]);

translate([26, 2, 0]) cube([1, 1, 4.5]);

translate([27, 2, 0]) cube([1, 1, 4.6]);

translate([28, 2, 0]) cube([1, 1, 4.7]);

translate([29, 2, 0]) cube([1, 1, 4.7]);

translate([30, 2, 0]) cube([1, 1, 4.7]);

translate([31, 2, 0]) cube([1, 1, 4.6]);

translate([32, 2, 0]) cube([1, 1, 4.5]);

translate([33, 2, 0]) cube([1, 1, 4.4]);

translate([34, 2, 0]) cube([1, 1, 4.3]);

translate([35, 2, 0]) cube([1, 1, 4.2]);

translate([36, 2, 0]) cube([1, 1, 4.1]);

translate([37, 2, 0]) cube([1, 1, 4.000000000882071]);

translate([38, 2, 0]) cube([1, 1, 3.9]);

translate([39, 2, 0]) cube([1, 1, 3.8]);

translate([40, 2, 0]) cube([1, 1, 3.600000003378607]);

translate([41, 2, 0]) cube([1, 1, 3.6]);

translate([42, 2, 0]) cube([1, 1, 3.7]);

translate([43, 2, 0]) cube([1, 1, 3.9]);

translate([44, 2, 0]) cube([1, 1, 4.0]);

translate([45, 2, 0]) cube([1, 1, 4.0]);

translate([46, 2, 0]) cube([1, 1, 4.1]);

translate([47, 2, 0]) cube([1, 1, 4.2]);

color([0,1,0])
translate([0, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 3, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 3, 0]) cube([1, 1, 6]);

translate([3, 3, 0]) cube([1, 1, 5.400000012291161]);

translate([4, 3, 0]) cube([1, 1, 5.200000145605985]);

translate([5, 3, 0]) cube([1, 1, 5.00000093942478]);

translate([6, 3, 0]) cube([1, 1, 4.800003660628951]);

translate([7, 3, 0]) cube([1, 1, 4.600010229057156]);

translate([8, 3, 0]) cube([1, 1, 4.400024589247493]);

translate([9, 3, 0]) cube([1, 1, 4.400029520608305]);

translate([10, 3, 0]) cube([1, 1, 4.4000407845239575]);

translate([11, 3, 0]) cube([1, 1, 4.400047225938613]);

translate([12, 3, 0]) cube([1, 1, 4.3000760722638205]);

translate([13, 3, 0]) cube([1, 1, 4.300041950015581]);

translate([14, 3, 0]) cube([1, 1, 4.100568695373556]);

translate([15, 3, 0]) cube([1, 1, 4.001756863719152]);

translate([16, 3, 0]) cube([1, 1, 3.904773128443287]);

translate([17, 3, 0]) cube([1, 1, 3.808040832215006]);

translate([18, 3, 0]) cube([1, 1, 3.8077770144056506]);

translate([19, 3, 0]) cube([1, 1, 3.9012888650731123]);

translate([20, 3, 0]) cube([1, 1, 3.901986127443955]);

translate([21, 3, 0]) cube([1, 1, 3.903042706669373]);

translate([22, 3, 0]) cube([1, 1, 4.003870825108849]);

translate([23, 3, 0]) cube([1, 1, 4.103124005959654]);

translate([24, 3, 0]) cube([1, 1, 4.2024041705758535]);

translate([25, 3, 0]) cube([1, 1, 4.301208785803347]);

translate([26, 3, 0]) cube([1, 1, 4.400369086711603]);

translate([27, 3, 0]) cube([1, 1, 4.400523546977278]);

translate([28, 3, 0]) cube([1, 1, 4.5]);

translate([29, 3, 0]) cube([1, 1, 4.5]);

translate([30, 3, 0]) cube([1, 1, 4.4]);

translate([31, 3, 0]) cube([1, 1, 4.300023808146401]);

translate([32, 3, 0]) cube([1, 1, 4.30000476008026]);

translate([33, 3, 0]) cube([1, 1, 4.200000952016053]);

translate([34, 3, 0]) cube([1, 1, 4.1000001903238665]);

translate([35, 3, 0]) cube([1, 1, 4.000000037892068]);

translate([36, 3, 0]) cube([1, 1, 4.000000006214052]);

translate([37, 3, 0]) cube([1, 1, 3.9000000008606]);

translate([38, 3, 0]) cube([1, 1, 3.8]);

translate([39, 3, 0]) cube([1, 1, 3.6000000153384764]);

translate([40, 3, 0]) cube([1, 1, 3.5000050902300472]);

translate([41, 3, 0]) cube([1, 1, 3.400014721999437]);

translate([42, 3, 0]) cube([1, 1, 3.50000000083214]);

translate([43, 3, 0]) cube([1, 1, 3.7]);

translate([44, 3, 0]) cube([1, 1, 3.8]);

translate([45, 3, 0]) cube([1, 1, 3.9]);

translate([46, 3, 0]) cube([1, 1, 3.8]);

translate([47, 3, 0]) cube([1, 1, 3.8]);

translate([0, 4, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([1, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 4, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 4, 0]) cube([1, 1, 6]);

translate([5, 4, 0]) cube([1, 1, 5.400000654593749]);

translate([6, 4, 0]) cube([1, 1, 5.20000383972719]);

translate([7, 4, 0]) cube([1, 1, 5.000012873301816]);

translate([8, 4, 0]) cube([1, 1, 4.800030772981997]);

translate([9, 4, 0]) cube([1, 1, 4.800038678732635]);

translate([10, 4, 0]) cube([1, 1, 4.800040799493833]);

translate([11, 4, 0]) cube([1, 1, 4.700090006956547]);

translate([12, 4, 0]) cube([1, 1, 4.60011263355249]);

translate([13, 4, 0]) cube([1, 1, 4.400096746298175]);

translate([14, 4, 0]) cube([1, 1, 4.202092319123195]);

translate([15, 4, 0]) cube([1, 1, 4.004423908587663]);

translate([16, 4, 0]) cube([1, 1, 3.907663366980902]);

translate([17, 4, 0]) cube([1, 1, 4.001711653034063]);

translate([18, 4, 0]) cube([1, 1, 4.001220595710605]);

translate([19, 4, 0]) cube([1, 1, 4.10041050740466]);

translate([20, 4, 0]) cube([1, 1, 4.200358826017223]);

translate([21, 4, 0]) cube([1, 1, 4.101585645952931]);

translate([22, 4, 0]) cube([1, 1, 4.102786250137159]);

translate([23, 4, 0]) cube([1, 1, 4.202764991528521]);

translate([24, 4, 0]) cube([1, 1, 4.204289164600587]);

translate([25, 4, 0]) cube([1, 1, 4.302399358291958]);

translate([26, 4, 0]) cube([1, 1, 4.400936843031049]);

translate([27, 4, 0]) cube([1, 1, 4.400711640305662]);

translate([28, 4, 0]) cube([1, 1, 4.301046322153902]);

translate([29, 4, 0]) cube([1, 1, 4.300571445786317]);

translate([30, 4, 0]) cube([1, 1, 4.300095238682336]);

translate([31, 4, 0]) cube([1, 1, 4.200024760607636]);

translate([32, 4, 0]) cube([1, 1, 4.10007626558912]);

translate([33, 4, 0]) cube([1, 1, 3.900127986863339]);

translate([34, 4, 0]) cube([1, 1, 3.8000258298917613]);

translate([35, 4, 0]) cube([1, 1, 3.7000052112151196]);

translate([36, 4, 0]) cube([1, 1, 3.7000010496454383]);

translate([37, 4, 0]) cube([1, 1, 3.700000209579576]);

translate([38, 4, 0]) cube([1, 1, 3.600000077793907]);

translate([39, 4, 0]) cube([1, 1, 3.500020347752282]);

translate([40, 4, 0]) cube([1, 1, 3.4000390769376656]);

translate([41, 4, 0]) cube([1, 1, 3.300223303492707]);

translate([42, 4, 0]) cube([1, 1, 3.400003790730921]);

translate([43, 4, 0]) cube([1, 1, 3.600000008552362]);

translate([44, 4, 0]) cube([1, 1, 3.7]);

translate([45, 4, 0]) cube([1, 1, 3.8]);

translate([46, 4, 0]) cube([1, 1, 3.7]);

translate([47, 4, 0]) cube([1, 1, 3.60000005586153]);

translate([0, 5, 0]) cube([1, 1, 7.0]);

translate([1, 5, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 5, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 5, 0]) cube([1, 1, 6]);

translate([7, 5, 0]) cube([1, 1, 5.300015349276167]);

translate([8, 5, 0]) cube([1, 1, 5.200042249320665]);

translate([9, 5, 0]) cube([1, 1, 5.200043374944327]);

translate([10, 5, 0]) cube([1, 1, 5.100075926796774]);

translate([11, 5, 0]) cube([1, 1, 5.000087122139529]);

translate([12, 5, 0]) cube([1, 1, 4.800246189706961]);

translate([13, 5, 0]) cube([1, 1, 4.600221657511832]);

translate([14, 5, 0]) cube([1, 1, 4.303755688643988]);

translate([15, 5, 0]) cube([1, 1, 4.204966552615016]);

translate([16, 5, 0]) cube([1, 1, 4.106091272447096]);

translate([17, 5, 0]) cube([1, 1, 4.2022763137138694]);

translate([18, 5, 0]) cube([1, 1, 4.300965578376924]);

translate([19, 5, 0]) cube([1, 1, 4.400455088595536]);

translate([20, 5, 0]) cube([1, 1, 4.500273048024954]);

translate([21, 5, 0]) cube([1, 1, 4.40142482165419]);

translate([22, 5, 0]) cube([1, 1, 4.402233123131553]);

translate([23, 5, 0]) cube([1, 1, 4.403278172708018]);

translate([24, 5, 0]) cube([1, 1, 4.404136008708296]);

translate([25, 5, 0]) cube([1, 1, 4.502462325987065]);

translate([26, 5, 0]) cube([1, 1, 4.501503527396616]);

translate([27, 5, 0]) cube([1, 1, 4.401589871845355]);

translate([28, 5, 0]) cube([1, 1, 4.301239484081261]);

translate([29, 5, 0]) cube([1, 1, 4.20188771125329]);

translate([30, 5, 0]) cube([1, 1, 4.101384793105115]);

translate([31, 5, 0]) cube([1, 1, 4.100250795827016]);

translate([32, 5, 0]) cube([1, 1, 3.9004297938384234]);

translate([33, 5, 0]) cube([1, 1, 3.7004519005076792]);

translate([34, 5, 0]) cube([1, 1, 3.6003792406518644]);

translate([35, 5, 0]) cube([1, 1, 3.500090936493555]);

translate([36, 5, 0]) cube([1, 1, 3.500085999138728]);

translate([37, 5, 0]) cube([1, 1, 3.600000178767291]);

translate([38, 5, 0]) cube([1, 1, 3.5001016585904887]);

translate([39, 5, 0]) cube([1, 1, 3.400169942634475]);

translate([40, 5, 0]) cube([1, 1, 3.300243994641187]);

translate([41, 5, 0]) cube([1, 1, 3.3002216211156497]);

translate([42, 5, 0]) cube([1, 1, 3.400001871164068]);

translate([43, 5, 0]) cube([1, 1, 3.5000003165512372]);

translate([44, 5, 0]) cube([1, 1, 3.6000000460427923]);

translate([45, 5, 0]) cube([1, 1, 3.7]);

translate([46, 5, 0]) cube([1, 1, 3.6000001135179707]);

translate([47, 5, 0]) cube([1, 1, 3.500001052463169]);

translate([0, 6, 0]) cube([1, 1, 7.2]);

translate([1, 6, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([2, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 6, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 6, 0]) cube([1, 1, 6]);

translate([8, 6, 0]) cube([1, 1, 5.400058956460194]);

translate([9, 6, 0]) cube([1, 1, 5.40007973953071]);

translate([10, 6, 0]) cube([1, 1, 5.400079517672457]);

translate([11, 6, 0]) cube([1, 1, 5.200177007264525]);

translate([12, 6, 0]) cube([1, 1, 5.000161968397746]);

translate([13, 6, 0]) cube([1, 1, 4.800839981545565]);

translate([14, 6, 0]) cube([1, 1, 4.506050320108984]);

translate([15, 6, 0]) cube([1, 1, 4.407814050015327]);

translate([16, 6, 0]) cube([1, 1, 4.406499387078453]);

translate([17, 6, 0]) cube([1, 1, 4.502808787959445]);

translate([18, 6, 0]) cube([1, 1, 4.6011078174713544]);

translate([19, 6, 0]) cube([1, 1, 4.80045620010597]);

translate([20, 6, 0]) cube([1, 1, 4.80043837897903]);

translate([21, 6, 0]) cube([1, 1, 4.800743710949111]);

translate([22, 6, 0]) cube([1, 1, 4.703137307708934]);

translate([23, 6, 0]) cube([1, 1, 4.704847244299192]);

translate([24, 6, 0]) cube([1, 1, 4.7054948681697715]);

translate([25, 6, 0]) cube([1, 1, 4.704683954479921]);

translate([26, 6, 0]) cube([1, 1, 4.603235013641424]);

translate([27, 6, 0]) cube([1, 1, 4.404209810088151]);

translate([28, 6, 0]) cube([1, 1, 4.204598363865363]);

translate([29, 6, 0]) cube([1, 1, 4.102960024774695]);

translate([30, 6, 0]) cube([1, 1, 4.002920583869943]);

translate([31, 6, 0]) cube([1, 1, 3.901797157254068]);

translate([32, 6, 0]) cube([1, 1, 3.8011477337823156]);

translate([33, 6, 0]) cube([1, 1, 3.6009060417257435]);

translate([34, 6, 0]) cube([1, 1, 3.401144588474575]);

translate([35, 6, 0]) cube([1, 1, 3.4009693008004747]);

translate([36, 6, 0]) cube([1, 1, 3.4011741582821866]);

translate([37, 6, 0]) cube([1, 1, 3.5002455202427227]);

translate([38, 6, 0]) cube([1, 1, 3.5002413644342845]);

translate([39, 6, 0]) cube([1, 1, 3.4003474510205307]);

translate([40, 6, 0]) cube([1, 1, 3.3003635386697168]);

translate([41, 6, 0]) cube([1, 1, 3.2022548239479858]);

translate([42, 6, 0]) cube([1, 1, 3.300236217997957]);

translate([43, 6, 0]) cube([1, 1, 3.4000053689876073]);

translate([44, 6, 0]) cube([1, 1, 3.500001529677839]);

translate([45, 6, 0]) cube([1, 1, 3.600000231485698]);

translate([46, 6, 0]) cube([1, 1, 3.6000002369500543]);

translate([47, 6, 0]) cube([1, 1, 3.50000106986062]);

translate([0, 7, 0]) cube([1, 1, 7.4]);

translate([1, 7, 0]) cube([1, 1, 7.0]);

translate([2, 7, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 7, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 7, 0]) cube([1, 1, 6]);

translate([11, 7, 0]) cube([1, 1, 5.400172265906626]);

translate([12, 7, 0]) cube([1, 1, 5.2005637335971695]);

translate([13, 7, 0]) cube([1, 1, 4.904279062078119]);

translate([14, 7, 0]) cube([1, 1, 4.7091109521559975]);

translate([15, 7, 0]) cube([1, 1, 4.609749627670543]);

translate([16, 7, 0]) cube([1, 1, 4.608330065975013]);

translate([17, 7, 0]) cube([1, 1, 4.803124303975645]);

translate([18, 7, 0]) cube([1, 1, 4.9014817540641085]);

translate([19, 7, 0]) cube([1, 1, 5.10047683077505]);

translate([20, 7, 0]) cube([1, 1, 5.100312734226724]);

translate([21, 7, 0]) cube([1, 1, 5.100311971523367]);

translate([22, 7, 0]) cube([1, 1, 5.003755514341069]);

translate([23, 7, 0]) cube([1, 1, 5.005476800231957]);

translate([24, 7, 0]) cube([1, 1, 4.911619184546395]);

translate([25, 7, 0]) cube([1, 1, 4.906743890154428]);

translate([26, 7, 0]) cube([1, 1, 4.707982242474488]);

translate([27, 7, 0]) cube([1, 1, 4.507738961416314]);

translate([28, 7, 0]) cube([1, 1, 4.207074569705027]);

translate([29, 7, 0]) cube([1, 1, 4.005199015860991]);

translate([30, 7, 0]) cube([1, 1, 3.9044296208368814]);

translate([31, 7, 0]) cube([1, 1, 3.803260930345261]);

translate([32, 7, 0]) cube([1, 1, 3.7025007891563257]);

translate([33, 7, 0]) cube([1, 1, 3.5024295113344395]);

translate([34, 7, 0]) cube([1, 1, 3.3481436980467785]);

translate([35, 7, 0]) cube([1, 1, 3.3481477642472193]);

translate([36, 7, 0]) cube([1, 1, 3.401888539718707]);

translate([37, 7, 0]) cube([1, 1, 3.5006042345973896]);

translate([38, 7, 0]) cube([1, 1, 3.5007400055960245]);

translate([39, 7, 0]) cube([1, 1, 3.4007781217074875]);

translate([40, 7, 0]) cube([1, 1, 3.3006033952106235]);

translate([41, 7, 0]) cube([1, 1, 3.3003356395172574]);

translate([42, 7, 0]) cube([1, 1, 3.3002485506437025]);

translate([43, 7, 0]) cube([1, 1, 3.4000145090773994]);

translate([44, 7, 0]) cube([1, 1, 3.500005096416679]);

translate([45, 7, 0]) cube([1, 1, 3.600000749548177]);

translate([46, 7, 0]) cube([1, 1, 3.600000505920007]);

translate([47, 7, 0]) cube([1, 1, 3.500001262671447]);

translate([0, 8, 0]) cube([1, 1, 7.5]);

translate([1, 8, 0]) cube([1, 1, 7.2]);

translate([2, 8, 0]) cube([1, 1, 6.9]);

translate([3, 8, 0]) cube([1, 1, 6.7]);

translate([4, 8, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([5, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 8, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 8, 0]) cube([1, 1, 6]);

translate([12, 8, 0]) cube([1, 1, 5.302712983288366]);

translate([13, 8, 0]) cube([1, 1, 5.106569947945521]);

translate([14, 8, 0]) cube([1, 1, 4.909472185921244]);

translate([15, 8, 0]) cube([1, 1, 4.815282631601815]);

translate([16, 8, 0]) cube([1, 1, 4.907815323736826]);

translate([17, 8, 0]) cube([1, 1, 5.10441542421573]);

translate([18, 8, 0]) cube([1, 1, 5.20190901890039]);

translate([19, 8, 0]) cube([1, 1, 5.400607499467493]);

color([0,1,0])
translate([20, 8, 0]) cube([1, 1, 6]);

translate([21, 8, 0]) cube([1, 1, 5.400285027878012]);

translate([22, 8, 0]) cube([1, 1, 5.401219467332632]);

translate([23, 8, 0]) cube([1, 1, 5.311215857765383]);

translate([24, 8, 0]) cube([1, 1, 5.216938416983407]);

translate([25, 8, 0]) cube([1, 1, 5.118185297479003]);

translate([26, 8, 0]) cube([1, 1, 4.818977053390164]);

translate([27, 8, 0]) cube([1, 1, 4.514639702973704]);

translate([28, 8, 0]) cube([1, 1, 4.211362127331526]);

translate([29, 8, 0]) cube([1, 1, 3.9110684871959673]);

translate([30, 8, 0]) cube([1, 1, 3.807157295016707]);

translate([31, 8, 0]) cube([1, 1, 3.7062981313217533]);

translate([32, 8, 0]) cube([1, 1, 3.6075930004491488]);

translate([33, 8, 0]) cube([1, 1, 3.436290027496131]);

translate([34, 8, 0]) cube([1, 1, 3.348390998865264]);

translate([35, 8, 0]) cube([1, 1, 3.3483820709827965]);

translate([36, 8, 0]) cube([1, 1, 3.4056516432126687]);

translate([37, 8, 0]) cube([1, 1, 3.5022871626070597]);

translate([38, 8, 0]) cube([1, 1, 3.6010243609410364]);

translate([39, 8, 0]) cube([1, 1, 3.6006754407233346]);

translate([40, 8, 0]) cube([1, 1, 3.5002763085213204]);

translate([41, 8, 0]) cube([1, 1, 3.5000901612495188]);

translate([42, 8, 0]) cube([1, 1, 3.5000328579366746]);

translate([43, 8, 0]) cube([1, 1, 3.5000158730939246]);

translate([44, 8, 0]) cube([1, 1, 3.6000026598151873]);

translate([45, 8, 0]) cube([1, 1, 3.700000941241515]);

translate([46, 8, 0]) cube([1, 1, 3.7000005835566454]);

translate([47, 8, 0]) cube([1, 1, 3.600000798041028]);

translate([0, 9, 0]) cube([1, 1, 7.7]);

translate([1, 9, 0]) cube([1, 1, 7.4]);

translate([2, 9, 0]) cube([1, 1, 7.1]);

translate([3, 9, 0]) cube([1, 1, 7.0]);

translate([4, 9, 0]) cube([1, 1, 6.8]);

translate([5, 9, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([6, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 9, 0]) cube([1, 1, 6]);

translate([13, 9, 0]) cube([1, 1, 5.306350350745056]);

translate([14, 9, 0]) cube([1, 1, 5.115197708951666]);

translate([15, 9, 0]) cube([1, 1, 5.116878353921025]);

translate([16, 9, 0]) cube([1, 1, 5.211766957202135]);

translate([17, 9, 0]) cube([1, 1, 5.306015883345235]);

color([0,1,0])
translate([18, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 9, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 9, 0]) cube([1, 1, 6]);

translate([24, 9, 0]) cube([1, 1, 5.347747683696412]);

translate([25, 9, 0]) cube([1, 1, 5.154584419199681]);

translate([26, 9, 0]) cube([1, 1, 4.830906140059633]);

translate([27, 9, 0]) cube([1, 1, 4.521869584091906]);

translate([28, 9, 0]) cube([1, 1, 4.216670273954348]);

translate([29, 9, 0]) cube([1, 1, 3.9150893556902147]);

translate([30, 9, 0]) cube([1, 1, 3.716642816740765]);

translate([31, 9, 0]) cube([1, 1, 3.6259051549377035]);

translate([32, 9, 0]) cube([1, 1, 3.547697566006636]);

translate([33, 9, 0]) cube([1, 1, 3.5315029942928065]);

translate([34, 9, 0]) cube([1, 1, 3.5171462251758743]);

translate([35, 9, 0]) cube([1, 1, 3.5116845181519807]);

translate([36, 9, 0]) cube([1, 1, 3.6050726414494325]);

translate([37, 9, 0]) cube([1, 1, 3.7026844227484474]);

translate([38, 9, 0]) cube([1, 1, 3.702304531557368]);

translate([39, 9, 0]) cube([1, 1, 3.8005487486617033]);

translate([40, 9, 0]) cube([1, 1, 3.9001080391797465]);

translate([41, 9, 0]) cube([1, 1, 3.900048448935911]);

translate([42, 9, 0]) cube([1, 1, 3.800017996191216]);

translate([43, 9, 0]) cube([1, 1, 3.8000076156146134]);

translate([44, 9, 0]) cube([1, 1, 3.80000325991485]);

translate([45, 9, 0]) cube([1, 1, 3.8000014589073894]);

translate([46, 9, 0]) cube([1, 1, 3.800000601797527]);

translate([47, 9, 0]) cube([1, 1, 3.7000008272121185]);

translate([0, 10, 0]) cube([1, 1, 7.9]);

translate([1, 10, 0]) cube([1, 1, 7.6]);

translate([2, 10, 0]) cube([1, 1, 7.4]);

translate([3, 10, 0]) cube([1, 1, 7.2]);

translate([4, 10, 0]) cube([1, 1, 7.1]);

translate([5, 10, 0]) cube([1, 1, 6.9]);

translate([6, 10, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([7, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 10, 0]) cube([1, 1, 6]);

translate([14, 10, 0]) cube([1, 1, 5.4139477159489395]);

translate([15, 10, 0]) cube([1, 1, 5.327653133894865]);

translate([16, 10, 0]) cube([1, 1, 5.416436188219395]);

color([0,1,0])
translate([17, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 10, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 10, 0]) cube([1, 1, 6]);

translate([24, 10, 0]) cube([1, 1, 4.354936070447505]);

translate([25, 10, 0]) cube([1, 1, 5.15768860327775]);

translate([26, 10, 0]) cube([1, 1, 4.838355886821813]);

translate([27, 10, 0]) cube([1, 1, 4.529608303480603]);

translate([28, 10, 0]) cube([1, 1, 4.222137374828483]);

translate([29, 10, 0]) cube([1, 1, 4.014155614520104]);

translate([30, 10, 0]) cube([1, 1, 3.8191005192736402]);

translate([31, 10, 0]) cube([1, 1, 3.6368977259190247]);

translate([32, 10, 0]) cube([1, 1, 3.631063310447444]);

translate([33, 10, 0]) cube([1, 1, 3.6271799971303667]);

translate([34, 10, 0]) cube([1, 1, 3.7147959195532962]);

translate([35, 10, 0]) cube([1, 1, 3.8107600782035034]);

translate([36, 10, 0]) cube([1, 1, 3.9062929304402423]);

translate([37, 10, 0]) cube([1, 1, 3.9056257858759538]);

translate([38, 10, 0]) cube([1, 1, 4.0020361413527]);

translate([39, 10, 0]) cube([1, 1, 4.100474725836529]);

translate([40, 10, 0]) cube([1, 1, 4.200124846868585]);

translate([41, 10, 0]) cube([1, 1, 4.300022748419485]);

translate([42, 10, 0]) cube([1, 1, 4.200012526235614]);

translate([43, 10, 0]) cube([1, 1, 4.100005403297364]);

translate([44, 10, 0]) cube([1, 1, 4.100002438164515]);

translate([45, 10, 0]) cube([1, 1, 4.0000012194654]);

translate([46, 10, 0]) cube([1, 1, 3.9000005717550192]);

translate([47, 10, 0]) cube([1, 1, 3.800000725775887]);

translate([0, 11, 0]) cube([1, 1, 8.0]);

translate([1, 11, 0]) cube([1, 1, 7.7]);

translate([2, 11, 0]) cube([1, 1, 7.5]);

translate([3, 11, 0]) cube([1, 1, 7.3]);

translate([4, 11, 0]) cube([1, 1, 7.2]);

translate([5, 11, 0]) cube([1, 1, 7.0]);

translate([6, 11, 0]) cube([1, 1, 6.8]);

translate([7, 11, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([8, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 11, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 11, 0]) cube([1, 1, 6]);

translate([24, 11, 0]) cube([1, 1, 5.408787956117936]);

translate([25, 11, 0]) cube([1, 1, 5.15211443750394]);

translate([26, 11, 0]) cube([1, 1, 4.836340011620924]);

translate([27, 11, 0]) cube([1, 1, 4.6212643295121945]);

translate([28, 11, 0]) cube([1, 1, 4.418600326440433]);

translate([29, 11, 0]) cube([1, 1, 4.213370099815531]);

translate([30, 11, 0]) cube([1, 1, 3.922429669317536]);

translate([31, 11, 0]) cube([1, 1, 3.8297241638978523]);

translate([32, 11, 0]) cube([1, 1, 3.8322933224604383]);

translate([33, 11, 0]) cube([1, 1, 3.9260900197961597]);

translate([34, 11, 0]) cube([1, 1, 4.12274483176321]);

translate([35, 11, 0]) cube([1, 1, 4.2143846723014455]);

translate([36, 11, 0]) cube([1, 1, 4.210377962602633]);

translate([37, 11, 0]) cube([1, 1, 4.207557824302497]);

translate([38, 11, 0]) cube([1, 1, 4.30167542697574]);

translate([39, 11, 0]) cube([1, 1, 4.4004727369121195]);

translate([40, 11, 0]) cube([1, 1, 4.500100619305995]);

translate([41, 11, 0]) cube([1, 1, 4.5000281317639415]);

translate([42, 11, 0]) cube([1, 1, 4.500007739823114]);

translate([43, 11, 0]) cube([1, 1, 4.400004012527373]);

translate([44, 11, 0]) cube([1, 1, 4.3000022572730865]);

translate([45, 11, 0]) cube([1, 1, 4.200000998991523]);

translate([46, 11, 0]) cube([1, 1, 4.100000403883155]);

translate([47, 11, 0]) cube([1, 1, 4.000000237216616]);

translate([0, 12, 0]) cube([1, 1, 7.9]);

translate([1, 12, 0]) cube([1, 1, 7.6]);

translate([2, 12, 0]) cube([1, 1, 7.4]);

translate([3, 12, 0]) cube([1, 1, 7.3]);

translate([4, 12, 0]) cube([1, 1, 7.1]);

translate([5, 12, 0]) cube([1, 1, 7.0]);

translate([6, 12, 0]) cube([1, 1, 6.8]);

translate([7, 12, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 12, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 12, 0]) cube([1, 1, 6]);

translate([24, 12, 0]) cube([1, 1, 5.409886713849653]);

translate([25, 12, 0]) cube([1, 1, 5.118551932988547]);

translate([26, 12, 0]) cube([1, 1, 4.914579082625649]);

translate([27, 12, 0]) cube([1, 1, 4.717046672171729]);

translate([28, 12, 0]) cube([1, 1, 4.517648079912251]);

translate([29, 12, 0]) cube([1, 1, 4.4127606052830926]);

translate([30, 12, 0]) cube([1, 1, 4.1182485569450975]);

translate([31, 12, 0]) cube([1, 1, 4.031183807595881]);

translate([32, 12, 0]) cube([1, 1, 4.131201649482286]);

translate([33, 12, 0]) cube([1, 1, 4.238163970791153]);

translate([34, 12, 0]) cube([1, 1, 4.438339650855815]);

translate([35, 12, 0]) cube([1, 1, 4.622835870006085]);

translate([36, 12, 0]) cube([1, 1, 4.614991428465505]);

translate([37, 12, 0]) cube([1, 1, 4.605665725608682]);

translate([38, 12, 0]) cube([1, 1, 4.6016739882230455]);

translate([39, 12, 0]) cube([1, 1, 4.600564689379397]);

translate([40, 12, 0]) cube([1, 1, 4.7000243884491635]);

translate([41, 12, 0]) cube([1, 1, 4.700011611847724]);

translate([42, 12, 0]) cube([1, 1, 4.600005762310153]);

translate([43, 12, 0]) cube([1, 1, 4.500004763961396]);

translate([44, 12, 0]) cube([1, 1, 4.500001796756972]);

translate([45, 12, 0]) cube([1, 1, 4.500000713369169]);

translate([46, 12, 0]) cube([1, 1, 4.400000228309826]);

translate([47, 12, 0]) cube([1, 1, 4.300000080104724]);

translate([0, 13, 0]) cube([1, 1, 7.9]);

translate([1, 13, 0]) cube([1, 1, 7.6]);

translate([2, 13, 0]) cube([1, 1, 7.3]);

translate([3, 13, 0]) cube([1, 1, 7.2]);

translate([4, 13, 0]) cube([1, 1, 7.0]);

translate([5, 13, 0]) cube([1, 1, 6.9]);

translate([6, 13, 0]) cube([1, 1, 6.7]);

translate([7, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([8, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 13, 0]) cube([1, 1, 6]);

translate([10, 13, 0]) cube([1, 1, 6.6]);

translate([11, 13, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([12, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 13, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 13, 0]) cube([1, 1, 6]);

translate([25, 13, 0]) cube([1, 1, 5.203366620672482]);

translate([26, 13, 0]) cube([1, 1, 4.912835689266196]);

translate([27, 13, 0]) cube([1, 1, 4.812356259858378]);

translate([28, 13, 0]) cube([1, 1, 4.711123356276421]);

translate([29, 13, 0]) cube([1, 1, 4.608801707542412]);

translate([30, 13, 0]) cube([1, 1, 4.414408918237591]);

translate([31, 13, 0]) cube([1, 1, 4.323652900636171]);

translate([32, 13, 0]) cube([1, 1, 4.337223207633664]);

translate([33, 13, 0]) cube([1, 1, 4.556968170926766]);

translate([34, 13, 0]) cube([1, 1, 4.8582888291376065]);

translate([35, 13, 0]) cube([1, 1, 4.9536053915127125]);

translate([36, 13, 0]) cube([1, 1, 4.910732935323244]);

translate([37, 13, 0]) cube([1, 1, 4.9021595612101]);

translate([38, 13, 0]) cube([1, 1, 4.900444717011625]);

translate([39, 13, 0]) cube([1, 1, 4.900099869056689]);

translate([40, 13, 0]) cube([1, 1, 4.900027320761158]);

translate([41, 13, 0]) cube([1, 1, 4.800010750741804]);

translate([42, 13, 0]) cube([1, 1, 4.800003989822404]);

translate([43, 13, 0]) cube([1, 1, 4.700002459488342]);

translate([44, 13, 0]) cube([1, 1, 4.700001344195471]);

translate([45, 13, 0]) cube([1, 1, 4.700000416139662]);

translate([46, 13, 0]) cube([1, 1, 4.8000000102178]);

translate([47, 13, 0]) cube([1, 1, 4.700000002696413]);

translate([0, 14, 0]) cube([1, 1, 7.9]);

translate([1, 14, 0]) cube([1, 1, 7.6]);

translate([2, 14, 0]) cube([1, 1, 7.3]);

translate([3, 14, 0]) cube([1, 1, 7.1]);

translate([4, 14, 0]) cube([1, 1, 6.9]);

translate([5, 14, 0]) cube([1, 1, 6.7]);

translate([6, 14, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([7, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 14, 0]) cube([1, 1, 6]);

translate([9, 14, 0]) cube([1, 1, 6.6]);

translate([10, 14, 0]) cube([1, 1, 6.7]);

translate([11, 14, 0]) cube([1, 1, 6.7]);

translate([12, 14, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([13, 14, 0]) cube([1, 1, 6]);

translate([14, 14, 0]) cube([1, 1, 5.127290688668324]);

color([0,1,0])
translate([15, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 14, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 14, 0]) cube([1, 1, 6]);

translate([25, 14, 0]) cube([1, 1, 5.205782869422805]);

translate([26, 14, 0]) cube([1, 1, 5.009004181351565]);

translate([27, 14, 0]) cube([1, 1, 4.912584380352743]);

translate([28, 14, 0]) cube([1, 1, 4.811966953885734]);

translate([29, 14, 0]) cube([1, 1, 4.711468748512539]);

translate([30, 14, 0]) cube([1, 1, 4.614196479578983]);

translate([31, 14, 0]) cube([1, 1, 4.525471949825636]);

translate([32, 14, 0]) cube([1, 1, 4.626257292117013]);

translate([33, 14, 0]) cube([1, 1, 4.854472386789885]);

translate([34, 14, 0]) cube([1, 1, 4.049076170231888]);

translate([35, 14, 0]) cube([1, 1, 5.300016587869095]);

translate([36, 14, 0]) cube([1, 1, 5.300021189228246]);

translate([37, 14, 0]) cube([1, 1, 5.30002012875382]);

translate([38, 14, 0]) cube([1, 1, 5.200023490347353]);

translate([39, 14, 0]) cube([1, 1, 5.100022712633946]);

translate([40, 14, 0]) cube([1, 1, 5.100013808209616]);

translate([41, 14, 0]) cube([1, 1, 5.000008516945583]);

translate([42, 14, 0]) cube([1, 1, 4.900004107792667]);

translate([43, 14, 0]) cube([1, 1, 4.800003950643892]);

translate([44, 14, 0]) cube([1, 1, 4.900000249799719]);

translate([45, 14, 0]) cube([1, 1, 5.00000006182976]);

translate([46, 14, 0]) cube([1, 1, 5.1]);

translate([47, 14, 0]) cube([1, 1, 5.1]);

translate([0, 15, 0]) cube([1, 1, 8.0]);

translate([1, 15, 0]) cube([1, 1, 7.7]);

translate([2, 15, 0]) cube([1, 1, 7.4]);

translate([3, 15, 0]) cube([1, 1, 7.1]);

translate([4, 15, 0]) cube([1, 1, 6.8]);

translate([5, 15, 0]) cube([1, 1, 6.7]);

translate([6, 15, 0]) cube([1, 1, 6.6]);

translate([7, 15, 0]) cube([1, 1, 6.6]);

translate([8, 15, 0]) cube([1, 1, 6.7]);

translate([9, 15, 0]) cube([1, 1, 6.8]);

translate([10, 15, 0]) cube([1, 1, 6.9]);

translate([11, 15, 0]) cube([1, 1, 6.8]);

translate([12, 15, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([13, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 15, 0]) cube([1, 1, 6]);

translate([25, 15, 0]) cube([1, 1, 5.217328432600817]);

translate([26, 15, 0]) cube([1, 1, 5.022985015230439]);

translate([27, 15, 0]) cube([1, 1, 4.924618880836943]);

translate([28, 15, 0]) cube([1, 1, 4.912959168726953]);

translate([29, 15, 0]) cube([1, 1, 4.812022876032621]);

translate([30, 15, 0]) cube([1, 1, 4.717596368525763]);

translate([31, 15, 0]) cube([1, 1, 4.631234601526263]);

translate([32, 15, 0]) cube([1, 1, 4.812603059600937]);

translate([33, 15, 0]) cube([1, 1, 5.106692718118834]);

translate([34, 15, 0]) cube([1, 1, 5.40001825721802]);

color([0,1,0])
translate([35, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 15, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 15, 0]) cube([1, 1, 6]);

translate([39, 15, 0]) cube([1, 1, 5.400028290337028]);

translate([40, 15, 0]) cube([1, 1, 5.300017632267673]);

translate([41, 15, 0]) cube([1, 1, 5.200008261530168]);

translate([42, 15, 0]) cube([1, 1, 5.1000028833636435]);

translate([43, 15, 0]) cube([1, 1, 5.100000877123941]);

translate([44, 15, 0]) cube([1, 1, 5.100000308106468]);

translate([45, 15, 0]) cube([1, 1, 5.300000001938419]);

translate([46, 15, 0]) cube([1, 1, 5.4]);

translate([47, 15, 0]) cube([1, 1, 5.4]);

translate([0, 16, 0]) cube([1, 1, 8.1]);

translate([1, 16, 0]) cube([1, 1, 7.8]);

translate([2, 16, 0]) cube([1, 1, 7.5]);

translate([3, 16, 0]) cube([1, 1, 7.1]);

translate([4, 16, 0]) cube([1, 1, 6.9]);

translate([5, 16, 0]) cube([1, 1, 6.8]);

translate([6, 16, 0]) cube([1, 1, 6.8]);

translate([7, 16, 0]) cube([1, 1, 6.8]);

translate([8, 16, 0]) cube([1, 1, 7.0]);

translate([9, 16, 0]) cube([1, 1, 7.1]);

translate([10, 16, 0]) cube([1, 1, 7.1]);

translate([11, 16, 0]) cube([1, 1, 6.9]);

translate([12, 16, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([13, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 16, 0]) cube([1, 1, 6]);

translate([25, 16, 0]) cube([1, 1, 5.245866693899005]);

translate([26, 16, 0]) cube([1, 1, 5.041641521492269]);

translate([27, 16, 0]) cube([1, 1, 5.022907693409479]);

translate([28, 16, 0]) cube([1, 1, 4.924927821013151]);

translate([29, 16, 0]) cube([1, 1, 4.825124651679857]);

translate([30, 16, 0]) cube([1, 1, 4.733584468601386]);

translate([31, 16, 0]) cube([1, 1, 4.732401204303815]);

translate([32, 16, 0]) cube([1, 1, 4.901965685868255]);

translate([33, 16, 0]) cube([1, 1, 5.2000766669564005]);

color([0,1,0])
translate([34, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 16, 0]) cube([1, 1, 6]);

translate([43, 16, 0]) cube([1, 1, 5.400000344061242]);

color([0,1,0])
translate([44, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 16, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 16, 0]) cube([1, 1, 6]);

translate([0, 17, 0]) cube([1, 1, 8.2]);

translate([1, 17, 0]) cube([1, 1, 7.9]);

translate([2, 17, 0]) cube([1, 1, 7.5]);

translate([3, 17, 0]) cube([1, 1, 7.2]);

translate([4, 17, 0]) cube([1, 1, 7.0]);

translate([5, 17, 0]) cube([1, 1, 7.0]);

translate([6, 17, 0]) cube([1, 1, 7.0]);

translate([7, 17, 0]) cube([1, 1, 7.1]);

translate([8, 17, 0]) cube([1, 1, 7.3]);

translate([9, 17, 0]) cube([1, 1, 7.3]);

translate([10, 17, 0]) cube([1, 1, 7.2]);

translate([11, 17, 0]) cube([1, 1, 7.0]);

translate([12, 17, 0]) cube([1, 1, 6.8]);

translate([13, 17, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([14, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 17, 0]) cube([1, 1, 6]);

translate([24, 17, 0]) cube([1, 1, 4.995765496952046]);

translate([25, 17, 0]) cube([1, 1, 5.346921146977127]);

translate([26, 17, 0]) cube([1, 1, 5.14145800049743]);

translate([27, 17, 0]) cube([1, 1, 5.044542672427559]);

translate([28, 17, 0]) cube([1, 1, 4.945909443931039]);

translate([29, 17, 0]) cube([1, 1, 4.923971978931921]);

translate([30, 17, 0]) cube([1, 1, 4.824385196652414]);

translate([31, 17, 0]) cube([1, 1, 4.822681577405357]);

translate([32, 17, 0]) cube([1, 1, 4.903974985884555]);

translate([33, 17, 0]) cube([1, 1, 5.200199431310099]);

color([0,1,0])
translate([34, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 17, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 17, 0]) cube([1, 1, 6]);

translate([0, 18, 0]) cube([1, 1, 8.2]);

translate([1, 18, 0]) cube([1, 1, 7.9]);

translate([2, 18, 0]) cube([1, 1, 7.6]);

translate([3, 18, 0]) cube([1, 1, 7.3]);

translate([4, 18, 0]) cube([1, 1, 7.2]);

translate([5, 18, 0]) cube([1, 1, 7.2]);

translate([6, 18, 0]) cube([1, 1, 7.3]);

translate([7, 18, 0]) cube([1, 1, 7.4]);

translate([8, 18, 0]) cube([1, 1, 7.5]);

translate([9, 18, 0]) cube([1, 1, 7.5]);

translate([10, 18, 0]) cube([1, 1, 7.4]);

translate([11, 18, 0]) cube([1, 1, 7.1]);

translate([12, 18, 0]) cube([1, 1, 6.9]);

translate([13, 18, 0]) cube([1, 1, 6.7]);

translate([14, 18, 0]) cube([1, 1, 6.6]);

translate([15, 18, 0]) cube([1, 1, 6.6]);

translate([16, 18, 0]) cube([1, 1, 6.6]);

translate([17, 18, 0]) cube([1, 1, 6.500874485596708]);

color([0,1,0])
translate([18, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 18, 0]) cube([1, 1, 6]);

translate([25, 18, 0]) cube([1, 1, 5.43746534566824]);

translate([26, 18, 0]) cube([1, 1, 5.240653433452662]);

translate([27, 18, 0]) cube([1, 1, 5.14494016859057]);

translate([28, 18, 0]) cube([1, 1, 5.12988569557889]);

translate([29, 18, 0]) cube([1, 1, 5.025352062755323]);

translate([30, 18, 0]) cube([1, 1, 4.924076198295854]);

translate([31, 18, 0]) cube([1, 1, 4.911641555785338]);

translate([32, 18, 0]) cube([1, 1, 5.102460141592018]);

translate([33, 18, 0]) cube([1, 1, 5.300462558492933]);

color([0,1,0])
translate([34, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 18, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 18, 0]) cube([1, 1, 6]);

translate([0, 19, 0]) cube([1, 1, 8.1]);

translate([1, 19, 0]) cube([1, 1, 7.9]);

translate([2, 19, 0]) cube([1, 1, 7.6]);

translate([3, 19, 0]) cube([1, 1, 7.4]);

translate([4, 19, 0]) cube([1, 1, 7.4]);

translate([5, 19, 0]) cube([1, 1, 7.4]);

translate([6, 19, 0]) cube([1, 1, 7.5]);

translate([7, 19, 0]) cube([1, 1, 7.6]);

translate([8, 19, 0]) cube([1, 1, 7.6]);

translate([9, 19, 0]) cube([1, 1, 7.6]);

translate([10, 19, 0]) cube([1, 1, 7.4]);

translate([11, 19, 0]) cube([1, 1, 7.2]);

translate([12, 19, 0]) cube([1, 1, 7.0]);

translate([13, 19, 0]) cube([1, 1, 6.8]);

translate([14, 19, 0]) cube([1, 1, 6.7]);

translate([15, 19, 0]) cube([1, 1, 6.8]);

translate([16, 19, 0]) cube([1, 1, 6.8]);

translate([17, 19, 0]) cube([1, 1, 6.7]);

translate([18, 19, 0]) cube([1, 1, 6.504372427983538]);

color([0,1,0])
translate([19, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 19, 0]) cube([1, 1, 6]);

translate([26, 19, 0]) cube([1, 1, 5.326243219209698]);

translate([27, 19, 0]) cube([1, 1, 5.340183281477017]);

translate([28, 19, 0]) cube([1, 1, 5.24715282611458]);

translate([29, 19, 0]) cube([1, 1, 5.237605501522851]);

translate([30, 19, 0]) cube([1, 1, 5.1121162920166805]);

translate([31, 19, 0]) cube([1, 1, 5.106575658468641]);

translate([32, 19, 0]) cube([1, 1, 5.20171102292315]);

translate([33, 19, 0]) cube([1, 1, 5.400985775780314]);

color([0,1,0])
translate([34, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 19, 0]) cube([1, 1, 6]);

translate([41, 19, 0]) cube([1, 1, 6.6]);

translate([42, 19, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([43, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 19, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 19, 0]) cube([1, 1, 6]);

translate([0, 20, 0]) cube([1, 1, 8.1]);

translate([1, 20, 0]) cube([1, 1, 7.9]);

translate([2, 20, 0]) cube([1, 1, 7.7]);

translate([3, 20, 0]) cube([1, 1, 7.6]);

translate([4, 20, 0]) cube([1, 1, 7.5]);

translate([5, 20, 0]) cube([1, 1, 7.6]);

translate([6, 20, 0]) cube([1, 1, 7.6]);

translate([7, 20, 0]) cube([1, 1, 7.6]);

translate([8, 20, 0]) cube([1, 1, 7.6]);

translate([9, 20, 0]) cube([1, 1, 7.6]);

translate([10, 20, 0]) cube([1, 1, 7.4]);

translate([11, 20, 0]) cube([1, 1, 7.2]);

translate([12, 20, 0]) cube([1, 1, 7.0]);

translate([13, 20, 0]) cube([1, 1, 6.9]);

translate([14, 20, 0]) cube([1, 1, 6.9]);

translate([15, 20, 0]) cube([1, 1, 6.9]);

translate([16, 20, 0]) cube([1, 1, 6.9]);

translate([17, 20, 0]) cube([1, 1, 6.8]);

translate([18, 20, 0]) cube([1, 1, 6.6040123456790125]);

color([0,1,0])
translate([19, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 20, 0]) cube([1, 1, 6]);

translate([28, 20, 0]) cube([1, 1, 4.789440335930249]);

translate([29, 20, 0]) cube([1, 1, 5.410589816193316]);

translate([30, 20, 0]) cube([1, 1, 5.30862369826496]);

translate([31, 20, 0]) cube([1, 1, 5.303233143024014]);

translate([32, 20, 0]) cube([1, 1, 5.401053903929543]);

color([0,1,0])
translate([33, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 20, 0]) cube([1, 1, 6]);

translate([40, 20, 0]) cube([1, 1, 6.6]);

translate([41, 20, 0]) cube([1, 1, 6.8]);

translate([42, 20, 0]) cube([1, 1, 6.8]);

translate([43, 20, 0]) cube([1, 1, 6.8]);

translate([44, 20, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([45, 20, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 20, 0]) cube([1, 1, 6]);

translate([47, 20, 0]) cube([1, 1, 5.400000355101615]);

translate([0, 21, 0]) cube([1, 1, 8.2]);

translate([1, 21, 0]) cube([1, 1, 7.9]);

translate([2, 21, 0]) cube([1, 1, 7.8]);

translate([3, 21, 0]) cube([1, 1, 7.7]);

translate([4, 21, 0]) cube([1, 1, 7.6]);

translate([5, 21, 0]) cube([1, 1, 7.6]);

translate([6, 21, 0]) cube([1, 1, 7.6]);

translate([7, 21, 0]) cube([1, 1, 7.5]);

translate([8, 21, 0]) cube([1, 1, 7.5]);

translate([9, 21, 0]) cube([1, 1, 7.4]);

translate([10, 21, 0]) cube([1, 1, 7.2]);

translate([11, 21, 0]) cube([1, 1, 7.1]);

translate([12, 21, 0]) cube([1, 1, 7.0]);

translate([13, 21, 0]) cube([1, 1, 7.0]);

translate([14, 21, 0]) cube([1, 1, 7.0]);

translate([15, 21, 0]) cube([1, 1, 7.0]);

translate([16, 21, 0]) cube([1, 1, 6.9]);

translate([17, 21, 0]) cube([1, 1, 6.7]);

translate([18, 21, 0]) cube([1, 1, 6.601666666666667]);

color([0,1,0])
translate([19, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 21, 0]) cube([1, 1, 6]);

translate([21, 21, 0]) cube([1, 1, 6.50342738894175]);

translate([22, 21, 0]) cube([1, 1, 6.503856679450221]);

color([0,1,0])
translate([23, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 21, 0]) cube([1, 1, 6]);

translate([40, 21, 0]) cube([1, 1, 6.8]);

translate([41, 21, 0]) cube([1, 1, 6.9]);

translate([42, 21, 0]) cube([1, 1, 7.0]);

translate([43, 21, 0]) cube([1, 1, 6.9]);

translate([44, 21, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([45, 21, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 21, 0]) cube([1, 1, 6]);

translate([47, 21, 0]) cube([1, 1, 5.400000355101615]);

translate([0, 22, 0]) cube([1, 1, 8.1]);

translate([1, 22, 0]) cube([1, 1, 7.9]);

translate([2, 22, 0]) cube([1, 1, 7.8]);

translate([3, 22, 0]) cube([1, 1, 7.7]);

translate([4, 22, 0]) cube([1, 1, 7.6]);

translate([5, 22, 0]) cube([1, 1, 7.5]);

translate([6, 22, 0]) cube([1, 1, 7.4]);

translate([7, 22, 0]) cube([1, 1, 7.3]);

translate([8, 22, 0]) cube([1, 1, 7.2]);

translate([9, 22, 0]) cube([1, 1, 7.0]);

translate([10, 22, 0]) cube([1, 1, 7.0]);

translate([11, 22, 0]) cube([1, 1, 7.0]);

translate([12, 22, 0]) cube([1, 1, 7.0]);

translate([13, 22, 0]) cube([1, 1, 7.0]);

translate([14, 22, 0]) cube([1, 1, 7.0]);

translate([15, 22, 0]) cube([1, 1, 7.0]);

translate([16, 22, 0]) cube([1, 1, 6.8]);

translate([17, 22, 0]) cube([1, 1, 6.606172839506173]);

translate([18, 22, 0]) cube([1, 1, 6.507691358024692]);

color([0,1,0])
translate([19, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 22, 0]) cube([1, 1, 6]);

translate([21, 22, 0]) cube([1, 1, 6.501496734929637]);

translate([22, 22, 0]) cube([1, 1, 6.600050555869495]);

translate([23, 22, 0]) cube([1, 1, 6.600050555869495]);

color([0,1,0])
translate([24, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 22, 0]) cube([1, 1, 6]);

translate([39, 22, 0]) cube([1, 1, 6.6]);

translate([40, 22, 0]) cube([1, 1, 6.7]);

translate([41, 22, 0]) cube([1, 1, 6.9]);

translate([42, 22, 0]) cube([1, 1, 7.0]);

translate([43, 22, 0]) cube([1, 1, 6.9]);

translate([44, 22, 0]) cube([1, 1, 6.8]);

color([0,1,0])
translate([45, 22, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 22, 0]) cube([1, 1, 6]);

translate([47, 22, 0]) cube([1, 1, 5.40000071080428]);

translate([0, 23, 0]) cube([1, 1, 8.0]);

translate([1, 23, 0]) cube([1, 1, 7.8]);

translate([2, 23, 0]) cube([1, 1, 7.6]);

translate([3, 23, 0]) cube([1, 1, 7.6]);

translate([4, 23, 0]) cube([1, 1, 7.5]);

translate([5, 23, 0]) cube([1, 1, 7.4]);

translate([6, 23, 0]) cube([1, 1, 7.2]);

translate([7, 23, 0]) cube([1, 1, 7.1]);

translate([8, 23, 0]) cube([1, 1, 6.9]);

translate([9, 23, 0]) cube([1, 1, 6.7091520000000004]);

translate([10, 23, 0]) cube([1, 1, 6.71010725925926]);

translate([11, 23, 0]) cube([1, 1, 6.8059259259259255]);

translate([12, 23, 0]) cube([1, 1, 6.801481481481481]);

translate([13, 23, 0]) cube([1, 1, 6.9]);

translate([14, 23, 0]) cube([1, 1, 6.9]);

translate([15, 23, 0]) cube([1, 1, 6.9]);

translate([16, 23, 0]) cube([1, 1, 6.8]);

translate([17, 23, 0]) cube([1, 1, 6.608395061728395]);

color([0,1,0])
translate([18, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 23, 0]) cube([1, 1, 6]);

translate([21, 23, 0]) cube([1, 1, 6.502017616280016]);

translate([22, 23, 0]) cube([1, 1, 6.600179458262225]);

translate([23, 23, 0]) cube([1, 1, 6.600179458262225]);

color([0,1,0])
translate([24, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 23, 0]) cube([1, 1, 6]);

translate([40, 23, 0]) cube([1, 1, 6.6]);

translate([41, 23, 0]) cube([1, 1, 6.8]);

translate([42, 23, 0]) cube([1, 1, 6.8]);

translate([43, 23, 0]) cube([1, 1, 6.8]);

translate([44, 23, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([45, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 23, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 23, 0]) cube([1, 1, 6]);

translate([0, 24, 0]) cube([1, 1, 7.7]);

translate([1, 24, 0]) cube([1, 1, 7.5]);

translate([2, 24, 0]) cube([1, 1, 7.4]);

translate([3, 24, 0]) cube([1, 1, 7.3]);

translate([4, 24, 0]) cube([1, 1, 7.2]);

translate([5, 24, 0]) cube([1, 1, 7.1]);

translate([6, 24, 0]) cube([1, 1, 7.0]);

translate([7, 24, 0]) cube([1, 1, 6.8]);

translate([8, 24, 0]) cube([1, 1, 6.6018304]);

translate([9, 24, 0]) cube([1, 1, 6.524099575308642]);

translate([10, 24, 0]) cube([1, 1, 6.553975308641976]);

color([0,1,0])
translate([11, 24, 0]) cube([1, 1, 6]);

translate([12, 24, 0]) cube([1, 1, 6.6171851851851855]);

translate([13, 24, 0]) cube([1, 1, 6.707407407407408]);

translate([14, 24, 0]) cube([1, 1, 6.8]);

translate([15, 24, 0]) cube([1, 1, 6.8]);

translate([16, 24, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([17, 24, 0]) cube([1, 1, 6]);

translate([18, 24, 0]) cube([1, 1, 6.537065743822794]);

color([0,1,0])
translate([19, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 24, 0]) cube([1, 1, 6]);

translate([21, 24, 0]) cube([1, 1, 6.507648370185761]);

translate([22, 24, 0]) cube([1, 1, 6.601200627362473]);

translate([23, 24, 0]) cube([1, 1, 6.501702969859819]);

color([0,1,0])
translate([24, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 24, 0]) cube([1, 1, 6]);

translate([31, 24, 0]) cube([1, 1, 5.006051698356952]);

color([0,1,0])
translate([32, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 24, 0]) cube([1, 1, 6]);

translate([37, 24, 0]) cube([1, 1, 5.226238035904639]);

color([0,1,0])
translate([38, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 24, 0]) cube([1, 1, 6]);

translate([41, 24, 0]) cube([1, 1, 6.6]);

translate([42, 24, 0]) cube([1, 1, 6.7]);

translate([43, 24, 0]) cube([1, 1, 6.7]);

translate([44, 24, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([45, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 24, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 24, 0]) cube([1, 1, 6]);

translate([0, 25, 0]) cube([1, 1, 7.3]);

translate([1, 25, 0]) cube([1, 1, 7.1]);

translate([2, 25, 0]) cube([1, 1, 7.1]);

translate([3, 25, 0]) cube([1, 1, 7.0]);

translate([4, 25, 0]) cube([1, 1, 7.0]);

translate([5, 25, 0]) cube([1, 1, 6.9]);

translate([6, 25, 0]) cube([1, 1, 6.8]);

translate([7, 25, 0]) cube([1, 1, 6.60036608]);

color([0,1,0])
translate([8, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 25, 0]) cube([1, 1, 6]);

translate([14, 25, 0]) cube([1, 1, 6.601416931216931]);

translate([15, 25, 0]) cube([1, 1, 6.600973544973544]);

translate([16, 25, 0]) cube([1, 1, 6.603571428571429]);

translate([17, 25, 0]) cube([1, 1, 6.540545004383253]);

translate([18, 25, 0]) cube([1, 1, 6.5399229516189115]);

translate([19, 25, 0]) cube([1, 1, 6.529965442544059]);

translate([20, 25, 0]) cube([1, 1, 6.519421618184879]);

translate([21, 25, 0]) cube([1, 1, 6.606066783558034]);

translate([22, 25, 0]) cube([1, 1, 6.60372499363514]);

translate([23, 25, 0]) cube([1, 1, 6.5028009217381015]);

color([0,1,0])
translate([24, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 25, 0]) cube([1, 1, 6]);

translate([28, 25, 0]) cube([1, 1, 5.4299644147829635]);

translate([29, 25, 0]) cube([1, 1, 5.429969253050014]);

translate([30, 25, 0]) cube([1, 1, 5.44570073246392]);

color([0,1,0])
translate([31, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 25, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 25, 0]) cube([1, 1, 6]);

translate([0, 26, 0]) cube([1, 1, 7.0]);

translate([1, 26, 0]) cube([1, 1, 6.8]);

translate([2, 26, 0]) cube([1, 1, 6.8]);

translate([3, 26, 0]) cube([1, 1, 6.8]);

translate([4, 26, 0]) cube([1, 1, 6.8]);

translate([5, 26, 0]) cube([1, 1, 6.7]);

translate([6, 26, 0]) cube([1, 1, 6.600073215999999]);

translate([7, 26, 0]) cube([1, 1, 6.500073216]);

color([0,1,0])
translate([8, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 26, 0]) cube([1, 1, 6]);

translate([16, 26, 0]) cube([1, 1, 6.512712536806105]);

translate([17, 26, 0]) cube([1, 1, 6.528012085511473]);

translate([18, 26, 0]) cube([1, 1, 6.613979568664939]);

translate([19, 26, 0]) cube([1, 1, 6.619890620286228]);

translate([20, 26, 0]) cube([1, 1, 6.7138123859723295]);

translate([21, 26, 0]) cube([1, 1, 6.7125147324423535]);

translate([22, 26, 0]) cube([1, 1, 6.706227321655642]);

translate([23, 26, 0]) cube([1, 1, 6.504029994025144]);

color([0,1,0])
translate([24, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 26, 0]) cube([1, 1, 6]);

translate([28, 26, 0]) cube([1, 1, 5.435759348880689]);

translate([29, 26, 0]) cube([1, 1, 5.36300240050809]);

translate([30, 26, 0]) cube([1, 1, 5.3485670063050605]);

translate([31, 26, 0]) cube([1, 1, 5.334161576967827]);

translate([32, 26, 0]) cube([1, 1, 5.4174746917767855]);

color([0,1,0])
translate([33, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 26, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 26, 0]) cube([1, 1, 6]);

translate([0, 27, 0]) cube([1, 1, 6.8]);

translate([1, 27, 0]) cube([1, 1, 6.6]);

translate([2, 27, 0]) cube([1, 1, 6.6]);

translate([3, 27, 0]) cube([1, 1, 6.6]);

translate([4, 27, 0]) cube([1, 1, 6.500003050666667]);

translate([5, 27, 0]) cube([1, 1, 6.5000122026666665]);

color([0,1,0])
translate([6, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 27, 0]) cube([1, 1, 6]);

translate([18, 27, 0]) cube([1, 1, 6.6139344544902325]);

translate([19, 27, 0]) cube([1, 1, 6.730762886220248]);

translate([20, 27, 0]) cube([1, 1, 6.926559842687075]);

translate([21, 27, 0]) cube([1, 1, 6.925065104166666]);

translate([22, 27, 0]) cube([1, 1, 6.904673549107143]);

translate([23, 27, 0]) cube([1, 1, 6.70307219883473]);

color([0,1,0])
translate([24, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 27, 0]) cube([1, 1, 6]);

translate([29, 27, 0]) cube([1, 1, 5.367184340918235]);

translate([30, 27, 0]) cube([1, 1, 5.306437573934342]);

translate([31, 27, 0]) cube([1, 1, 5.3064402461753675]);

translate([32, 27, 0]) cube([1, 1, 5.3065175639125455]);

translate([33, 27, 0]) cube([1, 1, 5.3245647083745515]);

color([0,1,0])
translate([34, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 27, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 27, 0]) cube([1, 1, 6]);

translate([0, 28, 0]) cube([1, 1, 6.7]);

translate([1, 28, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([2, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 28, 0]) cube([1, 1, 6]);

translate([11, 28, 0]) cube([1, 1, 5.434272340209778]);

color([0,1,0])
translate([12, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 28, 0]) cube([1, 1, 6]);

translate([18, 28, 0]) cube([1, 1, 6.5209372910670105]);

translate([19, 28, 0]) cube([1, 1, 6.83100683477756]);

translate([20, 28, 0]) cube([1, 1, 6.309055424644899]);

translate([21, 28, 0]) cube([1, 1, 7.1]);

translate([22, 28, 0]) cube([1, 1, 7.002976190476191]);

translate([23, 28, 0]) cube([1, 1, 6.801483932934671]);

translate([24, 28, 0]) cube([1, 1, 6.500940523436741]);

color([0,1,0])
translate([25, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 28, 0]) cube([1, 1, 6]);

translate([28, 28, 0]) cube([1, 1, 5.0389891474350605]);

color([0,1,0])
translate([29, 28, 0]) cube([1, 1, 6]);

translate([30, 28, 0]) cube([1, 1, 5.3293031308911]);

translate([31, 28, 0]) cube([1, 1, 5.306523482084991]);

translate([32, 28, 0]) cube([1, 1, 5.3078974397083565]);

translate([33, 28, 0]) cube([1, 1, 5.316583036615703]);

color([0,1,0])
translate([34, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 28, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 28, 0]) cube([1, 1, 6]);

translate([0, 29, 0]) cube([1, 1, 6.9]);

translate([1, 29, 0]) cube([1, 1, 6.7]);

translate([2, 29, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 29, 0]) cube([1, 1, 6]);

translate([10, 29, 0]) cube([1, 1, 5.346345008065943]);

translate([11, 29, 0]) cube([1, 1, 5.348712272821246]);

translate([12, 29, 0]) cube([1, 1, 5.430895764663318]);

color([0,1,0])
translate([13, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 29, 0]) cube([1, 1, 6]);

translate([19, 29, 0]) cube([1, 1, 6.7289822798470125]);

translate([20, 29, 0]) cube([1, 1, 7.000011810279667]);

translate([21, 29, 0]) cube([1, 1, 7.1]);

translate([22, 29, 0]) cube([1, 1, 7.000496031746032]);

translate([23, 29, 0]) cube([1, 1, 6.800859201946596]);

translate([24, 29, 0]) cube([1, 1, 6.500670615884282]);

color([0,1,0])
translate([25, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 29, 0]) cube([1, 1, 6]);

translate([30, 29, 0]) cube([1, 1, 5.4147418483009515]);

translate([31, 29, 0]) cube([1, 1, 5.317551917396938]);

translate([32, 29, 0]) cube([1, 1, 5.31393352864556]);

translate([33, 29, 0]) cube([1, 1, 5.318385867273453]);

translate([34, 29, 0]) cube([1, 1, 5.403729448172975]);

color([0,1,0])
translate([35, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 29, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 29, 0]) cube([1, 1, 6]);

translate([47, 29, 0]) cube([1, 1, 5.300060233515323]);

translate([0, 30, 0]) cube([1, 1, 7.0]);

translate([1, 30, 0]) cube([1, 1, 6.9]);

translate([2, 30, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 30, 0]) cube([1, 1, 6]);

translate([9, 30, 0]) cube([1, 1, 5.402057548028995]);

translate([10, 30, 0]) cube([1, 1, 5.345040150285732]);

translate([11, 30, 0]) cube([1, 1, 5.348675134500626]);

translate([12, 30, 0]) cube([1, 1, 5.42810885714286]);

color([0,1,0])
translate([13, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 30, 0]) cube([1, 1, 6]);

translate([19, 30, 0]) cube([1, 1, 6.605806595427581]);

translate([20, 30, 0]) cube([1, 1, 6.90001789116771]);

translate([21, 30, 0]) cube([1, 1, 7.0000708616780045]);

translate([22, 30, 0]) cube([1, 1, 6.900097680854749]);

translate([23, 30, 0]) cube([1, 1, 6.7002972288280125]);

color([0,1,0])
translate([24, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 30, 0]) cube([1, 1, 6]);

translate([31, 30, 0]) cube([1, 1, 5.408441183166062]);

translate([32, 30, 0]) cube([1, 1, 5.32476731177942]);

translate([33, 30, 0]) cube([1, 1, 5.331306374397216]);

translate([34, 30, 0]) cube([1, 1, 5.401203523736097]);

color([0,1,0])
translate([35, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 30, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 30, 0]) cube([1, 1, 6]);

translate([46, 30, 0]) cube([1, 1, 5.400040757771161]);

translate([47, 30, 0]) cube([1, 1, 5.100086683187917]);

translate([0, 31, 0]) cube([1, 1, 7.1]);

translate([1, 31, 0]) cube([1, 1, 7.0]);

translate([2, 31, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 31, 0]) cube([1, 1, 6]);

translate([7, 31, 0]) cube([1, 1, 5.400761010493187]);

translate([8, 31, 0]) cube([1, 1, 5.3187702865182755]);

translate([9, 31, 0]) cube([1, 1, 5.326540463644409]);

translate([10, 31, 0]) cube([1, 1, 5.343912025700923]);

translate([11, 31, 0]) cube([1, 1, 5.414975818771561]);

color([0,1,0])
translate([12, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 31, 0]) cube([1, 1, 6]);

translate([19, 31, 0]) cube([1, 1, 6.6011706027060395]);

translate([20, 31, 0]) cube([1, 1, 6.800020995843518]);

translate([21, 31, 0]) cube([1, 1, 6.900023761157902]);

translate([22, 31, 0]) cube([1, 1, 6.800033229592681]);

translate([23, 31, 0]) cube([1, 1, 6.500088552871164]);

color([0,1,0])
translate([24, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 31, 0]) cube([1, 1, 6]);

translate([32, 31, 0]) cube([1, 1, 5.412802587519892]);

translate([33, 31, 0]) cube([1, 1, 5.348487149165155]);

translate([34, 31, 0]) cube([1, 1, 5.358742008062513]);

translate([35, 31, 0]) cube([1, 1, 5.365157782723472]);

translate([36, 31, 0]) cube([1, 1, 5.368115308308181]);

translate([37, 31, 0]) cube([1, 1, 5.402532873322502]);

color([0,1,0])
translate([38, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 31, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 31, 0]) cube([1, 1, 6]);

translate([46, 31, 0]) cube([1, 1, 5.30003853263689]);

translate([47, 31, 0]) cube([1, 1, 5.0001000378177585]);

translate([0, 32, 0]) cube([1, 1, 7.2]);

translate([1, 32, 0]) cube([1, 1, 7.0]);

translate([2, 32, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 32, 0]) cube([1, 1, 6]);

translate([6, 32, 0]) cube([1, 1, 5.300350073371669]);

translate([7, 32, 0]) cube([1, 1, 5.233127595447181]);

translate([8, 32, 0]) cube([1, 1, 5.316448610215629]);

translate([9, 32, 0]) cube([1, 1, 5.324108955493514]);

translate([10, 32, 0]) cube([1, 1, 5.4110815207131635]);

color([0,1,0])
translate([11, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 32, 0]) cube([1, 1, 6]);

translate([19, 32, 0]) cube([1, 1, 6.600240772557899]);

translate([20, 32, 0]) cube([1, 1, 6.8000075310913966]);

translate([21, 32, 0]) cube([1, 1, 6.800011404424846]);

translate([22, 32, 0]) cube([1, 1, 6.700014625664794]);

translate([23, 32, 0]) cube([1, 1, 6.500028859176969]);

color([0,1,0])
translate([24, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 32, 0]) cube([1, 1, 6]);

translate([33, 32, 0]) cube([1, 1, 5.436176517324445]);

translate([34, 32, 0]) cube([1, 1, 5.436871664849163]);

translate([35, 32, 0]) cube([1, 1, 5.425729497574881]);

translate([36, 32, 0]) cube([1, 1, 5.369365540855359]);

translate([37, 32, 0]) cube([1, 1, 5.3712671249722295]);

translate([38, 32, 0]) cube([1, 1, 5.405552464811551]);

color([0,1,0])
translate([39, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 32, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 32, 0]) cube([1, 1, 6]);

translate([45, 32, 0]) cube([1, 1, 5.400038671734641]);

translate([46, 32, 0]) cube([1, 1, 5.100034102039555]);

translate([47, 32, 0]) cube([1, 1, 4.900102263863956]);

translate([0, 33, 0]) cube([1, 1, 7.1]);

translate([1, 33, 0]) cube([1, 1, 7.0]);

translate([2, 33, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([3, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 33, 0]) cube([1, 1, 6]);

translate([5, 33, 0]) cube([1, 1, 5.400128668547622]);

translate([6, 33, 0]) cube([1, 1, 5.233127426053394]);

translate([7, 33, 0]) cube([1, 1, 5.233131320926359]);

translate([8, 33, 0]) cube([1, 1, 5.31260679206612]);

color([0,1,0])
translate([9, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 33, 0]) cube([1, 1, 6]);

translate([19, 33, 0]) cube([1, 1, 6.600063555167346]);

translate([20, 33, 0]) cube([1, 1, 6.800004733732957]);

translate([21, 33, 0]) cube([1, 1, 6.800004733732957]);

translate([22, 33, 0]) cube([1, 1, 6.7000078881701715]);

translate([23, 33, 0]) cube([1, 1, 6.5000104323740056]);

color([0,1,0])
translate([24, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 33, 0]) cube([1, 1, 6]);

translate([36, 33, 0]) cube([1, 1, 5.428661267380576]);

translate([37, 33, 0]) cube([1, 1, 5.410872715937326]);

translate([38, 33, 0]) cube([1, 1, 5.407715254066343]);

color([0,1,0])
translate([39, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 33, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 33, 0]) cube([1, 1, 6]);

translate([44, 33, 0]) cube([1, 1, 5.400042327637493]);

translate([45, 33, 0]) cube([1, 1, 5.200039894353804]);

translate([46, 33, 0]) cube([1, 1, 5.0000318573759035]);

translate([47, 33, 0]) cube([1, 1, 4.800104941879081]);

translate([0, 34, 0]) cube([1, 1, 7.0]);

translate([1, 34, 0]) cube([1, 1, 6.9]);

translate([2, 34, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([3, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 34, 0]) cube([1, 1, 6]);

translate([5, 34, 0]) cube([1, 1, 5.400441945199497]);

translate([6, 34, 0]) cube([1, 1, 5.303275431871116]);

translate([7, 34, 0]) cube([1, 1, 5.305292028515059]);

color([0,1,0])
translate([8, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 34, 0]) cube([1, 1, 6]);

translate([14, 34, 0]) cube([1, 1, 5.0282538235051515]);

color([0,1,0])
translate([15, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 34, 0]) cube([1, 1, 6]);

translate([18, 34, 0]) cube([1, 1, 6.600012947595929]);

translate([19, 34, 0]) cube([1, 1, 6.700001183287136]);

translate([20, 34, 0]) cube([1, 1, 6.9]);

translate([21, 34, 0]) cube([1, 1, 6.9]);

translate([22, 34, 0]) cube([1, 1, 6.800000788858091]);

translate([23, 34, 0]) cube([1, 1, 6.500003853372831]);

color([0,1,0])
translate([24, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 34, 0]) cube([1, 1, 6]);

translate([34, 34, 0]) cube([1, 1, 4.657865136733077]);

color([0,1,0])
translate([35, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 34, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 34, 0]) cube([1, 1, 6]);

translate([43, 34, 0]) cube([1, 1, 5.400059275650046]);

translate([44, 34, 0]) cube([1, 1, 5.300049237531908]);

translate([45, 34, 0]) cube([1, 1, 5.1000466207760535]);

translate([46, 34, 0]) cube([1, 1, 4.900040791141101]);

translate([47, 34, 0]) cube([1, 1, 4.800085193266148]);

translate([0, 35, 0]) cube([1, 1, 6.8]);

translate([1, 35, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([2, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 35, 0]) cube([1, 1, 6]);

translate([17, 35, 0]) cube([1, 1, 6.600002589394555]);

translate([18, 35, 0]) cube([1, 1, 6.8]);

translate([19, 35, 0]) cube([1, 1, 6.9]);

translate([20, 35, 0]) cube([1, 1, 7.0]);

translate([21, 35, 0]) cube([1, 1, 7.0]);

translate([22, 35, 0]) cube([1, 1, 6.800000157674215]);

translate([23, 35, 0]) cube([1, 1, 6.500000966201149]);

color([0,1,0])
translate([24, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 35, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 35, 0]) cube([1, 1, 6]);

translate([42, 35, 0]) cube([1, 1, 5.400175254639029]);

translate([43, 35, 0]) cube([1, 1, 5.300137726298108]);

translate([44, 35, 0]) cube([1, 1, 5.10012607880463]);

translate([45, 35, 0]) cube([1, 1, 4.900104636258699]);

translate([46, 35, 0]) cube([1, 1, 4.800089178605844]);

translate([47, 35, 0]) cube([1, 1, 4.700145050654026]);

translate([0, 36, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([1, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 36, 0]) cube([1, 1, 6]);

translate([16, 36, 0]) cube([1, 1, 6.600000517749197]);

translate([17, 36, 0]) cube([1, 1, 6.8]);

translate([18, 36, 0]) cube([1, 1, 7.0]);

translate([19, 36, 0]) cube([1, 1, 7.1]);

translate([20, 36, 0]) cube([1, 1, 7.1]);

translate([21, 36, 0]) cube([1, 1, 7.1]);

translate([22, 36, 0]) cube([1, 1, 6.800000031437441]);

translate([23, 36, 0]) cube([1, 1, 6.500000232228658]);

color([0,1,0])
translate([24, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 36, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 36, 0]) cube([1, 1, 6]);

translate([40, 36, 0]) cube([1, 1, 5.40128843962943]);

translate([41, 36, 0]) cube([1, 1, 5.4006238483066475]);

translate([42, 36, 0]) cube([1, 1, 5.30043278248355]);

translate([43, 36, 0]) cube([1, 1, 5.100384709092598]);

translate([44, 36, 0]) cube([1, 1, 4.900298555847686]);

translate([45, 36, 0]) cube([1, 1, 4.800187101641303]);

translate([46, 36, 0]) cube([1, 1, 4.70014997498807]);

translate([47, 36, 0]) cube([1, 1, 4.600197360206418]);

color([0,1,0])
translate([0, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 37, 0]) cube([1, 1, 6]);

translate([16, 37, 0]) cube([1, 1, 6.7]);

translate([17, 37, 0]) cube([1, 1, 7.0]);

translate([18, 37, 0]) cube([1, 1, 7.2]);

translate([19, 37, 0]) cube([1, 1, 7.2]);

translate([20, 37, 0]) cube([1, 1, 7.2]);

translate([21, 37, 0]) cube([1, 1, 7.0]);

translate([22, 37, 0]) cube([1, 1, 6.700000006191561]);

color([0,1,0])
translate([23, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 37, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 37, 0]) cube([1, 1, 6]);

translate([38, 37, 0]) cube([1, 1, 5.402387834472134]);

translate([39, 37, 0]) cube([1, 1, 5.401652777370303]);

translate([40, 37, 0]) cube([1, 1, 5.401154255859752]);

translate([41, 37, 0]) cube([1, 1, 5.301186505934603]);

translate([42, 37, 0]) cube([1, 1, 5.200785020085828]);

translate([43, 37, 0]) cube([1, 1, 5.100428779595817]);

translate([44, 37, 0]) cube([1, 1, 4.900377472359007]);

translate([45, 37, 0]) cube([1, 1, 4.700317403952297]);

translate([46, 37, 0]) cube([1, 1, 4.600196979042471]);

translate([47, 37, 0]) cube([1, 1, 4.500647155192479]);

color([0,1,0])
translate([0, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 38, 0]) cube([1, 1, 6]);

translate([15, 38, 0]) cube([1, 1, 6.6]);

translate([16, 38, 0]) cube([1, 1, 6.8]);

translate([17, 38, 0]) cube([1, 1, 7.0]);

translate([18, 38, 0]) cube([1, 1, 7.2]);

translate([19, 38, 0]) cube([1, 1, 7.2]);

translate([20, 38, 0]) cube([1, 1, 7.1]);

translate([21, 38, 0]) cube([1, 1, 6.9]);

translate([22, 38, 0]) cube([1, 1, 6.5000000011601715]);

color([0,1,0])
translate([23, 38, 0]) cube([1, 1, 6]);

translate([24, 38, 0]) cube([1, 1, 5.013934149983956]);

color([0,1,0])
translate([25, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 38, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 38, 0]) cube([1, 1, 6]);

translate([37, 38, 0]) cube([1, 1, 5.402247431173462]);

translate([38, 38, 0]) cube([1, 1, 5.401909694473884]);

translate([39, 38, 0]) cube([1, 1, 5.401718262301269]);

translate([40, 38, 0]) cube([1, 1, 5.4012224495627015]);

translate([41, 38, 0]) cube([1, 1, 5.400431091884924]);

translate([42, 38, 0]) cube([1, 1, 5.300465856320772]);

translate([43, 38, 0]) cube([1, 1, 5.100557921347326]);

translate([44, 38, 0]) cube([1, 1, 5.00023905447532]);

translate([45, 38, 0]) cube([1, 1, 4.800143953345062]);

translate([46, 38, 0]) cube([1, 1, 4.600192320339137]);

translate([47, 38, 0]) cube([1, 1, 4.500649283160483]);

color([0,1,0])
translate([0, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 39, 0]) cube([1, 1, 6]);

translate([15, 39, 0]) cube([1, 1, 6.7]);

translate([16, 39, 0]) cube([1, 1, 6.8]);

translate([17, 39, 0]) cube([1, 1, 6.9]);

translate([18, 39, 0]) cube([1, 1, 7.0]);

translate([19, 39, 0]) cube([1, 1, 7.0]);

translate([20, 39, 0]) cube([1, 1, 6.8]);

translate([21, 39, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([22, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 39, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 39, 0]) cube([1, 1, 6]);

translate([37, 39, 0]) cube([1, 1, 5.402292317163578]);

translate([38, 39, 0]) cube([1, 1, 5.402112844395919]);

translate([39, 39, 0]) cube([1, 1, 5.4020772839217]);

color([0,1,0])
translate([40, 39, 0]) cube([1, 1, 6]);

translate([41, 39, 0]) cube([1, 1, 5.400482836957537]);

translate([42, 39, 0]) cube([1, 1, 5.400228849098588]);

translate([43, 39, 0]) cube([1, 1, 5.300173796245589]);

translate([44, 39, 0]) cube([1, 1, 5.200034778179093]);

translate([45, 39, 0]) cube([1, 1, 5.000068462537303]);

translate([46, 39, 0]) cube([1, 1, 4.800042483623431]);

translate([47, 39, 0]) cube([1, 1, 4.600128021576861]);

color([0,1,0])
translate([0, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 40, 0]) cube([1, 1, 6]);

translate([14, 40, 0]) cube([1, 1, 6.6]);

translate([15, 40, 0]) cube([1, 1, 6.7]);

translate([16, 40, 0]) cube([1, 1, 6.8]);

translate([17, 40, 0]) cube([1, 1, 6.8]);

translate([18, 40, 0]) cube([1, 1, 6.8]);

translate([19, 40, 0]) cube([1, 1, 6.7]);

color([0,1,0])
translate([20, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 40, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 40, 0]) cube([1, 1, 6]);

translate([45, 40, 0]) cube([1, 1, 5.300000002876175]);

translate([46, 40, 0]) cube([1, 1, 5.1]);

translate([47, 40, 0]) cube([1, 1, 4.800021240241781]);

color([0,1,0])
translate([0, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 41, 0]) cube([1, 1, 6]);

translate([14, 41, 0]) cube([1, 1, 6.7]);

translate([15, 41, 0]) cube([1, 1, 6.7]);

translate([16, 41, 0]) cube([1, 1, 6.6]);

translate([17, 41, 0]) cube([1, 1, 6.6]);

color([0,1,0])
translate([18, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([40, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([41, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([42, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 41, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 41, 0]) cube([1, 1, 6]);

translate([47, 41, 0]) cube([1, 1, 5.2]);

color([0,1,0])
translate([0, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([39, 42, 0]) cube([1, 1, 6]);

translate([40, 42, 0]) cube([1, 1, 5.400003245474152]);

translate([41, 42, 0]) cube([1, 1, 5.40000173234049]);

color([0,1,0])
translate([42, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 42, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 42, 0]) cube([1, 1, 6]);

translate([47, 42, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([0, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([7, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([8, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([9, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([10, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([33, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([34, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([35, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([38, 43, 0]) cube([1, 1, 6]);

translate([39, 43, 0]) cube([1, 1, 5.400003097793104]);

translate([40, 43, 0]) cube([1, 1, 5.300003538837887]);

translate([41, 43, 0]) cube([1, 1, 5.30000334684471]);

translate([42, 43, 0]) cube([1, 1, 5.400000491801414]);

color([0,1,0])
translate([43, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 43, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([1, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([2, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([3, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([4, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([5, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([6, 44, 0]) cube([1, 1, 6]);

translate([7, 44, 0]) cube([1, 1, 5.40010474044912]);

translate([8, 44, 0]) cube([1, 1, 5.3002258737352435]);

translate([9, 44, 0]) cube([1, 1, 5.4001327336697855]);

color([0,1,0])
translate([10, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([11, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([12, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([13, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([16, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([17, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([18, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([19, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([20, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([21, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([22, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([32, 44, 0]) cube([1, 1, 6]);

translate([33, 44, 0]) cube([1, 1, 5.400000197948473]);

translate([34, 44, 0]) cube([1, 1, 5.400000410031662]);

color([0,1,0])
translate([35, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([36, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([37, 44, 0]) cube([1, 1, 6]);

translate([38, 44, 0]) cube([1, 1, 5.400002408076368]);

translate([39, 44, 0]) cube([1, 1, 5.400001512885112]);

translate([40, 44, 0]) cube([1, 1, 5.3000026095955235]);

translate([41, 44, 0]) cube([1, 1, 5.300002884054024]);

translate([42, 44, 0]) cube([1, 1, 5.4000001228529095]);

color([0,1,0])
translate([43, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 44, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([0, 45, 0]) cube([1, 1, 6]);

translate([1, 45, 0]) cube([1, 1, 5.400000853321641]);

translate([2, 45, 0]) cube([1, 1, 5.400001892113518]);

translate([3, 45, 0]) cube([1, 1, 5.400003783770707]);

color([0,1,0])
translate([4, 45, 0]) cube([1, 1, 6]);

translate([5, 45, 0]) cube([1, 1, 5.400016741570556]);

translate([6, 45, 0]) cube([1, 1, 5.300038317878806]);

translate([7, 45, 0]) cube([1, 1, 5.200085042581753]);

translate([8, 45, 0]) cube([1, 1, 5.100131330248119]);

translate([9, 45, 0]) cube([1, 1, 5.100129393764352]);

translate([10, 45, 0]) cube([1, 1, 5.200053523039882]);

translate([11, 45, 0]) cube([1, 1, 5.300024442084488]);

translate([12, 45, 0]) cube([1, 1, 5.400006849437911]);

color([0,1,0])
translate([13, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([14, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([15, 45, 0]) cube([1, 1, 6]);

translate([16, 45, 0]) cube([1, 1, 5.400000441154269]);

translate([17, 45, 0]) cube([1, 1, 5.300014120011811]);

translate([18, 45, 0]) cube([1, 1, 5.2001542002729035]);

translate([19, 45, 0]) cube([1, 1, 5.200315390213869]);

translate([20, 45, 0]) cube([1, 1, 5.300605576756976]);

translate([21, 45, 0]) cube([1, 1, 5.400899592405269]);

color([0,1,0])
translate([22, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([23, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 45, 0]) cube([1, 1, 6]);

translate([32, 45, 0]) cube([1, 1, 5.400000056742935]);

translate([33, 45, 0]) cube([1, 1, 5.300000367082993]);

translate([34, 45, 0]) cube([1, 1, 5.300000395948475]);

translate([35, 45, 0]) cube([1, 1, 5.4000005962361906]);

translate([36, 45, 0]) cube([1, 1, 5.400000955890979]);

translate([37, 45, 0]) cube([1, 1, 5.400001203411993]);

translate([38, 45, 0]) cube([1, 1, 5.400001183204118]);

translate([39, 45, 0]) cube([1, 1, 5.300002017096258]);

translate([40, 45, 0]) cube([1, 1, 5.3000022627610175]);

translate([41, 45, 0]) cube([1, 1, 5.300002719074754]);

color([0,1,0])
translate([42, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 45, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 45, 0]) cube([1, 1, 6]);

translate([0, 46, 0]) cube([1, 1, 5.300000637486164]);

translate([1, 46, 0]) cube([1, 1, 5.300000966263695]);

translate([2, 46, 0]) cube([1, 1, 5.300001992973809]);

translate([3, 46, 0]) cube([1, 1, 5.300003440691403]);

translate([4, 46, 0]) cube([1, 1, 5.300006996197973]);

translate([5, 46, 0]) cube([1, 1, 5.300009930259951]);

translate([6, 46, 0]) cube([1, 1, 5.200030006123171]);

translate([7, 46, 0]) cube([1, 1, 5.100057035175229]);

translate([8, 46, 0]) cube([1, 1, 5.000087524773758]);

translate([9, 46, 0]) cube([1, 1, 4.900130996970126]);

translate([10, 46, 0]) cube([1, 1, 5.000045078542465]);

translate([11, 46, 0]) cube([1, 1, 5.1000180351420035]);

translate([12, 46, 0]) cube([1, 1, 5.20000536378246]);

translate([13, 46, 0]) cube([1, 1, 5.200002675722487]);

translate([14, 46, 0]) cube([1, 1, 5.200000782698892]);

translate([15, 46, 0]) cube([1, 1, 5.100000313388709]);

translate([16, 46, 0]) cube([1, 1, 5.000002989053195]);

translate([17, 46, 0]) cube([1, 1, 4.900034349902393]);

translate([18, 46, 0]) cube([1, 1, 4.800213154414902]);

translate([19, 46, 0]) cube([1, 1, 4.900334558719969]);

translate([20, 46, 0]) cube([1, 1, 5.000597626607732]);

translate([21, 46, 0]) cube([1, 1, 5.20062050336154]);

translate([22, 46, 0]) cube([1, 1, 5.400514350716497]);

color([0,1,0])
translate([23, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([24, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([25, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([26, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([27, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 46, 0]) cube([1, 1, 6]);

translate([32, 46, 0]) cube([1, 1, 5.400000011247964]);

translate([33, 46, 0]) cube([1, 1, 5.20000035727765]);

translate([34, 46, 0]) cube([1, 1, 5.200000404328173]);

translate([35, 46, 0]) cube([1, 1, 5.2000006055441546]);

translate([36, 46, 0]) cube([1, 1, 5.200001136787911]);

translate([37, 46, 0]) cube([1, 1, 5.300000834638255]);

translate([38, 46, 0]) cube([1, 1, 5.300001379700685]);

translate([39, 46, 0]) cube([1, 1, 5.300001696786253]);

translate([40, 46, 0]) cube([1, 1, 5.300001948476225]);

translate([41, 46, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([42, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([46, 46, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([47, 46, 0]) cube([1, 1, 6]);

translate([0, 47, 0]) cube([1, 1, 5.200000801601804]);

translate([1, 47, 0]) cube([1, 1, 5.1000123787227825]);

translate([2, 47, 0]) cube([1, 1, 5.100012784474945]);

translate([3, 47, 0]) cube([1, 1, 5.200014366036874]);

translate([4, 47, 0]) cube([1, 1, 5.2000165539736605]);

translate([5, 47, 0]) cube([1, 1, 5.200017219251334]);

translate([6, 47, 0]) cube([1, 1, 5.100056853596431]);

translate([7, 47, 0]) cube([1, 1, 5.000098297747391]);

translate([8, 47, 0]) cube([1, 1, 4.900148357807766]);

translate([9, 47, 0]) cube([1, 1, 4.800321134609521]);

translate([10, 47, 0]) cube([1, 1, 4.8003235484094935]);

translate([11, 47, 0]) cube([1, 1, 4.900038615562671]);

translate([12, 47, 0]) cube([1, 1, 5.000008757568675]);

translate([13, 47, 0]) cube([1, 1, 5.0000087104042175]);

translate([14, 47, 0]) cube([1, 1, 5.000006219943133]);

translate([15, 47, 0]) cube([1, 1, 4.90000515214169]);

translate([16, 47, 0]) cube([1, 1, 4.700021402132538]);

translate([17, 47, 0]) cube([1, 1, 4.6001359475981545]);

translate([18, 47, 0]) cube([1, 1, 4.501904932136686]);

translate([19, 47, 0]) cube([1, 1, 4.601186922832089]);

translate([20, 47, 0]) cube([1, 1, 4.80122851073393]);

translate([21, 47, 0]) cube([1, 1, 5.000904332778618]);

translate([22, 47, 0]) cube([1, 1, 5.200623255921133]);

translate([23, 47, 0]) cube([1, 1, 5.200774681609286]);

translate([24, 47, 0]) cube([1, 1, 5.200948088002052]);

translate([25, 47, 0]) cube([1, 1, 5.300173859365097]);

translate([26, 47, 0]) cube([1, 1, 5.4000294927329255]);

color([0,1,0])
translate([27, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([28, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([29, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([30, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([31, 47, 0]) cube([1, 1, 6]);

translate([32, 47, 0]) cube([1, 1, 5.3000000032551196]);

translate([33, 47, 0]) cube([1, 1, 5.100001875045923]);

translate([34, 47, 0]) cube([1, 1, 5.100001892662294]);

translate([35, 47, 0]) cube([1, 1, 5.100002368774493]);

translate([36, 47, 0]) cube([1, 1, 5.100002766194637]);

translate([37, 47, 0]) cube([1, 1, 5.200002036976848]);

translate([38, 47, 0]) cube([1, 1, 5.200003054730873]);

translate([39, 47, 0]) cube([1, 1, 5.300001796955579]);

translate([40, 47, 0]) cube([1, 1, 5.300002046842371]);

translate([41, 47, 0]) cube([1, 1, 5.4]);

color([0,1,0])
translate([42, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([43, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([44, 47, 0]) cube([1, 1, 6]);

color([0,1,0])
translate([45, 47, 0]) cube([1, 1, 6]);

translate([46, 47, 0]) cube([1, 1, 5.4]);

translate([47, 47, 0]) cube([1, 1, 5.3]);
