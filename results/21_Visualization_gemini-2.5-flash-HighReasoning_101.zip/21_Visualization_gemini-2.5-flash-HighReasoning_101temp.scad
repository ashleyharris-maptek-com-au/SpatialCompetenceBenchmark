
hull() {
    translate([5.0, 0.07500000000000001, 4.9925]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 1.425, 4.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 1.5750000000000002, 4.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 2.9250000000000003, 4.7075000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 3.075, 4.692500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 4.425, 4.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 4.575, 4.5424999999999995]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 5.925000000000001, 4.407500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0087, 6.0749, 4.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.1653, 7.423100000000001, 4.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.1993, 7.56695, 4.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.6547, 8.808050000000001, 4.1075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.7207, 8.9327, 4.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.4533, 9.9353, 3.9575000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.5487, 10.02845, 3.9425000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.5333000000000006, 10.70255, 3.8075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.655200000000001, 10.7539, 3.7925]) cube([0.4, 0.4, 0.1], center=true);
    translate([8.8648, 11.004100000000001, 3.6575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([9.0103, 11.004100000000001, 3.6425]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.4197, 10.7539, 3.5075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.58565, 10.70255, 3.4924999999999997]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.16335, 10.02845, 3.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.3465, 9.9353, 3.3425000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.0655, 8.9327, 3.2075000000000005]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.26275, 8.808050000000001, 3.1925000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.094250000000002, 7.56695, 3.0575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.302400000000002, 7.416300000000001, 3.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.2176, 5.9456999999999995, 2.9074999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.43345, 5.7718, 2.8925]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.40355, 4.1122, 2.7575000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.62385, 3.9188, 2.7425]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.61915, 2.0972, 2.6075000000000004]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.84075, 1.8827, 2.5925000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([24.83425, -0.1567, 2.4575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([25.0545, -0.3879, 2.4425]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.0255, -2.5101, 2.3074999999999997]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.2418, -2.7477500000000004, 2.2925]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.1642, -4.90325, 2.1575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.37405, -5.142799999999999, 2.1425]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.22895, -7.299199999999999, 2.0075000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.430000000000003, -7.536949999999999, 1.9925000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.194, -9.66005, 1.8575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.383700000000005, -9.8922, 1.8425]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.0343, -11.9478, 1.7075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.2102, -12.1708, 1.6925000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.72580000000001, -14.129199999999999, 1.5575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.885650000000005, -14.339749999999999, 1.5425]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.247350000000004, -16.17125, 1.4075]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.389100000000006, -16.36615, 1.3925]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.578900000000004, -18.042849999999998, 1.2575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.7006, -18.21945, 1.2425]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.7014, -19.72155, 1.1075000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.80125, -19.87775, 1.0925]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.597750000000005, -21.18725, 0.9575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.674150000000004, -21.3211, 0.9425]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.25285, -22.4209, 0.8075000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.3046, -22.530749999999998, 0.7925000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.6574, -23.40825, 0.6575000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.68375, -23.4929, 0.6425000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.80525, -24.1391, 0.5075000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.8057, -24.1978, 0.4925]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.6923, -24.6082, 0.3575]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.6668, -24.6407, 0.3425]) cube([0.4, 0.4, 0.1], center=true);
    translate([42.321200000000005, -24.8153, 0.20750000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([42.2702, -24.8216, 0.19250000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([41.6978, -24.7604, 0.05750000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([41.622150000000005, -24.740650000000002, 0.0425]) cube([0.4, 0.4, 0.1], center=true);
    translate([40.83285000000001, -24.446350000000002, -0.09250000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([40.733850000000004, -24.4009, -0.10750000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([39.74115, -23.8771, -0.2425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([39.62025, -23.8065, -0.2575]) cube([0.4, 0.4, 0.1], center=true);
    translate([38.43675, -23.0595, -0.39250000000000007]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([38.295500000000004, -22.9645, -0.40750000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([36.9365, -22.0015, -0.5425000000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([36.77675, -21.88275, -0.5575000000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([35.260250000000006, -20.70825, -0.6925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([35.084, -20.56645, -0.7075]) cube([0.4, 0.4, 0.1], center=true);
    translate([33.428, -19.188549999999996, -0.8425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([33.237449999999995, -19.024849999999997, -0.8575]) cube([0.4, 0.4, 0.1], center=true);
    translate([31.46355, -17.45615, -0.9925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([31.261200000000002, -17.272, -1.0075]) cube([0.4, 0.4, 0.1], center=true);
    translate([29.3928, -15.526000000000002, -1.1424999999999998]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([29.181300000000004, -15.32295, -1.1575]) cube([0.4, 0.4, 0.1], center=true);
    translate([27.242700000000003, -13.41405, -1.2925000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([27.02475, -13.1936, -1.3075]) cube([0.4, 0.4, 0.1], center=true);
    translate([25.04025, -11.1344, -1.4425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([24.8187, -10.89815, -1.4575]) cube([0.4, 0.4, 0.1], center=true);
    translate([22.8153, -8.70485, -1.5925000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([22.59315, -8.45435, -1.6075000000000002]) cube([0.4, 0.4, 0.1], center=true);
    translate([20.597849999999998, -6.13865, -1.7425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([20.378099999999996, -5.875249999999999, -1.7574999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([18.417900000000003, -3.44975, -1.8925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([18.20335, -3.1748, -1.9075]) cube([0.4, 0.4, 0.1], center=true);
    translate([16.301650000000002, -0.6512, -2.0425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([16.094250000000002, -0.36655000000000004, -2.0575]) cube([0.4, 0.4, 0.1], center=true);
    translate([14.26275, 2.23355, -2.1925000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([14.0655, 2.5262000000000002, -2.2075000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([12.3465, 5.1937999999999995, -2.3425000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([12.16335, 5.492799999999999, -2.3575000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([10.58565, 8.2072, -2.4925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([10.4197, 8.5099, -2.5075]) cube([0.4, 0.4, 0.1], center=true);
    translate([9.0103, 11.244100000000001, -2.6424999999999996]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([8.8648, 11.547600000000001, -2.6574999999999998]) cube([0.4, 0.4, 0.1], center=true);
    translate([7.655200000000001, 14.2764, -2.7925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([7.5333000000000006, 14.577900000000001, -2.8075]) cube([0.4, 0.4, 0.1], center=true);
    translate([6.5487, 17.2761, -2.9425000000000003]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([6.4533, 17.57285, -2.9575000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.7207, 20.21615, -3.0925000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.6547, 20.50545, -3.1075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.1993, 23.06955, -3.2425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.1653, 23.34865, -3.2575000000000003]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0087, 25.80835, -3.3925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 26.074550000000002, -3.4075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 28.40645, -3.5425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 28.65735, -3.5575]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 30.84165, -3.6925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 31.07505, -3.7075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 33.091950000000004, -3.8425000000000002]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 33.30575, -3.8575000000000004]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 35.13725, -3.9925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 35.32955, -4.0075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 36.95945, -4.1425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 37.128499999999995, -4.157500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 38.54149999999999, -4.2925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 38.685599999999994, -4.3075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 39.8664, -4.4425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 39.984, -4.4575]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 40.92, -4.592499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 41.0098, -4.6075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 41.6902, -4.742500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 41.7511, -4.7575]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 42.1669, -4.8925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 42.19815, -4.9075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 42.34485, -5.0424999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 42.3461, -5.0575]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 42.221900000000005, -5.192500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 42.1931, -5.2075000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 41.7989, -5.342499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 41.74025, -5.3575]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 41.07875, -5.4925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 40.99065, -5.5075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 40.06635, -5.642500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 39.94945, -5.657500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 38.76955, -5.7924999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 38.624700000000004, -5.8075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 37.197300000000006, -5.942500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 37.025600000000004, -5.9575000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 35.3624, -6.0925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 35.1653, -6.1075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 33.2807, -6.2425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 33.059900000000006, -6.2575]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 30.9701, -6.392500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 30.7275, -6.407500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 28.4505, -6.5424999999999995]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 28.188100000000002, -6.557499999999999]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 25.7419, -6.692500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 25.461850000000002, -6.7075000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 22.867150000000002, -6.8425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 22.5717, -6.8575]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 19.8483, -6.9925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 19.53985, -7.0075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 16.711149999999996, -7.1425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 16.392249999999997, -7.157500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 13.480750000000002, -7.2925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 13.152950000000002, -7.3075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 10.16405, -7.4425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 9.828499999999998, -7.4575000000000005]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 6.7775, -7.5925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 6.43565, -7.6075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, 3.3333500000000003, -7.742500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, 2.99035, -7.7575]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, -0.08135, -7.8925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, -0.4242, -7.907500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, -3.5238, -8.0425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, -3.86855, -8.057500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, -6.974450000000001, -8.192499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, -7.318850000000001, -8.2075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, -10.41215, -8.3425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, -10.754850000000001, -8.3575]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, -13.83015, -8.4925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, -14.170499999999999, -8.5075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, -17.2215, -8.6425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, -17.55875, -8.6575]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, -20.578249999999997, -8.7925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, -20.9117, -8.807500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, -23.8943, -8.942499999999999]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, -24.2232, -8.9575]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, -27.160800000000002, -9.0925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, -27.484300000000005, -9.1075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, -30.3697, -9.242500000000001]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, -30.68695, -9.2575]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, -33.51205, -9.3925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, -33.82215, -9.4075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, -36.578849999999996, -9.5425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, -36.8809, -9.557500000000001]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, -39.5611, -9.6925]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, -39.854150000000004, -9.7075]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, -42.44885000000001, -9.8425]) cube([0.4, 0.4, 0.1], center=true);
}


hull() {
    translate([5.0, -42.73185000000001, -9.8575]) cube([0.4, 0.4, 0.1], center=true);
    translate([5.0, -45.23115, -9.9925]) cube([0.4, 0.4, 0.1], center=true);
}

